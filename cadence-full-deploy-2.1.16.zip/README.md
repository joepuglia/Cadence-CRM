# Cadence CRM

Cadence is a CRM for health insurance agents. The app is a Node.js server (`server.js` loads `src/server.js`) with the browser UI in `public/`.

## Run locally

```bash
npm install
npm start
```

The server reads `.env` beside `server.js` and stores contacts in `crm.sqlite`. Neither file is part of this repo. Set `PORT` if you do not want the default port 3000.

## Spaceship deploy

`cadencecrm.pro` and `crmcadence.com` are separate site folders. Each has its own `crm.sqlite`, `tenant-data`, `uploads`, and `.env`.

Upload `cadence-full-deploy-2.1.16.zip` into each folder and follow `DEPLOY.txt`. The zip is the November program plus Duplicate and Save as, the Automations grid fix, and Computer calling on your own Settings page. It is code only. Do not copy a database from one site to the other, and do not delete the site folder before extracting.
