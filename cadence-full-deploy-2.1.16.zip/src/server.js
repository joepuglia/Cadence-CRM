const path = require("path");
require("dotenv").config({ path: path.join(__dirname, "..", ".env") });
const { installRuntimeEnvOverlay, runWithIsolatedRuntimeEnv, releaseRuntimeEnvKey } = require("./runtimeEnvOverlay");
installRuntimeEnvOverlay();

const fs = require("fs");
const os = require("os");
const crypto = require("crypto");
const express = require("express");
const cors = require("cors");
const multer = require("multer");
const { all, get, run, initDb, withTenantContext, openTenantDatabase, isTrialTenantContext, LEGACY_TENANT_ID, platformRun, platformGet, platformAll, ensureContactColumns, dbPath, dbFileExistedBeforeOpen } = require("./db");
const { hashLoginPassword, verifyLoginPassword } = require("./authPassword");
const {
  provisionTrialTenant,
  getTenantUserByEmail,
  getTenantById,
  issueNewTrialPasswordForEmail,
  restoreTrialPasswordHash,
  computeTrialState,
  markTenantExpiredIfNeeded,
  PRO_MONTHLY_USD,
  TRIAL_DAYS
} = require("./tenantPlatform");
const { normalizeSignupPhone, isValidSignupPhone, emailErrorMessage } = require("./signupValidation");
const { seedParadigmaiOutreachTemplates } = require("./paradigmaiOutreach");
const { seedCadenceOutreachTemplates } = require("./cadenceOutreach");
const {
  previewEmailBulkCampaign,
  queueEmailBulkCampaign,
  emailBulkCampaignStatus,
  emailBulkCampaignActiveList,
  cancelEmailBulkCampaign,
  pauseEmailBulkCampaign,
  resumeEmailBulkCampaign,
  pruneEmailBulkQueue,
  processDueBulkEmails,
  startEmailBulkScheduler
} = require("./emailBulkCampaign");
const {
  isStripeConfigured,
  createCheckoutSession,
  handleStripeWebhook,
  createBillingPortalSession,
  getStripeConfigSummary,
  isStripeWebhookConfigured
} = require("./billing");
const twilioSdk = require("twilio");
const { AccessToken } = twilioSdk.jwt;
const VoiceGrant = AccessToken.VoiceGrant;
const {
  sendSms,
  composeOutboundSms,
  startCall,
  startCallRecording,
  getCallStatus,
  endCall,
  normalizeTwilioFromLine,
  normalizePhoneRecipient,
  resolveFromNumber,
  resolveFromNumberWithFallback,
  fetchVoiceTwimlApp,
  syncVoiceTwimlAppUrl,
  isLikelyTwilioApiKey,
  isLikelyTwilioApiSecret,
  verifyTwilioVoiceApiCredentials,
  provisionVoiceApiKey,
  createVoiceTwimlApp,
  getVoiceProvider,
  getVoiceProviderMode,
  isSignalWireVoiceReady,
  getSignalWireMissing,
  isTwilioSmsReady
} = require("./twilioService");
const {
  sendEmail,
  sendTrialWelcomeEmail: deliverTrialWelcomeEmail,
  sendSystemNotificationEmail,
  isEmailConfigured,
  isOutboundEmailReady,
  canSendTrialWelcomeEmail,
  canSendSystemNotificationEmail,
  isTrialWelcomeSmtpConfigured,
  verifyTrialWelcomeSmtp,
  getTrialWelcomeSmtpMissing,
  getTrialWelcomeFromAddress,
  getTrialWelcomeSmtpHost,
  invalidatePerAddressTransporters
} = require("./emailService");
const {
  startFollowUpReminderScheduler,
  isTaskSmsRemindersEnabled,
  describeTaskSmsRoute,
  resolveReminderEmailTo,
  reminderEmailCanSend,
  remindTaskById,
  processTaskReminders,
  processFollowUpReminders,
  getLastTaskSmsError
} = require("./followUpReminderScheduler");
const { ensureVapidKeys, getVapidPublicKey } = require("./vapidKeys");
const { parseContactsCsv, columnMappingObject, createdAtMappedInColumnMapping, resolveImportCreatedAtSql } = require("./csvImport");
const {
  mergeInitialImportTag,
  activateInitialImportOmit,
  maybeCompleteExpiredInitialImportOmit,
  sqlExcludeInitialImportTags,
  tagNewContactsAsImportedBook,
  countTaggedInitialImport,
  countUntaggedNewContacts,
  completeInitialImportOmit
} = require("./initialImportOmit");
const { buildRenewalItems, renewalsInDateRange } = require("./renewals");
const { buildAttentionQueue } = require("./attentionQueue");
const { encryptField, decryptContactBankFields } = require("./fieldEncryption");
const { registerImportRoutes } = require("./importRoutes");
const { registerDripRoutes } = require("./dripRoutes");
const { rememberTags, collectKnownTags, uniqueTags } = require("./savedTags");
const { registerAssistantRoutes, registerAiCampaignRoute, registerReengageRoute, collectPipelineSnapshot } = require("./assistantRoutes");
const { registerRolePlayRoutes } = require("./rolePlayRoutes");
const { registerAiContentRoutes } = require("./aiContentRoutes");
const marketingBlog = require("./marketingBlog");
const { registerAiFeatureRoutes, scheduleAutoLeadScore, normalizeSoldLeadScores } = require("./aiFeatureRoutes");
const { registerEmailVerificationRoutes, recordApolloVerifiedFromCsv } = require("./emailVerifier");
const { registerInsuranceApplicationRoutes } = require("./insuranceApplicationRoutes");
const { registerClientIntakeRoutes } = require("./clientIntakeRoutes");
const { registerContactWorkspaceOptionsRoutes } = require("./contactWorkspaceOptions");
const { registerEmailSignatureSettingsRoutes } = require("./emailSignatureSettings");
const { registerEmailTemplateBrandingRoutes } = require("./emailTemplateBrandingSettings");
const { registerWebinarRoutes } = require("./webinarRoutes");
const {
  parseRecordCallFlag,
  isVoiceWebhookRecordEnabled,
  resolveVoiceWebhookRecordEnabled,
  getCallRecordingDefault,
  setCallRecordingDefault,
  buildRecordingStatusCallbackUrl,
  getWebhookPublicOrigin,
  crmPublicUrlHasPathSuffix,
  buildCallWithRecordingDetail,
  formatCallActivityDetailForDisplay,
  parseCallWithRecordingDetail,
  trackCallRecordingPending,
  handleTwilioRecordingStatusWebhook,
  listContactCallRecordings,
  syncCallRecordingsFromTwilio,
  resolveContactIdByPhone
} = require("./twilioCallRecording");
const { sortCustomTwilioRows } = require("./twilioNumberSort");
const { startDripScheduler, processDueDripSends } = require("./dripScheduler");
const { wrapEmailLinksForClickTracking, recordEmailClickAndGetDestination } = require("./emailClickTracking");
const { startSocialScheduler } = require("./socialScheduler");
const { startTrialOnboardingScheduler } = require("./trialOnboardingScheduler");
const { startPhoneCleanupScheduler } = require("./phoneCleanupScheduler");
const {
  startBounceScheduler,
  processBounces: runBounceProcessing,
  ensureBounceSchema,
  bounceConfig,
  getLastRun: getBounceLastRun
} = require("./bounceProcessor");
const { enrollContactInCampaign, maybeEnrollFromContactTags } = require("./dripEnrollment");
const googleCalendar = require("./googleCalendar");
const {
  THANKS_IO_APP_URL,
  maskThanksIoToken,
  verifyThanksIoApiKey
} = require("./thanksIo");
const { maskAnthropicApiKey, verifyAnthropicApiKey, sanitizeAnthropicApiKey } = require("./claudeClient");
const {
  normalizeMergeKey,
  normalizeMergeFieldScope,
  overlayContactCustomFields,
  parseContactCustomFieldValues,
  isPolicyRenewalMergeSlug,
  RESERVED_MERGE_FIELD_KEYS,
  contactRowToMergeFields,
  applyMergeFields
} = require("./mergeFields");
const {
  verifyUnsubscribeToken,
  prepareOutboundEmailWithUnsubscribe,
  isUnsubscribeReplyContent,
  extractReplyEmailAddress,
  markEmailUnsubscribed
} = require("./emailUnsubscribe");
const { attachEmailOpenPixel } = require("./emailOpenTracking");
const { registerAuth2faRoutes } = require("./auth2fa");
const { TERMS_VERSION, isTermsAcceptanceValid } = require("./termsOfService");

const dbDeps = () => ({ run, get, all });
const auth2faState = { completeLoginOrChallenge: null };

const app = express();
const port = process.env.PORT || 3000;
const publicDir = path.join(__dirname, "..", "public");
const indexHtmlPath = path.join(publicDir, "index.html");
const packageJsonPath = path.join(__dirname, "..", "package.json");
const uploadsDir = path.join(__dirname, "..", "uploads", "documents");
const uploadsVideosDir = path.join(__dirname, "..", "uploads", "videos");
const uploadsFormsDir = path.join(__dirname, "..", "uploads", "forms");
const uploadsSocialDir = path.join(__dirname, "..", "uploads", "social");
const uploadsSmsDir = path.join(__dirname, "..", "uploads", "sms");
const uploadsSmsStepsDir = path.join(__dirname, "..", "uploads", "sms-steps");
const {
  SMS_PHOTO_MAX_BYTES,
  SMS_PHOTO_TTL_MS,
  signSmsMediaToken,
  verifySmsMediaToken,
  saveSmsPhoto,
  resolveSmsPhoto
} = require("./smsMedia");
const { toRelativeUploadPath, resolveStoredUploadPath, uploadsRootDir } = require("./uploadPaths");
const AUTH_COOKIE_NAME = "crm_auth";
const AUTH_SESSION_MAX_AGE_MS = 8 * 60 * 60 * 1000;
const AUTH_IDLE_TIMEOUT_MS = 60 * 60 * 1000;
const AUTH_ACTIVITY_TOUCH_MS = 60 * 1000;
/** @deprecated Legacy in-memory sessions; new logins use signed cookies (works across cPanel workers). */
const authSessions = new Map();
const masterKeyPath = path.join(__dirname, "..", "crm-master-key.txt");

app.use((req, res, next) => {
  res.setHeader("X-Cadence-Build", DEPLOY_UI_STAMP);
  const pathLower = String(req.path || "").toLowerCase();
  const isHtml =
    pathLower.endsWith(".html") ||
    pathLower === "/" ||
    pathLower === "/index.html";
  if (isHtml) {
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    res.setHeader("Surrogate-Control", "no-store");
  }
  next();
});

/* =========================================================================
   Security helpers — see SECURITY review:
     - getMasterEncryptionKey / encryptSecret / decryptSecret
       Encrypt Twilio Auth Token and API Secret at rest in twilio_runtime_config.
       Plaintext rows already present are still readable (backward-compatible)
       and re-encrypted on next save.
     - maskSecret
       Used by GET /api/twilio/config so the raw token never leaves the server.
     - isLocalRequest
       Allows a one-time setup window from the host machine when login isn't
       configured yet (see item #6 in SECURITY review).
     - createRateLimiter
       Lightweight in-memory limiter for Twilio-billable endpoints and login.
     - twilioWebhookGuard
       Validates X-Twilio-Signature on every /webhooks/twilio/* request.
   ========================================================================= */

function getMasterEncryptionKey() {
  const envKey = String(process.env.CRM_SECRET_KEY || "").trim();
  if (envKey) {
    try {
      const buf = Buffer.from(envKey, "hex");
      if (buf.length === 32) return buf;
    } catch {
      // fall through to file-based key
    }
    console.warn("CRM_SECRET_KEY in env is not a 32-byte hex string; ignoring.");
  }
  try {
    if (fs.existsSync(masterKeyPath)) {
      const stored = fs.readFileSync(masterKeyPath, "utf8").trim();
      const buf = Buffer.from(stored, "hex");
      if (buf.length === 32) {
        process.env.CRM_SECRET_KEY = stored;
        return buf;
      }
    }
  } catch (err) {
    console.warn("Could not read master key file:", err.message || err);
  }
  const fresh = crypto.randomBytes(32);
  try {
    fs.writeFileSync(masterKeyPath, fresh.toString("hex"), { encoding: "utf8", mode: 0o600 });
    process.env.CRM_SECRET_KEY = fresh.toString("hex");
    console.warn(`Generated new master encryption key at ${masterKeyPath}. KEEP THIS FILE SAFE — losing it makes stored Twilio credentials unrecoverable. For production, copy its contents into the CRM_SECRET_KEY env var and remove the file.`);
  } catch (err) {
    console.error("Failed to persist master encryption key:", err.message || err);
  }
  return fresh;
}

function encryptSecret(plain) {
  const s = String(plain == null ? "" : plain);
  if (!s) return "";
  const key = getMasterEncryptionKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  const enc = Buffer.concat([cipher.update(s, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `enc:v1:${iv.toString("hex")}:${tag.toString("hex")}:${enc.toString("hex")}`;
}

function decryptSecret(stored) {
  const raw = String(stored == null ? "" : stored);
  if (!raw) return "";
  if (!raw.startsWith("enc:v1:")) {
    /* Legacy plaintext value left over from before encryption was introduced.
       Returned as-is so existing deployments keep working; saved values
       re-encrypt on next write. */
    return raw;
  }
  try {
    const parts = raw.split(":");
    if (parts.length < 5) return "";
    const iv = Buffer.from(parts[2], "hex");
    const tag = Buffer.from(parts[3], "hex");
    const enc = Buffer.from(parts[4], "hex");
    const key = getMasterEncryptionKey();
    const decipher = crypto.createDecipheriv("aes-256-gcm", key, iv);
    decipher.setAuthTag(tag);
    const dec = Buffer.concat([decipher.update(enc), decipher.final()]);
    return dec.toString("utf8");
  } catch (err) {
    console.error("Failed to decrypt stored secret:", err.message || err);
    return "";
  }
}

function maskSecret(value) {
  const s = String(value || "");
  if (!s) return "";
  if (s.length <= 6) return "•".repeat(s.length);
  const last4 = s.slice(-4);
  return `${"•".repeat(Math.max(4, Math.min(24, s.length - 4)))}${last4}`;
}

function isLocalRequest(req) {
  const host = String((req && (req.headers["x-forwarded-host"] || req.headers.host)) || "")
    .split(",")[0]
    .trim()
    .replace(/:\d+$/, "")
    .toLowerCase();
  // LiteSpeed connects to Node from 127.0.0.1 for every public visitor.
  // A public hostname must not count as the local setup bypass.
  if (host && !isPrivateOrLocalHostname(host)) return false;

  const forwarded = String((req && req.headers["x-forwarded-for"]) || "")
    .split(",")[0]
    .trim()
    .replace(/^::ffff:/, "");
  const ip = (
    forwarded ||
    String(
      (req && req.ip) ||
        (req && req.socket && req.socket.remoteAddress) ||
        (req && req.connection && req.connection.remoteAddress) ||
        ""
    )
  ).replace(/^::ffff:/, "");
  return ip === "127.0.0.1" || ip === "::1" || ip === "localhost";
}

/** Local-only bypass for scripts/capture-marketing-screenshots.js (see CRM_SCREENSHOT_SECRET). */
function isMarketingScreenshotRequest(req) {
  const secret = String(process.env.CRM_SCREENSHOT_SECRET || "").trim();
  if (!secret || !isLocalRequest(req)) return false;
  const header = String((req.get && req.get("x-crm-screenshot-secret")) || "").trim();
  return header === secret;
}

/* In-memory sliding-window rate limiter. Keys default to client IP (or
   X-Forwarded-For first hop) so multiple authenticated users on the same
   network each get their own bucket. */
function createRateLimiter({ windowMs, max, label, keyFn }) {
  const buckets = new Map();
  const interval = setInterval(() => {
    const now = Date.now();
    for (const [k, v] of buckets.entries()) {
      if (now >= v.resetAt) buckets.delete(k);
    }
  }, Math.max(60_000, windowMs));
  if (typeof interval.unref === "function") interval.unref();
  return (req, res, next) => {
    const now = Date.now();
    const ipRaw = (req.headers["x-forwarded-for"] || req.ip || req.socket?.remoteAddress || "anon").toString();
    const ip = ipRaw.split(",")[0].trim() || "anon";
    const key = keyFn ? `${ip}:${keyFn(req)}` : ip;
    const entry = buckets.get(key) || { count: 0, resetAt: now + windowMs };
    if (now >= entry.resetAt) {
      entry.count = 0;
      entry.resetAt = now + windowMs;
    }
    entry.count += 1;
    buckets.set(key, entry);
    if (entry.count > max) {
      const retryAfter = Math.max(1, Math.ceil((entry.resetAt - now) / 1000));
      res.setHeader("Retry-After", String(retryAfter));
      console.warn(`Rate limit hit (${label || "endpoint"}): ip=${ip} count=${entry.count}/${max}`);
      return res.status(429).json({ error: "Too many requests; please slow down.", retryAfterSeconds: retryAfter });
    }
    next();
  };
}

const twilioCallLimiter = createRateLimiter({ windowMs: 60_000, max: 30, label: "twilio-call" });
const twilioSmsLimiter = createRateLimiter({ windowMs: 60_000, max: 30, label: "twilio-sms" });
const voiceTokenLimiter = createRateLimiter({ windowMs: 60_000, max: 12, label: "voice-token" });
const authLoginLimiter = createRateLimiter({ windowMs: 15 * 60_000, max: 10, label: "auth-login" });
const subscriptionSignupLimiter = createRateLimiter({ windowMs: 60_000, max: 5, label: "subscription-signup" });
const forgotPasswordLimiter = createRateLimiter({ windowMs: 60 * 60_000, max: 5, label: "auth-forgot-password" });
/** One signup per email at a time — stops double-clicks from sending the "already registered" email. */
const signupInFlight = new Map();
const SIGNUP_DUPLICATE_WINDOW_MS = 120_000;

function withSignupLock(email, fn) {
  const key = String(email || "")
    .trim()
    .toLowerCase();
  const prev = signupInFlight.get(key) || Promise.resolve();
  const run = prev.then(() => fn()).finally(() => {
    if (signupInFlight.get(key) === run) signupInFlight.delete(key);
  });
  signupInFlight.set(key, run);
  return run;
}
const salesContactLimiter = createRateLimiter({ windowMs: 60_000, max: 5, label: "sales-contact" });
/** Public lead/intake forms — stop spam floods without blocking real applicants. */
const publicFormsLimiter = createRateLimiter({ windowMs: 60_000, max: 12, label: "public-forms" });
let cachedTwimlAppVoiceUrl = "";

async function refreshCachedTwimlAppVoiceUrl() {
  const sid = String(process.env.TWILIO_VOICE_TWIML_APP_SID || "").trim();
  if (!sid) {
    cachedTwimlAppVoiceUrl = "";
    return cachedTwimlAppVoiceUrl;
  }
  try {
    const app = await fetchVoiceTwimlApp(sid);
    cachedTwimlAppVoiceUrl = String(app.voiceUrl || "").trim().replace(/\/$/, "");
  } catch (err) {
    console.warn("[voice] Could not cache TwiML app voice URL:", err.message || err);
  }
  return cachedTwimlAppVoiceUrl;
}

function addTwilioWebhookUrlVariant(set, rawUrl) {
  const url = String(rawUrl || "").trim();
  if (!url) return;
  set.add(url);
  try {
    const u = new URL(url);
    const proto = u.protocol || "https:";
    const host = u.host;
    const pathname = u.pathname || "/";
    const pathNoTrail = pathname.replace(/\/$/, "") || pathname;
    const pathWithTrail = pathNoTrail.endsWith("/") ? pathNoTrail : `${pathNoTrail}/`;
    const search = u.search || "";
    const bases = [
      `${proto}//${host}${pathname}${search}`,
      `${proto}//${host}${pathNoTrail}${search}`,
      `${proto}//${host}${pathWithTrail}${search}`
    ];
    for (const base of bases) set.add(base);
    const hostNoPort = host.split(":")[0];
    if (hostNoPort.startsWith("www.")) {
      const bare = hostNoPort.slice(4);
      const port = host.includes(":") ? host.slice(host.indexOf(":")) : "";
      for (const p of [pathNoTrail, pathWithTrail, pathname]) {
        set.add(`${proto}//${bare}${port}${p}${search}`);
      }
    } else if (hostNoPort) {
      const port = host.includes(":") ? host.slice(host.indexOf(":")) : "";
      for (const p of [pathNoTrail, pathWithTrail, pathname]) {
        set.add(`${proto}//www.${hostNoPort}${port}${p}${search}`);
      }
    }
  } catch {
    // keep raw url only
  }
}

function computeTwilioWebhookSignature(authToken, url, params) {
  const token = String(authToken || "").trim();
  const targetUrl = String(url || "").trim();
  const body = params && typeof params === "object" ? params : {};
  if (!token || !targetUrl) return "";
  if (typeof twilioSdk.getExpectedTwilioSignature === "function") {
    try {
      return twilioSdk.getExpectedTwilioSignature(token, targetUrl, body);
    } catch {
      // fall through to manual HMAC
    }
  }
  let data = targetUrl;
  for (const key of Object.keys(body).sort()) {
    data += key + String(body[key] ?? "");
  }
  return crypto.createHmac("sha1", token).update(Buffer.from(data, "utf8")).digest("base64");
}

function buildTwilioWebhookUrlCandidates(req) {
  const path = String(req.originalUrl || req.url || "");
  const pathOnly = path.split("?")[0];
  const query = path.includes("?") ? path.slice(path.indexOf("?")) : "";
  const forwardedProto = String(req.get("x-forwarded-proto") || "").split(",")[0].trim();
  const forwardedHost = String(req.get("x-forwarded-host") || req.get("x-original-host") || "")
    .split(",")[0]
    .trim();
  const host = forwardedHost || req.get("host") || "";
  const isLocalHost = /^(localhost|127\.0\.0\.1)(:\d+)?$/i.test(host);
  const proto = forwardedProto || (isLocalHost ? req.protocol : "https") || "https";
  const candidates = new Set();
  if (host) {
    addTwilioWebhookUrlVariant(candidates, `${proto}://${host}${path}`);
    addTwilioWebhookUrlVariant(candidates, `${proto}://${host}${pathOnly}${query}`);
    addTwilioWebhookUrlVariant(candidates, `${proto}://${host}${pathOnly}`);
  }
  const publicBase = String(process.env.CRM_PUBLIC_URL || "").trim().replace(/\/$/, "");
  if (publicBase) {
    addTwilioWebhookUrlVariant(candidates, `${publicBase}${path}`);
    addTwilioWebhookUrlVariant(candidates, `${publicBase}${pathOnly}${query}`);
    addTwilioWebhookUrlVariant(candidates, `${publicBase}${pathOnly}`);
  }
  if (cachedTwimlAppVoiceUrl) {
    addTwilioWebhookUrlVariant(candidates, cachedTwimlAppVoiceUrl);
  }
  return [...candidates];
}

function twilioWebhookGuard(req, res, next) {
  if (envFlag("TWILIO_WEBHOOK_SKIP_VALIDATION")) {
    /* Escape hatch for local dev / unit tests. Never enable in production. */
    return next();
  }
  Promise.resolve()
    .then(async () => {
      if (String(req.originalUrl || "").includes("/webhooks/twilio/voice") && !cachedTwimlAppVoiceUrl) {
        await refreshCachedTwimlAppVoiceUrl();
      }
      const authToken = String(process.env.TWILIO_AUTH_TOKEN || "").trim();
      if (!authToken) {
        console.warn("Twilio webhook signature check skipped: TWILIO_AUTH_TOKEN missing");
        res.status(503).type("text/plain").send("Twilio not configured");
        return;
      }
      const signature = String(req.get("X-Twilio-Signature") || "");
      if (!signature) {
        const isVoiceWebhook = String(req.originalUrl || "").includes("/webhooks/twilio/voice");
        // Twilio Console and some CDN probes GET this URL without a signature.
        // Real headset calls POST with a signature and still go through validation.
        if (isVoiceWebhook && req.method === "GET") {
          console.warn(`[voice-webhook] GET without signature allowed: ${req.originalUrl}`);
          next();
          return;
        }
        console.warn(`Twilio webhook rejected (no signature): ${req.method} ${req.originalUrl}`);
        res.status(403).type("text/plain").send("Missing Twilio signature");
        return;
      }
      const params = req.method === "GET" ? {} : req.body && typeof req.body === "object" ? req.body : {};
      const candidates = buildTwilioWebhookUrlCandidates(req);
      let matchedUrl = "";
      for (const url of candidates) {
        try {
          if (twilioSdk.validateRequest(authToken, signature, url, params)) {
            matchedUrl = url;
            break;
          }
        } catch (err) {
          console.warn("Twilio signature validation threw:", err && err.message);
        }
      }
      if (!matchedUrl) {
        console.warn(
          `Twilio webhook signature rejected: ${req.method} ${req.originalUrl} (tried: ${candidates.join(", ")})`
        );
        res.status(403).type("text/plain").send("Invalid Twilio signature");
        return;
      }
      if (String(req.originalUrl || "").includes("/webhooks/twilio/voice")) {
        console.info(`[voice-webhook] signature ok via ${matchedUrl}`);
      }
      next();
    })
    .catch((err) => {
      console.error("[twilio-webhook] guard error:", err.message || err);
      if (!res.headersSent) res.status(500).type("text/plain").send("Webhook guard failed");
    });
}

async function reloadTwilioConfigForWebhook(req, res, next) {
  try {
    await loadTwilioRuntimeConfigFromDb();
    await refreshCachedTwimlAppVoiceUrl();
  } catch (err) {
    console.warn("[twilio-webhook] config reload failed:", err.message || err);
  }
  next();
}

function envFlag(name) {
  const v = String(process.env[name] || "").trim().toLowerCase();
  return v === "1" || v === "true" || v === "yes" || v === "on";
}
let appVersion = "dev";
try {
  const pkg = JSON.parse(fs.readFileSync(packageJsonPath, "utf8"));
  appVersion = String(pkg?.version || "dev").trim() || "dev";
} catch {
  // ignore package.json read errors
}
const appBootStamp = new Date().toISOString().replace("T", " ").replace("Z", " UTC");
/** Bump when UI deploy packs change - compare on production via GET /api/runtime/build-stamp */
const DEPLOY_UI_STAMP = "nov-features-20261125";
const buildStampText = `Build v${appVersion} | ${DEPLOY_UI_STAMP} | ${appBootStamp}`;
const staleRootIndexPath = path.join(__dirname, "..", "index.html");

if (fs.existsSync(staleRootIndexPath)) {
  console.warn(
    "[deploy] Stale index.html at app root will make https://yoursite/ show OLD UI. " +
      "Delete this file (keep public/index.html): " +
      staleRootIndexPath
  );
}

if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}
if (!fs.existsSync(uploadsVideosDir)) {
  fs.mkdirSync(uploadsVideosDir, { recursive: true });
}
if (!fs.existsSync(uploadsFormsDir)) {
  fs.mkdirSync(uploadsFormsDir, { recursive: true });
}
if (!fs.existsSync(uploadsSocialDir)) {
  fs.mkdirSync(uploadsSocialDir, { recursive: true });
}
if (!fs.existsSync(uploadsSmsDir)) {
  fs.mkdirSync(uploadsSmsDir, { recursive: true });
}
if (!fs.existsSync(uploadsSmsStepsDir)) {
  fs.mkdirSync(uploadsSmsStepsDir, { recursive: true });
}

function guessVideoMimeFromFilename(name) {
  const ext = path.extname(String(name || "")).toLowerCase();
  const map = {
    ".mp4": "video/mp4",
    ".webm": "video/webm",
    ".ogg": "video/ogg",
    ".ogv": "video/ogg",
    ".mov": "video/quicktime",
    ".m4v": "video/x-m4v",
    ".avi": "video/x-msvideo",
    ".mkv": "video/x-matroska",
    ".wmv": "video/x-ms-wmv",
    ".mpeg": "video/mpeg",
    ".mpg": "video/mpeg",
    ".3gp": "video/3gpp",
    ".3g2": "video/3gpp2"
  };
  return map[ext] || "";
}

const pcVideoUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, uploadsVideosDir),
    filename: (req, file, cb) => {
      const safe = String(file.originalname || "video.bin").replace(/[<>:"/\\|?*\x00-\x1F]/g, "_");
      cb(null, `${Date.now()}_${Math.floor(Math.random() * 1e6)}_${safe}`);
    }
  }),
  limits: { fileSize: 500 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname || "").toLowerCase();
    const videoExts = new Set([
      ".mp4",
      ".webm",
      ".ogg",
      ".ogv",
      ".mov",
      ".m4v",
      ".avi",
      ".mkv",
      ".wmv",
      ".mpeg",
      ".mpg",
      ".3gp",
      ".3g2"
    ]);
    const mime = String(file.mimetype || "").toLowerCase();
    if (mime.startsWith("video/")) return cb(null, true);
    if (videoExts.has(ext)) return cb(null, true);
    if (mime === "application/octet-stream" && videoExts.has(ext)) return cb(null, true);
    cb(new Error("Choose a video file from your computer (for example .mp4 or .mov)."));
  }
});

function guessFormMimeFromFilename(name) {
  const ext = path.extname(String(name || "")).toLowerCase();
  const map = {
    ".pdf": "application/pdf",
    ".doc": "application/msword",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".xls": "application/vnd.ms-excel",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".ppt": "application/vnd.ms-powerpoint",
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".csv": "text/csv",
    ".txt": "text/plain",
    ".html": "text/html",
    ".htm": "text/html",
    ".rtf": "application/rtf",
    ".odt": "application/vnd.oasis.opendocument.text",
    ".ods": "application/vnd.oasis.opendocument.spreadsheet",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".tif": "image/tiff",
    ".tiff": "image/tiff",
    ".webp": "image/webp"
  };
  return map[ext] || "";
}

const FORM_FILE_EXTS = new Set([
  ".pdf",
  ".doc",
  ".docx",
  ".xls",
  ".xlsx",
  ".ppt",
  ".pptx",
  ".csv",
  ".txt",
  ".html",
  ".htm",
  ".rtf",
  ".odt",
  ".ods",
  ".jpg",
  ".jpeg",
  ".png",
  ".gif",
  ".tif",
  ".tiff",
  ".webp"
]);

const pcFormUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, uploadsFormsDir),
    filename: (req, file, cb) => {
      const safe = String(file.originalname || "form.bin").replace(/[<>:"/\\|?*\x00-\x1F]/g, "_");
      cb(null, `${Date.now()}_${Math.floor(Math.random() * 1e6)}_${safe}`);
    }
  }),
  limits: { fileSize: 75 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname || "").toLowerCase();
    const mime = String(file.mimetype || "").toLowerCase();
    if (FORM_FILE_EXTS.has(ext)) return cb(null, true);
    if (mime === "application/octet-stream" && FORM_FILE_EXTS.has(ext)) return cb(null, true);
    if (
      mime.startsWith("image/") ||
      mime.startsWith("text/") ||
      mime === "application/pdf" ||
      mime.includes("word") ||
      mime.includes("excel") ||
      mime.includes("spreadsheet") ||
      mime.includes("powerpoint") ||
      mime.includes("officedocument") ||
      mime.includes("opendocument")
    ) {
      return cb(null, true);
    }
    cb(new Error("Choose a form file from your PC (PDF, Word, Excel, CSV, HTML, image, etc.)."));
  }
});

const SOCIAL_MEDIA_EXTS = new Set([
  ".jpg",
  ".jpeg",
  ".png",
  ".gif",
  ".webp",
  ".mp4",
  ".mov",
  ".m4v",
  ".webm"
]);

const pcSocialMediaUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, uploadsSocialDir),
    filename: (req, file, cb) => {
      const safe = String(file.originalname || "social-media.bin").replace(/[<>:"/\\|?*\x00-\x1F]/g, "_");
      cb(null, `${Date.now()}_${Math.floor(Math.random() * 1e6)}_${safe}`);
    }
  }),
  limits: { fileSize: 150 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname || "").toLowerCase();
    const mime = String(file.mimetype || "").toLowerCase();
    if (SOCIAL_MEDIA_EXTS.has(ext)) return cb(null, true);
    if (mime.startsWith("image/") || mime.startsWith("video/")) return cb(null, true);
    if (mime === "application/octet-stream" && SOCIAL_MEDIA_EXTS.has(ext)) return cb(null, true);
    cb(new Error("Choose an image or video for social media posting."));
  }
});

const pcSmsPhotoUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: SMS_PHOTO_MAX_BYTES }
});

function smsPhotoUpload(req, res, next) {
  pcSmsPhotoUpload.single("photo")(req, res, (err) => {
    if (!err) return next();
    if (err && err.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ error: "That photo is too large for a text. Use a picture under 5 MB." });
    }
    return res.status(400).json({ error: (err && err.message) || "Could not read that photo." });
  });
}

function smsPhotoPublicUrl(req) {
  if (!req.file || !req.file.buffer || !req.file.buffer.length) return "";
  const saved = saveSmsPhoto(uploadsSmsDir, req.file.buffer);
  const exp = Date.now() + SMS_PHOTO_TTL_MS;
  const sig = signSmsMediaToken(getAuthSigningSecret(), saved.id, exp);
  return `${socialMediaPublicOrigin(req)}/api/sms/media/${saved.id}?${new URLSearchParams({
    e: String(exp),
    s: sig
  }).toString()}`;
}

async function rememberSmsEndingFromBody(body) {
  if (!body || !Object.prototype.hasOwnProperty.call(body, "smsEnding")) return;
  const smsEnding = String(body.smsEnding || "").replace(/[ \t\u00A0]+$/g, "").trim().slice(0, 300);
  await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, ["smsEnding", smsEnding]);
  process.env.CRM_SMS_ENDING = smsEnding;
}

function smsActivityText(body, hasPhoto) {
  const text = composeOutboundSms(String(body || "").trim());
  if (hasPhoto && text) return `Sent SMS with a photo: ${text}`;
  if (hasPhoto) return "Sent SMS with a photo";
  return `Sent SMS: ${text}`;
}

function templateBodyToHtml(body) {
  return String(body || "")
    .split(/\r?\n/)
    .map((line) =>
      String(line)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
    )
    .join("<br>");
}

app.set("trust proxy", 1);

function buildTwilioFromNumbersScript(req) {
  // Stub only — client always refreshes from GET /api/twilio/from-numbers
  // (includes custom rows + labels). Do not treat this as a complete cache.
  const includeEnvLines = req ? !isTrialWorkspaceSession(req) : true;
  const payload = JSON.stringify({
    primary: includeEnvLines ? String(process.env.TWILIO_PHONE_NUMBER || "").trim() || null : null,
    secondary: includeEnvLines ? String(process.env.TWILIO_PHONE_NUMBER_SECOND || "").trim() || null : null,
    third: includeEnvLines ? String(process.env.TWILIO_PHONE_NUMBER_THIRD || "").trim() || null : null,
    custom: [],
    partial: true
  });
  return `<script id="twilio-from-config">window.__TWILIO_FROM_NUMBERS__=${payload};</script>`;
}

function getTwilioFromLine(body) {
  if (!body || typeof body !== "object") return "primary";
  if (body.twilioFrom != null && String(body.twilioFrom).trim() !== "") {
    return normalizeTwilioFromLine(body.twilioFrom);
  }
  if (body.useSecondary) return "secondary";
  return "primary";
}

function normalizeTwilioPhoneInput(raw) {
  const s = String(raw || "").trim();
  if (!s) return "";
  const withPlus = s.startsWith("+") ? s : `+${s}`;
  if (!/^\+[1-9]\d{6,14}$/.test(withPlus)) return "";
  return withPlus;
}

function normalizeTwilioLineKey(raw) {
  const key = String(raw || "")
    .trim()
    .toLowerCase();
  return key === "primary" || key === "secondary" || key === "third" ? key : "";
}

/** Keys loaded from twilio_runtime_config into process.env (per-request for trial workspaces). */
const RUNTIME_CONFIG_ENV_KEYS = [
  "TWILIO_ACCOUNT_SID",
  "TWILIO_AUTH_TOKEN",
  "TWILIO_API_KEY",
  "TWILIO_API_SECRET",
  "TWILIO_VOICE_TWIML_APP_SID",
  "TWILIO_VOICE_IDENTITY",
  "TWILIO_INBOUND_FORWARD_TO",
  "TWILIO_PHONE_NUMBER",
  "TWILIO_PHONE_NUMBER_SECOND",
  "TWILIO_PHONE_NUMBER_THIRD",
  "CRM_LOGIN_2FA_ENABLED",
  "SOCIAL_EXTRA_PLATFORMS",
  "SMTP_HOST",
  "SMTP_PORT",
  "SMTP_USER",
  "SMTP_PASS",
  "SMTP_FROM",
  "SMTP_SECURE",
  "CRM_PUBLIC_URL",
  "CRM_SMS_ENDING",
  "THANKS_IO_API_KEY",
  "ANTHROPIC_API_KEY"
];

function clearRuntimeConfigEnvOverrides() {
  for (const key of RUNTIME_CONFIG_ENV_KEYS) {
    delete process.env[key];
  }
  for (const key of Object.keys(process.env)) {
    if (String(key).startsWith("SOCIAL_") && String(key).endsWith("_WEBHOOK_URL")) {
      delete process.env[key];
    }
  }
}

function snapshotRuntimeEnv() {
  const snap = {};
  for (const key of RUNTIME_CONFIG_ENV_KEYS) {
    if (process.env[key] !== undefined) snap[key] = process.env[key];
  }
  for (const key of Object.keys(process.env)) {
    if (String(key).startsWith("SOCIAL_") && String(key).endsWith("_WEBHOOK_URL")) {
      snap[key] = process.env[key];
    }
  }
  return snap;
}

function restoreRuntimeEnv(snap) {
  if (!snap) return;
  clearRuntimeConfigEnvOverrides();
  for (const [key, value] of Object.entries(snap)) {
    if (value !== undefined && value !== "") process.env[key] = value;
  }
}

async function loadTwilioRuntimeConfigFromDb(options = {}) {
  const trialWorkspace = Boolean(options.trialWorkspace);
  let envFallbackToken = "";
  let envFallbackApiKey = "";
  let envFallbackApiSecret = "";
  try {
    const rows = await all(`SELECT key, value FROM twilio_runtime_config`);
    const map = new Map((Array.isArray(rows) ? rows : []).map((r) => [String(r.key || ""), String(r.value || "")]));
    if (trialWorkspace) {
      clearRuntimeConfigEnvOverrides();
      /* Blank the main sign-in on this request only. The overlay keeps the real values. */
      process.env.CRM_LOGIN_EMAIL = "";
      process.env.CRM_LOGIN_PASSWORD_HASH = "";
      process.env.CRM_AGENT_NAME = "";
      process.env.CRM_AGENT_PHONE = "";
    } else {
      /* Remember .env secrets before clearing them. A failed decrypt must not
         erase a working Auth Token and leave Start Call with nothing. */
      envFallbackToken = String(process.env.TWILIO_AUTH_TOKEN || "").trim();
      envFallbackApiKey = String(process.env.TWILIO_API_KEY || "").trim();
      envFallbackApiSecret = String(process.env.TWILIO_API_SECRET || "").trim();
      /* Drop stale .env Twilio values so a failed decrypt cannot leave a wrong API secret paired with a new API key. */
      delete process.env.TWILIO_API_KEY;
      delete process.env.TWILIO_API_SECRET;
      delete process.env.TWILIO_AUTH_TOKEN;
    }
    const sid = String(map.get("accountSid") || "").trim();
    const tokenRaw = map.get("authToken") || "";
    const token = String(decryptSecret(tokenRaw) || "").trim();
    const apiKey = String(map.get("apiKey") || "").trim();
    const apiSecretRaw = map.get("apiSecret") || "";
    const apiSecret = String(decryptSecret(apiSecretRaw) || "").trim();
    const voiceTwimlAppSid = String(map.get("voiceTwimlAppSid") || "").trim();
    const voiceIdentity = String(map.get("voiceIdentity") || "").trim();
    const inboundForwardTo = String(map.get("inboundForwardTo") || "").trim();
    const envSid = String(process.env.TWILIO_ACCOUNT_SID || "").trim();
    const resolvedSid = isLikelyTwilioAccountSid(sid)
      ? sid
      : isLikelyTwilioAccountSid(envSid)
        ? envSid
        : "";
    if (!sid && resolvedSid) {
      try {
        await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, [
          "accountSid",
          resolvedSid
        ]);
      } catch {
        /* ignore */
      }
    }
    let crmPublicUrl = normalizeCrmPublicUrl(map.get("crmPublicUrl") || "");
    if (crmPublicUrlHasPathSuffix(crmPublicUrl)) {
      crmPublicUrl = getWebhookPublicOrigin(crmPublicUrl);
    }
    if (trialWorkspace && (!crmPublicUrl || isLegacyOwnerPublicUrl(crmPublicUrl))) {
      crmPublicUrl = getTrialWelcomeLoginBase();
    }
    const loginEmail = String(map.get("loginEmail") || "").trim().toLowerCase();
    const loginPasswordHash = String(map.get("loginPasswordHash") || "").trim();
    const socialExtraPlatforms = String(map.get("socialExtraPlatforms") || "").trim();
    const safeSid = resolvedSid && isLikelyTwilioAccountSid(resolvedSid) ? resolvedSid : "";
    const safeToken = token && isLikelyTwilioAuthToken(token) ? token : "";
    if (safeSid) process.env.TWILIO_ACCOUNT_SID = safeSid;
    if (safeToken) {
      process.env.TWILIO_AUTH_TOKEN = safeToken;
    } else if (!trialWorkspace && isLikelyTwilioAuthToken(envFallbackToken)) {
      process.env.TWILIO_AUTH_TOKEN = envFallbackToken;
      const storedToken = String(tokenRaw || "");
      const storedUnreadable = !storedToken.trim() || storedToken.startsWith("enc:v1:");
      if (storedUnreadable) {
        try {
          await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, [
            "authToken",
            encryptSecret(envFallbackToken)
          ]);
          console.warn("[twilio] Stored Auth Token could not be read. Restored it from .env.");
        } catch (err) {
          console.warn("[twilio] Using Auth Token from .env. Could not write it back:", err && err.message);
        }
      } else {
        console.warn("[twilio] Stored Auth Token was not usable. Using TWILIO_AUTH_TOKEN from .env.");
      }
    } else if (String(tokenRaw || "").startsWith("enc:v1:")) {
      console.error(
        "[twilio] Stored Auth Token could not be read, and .env has no TWILIO_AUTH_TOKEN. Start Call stays off until the token is saved in Settings → Your phone number."
      );
    }
    if (apiKey) process.env.TWILIO_API_KEY = apiKey;
    else if (!trialWorkspace && envFallbackApiKey) process.env.TWILIO_API_KEY = envFallbackApiKey;
    if (apiSecret) {
      process.env.TWILIO_API_SECRET = apiSecret;
    } else if (!trialWorkspace && envFallbackApiSecret && (!apiKey || apiKey === envFallbackApiKey)) {
      process.env.TWILIO_API_SECRET = envFallbackApiSecret;
    }
    if (voiceTwimlAppSid) process.env.TWILIO_VOICE_TWIML_APP_SID = voiceTwimlAppSid;
    if (voiceIdentity) process.env.TWILIO_VOICE_IDENTITY = voiceIdentity;
    if (inboundForwardTo) process.env.TWILIO_INBOUND_FORWARD_TO = inboundForwardTo;
    // Load auto-provisioned phone number from DB (set during tenant creation)
    const provisionedPhone = String(map.get("phoneNumber") || "").trim();
    if (provisionedPhone) process.env.TWILIO_PHONE_NUMBER = provisionedPhone;
    if (crmPublicUrl) process.env.CRM_PUBLIC_URL = crmPublicUrl;
    /* Trial requests share this process. Never swap the operator sign-in, or the main account is signed out. */
    if (!trialWorkspace) {
      if (loginEmail) process.env.CRM_LOGIN_EMAIL = loginEmail;
      if (loginPasswordHash) process.env.CRM_LOGIN_PASSWORD_HASH = loginPasswordHash;
    }
    const agentName = String(map.get("agentName") || "").trim();
    const agentPhone = String(map.get("agentPhone") || "").trim();
    if (agentName) process.env.CRM_AGENT_NAME = agentName;
    if (agentPhone) process.env.CRM_AGENT_PHONE = agentPhone;
    if (map.has("smsEnding")) process.env.CRM_SMS_ENDING = String(map.get("smsEnding") || "");
    else delete process.env.CRM_SMS_ENDING;
    const thanksIoApiKey = String(decryptSecret(map.get("thanksIoApiKey") || "") || "").trim();
    if (thanksIoApiKey) process.env.THANKS_IO_API_KEY = thanksIoApiKey;
    const anthropicApiKey = sanitizeAnthropicApiKey(decryptSecret(map.get("anthropicApiKey") || "") || "");
    if (trialWorkspace) {
      /* Customers never add a Claude key. A trial request uses the key saved on this site. */
      releaseRuntimeEnvKey("ANTHROPIC_API_KEY");
    } else if (anthropicApiKey) {
      process.env.ANTHROPIC_API_KEY = anthropicApiKey;
    }
    // If DB has no stored hash, preserve whatever .env set — don't delete it.
    // This lets CRM_LOGIN_PASSWORD_HASH in .env serve as a reliable fallback.
    if (socialExtraPlatforms) process.env.SOCIAL_EXTRA_PLATFORMS = socialExtraPlatforms;

    const login2faEnabled = String(map.get("login2faEnabled") || "").trim() === "1";
    process.env.CRM_LOGIN_2FA_ENABLED = login2faEnabled ? "1" : "";

    for (const [k, v] of map.entries()) {
      if (!String(k).startsWith("socialWebhook:")) continue;
      const target = normalizeSocialTarget(String(k).slice("socialWebhook:".length));
      if (!target) continue;
      const envKey = `SOCIAL_${target.toUpperCase().replace(/[^A-Z0-9]/g, "_")}_WEBHOOK_URL`;
      const url = String(v || "").trim();
      if (url) process.env[envKey] = url;
    }
    /* One-time migration: if authToken or apiSecret were stored in plaintext
       (legacy rows from before encryption was introduced) re-encrypt them in
       place so a stolen DB file no longer exposes the raw values. */
    const plainSecretKeys = [
      "authToken",
      "apiSecret",
      "metaWhatsappAccessToken",
      "metaWhatsappAppSecret",
      "thanksIoApiKey",
      "anthropicApiKey"
    ];
    for (const key of plainSecretKeys) {
      const stored = String(map.get(key) || "");
      if (!stored) continue;
      if (stored.startsWith("enc:v1:")) continue;
      try {
        const re = encryptSecret(stored);
        await run(`UPDATE twilio_runtime_config SET value = ? WHERE key = ?`, [re, key]);
        console.warn(`Re-encrypted plaintext '${key}' row in twilio_runtime_config.`);
      } catch (err) {
        console.warn(`Failed to re-encrypt '${key}':`, err && err.message);
      }
    }
  } catch (error) {
    console.error("Twilio runtime config load:", error.message || error);
  }
}

function getConfiguredLoginEmail() {
  return String(process.env.CRM_LOGIN_EMAIL || "")
    .trim()
    .toLowerCase();
}

function getConfiguredLoginPasswordHash() {
  return String(process.env.CRM_LOGIN_PASSWORD_HASH || "").trim();
}

function isEmailLike(value) {
  const s = String(value || "").trim();
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
}

function parseCookies(req) {
  const header = String(req.headers?.cookie || "");
  const out = {};
  for (const part of header.split(";")) {
    const idx = part.indexOf("=");
    if (idx <= 0) continue;
    const key = part.slice(0, idx).trim();
    const rawVal = part.slice(idx + 1).trim();
    if (!key) continue;
    try {
      out[key] = decodeURIComponent(rawVal);
    } catch {
      out[key] = rawVal;
    }
  }
  return out;
}

/** Stable across requests — must not use CRM_LOGIN_PASSWORD_HASH (cleared for trial workspaces). */
let authSigningSecretCache = null;

function getAuthSigningSecret() {
  if (authSigningSecretCache) return authSigningSecretCache;
  const env = String(process.env.CRM_AUTH_SECRET || "").trim();
  if (env) {
    authSigningSecretCache = crypto.createHash("sha256").update(`crm-auth-v1:${env}`).digest();
    return authSigningSecretCache;
  }
  try {
    if (fs.existsSync(masterKeyPath)) {
      const mk = fs.readFileSync(masterKeyPath, "utf8").trim();
      if (mk) {
        authSigningSecretCache = crypto.createHash("sha256").update(`crm-auth-v1:mk:${mk}`).digest();
        return authSigningSecretCache;
      }
    }
  } catch {
    // ignore
  }
  console.warn(
    "[auth] CRM_AUTH_SECRET not set — using dev fallback. Trial sessions may break on multi-worker hosts; set CRM_AUTH_SECRET in .env."
  );
  authSigningSecretCache = crypto.createHash("sha256").update("crm-local-dev-insecure").digest();
  return authSigningSecretCache;
}

function issueSignedAuthToken(email, tenantId = LEGACY_TENANT_ID, sessionOpts = null) {
  const now = Date.now();
  const lastActivity =
    sessionOpts && typeof sessionOpts.lastActivity === "number" ? sessionOpts.lastActivity : now;
  const exp = sessionOpts && typeof sessionOpts.exp === "number" ? sessionOpts.exp : now + AUTH_SESSION_MAX_AGE_MS;
  const tid = Number(tenantId);
  const resolvedTenantId = Number.isInteger(tid) && tid >= 1 ? tid : LEGACY_TENANT_ID;
  const payload = Buffer.from(
    JSON.stringify({
      email: String(email).toLowerCase(),
      exp,
      tenantId: resolvedTenantId,
      lastActivity
    }),
    "utf8"
  ).toString("base64url");
  const sig = crypto.createHmac("sha256", getAuthSigningSecret()).update(payload).digest("base64url");
  return `${payload}.${sig}`;
}

function isSessionIdleExpired(session) {
  if (!session) return true;
  const last = Number(session.lastActivity);
  const anchor = Number.isFinite(last) && last > 0 ? last : Number(session.createdAt) || 0;
  if (!anchor) return false;
  return Date.now() - anchor > AUTH_IDLE_TIMEOUT_MS;
}

function touchAuthSession(req, res) {
  const cookies = parseCookies(req);
  const token = String(cookies[AUTH_COOKIE_NAME] || "").trim();
  if (!token) return null;

  let session = authSessions.get(token);
  if (!session) session = verifySignedAuthToken(token);
  if (!session) return null;

  const exp = Number(session.exp) || 0;
  if (exp > 0 && exp < Date.now()) {
    authSessions.delete(token);
    return { expired: true, reason: "absolute" };
  }
  if (isSessionIdleExpired(session)) {
    authSessions.delete(token);
    return { expired: true, reason: "idle" };
  }

  const now = Date.now();
  if (now - Number(session.lastActivity || 0) < AUTH_ACTIVITY_TOUCH_MS) {
    return session;
  }

  const nextExp = exp > now ? exp : now + AUTH_SESSION_MAX_AGE_MS;
  const newToken = issueSignedAuthToken(session.email, session.tenantId, {
    lastActivity: now,
    exp: nextExp
  });
  setAuthCookie(res, newToken, req);
  const refreshed = {
    email: session.email,
    tenantId: session.tenantId,
    lastActivity: now,
    exp: nextExp,
    createdAt: session.createdAt
  };
  if (authSessions.has(token)) {
    authSessions.delete(token);
    authSessions.set(newToken, refreshed);
  }
  return refreshed;
}

function verifySignedAuthToken(token) {
  const raw = String(token || "").trim();
  const dot = raw.lastIndexOf(".");
  if (dot <= 0) return null;
  const payload = raw.slice(0, dot);
  const sig = raw.slice(dot + 1);
  if (!payload || !sig) return null;
  const expected = crypto.createHmac("sha256", getAuthSigningSecret()).update(payload).digest("base64url");
  try {
    const a = Buffer.from(sig);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  } catch {
    return null;
  }
  try {
    const data = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    if (!data || typeof data.email !== "string" || typeof data.exp !== "number") return null;
    if (data.exp < Date.now()) return null;

    const lastActivity =
      typeof data.lastActivity === "number" ? data.lastActivity : data.exp - AUTH_SESSION_MAX_AGE_MS;
    const sessionBase = { exp: data.exp, lastActivity, createdAt: data.exp - AUTH_SESSION_MAX_AGE_MS };
    if (Date.now() - lastActivity > AUTH_IDLE_TIMEOUT_MS) return null;

    const rawTenantId = data.tenantId;
    let tenantId;
    if (rawTenantId === undefined || rawTenantId === null) {
      const configured = getConfiguredLoginEmail();
      if (!configured || data.email !== configured) return null;
      tenantId = LEGACY_TENANT_ID;
    } else {
      tenantId = Number(rawTenantId);
      if (!Number.isInteger(tenantId) || tenantId < 1) return null;
    }

    if (tenantId !== LEGACY_TENANT_ID) {
      return { email: data.email, tenantId, ...sessionBase };
    }
    const configured = getConfiguredLoginEmail();
    if (configured && data.email !== configured) return null;
    return { email: data.email, tenantId: LEGACY_TENANT_ID, ...sessionBase };
  } catch {
    return null;
  }
}

function getAuthSession(req) {
  const cookies = parseCookies(req);
  const token = String(cookies[AUTH_COOKIE_NAME] || "").trim();
  if (!token) return null;
  const session = authSessions.get(token) || verifySignedAuthToken(token);
  if (!session) return null;
  if (Number(session.exp) > 0 && Number(session.exp) < Date.now()) return null;
  if (isSessionIdleExpired(session)) return null;
  return session;
}

function isTrialWorkspaceSession(req) {
  const session = getAuthSession(req);
  return Boolean(session?.tenantId && session.tenantId !== LEGACY_TENANT_ID);
}

/** Main Cadence operator workspace (legacy tenant) — not 14-day trial customers. */
function isOwnerWorkspaceSession(req) {
  return isRequestAuthenticated(req) && !isTrialWorkspaceSession(req);
}

function rejectUnlessOwnerWorkspace(req, res) {
  if (isOwnerWorkspaceSession(req)) return false;
  res.status(403).json({ error: "This tool is only available on the main operator workspace." });
  return true;
}

function isRequestAuthenticated(req) {
  if (isMarketingScreenshotRequest(req)) return true;
  const session = getAuthSession(req);
  /* 14-day trial workspaces use tenant_users (signup email + password), not Settings → Sign-in. */
  if (session?.tenantId && session.tenantId !== LEGACY_TENANT_ID) {
    return true;
  }
  const email = getConfiguredLoginEmail();
  const hash = getConfiguredLoginPasswordHash();
  if (!email || !hash) {
    /* Fail closed when login isn't fully configured. Allow ONLY requests from
       the host machine itself so the admin can complete initial setup from a
       local browser without exposing the CRM (and the Twilio credentials it
       brokers) to the public internet. */
    return isLocalRequest(req);
  }
  return !!session;
}

function loginIsFullyConfigured() {
  return Boolean(getConfiguredLoginEmail()) && Boolean(getConfiguredLoginPasswordHash());
}

function hadStaleAuthCookie(req) {
  return Boolean(String(parseCookies(req)[AUTH_COOKIE_NAME] || "").trim());
}

function buildLoginRedirectUrl(req, { sessionTimedOut = false } = {}) {
  const next = encodeURIComponent(req.originalUrl || req.path || "/");
  if (sessionTimedOut) {
    const idleMin = Math.round(AUTH_IDLE_TIMEOUT_MS / 60_000);
    return `/login.html?timeout=1&idle=${idleMin}&next=${next}`;
  }
  return `/login.html?next=${next}`;
}

function redirectToLogin(req, res, { sessionTimedOut } = {}) {
  const timedOut =
    sessionTimedOut === true || (sessionTimedOut !== false && hadStaleAuthCookie(req));
  return res.redirect(buildLoginRedirectUrl(req, { sessionTimedOut: timedOut }));
}

function isHttpsRequest(req) {
  if (!req) return false;
  if (req.secure) return true;
  const proto = String((req.get && req.get("x-forwarded-proto")) || "").toLowerCase();
  return proto.split(",")[0].trim() === "https";
}

function buildAuthCookie(value, req, { maxAgeSeconds }) {
  const parts = [`${AUTH_COOKIE_NAME}=${value}`, "Path=/", "HttpOnly", "SameSite=Strict", `Max-Age=${maxAgeSeconds}`];
  if (isHttpsRequest(req)) parts.push("Secure");
  return parts.join("; ");
}

function clearAuthCookie(res, req) {
  res.setHeader("Set-Cookie", buildAuthCookie("", req, { maxAgeSeconds: 0 }));
}

function setAuthCookie(res, token, req) {
  /* Shortened from 30 days to 8 hours — Twilio credentials are accessible to
     any active session, so we don't keep sessions warm for weeks. */
  const maxAgeSeconds = 60 * 60 * 8;
  res.setHeader("Set-Cookie", buildAuthCookie(encodeURIComponent(token), req, { maxAgeSeconds }));
}

function isBillingExemptApiPath(pathname) {
  const p = String(pathname || "");
  return (
    p === "/api/billing/status" ||
    p === "/api/billing/create-checkout-session" ||
    p === "/api/billing/portal"
  );
}

function isAuthExemptApiPath(pathname) {
  const p = String(pathname || "");
  if (p.startsWith("/webhooks/stripe")) return true;
  if (
    p === "/api/health" ||
    p === "/api/cron/email-queue" ||
    p === "/api/auth/login" ||
    p === "/api/auth/verify-2fa" ||
    p === "/api/auth/status" ||
    p === "/api/auth/logout" ||
    p === "/api/auth/forgot-password" ||
    p === "/api/subscription/signup" ||
    p === "/api/sales/contact" ||
    p === "/api/webinars/public" ||
    p === "/api/webinars/register"
  )
    return true;
  if (p.startsWith("/api/email/open/")) return true;
  if (p.startsWith("/api/email/click/")) return true;
  if (p === "/api/email/unsubscribe") return true;
  if (p === "/api/google/calendar/callback") return true;
  if (p.startsWith("/api/capture/")) return true;
  if (p.startsWith("/api/apply/")) return true;
  if (p.startsWith("/api/intake/")) return true;
  if (p === "/api/intake-form") return true;
  // Social media image download — the handler enforces a signed token for
  // unauthenticated callers (Make.com / Facebook fetching the image to post).
  if (/^\/api\/social\/media\/\d+\/download$/.test(p)) return true;
  // Twilio fetches the picture with no CRM login. The handler checks a signed token.
  if (/^\/api\/sms\/media\/[a-f0-9]{32}$/.test(p)) return true;
  return false;
}

function shouldProtectPageRoute(pathname) {
  const p = String(pathname || "");
  if (
    p === "/login.html" ||
    p === "/welcome.html" ||
    p === "/welcome" ||
    p === "/signup.html" ||
    p === "/signup" ||
    p === "/terms.html" ||
    p === "/terms" ||
    p === "/privacy.html" ||
    p === "/privacy" ||
    p === "/billing.html" ||
    p === "/billing" ||
    p === "/agent-demo.html" ||
    p === "/agent-demo" ||
    p === "/contact-sales.html" ||
    p === "/contact-sales" ||
    p === "/webinars.html" ||
    p === "/webinars" ||
    p === "/email-unsubscribe.html" ||
    p.startsWith("/marketing-previews/") ||
    p === "/api/auth/login" ||
    p === "/api/auth/verify-2fa" ||
    p === "/api/auth/status" ||
    p === "/api/auth/logout"
  )
    return false;
  /* Always protect HTML pages when login isn't fully configured — without an
     email AND password hash on file we don't trust anything but localhost. */
  if (!loginIsFullyConfigured()) return true;
  return p === "/" || p.endsWith(".html") || p === "/contact-details" || p === "/role-play" || p === "/tasks";
}

function twilioXmlEscape(s) {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function isVoiceBrowserConfigured() {
  return !!(
    process.env.TWILIO_ACCOUNT_SID &&
    process.env.TWILIO_API_KEY &&
    process.env.TWILIO_API_SECRET &&
    process.env.TWILIO_VOICE_TWIML_APP_SID
  );
}

function listVoiceBrowserConfigGaps() {
  const missing = [];
  if (!String(process.env.TWILIO_ACCOUNT_SID || "").trim()) missing.push("TWILIO_ACCOUNT_SID");
  if (!String(process.env.TWILIO_API_KEY || "").trim()) missing.push("TWILIO_API_KEY");
  if (!String(process.env.TWILIO_API_SECRET || "").trim()) missing.push("TWILIO_API_SECRET");
  if (!String(process.env.TWILIO_VOICE_TWIML_APP_SID || "").trim()) missing.push("TWILIO_VOICE_TWIML_APP_SID");
  return missing;
}

/** Shown in /api/twilio/voice-config and in 503 for /api/twilio/voice-token. */
function getVoiceBrowserSetupHint() {
  return (
    "In Twilio Console: (1) Account → API keys & tokens → create an API key — use its SID as TWILIO_API_KEY and secret as TWILIO_API_SECRET. " +
    "(2) Develop → TwiML → TwiML apps → create an app; set Voice configuration → Request URL to https://YOUR-PUBLIC-HOST/webhooks/twilio/voice (use ngrok in dev) — use the app’s SID as TWILIO_VOICE_TWIML_APP_SID. " +
    "Ensure TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN are set (same as SMS). Restart the server after changing .env."
  );
}

const createGetSetupStatus = require("./setupStatus");
const getSetupStatus = createGetSetupStatus({
  getConfiguredLoginEmail,
  getConfiguredLoginPasswordHash,
  isVoiceBrowserConfigured,
  listVoiceBrowserConfigGaps
});

function createVoiceAccessToken() {
  const accountSid = process.env.TWILIO_ACCOUNT_SID;
  const apiKey = process.env.TWILIO_API_KEY;
  const apiSecret = process.env.TWILIO_API_SECRET;
  const appSid = process.env.TWILIO_VOICE_TWIML_APP_SID;
  if (!accountSid || !apiKey || !apiSecret || !appSid) return null;
  const baseIdentity = String(process.env.TWILIO_VOICE_IDENTITY || "crm-agent").trim() || "crm-agent";
  const identity = `${baseIdentity}-${Date.now().toString(36)}-${crypto.randomBytes(3).toString("hex")}`;
  const token = new AccessToken(accountSid, apiKey, apiSecret, { identity, ttl: 3600 });
  const grant = new VoiceGrant({
    outgoingApplicationSid: appSid,
    incomingAllow: false
  });
  token.addGrant(grant);
  return token.toJwt();
}

function sendDashboardHtml(req, res) {
  try {
    let html = fs.readFileSync(indexHtmlPath, "utf8");
    html = html.replace(
      /name="crm-served-by-api"\s+content="0"/,
      'name="crm-served-by-api" content="1"'
    );
    const publicOrigin = `${req.protocol}://${req.get("host")}`;
    html = html.replace(
      /<script id="crm-api-origin">window\.__CRM_API_ORIGIN__=""<\/script>/,
      `<script id="crm-api-origin">window.__CRM_API_ORIGIN__=${JSON.stringify(publicOrigin)}</script>`
    );
    html = html.replace(
      /<meta\s+name="crm-api-base"\s+content="[^"]*"\s*\/?>/i,
      `<meta name="crm-api-base" content="${publicOrigin}" />`
    );
    html = injectJourneyNavLink(html);
    html = injectWebinarNavLink(html);
    html = injectRolePlayNavLink(html);
    html = injectAppNoIndex(html);
    html = injectBuildStamp(html);
    html = html.replace(/\/crmApi\.js\?v=\d+/g, "/crmApi.js?v=20260772");
    html = html.replace(/\/app\.js\?v=[^"'&\s]+/g, "/app.js?v=20260923speaker");
    if (!html.includes("sold-date-filter.js")) {
      html = html.replace(
        /(<script src="\/app\.js\?v=[^"]*"><\/script>)/,
        `<script src="/sold-date-filter.js?v=20260828sold7"></script>\n    $1`
      );
    }
    html = html.replace(/\/contactWorkspaceOptions\.js\?v=[^"'&\s]+/g, "/contactWorkspaceOptions.js?v=20260901insuranceqf2");
    html = injectTrialBillingGate(html);
    html = injectWorkspaceBanner(html);
    html = injectIndianFieldLabel(html, req, "index.html");
    html = injectCrmAuthRedirect(html, "index.html");
    html = injectSessionIdle(html, "index.html");
    html = injectNavAgentProfileScript(html, "index.html");
    html = normalizeContactsRootLinks(html);
    if (!html.includes("twilio-from-config")) {
      html = html.replace("</head>", `${buildTwilioFromNumbersScript(req)}\n</head>`);
    }
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
    res.type("html").send(html);
  } catch (err) {
    console.error("Dashboard render failed:", err);
    res.status(500).send("Dashboard unavailable");
  }
}

function requestHostname(req) {
  return String(req.headers["x-forwarded-host"] || req.headers.host || "")
    .split(",")[0]
    .trim()
    .toLowerCase()
    .replace(/:\d+$/, "");
}

function isCrmMarketingHost(req) {
  const host = requestHostname(req);
  return host === "crmcadence.com" || host === "www.crmcadence.com";
}

function isInsuranceMarketingHost(req) {
  const host = requestHostname(req);
  return host === "cadencecrm.pro" || host === "www.cadencecrm.pro";
}

/** Public origin for canonical tags. Unknown hosts follow the insurance site. */
function marketingOriginForRequest(req) {
  if (isCrmMarketingHost(req)) return "https://crmcadence.com";
  if (isInsuranceMarketingHost(req)) return "https://cadencecrm.pro";
  return "https://cadencecrm.pro";
}

const INSURANCE_ONLY_PAGES = new Set([
  "welcome.html",
  "blog.html",
  "best-crm-for-health-insurance-agents.html",
  "aca-open-enrollment-crm.html",
  "medicare-advantage-agent-crm.html",
  "insurance-lead-follow-up-system.html",
  "private-health-insurance-plans-agent-guide.html",
  "why-ai-matters-for-insurance-crm.html",
  "getting-your-crm-ready-for-aca-open-enrollment.html"
]);

const INSURANCE_SITEMAP_PATHS = [
  "/",
  "/welcome.html",
  "/signup.html",
  "/contact-sales.html",
  "/webinars.html",
  "/blog.html",
  "/best-crm-for-health-insurance-agents.html",
  "/aca-open-enrollment-crm.html",
  "/medicare-advantage-agent-crm.html",
  "/insurance-lead-follow-up-system.html",
  "/private-health-insurance-plans-agent-guide.html",
  "/why-ai-matters-for-insurance-crm.html",
  "/getting-your-crm-ready-for-aca-open-enrollment.html"
];

const CRM_SITEMAP_PATHS = ["/", "/signup.html", "/contact-sales.html"];

const ROBOTS_DISALLOW = [
  "/api/",
  "/webhooks/",
  "/index.html",
  "/home.html",
  "/login.html",
  "/campaigns.html",
  "/pipeline.html",
  "/contact.html",
  "/contact-import.html",
  "/activities.html",
  "/calendar.html",
  "/settings.html",
  "/email.html",
  "/email-templates.html",
  "/landing-pages.html",
  "/webinar-admin.html",
  "/social.html",
  "/documents.html",
  "/reports.html",
  "/automations.html",
  "/assistant.html",
  "/billing.html",
  "/agent-demo.html",
  "/marketing-previews/"
];

function buildRobotsTxt(origin) {
  const lines = [
    "# Marketing pages are indexable. CRM app screens stay out of search.",
    "User-agent: *",
    "Allow: /"
  ];
  if (origin === "https://crmcadence.com") {
    lines.push("Allow: /signup.html", "Allow: /contact-sales.html");
  } else {
    lines.push(
      "Allow: /welcome.html",
      "Allow: /signup.html",
      "Allow: /contact-sales.html",
      "Allow: /webinars.html",
      "Allow: /blog.html",
      "Allow: /best-crm-for-health-insurance-agents.html",
      "Allow: /aca-open-enrollment-crm.html",
      "Allow: /medicare-advantage-agent-crm.html",
      "Allow: /insurance-lead-follow-up-system.html",
      "Allow: /private-health-insurance-plans-agent-guide.html",
      "Allow: /why-ai-matters-for-insurance-crm.html",
      "Allow: /getting-your-crm-ready-for-aca-open-enrollment.html"
    );
  }
  for (const blocked of ROBOTS_DISALLOW) lines.push(`Disallow: ${blocked}`);
  lines.push("", `Sitemap: ${origin}/sitemap.xml`, "");
  return lines.join("\n");
}

function buildSitemapXml(origin, paths) {
  const today = new Date().toISOString().slice(0, 10);
  const urls = paths
    .map((pagePath) => {
      const loc = pagePath === "/" ? `${origin}/` : `${origin}${pagePath}`;
      return `  <url>\n    <loc>${loc}</loc>\n    <lastmod>${today}</lastmod>\n  </url>`;
    })
    .join("\n");
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`;
}

/** Rewrite only the document head so a shared signup page can be canonical on either host. */
function rewriteHeadOrigin(html, origin) {
  if (!html || !origin) return html;
  return html.replace(/<head>([\s\S]*?)<\/head>/i, (_full, inner) => {
    const next = String(inner)
      .split("https://crmcadence.com")
      .join(origin)
      .split("https://cadencecrm.pro")
      .join(origin);
    return `<head>${next}</head>`;
  });
}

function sendNotFoundPage(res) {
  const home = "/";
  const html = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="robots" content="noindex" />
  <title>Page not found · Cadence CRM</title>
  <link rel="stylesheet" href="/welcome.css?v=20261021crm" />
  <link rel="icon" type="image/svg+xml" href="/favicon.svg" />
</head>
<body class="welcome-page" data-hide-build-stamp="1">
  <main class="welcome-article">
    <article class="welcome-article-card">
      <p class="welcome-section-eyebrow">404</p>
      <h1>That page is not on this site.</h1>
      <p>The address may be mistyped, or the page has been removed.</p>
      <p><a href="${home}" class="welcome-btn welcome-btn--primary">Back to the homepage</a></p>
      <p><a href="/signup.html">Start a 14-day trial</a> · <a href="/login.html">Log in</a></p>
    </article>
  </main>
</body>
</html>`;
  res.status(404);
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  res.type("html").send(html);
}

function sendMarketingPage(req, res, fileName) {
  const baseName = String(fileName || "").trim().toLowerCase();
  if (isCrmMarketingHost(req) && INSURANCE_ONLY_PAGES.has(baseName)) {
    const target = baseName === "welcome.html" ? "https://cadencecrm.pro/" : `https://cadencecrm.pro/${baseName}`;
    return res.redirect(301, target);
  }
  const filePath = path.join(publicDir, fileName);
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  try {
    let html = fs.readFileSync(filePath, "utf8");
    html = rewriteHeadOrigin(html, marketingOriginForRequest(req));
    res.type("html").send(html);
  } catch (err) {
    console.error(`Marketing page missing or unreadable: ${fileName}`, err);
    if (!res.headersSent) sendNotFoundPage(res);
  }
}

function sendHtmlPageWithTwilio(req, res, fileName) {
  try {
    const filePath = path.join(publicDir, fileName);
    let html = fs.readFileSync(filePath, "utf8");
    html = html.replace(
      /name="crm-served-by-api"\s+content="0"/,
      'name="crm-served-by-api" content="1"'
    );
    const publicOrigin = `${req.protocol}://${req.get("host")}`;
    html = html.replace(
      /<meta\s+name="crm-api-base"\s+content="[^"]*"\s*\/?>/i,
      `<meta name="crm-api-base" content="${publicOrigin}" />`
    );
    html = injectJourneyNavLink(html);
    html = injectWebinarNavLink(html);
    html = injectRolePlayNavLink(html);
    html = injectAppNoIndex(html);
    html = injectBuildStamp(html);
    html = injectTrialBillingGate(html);
    html = injectWorkspaceBanner(html);
    html = injectIndianFieldLabel(html, req, fileName);
    html = injectCrmAuthRedirect(html, fileName);
    html = injectSessionIdle(html, fileName);
    html = injectNavAgentProfileScript(html, fileName);
    html = normalizeContactsRootLinks(html);
    if (String(fileName || "").toLowerCase() === "login.html") {
      html = injectLoginTimeoutNotice(html, req);
    }
    if (html.includes('id="crm-api-origin"')) {
      html = html.replace(
        /<script id="crm-api-origin">window\.__CRM_API_ORIGIN__=""<\/script>/,
        `<script id="crm-api-origin">window.__CRM_API_ORIGIN__=${JSON.stringify(publicOrigin)}</script>`
      );
    } else {
      html = html.replace(
        "</head>",
        `<script id="crm-api-origin">window.__CRM_API_ORIGIN__=${JSON.stringify(publicOrigin)}</script>\n</head>`
      );
    }
    if (!html.includes("twilio-from-config")) {
      html = html.replace("</head>", `${buildTwilioFromNumbersScript(req)}\n</head>`);
    }
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
    res.type("html").send(html);
  } catch (err) {
    console.error(`Page render failed (${fileName}):`, err);
    res.status(500).send("Page unavailable");
  }
}

function injectJourneyNavLink(html) {
  const source = String(html || "");
  if (!source) return source;
  if (
    source.includes('href="/automations.html">Automations</a>') ||
    source.includes('href="/automations.html"') ||
    source.includes('<span class="active">Automations</span>')
  ) {
    return source;
  }
  const journeyLink = '<a href="/automations.html">Automations</a>';
  const withDripAnchor = source.replace('<a href="/drip.html">Drip</a>', `<a href="/drip.html">Drip</a>\n        ${journeyLink}`);
  if (withDripAnchor !== source) return withDripAnchor;
  return source.replace('<span class="active">Drip</span>', `<span class="active">Drip</span>\n        ${journeyLink}`);
}

// Safety net: ensure the Webinars link is present in the sidebar. No-op when the
// page already lists it (every app page now hard-codes it). Anchors before the
// Social Marketing link since the former anchor (Landing Pages) was removed.
function injectWebinarNavLink(html) {
  const source = String(html || "");
  if (
    !source ||
    source.includes('href="/webinar-admin.html"') ||
    source.includes(">Webinars</span>")
  ) {
    return source;
  }
  const link =
    '        <a href="/webinar-admin.html"><svg class="agile-nav-icon" aria-hidden="true" width="20" height="20"><use href="/nav-icons.svg?v=20260610#nav-webinar"/></svg>Webinars</a>';
  const re = /(\s*)(<a href="\/social\.html">)/;
  if (!re.test(source)) return source;
  return source.replace(re, `$1${link}$1$2`);
}

function injectRolePlayNavLink(html) {
  const source = String(html || "");
  if (!source) return source;
  if (source.includes('href="/role-play.html"') || source.includes(">AI Role Play</span>")) {
    return source;
  }
  const link =
    '        <a href="/role-play.html"><svg class="agile-nav-icon" aria-hidden="true" width="20" height="20"><use href="/nav-icons.svg?v=20260903roleplay#nav-role-play"/></svg>AI Role Play</a>';
  const afterAssistantLink = source.replace(
    /(<a href="\/assistant(?:\.html)?"[^>]*>[\s\S]*?AI Assistant<\/a>)/,
    `$1\n${link}`
  );
  if (afterAssistantLink !== source) return afterAssistantLink;
  const afterAssistantActive = source.replace(
    /(<span[^>]*class="[^"]*\bactive\b[^"]*"[^>]*>[\s\S]*?AI Assistant<\/span>)/,
    `$1\n${link}`
  );
  if (afterAssistantActive !== source) return afterAssistantActive;
  const beforeAiContent = source.replace(/(<a href="\/ai-content\.html">)/, `${link}\n        $1`);
  if (beforeAiContent !== source) return beforeAiContent;
  return source.replace(/(<a href="\/email\.html">)/, `${link}\n        $1`);
}

function isPrivateOrLocalHostname(host) {
  const h = String(host || "")
    .trim()
    .toLowerCase()
    .replace(/^\[|\]$/g, "");
  if (!h) return true;
  if (h === "localhost" || h === "127.0.0.1" || h === "::1" || h === "0.0.0.0") return true;
  if (h.endsWith(".local") || h.endsWith(".localhost")) return true;
  const ipv4 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(h);
  if (ipv4) {
    const a = Number(ipv4[1]);
    const b = Number(ipv4[2]);
    if (a === 10 || a === 127) return true;
    if (a === 192 && b === 168) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 169 && b === 254) return true;
  }
  return false;
}

function hostnameFromUrlOrHost(value) {
  const raw = String(value || "").trim();
  if (!raw) return "";
  try {
    const withProto = /^[a-z][a-z0-9+.-]*:\/\//i.test(raw) ? raw : `https://${raw}`;
    return new URL(withProto).hostname.toLowerCase();
  } catch {
    return raw.split("/")[0].split(":")[0].toLowerCase();
  }
}

// Shareable lead-capture / intake URLs must keep working when the admin's PC
// (or Cursor) is off. Use the request host on a public domain; if the admin is
// on localhost/LAN, prefer CRM_PUBLIC_URL or the live Cadence host instead.
function resolveLeadCaptureBase(req) {
  const proto = (req.headers["x-forwarded-proto"] || "https").split(",")[0].trim() || "https";
  const host = String(req.headers["x-forwarded-host"] || req.headers.host || "crmcadence.com")
    .split(",")[0]
    .trim();
  const requestBase = `${proto}://${host}`.replace(/\/$/, "");
  if (!isPrivateOrLocalHostname(hostnameFromUrlOrHost(host))) return requestBase;

  const configured = normalizeCrmPublicUrl(process.env.CRM_PUBLIC_URL || "");
  if (configured && !isPrivateOrLocalHostname(hostnameFromUrlOrHost(configured))) {
    return configured;
  }
  return "https://cadencecrm.pro";
}

/** Intake and application links always open this site, whichever CRM you copied them from. */
const CUSTOMER_FORM_ORIGIN = "https://cadencecrm.pro";

function customerFormUrl(suffix) {
  const path = String(suffix || "");
  return `${CUSTOMER_FORM_ORIGIN}${path.startsWith("/") ? path : `/${path}`}`;
}

async function getOrCreateLeadCaptureConfig(tenantId) {
  const id = Number(tenantId || LEGACY_TENANT_ID);
  let cfg = await platformGet(
    `SELECT id, tenant_id, form_key, notify_email FROM lead_capture_config WHERE tenant_id = ?`,
    [id]
  );
  if (!cfg) {
    const formKey = crypto.randomBytes(20).toString("hex");
    await platformRun(
      `INSERT OR IGNORE INTO lead_capture_config (tenant_id, form_key) VALUES (?, ?)`,
      [id, formKey]
    );
    cfg = await platformGet(
      `SELECT id, tenant_id, form_key, notify_email FROM lead_capture_config WHERE tenant_id = ?`,
      [id]
    );
  }
  return cfg;
}

function buildPublicCaptureFormHtml(formKey, agencyName) {
  const safeAgency = String(agencyName || "Your Agent")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const safeKey = String(formKey || "").replace(/[^a-f0-9]/g, "");
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Contact ${safeAgency}</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Segoe UI',system-ui,sans-serif;background:#f1f5f9;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:flex-start;padding:32px 16px}
  .card{background:#fff;border-radius:16px;box-shadow:0 8px 32px rgba(15,23,42,.10);width:100%;max-width:520px;overflow:hidden}
  .card-header{background:linear-gradient(135deg,#312e81 0%,#4f46e5 60%,#7c3aed 100%);padding:28px 32px 24px;text-align:center}
  .card-header h1{color:#fff;font-size:1.25rem;font-weight:800;letter-spacing:-.01em;margin-bottom:4px}
  .card-header p{color:rgba(255,255,255,.82);font-size:.88rem}
  .card-body{padding:28px 32px 32px}
  .field{margin-bottom:18px}
  label{display:block;font-size:.82rem;font-weight:600;color:#475569;margin-bottom:6px;text-transform:uppercase;letter-spacing:.05em}
  input,select,textarea{width:100%;border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 14px;font-size:.95rem;color:#0f172a;background:#fff;transition:border .15s}
  input:focus,select:focus,textarea:focus{outline:none;border-color:#4f46e5}
  textarea{resize:vertical;min-height:88px}
  .row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
  .btn{display:block;width:100%;padding:13px;background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;font-weight:700;font-size:1rem;border:none;border-radius:999px;cursor:pointer;margin-top:8px;transition:opacity .15s}
  .btn:hover{opacity:.9}
  .btn:disabled{opacity:.6;cursor:not-allowed}
  .success{display:none;text-align:center;padding:32px 0 16px}
  .success-icon{font-size:2.5rem;margin-bottom:12px}
  .success h2{color:#1e1b4b;font-size:1.15rem;margin-bottom:8px}
  .success p{color:#475569;font-size:.95rem}
  .err{color:#dc2626;font-size:.88rem;margin-top:10px;display:none}
  .footer{margin-top:20px;text-align:center;font-size:.78rem;color:#94a3b8}
  .footer a{color:#4f46e5;text-decoration:none}
  @media(max-width:480px){.row{grid-template-columns:1fr}.card-body{padding:20px}}
</style>
</head>
<body>
<div class="card">
  <div class="card-header">
    <h1>Request Affordable Quotes</h1>
    <p>Tell us a little about yourself and we'll be in touch.</p>
  </div>
  <div class="card-body">
    <form id="lc-form">
      <div class="row">
        <div class="field"><label for="lc-first">First Name *</label><input id="lc-first" name="first_name" type="text" required autocomplete="given-name" /></div>
        <div class="field"><label for="lc-last">Last Name</label><input id="lc-last" name="last_name" type="text" autocomplete="family-name" /></div>
      </div>
      <div class="field"><label for="lc-email">Email Address *</label><input id="lc-email" name="email" type="email" required autocomplete="email" /></div>
      <div class="field"><label for="lc-phone">Phone Number</label><input id="lc-phone" name="phone" type="tel" autocomplete="tel" /></div>
      <div class="field">
        <label for="lc-interest">I'm interested in…</label>
        <select id="lc-interest" name="interest">
          <option value="">Select one&hellip;</option>
          <option value="Private Health Insurance">Private Health Insurance</option>
          <option value="ACA / Marketplace">ACA / Marketplace</option>
          <option value="Medicare Advantage">Medicare Advantage</option>
          <option value="Medicare Supplement">Medicare Supplement</option>
          <option value="Short-Term Health">Short-Term Health</option>
          <option value="Life Insurance">Life Insurance</option>
          <option value="Other / Not Sure">Other / Not Sure</option>
        </select>
      </div>
      <div class="field"><label for="lc-msg">Message (optional)</label><textarea id="lc-msg" name="message" placeholder="Anything you'd like us to know…"></textarea></div>
      <p class="err" id="lc-err"></p>
      <button class="btn" type="submit" id="lc-submit">Send My Information</button>
    </form>
    <div class="success" id="lc-success">
      <div class="success-icon">✓</div>
      <h2>Got it — we'll be in touch soon!</h2>
      <p>Your information has been received. An agent will reach out to you shortly.</p>
    </div>
  </div>
</div>
<p class="footer">Powered by <a href="https://crmcadence.com" target="_blank" rel="noopener">Cadence CRM</a></p>
<script>
(function(){
  var form=document.getElementById('lc-form');
  var btn=document.getElementById('lc-submit');
  var err=document.getElementById('lc-err');
  var success=document.getElementById('lc-success');
  form.addEventListener('submit',function(e){
    e.preventDefault();
    err.style.display='none';
    btn.disabled=true;
    btn.textContent='Sending…';
    var data={
      first_name:form.lc_first?form['lc-first'].value:document.getElementById('lc-first').value,
      last_name:document.getElementById('lc-last').value,
      email:document.getElementById('lc-email').value,
      phone:document.getElementById('lc-phone').value,
      interest:document.getElementById('lc-interest').value,
      message:document.getElementById('lc-msg').value
    };
    fetch('/api/capture/${safeKey}',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify(data)
    }).then(function(r){return r.json();}).then(function(j){
      if(j.ok){
        form.style.display='none';
        success.style.display='block';
      } else {
        err.textContent=j.error||'Something went wrong. Please try again.';
        err.style.display='block';
        btn.disabled=false;
        btn.textContent='Send My Information';
      }
    }).catch(function(){
      err.textContent='Network error. Please try again.';
      err.style.display='block';
      btn.disabled=false;
      btn.textContent='Send My Information';
    });
  });
})();
</script>
</body>
</html>`;
}

function injectTrialBillingGate(html) {
  if (!html || html.includes("trialBillingGate.js")) return html;
  const tag = '<script src="/trialBillingGate.js?v=20260524"></script>';
  if (html.includes("</body>")) return html.replace("</body>", `${tag}\n</body>`);
  return html;
}

function injectWorkspaceBanner(html) {
  return html;
}

const SESSION_IDLE_SKIP_PAGES = new Set([
  "login.html",
  "welcome.html",
  "signup.html",
  "billing.html",
  "agent-demo.html",
  "contact-sales.html",
  "webinars.html"
]);

const INDIAN_FIELD_LABEL_OWNER = "Indian";

function stripIndianFieldFromHtml(html) {
  let source = String(html || "");
  source = source.replace(/\s*<option value="indian">Indian<\/option>\s*/gi, "\n");
  source = source.replace(/\s*<select id="indian" name="indian"[^>]*>[\s\S]*?<\/select>\s*/gi, "\n");
  source = source.replace(
    /\s*<div class="contact-field-box"[^>]*>[\s\S]*?for="indian"[\s\S]*?<\/select>\s*<\/div>\s*/gi,
    "\n"
  );
  return source;
}

/** Remove operator-only UI (Paradigmai import, etc.) from HTML served to trial workspaces. */
function stripOwnerOnlyFromHtml(html) {
  let source = String(html || "");
  const patterns = [
    /\s*<a\b[^>]*\bdata-owner-only\b[^>]*>[\s\S]*?<\/a>\s*/gi,
    /\s*<section\b[^>]*\bdata-owner-only\b[^>]*>[\s\S]*?<\/section>\s*/gi,
    /\s*<p\b[^>]*\bdata-owner-only\b[^>]*>[\s\S]*?<\/p>\s*/gi,
    /\s*<div\b[^>]*\bdata-owner-only\b[^>]*>[\s\S]*?<\/div>\s*/gi,
    /\s*<select\b[^>]*\bdata-owner-only\b[^>]*>[\s\S]*?<\/select>\s*/gi,
    /\s*<option\b[^>]*\bdata-owner-only\b[^>]*>[\s\S]*?<\/option>\s*/gi
  ];
  for (const pattern of patterns) {
    source = source.replace(pattern, "\n");
  }
  return source;
}

const INDEX_INDIAN_SELECT_HTML = `          <select id="indian" name="indian" data-owner-only aria-label="Indian">
            <option value="">&mdash;</option>
            <option value="Yes">Yes</option>
            <option value="No">No</option>
          </select>
`;

const CONTACT_INDIAN_FIELD_HTML = `              <div class="contact-field-box" data-owner-only><label class="contact-modal-field-label" for="indian">Indian</label><select id="indian" name="indian" aria-label="Indian">
                <option value=""></option>
                <option value="Yes">Yes</option>
                <option value="No">No</option>
              </select></div>
`;

function injectTrialWorkspaceUiScript(html) {
  let source = String(html || "");
  if (!source || source.includes("trialWorkspaceUi.js")) return source;
  const tag = '<script src="/trialWorkspaceUi.js?v=20260908indian"></script>';
  if (source.includes("</head>")) {
    return source.replace("</head>", `${tag}\n</head>`);
  }
  if (source.includes("</body>")) {
    return source.replace("</body>", `${tag}\n</body>`);
  }
  return source;
}

/** Owner workspace only: Indian field, filters, and help text. Trial/public HTML has no Indian UI. */
function injectIndianFieldLabel(html, req, fileName) {
  let source = String(html || "");
  if (!source) return source;
  source = injectTrialWorkspaceUiScript(source);
  const base = String(fileName || "").trim().toLowerCase();

  if (!isOwnerWorkspaceSession(req)) {
    const omitScript = `<script id="crm-omit-indian-workspace">window.__CRM_OMIT_INDIAN_WORKSPACE__=true</script>`;
    if (!source.includes('id="crm-omit-indian-workspace"')) {
      source = source.replace("</head>", `${omitScript}\n</head>`);
    }
    source = stripIndianFieldFromHtml(source);
    source = stripOwnerOnlyFromHtml(source);
    if (base === "settings.html") {
      source = source.replace(/, or "Indian" lead flag/g, "");
    }
    return source;
  }

  const scriptTag = `<script id="crm-indian-field-label">window.__CRM_INDIAN_FIELD_LABEL__=${JSON.stringify(INDIAN_FIELD_LABEL_OWNER)}</script>`;
  if (!source.includes('id="crm-indian-field-label"')) {
    source = source.replace("</head>", `${scriptTag}\n</head>`);
  }
  if (base === "index.html") {
    if (!source.includes('id="indian"')) {
      source = source.replace(/(\s*<select id="household_size")/i, `${INDEX_INDIAN_SELECT_HTML}$1`);
    }
    if (!/<option value="indian">Indian<\/option>/i.test(source)) {
      source = source.replace(
        /(\s*<option value="profession">Profession<\/option>)/i,
        `\n                <option value="indian">Indian</option>$1`
      );
    }
  } else if (base === "contact.html") {
    if (!source.includes('id="indian"')) {
      source = source.replace(
        /(\s*<div class="contact-field-box"><label class="contact-modal-field-label" for="household_size")/i,
        `${CONTACT_INDIAN_FIELD_HTML}$1`
      );
    }
  } else if (base === "settings.html") {
    if (!source.includes('"Indian" lead flag')) {
      source = source.replace(
        /filters by name, phone, email, lead source\./,
        'filters by name, phone, email, lead source, or "Indian" lead flag.'
      );
    }
  }
  return source;
}

function injectLoginTimeoutNotice(html, req) {
  const source = String(html || "");
  if (!source || String(req?.query?.timeout || "") !== "1") return source;
  const idleRaw = Number(req.query.idle);
  const idleMin =
    Number.isFinite(idleRaw) && idleRaw > 0 ? idleRaw : Math.round(AUTH_IDLE_TIMEOUT_MS / 60_000);
  const message = `You were signed out after ${idleMin} minutes of inactivity.`;
  const inline = `<script>(function(){function show(){try{var m=document.getElementById("loginMessage");if(!m)return;var mins=${idleMin};m.textContent="You were signed out after "+mins+" minutes of inactivity.";m.classList.add("signin-message--error");sessionStorage.removeItem("crm_login_timeout_msg");sessionStorage.removeItem("crm_login_timeout_at");localStorage.removeItem("crm_login_timeout_msg");localStorage.removeItem("crm_login_timeout_at");localStorage.removeItem("crm_had_authenticated_session");}catch(e){}}if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",show);else show();})();</script>`;
  if (source.includes("data-crm-login-timeout-inline")) return source;
  if (source.includes('id="loginMessage"')) {
    return source.replace(
      '<p id="loginMessage" class="signin-message"',
      `${inline}\n            <p id="loginMessage" class="signin-message" data-crm-login-timeout-inline="1" title="${twilioXmlEscape(
        message
      )}"`
    );
  }
  return source.replace("</body>", `${inline}\n</body>`);
}

function injectCrmAuthRedirect(html, fileName) {
  if (!html || html.includes("crm-auth-redirect.js")) return html;
  const base = String(fileName || "").trim().toLowerCase();
  if (SESSION_IDLE_SKIP_PAGES.has(base)) return html;
  const tag = '<script src="/crm-auth-redirect.js?v=20260812b"></script>';
  if (html.includes("</head>")) return html.replace("</head>", `  ${tag}\n</head>`);
  return html;
}

function injectSessionIdle(html, fileName) {
  if (!html || html.includes("session-idle.js")) return html;
  const base = String(fileName || "").trim().toLowerCase();
  if (SESSION_IDLE_SKIP_PAGES.has(base)) return html;
  const tag = '<script src="/session-idle.js?v=20260812b"></script>';
  if (html.includes("</body>")) return html.replace("</body>", `${tag}\n</body>`);
  return html;
}

function injectNavAgentProfileScript(html, fileName) {
  if (!html || html.includes("navAgentProfile.js")) return html;
  const base = String(fileName || "").trim().toLowerCase();
  if (SESSION_IDLE_SKIP_PAGES.has(base)) return html;
  const tag = '<script src="/navAgentProfile.js?v=20261022phone"></script>';
  if (html.includes("</body>")) return html.replace("</body>", `${tag}\n</body>`);
  return html;
}

/** Keep CRM app pages out of Google; marketing pages set their own robots meta. */
function injectAppNoIndex(html) {
  if (!html || /<meta\s+name=["']robots["']/i.test(html)) return html;
  return html.replace("</head>", '  <meta name="robots" content="noindex, nofollow" />\n</head>');
}

function injectBuildStamp(html) {
  const source = String(html || "");
  if (!source) return source;
  if (source.includes('data-hide-build-stamp="1"')) return source;
  if (source.includes('id="crmBuildStampFooter"')) {
    return source.replace(
      /(<div\b[^>]*\bid="crmBuildStampFooter"[^>]*>)[\s\S]*?(<\/div>)/i,
      `$1${twilioXmlEscape(buildStampText)}$2`
    );
  }
  const stamp = `<div id="crmBuildStampFooter" style="font: 500 10px/1.2 system-ui,Segoe UI,Arial,sans-serif;color:#6b7280;text-align:right;padding:6px 10px 10px;">${twilioXmlEscape(
    buildStampText
  )}</div>`;
  if (source.includes("</main>")) {
    return source.replace("</main>", `${stamp}\n    </main>`);
  }
  return source.replace("</body>", `${stamp}\n  </body>`);
}

function normalizeContactsRootLinks(html) {
  const source = String(html || "");
  if (!source) return source;
  return source
    .replace(/\bhref=(["'])\/\1/g, (_match, quote) => `href=${quote}/index.html${quote}`)
    .replace(/\bhref=(["'])\/\?/g, (_match, quote) => `href=${quote}/index.html?`)
    .replace(/window\.location\.href\s*=\s*(["'])\/\1/g, (_match, quote) => `window.location.href=${quote}/index.html${quote}`)
    .replace(/window\.location\.href\s*=\s*(["'])\/\?/g, (_match, quote) => `window.location.href=${quote}/index.html?`);
}

/* CORS: previously wide open (cors() with defaults). Now restricted to the
   CRM's own public origin. Same-origin requests carry no Origin header so
   they bypass the allow-list naturally. Set CRM_PUBLIC_URL in env/Settings
   if you embed the CRM in another origin. */
app.use(
  cors({
    credentials: true,
    origin: (origin, callback) => {
      if (!origin) return callback(null, true);
      const incoming = origin.replace(/\/$/, "");
      /* A form opened on either Cadence site posts the customer to cadencecrm.pro. */
      if (
        incoming === "https://cadencecrm.pro" ||
        incoming === "https://www.cadencecrm.pro" ||
        incoming === "https://crmcadence.com" ||
        incoming === "https://www.crmcadence.com"
      ) {
        return callback(null, true);
      }
      const allowedRaw = String(process.env.CRM_PUBLIC_URL || "").trim();
      if (!allowedRaw) return callback(null, false);
      const allowedList = allowedRaw
        .split(",")
        .map((v) => v.trim().replace(/\/$/, ""))
        .filter(Boolean);
      if (allowedList.includes(incoming)) return callback(null, true);
      return callback(null, false);
    }
  })
);

app.post("/webhooks/stripe", express.raw({ type: "application/json" }), async (req, res) => {
  try {
    const sig = req.headers["stripe-signature"];
    const result = await handleStripeWebhook(req.body, sig);
    if (!result.ok) return res.status(result.status || 400).send(result.error || "Webhook error");
    return res.json({ received: true });
  } catch (err) {
    console.error("Stripe webhook error:", err);
    return res.status(500).send("Webhook handler failed");
  }
});

app.use(express.json({ limit: "20mb" }));
app.use(express.urlencoded({ extended: true, limit: "20mb" }));

function shouldSkipTenantContext(req) {
  const p = String(req.path || "");
  return (
    p === "/api/auth/login" ||
    p === "/api/auth/verify-2fa" ||
    p === "/api/subscription/signup" ||
    p.startsWith("/api/public/agent-branding-photo/")
  );
}

app.use(async (req, res, next) => {
  if (shouldSkipTenantContext(req)) return next();
  const session = getAuthSession(req);
  if (!session?.tenantId) return next();
  try {
    await openTenantDatabase(session.tenantId);
    if (session.tenantId !== LEGACY_TENANT_ID) {
      return runWithIsolatedRuntimeEnv(() =>
        withTenantContext(session.tenantId, async () => {
          try {
            await loadTwilioRuntimeConfigFromDb({ trialWorkspace: true });
            next();
          } catch (err) {
            console.error("Tenant context error:", err);
            if (res.headersSent) return;
            if (req.path.startsWith("/api")) {
              return res.status(500).json({ error: "Workspace is unavailable. Try again or contact support." });
            }
            return res.status(500).send("Workspace unavailable");
          }
        })
      );
    }
    return withTenantContext(session.tenantId, () => next());
  } catch (err) {
    console.error("Tenant context error:", err);
    if (req.path.startsWith("/api")) {
      return res.status(500).json({ error: "Workspace is unavailable. Try again or contact support." });
    }
    return res.status(500).send("Workspace unavailable");
  }
});

function isBackgroundSessionPollPath(pathname) {
  const p = String(pathname || "");
  if (p === "/api/server-time" || p === "/api/email/open-events") return true;
  if (p === "/api/tasks/upcoming" || p.startsWith("/api/tasks/upcoming")) return true;
  if (p.startsWith("/api/twilio/call-status/")) return true;
  return false;
}

function shouldRefreshSessionActivity(req) {
  const p = String(req.path || "");
  if (isBackgroundSessionPollPath(p)) return false;
  const method = String(req.method || "GET").toUpperCase();
  if (method === "POST" || method === "PUT" || method === "PATCH" || method === "DELETE") {
    if (p === "/api/auth/logout") return false;
    return true;
  }
  if (String(req.get("x-crm-user-activity") || "").trim() === "1") return true;
  /* Keep session alive while browsing (settings, templates, etc.). Exclude periodic
     session-idle auth checks so an open tab alone does not defeat the idle timeout. */
  if (method === "GET" && p.startsWith("/api/") && p !== "/api/auth/status") return true;
  return false;
}

function shouldSkipSessionTouch(req) {
  const p = String(req.path || "");
  if (isAuthExemptApiPath(p)) return true;
  if (
    p === "/login.html" ||
    p === "/signup.html" ||
    p === "/signup" ||
    p === "/welcome.html" ||
    p === "/welcome" ||
    p === "/billing.html" ||
    p === "/billing" ||
    p === "/agent-demo.html" ||
    p === "/agent-demo" ||
    p === "/contact-sales.html" ||
    p === "/contact-sales"
  ) {
    return true;
  }
  return false;
}

app.use((req, res, next) => {
  const cookies = parseCookies(req);
  const hasAuthCookie = Boolean(String(cookies[AUTH_COOKIE_NAME] || "").trim());
  if (hasAuthCookie && !shouldSkipSessionTouch(req) && shouldRefreshSessionActivity(req)) {
    const touched = touchAuthSession(req, res);
    if (touched && touched.expired) {
      clearAuthCookie(res, req);
      if (req.path.startsWith("/api")) {
        return res.status(401).json({
          error: "Your session expired due to inactivity. Please log in again.",
          sessionExpired: true
        });
      }
      if (shouldProtectPageRoute(req.path)) {
        return res.redirect(buildLoginRedirectUrl(req, { sessionTimedOut: true }));
      }
    }
  }
  next();
});

app.use((req, res, next) => {
  /* Auth gate for /api/*. When login is not fully configured we only allow
     requests originating from the host machine so the admin can complete
     setup; everything else fails closed. */
  if (!req.path.startsWith("/api")) return next();
  if (isAuthExemptApiPath(req.path)) return next();
  if (isRequestAuthenticated(req)) return next();
  if (!loginIsFullyConfigured() && !isLocalRequest(req)) {
    return res.status(503).json({
      error: "CRM login is not configured yet. Sign in from the host machine to complete setup."
    });
  }
  const sessionExpired = hadStaleAuthCookie(req);
  if (sessionExpired) clearAuthCookie(res, req);
  return res.status(401).json({
    error: sessionExpired
      ? "Your session expired due to inactivity. Please log in again."
      : "Please log in to continue.",
    sessionExpired
  });
});

app.use(async (req, res, next) => {
  if (!req.path.startsWith("/api")) return next();
  if (isAuthExemptApiPath(req.path) || isBillingExemptApiPath(req.path)) return next();
  const session = getAuthSession(req);
  if (!session?.tenantId || session.tenantId === LEGACY_TENANT_ID) return next();
  try {
    const tenant = await markTenantExpiredIfNeeded(session.tenantId);
    const trial = computeTrialState(tenant);
    if (trial.allowed) return next();
    return res.status(402).json({
      error: "Your 14-day trial has ended. Subscribe to continue using Cadence Pro.",
      billingRequired: true,
      monthlyPrice: PRO_MONTHLY_USD,
      trialEndsAt: Number(tenant?.trial_ends_at || 0)
    });
  } catch (err) {
    console.error("Trial gate error:", err);
    return res.status(500).json({ error: "Could not verify subscription status." });
  }
});

app.post("/api/auth/login", authLoginLimiter, async (req, res) => {
  const email = String(req.body?.email || "")
    .trim()
    .toLowerCase();
  if (!isEmailLike(email)) return res.status(400).json({ error: "Enter a valid email address." });
  const password = String(req.body?.password ?? "");

  /* Always read owner sign-in from legacy crm.sqlite — never from a trial workspace DB. */
  try {
    await withTenantContext(LEGACY_TENANT_ID, async () => {
      await loadTwilioRuntimeConfigFromDb();
    });
  } catch (err) {
    console.error("Login runtime config load:", err.message || err);
  }

  const configured = getConfiguredLoginEmail();
  const storedHash = getConfiguredLoginPasswordHash();
  if (configured && storedHash && email === configured) {
    if (!verifyLoginPassword(password, storedHash)) {
      return res.status(401).json({ error: "Invalid email or password." });
    }
    if (auth2faState.completeLoginOrChallenge) {
      return auth2faState.completeLoginOrChallenge(req, res, email);
    }
    const token = issueSignedAuthToken(email, LEGACY_TENANT_ID);
    setAuthCookie(res, token, req);
    return res.json({ ok: true, tenantId: LEGACY_TENANT_ID, workspace: "owner", email });
  }

  const tenantUser = await getTenantUserByEmail(email);
  if (tenantUser && verifyLoginPassword(password, tenantUser.password_hash)) {
    const tenant = await markTenantExpiredIfNeeded(tenantUser.tenant_id);
    const trial = computeTrialState(tenant);
    await openTenantDatabase(tenantUser.tenant_id);
    const token = issueSignedAuthToken(email, tenantUser.tenant_id);
    setAuthCookie(res, token, req);
    return res.json({
      ok: true,
      tenantId: tenantUser.tenant_id,
      workspace: "trial",
      email,
      trialEndsAt: Number(tenant?.trial_ends_at || 0),
      daysLeft: trial.daysLeft,
      agencyName: tenant?.agency_name || "",
      billingRequired: !trial.allowed,
      status: trial.status
    });
  }

  if (!configured) return res.status(400).json({ error: "Login email is not configured in Settings yet." });
  if (!storedHash) {
    return res.status(400).json({ error: "Login password is not set yet. Set it under Settings → Sign-in." });
  }
  return res.status(401).json({ error: "Invalid email or password." });
});

const FORGOT_PASSWORD_SENT_MSG =
  "We emailed a temporary password. Check your inbox and spam folder, then sign in with that password.";

app.post("/api/auth/forgot-password", forgotPasswordLimiter, async (req, res) => {
  const email = String(req.body?.email || "")
    .trim()
    .toLowerCase();
  if (!isEmailLike(email)) {
    return res.status(400).json({ error: "Enter a valid email address." });
  }

  try {
    if (!canSendTrialWelcomeEmail()) {
      console.error(`[auth] Forgot-password for ${email} but trial welcome SMTP is not configured.`);
      return res.status(503).json({
        ok: false,
        sent: false,
        error: "We could not email a password because sending is not set up yet. Nothing was changed."
      });
    }

    const configuredOwner = getConfiguredLoginEmail();
    if (configuredOwner && email === configuredOwner) {
      console.log(`[auth] Forgot-password requested for owner login ${email} — use Settings.`);
      return res.status(400).json({
        ok: false,
        sent: false,
        error: "That email is the main site sign-in. Change it under Settings → Sign-in. Nothing was emailed."
      });
    }

    const tenantUser = await getTenantUserByEmail(email);
    if (!tenantUser) {
      return res.status(404).json({
        ok: false,
        sent: false,
        error: "We did not find a trial account for that email, so nothing was sent."
      });
    }

    const issued = await issueNewTrialPasswordForEmail(email);
    if (!issued?.tempPassword) {
      return res.status(404).json({
        ok: false,
        sent: false,
        error: "We did not find a trial account for that email, so nothing was sent."
      });
    }

    const signup = await get(`SELECT first_name, trial_ends_at FROM subscription_signups WHERE email = ?`, [email]);
    const trialEndsAt = Number(issued.tenant?.trial_ends_at || signup?.trial_ends_at || Date.now());
    let welcomeResult = { sent: false, error: "Email was not sent." };
    try {
      welcomeResult = await sendTrialWelcomeEmail({
        email,
        firstName: signup?.first_name || "there",
        tempPassword: issued.tempPassword,
        trialEndsAt,
        agencyName: issued.tenant?.agency_name || "",
        accessResent: true
      });
    } catch (sendErr) {
      welcomeResult = { sent: false, error: sendErr && sendErr.message ? sendErr.message : sendErr };
    }

    if (!welcomeResult.sent) {
      console.error(`[auth] Forgot-password email failed for ${email}:`, welcomeResult.error);
      let restored = false;
      try {
        await restoreTrialPasswordHash(issued.tenantUser.id, issued.previousHash);
        restored = true;
      } catch (restoreErr) {
        console.error("[auth] Could not restore the previous trial password:", restoreErr.message || restoreErr);
      }
      return res.status(502).json({
        ok: false,
        sent: false,
        error: restored
          ? "We could not send the password email. Your password was not changed."
          : "We could not send the password email, and the password was already changed. Try Email me a password again in a few minutes."
      });
    }

    console.log(`[auth] Forgot-password email sent to ${email} via ${welcomeResult.via || "unknown"}`);
    return res.json({ ok: true, sent: true, message: FORGOT_PASSWORD_SENT_MSG });
  } catch (err) {
    console.error("[auth] Forgot-password error:", err.message || err);
    return res.status(500).json({
      ok: false,
      sent: false,
      error: "We could not send the password email. Nothing was changed."
    });
  }
});

app.post("/api/auth/logout", (req, res) => {
  const cookies = parseCookies(req);
  const token = String(cookies[AUTH_COOKIE_NAME] || "").trim();
  if (token) authSessions.delete(token);
  clearAuthCookie(res, req);
  return res.json({ ok: true });
});

app.get("/logout", (req, res) => {
  const cookies = parseCookies(req);
  const token = String(cookies[AUTH_COOKIE_NAME] || "").trim();
  if (token) authSessions.delete(token);
  clearAuthCookie(res, req);
  return res.redirect("/login.html?signedOut=1");
});

/** Throttled background send kick — used by /api/health and /api/cron/email-queue so
 *  throttled tag campaigns (and drips) keep moving when nobody is logged in.
 *  cPanel Passenger often sleeps the Node process when idle; an external cron
 *  hitting these endpoints wakes it and drains due queue rows. */
let lastOutboundQueueKickAt = 0;
function kickOutboundEmailQueues({ force = false, maxPerTick = 8 } = {}) {
  const now = Date.now();
  if (!force && now - lastOutboundQueueKickAt < 25_000) {
    return { kicked: false, reason: "throttled" };
  }
  lastOutboundQueueKickAt = now;
  processDueBulkEmails(bulkEmailProcessorDeps(maxPerTick)).catch((err) =>
    console.error("[email-bulk] cron/health tick:", (err && err.message) || err)
  );
  processDueDripSends({ run, all, get, getSigningSecret: getAuthSigningSecret }).catch((err) =>
    console.error("[drip] cron/health tick:", (err && err.message) || err)
  );
  processFollowUpReminders(reminderJobDeps()).catch((err) =>
    console.error("[follow-up reminder] cron/health tick:", (err && err.message) || err)
  );
  processTaskReminders(reminderJobDeps()).catch((err) =>
    console.error("[task reminder] cron/health tick:", (err && err.message) || err)
  );
  return { kicked: true };
}

function cronSecretAuthorized(req) {
  const expected = String(process.env.CRON_SECRET || "").trim();
  if (!expected) return true; // open when unset (cPanel curl to /api/health still works)
  const header = String(req.get("x-cron-secret") || "").trim();
  const queryKey = String(req.query?.key || "").trim();
  const bearer = String(req.get("authorization") || "").replace(/^Bearer\s+/i, "").trim();
  return header === expected || queryKey === expected || bearer === expected;
}

app.get("/api/health", (req, res) => {
  const queue = kickOutboundEmailQueues({ maxPerTick: 8 });
  return res.json({ ok: true, service: "cadence-crm", queue });
});

app.get("/api/cron/email-queue", (req, res) => {
  if (!cronSecretAuthorized(req)) {
    return res.status(401).json({ error: "Invalid cron secret." });
  }
  const queue = kickOutboundEmailQueues({ force: true, maxPerTick: 15 });
  return res.json({ ok: true, service: "cadence-crm", queue });
});

function getTrialSignupNotificationRecipients() {
  const raw = String(process.env.TRIAL_SIGNUP_NOTIFY_EMAIL || "").trim();
  const fromFallback = String(process.env.SMTP_FROM || process.env.SMTP_USER || "").trim();
  const parsed = (raw ? raw.split(/[;,]+/) : [])
    .map((v) => String(v || "").trim().toLowerCase())
    .filter((v) => isEmailLike(v));
  const unique = [...new Set(parsed)];
  if (unique.length) return unique;
  return fromFallback && isEmailLike(fromFallback) ? [fromFallback.toLowerCase()] : [];
}

async function notifyTrialSignupByEmail({
  firstName,
  lastName,
  email,
  phone,
  agencyName,
  licensedState,
  licenseNumber,
  residentState,
  trialEndsAt,
  alreadyRegistered = false
}) {
  const recipients = getTrialSignupNotificationRecipients();
  if (!recipients.length || !(await canSendSystemNotificationEmail())) return false;
  const fullName = `${firstName} ${lastName}`.trim();
  const trialEndText = new Date(Number(trialEndsAt || Date.now())).toISOString().replace("T", " ").replace("Z", " UTC");
  const lines = [
    "New 14-day Cadence CRM trial signup",
    alreadyRegistered ? "NOTE: This email was already registered before (repeat submission)." : "",
    "",
    `Name: ${fullName || "—"}`,
    `Email: ${email || "—"}`,
    `Phone: ${phone || "—"}`,
    `Agency: ${agencyName || "—"}`,
    `Resident state: ${residentState || "—"}`,
    `Licensed state: ${licensedState || "—"}`,
    `License number: ${licenseNumber || "—"}`,
    `Trial ends: ${trialEndText}`,
    "",
    "This lead was submitted from the public signup form."
  ];
  await sendSystemNotificationEmail({
    to: recipients.join(", "),
    subject: `${alreadyRegistered ? "[Repeat] " : ""}New Cadence trial signup: ${fullName || email}`,
    text: lines.join("\n")
  });
  return true;
}

function getContactSalesNotificationRecipients() {
  const raw = String(process.env.CONTACT_SALES_NOTIFY_EMAIL || "").trim();
  const trialFallback = String(process.env.TRIAL_SIGNUP_NOTIFY_EMAIL || "").trim();
  const fromFallback = String(process.env.SMTP_FROM || process.env.SMTP_USER || "").trim();
  const source = raw || trialFallback;
  const parsed = (source ? source.split(/[;,]+/) : [])
    .map((v) => String(v || "").trim().toLowerCase())
    .filter((v) => isEmailLike(v));
  const unique = [...new Set(parsed)];
  if (unique.length) return unique;
  return fromFallback && isEmailLike(fromFallback) ? [fromFallback.toLowerCase()] : [];
}

async function notifyContactSalesByEmail({
  fullName,
  email,
  phone,
  country,
  companyName,
  companySize,
  hearAbout,
  message
}) {
  const recipients = getContactSalesNotificationRecipients();
  if (!recipients.length || !(await canSendSystemNotificationEmail())) return false;
  const submittedAt = new Date().toISOString().replace("T", " ").replace("Z", " UTC");
  const lines = [
    "New Contact Sales inquiry — Cadence CRM",
    "",
    `Name: ${fullName || "—"}`,
    `Email: ${email || "—"}`,
    `Phone: ${phone || "—"}`,
    `Country: ${country || "—"}`,
    `Company: ${companyName || "—"}`,
    `Company size: ${companySize || "—"}`,
    `How they heard about us: ${hearAbout || "—"}`,
    `Message: ${message || "—"}`,
    "",
    `Submitted: ${submittedAt}`,
    "Source: https://crmcadence.com/contact-sales.html"
  ];
  await sendSystemNotificationEmail({
    to: recipients.join(", "),
    subject: `New Contact Sales lead: ${fullName || email}${companyName ? ` (${companyName})` : ""}`,
    text: lines.join("\n"),
    from: String(process.env.SMTP_FROM || process.env.SMTP_USER || "").trim() || undefined
  });
  return true;
}

/** Login links in trial welcome email — not CRM_PUBLIC_URL (may point at another host). */
function getTrialWelcomeLoginBase() {
  const explicit = String(process.env.TRIAL_WELCOME_LOGIN_URL || "").trim().replace(/\/$/, "");
  if (explicit) return explicit;
  return "https://crmcadence.com";
}

function isLegacyOwnerPublicUrl(url) {
  return /wisehealthagency/i.test(String(url || ""));
}

function resolveCrmPublicUrlForRequest(req, storedRaw) {
  const stored = String(storedRaw || "").trim();
  if (isTrialWorkspaceSession(req)) {
    if (stored && !isLegacyOwnerPublicUrl(stored)) return stored;
    return getTrialWelcomeLoginBase();
  }
  return stored || String(process.env.CRM_PUBLIC_URL || "").trim();
}

function isLikelyTwilioAccountSid(value) {
  return /^AC[0-9a-f]{32}$/i.test(String(value || "").trim());
}

function isLikelyTwilioAuthToken(value) {
  const s = String(value || "").trim();
  if (!s) return false;
  if (s.includes("@") || /\s/.test(s)) return false;
  if (s.startsWith("$2") || s.startsWith("scrypt:")) return false;
  return /^[0-9a-f]{32}$/i.test(s);
}

/** Remove credentials that cannot be Twilio values (e.g. login password autofill). */
async function purgeInvalidTrialTwilioSecrets() {
  const rows = await all(
    `SELECT key, value FROM twilio_runtime_config WHERE key IN ('authToken', 'accountSid', 'apiSecret')`
  );
  for (const row of Array.isArray(rows) ? rows : []) {
    const key = String(row.key || "");
    const raw = String(row.value || "");
    if (key === "accountSid") {
      const sid = raw.trim();
      if (sid && (sid.includes("@") || !isLikelyTwilioAccountSid(sid))) {
        await run(`DELETE FROM twilio_runtime_config WHERE key = ?`, [key]);
      }
      continue;
    }
    const plain = String(decryptSecret(raw) || "").trim();
    if (!plain) continue;
    const valid =
      key === "authToken"
        ? isLikelyTwilioAuthToken(plain)
        : key === "apiSecret"
          ? isLikelyTwilioApiSecret(plain)
          : plain.length >= 16 && !plain.includes("@");
    if (!valid) {
      await run(`DELETE FROM twilio_runtime_config WHERE key = ?`, [key]);
    }
  }
}

async function sendTrialWelcomeEmail({
  email,
  firstName,
  tempPassword,
  trialEndsAt,
  agencyName,
  existingAccount = false,
  accessResent = false,
  provisionedPhone = null
}) {
  if (!canSendTrialWelcomeEmail() || !isEmailLike(email)) {
    return { sent: false, error: "SMTP not configured" };
  }
  const base = getTrialWelcomeLoginBase();
  const trialEndText = new Date(Number(trialEndsAt || Date.now())).toLocaleDateString(undefined, {
    month: "long",
    day: "numeric",
    year: "numeric"
  });
  const lines =
    existingAccount && !tempPassword
      ? [
          `Hi ${firstName || "there"},`,
          "",
          "You already have a Cadence CRM trial workspace for this email.",
          "",
          `Trial ends: ${trialEndText}`,
          `Log in: ${base}/login.html`,
          `Email: ${email}`,
          "",
          "Use the password from your original welcome email, or change it under Settings → Sign-in after you log in.",
          "",
          "If you did not create this account, contact support@crmcadence.com.",
          "",
          "— Cadence CRM"
        ]
      : accessResent && tempPassword
        ? [
            `Hi ${firstName || "there"},`,
            "",
            "We received another signup request for this email. Your Cadence CRM trial is already active.",
            "",
            "If you did not sign up before, someone may have used this email by mistake — contact support@crmcadence.com.",
            "",
            "Sign in with this new temporary password (previous trial passwords no longer work):",
            `  Login page: ${base}/login.html`,
            `  Email: ${email}`,
            `  Temporary password: ${tempPassword}`,
            "",
            `Trial ends: ${trialEndText}`,
            "",
            "Change your password anytime under Settings → Sign-in.",
            "",
            "— Cadence CRM"
          ]
        : [
        `Hello ${firstName || "there"},`,
        "",
        "",
        "Welcome to the future of CRM—where AI transforms how you connect with customers.",
        "",
        "",
        "",
        "With over 20 years of sales experience and 12 years specifically in health insurance, I know the exact challenges you face as a Health Insurance Agent. That is exactly why I built Cadence CRM. It is a platform dedicated to streamlining your sales process—from the initial lead and contact to the close and beyond.",
        "",
        "",
        "I designed Cadence to eliminate wasted time and keep you productive at every given moment. Remember, \"Success happens when opportunity meets preparation.\"",
        "",
        "",
        "Think of Cadence CRM as a tireless partner that works for you even when you are not. Our built-in workflows and automations are custom-made for the health insurance market to help you scale your business effortlessly.",
        "",
        "Your 14-day Pro trial is ready. Here is how to log in:",
        "",
        `  Login page: ${base}/login.html`,
        `  Email: ${email}`,
        `  Temporary password: ${tempPassword}`,
        "",
        `Workspace: ${agencyName || "Your agency"}`,
        `Trial ends: ${trialEndText}`,
        `Monthly price after trial: $${PRO_MONTHLY_USD}/month`,
        "",
        ...(provisionedPhone ? [
          "📱 Your dedicated business phone number is ready:",
          `  ${provisionedPhone}`,
          "Use it to send texts and make calls directly from Cadence. Find it under Settings → Texting & Calls.",
          ""
        ] : []),
        "Change your password anytime under Settings → Sign-in.",
        "",
        "If you do not see this message in your inbox, check your spam or junk folder and mark it as not spam.",
        "",
        "I wish you great success in this new journey. If I can ever be of personal help, please feel free to reach out anytime.",
        "",
        "Best regards,",
        "Joseph R. Pugliares",
        "Founder, Cadence CRM",
        "support@crmcadence.com"
      ];

  const isMainWelcome = !(existingAccount || (accessResent && tempPassword));
  const welcomeHtml = isMainWelcome ? `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:'Segoe UI',system-ui,sans-serif;color:#0f172a;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:40px 16px;">
    <tr><td align="center">
      <table width="100%" style="max-width:580px;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 8px 32px rgba(15,23,42,0.10);" cellpadding="0" cellspacing="0">

        <!-- Header -->
        <tr>
          <td style="background:linear-gradient(135deg,#312e81 0%,#4f46e5 60%,#7c3aed 100%);padding:32px 40px 28px;text-align:center;">
            <p style="margin:0 0 4px;font-size:1.5rem;font-weight:800;color:#ffffff;letter-spacing:-0.01em;">Cadence CRM</p>
            <p style="margin:0;font-size:0.88rem;color:rgba(255,255,255,0.80);font-weight:500;">Built for Health Insurance Agents</p>
          </td>
        </tr>

        <!-- Body -->
        <tr>
          <td style="padding:36px 40px 32px;">
            <p style="margin:0 0 20px;font-size:1.05rem;color:#0f172a;">Hello ${firstName || "there"},</p>

            <p style="margin:0 0 32px;font-size:1.05rem;font-weight:600;line-height:1.75;color:#1e1b4b;">
              Welcome to the future of CRM—where AI transforms how you connect with customers.
            </p>
            <p style="margin:0 0 24px;font-size:0.97rem;line-height:1.75;color:#334155;">
              With over 20 years of sales experience and 12 years specifically in health insurance, I know the exact challenges you face as a Health Insurance Agent. That is exactly why I built Cadence CRM. It is a platform dedicated to streamlining your sales process—from the initial lead and contact to the close and beyond.
            </p>
            <p style="margin:0 0 24px;font-size:0.97rem;line-height:1.75;color:#334155;">
              I designed Cadence to eliminate wasted time and keep you productive at every given moment. Remember, <em>"Success happens when opportunity meets preparation."</em>
            </p>
            <p style="margin:0 0 32px;font-size:0.97rem;line-height:1.75;color:#334155;">
              Think of Cadence CRM as a tireless partner that works for you even when you are not. Our built-in workflows and automations are custom-made for the health insurance market to help you scale your business effortlessly.
            </p>

            <!-- Login box -->
            <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;margin-bottom:28px;">
              <tr><td style="padding:24px 28px;">
                <p style="margin:0 0 16px;font-size:0.82rem;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:#4f46e5;">Your Login Details</p>
                <table cellpadding="0" cellspacing="0">
                  <tr>
                    <td style="font-size:0.9rem;color:#64748b;padding:4px 16px 4px 0;white-space:nowrap;">Login page</td>
                    <td style="font-size:0.9rem;color:#1e1b4b;font-weight:600;padding:4px 0;"><a href="${base}/login.html" style="color:#4f46e5;text-decoration:none;">${base}/login.html</a></td>
                  </tr>
                  <tr>
                    <td style="font-size:0.9rem;color:#64748b;padding:4px 16px 4px 0;white-space:nowrap;">Email</td>
                    <td style="font-size:0.9rem;color:#1e1b4b;font-weight:600;padding:4px 0;">${email}</td>
                  </tr>
                  <tr>
                    <td style="font-size:0.9rem;color:#64748b;padding:4px 16px 4px 0;white-space:nowrap;">Temp password</td>
                    <td style="font-size:0.9rem;color:#1e1b4b;font-weight:600;padding:4px 0;font-family:monospace;">${tempPassword}</td>
                  </tr>
                  <tr>
                    <td style="font-size:0.9rem;color:#64748b;padding:4px 16px 4px 0;white-space:nowrap;">Trial ends</td>
                    <td style="font-size:0.9rem;color:#1e1b4b;font-weight:600;padding:4px 0;">${trialEndText}</td>
                  </tr>
                  <tr>
                    <td style="font-size:0.9rem;color:#64748b;padding:4px 16px 4px 0;white-space:nowrap;">After trial</td>
                    <td style="font-size:0.9rem;color:#1e1b4b;font-weight:600;padding:4px 0;">$${PRO_MONTHLY_USD}/month</td>
                  </tr>
                </table>
                <div style="margin-top:20px;text-align:center;">
                  <a href="${base}/login.html" style="display:inline-block;padding:12px 28px;background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;font-weight:700;font-size:0.95rem;text-decoration:none;border-radius:999px;">Log In to Cadence →</a>
                </div>
              </td></tr>
            </table>

            ${provisionedPhone ? `
            <table width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 20px;background:#d1fae5;border:1px solid #6ee7b7;border-radius:12px;">
              <tr><td style="padding:16px 20px;">
                <p style="margin:0 0 4px;font-size:0.95rem;font-weight:700;color:#065f46;">📱 Your dedicated business phone number is ready</p>
                <p style="margin:0 0 8px;font-size:1.1rem;font-weight:800;color:#064e3b;letter-spacing:0.03em;">${provisionedPhone}</p>
                <p style="margin:0;font-size:0.88rem;color:#047857;">Use it to send texts and make calls directly from Cadence. Find it under <strong>Settings → Texting &amp; Calls</strong>.</p>
              </td></tr>
            </table>` : ""}

            <!-- 3 steps to get started -->
            <table width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 24px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;">
              <tr><td style="padding:20px 24px;">
                <p style="margin:0 0 16px;font-size:0.82rem;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:#4f46e5;">3 Steps to Get Started</p>
                <table cellpadding="0" cellspacing="0" width="100%">
                  <tr>
                    <td style="padding:8px 0;border-bottom:1px solid #e2e8f0;">
                      <span style="display:inline-block;width:24px;height:24px;background:#4f46e5;color:#fff;border-radius:50%;text-align:center;line-height:24px;font-size:0.8rem;font-weight:700;margin-right:10px;vertical-align:middle;">1</span>
                      <span style="font-size:0.92rem;color:#1e293b;font-weight:600;vertical-align:middle;">Change your password</span>
                      <span style="font-size:0.82rem;color:#64748b;display:block;margin-left:34px;">Go to <strong>Settings → General</strong> and set a permanent password.</span>
                    </td>
                  </tr>
                  <tr>
                    <td style="padding:8px 0;border-bottom:1px solid #e2e8f0;">
                      <span style="display:inline-block;width:24px;height:24px;background:#4f46e5;color:#fff;border-radius:50%;text-align:center;line-height:24px;font-size:0.8rem;font-weight:700;margin-right:10px;vertical-align:middle;">2</span>
                      <span style="font-size:0.92rem;color:#1e293b;font-weight:600;vertical-align:middle;">Forward calls to your cell</span>
                      <span style="font-size:0.82rem;color:#64748b;display:block;margin-left:34px;">Go to <strong>Settings → Texting &amp; Calls</strong> and enter your cell number so inbound calls ring your phone.</span>
                    </td>
                  </tr>
                  <tr>
                    <td style="padding:8px 0;">
                      <span style="display:inline-block;width:24px;height:24px;background:#4f46e5;color:#fff;border-radius:50%;text-align:center;line-height:24px;font-size:0.8rem;font-weight:700;margin-right:10px;vertical-align:middle;">3</span>
                      <span style="font-size:0.92rem;color:#1e293b;font-weight:600;vertical-align:middle;">Connect your email</span>
                      <span style="font-size:0.82rem;color:#64748b;display:block;margin-left:34px;">Go to <strong>Settings → API &amp; Integrations</strong> and add your SMTP settings to send emails and campaigns.</span>
                    </td>
                  </tr>
                </table>
              </td></tr>
            </table>

            <p style="margin:0 0 16px;font-size:0.9rem;color:#64748b;line-height:1.6;">
              Change your password anytime under <strong>Settings → Sign-in</strong>. If you do not see this email in your inbox, check your spam folder and mark it as not spam.
            </p>

            <p style="margin:28px 0 6px;font-size:0.97rem;line-height:1.65;color:#334155;">
              I wish you great success in this new journey. If I can ever be of personal help, please feel free to reach out anytime.
            </p>
            <p style="margin:0 0 4px;font-size:0.97rem;color:#334155;font-weight:600;">Best regards,</p>
            <p style="margin:0 0 2px;font-size:0.97rem;color:#1e1b4b;font-weight:700;">Joseph R. Pugliares</p>
            <p style="margin:0;font-size:0.88rem;color:#64748b;">Founder, Cadence CRM</p>
          </td>
        </tr>

        <!-- Footer -->
        <tr>
          <td style="background:#f8fafc;border-top:1px solid #e2e8f0;padding:20px 40px;text-align:center;">
            <p style="margin:0;font-size:0.8rem;color:#94a3b8;">
              © Cadence CRM &nbsp;·&nbsp; <a href="https://crmcadence.com" style="color:#4f46e5;text-decoration:none;">crmcadence.com</a> &nbsp;·&nbsp; <a href="mailto:support@crmcadence.com" style="color:#4f46e5;text-decoration:none;">support@crmcadence.com</a>
            </p>
          </td>
        </tr>

      </table>
    </td></tr>
  </table>
</body>
</html>` : undefined;

  try {
    const info = await deliverTrialWelcomeEmail({
      to: email,
      subject:
        accessResent && tempPassword
          ? "Your Cadence CRM trial login (new temporary password)"
          : existingAccount
            ? "Your Cadence CRM trial login"
            : `Welcome to Cadence CRM, ${firstName || "there"}!`,
      text: lines.join("\n"),
      html: welcomeHtml
    });
    return { sent: true, via: info.via || "unknown" };
  } catch (err) {
    return { sent: false, error: String(err && err.message ? err.message : err) };
  }
}

app.post("/api/subscription/signup", subscriptionSignupLimiter, async (req, res) => {
  const firstName = String(req.body?.firstName || "").trim();
  const lastName = String(req.body?.lastName || "").trim();
  const email = String(req.body?.email || "")
    .trim()
    .toLowerCase();
  const emailErr = emailErrorMessage(email);
  if (emailErr) {
    return res.status(400).json({ error: emailErr });
  }
  const phoneRaw = String(req.body?.phone || "").trim();
  if (phoneRaw && !isValidSignupPhone(phoneRaw)) {
    return res.status(400).json({
      error: "Enter a valid 10-digit US phone number, or leave phone blank. You can use +1 or dashes — we will format it."
    });
  }

  try {
    await withSignupLock(email, async () => {
      return handleSubscriptionSignup(req, res, {
        firstName,
        lastName,
        email,
        phone: normalizeSignupPhone(phoneRaw),
        agencyName: String(req.body?.agencyName || "").trim(),
        residentState: String(req.body?.residentState || "").trim(),
        licensedState: String(req.body?.state || req.body?.licensedState || "").trim().toUpperCase(),
        licenseNumber: String(req.body?.licenseNumber || "").trim(),
        plan: String(req.body?.plan || "pro").trim().toLowerCase() || "pro"
      });
    });
  } catch (err) {
    if (!res.headersSent) {
      console.error("Subscription signup error:", err);
      return res.status(500).json({ error: "Could not save your signup. Please try again." });
    }
  }
});

async function handleSubscriptionSignup(req, res, body) {
  try {
    const { firstName, lastName, email, phone, agencyName, residentState, licensedState, licenseNumber, plan } = body;
    if (!firstName || !lastName) {
      return res.status(400).json({ error: "First and last name are required." });
    }
    if (!String(residentState || "").trim()) {
      return res.status(400).json({ error: "Resident state is required." });
    }
    const signupEmailErr = emailErrorMessage(email);
    if (signupEmailErr) {
      return res.status(400).json({ error: signupEmailErr });
    }
    if (plan !== "pro") {
      return res.status(400).json({ error: "Only the Pro plan is available." });
    }

    const trialEndsAt = Date.now() + TRIAL_DAYS * 24 * 60 * 60 * 1000;
    const termsAcceptedAt = Math.floor(Date.now() / 1000);

    const existing = await get(
      `SELECT id, trial_ends_at, tenant_id, created_at FROM subscription_signups WHERE email = ?`,
      [email]
    );
    if (existing) {
      const existingUser = await getTenantUserByEmail(email);
      const trialEnd = Number(existing.trial_ends_at) || trialEndsAt;

      if (!existingUser) {
        console.log(`[subscription] Recovering orphan signup for ${email} (signup row without workspace)`);
        let provisioned;
        try {
          provisioned = await provisionTrialTenant({
            firstName,
            lastName,
            email,
            phone,
            agencyName,
            residentState,
            licensedState,
            licenseNumber,
            plan
          });
        } catch (provErr) {
          console.error("[subscription] Orphan recovery provision failed:", provErr);
          return res.status(500).json({ error: "Could not create your trial workspace. Please contact support." });
        }
        const recoveredPassword = provisioned.tempPassword;
        const tenantTrialEnds = Number(provisioned.tenant?.trial_ends_at || trialEnd);
        let welcomeResult = { sent: false };
        if (recoveredPassword) {
          welcomeResult = await sendTrialWelcomeEmail({
            email,
            firstName,
            tempPassword: recoveredPassword,
            trialEndsAt: tenantTrialEnds,
            agencyName
          });
        }
        try {
          await notifyTrialSignupByEmail({
            firstName,
            lastName,
            email,
            phone,
            agencyName,
            residentState,
            licensedState,
            licenseNumber,
            trialEndsAt: tenantTrialEnds,
            alreadyRegistered: false
          });
        } catch (notifyErr) {
          console.error("[subscription] Orphan recovery notify failed:", notifyErr.message || notifyErr);
        }
        return res.status(201).json({
          ok: true,
          email,
          plan: "pro",
          monthlyPrice: PRO_MONTHLY_USD,
          trialEndsAt: tenantTrialEnds,
          alreadyRegistered: false,
          recovered: true,
          tempPassword: recoveredPassword || undefined,
          tenantId: provisioned.tenant?.id,
          loginReady: Boolean(recoveredPassword),
          welcomeEmailSent: welcomeResult.sent,
          welcomeEmailError: welcomeResult.sent ? undefined : welcomeResult.error
        });
      }

      const trialEndActive =
        Number(existingUser.trial_ends_at) || Number(existing.trial_ends_at) || trialEnd;
      const signupAgeMs = Date.now() - (Number(existing.created_at) || 0) * 1000;
      if (signupAgeMs < SIGNUP_DUPLICATE_WINDOW_MS) {
        console.log(
          `[subscription] Duplicate signup request for ${email} (${Math.round(signupAgeMs / 1000)}s after first) — no extra email`
        );
        return res.json({
          ok: true,
          email,
          plan: "pro",
          monthlyPrice: PRO_MONTHLY_USD,
          trialEndsAt: trialEndActive,
          alreadyRegistered: false,
          duplicateRequest: true,
          hasWorkspace: true,
          loginEmail: email,
          welcomeEmailSent: true
        });
      }

      const reissued = await issueNewTrialPasswordForEmail(email);
      const trialEndRepeat = Number(reissued?.tenant?.trial_ends_at) || trialEndActive;
      try {
        await notifyTrialSignupByEmail({
          firstName,
          lastName,
          email,
          phone,
          agencyName,
          residentState,
          licensedState,
          licenseNumber,
          trialEndsAt: trialEndRepeat,
          alreadyRegistered: true
        });
      } catch (notifyErr) {
        console.error("[subscription] Repeat signup notify failed:", notifyErr.message || notifyErr);
      }
      let welcomeResult = { sent: false };
      if (reissued?.tempPassword) {
        welcomeResult = await sendTrialWelcomeEmail({
          email,
          firstName,
          tempPassword: reissued.tempPassword,
          trialEndsAt: trialEndRepeat,
          agencyName,
          existingAccount: false,
          accessResent: true
        });
        if (!welcomeResult.sent) {
          console.error("[subscription] Repeat signup welcome email failed:", welcomeResult.error);
        }
      }
      return res.json({
        ok: true,
        email,
        plan: "pro",
        monthlyPrice: PRO_MONTHLY_USD,
        trialEndsAt: trialEndRepeat,
        alreadyRegistered: true,
        accessResent: Boolean(reissued?.tempPassword),
        hasWorkspace: true,
        loginEmail: email,
        tempPassword: reissued?.tempPassword || undefined,
        welcomeEmailSent: welcomeResult.sent,
        welcomeEmailError: welcomeResult.sent ? undefined : welcomeResult.error
      });
    }

    if (!isTermsAcceptanceValid(req.body)) {
      return res.status(400).json({ error: "You must accept the Terms of Service to start a trial." });
    }

    await run(
      `INSERT INTO subscription_signups (
         first_name, last_name, email, phone, agency_name, resident_state, licensed_state, license_number,
         plan, trial_ends_at, status, terms_accepted_at, terms_version
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'trial_active', ?, ?)`,
      [
        firstName,
        lastName,
        email,
        phone,
        agencyName,
        residentState,
        licensedState,
        licenseNumber,
        plan,
        trialEndsAt,
        termsAcceptedAt,
        TERMS_VERSION
      ]
    );

    let provisioned;
    try {
      provisioned = await provisionTrialTenant({
        firstName,
        lastName,
        email,
        phone,
        agencyName,
        residentState,
        licensedState,
        licenseNumber,
        plan
      });
    } catch (provErr) {
      console.error("[subscription] Tenant provision failed:", provErr);
      try {
        await run(`DELETE FROM subscription_signups WHERE email = ?`, [email]);
      } catch (rollbackErr) {
        console.error("[subscription] Signup rollback failed:", rollbackErr.message || rollbackErr);
      }
      return res.status(500).json({ error: "Could not create your trial workspace. Please contact support." });
    }

    let tempPassword = provisioned.tempPassword;
    if (!tempPassword && provisioned.alreadyRegistered) {
      const reissued = await issueNewTrialPasswordForEmail(email);
      tempPassword = reissued?.tempPassword || null;
    }
    const tenantTrialEnds = Number(provisioned.tenant?.trial_ends_at || trialEndsAt);

    console.log(
      `[subscription] New trial workspace: tenant=${provisioned.tenant?.id} email=${email} agency=${agencyName || "—"}`
    );

    try {
      await notifyTrialSignupByEmail({
        firstName,
        lastName,
        email,
        phone,
        agencyName,
        residentState,
        licensedState,
        licenseNumber,
        trialEndsAt: tenantTrialEnds
      });
    } catch (notifyErr) {
      console.error("[subscription] Admin notify failed:", notifyErr.message || notifyErr);
    }

    let welcomeResult = { sent: false, error: "No new password issued" };
    if (tempPassword) {
      welcomeResult = await sendTrialWelcomeEmail({
        email,
        firstName,
        tempPassword,
        trialEndsAt: tenantTrialEnds,
        agencyName,
        provisionedPhone: provisioned.provisionedPhone || null
      });
      if (!welcomeResult.sent) {
        console.error(`[subscription] Welcome email failed for ${email}:`, welcomeResult.error);
      } else {
        console.log(`[subscription] Welcome email sent to ${email} via ${welcomeResult.via}`);
      }
    } else if (provisioned.alreadyRegistered) {
      console.warn(`[subscription] Welcome email skipped for ${email} (could not issue login password).`);
    }

    return res.status(201).json({
      ok: true,
      email,
      plan: "pro",
      monthlyPrice: PRO_MONTHLY_USD,
      trialEndsAt: tenantTrialEnds,
      alreadyRegistered: false,
      tempPassword: tempPassword || undefined,
      tenantId: provisioned.tenant?.id,
      loginReady: Boolean(tempPassword),
      welcomeEmailSent: welcomeResult.sent,
      welcomeEmailVia: welcomeResult.via,
      welcomeEmailError: welcomeResult.sent ? undefined : welcomeResult.error
    });
  } catch (err) {
    console.error("Subscription signup error:", err);
    return res.status(500).json({ error: "Could not save your signup. Please try again." });
  }
}

app.get("/api/auth/status", async (req, res) => {
  const configured = getConfiguredLoginEmail();
  const session = getAuthSession(req);
  let subscription = null;
  if (session?.tenantId && session.tenantId !== LEGACY_TENANT_ID) {
    try {
      const tenant = await markTenantExpiredIfNeeded(session.tenantId);
      const trial = computeTrialState(tenant);
      subscription = {
        tenantId: session.tenantId,
        status: trial.status,
        trialEndsAt: Number(tenant?.trial_ends_at || 0),
        daysLeft: trial.daysLeft,
        needsPayment: trial.needsPayment,
        monthlyPrice: PRO_MONTHLY_USD,
        stripeConfigured: isStripeConfigured()
      };
    } catch {
      subscription = null;
    }
  }
  let workspace = null;
  if (session) {
    const isTrial = session.tenantId !== LEGACY_TENANT_ID;
    let agencyName = "";
    if (isTrial) {
      try {
        const tenant = await getTenantById(session.tenantId);
        agencyName = String(tenant?.agency_name || "").trim();
      } catch {
        agencyName = "";
      }
    }
    workspace = {
      type: isTrial ? "trial" : "owner",
      tenantId: session.tenantId,
      email: session.email,
      agencyName
    };
  }

  return res.json({
    loginRequired: Boolean(configured),
    passwordRequired: Boolean(getConfiguredLoginPasswordHash()),
    twoFactorEnabled: String(process.env.CRM_LOGIN_2FA_ENABLED || "").trim() === "1",
    authenticated: isRequestAuthenticated(req),
    idleTimeoutMinutes: Math.round(AUTH_IDLE_TIMEOUT_MS / 60_000),
    subscription,
    workspace
  });
});

app.post("/api/auth/activity", (req, res) => {
  const touched = touchAuthSession(req, res);
  if (!touched || touched.expired) {
    clearAuthCookie(res, req);
    return res.status(401).json({
      error: "Your session expired due to inactivity. Please log in again.",
      sessionExpired: true
    });
  }
  return res.json({
    ok: true,
    idleTimeoutMinutes: Math.round(AUTH_IDLE_TIMEOUT_MS / 60_000)
  });
});

app.get("/api/billing/status", async (req, res) => {
  const session = getAuthSession(req);
  if (!session?.tenantId || session.tenantId === LEGACY_TENANT_ID) {
    return res.json({ ok: true, legacy: true });
  }
  const tenant = await markTenantExpiredIfNeeded(session.tenantId);
  const trial = computeTrialState(tenant);
  return res.json({
    ok: true,
    tenantId: session.tenantId,
    agencyName: tenant?.agency_name || "",
    status: trial.status,
    trialEndsAt: Number(tenant?.trial_ends_at || 0),
    daysLeft: trial.daysLeft,
    needsPayment: trial.needsPayment,
    monthlyPrice: PRO_MONTHLY_USD,
    stripeConfigured: isStripeConfigured()
  });
});

app.post("/api/billing/create-checkout-session", async (req, res) => {
  const session = getAuthSession(req);
  if (!session?.tenantId || session.tenantId === LEGACY_TENANT_ID) {
    return res.status(400).json({ error: "Billing applies to trial workspaces only." });
  }
  try {
    const result = await createCheckoutSession(req, {
      tenantId: session.tenantId,
      email: session.email
    });
    if (result.error) return res.status(400).json({ error: result.error });
    return res.json({ ok: true, url: result.url });
  } catch (err) {
    console.error("Checkout session error:", err);
    return res.status(500).json({ error: "Could not start checkout. Try again later." });
  }
});

app.post("/api/billing/portal", async (req, res) => {
  const session = getAuthSession(req);
  if (!session?.tenantId || session.tenantId === LEGACY_TENANT_ID) {
    return res.status(400).json({ error: "Billing portal applies to trial workspaces only." });
  }
  try {
    const result = await createBillingPortalSession(req, { tenantId: session.tenantId });
    if (result.error) return res.status(400).json({ error: result.error });
    return res.json({ ok: true, url: result.url });
  } catch (err) {
    console.error("Billing portal error:", err);
    return res.status(500).json({ error: "Could not open billing portal." });
  }
});

function parseContactIds(input) {
  if (Array.isArray(input)) {
    return [...new Set(input.map((v) => Number(v)).filter((n) => Number.isInteger(n) && n > 0))];
  }
  if (typeof input === "string" && input.trim()) {
    return [
      ...new Set(
        input
          .split(",")
          .map((v) => Number(String(v).trim()))
          .filter((n) => Number.isInteger(n) && n > 0)
      )
    ];
  }
  return [];
}

/** Split stored or user-entered tag lists (comma, semicolon, or newline). */
function parseTagList(raw) {
  return String(raw || "")
    .split(/[,;\n\r]+/)
    .map((t) => t.trim())
    .filter(Boolean);
}

function mergeTags(existing, toAdd, toRemove) {
  const base = new Set(parseTagList(existing));
  for (const t of toAdd) base.add(t);
  for (const t of toRemove) base.delete(t);
  return [...base].join(", ");
}

function getAddedTags(prevRaw, nextRaw) {
  const prev = parseTagList(prevRaw);
  const next = parseTagList(nextRaw);
  const prevSet = new Set(prev.map((t) => t.toLowerCase()));
  return next.filter((t) => !prevSet.has(t.toLowerCase()));
}

async function logContactActivity(contactId, activityType, detail = "") {
  const id = Number(contactId);
  if (!Number.isInteger(id) || id < 1) return;
  const type = String(activityType || "event");
  await run(
    `INSERT INTO contact_activity (contact_id, activity_type, detail, created_at)
     VALUES (?, ?, ?, CURRENT_TIMESTAMP)`,
    [id, type, String(detail || "")]
  );
  if (["call", "sms", "email", "campaign"].includes(type.trim().toLowerCase())) {
    scheduleAutoLeadScore(dbDeps(), id, `activity_${type}`);
  }
}

function isSoldOutcomeValue(value) {
  const normalized = String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[-\s]/g, "");
  return normalized === "sold" || normalized === "closedsold";
}

async function stampOutcomeSoldAt(contactId) {
  const id = Number(contactId);
  if (!Number.isInteger(id) || id < 1) return;
  try {
    await run(`UPDATE contacts SET outcome_sold_at = CURRENT_TIMESTAMP WHERE id = ?`, [id]);
  } catch (err) {
    if (!/no such column: .*outcome_sold_at/i.test(String(err && err.message ? err.message : err))) {
      throw err;
    }
  }
}

function splitEmailAddresses(raw) {
  const out = [];
  const parts = String(raw || "")
    .split(/[,;\n\r]+/)
    .map((v) => String(v || "").trim())
    .filter(Boolean);
  for (const piece of parts) {
    const angleMatch = piece.match(/<([^>]+@[^>]+)>/);
    const emailMatch = piece.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
    const candidate = angleMatch
      ? String(angleMatch[1] || "").trim()
      : emailMatch
        ? String(emailMatch[0] || "").trim()
        : piece;
    const normalized = candidate.toLowerCase();
    if (!normalized || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized)) continue;
    out.push(normalized);
  }
  return [...new Set(out)];
}

function recipientEmailsFromBody(body) {
  const explicit = Array.isArray(body?.recipientEmails) ? body.recipientEmails : [];
  const fromExplicit = [];
  for (const item of explicit) {
    for (const addr of splitEmailAddresses(String(item || ""))) {
      fromExplicit.push(addr);
    }
  }
  return [...new Set(fromExplicit)];
}

function normalizeCrmPublicUrl(raw) {
  let s = String(raw || "").trim();
  if (!s) return "";
  if (!/^https?:\/\//i.test(s)) s = `https://${s}`;
  return s.replace(/\/$/, "");
}

function getRequestHostname(req) {
  if (!req || typeof req.get !== "function") return "";
  const forwardedHost = String(req.get("x-forwarded-host") || "")
    .split(",")[0]
    ?.trim();
  const host = forwardedHost || String(req.get("host") || "").trim();
  return host.split(":")[0].toLowerCase();
}

function buildPublicUrlTrackingHint(req, crmPublicUrlRaw) {
  const normalized = normalizeCrmPublicUrl(crmPublicUrlRaw);
  if (!normalized) {
    return "Enter the website address for this site so email opens and calls work.";
  }
  try {
    const configuredHost = new URL(normalized).hostname.toLowerCase();
    const requestHost = getRequestHostname(req);
    if (requestHost && configuredHost && configuredHost !== requestHost) {
      return `You are signed in at ${requestHost}. Change this to https://${requestHost}.`;
    }
  } catch {
    return "Enter a full address, like https://crmcadence.com.";
  }
  return "";
}

function getPublicOrigin(req) {
  const configured = normalizeCrmPublicUrl(process.env.CRM_PUBLIC_URL || "");
  if (configured) return configured;
  const forwardedProtoRaw = req && typeof req.get === "function" ? String(req.get("x-forwarded-proto") || "").trim() : "";
  const forwardedHostRaw = req && typeof req.get === "function" ? String(req.get("x-forwarded-host") || "").trim() : "";
  const forwardedProto = forwardedProtoRaw.split(",")[0]?.trim().toLowerCase() || "";
  const forwardedHost = forwardedHostRaw.split(",")[0]?.trim() || "";
  if (forwardedProto && forwardedHost) return `${forwardedProto}://${forwardedHost}`.replace(/\/$/, "");
  const originHeader = req && typeof req.get === "function" ? String(req.get("origin") || "").trim() : "";
  if (/^https?:\/\//i.test(originHeader)) return originHeader.replace(/\/$/, "");
  const refererHeader = req && typeof req.get === "function" ? String(req.get("referer") || "").trim() : "";
  if (/^https?:\/\//i.test(refererHeader)) {
    try {
      const u = new URL(refererHeader);
      return `${u.protocol}//${u.host}`.replace(/\/$/, "");
    } catch {
      // ignore malformed referer
    }
  }
  const host = req && typeof req.get === "function" ? String(req.get("host") || "").trim() : "";
  if (req && req.protocol && host) return `${req.protocol}://${host}`.replace(/\/$/, "");
  return "http://localhost:3000";
}

function buildEmailOpenPixelUrl(req, token) {
  return `${getPublicOrigin(req)}/api/email/open/${encodeURIComponent(String(token || "").trim())}`;
}

function isLocalhostLikeUrl(urlValue) {
  const s = String(urlValue || "").trim();
  if (!s) return false;
  try {
    const u = new URL(s);
    const host = String(u.hostname || "").trim().toLowerCase();
    return host === "localhost" || host === "127.0.0.1" || host === "::1";
  } catch {
    return false;
  }
}

function getEmailOpenMinAgeSeconds() {
  const raw = Number(process.env.EMAIL_OPEN_MIN_AGE_SECONDS);
  if (Number.isFinite(raw) && raw >= 0) return Math.floor(raw);
  // Filter near-instant automated fetches (scanner bots fetch within 1–2 s).
  // 5 s is short enough to allow Gmail's image proxy (which fetches 5–60 s after
  // delivery) to count as a real open. Override with EMAIL_OPEN_MIN_AGE_SECONDS=0
  // to accept all fetches, or a higher value to be more conservative.
  return 5;
}

function shouldIgnoreEarlyEmailOpen(row, nowUnix) {
  const minAge = getEmailOpenMinAgeSeconds();
  if (minAge <= 0) return false;
  const createdAt = Number(row?.created_at || 0);
  if (!Number.isFinite(createdAt) || createdAt <= 0) return false;
  return nowUnix - createdAt < minAge;
}

function ensureTrackingPixelHtml(html, pixelUrl) {
  const body = String(html || "").trim();
  const pixel = `<img src="${twilioXmlEscape(pixelUrl)}" alt="" width="1" height="1" style="display:block;width:1px;height:1px;border:0;opacity:0;" />`;
  if (!body) return pixel;
  if (/<\/body>/i.test(body)) {
    return body.replace(/<\/body>/i, `${pixel}</body>`);
  }
  return `${body}${pixel}`;
}

function buildSentEmailHistoryDetail({ from, to, cc, subject, text, html, bccBulk }) {
  const htmlBody = String(html || "").trim();
  const textBody = String(text || "").trim();
  const payload = {
    v: 1,
    type: "sent_email",
    from: String(from || "").trim() || "(default sender)",
    to: String(to || "").trim() || "-",
    cc: String(cc || "").trim() || "-",
    subject: String(subject || "").trim() || "(no subject)",
    html: htmlBody || "",
    text: textBody || ""
  };
  if (bccBulk && bccBulk.used) {
    payload.bccBulk = true;
    payload.smtpVisibleTo = String(bccBulk.envelopeTo || "").trim();
    payload.bccRecipients = String(bccBulk.bccRecipients || "").trim();
  }
  return `EMAIL_JSON:${JSON.stringify(payload)}`;
}

async function recordCallStarted({ contactId, phone, callSid, record }) {
  const to = String(phone || "").trim();
  const detail = record ? buildCallWithRecordingDetail({ status: "pending" }) : "Started call";
  if (contactId) {
    const id = Number(contactId);
    if (Number.isInteger(id) && id > 0) {
      await run(`UPDATE contacts SET last_called = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [id]);
      await logContactActivity(id, "call", detail);
    }
  } else if (to) {
    await run(
      `UPDATE contacts SET last_called = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
       WHERE phone = ? OR secondary_phone = ?`,
      [to, to]
    );
    const byPhone = await all(`SELECT id FROM contacts WHERE phone = ? OR secondary_phone = ? LIMIT 10`, [to, to]);
    for (const c of byPhone) {
      await logContactActivity(c.id, "call", detail);
    }
  }
  if (record && callSid) {
    await trackCallRecordingPending(run, {
      callSid,
      contactId,
      phone: to
    });
  }
}

async function resolveShouldRecordCall(req, body) {
  const defaultOn = await getCallRecordingDefault(get);
  return parseRecordCallFlag(body?.recordCall, defaultOn);
}

const FOLLOW_UP_REMINDER_VALUES = new Set(["none", "day_of", "day_before", "three_days_before", "week_before"]);

function normalizeFollowUpReminder(raw) {
  const v = String(raw || "")
    .trim()
    .toLowerCase()
    .replace(/-/g, "_");
  if (FOLLOW_UP_REMINDER_VALUES.has(v)) return v;
  return "none";
}

function prettyFieldName(field) {
  const f = String(field || "").trim();
  if (f === "app_id") return "Policy Number";
  if (f === "commission") return "Estimated Commission";
  if (f === "follow_up_date") return "Follow Up Date";
  if (f === "follow_up_time") return "Follow Up Time";
  if (f === "follow_up_reminder") return "Follow Up Reminder";
  if (f === "special_notes") return "Special Notes";
  if (f === "household_members") return "Household";
  if (f === "quotes") return "Quotes";
  return f
    .replace(/_/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

const HOUSEHOLD_RELATIONSHIPS = new Set(["Spouse", "Child", "Domestic Partner", "Parent", "Other"]);
const CONTACT_QUOTE_STATUSES = new Set(["Quoted", "Presented", "Chosen", "Declined"]);

function parseJsonArrayField(raw) {
  if (Array.isArray(raw)) return raw;
  const text = String(raw == null ? "" : raw).trim();
  if (!text) return [];
  try {
    const parsed = JSON.parse(text);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function sanitizeIsoDateField(raw) {
  const value = String(raw == null ? "" : raw).trim();
  return /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : "";
}

function formatStoredQuotePremium(raw) {
  const value = String(raw == null ? "" : raw).trim().slice(0, 40);
  if (!value) return "";
  return value.startsWith("$") ? value : `$${value}`;
}

function normalizeHouseholdMembers(raw) {
  return parseJsonArrayField(raw)
    .slice(0, 20)
    .map((item, index) => {
      const relationship = String(item?.relationship || "").trim();
      const gender = String(item?.gender || "").trim();
      const tobacco = String(item?.tobacco || "").trim();
      return {
        id: String(item?.id || `hm_${index + 1}`).trim().slice(0, 80),
        relationship: HOUSEHOLD_RELATIONSHIPS.has(relationship) ? relationship : "Other",
        first_name: String(item?.first_name || "").trim().slice(0, 80),
        middle_name: String(item?.middle_name || "").trim().slice(0, 80),
        last_name: String(item?.last_name || "").trim().slice(0, 80),
        date_of_birth: sanitizeIsoDateField(item?.date_of_birth),
        gender: gender === "Male" || gender === "Female" ? gender : "",
        tobacco: tobacco === "Yes" || tobacco === "No" ? tobacco : ""
      };
    })
    .filter((member) => member.first_name || member.middle_name || member.last_name || member.date_of_birth);
}

function normalizeContactQuotes(raw) {
  const quotes = parseJsonArrayField(raw)
    .slice(0, 30)
    .map((item, index) => {
      const status = String(item?.status || "").trim();
      const currentRaw = item?.current;
      return {
        id: String(item?.id || `qt_${index + 1}`).trim().slice(0, 80),
        carrier: String(item?.carrier || "").trim().slice(0, 80),
        plan_name: String(item?.plan_name || "").trim().slice(0, 120),
        premium: formatStoredQuotePremium(item?.premium),
        quoted_at: sanitizeIsoDateField(item?.quoted_at),
        status: CONTACT_QUOTE_STATUSES.has(status) ? status : "Quoted",
        notes: String(item?.notes || "").trim().slice(0, 500),
        current: currentRaw === true || currentRaw === 1 || String(currentRaw || "") === "1"
      };
    })
    .filter((quote) => quote.carrier || quote.plan_name || quote.premium);
  let foundCurrent = false;
  return quotes.map((quote) => {
    if (quote.current && !foundCurrent) {
      foundCurrent = true;
      return quote;
    }
    return { ...quote, current: false };
  });
}

function currentQuotePremium(quotes) {
  const current = (Array.isArray(quotes) ? quotes : []).find((quote) => quote.current);
  return current ? String(current.premium || "").trim() : "";
}

function withContactJsonFields(contact) {
  if (!contact) return contact;
  return {
    ...contact,
    household_members: normalizeHouseholdMembers(contact.household_members),
    quotes: normalizeContactQuotes(contact.quotes)
  };
}

const TASK_ACTION_VALUES = new Set(["Call", "Text", "Email", "Other"]);
const TASK_CONDITION_VALUES = new Set(["Yet to Start", "In Progress", "Completed"]);

function normalizeTaskAction(raw) {
  const value = String(raw || "").trim();
  return TASK_ACTION_VALUES.has(value) ? value : "Other";
}

function normalizeTaskCondition(raw) {
  const value = String(raw || "").trim();
  return TASK_CONDITION_VALUES.has(value) ? value : "Yet to Start";
}

/** Multi-status IN / NOT IN filter — used by the Leads and Clients tab views. */
function contactsMultiStatusClause(statusInRaw, statusNotInRaw) {
  const parseList = (raw) =>
    String(raw || "").split(",").map((s) => s.trim().toLowerCase()).filter(Boolean);
  const inList = parseList(statusInRaw);
  const notInList = parseList(statusNotInRaw);
  if (inList.length > 0) {
    const placeholders = inList.map(() => "?").join(",");
    return {
      sql: ` AND LOWER(TRIM(COALESCE(status,''))) IN (${placeholders})`,
      params: inList
    };
  }
  if (notInList.length > 0) {
    const placeholders = notInList.map(() => "?").join(",");
    return {
      sql: ` AND LOWER(TRIM(COALESCE(status,''))) NOT IN (${placeholders})`,
      params: notInList
    };
  }
  return { sql: "", params: [] };
}

/**
 * Contacts view segment — Clients tab: status=SOLD OR tag contains "SOLD".
 * Leads tab: NOT (status=SOLD OR tag contains "SOLD").
 * Uses comma-delimited tag boundary matching to avoid false matches like "Unsold".
 */
function contactsViewSegmentClause(viewRaw) {
  const view = String(viewRaw || "").trim().toLowerCase();
  if (!view || view === "all") return { sql: "", params: [] };
  const soldSql = `(
    LOWER(TRIM(COALESCE(status,''))) = 'sold'
    OR LOWER(TRIM(COALESCE(status,''))) = 'approved'
    OR (',' || LOWER(COALESCE(tags,'')) || ',') LIKE '%,sold,%'
  )`;
  const notDeclinedSql = `LOWER(TRIM(COALESCE(status,''))) != 'declined'`;
  if (view === "clients") return { sql: ` AND ${soldSql} AND ${notDeclinedSql}`, params: [] };
  if (view === "leads")   return { sql: ` AND NOT ${soldSql}`, params: [] };
  return { sql: "", params: [] };
}

/** Extra WHERE fragment for Contacts list segment (view) filter from dropdown. */
function contactsSegmentClause(segmentRaw) {
  const segment = String(segmentRaw || "").trim();
  if (!segment) return { sql: "", params: [] };
  if (segment === "drip") {
    return { sql: " AND id IN (SELECT contact_id FROM drip_enrollments)", params: [] };
  }
  return {
    sql: ` AND (
      LOWER(TRIM(COALESCE(status,''))) = LOWER(?)
      OR LOWER(TRIM(COALESCE(outcome,''))) = LOWER(?)
      OR LOWER(COALESCE(tags,'')) LIKE '%' || LOWER(?) || '%'
      OR LOWER(COALESCE(notes,'')) LIKE '%' || LOWER(?) || '%'
      OR LOWER(COALESCE(special_notes,'')) LIKE '%' || LOWER(?) || '%'
    )`,
    params: [segment, segment, segment, segment, segment]
  };
}

/** Tags Filter (IS / IS NOT / IS NOT DEFINED) — optional WHERE fragment for list + export. */
function contactsTagFilterClause(tagFilterRaw, tagTermRaw) {
  const mode = String(tagFilterRaw || "").trim().toLowerCase();
  const term = String(tagTermRaw || "").trim();
  if (mode === "all" || mode === "") {
    return { sql: "", params: [] };
  }
  if (mode === "not-defined") {
    return { sql: " AND (tags IS NULL OR TRIM(COALESCE(tags,'')) = '')", params: [] };
  }
  if ((mode === "is" || mode === "is-not") && term) {
    const like = `%${term}%`;
    if (mode === "is") {
      return { sql: " AND LOWER(COALESCE(tags,'')) LIKE ?", params: [like.toLowerCase()] };
    }
    return { sql: " AND NOT (LOWER(COALESCE(tags,'')) LIKE ?)", params: [like.toLowerCase()] };
  }
  return { sql: "", params: [] };
}

/** Normalize status/outcome labels for dropdown filter matching (Call Back ↔ Callback). */
function normalizeContactLabelForMatch(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[\s-]+/g, "");
}

/** Exact dropdown filter for status/outcome — case-insensitive and spacing/hyphen tolerant. */
function contactsDropdownFieldFilterClause(column, valueRaw) {
  const safeColumn =
    column === "status" ? "status" : column === "outcome" ? "outcome" : "";
  const value = String(valueRaw || "").trim();
  if (!safeColumn || !value) return { sql: "", params: [] };
  const normalized = normalizeContactLabelForMatch(value);
  const colExpr = `COALESCE(${safeColumn},'')`;
  return {
    sql: ` AND (
      LOWER(TRIM(${colExpr})) = LOWER(?)
      OR LOWER(REPLACE(REPLACE(TRIM(${colExpr}), '-', ''), ' ', '')) = ?
    )`,
    params: [value, normalized]
  };
}

/** Label filters for status/outcome and other text contact columns (IS / IS NOT / IS NOT DEFINED). */
const QUICK_FILTER_LABEL_COLUMNS = new Set([
  "status",
  "outcome",
  "lead_source",
  "indian",
  "state",
  "gender",
  "city",
  "zip_code",
  "email",
  "profession",
  "communication_type",
  "app_id",
  "income",
  "quote",
  "commission",
  "age",
  "household_size",
  "insurance_type"
]);

function contactsLabelFilterClause(column, modeRaw, termRaw) {
  const mode = String(modeRaw || "").trim().toLowerCase();
  const term = String(termRaw || "").trim().toLowerCase();
  const safeColumn = QUICK_FILTER_LABEL_COLUMNS.has(column) ? column : "";
  if (!safeColumn || mode === "" || mode === "all") return { sql: "", params: [] };
  if (mode === "not-defined") {
    return { sql: ` AND TRIM(COALESCE(${safeColumn},'')) = ''`, params: [] };
  }
  if ((mode === "is" || mode === "is-not") && term) {
    if (mode === "is") {
      return {
        sql: ` AND LOWER(TRIM(COALESCE(${safeColumn},''))) LIKE ?`,
        params: [`%${term}%`]
      };
    }
    return {
      sql: ` AND NOT (LOWER(TRIM(COALESCE(${safeColumn},''))) LIKE ?)`,
      params: [`%${term}%`]
    };
  }
  return { sql: "", params: [] };
}

function contactsGenericQuickFilterClause(fieldRaw, modeRaw, termRaw) {
  const field = String(fieldRaw || "").trim();
  if (field === "tags") return contactsTagFilterClause(modeRaw, termRaw);
  return contactsLabelFilterClause(field, modeRaw, termRaw);
}

function contactsHeaderTagClause(tagsRaw) {
  const term = String(tagsRaw || "").trim();
  if (!term) return { sql: "", params: [] };
  return { sql: " AND LOWER(COALESCE(tags,'')) LIKE ?", params: [`%${term.toLowerCase()}%`] };
}

function parseContactFilterDate(raw) {
  const s = String(raw || "").trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  const us = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (us) {
    const month = String(us[1]).padStart(2, "0");
    const day = String(us[2]).padStart(2, "0");
    return `${us[3]}-${month}-${day}`;
  }
  const iso = s.match(/^(\d{4}-\d{2}-\d{2})[T\s]/);
  if (iso) return iso[1];
  return "";
}

function contactsCreatedRangeClause(createdFromRaw, createdToRaw) {
  const createdFrom = parseContactFilterDate(createdFromRaw);
  const createdTo = parseContactFilterDate(createdToRaw);
  const parts = [];
  const params = [];
  if (createdFrom) {
    parts.push("datetime(created_at) >= datetime(?, 'start of day')");
    params.push(createdFrom);
  }
  if (createdTo) {
    parts.push("datetime(created_at) < datetime(?, 'start of day', '+1 day')");
    params.push(createdTo);
  }
  if (!parts.length) return { sql: "", params: [] };
  return { sql: ` AND ${parts.join(" AND ")}`, params };
}

function contactsSoldOutcomeChangeSql(detailExpr = "ca.detail") {
  const normalized = `TRIM(LOWER(REPLACE(REPLACE(COALESCE(${detailExpr}, ''), '→', ' -> '), '➞', ' -> ')))`;
  return `(
    ${normalized} LIKE 'outcome:%'
    AND (
      ${normalized} LIKE '% -> sold'
      OR ${normalized} LIKE '% -> sold %'
      OR ${normalized} LIKE '% -> closedsold'
      OR ${normalized} LIKE '%->sold'
      OR ${normalized} LIKE '%->sold %'
    )
  )`;
}

function contactsCurrentlySoldPredicate(idColumn = "contacts.id") {
  const prefix = String(idColumn).includes(".")
    ? String(idColumn).replace(/\.id$/i, ".")
    : "";
  const outcome = `LOWER(REPLACE(REPLACE(TRIM(COALESCE(${prefix}outcome,'')), '-', ''), ' ', ''))`;
  return `${outcome} IN ('sold', 'closedsold')`;
}

function contactsSoldAtExpr(idColumn = "contacts.id", useSoldAtColumn = true) {
  const prefix = String(idColumn).includes(".")
    ? String(idColumn).replace(/\.id$/i, ".")
    : "";
  const idRef = String(idColumn).includes(".") ? String(idColumn) : "id";
  const activityMax = `(
    SELECT MAX(ca.created_at)
    FROM contact_activity ca
    WHERE ca.contact_id = ${idRef}
      AND LOWER(COALESCE(ca.activity_type, '')) = 'detail_change'
      AND ${contactsSoldOutcomeChangeSql("ca.detail")}
  )`;
  if (!useSoldAtColumn) return activityMax;
  return `COALESCE(NULLIF(TRIM(COALESCE(${prefix}outcome_sold_at, '')), ''), ${activityMax})`;
}

function contactsSoldRangeClause(soldFromRaw, soldToRaw, idColumn = "contacts.id", useSoldAtColumn = true) {
  const soldFrom = parseContactFilterDate(soldFromRaw);
  const soldTo = parseContactFilterDate(soldToRaw);
  const soldAt = contactsSoldAtExpr(idColumn, useSoldAtColumn);
  const parts = [];
  const params = [];
  if (soldFrom) {
    parts.push(`datetime(${soldAt}) >= datetime(?, 'start of day')`);
    params.push(soldFrom);
  }
  if (soldTo) {
    parts.push(`datetime(${soldAt}) < datetime(?, 'start of day', '+1 day')`);
    params.push(soldTo);
  }
  if (!parts.length) return { sql: "", params: [] };
  return {
    sql: ` AND ${contactsCurrentlySoldPredicate(idColumn)} AND ${parts.join(" AND ")}`,
    params
  };
}

function contactsCurrentlyClosedPredicate(idColumn = "contacts.id") {
  const prefix = String(idColumn).includes(".")
    ? String(idColumn).replace(/\.id$/i, ".")
    : "";
  const status = `LOWER(REPLACE(REPLACE(TRIM(COALESCE(${prefix}status,'')), '-', ''), ' ', ''))`;
  return `${status} = 'closed'`;
}

function contactsClosedStatusChangeSql(detailExpr = "ca.detail") {
  const normalized = `TRIM(LOWER(REPLACE(REPLACE(COALESCE(${detailExpr}, ''), '→', ' -> '), '➞', ' -> ')))`;
  return `(
    ${normalized} LIKE 'status:%'
    AND (
      ${normalized} LIKE '% -> closed'
      OR ${normalized} LIKE '% -> closed %'
      OR ${normalized} LIKE '%->closed'
      OR ${normalized} LIKE '%->closed %'
    )
    AND ${normalized} NOT LIKE '%closedsold%'
  )`;
}

function contactsClosedAtExpr(idColumn = "contacts.id") {
  const idRef = String(idColumn).includes(".") ? String(idColumn) : "id";
  return `(
    SELECT MAX(ca.created_at)
    FROM contact_activity ca
    WHERE ca.contact_id = ${idRef}
      AND LOWER(COALESCE(ca.activity_type, '')) = 'detail_change'
      AND ${contactsClosedStatusChangeSql("ca.detail")}
  )`;
}

function contactsClosedRangeClause(closedFromRaw, closedToRaw, idColumn = "contacts.id") {
  const closedFrom = parseContactFilterDate(closedFromRaw);
  const closedTo = parseContactFilterDate(closedToRaw);
  const closedAt = contactsClosedAtExpr(idColumn);
  const parts = [];
  const params = [];
  if (closedFrom) {
    parts.push(`datetime(${closedAt}) >= datetime(?, 'start of day')`);
    params.push(closedFrom);
  }
  if (closedTo) {
    parts.push(`datetime(${closedAt}) < datetime(?, 'start of day', '+1 day')`);
    params.push(closedTo);
  }
  if (!parts.length) return { sql: "", params: [] };
  return {
    sql: ` AND ${contactsCurrentlyClosedPredicate(idColumn)} AND ${parts.join(" AND ")}`,
    params
  };
}

function contactsDateFilterFragments({
  createdFrom = "",
  createdTo = "",
  soldFrom = "",
  soldTo = "",
  closedFrom = "",
  closedTo = "",
  dateRangeType = "",
  soldIdColumn = "contacts.id",
  useSoldAtColumn = true
}) {
  const rangeType = String(dateRangeType || "").trim().toLowerCase();
  const soldType = rangeType === "sold";
  const closedType = rangeType === "closed";
  const soldRangeFrag = contactsSoldRangeClause(
    soldFrom || (soldType ? createdFrom : ""),
    soldTo || (soldType ? createdTo : ""),
    soldIdColumn,
    useSoldAtColumn
  );
  const closedRangeFrag = contactsClosedRangeClause(
    closedFrom || (closedType ? createdFrom : ""),
    closedTo || (closedType ? createdTo : ""),
    soldIdColumn
  );
  if (soldType && (soldFrom || soldTo || createdFrom || createdTo) && !soldRangeFrag.sql) {
    return {
      createdRangeFrag: { sql: "", params: [] },
      soldRangeFrag: { sql: " AND 1=0", params: [] },
      closedRangeFrag: { sql: "", params: [] }
    };
  }
  if (closedType && (closedFrom || closedTo || createdFrom || createdTo) && !closedRangeFrag.sql) {
    return {
      createdRangeFrag: { sql: "", params: [] },
      soldRangeFrag: { sql: "", params: [] },
      closedRangeFrag: { sql: " AND 1=0", params: [] }
    };
  }
  const createdRangeFrag =
    soldRangeFrag.sql || closedRangeFrag.sql
      ? { sql: "", params: [] }
      : contactsCreatedRangeClause(createdFrom, createdTo);
  return { createdRangeFrag, soldRangeFrag, closedRangeFrag };
}

/** Yes → No → blank when sorting/filtering by Indian. */
function contactsIndianYesFirstRankSql(columnExpr = "contacts.indian") {
  const col = `LOWER(TRIM(COALESCE(${columnExpr},'')))`;
  return `CASE
    WHEN ${col} IN ('yes', 'y', '1', 'true') THEN 0
    WHEN ${col} IN ('no', 'n', '0', 'false') THEN 1
    ELSE 2
  END`;
}

function contactsIndianFilterIsActive(indianModeRaw) {
  const mode = String(indianModeRaw || "").trim().toLowerCase();
  return mode !== "" && mode !== "all";
}

function buildContactsListOrderBy({
  sortBy,
  sortOrder,
  indianMode,
  indianSortFirst,
  idColumn = "contacts.id",
  indianColumn = "contacts.indian",
  useSoldAtColumn = true
}) {
  const sortColumnMap = {
    created_at: `datetime(CASE
      WHEN application_submitted_at IS NOT NULL
           AND TRIM(application_submitted_at) != ''
           AND datetime(application_submitted_at) > datetime(COALESCE(created_at, '1970-01-01'))
      THEN application_submitted_at
      ELSE created_at
    END)`,
    updated_at: "datetime(updated_at)",
    full_name: "LOWER(TRIM(COALESCE(full_name,'')))",
    status: "LOWER(TRIM(COALESCE(status,'')))",
    outcome: "LOWER(TRIM(COALESCE(outcome,'')))",
    gender: "LOWER(TRIM(COALESCE(gender,'')))",
    age: "CAST(NULLIF(age, '') AS REAL)",
    household_size: "CAST(NULLIF(household_size, '') AS REAL)",
    quote: "CAST(NULLIF(quote, '') AS REAL)",
    commission:
      "CAST(NULLIF(REPLACE(REPLACE(TRIM(COALESCE(commission,'')),'$',''),',',''),'') AS REAL)",
    last_called: "datetime(last_called)",
    last_emailed: "datetime(last_emailed)",
    last_sms: "datetime(last_sms)",
    last_tagged: "datetime(last_tagged)",
    state: "LOWER(TRIM(COALESCE(state,'')))",
    lead_source: "LOWER(TRIM(COALESCE(lead_source,'')))",
    ai_lead_score: "CAST(NULLIF(ai_lead_score, '') AS REAL)",
    indian: "LOWER(TRIM(COALESCE(indian,'')))",
    profession: "LOWER(TRIM(COALESCE(profession,'')))",
    income:
      "CAST(NULLIF(REPLACE(REPLACE(TRIM(COALESCE(income,'')),'$',''),',',''),'') AS REAL)",
    date_of_contact: "datetime(date_of_contact)",
    date_of_birth: "datetime(date_of_birth)",
    coverage_start_date: "datetime(coverage_start_date)",
    insurance_type: "LOWER(TRIM(COALESCE(insurance_type,'')))",
    email: "LOWER(TRIM(COALESCE(email,'')))",
    city: "LOWER(TRIM(COALESCE(city,'')))",
    zip_code: "LOWER(TRIM(COALESCE(zip_code,'')))",
    communication_type: "LOWER(TRIM(COALESCE(communication_type,'')))",
    app_id: "LOWER(TRIM(COALESCE(app_id,'')))",
    tags: "LOWER(TRIM(COALESCE(tags,'')))",
    outcome_sold_at: `datetime(${contactsSoldAtExpr(idColumn, useSoldAtColumn)})`
  };
  const orderDirection = String(sortOrder).toLowerCase() === "asc" ? "ASC" : "DESC";
  const sortByKey = String(sortBy);
  const rankSql = contactsIndianYesFirstRankSql(indianColumn);
  const wantIndianFirst =
    contactsIndianFilterIsActive(indianMode) ||
    String(indianSortFirst || "").trim() === "1" ||
    sortByKey === "indian";
  const segments = [];
  if (wantIndianFirst) {
    const rankDir = sortByKey === "indian" && orderDirection === "DESC" ? "DESC" : "ASC";
    segments.push(`${rankSql} ${rankDir}`);
  }
  if (sortByKey !== "indian") {
    const orderColumn = sortColumnMap[sortByKey] || sortColumnMap.created_at;
    segments.push(`${orderColumn} ${orderDirection}`);
  }
  segments.push(`${idColumn} ASC`);
  return segments.join(", ");
}

/** Highest 1-based rank accepted by the contact count window. Matches the Select All id cap. */
const CONTACT_COUNT_RANK_CAP = 100000;

function parseContactCountBound(raw) {
  const text = String(raw ?? "").trim();
  if (!/^[1-9]\d*$/.test(text)) return null;
  const n = Number(text);
  if (!Number.isSafeInteger(n) || n < 1) return null;
  return Math.min(n, CONTACT_COUNT_RANK_CAP);
}

/**
 * Inclusive 1-based ranks on the already filtered, already sorted contact list.
 * "Last 100" is from 1 through 100 (the first 100 in the current sort).
 * "200 through 300" keeps both ends. Returns null when no count filter was sent.
 * offset/limit are the SQL window; size is how many contacts fall inside it.
 */
function contactCountWindow(countFromRaw, countToRaw, total) {
  let from = parseContactCountBound(countFromRaw);
  let to = parseContactCountBound(countToRaw);
  if (from == null && to == null) return null;
  const safeTotal = Math.max(0, Number(total) || 0);
  if (from == null) from = 1;
  if (to == null) to = Math.min(safeTotal, CONTACT_COUNT_RANK_CAP);
  if (from > to) {
    const swap = from;
    from = to;
    to = swap;
  }
  if (from > safeTotal) return { offset: safeTotal, limit: 0, size: 0 };
  const end = Math.min(to, safeTotal);
  return { offset: from - 1, limit: Math.max(0, end - from + 1), size: Math.max(0, end - from + 1) };
}

function countWindowMeta(countWindow, matchedTotal) {
  if (!countWindow) return { countApplied: false, matchedTotal };
  const size = Number(countWindow.size || 0);
  return {
    countApplied: true,
    matchedTotal,
    countFrom: size > 0 ? countWindow.offset + 1 : null,
    countTo: size > 0 ? countWindow.offset + size : null
  };
}

function contactsListQueryParams(req) {
  const query = req.query && typeof req.query === "object" ? req.query : {};
  const body = req.body && typeof req.body === "object" && !Array.isArray(req.body) ? req.body : {};
  if (req.method === "POST") return { ...query, ...body };
  return query;
}

async function handleContactsList(req, res) {
  try {
    const {
      q = "",
      searchBy = "all",
      status = "",
      outcome = "",
      segment = "",
      tagFilter = "",
      tagTerm = "",
      statusLabelMode = "",
      statusLabelTerm = "",
      outcomeLabelMode = "",
      outcomeLabelTerm = "",
      leadSourceMode = "",
      leadSourceTerm = "",
      indianMode = "",
      indianTerm = "",
      indianSortFirst = "",
      qfField = "",
      qfMode = "",
      qfTerm = "",
      tags = "",
      createdFrom = "",
      createdTo = "",
      soldFrom = "",
      soldTo = "",
      closedFrom = "",
      closedTo = "",
      dateRangeType = "",
      contactState = "",
      contactIds = "",
      minLeadScore = "",
      hotLeads = "",
      statusIn = "",
      statusNotIn = "",
      contactViewSegment = "",
      sortBy = "created_at",
      sortOrder = "desc",
      page = "",
      limit = "",
      idsOnly = "",
      countFrom = "",
      countTo = ""
    } = contactsListQueryParams(req);
    const wantIdsOnly =
      idsOnly === "1" ||
      idsOnly === 1 ||
      idsOnly === true ||
      String(idsOnly || "").trim().toLowerCase() === "true";
    const filterState = String(contactState || "").trim();
    const like = `%${q}%`;
    const orderBy = buildContactsListOrderBy({
      sortBy,
      sortOrder,
      indianMode,
      indianSortFirst,
      useSoldAtColumn: !req._soldAtColumnDisabled
    });
    const normalizedSearchBy = String(searchBy || "all").toLowerCase();
    let searchClause =
      "(full_name LIKE ? OR email LIKE ? OR phone LIKE ? OR COALESCE(notes,'') LIKE ? OR COALESCE(special_notes,'') LIKE ?)";
    let searchParams = [like, like, like, like, like];
    if (normalizedSearchBy === "name") {
      searchClause = "full_name LIKE ?";
      searchParams = [like];
    } else if (normalizedSearchBy === "phone") {
      searchClause = "phone LIKE ? OR secondary_phone LIKE ?";
      searchParams = [like, like];
    } else if (normalizedSearchBy === "email") {
      searchClause = "email LIKE ?";
      searchParams = [like];
    }
    const seg = contactsSegmentClause(segment);
    const tagFrag = contactsTagFilterClause(tagFilter, tagTerm);
    const statusFilterFrag = contactsDropdownFieldFilterClause("status", status);
    const outcomeFilterFrag = contactsDropdownFieldFilterClause("outcome", outcome);
    const statusLabelFrag = contactsLabelFilterClause("status", statusLabelMode, statusLabelTerm);
    const outcomeLabelFrag = contactsLabelFilterClause("outcome", outcomeLabelMode, outcomeLabelTerm);
    const leadSourceFrag = contactsLabelFilterClause("lead_source", leadSourceMode, leadSourceTerm);
    const indianFrag = contactsLabelFilterClause("indian", indianMode, indianTerm);
    const genericQuickFilterFrag = contactsGenericQuickFilterClause(qfField, qfMode, qfTerm);
    const headerTagFrag = contactsHeaderTagClause(tags);
    const { createdRangeFrag, soldRangeFrag, closedRangeFrag } = contactsDateFilterFragments({
      createdFrom,
      createdTo,
      soldFrom,
      soldTo,
      closedFrom,
      closedTo,
      dateRangeType,
      soldIdColumn: "contacts.id",
      useSoldAtColumn: !req._soldAtColumnDisabled
    });
    const multiStatusFrag = contactsMultiStatusClause(statusIn, statusNotIn);
    const viewSegmentFrag = contactsViewSegmentClause(contactViewSegment);
    const contactIdsFilter = parseContactIds(contactIds);
    const contactIdsClause = contactIdsFilter.length
      ? ` AND contacts.id IN (${contactIdsFilter.map(() => "?").join(",")})`
      : "";
    const minLeadScoreNum = Number(hotLeads === "1" ? 8 : minLeadScore);
    const leadScoreClause =
      Number.isFinite(minLeadScoreNum) && minLeadScoreNum > 0
        ? " AND CAST(NULLIF(ai_lead_score, '') AS REAL) >= ?"
        : "";
    const baseWhere = `FROM contacts
       WHERE (${searchClause})
       ${statusFilterFrag.sql}
       ${outcomeFilterFrag.sql}
       ${seg.sql}
       ${tagFrag.sql}
       ${statusLabelFrag.sql}
       ${outcomeLabelFrag.sql}
       ${leadSourceFrag.sql}
       ${indianFrag.sql}
       ${genericQuickFilterFrag.sql}
       ${headerTagFrag.sql}
       ${createdRangeFrag.sql}
       ${soldRangeFrag.sql}
       ${closedRangeFrag.sql}
       ${multiStatusFrag.sql}
       ${viewSegmentFrag.sql}
       ${contactIdsClause}
       ${leadScoreClause}
       AND (? = '' OR LOWER(TRIM(COALESCE(state,''))) = LOWER(TRIM(?)))`;
    const params = [
      ...searchParams,
      ...statusFilterFrag.params,
      ...outcomeFilterFrag.params,
      ...seg.params,
      ...tagFrag.params,
      ...statusLabelFrag.params,
      ...outcomeLabelFrag.params,
      ...leadSourceFrag.params,
      ...indianFrag.params,
      ...genericQuickFilterFrag.params,
      ...headerTagFrag.params,
      ...createdRangeFrag.params,
      ...soldRangeFrag.params,
      ...closedRangeFrag.params,
      ...multiStatusFrag.params,
      ...viewSegmentFrag.params,
      ...contactIdsFilter,
      ...(leadScoreClause ? [Math.max(1, Math.min(10, minLeadScoreNum))] : []),
      filterState,
      filterState
    ];

    const parsedPage = Number(page);
    const parsedLimit = Number(limit);
    const usePagination = Number.isInteger(parsedPage) && parsedPage > 0;

    if (usePagination) {
      const maxLimit = wantIdsOnly ? 10000 : 200;
      const safeLimit = Number.isInteger(parsedLimit) && parsedLimit > 0 ? Math.min(parsedLimit, maxLimit) : 25;
      const offset = (parsedPage - 1) * safeLimit;
      const totalRow = await get(`SELECT COUNT(*) AS total ${baseWhere}`, params);
      const matchedTotal = totalRow ? Number(totalRow.total || 0) : 0;
      const countWindow = contactCountWindow(countFrom, countTo, matchedTotal);
      const visibleTotal = countWindow ? countWindow.size : matchedTotal;
      const pageSlice = (pageOffset, pageSize) => {
        if (!countWindow) return { limit: pageSize, offset: pageOffset };
        const remain = Math.max(0, countWindow.limit - pageOffset);
        return { limit: Math.min(pageSize, remain), offset: countWindow.offset + pageOffset };
      };
      if (wantIdsOnly) {
        // One-shot path: return every matching id (capped) so Select All does not page 31k rows.
        if (
          parsedPage === 1 &&
          (parsedLimit <= 0 ||
            parsedLimit >= 5000 ||
            String(req.query?.allIds || req.body?.allIds || "") === "1")
        ) {
          const idLimit = countWindow ? countWindow.limit : 100000;
          const idOffset = countWindow ? countWindow.offset : 0;
          const idRows =
            idLimit > 0
              ? await all(
                  `SELECT contacts.id ${baseWhere}
                   ORDER BY ${orderBy}
                   LIMIT ? OFFSET ?`,
                  [...params, idLimit, idOffset]
                )
              : [];
          const items = Array.isArray(idRows) ? idRows.map((r) => ({ id: Number(r.id) })) : [];
          return res.json({
            items,
            total: visibleTotal,
            page: 1,
            limit: items.length,
            idsOnly: true,
            ...countWindowMeta(countWindow, matchedTotal)
          });
        }
        const idSlice = pageSlice(offset, safeLimit);
        const idRows =
          idSlice.limit > 0
            ? await all(
                `SELECT contacts.id ${baseWhere}
                 ORDER BY ${orderBy}
                 LIMIT ? OFFSET ?`,
                [...params, idSlice.limit, idSlice.offset]
              )
            : [];
        return res.json({
          items: Array.isArray(idRows) ? idRows.map((r) => ({ id: Number(r.id) })) : [],
          total: visibleTotal,
          page: parsedPage,
          limit: safeLimit,
          idsOnly: true,
          ...countWindowMeta(countWindow, matchedTotal)
        });
      }
      const listSlice = pageSlice(offset, safeLimit);
      const items = await all(
        `SELECT
           contacts.*,
           (
             SELECT COUNT(DISTINCT de.campaign_id)
             FROM drip_enrollments de
             WHERE de.contact_id = contacts.id
               AND LOWER(COALESCE(de.status, '')) = 'active'
           ) AS active_campaign_count,
           (
             SELECT COUNT(*)
             FROM drip_send_queue q
             JOIN drip_enrollments e ON e.id = q.enrollment_id
             WHERE e.contact_id = contacts.id
               AND LOWER(COALESCE(e.status, '')) = 'active'
               AND LOWER(COALESCE(q.status, '')) = 'pending'
           ) AS drip_pending_count,
           (
             SELECT COUNT(DISTINCT e.campaign_id)
             FROM drip_enrollments e
             WHERE e.contact_id = contacts.id
               AND LOWER(COALESCE(e.status, '')) = 'cancelled'
               AND EXISTS (SELECT 1 FROM drip_send_queue q WHERE q.enrollment_id = e.id)
               AND NOT EXISTS (
                 SELECT 1
                 FROM drip_send_queue q
                 WHERE q.enrollment_id = e.id
                   AND LOWER(COALESCE(q.status, '')) = 'pending'
               )
           ) AS drip_completed_campaign_count
         ${baseWhere}
         ORDER BY ${orderBy}
         LIMIT ? OFFSET ?`,
        [...params, listSlice.limit, listSlice.offset]
      );
      return res.json({
        items: listSlice.limit > 0 ? items : [],
        total: visibleTotal,
        page: parsedPage,
        limit: safeLimit,
        ...countWindowMeta(countWindow, matchedTotal)
      });
    }

    let listLimitSql = "";
    let listLimitParams = [];
    if (parseContactCountBound(countFrom) != null || parseContactCountBound(countTo) != null) {
      const totalRow = await get(`SELECT COUNT(*) AS total ${baseWhere}`, params);
      const matchedTotal = totalRow ? Number(totalRow.total || 0) : 0;
      const countWindow = contactCountWindow(countFrom, countTo, matchedTotal);
      if (countWindow) {
        listLimitSql = " LIMIT ? OFFSET ?";
        listLimitParams = [countWindow.limit, countWindow.offset];
      }
    }
    const rows = await all(
      `SELECT
         contacts.*,
         (
           SELECT COUNT(DISTINCT de.campaign_id)
           FROM drip_enrollments de
           WHERE de.contact_id = contacts.id
             AND LOWER(COALESCE(de.status, '')) = 'active'
         ) AS active_campaign_count,
         (
           SELECT COUNT(*)
           FROM drip_send_queue q
           JOIN drip_enrollments e ON e.id = q.enrollment_id
           WHERE e.contact_id = contacts.id
             AND LOWER(COALESCE(e.status, '')) = 'active'
             AND LOWER(COALESCE(q.status, '')) = 'pending'
         ) AS drip_pending_count,
         (
           SELECT COUNT(DISTINCT e.campaign_id)
           FROM drip_enrollments e
           WHERE e.contact_id = contacts.id
             AND LOWER(COALESCE(e.status, '')) = 'cancelled'
             AND EXISTS (SELECT 1 FROM drip_send_queue q WHERE q.enrollment_id = e.id)
             AND NOT EXISTS (
               SELECT 1
               FROM drip_send_queue q
               WHERE q.enrollment_id = e.id
                 AND LOWER(COALESCE(q.status, '')) = 'pending'
             )
         ) AS drip_completed_campaign_count
       ${baseWhere}
       ORDER BY ${orderBy}${listLimitSql}`,
      [...params, ...listLimitParams]
    );
    return res.json(rows.map(decryptContactBankFields));
  } catch (error) {
    const missingSoldAt = /no such column: .*outcome_sold_at/i.test(String(error && error.message ? error.message : error));
    if (missingSoldAt && !req._soldAtFilterRetry) {
      req._soldAtFilterRetry = 1;
      try {
        await ensureContactColumns();
      } catch (_) {
        req._soldAtColumnDisabled = true;
      }
      return handleContactsList(req, res);
    }
    if (missingSoldAt && req._soldAtFilterRetry === 1) {
      req._soldAtFilterRetry = 2;
      req._soldAtColumnDisabled = true;
      return handleContactsList(req, res);
    }
    res.status(500).json({ error: error.message });
  }
}

app.get("/api/contacts", handleContactsList);
app.post("/api/contacts/list", handleContactsList);

/** Tab counts: total, leads, clients — must be registered before /api/contacts/:id */
app.get("/api/contacts/tab-counts", async (req, res) => {
  try {
    const session = getAuthSession(req);
    if (!session) return res.status(401).json({ error: "Unauthorized" });
    const soldSql = `(
      LOWER(TRIM(COALESCE(status,''))) = 'sold'
      OR LOWER(TRIM(COALESCE(status,''))) = 'approved'
      OR (',' || LOWER(COALESCE(tags,'')) || ',') LIKE '%,sold,%'
    )`;
    const counts = await withTenantContext(session.tenantId, async () => {
      const [totalRow, clientsRow, leadsRow] = await Promise.all([
        get(`SELECT COUNT(*) AS n FROM contacts`),
        get(`SELECT COUNT(*) AS n FROM contacts WHERE ${soldSql} AND LOWER(TRIM(COALESCE(status,''))) != 'declined'`),
        get(`SELECT COUNT(*) AS n FROM contacts WHERE NOT ${soldSql}`)
      ]);
      return { all: totalRow.n, clients: clientsRow.n, leads: leadsRow.n };
    });
    res.json(counts);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

/** Distinct tags: contacts + saved catalog + drip campaign names/enroll tags. */
app.get("/api/contacts/tags", async (req, res) => {
  try {
    const tags = await collectKnownTags({ get, all, run });
    res.json({ tags });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/** Remember a tag even when it is not on any contact yet. */
app.post("/api/contacts/tags", async (req, res) => {
  try {
    const body = req.body && typeof req.body === "object" ? req.body : {};
    const incoming = [];
    if (Array.isArray(body.tags)) incoming.push(...body.tags);
    if (body.tag != null) incoming.push(body.tag);
    const extra = uniqueTags(incoming);
    if (extra.length) {
      await rememberTags({ get, run }, extra);
    }
    const tags = await collectKnownTags({ get, all, run });
    res.json({ tags });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/contacts/export-csv", handleContactsExportCsv);
app.post("/api/contacts/export-csv", handleContactsExportCsv);

// Recycle bin list — registered before /api/contacts/:id so the word "deleted" isn't read as a contact id.
app.get("/api/contacts/imported-book", async (req, res) => {
  try {
    await maybeCompleteExpiredInitialImportOmit({ get, run, all });
    const [totalRow, taggedCount, untaggedNewCount] = await Promise.all([
      get(`SELECT COUNT(*) AS n FROM contacts`),
      countTaggedInitialImport(get),
      countUntaggedNewContacts(get)
    ]);
    const contactCount = Number(totalRow?.n || 0);
    return res.json({
      contactCount,
      taggedCount,
      untaggedNewCount,
      isEmptyWorkspace: contactCount === 0,
      importedBookActive: taggedCount > 0
    });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Could not load imported book status." });
  }
});

app.post("/api/contacts/imported-book", async (req, res) => {
  try {
    const action = String(req.body?.action || "mark-new").trim().toLowerCase();
    if (action === "clear") {
      await completeInitialImportOmit({ run, all, get });
      return res.json({
        ok: true,
        taggedCount: 0,
        untaggedNewCount: await countUntaggedNewContacts(get),
        contactCount: Number((await get(`SELECT COUNT(*) AS n FROM contacts`))?.n || 0),
        importedBookActive: false
      });
    }
    if (action === "mark-new" || action === "mark") {
      const result = await tagNewContactsAsImportedBook({ run, all, get });
      const contactCount = Number((await get(`SELECT COUNT(*) AS n FROM contacts`))?.n || 0);
      return res.json({
        ok: true,
        newlyTagged: result.newlyTagged,
        taggedCount: result.taggedCount,
        untaggedNewCount: await countUntaggedNewContacts(get),
        contactCount,
        importedBookActive: result.taggedCount > 0
      });
    }
    return res.status(400).json({ error: "Unknown action. Use mark-new or clear." });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Could not update imported book tags." });
  }
});

app.get("/api/contacts/deleted", async (req, res) => {
  try {
    await run(`DELETE FROM deleted_contacts WHERE deleted_at < datetime('now','-30 days')`);
    const rows = await all(
      `SELECT id, original_id, full_name, email, deleted_at
       FROM deleted_contacts
       ORDER BY deleted_at DESC`
    );
    res.json({ items: Array.isArray(rows) ? rows : [] });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Must be registered before /api/contacts/:id so "upcoming-birthdays" is not read as an id.
app.get("/api/contacts/upcoming-birthdays", async (req, res) => {
  try {
    const windowDaysRaw = Number(req.query.days);
    const windowDays =
      Number.isInteger(windowDaysRaw) && windowDaysRaw > 0 ? Math.min(windowDaysRaw, 90) : 30;
    const limitRaw = Number(req.query.limit);
    const limit = Number.isInteger(limitRaw) && limitRaw > 0 ? Math.min(limitRaw, 50) : 20;
    const rows = await all(
      `SELECT id, full_name, date_of_birth
         FROM contacts
        WHERE trim(COALESCE(date_of_birth, '')) != ''`
    );
    const now = new Date();
    const upcoming = [];
    for (const row of Array.isArray(rows) ? rows : []) {
      const parts = parseContactDobParts(row.date_of_birth);
      if (!parts) continue;
      const daysAway = daysUntilNextBirthday(parts, now);
      if (daysAway == null || daysAway < 0 || daysAway > windowDays) continue;
      upcoming.push({
        id: Number(row.id),
        contact_id: Number(row.id),
        full_name: String(row.full_name || "").trim(),
        date_of_birth: String(row.date_of_birth || "").trim(),
        daysAway,
        turningAge: turningAgeOnNextBirthday(parts, now)
      });
    }
    upcoming.sort(
      (a, b) => a.daysAway - b.daysAway || String(a.full_name).localeCompare(String(b.full_name))
    );
    return res.json(upcoming.slice(0, limit));
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/contacts/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid contact id" });
    const contact = await get(
      `SELECT
         contacts.*,
         (
           SELECT COUNT(DISTINCT de.campaign_id)
           FROM drip_enrollments de
           WHERE de.contact_id = contacts.id
             AND LOWER(COALESCE(de.status, '')) = 'active'
         ) AS active_campaign_count,
         (
           SELECT COUNT(*)
           FROM drip_send_queue q
           JOIN drip_enrollments e ON e.id = q.enrollment_id
           WHERE e.contact_id = contacts.id
             AND LOWER(COALESCE(e.status, '')) = 'active'
             AND LOWER(COALESCE(q.status, '')) = 'pending'
         ) AS drip_pending_count,
         (
           SELECT COUNT(DISTINCT e.campaign_id)
           FROM drip_enrollments e
           WHERE e.contact_id = contacts.id
             AND LOWER(COALESCE(e.status, '')) = 'cancelled'
             AND EXISTS (SELECT 1 FROM drip_send_queue q WHERE q.enrollment_id = e.id)
             AND NOT EXISTS (
               SELECT 1
               FROM drip_send_queue q
               WHERE q.enrollment_id = e.id
                 AND LOWER(COALESCE(q.status, '')) = 'pending'
             )
         ) AS drip_completed_campaign_count
       FROM contacts
       WHERE contacts.id = ?`,
      [id]
    );
    if (!contact) return res.status(404).json({ error: "Contact not found" });
    return res.json(withContactJsonFields(decryptContactBankFields(contact)));
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/tasks/:id/remind", async (req, res) => {
  try {
    const result = await remindTaskById(reminderJobDeps(), req.params.id);
    if (result.missing) return res.status(404).json({ error: "Task not found" });
    return res.json(result);
  } catch (error) {
    return res.status(500).json({ error: error.message || "Could not send the reminder." });
  }
});

app.get("/api/contacts/:id/tasks", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid contact id" });
    const rows = await all(
      `SELECT id, contact_id, task_name, action_type, task_date, task_time, condition, created_at, updated_at
       FROM contact_tasks
       WHERE contact_id = ?
       ORDER BY
         CASE WHEN trim(COALESCE(task_date,'')) = '' THEN 1 ELSE 0 END ASC,
         datetime(
           CASE
             WHEN trim(COALESCE(task_date,'')) = '' THEN '9999-12-31 23:59:59'
             WHEN trim(COALESCE(task_time,'')) = '' THEN task_date || ' 23:59:59'
             ELSE task_date || ' ' || task_time || ':00'
           END
         ) ASC,
         id DESC`,
      [id]
    );
    return res.json(rows);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/contacts/:id/tasks", async (req, res) => {
  try {
    const contactId = Number(req.params.id);
    if (!Number.isInteger(contactId) || contactId < 1) return res.status(400).json({ error: "Invalid contact id" });
    const exists = await get(`SELECT id FROM contacts WHERE id = ?`, [contactId]);
    if (!exists) return res.status(404).json({ error: "Contact not found" });
    const taskName = String(req.body?.task_name || "").trim();
    const taskDate = String(req.body?.task_date || "").trim();
    const taskTime = String(req.body?.task_time || "").trim();
    const actionType = normalizeTaskAction(req.body?.action_type);
    const condition = normalizeTaskCondition(req.body?.condition);
    if (!taskName) return res.status(400).json({ error: "Task Name is required" });
    await run(
      `INSERT INTO contact_tasks (contact_id, task_name, action_type, task_date, task_time, condition, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`,
      [contactId, taskName, actionType, taskDate, taskTime, condition]
    );
    const created = await get(
      `SELECT id, contact_id, task_name, action_type, task_date, task_time, condition, created_at, updated_at
       FROM contact_tasks
       WHERE id = (SELECT last_insert_rowid())`
    );
    return res.status(201).json(created);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.patch("/api/contacts/:id/tasks/:taskId", async (req, res) => {
  try {
    const contactId = Number(req.params.id);
    const taskId = Number(req.params.taskId);
    if (!Number.isInteger(contactId) || contactId < 1) return res.status(400).json({ error: "Invalid contact id" });
    if (!Number.isInteger(taskId) || taskId < 1) return res.status(400).json({ error: "Invalid task id" });
    const existing = await get(`SELECT id FROM contact_tasks WHERE id = ? AND contact_id = ?`, [taskId, contactId]);
    if (!existing) return res.status(404).json({ error: "Task not found" });
    const condition = normalizeTaskCondition(req.body?.condition);
    await run(
      `UPDATE contact_tasks
       SET condition = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ? AND contact_id = ?`,
      [condition, taskId, contactId]
    );
    const updated = await get(
      `SELECT id, contact_id, task_name, action_type, task_date, task_time, condition, created_at, updated_at
       FROM contact_tasks
       WHERE id = ? AND contact_id = ?`,
      [taskId, contactId]
    );
    if (condition === "Completed") {
      const contactRow = await get(`SELECT follow_up_date, follow_up_time FROM contacts WHERE id = ?`, [contactId]);
      const followUpDate = String(contactRow?.follow_up_date || "").trim();
      const taskDate = String(updated?.task_date || "").trim();
      let clearFollowUp = false;
      if (followUpDate && taskDate && followUpDate === taskDate) {
        clearFollowUp = true;
      } else if (followUpDate && /^\d{4}-\d{2}-\d{2}$/.test(followUpDate)) {
        const pastFollowUp = await get(`SELECT CASE WHEN date(?) < date('now') THEN 1 ELSE 0 END AS is_past`, [
          followUpDate
        ]);
        if (Number(pastFollowUp?.is_past) === 1) {
          const openPastTask = await get(
            `SELECT id FROM contact_tasks
             WHERE contact_id = ?
               AND lower(trim(COALESCE(condition, ''))) != 'completed'
               AND trim(COALESCE(task_date, '')) != ''
               AND date(task_date) <= date(?)
             LIMIT 1`,
            [contactId, followUpDate]
          );
          clearFollowUp = !openPastTask;
        }
      }
      if (clearFollowUp) {
        await run(
          `UPDATE contacts
           SET follow_up_date = '', follow_up_time = '', updated_at = CURRENT_TIMESTAMP
           WHERE id = ?`,
          [contactId]
        );
      }
    }
    return res.json(updated);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/contacts/:id/call-recordings", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid contact id" });
    const sync = String(req.query.sync || "").trim() === "1";
    const items = await listContactCallRecordings({ run, get, all, logContactActivity }, id, { sync });
    return res.json({ ok: true, items });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

async function syncContactEmailOpenHistory(contactId) {
  const id = Number(contactId);
  if (!Number.isInteger(id) || id < 1) return;
  const contact = await get(`SELECT email FROM contacts WHERE id = ?`, [id]);
  const email = String(contact?.email || "").trim().toLowerCase();
  const recentWindowSeconds = 2 * 60 * 60;
  const rows = await all(
    `SELECT id, subject, opened_at, contact_ids, to_emails
     FROM email_open_tracking
     WHERE opened_at IS NOT NULL
       AND opened_at >= CAST(strftime('%s','now') AS INTEGER) - ?
       AND (
         (',' || COALESCE(contact_ids, '') || ',') LIKE '%,' || ? || ',%'
         OR (? != '' AND lower(COALESCE(to_emails, '')) LIKE '%' || ? || '%')
       )
     ORDER BY opened_at DESC
     LIMIT 80`,
    [recentWindowSeconds, String(id), email, email]
  );
  for (const row of Array.isArray(rows) ? rows : []) {
    const subjectLabel = String(row.subject || "(no subject)").trim() || "(no subject)";
    const openedUnix = Number(row.opened_at || 0);
    if (!openedUnix) continue;
    const openedAtLabel = new Date(openedUnix * 1000).toLocaleString();
    const detail = `Email Opened\nSubject: ${subjectLabel}\nOpened At: ${openedAtLabel}`;
    const existing = await get(
      `SELECT id FROM contact_activity
       WHERE contact_id = ?
         AND LOWER(COALESCE(activity_type, '')) = 'email'
         AND detail = ?
       LIMIT 1`,
      [id, detail]
    );
    if (!existing) await logContactActivity(id, "email", detail);
  }
}

function extractOpenedAtUnixFromHistoryDetail(detail) {
  const raw = String(detail || "");
  const match = raw.match(/^Opened At:\s*(.+)$/im);
  if (!match) return 0;
  const parsed = Date.parse(String(match[1] || "").trim());
  if (!Number.isFinite(parsed)) return 0;
  return Math.floor(parsed / 1000);
}

app.get("/api/contacts/:id/history", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid contact id" });
    if (String(req.query.syncRecordings || "") === "1") {
      await listContactCallRecordings({ run, get, all, logContactActivity }, id);
    }
    if (String(req.query.syncEmailOpens || "1") !== "0") {
      await syncContactEmailOpenHistory(id);
    }
    const limitRaw = Number(req.query.limit);
    const offsetRaw = Number(req.query.offset);
    const limit = Number.isInteger(limitRaw) && limitRaw > 0 ? Math.min(limitRaw, 200) : 80;
    const offset = Number.isInteger(offsetRaw) && offsetRaw >= 0 ? offsetRaw : 0;
    const contactRow = await get(`SELECT email FROM contacts WHERE id = ?`, [id]);
    const contactEmail = String(contactRow?.email || "").trim().toLowerCase();
    const rows = await all(
      `SELECT id, contact_id, activity_type, detail, is_pinned, is_starred, created_at
       FROM contact_activity
       WHERE contact_id = ?
       ORDER BY is_pinned DESC, created_at DESC, id DESC
       LIMIT ? OFFSET ?`,
      [id, limit, offset]
    );
    const emailOpens = await all(
      `SELECT subject, opened_at
       FROM email_open_tracking
       WHERE opened_at IS NOT NULL
         AND (
           (',' || COALESCE(contact_ids, '') || ',') LIKE '%,' || ? || ',%'
           OR (? != '' AND lower(COALESCE(to_emails, '')) LIKE '%' || ? || '%')
         )
       ORDER BY opened_at DESC
       LIMIT 200`,
      [String(id), contactEmail, contactEmail]
    );
    const emailOpensBySubject = {};
    for (const row of Array.isArray(emailOpens) ? emailOpens : []) {
      const key = String(row.subject || "").trim().toLowerCase();
      if (!key || emailOpensBySubject[key]) continue;
      emailOpensBySubject[key] = Number(row.opened_at || 0);
    }
    return res.json({
      items: Array.isArray(rows) ? rows : [],
      emailOpensBySubject,
      limit,
      offset,
      hasMore: Array.isArray(rows) ? rows.length === limit : false
    });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/pipeline/completed-follow-ups", async (req, res) => {
  try {
    await maybeCompleteExpiredInitialImportOmit({ get, run, all });
    const rows = await all(
      `SELECT DISTINCT c.id AS contact_id
       FROM contacts c
       WHERE trim(COALESCE(c.follow_up_date, '')) != ''
         AND (
           EXISTS (
             SELECT 1
             FROM contact_tasks t
             WHERE t.contact_id = c.id
               AND lower(trim(COALESCE(t.condition, ''))) = 'completed'
               AND trim(COALESCE(t.task_date, '')) != ''
               AND date(t.task_date) = date(c.follow_up_date)
           )
           OR (
             date(c.follow_up_date) < date('now')
             AND EXISTS (
               SELECT 1
               FROM contact_tasks t
               WHERE t.contact_id = c.id
                 AND lower(trim(COALESCE(t.condition, ''))) = 'completed'
                 AND trim(COALESCE(t.task_date, '')) != ''
                 AND date(t.task_date) <= date(c.follow_up_date)
             )
             AND NOT EXISTS (
               SELECT 1
               FROM contact_tasks t
               WHERE t.contact_id = c.id
                 AND lower(trim(COALESCE(t.condition, ''))) != 'completed'
                 AND trim(COALESCE(t.task_date, '')) != ''
                 AND date(t.task_date) <= date(c.follow_up_date)
             )
           )
         )`
    );
    const contactIds = (Array.isArray(rows) ? rows : [])
      .map((row) => Number(row?.contact_id || 0))
      .filter((id) => Number.isInteger(id) && id > 0);
    return res.json({ contactIds });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/pipeline/status-changes", async (req, res) => {
  try {
    await maybeCompleteExpiredInitialImportOmit({ get, run, all });
    const daysRaw = Number(req.query?.days);
    const days = Number.isFinite(daysRaw) && daysRaw > 0 ? Math.floor(daysRaw) : 7;
    const omitTagsC = sqlExcludeInitialImportTags("c");
    const rows = await all(
      `SELECT ca.contact_id, c.full_name, c.email, c.outcome, c.follow_up_date, c.follow_up_time,
              MAX(datetime(ca.created_at)) AS changed_at
       FROM contact_activity ca
       INNER JOIN contacts c ON c.id = ca.contact_id
       WHERE LOWER(COALESCE(ca.activity_type, '')) = 'detail_change'
        AND LOWER(COALESCE(ca.detail, '')) LIKE 'outcome:%'
         AND datetime(ca.created_at) >= datetime('now', ?)
         AND ${omitTagsC}
       GROUP BY ca.contact_id, c.full_name, c.email, c.outcome, c.follow_up_date, c.follow_up_time
       ORDER BY datetime(changed_at) DESC
       LIMIT 500`,
      [`-${days} days`]
    );
    return res.json({ days, items: Array.isArray(rows) ? rows : [] });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/pipeline/scheduled-tasks", async (req, res) => {
  try {
    await maybeCompleteExpiredInitialImportOmit({ get, run, all });
    const daysRaw = Number(req.query?.days);
    const days = Number.isFinite(daysRaw) && daysRaw > 0 ? Math.floor(daysRaw) : 14;
    const omitTagsC = sqlExcludeInitialImportTags("c");
    const rows = await all(
      `SELECT
         t.contact_id,
         COALESCE(c.full_name, '') AS full_name,
         COALESCE(c.email, '') AS email,
         COALESCE(c.outcome, '') AS outcome,
         t.task_name,
         t.task_date,
         t.task_time,
         t.condition
       FROM contact_tasks t
       INNER JOIN contacts c ON c.id = t.contact_id
       WHERE lower(trim(COALESCE(t.condition, ''))) != 'completed'
         AND trim(COALESCE(t.task_date, '')) != ''
         AND date(t.task_date) >= date('now')
         AND date(t.task_date) <= date('now', ?)
         AND ${omitTagsC}
       ORDER BY date(t.task_date) ASC, trim(COALESCE(t.task_time, '')) ASC, t.id ASC
       LIMIT 500`,
      [`+${days} days`]
    );
    return res.json({ days, items: Array.isArray(rows) ? rows : [] });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/pipeline/morning-briefing", async (req, res) => {
  try {
    await maybeCompleteExpiredInitialImportOmit({ get, run, all });
    const pastDaysRaw = Number(req.query?.pastDays);
    const futureDaysRaw = Number(req.query?.futureDays);
    const pastDays = Number.isFinite(pastDaysRaw) && pastDaysRaw > 0 ? Math.min(Math.floor(pastDaysRaw), 90) : 7;
    const futureDays =
      Number.isFinite(futureDaysRaw) && futureDaysRaw > 0 ? Math.min(Math.floor(futureDaysRaw), 90) : 7;
    const snapshot = await collectPipelineSnapshot(all, { pastDays, futureDays });
    return res.json({ ok: true, snapshot });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Could not load morning briefing." });
  }
});

app.get("/api/renewals", async (req, res) => {
  try {
    await maybeCompleteExpiredInitialImportOmit({ get, run, all });
    const omitTags = sqlExcludeInitialImportTags();
    const rows = await all(
      `SELECT id, full_name, email, phone, coverage_start_date, quote, coverages_sold,
              status, outcome, lead_source, annual_renewal, renewal_interval
       FROM contacts
       WHERE trim(COALESCE(coverage_start_date, '')) != ''
         AND (
           COALESCE(renewal_interval, '') IN ('3', '6', '12')
           OR (COALESCE(renewal_interval, '') = '' AND COALESCE(annual_renewal, '') = '1')
         )
         AND ${omitTags}`
    );
    return res.json(buildRenewalItems(rows));
  } catch (error) {
    return res.status(500).json({ error: error.message || "Could not load renewals." });
  }
});

app.get("/api/attention/queue", async (req, res) => {
  try {
    await maybeCompleteExpiredInitialImportOmit({ get, run, all });
    const payload = await buildAttentionQueue({ all, get });
    return res.json(payload);
  } catch (error) {
    return res.status(500).json({ error: error.message || "Could not load attention queue." });
  }
});

app.get("/api/reports/close-rate-by-lead-source", async (req, res) => {
  try {
    await maybeCompleteExpiredInitialImportOmit({ get, run, all });
    const daysRaw = Number(req.query?.days);
    const days = Number.isFinite(daysRaw) && daysRaw > 0 ? Math.min(Math.floor(daysRaw), 3650) : 0;
    const omitTags = sqlExcludeInitialImportTags();
    const dateSql = days > 0 ? ` AND datetime(created_at) >= datetime('now', ?)` : "";
    const params = days > 0 ? [`-${days} days`] : [];
    const soldSql = `(
      LOWER(TRIM(COALESCE(status,''))) IN ('sold', 'approved')
      OR LOWER(TRIM(COALESCE(outcome,''))) = 'sold'
      OR (',' || LOWER(COALESCE(tags,'')) || ',') LIKE '%,sold,%'
    )`;
    const rows = await all(
      `SELECT
         CASE
           WHEN trim(COALESCE(lead_source, '')) = '' THEN '(None)'
           ELSE trim(lead_source)
         END AS lead_source,
         COUNT(*) AS total,
         SUM(CASE WHEN ${soldSql} THEN 1 ELSE 0 END) AS sold
       FROM contacts
       WHERE ${omitTags}
         ${dateSql}
       GROUP BY 1
       ORDER BY sold DESC, total DESC, lead_source COLLATE NOCASE ASC`,
      params
    );
    const items = (Array.isArray(rows) ? rows : []).map((row) => {
      const total = Number(row.total) || 0;
      const sold = Number(row.sold) || 0;
      const closeRate = total > 0 ? Math.round((sold / total) * 1000) / 10 : 0;
      return {
        lead_source: String(row.lead_source || "(None)"),
        total,
        sold,
        close_rate: closeRate
      };
    });
    const totals = items.reduce(
      (acc, row) => {
        acc.total += row.total;
        acc.sold += row.sold;
        return acc;
      },
      { total: 0, sold: 0 }
    );
    totals.close_rate = totals.total > 0 ? Math.round((totals.sold / totals.total) * 1000) / 10 : 0;
    return res.json({ days: days || null, items, totals });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Could not load close rate report." });
  }
});

function reportRatePct(numerator, denominator) {
  const den = Number(denominator) || 0;
  const num = Number(numerator) || 0;
  if (den <= 0) return 0;
  return Math.round((num / den) * 1000) / 10;
}

function reportEmailSubjectLabel(raw) {
  const text = String(raw == null ? "" : raw).trim();
  return text || "(no subject)";
}

/** Opened/sent and clicked/opened for emails tracked in email_open_tracking.
 *  Window is send time. Clicks ignore scanner hits within 10s of send (same as dashboard). */
app.get("/api/reports/email-engagement", async (req, res) => {
  try {
    const daysRaw = Number(req.query?.days);
    const days = Number.isFinite(daysRaw) && daysRaw > 0 ? Math.min(Math.floor(daysRaw), 3650) : 0;
    const sinceUnix = days > 0 ? Math.floor(Date.now() / 1000) - days * 86400 : 0;
    const dateSql = days > 0 ? "AND ot.created_at >= ?" : "";
    const params = days > 0 ? [sinceUnix] : [];
    const CLICK_BOT_GRACE_SECONDS = 10;
    const sentRows = await all(
      `SELECT
         CASE WHEN trim(COALESCE(ot.subject, '')) = '' THEN '(no subject)' ELSE trim(ot.subject) END AS subject,
         COUNT(*) AS sent,
         SUM(CASE WHEN ot.opened_at IS NOT NULL THEN 1 ELSE 0 END) AS opened
       FROM email_open_tracking ot
       WHERE 1=1 ${dateSql}
       GROUP BY 1
       ORDER BY sent DESC, subject COLLATE NOCASE ASC`,
      params
    );
    const clickRows = await all(
      `SELECT
         CASE WHEN trim(COALESCE(ot.subject, '')) = '' THEN '(no subject)' ELSE trim(ot.subject) END AS subject,
         COUNT(DISTINCT ot.open_token) AS clicked
       FROM email_open_tracking ot
       INNER JOIN email_click_events ce
         ON ce.open_token = ot.open_token
        AND trim(ce.open_token) != ''
       WHERE 1=1 ${dateSql}
         AND (ot.created_at IS NULL OR ce.clicked_at - ot.created_at >= ${CLICK_BOT_GRACE_SECONDS})
       GROUP BY 1`,
      params
    );
    const clickedBySubject = {};
    for (const row of Array.isArray(clickRows) ? clickRows : []) {
      clickedBySubject[reportEmailSubjectLabel(row.subject)] = Number(row.clicked) || 0;
    }
    const items = (Array.isArray(sentRows) ? sentRows : []).map((row) => {
      const subject = reportEmailSubjectLabel(row.subject);
      const sent = Number(row.sent) || 0;
      const opened = Number(row.opened) || 0;
      const clicked = Number(clickedBySubject[subject]) || 0;
      return {
        subject,
        sent,
        opened,
        open_rate: reportRatePct(opened, sent),
        clicked,
        click_to_open_rate: reportRatePct(clicked, opened)
      };
    });
    const totals = items.reduce(
      (acc, row) => {
        acc.sent += row.sent;
        acc.opened += row.opened;
        acc.clicked += row.clicked;
        return acc;
      },
      { sent: 0, opened: 0, clicked: 0 }
    );
    totals.open_rate = reportRatePct(totals.opened, totals.sent);
    totals.click_to_open_rate = reportRatePct(totals.clicked, totals.opened);
    return res.json({ days: days || null, items, totals });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Could not load email engagement report." });
  }
});

app.patch("/api/contacts/:id/history/:historyId", async (req, res) => {
  try {
    const contactId = Number(req.params.id);
    const historyId = Number(req.params.historyId);
    if (!Number.isInteger(contactId) || contactId < 1) return res.status(400).json({ error: "Invalid contact id" });
    if (!Number.isInteger(historyId) || historyId < 1) return res.status(400).json({ error: "Invalid history id" });
    const existing = await get(`SELECT id FROM contact_activity WHERE id = ? AND contact_id = ?`, [historyId, contactId]);
    if (!existing) return res.status(404).json({ error: "History item not found" });
    const updates = [];
    const params = [];
    if (Object.prototype.hasOwnProperty.call(req.body || {}, "is_pinned")) {
      updates.push("is_pinned = ?");
      params.push(req.body.is_pinned ? 1 : 0);
    }
    if (Object.prototype.hasOwnProperty.call(req.body || {}, "is_starred")) {
      updates.push("is_starred = ?");
      params.push(req.body.is_starred ? 1 : 0);
    }
    if (!updates.length) {
      return res.status(400).json({ error: "Nothing to update. Provide is_pinned and/or is_starred." });
    }
    params.push(historyId, contactId);
    await run(`UPDATE contact_activity SET ${updates.join(", ")} WHERE id = ? AND contact_id = ?`, params);
    const updated = await get(
      `SELECT id, contact_id, activity_type, detail, is_pinned, is_starred, created_at
       FROM contact_activity
       WHERE id = ? AND contact_id = ?`,
      [historyId, contactId]
    );
    return res.json(updated);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.delete("/api/contacts/:id/history/:historyId", async (req, res) => {
  try {
    const contactId = Number(req.params.id);
    const historyId = Number(req.params.historyId);
    if (!Number.isInteger(contactId) || contactId < 1) return res.status(400).json({ error: "Invalid contact id" });
    if (!Number.isInteger(historyId) || historyId < 1) return res.status(400).json({ error: "Invalid history id" });
    const result = await run(`DELETE FROM contact_activity WHERE id = ? AND contact_id = ?`, [historyId, contactId]);
    if (!result.changes) return res.status(404).json({ error: "History item not found" });
    return res.json({ ok: true });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/reminders/status", async (req, res) => {
  let pub = "";
  try {
    ensureVapidKeys();
    pub = String(getVapidPublicKey() || "").trim();
  } catch (err) {
    console.error("[api/reminders/status] VAPID:", err.message || err);
  }

  let emailReady = false;
  let emailReminderTo = "";
  try {
    emailReminderTo = await resolveReminderEmailTo(get);
    emailReady = Boolean(emailReminderTo) && (await reminderEmailCanSend());
  } catch {
    /* ignore */
  }

  let pushSubscriptionCount = 0;
  try {
    const row = await get(`SELECT COUNT(*) AS n FROM push_subscriptions`);
    pushSubscriptionCount = Number(row?.n ?? 0);
  } catch (err) {
    console.warn("[api/reminders/status] push_subscriptions:", err.message || err);
  }

  let taskSmsRemindersEnabled = true;
  let taskSmsFrom = "";
  let taskSmsTo = "";
  let taskSmsBlockedBusinessLine = false;
  let lastTaskSmsError = getLastTaskSmsError();
  try {
    taskSmsRemindersEnabled = await isTaskSmsRemindersEnabled(get);
  } catch {
    taskSmsRemindersEnabled = true;
  }
  try {
    const route = await describeTaskSmsRoute(get, all);
    taskSmsFrom = route.taskSmsFrom || "";
    taskSmsTo = route.taskSmsTo || "";
    taskSmsBlockedBusinessLine = route.taskSmsBlockedBusinessLine === true;
    if (route.lastTaskSmsError) lastTaskSmsError = route.lastTaskSmsError;
  } catch {
    /* the switch still loads if the number lookup fails */
  }

  res.json({
    emailReminderReady: emailReady,
    emailReminderTo,
    pushReminderReady: pub.length > 0,
    pushSubscriptionCount,
    vapidPublicKey: pub,
    taskSmsRemindersEnabled,
    taskSmsFrom,
    taskSmsTo,
    taskSmsBlockedBusinessLine,
    lastTaskSmsError
  });
});

app.put("/api/reminders/task-sms", async (req, res) => {
  try {
    const raw = req.body && req.body.enabled;
    const enabled = raw === true || raw === 1 || raw === "1" || raw === "true";
    await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, [
      "taskSmsReminders",
      enabled ? "1" : "0"
    ]);
    return res.json({ ok: true, taskSmsRemindersEnabled: enabled });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Could not save task text reminders." });
  }
});

async function sendSetupStatusJson(_req, res) {
  try {
    const body = await getSetupStatus();
    return res.json(body);
  } catch (error) {
    return res.status(500).json({ error: error.message || "Failed to read setup status." });
  }
}

app.get("/api/setup/status", sendSetupStatusJson);

app.post("/api/reminders/push-subscribe", async (req, res) => {
  try {
    const sub = req.body && req.body.subscription;
    if (!sub || !sub.endpoint || !sub.keys || !sub.keys.p256dh || !sub.keys.auth) {
      return res.status(400).json({ error: "Invalid subscription object" });
    }
    await run(
      `INSERT OR REPLACE INTO push_subscriptions (endpoint, subscription_json, created_at)
       VALUES (?, ?, CAST(strftime('%s','now') AS INTEGER))`,
      [sub.endpoint, JSON.stringify(sub)]
    );
    res.json({ ok: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/reminders/push-unsubscribe", async (req, res) => {
  try {
    const endpoint = req.body && req.body.endpoint;
    if (!endpoint || typeof endpoint !== "string") {
      return res.status(400).json({ error: "endpoint is required" });
    }
    await run(`DELETE FROM push_subscriptions WHERE endpoint = ?`, [endpoint]);
    res.json({ ok: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

const ACTIVITIES_PAGE_WINDOW_DAYS = 30;
const ACTIVITIES_STATUS_CHART_WEEKS = 4;
const ACTIVITIES_STATUS_CHART_WINDOW_DAYS = ACTIVITIES_STATUS_CHART_WEEKS * 7;
const ACTIVITIES_PAGE_LIST_LIMIT = 100;
const ACTIVITY_STATUS_BUCKETS = ["new", "approved", "declined", "referred", "aps", "pending", "closed"];

function parseActivityTransition(detail) {
  const text = String(detail || "").trim();
  const idx = text.indexOf("->");
  if (idx < 0) return null;
  const head = text.slice(0, idx).trim();
  const colon = head.indexOf(":");
  const field = colon >= 0 ? head.slice(0, colon).trim() : head;
  const from = colon >= 0 ? head.slice(colon + 1).trim() : "";
  const to = text.slice(idx + 2).trim();
  return { field, from, to };
}

function activityStatusBucket(detail) {
  const transition = parseActivityTransition(detail);
  if (!transition) return null;
  const field = String(transition.field || "").trim().toLowerCase();
  if (field !== "status" && field !== "outcome") return null;
  const to = String(transition.to || "").trim().toLowerCase();
  if (!to) return null;
  for (const bucket of ACTIVITY_STATUS_BUCKETS) {
    if (to === bucket) return bucket;
    if (bucket === "new") continue;
    if (bucket === "aps" && (to === "aps" || /\baps\b/.test(to))) return bucket;
    if (to.includes(bucket)) return bucket;
  }
  return null;
}

function formatActivityDetailForFeed(activityType, detail) {
  const raw = String(detail || "");
  const type = String(activityType || "").trim().toLowerCase();
  if (type === "email") {
    if (raw.toLowerCase().startsWith("email opened")) {
      return "";
    }
    if (raw.toLowerCase().startsWith("email clicked")) {
      return "";
    }
    const jsonPrefix = raw.match(/^email_json:/i);
    if (jsonPrefix) {
      try {
        const payload = JSON.parse(raw.slice(jsonPrefix[0].length));
        const subject = String(payload?.subject || "(no subject)").trim();
        const to = String(payload?.to || "").trim();
        return to ? `${subject} · To: ${to}` : subject;
      } catch {
        /* fall through */
      }
    }
    if (raw.toLowerCase().startsWith("sent email:")) {
      return raw.replace(/^sent email:\s*/i, "").trim() || "Email sent";
    }
    return raw.split("\n")[0] || "Email";
  }
  if (type === "sms") {
    return raw.replace(/^sent sms:\s*/i, "").trim() || "SMS sent";
  }
  if (type === "call") return formatCallActivityDetailForDisplay(raw);
  if (type === "new_contact") return "New contact entered";
  const transition = parseActivityTransition(raw);
  if (transition && transition.to) {
    const from = String(transition.from || "(empty)");
    const to = String(transition.to || "");
    return `${from} → ${to}`;
  }
  return raw || "-";
}

function mapActivityFeedRow(row, options = {}) {
  const transition = parseActivityTransition(row && row.detail);
  const contactId = Number(row && row.contact_id);
  const rawName = String((row && row.contact_name) || "").trim();
  const activityType = row && row.activity_type;
  const detailRaw = row && row.detail;
  const detail_display = formatActivityDetailForFeed(activityType, detailRaw);
  const activityTypeNorm = String(activityType || "").trim().toLowerCase();
  const detailRawStr = String(detailRaw || "");
  const omitHeavy =
    options.omitHeavyDetail &&
    ((activityTypeNorm === "email" && /^email_json:/i.test(detailRawStr)) ||
      (activityTypeNorm === "call" && Boolean(parseCallWithRecordingDetail(detailRawStr))));
  return {
    id: row && row.id,
    contact_id: contactId,
    contact_name: rawName || (Number.isInteger(contactId) && contactId > 0 ? `Contact #${contactId}` : ""),
    activity_type: activityType,
    detail: omitHeavy ? detail_display : detailRaw,
    detail_display,
    created_at: row && row.created_at,
    transition: transition
      ? { field: transition.field, from: transition.from, to: transition.to }
      : null
  };
}

function emptyStatusBuckets() {
  const out = {};
  for (const key of ACTIVITY_STATUS_BUCKETS) {
    out[key] = { count: 0, items: [] };
  }
  return out;
}

function bucketStatusActivities(rows, options = {}) {
  const buckets = emptyStatusBuckets();
  for (const row of rows) {
    const bucket = activityStatusBucket(row.detail);
    if (!bucket) continue;
    const item = mapActivityFeedRow(row, options);
    buckets[bucket].count += 1;
    if (buckets[bucket].items.length < ACTIVITIES_PAGE_LIST_LIMIT) {
      buckets[bucket].items.push(item);
    }
  }
  return buckets;
}

function formatActivityWeekRangeLabel(start, end) {
  const sameMonth = start.getMonth() === end.getMonth() && start.getFullYear() === end.getFullYear();
  const startPart = start.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    ...(sameMonth ? {} : { year: "numeric" })
  });
  const endPart = end.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  return `${startPart}–${endPart}`;
}

function buildActivityWeekRanges(numWeeks = ACTIVITIES_STATUS_CHART_WEEKS, now = new Date()) {
  const weeks = [];
  for (let w = 0; w < numWeeks; w += 1) {
    const weeksFromEnd = numWeeks - 1 - w;
    const end = new Date(now);
    end.setHours(23, 59, 59, 999);
    end.setDate(end.getDate() - weeksFromEnd * 7);
    const start = new Date(end);
    start.setHours(0, 0, 0, 0);
    start.setDate(start.getDate() - 6);
    weeks.push({
      index: w,
      label: formatActivityWeekRangeLabel(start, end),
      start: start.toISOString(),
      end: end.toISOString()
    });
  }
  return weeks;
}

function activityWeekIndex(createdAt, numWeeks = ACTIVITIES_STATUS_CHART_WEEKS, now = new Date()) {
  const d = new Date(String(createdAt || ""));
  if (!Number.isFinite(d.getTime())) return null;
  const diffDays = Math.floor((now.getTime() - d.getTime()) / 86400000);
  if (diffDays < 0 || diffDays >= numWeeks * 7) return null;
  return numWeeks - 1 - Math.floor(diffDays / 7);
}

function emptyStatusWeeklyCounts(numWeeks = ACTIVITIES_STATUS_CHART_WEEKS) {
  const out = {};
  for (const key of ACTIVITY_STATUS_BUCKETS) {
    out[key] = Array.from({ length: numWeeks }, () => 0);
  }
  return out;
}

function buildStatusWeeklyComparison(rows, options = {}) {
  const numWeeks = ACTIVITIES_STATUS_CHART_WEEKS;
  const now = options.now instanceof Date ? options.now : new Date();
  const weeks = buildActivityWeekRanges(numWeeks, now);
  const counts = emptyStatusWeeklyCounts(numWeeks);
  for (const row of rows) {
    const bucket = activityStatusBucket(row.detail);
    if (!bucket) continue;
    const weekIdx = activityWeekIndex(row.created_at, numWeeks, now);
    if (weekIdx == null) continue;
    counts[bucket][weekIdx] += 1;
  }
  const totals = {};
  for (const key of ACTIVITY_STATUS_BUCKETS) {
    totals[key] = counts[key].reduce((sum, n) => sum + n, 0);
  }
  return {
    weeks,
    statuses: ACTIVITY_STATUS_BUCKETS.slice(),
    counts,
    totals,
    windowDays: ACTIVITIES_STATUS_CHART_WINDOW_DAYS
  };
}

function buildStatusWeeklyComparisonFromAggregates(aggregateRows, options = {}) {
  const numWeeks = ACTIVITIES_STATUS_CHART_WEEKS;
  const now = options.now instanceof Date ? options.now : new Date();
  const weeks = buildActivityWeekRanges(numWeeks, now);
  const counts = emptyStatusWeeklyCounts(numWeeks);
  for (const row of Array.isArray(aggregateRows) ? aggregateRows : []) {
    const bucket = String(row.bucket || "").trim().toLowerCase();
    const weekIdx = Number(row.week_idx);
    const c = Number(row.c || 0);
    if (!ACTIVITY_STATUS_BUCKETS.includes(bucket)) continue;
    if (!Number.isInteger(weekIdx) || weekIdx < 0 || weekIdx >= numWeeks) continue;
    counts[bucket][weekIdx] += c;
  }
  const totals = {};
  for (const key of ACTIVITY_STATUS_BUCKETS) {
    totals[key] = counts[key].reduce((sum, n) => sum + n, 0);
  }
  return {
    weeks,
    statuses: ACTIVITY_STATUS_BUCKETS.slice(),
    counts,
    totals,
    windowDays: ACTIVITIES_STATUS_CHART_WINDOW_DAYS
  };
}

async function fetchActivitiesStatusWeeklyAggregates() {
  const maxDays = ACTIVITIES_STATUS_CHART_WINDOW_DAYS;
  const maxWeekIdx = ACTIVITIES_STATUS_CHART_WEEKS - 1;
  return all(
    `SELECT bucket, week_idx, COUNT(*) AS c
       FROM (
         SELECT
           CASE
             WHEN ca.detail LIKE '%->%closed%' THEN 'closed'
             WHEN ca.detail LIKE '%->%pending%' THEN 'pending'
             WHEN ca.detail LIKE '%->%declined%' THEN 'declined'
             WHEN ca.detail LIKE '%->%approved%' THEN 'approved'
             WHEN ca.detail LIKE '%->%referred%' THEN 'referred'
             WHEN ca.detail LIKE '%->%aps%' THEN 'aps'
             WHEN ca.detail LIKE '%->%new%' THEN 'new'
           END AS bucket,
           CASE
             WHEN CAST((julianday('now') - julianday(ca.created_at)) AS INTEGER) < 0 THEN NULL
             WHEN CAST((julianday('now') - julianday(ca.created_at)) AS INTEGER) >= ${maxDays} THEN NULL
             ELSE ${maxWeekIdx} - CAST(CAST((julianday('now') - julianday(ca.created_at)) AS INTEGER) / 7 AS INTEGER)
           END AS week_idx
         FROM contact_activity ca
         WHERE ca.created_at >= datetime('now', '-${maxDays} days')
           AND ca.activity_type = 'detail_change'
           AND (
             ca.detail LIKE 'status:%'
             OR ca.detail LIKE 'outcome:%'
           )
           AND (
             ca.detail LIKE '%->%new%'
             OR ca.detail LIKE '%->%approved%'
             OR ca.detail LIKE '%->%declined%'
             OR ca.detail LIKE '%->%referred%'
             OR ca.detail LIKE '%->%aps%'
             OR ca.detail LIKE '%->%pending%'
             OR ca.detail LIKE '%->%closed%'
           )
       ) staged
       WHERE bucket IS NOT NULL AND week_idx IS NOT NULL
       GROUP BY bucket, week_idx`
  );
}

function activityFeedSection(count, items) {
  return { count: Number(count || 0), items: Array.isArray(items) ? items : [] };
}

function mergeActivityFeedRows(rowsA, rowsB, limit = ACTIVITIES_PAGE_LIST_LIMIT) {
  return [...rowsA, ...rowsB]
    .sort((a, b) => {
      const ta = new Date(String(a.created_at || "")).getTime();
      const tb = new Date(String(b.created_at || "")).getTime();
      if (Number.isFinite(tb) && Number.isFinite(ta) && tb !== ta) return tb - ta;
      return Number(b.id || 0) - Number(a.id || 0);
    })
    .slice(0, limit);
}

const DRIP_SENT_ACTIVITY_JOIN = `
  FROM drip_send_queue q
  JOIN drip_steps s ON s.id = q.step_id
  JOIN drip_enrollments e ON e.id = q.enrollment_id
  JOIN contacts c ON c.id = e.contact_id`;

function dripSentActivityWhere(channel, sentAtUnixCutoff) {
  return `${DRIP_SENT_ACTIVITY_JOIN}
       WHERE LOWER(COALESCE(s.channel, '')) = ?
         AND q.status = 'sent'
         AND q.sent_at IS NOT NULL
         AND q.sent_at >= ${sentAtUnixCutoff}`;
}

const DRIP_EMAIL_SENT_SELECT = `SELECT
         q.id AS id,
         e.contact_id AS contact_id,
         'email' AS activity_type,
         ('Sent email: ' || COALESCE(NULLIF(TRIM(s.subject), ''), '(no subject)') || ' (automation)') AS detail,
         datetime(q.sent_at, 'unixepoch') AS created_at,
         COALESCE(c.full_name, '') AS contact_name`;

const DRIP_SMS_SENT_SELECT = `SELECT
         q.id AS id,
         e.contact_id AS contact_id,
         'sms' AS activity_type,
         ('Sent SMS: ' || COALESCE(NULLIF(TRIM(s.body), ''), '(no message)') || ' (automation)') AS detail,
         datetime(q.sent_at, 'unixepoch') AS created_at,
         COALESCE(c.full_name, '') AS contact_name`;

const TRACKING_FIRST_CONTACT_ID_EXPR = `
  CAST(NULLIF(TRIM(
    CASE
      WHEN INSTR(COALESCE(t.contact_ids, ''), ',') > 0
        THEN SUBSTR(t.contact_ids, 1, INSTR(t.contact_ids, ',') - 1)
      ELSE COALESCE(t.contact_ids, '')
    END
  ), '') AS INTEGER)`;

const EMAIL_OPENED_FEED_SELECT = `SELECT
         t.id AS id,
         ${TRACKING_FIRST_CONTACT_ID_EXPR} AS contact_id,
         'email' AS activity_type,
         ('Email Opened' || CHAR(10) || 'Subject: ' || COALESCE(NULLIF(TRIM(t.subject), ''), '(no subject)') || CHAR(10) || 'Opened At: ' || datetime(t.opened_at, 'unixepoch')) AS detail,
         datetime(t.opened_at, 'unixepoch') AS created_at,
         COALESCE(c.full_name, '') AS contact_name`;

const EMAIL_CLICK_BOT_GRACE_SECONDS = 10;

const EMAIL_CLICKED_FEED_SELECT = `SELECT
         ce.id AS id,
         COALESCE(NULLIF(ce.contact_id, 0), ${TRACKING_FIRST_CONTACT_ID_EXPR}) AS contact_id,
         'email' AS activity_type,
         ('Email Clicked' || CHAR(10) || 'Subject: ' || COALESCE(NULLIF(TRIM(ce.subject), ''), '(no subject)') || CHAR(10) || 'Link: ' || COALESCE(NULLIF(TRIM(ce.link_url), ''), '(link)') || CHAR(10) || 'Clicked At: ' || datetime(ce.clicked_at, 'unixepoch')) AS detail,
         datetime(ce.clicked_at, 'unixepoch') AS created_at,
         COALESCE(c.full_name, '') AS contact_name`;

const EMAIL_SENT_TRACKING_SELECT = `SELECT
         t.id AS id,
         ${TRACKING_FIRST_CONTACT_ID_EXPR} AS contact_id,
         'email' AS activity_type,
         ('Sent email: ' || COALESCE(NULLIF(TRIM(t.subject), ''), '(no subject)')) AS detail,
         datetime(t.created_at, 'unixepoch') AS created_at,
         COALESCE(c.full_name, '') AS contact_name`;

const ACTIVITY_FEED_MAP_OPTS = { omitHeavyDetail: true };

function activitiesWindowUnixCutoff(windowDays) {
  return `CAST(strftime('%s', 'now', '-${windowDays} days') AS INTEGER)`;
}

function parseActivitiesWindowDays(value) {
  const n = Math.floor(Number(value || ACTIVITIES_PAGE_WINDOW_DAYS));
  if ([7, 30, 90].includes(n)) return n;
  return ACTIVITIES_PAGE_WINDOW_DAYS;
}

async function buildActivitiesPageSummary(options = {}) {
  const windowDays = parseActivitiesWindowDays(options.windowDays);
  const activitySince = `datetime('now', '-${windowDays} days')`;
  const openSinceUnix = activitiesWindowUnixCutoff(windowDays);
  const dripSinceUnix = activitiesWindowUnixCutoff(windowDays);
  const activityJoin = `FROM contact_activity ca LEFT JOIN contacts c ON c.id = ca.contact_id`;
  const activitySelect = `SELECT
         ca.id,
         ca.contact_id,
         ca.activity_type,
         ca.detail,
         ca.created_at,
         COALESCE(c.full_name, '') AS contact_name`;

  const emailsSentWhere = `${activityJoin}
       WHERE ca.created_at >= ${activitySince}
         AND ca.activity_type = 'email'
         AND (
           ca.detail LIKE 'sent email:%'
           OR ca.detail LIKE 'email_json:%'
         )
         AND ca.detail NOT LIKE 'email opened%'`;

  const dripSentBaseWhere = `${DRIP_SENT_ACTIVITY_JOIN}
       WHERE q.status = 'sent'
         AND q.sent_at IS NOT NULL
         AND q.sent_at >= ${dripSinceUnix}`;

  const smsSentWhere = `${activityJoin}
       WHERE ca.created_at >= ${activitySince}
         AND ca.activity_type = 'sms'
         AND ca.detail LIKE 'sent sms:%'`;

  const callsWhere = `${activityJoin}
       WHERE ca.created_at >= ${activitySince}
         AND ca.activity_type = 'call'`;

  const [
    emailOpenedCountRow,
    emailOpenedRows,
    emailClickedCountRow,
    emailClickedRows,
    trackingSentCountRow,
    trackingSentRows,
    activityCountRow,
    emailsSentRows,
    dripCountRow,
    dripEmailsSentRows,
    dripSmsSentRows,
    smsSentRows,
    callsRows,
    newContactsCountRow,
    newContactRows,
    statusWeeklyAggregates
  ] = await Promise.all([
    get(
      `SELECT COUNT(*) AS c
         FROM email_open_tracking
         WHERE opened_at IS NOT NULL
           AND opened_at >= ${openSinceUnix}`
    ),
    all(
      `${EMAIL_OPENED_FEED_SELECT}
         FROM email_open_tracking t
         LEFT JOIN contacts c ON c.id = ${TRACKING_FIRST_CONTACT_ID_EXPR}
         WHERE t.opened_at IS NOT NULL
           AND t.opened_at >= ${openSinceUnix}
         ORDER BY t.opened_at DESC, t.id DESC
         LIMIT ${ACTIVITIES_PAGE_LIST_LIMIT}`
    ),
    get(
      `SELECT COUNT(DISTINCT CASE
           WHEN trim(ce.open_token) != ''
            AND (ot.created_at IS NULL OR ce.clicked_at - ot.created_at >= ${EMAIL_CLICK_BOT_GRACE_SECONDS})
           THEN ce.open_token END) AS c
         FROM email_click_events ce
         LEFT JOIN email_open_tracking ot ON ot.open_token = ce.open_token
         WHERE ce.clicked_at >= ${openSinceUnix}`
    ),
    all(
      `${EMAIL_CLICKED_FEED_SELECT}
         FROM email_click_events ce
         INNER JOIN (
           SELECT ce2.open_token, MAX(ce2.id) AS id
             FROM email_click_events ce2
             LEFT JOIN email_open_tracking ot2 ON ot2.open_token = ce2.open_token
            WHERE ce2.clicked_at >= ${openSinceUnix}
              AND trim(ce2.open_token) != ''
              AND (ot2.created_at IS NULL OR ce2.clicked_at - ot2.created_at >= ${EMAIL_CLICK_BOT_GRACE_SECONDS})
            GROUP BY ce2.open_token
         ) latest ON latest.id = ce.id
         LEFT JOIN email_open_tracking t ON t.open_token = ce.open_token
         LEFT JOIN contacts c ON c.id = COALESCE(NULLIF(ce.contact_id, 0), ${TRACKING_FIRST_CONTACT_ID_EXPR})
         ORDER BY ce.clicked_at DESC, ce.id DESC
         LIMIT ${ACTIVITIES_PAGE_LIST_LIMIT}`
    ),
    get(
      `SELECT COUNT(*) AS c
         FROM email_open_tracking
         WHERE created_at >= ${openSinceUnix}`
    ),
    all(
      `${EMAIL_SENT_TRACKING_SELECT}
         FROM email_open_tracking t
         LEFT JOIN contacts c ON c.id = ${TRACKING_FIRST_CONTACT_ID_EXPR}
         WHERE t.created_at >= ${openSinceUnix}
         ORDER BY t.created_at DESC, t.id DESC
         LIMIT ${ACTIVITIES_PAGE_LIST_LIMIT}`
    ),
    get(
      `SELECT
         SUM(CASE
           WHEN ca.activity_type = 'email'
             AND (
               ca.detail LIKE 'sent email:%'
               OR ca.detail LIKE 'email_json:%'
             )
             AND ca.detail NOT LIKE 'email opened%'
           THEN 1 ELSE 0 END) AS emails_sent,
         SUM(CASE
           WHEN ca.activity_type = 'sms' AND ca.detail LIKE 'sent sms:%'
           THEN 1 ELSE 0 END) AS sms_sent,
         SUM(CASE
           WHEN ca.activity_type = 'call'
           THEN 1 ELSE 0 END) AS calls_made
       FROM contact_activity ca
       WHERE ca.created_at >= ${activitySince}`
    ),
    all(
      `${activitySelect} ${emailsSentWhere}
         ORDER BY ca.created_at DESC, ca.id DESC
         LIMIT ${ACTIVITIES_PAGE_LIST_LIMIT}`
    ),
    get(
      `SELECT
         SUM(CASE WHEN LOWER(COALESCE(s.channel, '')) = 'email' THEN 1 ELSE 0 END) AS drip_emails,
         SUM(CASE WHEN LOWER(COALESCE(s.channel, '')) = 'sms' THEN 1 ELSE 0 END) AS drip_sms
       ${dripSentBaseWhere}`
    ),
    all(
      `${DRIP_EMAIL_SENT_SELECT} ${dripSentActivityWhere("email", dripSinceUnix)}
         ORDER BY q.sent_at DESC, q.id DESC
         LIMIT ${ACTIVITIES_PAGE_LIST_LIMIT}`,
      ["email"]
    ),
    all(
      `${DRIP_SMS_SENT_SELECT} ${dripSentActivityWhere("sms", dripSinceUnix)}
         ORDER BY q.sent_at DESC, q.id DESC
         LIMIT ${ACTIVITIES_PAGE_LIST_LIMIT}`,
      ["sms"]
    ),
    all(
      `${activitySelect} ${smsSentWhere}
         ORDER BY ca.created_at DESC, ca.id DESC
         LIMIT ${ACTIVITIES_PAGE_LIST_LIMIT}`
    ),
    all(
      `${activitySelect} ${callsWhere}
         ORDER BY ca.created_at DESC, ca.id DESC
         LIMIT ${ACTIVITIES_PAGE_LIST_LIMIT}`
    ),
    get(
      `SELECT COUNT(*) AS c
         FROM contacts
         WHERE created_at >= ${activitySince}
           AND LOWER(COALESCE(tags, '')) NOT LIKE '%bulk%'`
    ),
    all(
      `SELECT
           id,
           id AS contact_id,
           'new_contact' AS activity_type,
           'New contact entered' AS detail,
           created_at,
           COALESCE(full_name, '') AS contact_name
         FROM contacts
         WHERE created_at >= ${activitySince}
           AND LOWER(COALESCE(tags, '')) NOT LIKE '%bulk%'
         ORDER BY created_at DESC, id DESC
         LIMIT ${ACTIVITIES_PAGE_LIST_LIMIT}`
    ),
    fetchActivitiesStatusWeeklyAggregates()
  ]);

  const mapOpts = ACTIVITY_FEED_MAP_OPTS;
  const activitySent = Number(activityCountRow?.emails_sent || 0);
  const dripSent = Number(dripCountRow?.drip_emails || 0);
  const trackingSent = Number(trackingSentCountRow?.c || 0);
  const manualAndAutomation = activitySent + dripSent;
  // Bulk + drip + manual sends all log to email_open_tracking when dispatched; use that
  // as the campaign send total so Emails Sent aligns with Emails Opened.
  const emailsSentTotal =
    trackingSent > 0 ? Math.max(trackingSent, manualAndAutomation) : manualAndAutomation;
  const smsSentTotal = Number(activityCountRow?.sms_sent || 0) + Number(dripCountRow?.drip_sms || 0);
  const callsMadeTotal = Number(activityCountRow?.calls_made || 0);
  const emailsSentItems =
    trackingSent > manualAndAutomation
      ? trackingSentRows.map((row) => mapActivityFeedRow(row, mapOpts))
      : mergeActivityFeedRows(
          emailsSentRows.map((row) => mapActivityFeedRow(row, mapOpts)),
          dripEmailsSentRows.map((row) => mapActivityFeedRow(row, mapOpts))
        );
  const smsSentItems = mergeActivityFeedRows(
    smsSentRows.map((row) => mapActivityFeedRow(row, mapOpts)),
    dripSmsSentRows.map((row) => mapActivityFeedRow(row, mapOpts))
  );
  return {
    windowDays,
    totalsLast30d: {
      emailOpened: Number(emailOpenedCountRow?.c || 0),
      emailClicked: Number(emailClickedCountRow?.c || 0),
      emailsSent: emailsSentTotal,
      smsSent: smsSentTotal,
      callsMade: callsMadeTotal,
      newContacts: Number(newContactsCountRow?.c || 0)
    },
    contactActivities: {
      emailOpened: activityFeedSection(
        emailOpenedCountRow?.c,
        emailOpenedRows.map((row) => mapActivityFeedRow(row, mapOpts))
      ),
      emailClicked: activityFeedSection(
        emailClickedCountRow?.c,
        emailClickedRows.map((row) => mapActivityFeedRow(row, mapOpts))
      )
    },
    userActivities: {
      emailsSent: activityFeedSection(emailsSentTotal, emailsSentItems),
      smsSent: activityFeedSection(smsSentTotal, smsSentItems),
      callsMade: activityFeedSection(
        callsMadeTotal,
        callsRows.map((row) => mapActivityFeedRow(row, mapOpts))
      ),
      newContacts: activityFeedSection(
        newContactsCountRow?.c,
        newContactRows.map((row) => mapActivityFeedRow(row, mapOpts))
      )
    },
    statusWeeklyComparison: buildStatusWeeklyComparisonFromAggregates(statusWeeklyAggregates)
  };
}

function isActivitiesPageScope(req) {
  const scope = String(req.query?.scope || req.query?.page || "").trim().toLowerCase();
  return scope === "page" || scope === "activities" || String(req.query?.lite || "") === "1";
}

function isHomeDashboardScope(req) {
  const scope = String(req.query?.scope || "").trim().toLowerCase();
  return scope === "dashboard" || scope === "home";
}

async function buildHomeDashboardSummary() {
  const [
    totalsRow,
    newContactsRow,
    newContacts24hRow,
    contactsSold7dRow,
    categories,
    recent,
    soldRow
  ] = await Promise.all([
    get(
      `SELECT
         SUM(
           CASE
             WHEN LOWER(COALESCE(activity_type, '')) = 'email'
              AND (
                LOWER(COALESCE(detail, '')) LIKE 'sent email:%'
                OR LOWER(COALESCE(detail, '')) LIKE 'email_json:%'
              )
             THEN 1
             ELSE 0
           END
         ) AS emails_last_7d,
         SUM(
           CASE WHEN LOWER(COALESCE(activity_type, '')) = 'call' THEN 1 ELSE 0 END
         ) AS calls_last_7d,
         SUM(
           CASE
             WHEN LOWER(COALESCE(activity_type, '')) = 'sms'
              AND LOWER(COALESCE(detail, '')) LIKE 'sent sms:%'
             THEN 1
             ELSE 0
           END
         ) AS sms_last_7d
       FROM contact_activity
       WHERE created_at >= datetime('now', '-7 days')`
    ),
    get(
      `SELECT COUNT(*) AS created_last_7d
       FROM contacts
       WHERE created_at >= datetime('now', '-7 days')
         AND LOWER(COALESCE(tags, '')) NOT LIKE '%bulk%'`
    ),
    get(
      `SELECT COUNT(*) AS created_last_24h
       FROM contacts
       WHERE created_at >= datetime('now', '-24 hours')`
    ),
    get(
      `SELECT COUNT(DISTINCT contact_id) AS sold_last_7d
       FROM contact_activity
       WHERE created_at >= datetime('now', '-7 days')
         AND LOWER(COALESCE(activity_type, '')) = 'detail_change'
         AND (
           LOWER(COALESCE(detail, '')) LIKE 'status:%'
           OR LOWER(COALESCE(detail, '')) LIKE 'outcome:%'
         )
         AND LOWER(COALESCE(detail, '')) LIKE '%->%sold%'`
    ),
    all(
      `WITH base AS (
         SELECT
           LOWER(COALESCE(ca.activity_type, '')) AS activity_type,
           LOWER(COALESCE(ca.detail, '')) AS detail,
           LOWER(COALESCE(c.tags, '')) AS tags
         FROM contact_activity ca
         LEFT JOIN contacts c ON c.id = ca.contact_id
         WHERE ca.created_at >= datetime('now', '-14 days')
       ),
       bucket_counts AS (
         SELECT 'email' AS activity_type, COUNT(*) AS count
         FROM base
         WHERE activity_type = 'email'
           AND (detail LIKE 'sent email:%' OR detail LIKE 'email_json:%')
         UNION ALL
         SELECT 'call' AS activity_type, COUNT(*) AS count
         FROM base
         WHERE activity_type = 'call'
         UNION ALL
         SELECT 'sms' AS activity_type, COUNT(*) AS count
         FROM base
         WHERE activity_type = 'sms'
           AND detail LIKE 'sent sms:%'
         UNION ALL
         SELECT 'sold' AS activity_type, COUNT(*) AS count
         FROM base
         WHERE activity_type = 'detail_change'
           AND (detail LIKE 'status:%' OR detail LIKE 'outcome:%')
           AND (detail LIKE '%->%approved%' OR detail LIKE '%->%sold%')
         UNION ALL
         SELECT 'detail_change' AS activity_type, COUNT(*) AS count
         FROM base
         WHERE activity_type = 'detail_change'
           AND (
             detail LIKE 'status:%'
             OR detail LIKE 'outcome:%'
             OR (detail LIKE 'created date:%' AND tags NOT LIKE '%bulk%')
           )
       )
       SELECT activity_type, count
       FROM bucket_counts
       WHERE count > 0
       ORDER BY CASE activity_type
         WHEN 'email' THEN 1
         WHEN 'call' THEN 2
         WHEN 'sms' THEN 3
         WHEN 'sold' THEN 4
         WHEN 'detail_change' THEN 5
         ELSE 99
       END`
    ),
    all(
      `SELECT
         ca.id,
         ca.contact_id,
         ca.activity_type,
         ca.detail,
         ca.created_at,
         COALESCE(c.full_name, '') AS contact_name
       FROM contact_activity ca
       LEFT JOIN contacts c ON c.id = ca.contact_id
       WHERE ca.created_at >= datetime('now', '-30 days')
         AND (
           (
             LOWER(COALESCE(ca.activity_type, '')) = 'detail_change'
             AND (
               LOWER(COALESCE(ca.detail, '')) LIKE 'status:%'
               OR LOWER(COALESCE(ca.detail, '')) LIKE 'vcall:%'
             )
           )
           OR (
             LOWER(COALESCE(ca.activity_type, '')) = 'email'
             AND LOWER(COALESCE(ca.detail, '')) LIKE 'email opened%'
           )
           OR (
             LOWER(COALESCE(ca.activity_type, '')) = 'detail_change'
             AND LOWER(COALESCE(ca.detail, '')) LIKE 'created date:%'
             AND LOWER(COALESCE(c.tags, '')) NOT LIKE '%bulk%'
           )
         )
       ORDER BY ca.created_at DESC, ca.id DESC
       LIMIT 20`
    ),
    get(
      `SELECT COUNT(*) AS sold_total
       FROM contact_activity ca
       WHERE created_at >= datetime('now', '-7 days')
         AND LOWER(COALESCE(ca.activity_type, '')) = 'detail_change'
         AND (
           (LOWER(COALESCE(ca.detail, '')) LIKE 'status:%' OR LOWER(COALESCE(ca.detail, '')) LIKE 'outcome:%')
           AND (
             LOWER(COALESCE(ca.detail, '')) LIKE '%->%approved%'
             OR LOWER(COALESCE(ca.detail, '')) LIKE '%->%sold%'
           )
         )`
    )
  ]);

  const mapOpts = ACTIVITY_FEED_MAP_OPTS;
  return {
    totals: {
      totalLast7d:
        Number(totalsRow?.emails_last_7d || 0) +
        Number(totalsRow?.calls_last_7d || 0) +
        Number(totalsRow?.sms_last_7d || 0),
      emailsLast7d: Number(totalsRow?.emails_last_7d || 0),
      callsLast7d: Number(totalsRow?.calls_last_7d || 0),
      smsLast7d: Number(totalsRow?.sms_last_7d || 0),
      newContactsCreatedLast7d: Number(newContactsRow?.created_last_7d || 0),
      contactsCreatedLast24h: Number(newContacts24hRow?.created_last_24h || 0),
      contactsSoldLast7d: Number(contactsSold7dRow?.sold_last_7d || 0),
      soldCategory: Number(soldRow?.sold_total || 0)
    },
    categories: (Array.isArray(categories) ? categories : []).map((row) => ({
      type: String(row.activity_type || "event"),
      count: Number(row.count || 0)
    })),
    recent: (Array.isArray(recent) ? recent : []).map((row) => mapActivityFeedRow(row, mapOpts))
  };
}

app.get("/api/activities/summary", async (req, res) => {
  try {
    if (isActivitiesPageScope(req)) {
      return res.json(await buildActivitiesPageSummary({ windowDays: req.query?.days }));
    }
    if (isHomeDashboardScope(req)) {
      return res.json(await buildHomeDashboardSummary());
    }

    return res.json(await buildHomeDashboardSummary());
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

function localTodayYmd(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function classifyTaskBucket(row, todayYmd) {
  const condition = String(row?.condition || "").trim().toLowerCase();
  if (condition === "completed") return "completed";
  const date = String(row?.task_date || "").trim().slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return "unscheduled";
  if (date < todayYmd) return "overdue";
  if (date === todayYmd) return "today";
  return "upcoming";
}

app.get("/api/tasks", async (req, res) => {
  try {
    const requestedLimit = Number(req.query.limit);
    const limit = Number.isInteger(requestedLimit) && requestedLimit > 0 ? Math.min(requestedLimit, 500) : 400;
    const rows = await all(
      `SELECT
         t.id,
         t.contact_id,
         t.task_name,
         t.action_type,
         t.task_date,
         t.task_time,
         t.condition,
         t.created_at,
         t.updated_at,
         COALESCE(c.full_name, '') AS contact_name
       FROM contact_tasks t
       LEFT JOIN contacts c ON c.id = t.contact_id
       ORDER BY
         CASE WHEN lower(trim(COALESCE(t.condition, ''))) = 'completed' THEN 1 ELSE 0 END ASC,
         CASE WHEN trim(COALESCE(t.task_date,'')) = '' THEN 1 ELSE 0 END ASC,
         date(t.task_date) ASC,
         trim(COALESCE(t.task_time,'')) ASC,
         t.id DESC
       LIMIT ?`,
      [limit]
    );
    const todayYmd = localTodayYmd();
    const items = (Array.isArray(rows) ? rows : []).map((row) => {
      const contactId = Number(row.contact_id) || 0;
      const bucket = classifyTaskBucket(row, todayYmd);
      return {
        id: Number(row.id) || 0,
        contact_id: contactId,
        contact_name: String(row.contact_name || "").trim() || "Unnamed contact",
        task_name: String(row.task_name || "").trim(),
        action_type: String(row.action_type || "Other").trim() || "Other",
        task_date: String(row.task_date || "").trim(),
        task_time: String(row.task_time || "").trim(),
        condition: String(row.condition || "Yet to Start").trim() || "Yet to Start",
        created_at: row.created_at,
        updated_at: row.updated_at,
        bucket,
        href: contactId
          ? `/contact.html?id=${encodeURIComponent(contactId)}&full=1`
          : "#"
      };
    });
    const counts = {
      overdue: items.filter((it) => it.bucket === "overdue").length,
      today: items.filter((it) => it.bucket === "today").length,
      upcoming: items.filter((it) => it.bucket === "upcoming").length,
      unscheduled: items.filter((it) => it.bucket === "unscheduled").length,
      completed: items.filter((it) => it.bucket === "completed").length
    };
    counts.open = counts.overdue + counts.today + counts.upcoming + counts.unscheduled;
    counts.total = items.length;
    return res.json({ items, counts, today: todayYmd });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/tasks/upcoming", async (req, res) => {
  try {
    const requestedLimit = Number(req.query.limit);
    const limit = Number.isInteger(requestedLimit) && requestedLimit > 0 ? Math.min(requestedLimit, 100) : 20;
    const rows = await all(
      `SELECT
         t.id,
         t.contact_id,
         t.task_name,
         t.action_type,
         t.task_date,
         t.task_time,
         t.condition,
         t.updated_at,
         COALESCE(c.full_name, '') AS contact_name
       FROM contact_tasks t
       LEFT JOIN contacts c ON c.id = t.contact_id
       WHERE lower(trim(COALESCE(t.condition, ''))) != 'completed'
       ORDER BY
         CASE WHEN trim(COALESCE(t.task_date,'')) = '' THEN 0 ELSE 1 END ASC,
         CASE
           WHEN trim(COALESCE(t.task_date,'')) = '' THEN datetime(COALESCE(t.updated_at, t.created_at))
           ELSE NULL
         END DESC,
         CASE
           WHEN trim(COALESCE(t.task_date,'')) = '' THEN NULL
           ELSE datetime(
             CASE
               WHEN trim(COALESCE(t.task_time,'')) = '' THEN t.task_date || ' 23:59:59'
               ELSE t.task_date || ' ' || t.task_time || ':00'
             END
           )
         END ASC,
         t.id DESC
       LIMIT ?`,
      [limit]
    );
    return res.json(rows);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

function parseContactDobParts(raw) {
  const s = String(raw || "").trim();
  if (!s) return null;
  let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (m) {
    const y = Number(m[1]);
    const mo = Number(m[2]);
    const d = Number(m[3]);
    if (y >= 1900 && mo >= 1 && mo <= 12 && d >= 1 && d <= 31) return { y, mo, d };
  }
  m = s.match(/^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})/);
  if (m) {
    const mo = Number(m[1]);
    const d = Number(m[2]);
    const y = Number(m[3]);
    if (y >= 1900 && mo >= 1 && mo <= 12 && d >= 1 && d <= 31) return { y, mo, d };
  }
  return null;
}

function daysUntilNextBirthday(parts, now) {
  if (!parts) return null;
  const year = now.getFullYear();
  const start = new Date(year, now.getMonth(), now.getDate());
  let next = new Date(year, parts.mo - 1, parts.d);
  if (Number.isNaN(next.getTime()) || next.getMonth() !== parts.mo - 1) {
    next = new Date(year, 2, 1);
  }
  if (next < start) {
    next = new Date(year + 1, parts.mo - 1, parts.d);
    if (Number.isNaN(next.getTime()) || next.getMonth() !== parts.mo - 1) {
      next = new Date(year + 1, 2, 1);
    }
  }
  return Math.round((next.getTime() - start.getTime()) / 86400000);
}

function turningAgeOnNextBirthday(parts, now) {
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const thisYear = new Date(now.getFullYear(), parts.mo - 1, parts.d);
  const yearOfNext = thisYear >= start ? now.getFullYear() : now.getFullYear() + 1;
  return yearOfNext - parts.y;
}

function isValidIsoDate(value) {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value);
}

function isValidHhmm(value) {
  if (value == null) return false;
  const s = String(value).trim();
  return s === "" || /^\d{2}:\d{2}$/.test(s);
}

function normalizeCalendarPayload(body) {
  const title = String(body && body.title != null ? body.title : "").trim();
  const description = String(body && body.description != null ? body.description : "");
  const eventDate = String(body && body.event_date != null ? body.event_date : "").trim();
  const eventTime = String(body && body.event_time != null ? body.event_time : "").trim();
  const endDate = String(body && body.end_date != null ? body.end_date : "").trim();
  const endTime = String(body && body.end_time != null ? body.end_time : "").trim();
  const location = String(body && body.location != null ? body.location : "");
  const color = String(body && body.color != null ? body.color : "#2563eb").trim() || "#2563eb";
  const allDay = body && (body.all_day === 1 || body.all_day === true || body.all_day === "1") ? 1 : 0;
  let contactId = null;
  if (body && body.contact_id != null && body.contact_id !== "") {
    const n = Number(body.contact_id);
    contactId = Number.isInteger(n) && n > 0 ? n : null;
  }
  const recurrenceRaw = String(body && body.recurrence != null ? body.recurrence : "").trim().toLowerCase();
  const allowedRecurrence = new Set(["", "none", "daily", "weekly", "monthly", "yearly"]);
  const recurrence = allowedRecurrence.has(recurrenceRaw)
    ? recurrenceRaw === "none"
      ? ""
      : recurrenceRaw
    : "";
  return {
    title,
    description,
    event_date: eventDate,
    event_time: allDay ? "" : eventTime,
    end_date: endDate || eventDate,
    end_time: allDay ? "" : endTime,
    all_day: allDay,
    location,
    color,
    contact_id: contactId,
    recurrence
  };
}

function calendarValidationError(payload) {
  if (!payload.title) return "Title is required.";
  if (!isValidIsoDate(payload.event_date)) return "Event date must be YYYY-MM-DD.";
  if (payload.end_date && !isValidIsoDate(payload.end_date)) return "End date must be YYYY-MM-DD.";
  if (!isValidHhmm(payload.event_time)) return "Start time must be HH:MM (24h).";
  if (!isValidHhmm(payload.end_time)) return "End time must be HH:MM (24h).";
  return "";
}

async function fetchCalendarEventById(id) {
  return get(
    `SELECT id, title, description, event_date, event_time, end_date, end_time, all_day,
            location, color, contact_id, recurrence, google_event_id, google_calendar_id, google_synced_at,
            origin, created_at, updated_at
       FROM calendar_events WHERE id = ?`,
    [id]
  );
}

app.get("/api/calendar/events", async (req, res) => {
  try {
    const start = String(req.query.start || "").trim();
    const end = String(req.query.end || "").trim();
    if (!isValidIsoDate(start) || !isValidIsoDate(end)) {
      return res.status(400).json({ error: "start and end query params must be YYYY-MM-DD" });
    }
    const events = await all(
      `SELECT e.id, e.title, e.description, e.event_date, e.event_time, e.end_date, e.end_time,
              e.all_day, e.location, e.color, e.contact_id, e.recurrence, e.google_event_id, e.google_calendar_id,
              e.google_synced_at, e.origin, e.created_at, e.updated_at,
              COALESCE(c.full_name, '') AS contact_name
         FROM calendar_events e
         LEFT JOIN contacts c ON c.id = e.contact_id
         WHERE e.event_date BETWEEN ? AND ?
            OR (e.end_date != '' AND e.end_date BETWEEN ? AND ?)
            OR (e.event_date <= ? AND e.end_date >= ?)
            OR (COALESCE(e.recurrence, '') != '' AND e.event_date <= ?)
         ORDER BY e.event_date ASC,
                  CASE WHEN e.event_time = '' THEN 1 ELSE 0 END ASC,
                  e.event_time ASC,
                  e.id ASC`,
      [start, end, start, end, start, end, end]
    );
    const tasks = await all(
      `SELECT t.id, t.contact_id, t.task_name, t.action_type, t.task_date, t.task_time,
              t.condition, t.created_at, t.updated_at,
              COALESCE(c.full_name, '') AS contact_name
         FROM contact_tasks t
         LEFT JOIN contacts c ON c.id = t.contact_id
         WHERE t.task_date BETWEEN ? AND ?
         ORDER BY t.task_date ASC,
                  CASE WHEN COALESCE(t.task_time,'') = '' THEN 1 ELSE 0 END ASC,
                  t.task_time ASC,
                  t.id ASC`,
      [start, end]
    );
    const followUps = await all(
      `SELECT 'follow-up-' || c.id AS id,
              c.id AS contact_id,
              'Follow-up' AS task_name,
              'Follow Up' AS action_type,
              c.follow_up_date AS task_date,
              COALESCE(c.follow_up_time, '') AS task_time,
              'Yet to Start' AS condition,
              c.created_at,
              c.updated_at,
              COALESCE(c.full_name, '') AS contact_name,
              'follow_up' AS calendar_kind
         FROM contacts c
        WHERE trim(COALESCE(c.follow_up_date, '')) BETWEEN ? AND ?
        ORDER BY c.follow_up_date ASC,
                 CASE WHEN COALESCE(c.follow_up_time,'') = '' THEN 1 ELSE 0 END ASC,
                 c.follow_up_time ASC,
                 c.id ASC`,
      [start, end]
    );
    const renewalRows = await all(
      `SELECT id, full_name, email, phone, coverage_start_date, quote, coverages_sold,
              status, outcome, lead_source, annual_renewal, renewal_interval
         FROM contacts
        WHERE COALESCE(renewal_interval, '') IN ('3', '6', '12')
           OR (COALESCE(renewal_interval, '') = '' AND COALESCE(annual_renewal, '') = '1')`
    );
    const renewals = renewalsInDateRange(renewalRows, start, end).map((r) => ({
      id: r.id,
      contact_id: r.contact_id,
      task_name: r.renewal_interval === 12 ? "Annual renewal" : `${r.renewal_interval}-mo renewal`,
      action_type: "Renewal",
      task_date: r.next_renewal,
      task_time: "",
      condition: "Yet to Start",
      contact_name: r.full_name,
      coverages_sold: r.coverages_sold,
      calendar_kind: "renewal"
    }));
    const taggedTasks = (Array.isArray(tasks) ? tasks : []).map((t) => ({
      ...t,
      calendar_kind: "task"
    }));
    return res.json({
      events,
      tasks: taggedTasks,
      followUps,
      renewals,
      // Back-compat: older clients expected follow-ups merged into tasks
      items: [...taggedTasks, ...followUps, ...renewals]
    });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/calendar/events", async (req, res) => {
  try {
    const payload = normalizeCalendarPayload(req.body || {});
    const validationError = calendarValidationError(payload);
    if (validationError) return res.status(400).json({ error: validationError });
    const nowSec = Math.floor(Date.now() / 1000);
    const result = await run(
      `INSERT INTO calendar_events
         (title, description, event_date, event_time, end_date, end_time, all_day, location, color,
          contact_id, recurrence, origin, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'manual', ?, ?)`,
      [
        payload.title,
        payload.description,
        payload.event_date,
        payload.event_time,
        payload.end_date,
        payload.end_time,
        payload.all_day,
        payload.location,
        payload.color,
        payload.contact_id,
        payload.recurrence,
        nowSec,
        nowSec
      ]
    );
    const created = await fetchCalendarEventById(result.lastID);

    if (req.body && req.body.push_to_google) {
      try {
        const remote = await googleCalendar.pushEventToGoogle(created);
        if (remote && remote.id) {
          await run(
            `UPDATE calendar_events SET google_event_id = ?, google_synced_at = ?, updated_at = ?
             WHERE id = ?`,
            [String(remote.id), nowSec, nowSec, created.id]
          );
          const refreshed = await fetchCalendarEventById(created.id);
          return res.status(201).json(refreshed);
        }
      } catch (gErr) {
        return res.status(201).json({ ...created, google_push_error: gErr.message });
      }
    }
    return res.status(201).json(created);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.patch("/api/calendar/events/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const existing = await fetchCalendarEventById(id);
    if (!existing) return res.status(404).json({ error: "Event not found" });
    const payload = normalizeCalendarPayload({ ...existing, ...req.body });
    const validationError = calendarValidationError(payload);
    if (validationError) return res.status(400).json({ error: validationError });
    const nowSec = Math.floor(Date.now() / 1000);
    await run(
      `UPDATE calendar_events
         SET title = ?, description = ?, event_date = ?, event_time = ?, end_date = ?, end_time = ?,
             all_day = ?, location = ?, color = ?, contact_id = ?, recurrence = ?, updated_at = ?
       WHERE id = ?`,
      [
        payload.title,
        payload.description,
        payload.event_date,
        payload.event_time,
        payload.end_date,
        payload.end_time,
        payload.all_day,
        payload.location,
        payload.color,
        payload.contact_id,
        payload.recurrence,
        nowSec,
        id
      ]
    );
    let updated = await fetchCalendarEventById(id);
    if (existing.google_event_id) {
      try {
        await googleCalendar.pushEventToGoogle(updated);
        await run(
          `UPDATE calendar_events SET google_synced_at = ?, updated_at = ? WHERE id = ?`,
          [nowSec, nowSec, id]
        );
        updated = await fetchCalendarEventById(id);
      } catch (_e) {
        // sync failure is non-fatal for the local update
      }
    }
    return res.json(updated);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.delete("/api/calendar/events/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const existing = await fetchCalendarEventById(id);
    if (!existing) return res.status(404).json({ error: "Event not found" });
    if (existing.google_event_id) {
      try {
        await googleCalendar.deleteGoogleEvent(existing.google_event_id);
      } catch (_e) {
        // ignore remote delete failure; local delete still proceeds
      }
    }
    await run(`DELETE FROM calendar_events WHERE id = ?`, [id]);
    return res.json({ ok: true });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/google/calendar/status", async (_req, res) => {
  try {
    const status = await googleCalendar.getStatus();
    return res.json(status);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/google/calendar/auth-url", async (req, res) => {
  try {
    if (!googleCalendar.isConfigured()) {
      return res.status(400).json({
        error: "Google OAuth is not configured. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in .env."
      });
    }
    const returnTo = String(req.query.next || "/calendar.html").trim() || "/calendar.html";
    const url = await googleCalendar.buildAuthUrl(req, returnTo);
    if (!url) {
      return res.status(500).json({ error: "Could not build Google sign-in URL." });
    }
    return res.json({ url });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/google/calendar/callback", async (req, res) => {
  try {
    const code = String(req.query.code || "");
    const state = String(req.query.state || "");
    const errorParam = String(req.query.error || "");
    if (errorParam) {
      return res.redirect(
        `/calendar.html?google_error=${encodeURIComponent(errorParam)}`
      );
    }
    if (!code) return res.status(400).send("Missing authorization code.");
    const meta = googleCalendar.consumeState(state);
    if (!meta) {
      return res.status(400).send("Invalid or expired OAuth state. Please try connecting again.");
    }
    const redirectUri = googleCalendar.getRedirectUri(req);
    const tokenData = await googleCalendar.exchangeCodeForTokens(code, redirectUri);
    const accountEmail = tokenData.access_token
      ? await googleCalendar.fetchUserEmail(tokenData.access_token)
      : "";
    await googleCalendar.saveTokens(tokenData, accountEmail);
    const returnTo = meta.returnTo && meta.returnTo.startsWith("/") ? meta.returnTo : "/calendar.html";
    const sep = returnTo.includes("?") ? "&" : "?";
    return res.redirect(`${returnTo}${sep}google_connected=1`);
  } catch (error) {
    return res
      .status(500)
      .send(`Google Calendar connection failed: ${String(error.message || error)}`);
  }
});

app.post("/api/google/calendar/disconnect", async (_req, res) => {
  try {
    await googleCalendar.disconnect();
    return res.json({ ok: true });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/google/calendar/sync", async (req, res) => {
  try {
    const status = await googleCalendar.getStatus();
    if (!status.connected) {
      return res.status(400).json({ error: "Google Calendar is not connected." });
    }
    const start = String((req.body && req.body.start) || req.query.start || "").trim();
    const end = String((req.body && req.body.end) || req.query.end || "").trim();
    if (!isValidIsoDate(start) || !isValidIsoDate(end)) {
      return res.status(400).json({ error: "start and end (YYYY-MM-DD) are required." });
    }
    const timeMinIso = `${start}T00:00:00.000Z`;
    const timeMaxIso = `${end}T23:59:59.999Z`;
    const remoteItems = await googleCalendar.listGoogleEventsInRange(timeMinIso, timeMaxIso);
    let imported = 0;
    let updated = 0;
    let pushed = 0;
    const nowSec = Math.floor(Date.now() / 1000);

    for (const item of remoteItems) {
      if (!item || !item.id) continue;
      if (item.status === "cancelled") {
        await run(`DELETE FROM calendar_events WHERE google_event_id = ?`, [String(item.id)]);
        continue;
      }
      const local = googleCalendar.googleEventToLocalRow(item);
      if (!local || !local.event_date) continue;
      const existing = await get(
        `SELECT id FROM calendar_events WHERE google_event_id = ?`,
        [local.google_event_id]
      );
      if (existing) {
        await run(
          `UPDATE calendar_events
             SET title = ?, description = ?, event_date = ?, event_time = ?, end_date = ?, end_time = ?,
                 all_day = ?, location = ?, color = ?, google_synced_at = ?, origin = 'google',
                 updated_at = ?
           WHERE id = ?`,
          [
            local.title,
            local.description,
            local.event_date,
            local.event_time,
            local.end_date,
            local.end_time,
            local.all_day,
            local.location,
            local.color,
            nowSec,
            nowSec,
            existing.id
          ]
        );
        updated += 1;
      } else {
        await run(
          `INSERT INTO calendar_events
             (title, description, event_date, event_time, end_date, end_time, all_day, location, color,
              google_event_id, google_calendar_id, google_synced_at, origin, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'google', ?, ?)`,
          [
            local.title,
            local.description,
            local.event_date,
            local.event_time,
            local.end_date,
            local.end_time,
            local.all_day,
            local.location,
            local.color,
            local.google_event_id,
            local.google_calendar_id,
            nowSec,
            nowSec,
            nowSec
          ]
        );
        imported += 1;
      }
    }

    const localManual = await all(
      `SELECT * FROM calendar_events
        WHERE origin = 'manual'
          AND (google_event_id IS NULL OR google_event_id = '')
          AND event_date BETWEEN ? AND ?`,
      [start, end]
    );
    for (const localEvent of localManual) {
      try {
        const remote = await googleCalendar.pushEventToGoogle(localEvent);
        if (remote && remote.id) {
          await run(
            `UPDATE calendar_events
               SET google_event_id = ?, google_calendar_id = ?, google_synced_at = ?, updated_at = ?
             WHERE id = ?`,
            [String(remote.id), "primary", nowSec, nowSec, localEvent.id]
          );
          pushed += 1;
        }
      } catch (_pushErr) {
        // skip push errors per event; surface aggregate counts only
      }
    }

    await googleCalendar.setLastSyncAt(nowSec);
    return res.json({ ok: true, imported, updated, pushed });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/contacts", async (req, res) => {
  try {
    const {
      full_name,
      email,
      phone,
      status = "NEW",
      tags = "",
      notes = "",
      special_notes: specialNotesBody = "",
      app_id: appIdBody = "",
      lead_source: leadSourceBody = ""
    } = req.body;
    if (!full_name) return res.status(400).json({ error: "full_name is required" });
    const special_notes = String(specialNotesBody == null ? "" : specialNotesBody);
    const app_id = String(appIdBody == null ? "" : appIdBody);
    const lead_source = String(leadSourceBody == null ? "" : leadSourceBody);

    const result = await run(
      `INSERT INTO contacts (full_name, email, phone, status, tags, notes, special_notes, app_id, lead_source, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`,
      [full_name, email, phone, status, tags, notes, special_notes, app_id, lead_source]
    );
    const created = await get("SELECT * FROM contacts WHERE id = ?", [result.lastID]);
    try {
      await rememberTags({ get, run }, parseTagList(tags));
    } catch (e) {
      console.error("Remember contact tags (create):", e);
    }
    try {
      await logContactActivity(
        created.id,
        "detail_change",
        `Created Date: (empty) -> ${String(created.created_at || new Date().toISOString())}`
      );
    } catch (e) {
      console.error("Contact history (create):", e);
    }
    try {
      await maybeEnrollFromContactTags(dbDeps(), created.id, "", created.tags || "");
    } catch (e) {
      console.error("Tag campaign enroll (create contact):", e);
    }
    scheduleAutoLeadScore(dbDeps(), created.id, "contact_created");
    res.status(201).json(created);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/contacts/import-csv", async (req, res) => {
  try {
    const { csv } = req.body || {};
    if (typeof csv !== "string" || !csv.trim()) {
      return res.status(400).json({ error: "csv string is required in JSON body" });
    }

    const columnMapping =
      req.body?.columnMapping && typeof req.body.columnMapping === "object" ? req.body.columnMapping : null;
    const mappings = Array.isArray(req.body?.mappings) ? req.body.mappings : null;
    const mappingObj =
      columnMapping ||
      (mappings ? columnMappingObject(mappings) : null);
    const preserveCsvCreatedDates = req.body?.preserveCsvCreatedDates === true;
    const createdAtMapped = createdAtMappedInColumnMapping(mappingObj);

    const { contacts, parseErrors } = parseContactsCsv(csv, mappingObj && Object.keys(mappingObj).length ? mappingObj : undefined);
    if (!contacts.length && !parseErrors.length) {
      return res.status(400).json({ error: "CSV contains no data rows" });
    }
    if (parseErrors.length && !contacts.length) {
      return res.status(400).json({ error: "No valid rows to import", details: parseErrors });
    }

    const countRow = await get(`SELECT COUNT(*) AS n FROM contacts`);
    const isFirstEverImport = Number(countRow?.n || 0) === 0;
    const existingBookRaw = req.body?.existingBookImport;
    const treatAsExistingBook =
      existingBookRaw === true ||
      existingBookRaw === "true" ||
      (existingBookRaw !== false && existingBookRaw !== "false" && isFirstEverImport);

    let imported = 0;
    const importedContactIds = [];
    for (const row of contacts) {
      const tags = treatAsExistingBook ? mergeInitialImportTag(row.tags) : row.tags;
      const { fragment: createdAtSql, params: createdAtParam } = resolveImportCreatedAtSql(row, {
        preserveCsvCreatedDates,
        createdAtMapped
      });
      const result = await run(
        `INSERT INTO contacts (
          full_name, email, phone, secondary_phone, status, tags, notes, special_notes,
          app_id,
          age, gender, household_size, income, lead_source, communication_type,
          date_of_contact, outcome, date_of_birth, coverages_sold, profession, quote,
          health_issues, coverage_start_date, policy_renewal, bank_routing, bank_account, vcall, insurance_type, commission,
          home_address, city, state, zip_code, indian, last_called, last_emailed,
          created_at, updated_at
        )
         VALUES (
          ?, ?, ?, ?, ?, ?, ?, ?,
          ?,
          ?, ?, ?, ?, ?, ?,
          ?, ?, ?, ?, ?, ?,
          ?, ?, ?, ?, ?, ?, ?, ?,
          ?, ?, ?, ?, ?, ?, ?,
          ${createdAtSql}, CURRENT_TIMESTAMP
         )`,
        [
          row.full_name,
          row.email,
          row.phone,
          row.secondary_phone,
          row.status,
          tags,
          row.notes,
          row.special_notes,
          row.app_id,
          row.age,
          row.gender,
          row.household_size,
          row.income,
          row.lead_source,
          row.communication_type,
          row.date_of_contact,
          row.outcome,
          row.date_of_birth,
          row.coverages_sold,
          row.profession,
          row.quote,
          row.health_issues,
          row.coverage_start_date,
          row.policy_renewal,
          row.bank_routing,
          row.bank_account,
          row.vcall,
          row.insurance_type,
          row.commission,
          row.home_address,
          row.city,
          row.state,
          row.zip_code,
          row.indian,
          row.last_called,
          row.last_emailed,
          ...createdAtParam
        ]
      );
      if (result?.lastID) importedContactIds.push(result.lastID);
      imported += 1;
    }

    importedContactIds.forEach((contactId) => {
      scheduleAutoLeadScore(dbDeps(), contactId, "csv_import");
    });

    if (treatAsExistingBook && imported > 0) {
      await activateInitialImportOmit(run, imported);
    }

    res.status(201).json({
      imported,
      skipped: parseErrors.length,
      details: parseErrors.length ? parseErrors : undefined,
      initialImportOmit:
        treatAsExistingBook && imported > 0
          ? { active: true, permanent: true, importedCount: imported }
          : undefined
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.patch("/api/contacts/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const existing = await get("SELECT * FROM contacts WHERE id = ?", [id]);
    if (!existing) return res.status(404).json({ error: "Contact not found" });
    const updatableFields = [
      "full_name",
      "middle_name",
      "email",
      "phone",
      "secondary_phone",
      "status",
      "tags",
      "notes",
      "special_notes",
      "app_id",
      "age",
      "gender",
      "household_size",
      "income",
      "lead_source",
      "communication_type",
      "date_of_contact",
      "outcome",
      "date_of_birth",
      "coverages_sold",
      "profession",
      "quote",
      "health_issues",
      "coverage_start_date",
      "policy_renewal",
      "annual_renewal",
      "renewal_interval",
      "bank_routing",
      "bank_account",
      "height",
      "weight",
      "ssn_last4",
      "vcall",
      "insurance_type",
      "commission",
      "home_address",
      "city",
      "state",
      "zip_code",
      "indian",
      "follow_up_date",
      "follow_up_time",
      "do_not_email",
      "custom_fields"
    ];
    const next = {};
    for (const field of updatableFields) {
      if (req.body && Object.prototype.hasOwnProperty.call(req.body, field)) {
        next[field] = req.body[field];
      } else {
        next[field] = existing[field];
      }
    }
    if (Object.prototype.hasOwnProperty.call(req.body || {}, "custom_fields")) {
      const parsed = parseContactCustomFieldValues(req.body.custom_fields);
      next.custom_fields = JSON.stringify(parsed);
    } else {
      next.custom_fields = existing.custom_fields || "";
    }
    if (Object.prototype.hasOwnProperty.call(req.body || {}, "household_members")) {
      next.household_members = JSON.stringify(normalizeHouseholdMembers(req.body.household_members));
    } else {
      next.household_members = existing.household_members || "";
    }
    if (Object.prototype.hasOwnProperty.call(req.body || {}, "quotes")) {
      const quotes = normalizeContactQuotes(req.body.quotes);
      next.quotes = JSON.stringify(quotes);
      const premium = currentQuotePremium(quotes);
      if (premium) next.quote = premium;
    } else {
      next.quotes = existing.quotes || "";
    }
    /* Reminder kind is derived (day_of when date set, else none). Clearing date clears time. */
    const intervalRaw = String(next.renewal_interval || "").trim();
    if (intervalRaw === "3" || intervalRaw === "6" || intervalRaw === "12") {
      next.renewal_interval = intervalRaw;
    } else if (String(next.annual_renewal || "") === "1") {
      next.renewal_interval = "12";
    } else {
      next.renewal_interval = "";
    }
    next.annual_renewal = next.renewal_interval === "12" ? "1" : "";
    next.do_not_email = String(next.do_not_email || "") === "1" ? "1" : "";
    const fuTrim = String(next.follow_up_date == null ? "" : next.follow_up_date).trim();
    if (!fuTrim) {
      next.follow_up_time = "";
    }
    next.follow_up_reminder = normalizeFollowUpReminder(fuTrim ? "day_of" : "none");
    next.middle_name = String(next.middle_name == null ? "" : next.middle_name).trim().slice(0, 80);
    if (!String(next.full_name || "").trim()) {
      return res.status(400).json({ error: "full_name is required" });
    }
    const detailChangeCompareFields = [...updatableFields, "follow_up_reminder", "household_members", "quotes"];
    const changedFields = [];
    for (const field of detailChangeCompareFields) {
      const prevVal = String(existing[field] == null ? "" : existing[field]).trim();
      const nextVal = String(next[field] == null ? "" : next[field]).trim();
      if (prevVal !== nextVal) changedFields.push(field);
    }
    await run(
      `UPDATE contacts
       SET full_name = ?, middle_name = ?, email = ?, phone = ?, secondary_phone = ?, status = ?, tags = ?, notes = ?, special_notes = ?,
           app_id = ?, age = ?, gender = ?, household_size = ?, income = ?, lead_source = ?, communication_type = ?,
           date_of_contact = ?, outcome = ?, date_of_birth = ?, coverages_sold = ?, profession = ?, quote = ?,
           health_issues = ?, coverage_start_date = ?, policy_renewal = ?, annual_renewal = ?, renewal_interval = ?, bank_routing = ?, bank_account = ?,
           height = ?, weight = ?, ssn_last4 = ?,
           vcall = ?, insurance_type = ?, commission = ?,
           home_address = ?, city = ?, state = ?, zip_code = ?, indian = ?, do_not_email = ?,
           custom_fields = ?, household_members = ?, quotes = ?,
           follow_up_date = ?, follow_up_time = ?, follow_up_reminder = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`,
      [
        next.full_name,
        next.middle_name,
        next.email,
        next.phone,
        next.secondary_phone,
        next.status,
        next.tags,
        next.notes,
        next.special_notes,
        next.app_id,
        next.age,
        next.gender,
        next.household_size,
        next.income,
        next.lead_source,
        next.communication_type,
        next.date_of_contact,
        next.outcome,
        next.date_of_birth,
        next.coverages_sold,
        next.profession,
        next.quote,
        next.health_issues,
        next.coverage_start_date,
        next.policy_renewal,
        next.annual_renewal,
        next.renewal_interval,
        encryptField(next.bank_routing),
        encryptField(next.bank_account),
        next.height,
        next.weight,
        encryptField(next.ssn_last4),
        next.vcall,
        next.insurance_type,
        next.commission,
        next.home_address,
        next.city,
        next.state,
        next.zip_code,
        next.indian,
        next.do_not_email,
        next.custom_fields,
        next.household_members,
        next.quotes,
        next.follow_up_date,
        next.follow_up_time,
        next.follow_up_reminder,
        id
      ]
    );

    if (changedFields.includes("tags")) {
      await run(`UPDATE contacts SET last_tagged = CURRENT_TIMESTAMP WHERE id = ?`, [id]);
      try {
        await rememberTags({ get, run }, parseTagList(next.tags));
      } catch (e) {
        console.error("Remember contact tags (update):", e);
      }
    }
    const updated = await get("SELECT * FROM contacts WHERE id = ?", [id]);
    const skipDetailHistory = new Set(["follow_up_reminder", "household_members", "quotes"]);
    if (changedFields.length) {
      for (const field of changedFields) {
        if (skipDetailHistory.has(field)) continue;
        const beforeValue = String(existing[field] == null ? "" : existing[field]).trim() || "(empty)";
        const afterValue = String(next[field] == null ? "" : next[field]).trim() || "(empty)";
        await logContactActivity(id, "detail_change", `${prettyFieldName(field)}: ${beforeValue} -> ${afterValue}`);
      }
      if (changedFields.includes("household_members")) {
        const count = normalizeHouseholdMembers(next.household_members).length;
        await logContactActivity(id, "detail_change", `Household: ${count} member${count === 1 ? "" : "s"}`);
      }
      if (changedFields.includes("quotes")) {
        const count = normalizeContactQuotes(next.quotes).length;
        await logContactActivity(id, "detail_change", `Quotes: ${count} quote${count === 1 ? "" : "s"}`);
      }
    }
    if (
      changedFields.includes("outcome") &&
      isSoldOutcomeValue(next.outcome) &&
      !isSoldOutcomeValue(existing.outcome)
    ) {
      await stampOutcomeSoldAt(id);
    }
    if (changedFields.includes("tags")) {
      try {
        await maybeEnrollFromContactTags(dbDeps(), id, existing.tags || "", next.tags || "");
      } catch (e) {
        console.error("Tag campaign enroll (patch contact):", e);
      }
    }
    const aiScoreTriggerFields = new Set([
      "status",
      "outcome",
      "tags",
      "notes",
      "special_notes",
      "lead_source",
      "quote",
      "household_size",
      "income",
      "communication_type",
      "date_of_contact",
      "health_issues",
      "coverage_start_date"
    ]);
    if (changedFields.some((field) => aiScoreTriggerFields.has(field))) {
      scheduleAutoLeadScore(dbDeps(), id, "contact_updated");
    }
    res.json(withContactJsonFields(decryptContactBankFields(updated)));
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/contacts/bulk-update", async (req, res) => {
  try {
    const contactIds = parseContactIds(req.body && req.body.contactIds);
    if (!contactIds.length) return res.status(400).json({ error: "contactIds is required" });
    const body = req.body || {};
    const hasStatus = Object.prototype.hasOwnProperty.call(body, "status");
    const hasOutcome = Object.prototype.hasOwnProperty.call(body, "outcome");
    const hasLeadSource = Object.prototype.hasOwnProperty.call(body, "lead_source");
    const status = hasStatus ? String(body.status == null ? "" : body.status).trim() : null;
    const outcome = hasOutcome ? String(body.outcome == null ? "" : body.outcome).trim() : null;
    const lead_source = hasLeadSource ? String(body.lead_source == null ? "" : body.lead_source).trim() : null;
    const addTagsRaw = body.addTags != null ? String(body.addTags) : "";
    const removeTagsRaw = body.removeTags != null ? String(body.removeTags) : "";
    const addTags = parseTagList(addTagsRaw);
    const removeTags = parseTagList(removeTagsRaw);
    if (addTags.length) {
      try {
        await rememberTags({ get, run }, addTags);
      } catch (e) {
        console.error("Remember contact tags (bulk-update):", e);
      }
    }

    let updated = 0;
    const placeholders = contactIds.map(() => "?").join(",");
    const existingRows = await all(
      `SELECT id, tags, status, outcome, lead_source FROM contacts WHERE id IN (${placeholders})`,
      contactIds
    );
    const existingById = new Map(existingRows.map((r) => [Number(r.id), r]));

    for (const id of contactIds) {
      const existing = existingById.get(Number(id));
      if (!existing) continue;
      const prevTags = String(existing.tags || "");
      const nextTags = mergeTags(existing.tags, addTags, removeTags);
      const st = hasStatus ? status : String(existing.status || "");
      const oc = hasOutcome ? outcome : String(existing.outcome || "");
      const ls = hasLeadSource ? lead_source : String(existing.lead_source || "");
      if (prevTags !== nextTags) {
        await run(
          `UPDATE contacts
           SET status = ?, outcome = ?, lead_source = ?, tags = ?, updated_at = CURRENT_TIMESTAMP, last_tagged = CURRENT_TIMESTAMP
           WHERE id = ?`,
          [st, oc, ls, nextTags, id]
        );
        const addedTags = getAddedTags(prevTags, nextTags);
        if (addedTags.length) {
          const beforeValue = String(prevTags || "").trim() || "(empty)";
          const afterValue = String(nextTags || "").trim() || "(empty)";
          await logContactActivity(id, "detail_change", `Tags: ${beforeValue} -> ${afterValue}`);
        }
      } else {
        await run(
          `UPDATE contacts SET status = ?, outcome = ?, lead_source = ?, tags = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
          [st, oc, ls, nextTags, id]
        );
      }
      if (hasOutcome) {
        const beforeValue = String(existing.outcome == null ? "" : existing.outcome).trim() || "(empty)";
        const afterValue = String(oc == null ? "" : oc).trim() || "(empty)";
        if (beforeValue !== afterValue) {
          await logContactActivity(id, "detail_change", `${prettyFieldName("outcome")}: ${beforeValue} -> ${afterValue}`);
          if (isSoldOutcomeValue(afterValue) && !isSoldOutcomeValue(beforeValue)) {
            await stampOutcomeSoldAt(id);
          }
        }
      }
      if (hasLeadSource) {
        const beforeValue = String(existing.lead_source == null ? "" : existing.lead_source).trim() || "(empty)";
        const afterValue = String(ls == null ? "" : ls).trim() || "(empty)";
        if (beforeValue !== afterValue) {
          await logContactActivity(id, "detail_change", `${prettyFieldName("lead_source")}: ${beforeValue} -> ${afterValue}`);
        }
      }
      /** Run enroll check whenever tags changed OR bulk added tokens (covers spacing/order edge cases). */
      const shouldTryTagEnrollment = prevTags !== nextTags || addTags.length > 0;
      if (shouldTryTagEnrollment) {
        try {
          await maybeEnrollFromContactTags(dbDeps(), id, prevTags, nextTags, {
            explicitAddedTokens: addTags.length ? addTags : undefined
          });
        } catch (e) {
          console.error("Tag campaign enroll (bulk-update):", e);
        }
      }
      scheduleAutoLeadScore(dbDeps(), id, "bulk_contact_update");
      updated += 1;
    }
    res.json({ updated });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/contacts/bulk-delete", async (req, res) => {
  try {
    const contactIds = parseContactIds(req.body && req.body.contactIds);
    if (!contactIds.length) return res.status(400).json({ error: "contactIds is required" });
    const placeholders = contactIds.map(() => "?").join(",");
    // Recycle bin: snapshot each contact before deleting so it can be restored for 30 days.
    try {
      const snapshotRows = await all(`SELECT * FROM contacts WHERE id IN (${placeholders})`, contactIds);
      for (const c of Array.isArray(snapshotRows) ? snapshotRows : []) {
        await run(
          `INSERT INTO deleted_contacts (original_id, full_name, email, payload) VALUES (?, ?, ?, ?)`,
          [Number(c.id) || null, String(c.full_name || ""), String(c.email || ""), JSON.stringify(c)]
        );
      }
    } catch (archiveErr) {
      console.error("Recycle bin archive failed (continuing with delete):", archiveErr);
    }
    await run(
      `DELETE FROM drip_send_queue
       WHERE enrollment_id IN (SELECT id FROM drip_enrollments WHERE contact_id IN (${placeholders}))`,
      contactIds
    );
    await run(`DELETE FROM drip_enrollments WHERE contact_id IN (${placeholders})`, contactIds);
    await run(`DELETE FROM contact_tasks WHERE contact_id IN (${placeholders})`, contactIds);
    await run(`DELETE FROM contact_activity WHERE contact_id IN (${placeholders})`, contactIds);
    await run(`DELETE FROM follow_up_reminder_sent WHERE contact_id IN (${placeholders})`, contactIds);
    await run(`DELETE FROM call_recordings WHERE contact_id IN (${placeholders})`, contactIds);
    const result = await run(`DELETE FROM contacts WHERE id IN (${placeholders})`, contactIds);
    res.json({ deleted: result.changes || 0 });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ── Recycle bin: restore a contact deleted in the last 30 days ─────────────────
app.post("/api/contacts/deleted/restore", async (req, res) => {
  try {
    const ids = parseContactIds(req.body && req.body.ids);
    if (!ids.length) return res.status(400).json({ error: "ids is required" });
    const placeholders = ids.map(() => "?").join(",");
    const rows = await all(`SELECT * FROM deleted_contacts WHERE id IN (${placeholders})`, ids);
    const colInfo = await all(`PRAGMA table_info(contacts)`);
    const validCols = new Set(
      (Array.isArray(colInfo) ? colInfo : []).map((c) => c.name).filter((n) => n && n !== "id")
    );
    let restored = 0;
    for (const row of Array.isArray(rows) ? rows : []) {
      let data;
      try {
        data = JSON.parse(row.payload || "{}");
      } catch {
        data = null;
      }
      if (!data || typeof data !== "object") continue;
      const cols = Object.keys(data).filter((k) => validCols.has(k));
      if (!cols.length) continue;
      const ph = cols.map(() => "?").join(",");
      await run(`INSERT INTO contacts (${cols.join(",")}) VALUES (${ph})`, cols.map((c) => data[c]));
      restored += 1;
    }
    if (rows && rows.length) {
      await run(`DELETE FROM deleted_contacts WHERE id IN (${placeholders})`, ids);
    }
    res.json({ restored });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

function contactsExportQueryParams(req) {
  const query = req.query && typeof req.query === "object" ? req.query : {};
  const body = req.body && typeof req.body === "object" && !Array.isArray(req.body) ? req.body : {};
  if (req.method === "POST") return { ...query, ...body };
  return query;
}

async function handleContactsExportCsv(req, res) {
  try {
    const {
      q = "",
      status = "",
      outcome = "",
      segment = "",
      tagFilter = "",
      tagTerm = "",
      statusLabelMode = "",
      statusLabelTerm = "",
      outcomeLabelMode = "",
      outcomeLabelTerm = "",
      leadSourceMode = "",
      leadSourceTerm = "",
      indianMode = "",
      indianTerm = "",
      indianSortFirst = "",
      qfField = "",
      qfMode = "",
      qfTerm = "",
      tags = "",
      createdFrom = "",
      createdTo = "",
      soldFrom = "",
      soldTo = "",
      closedFrom = "",
      closedTo = "",
      dateRangeType = "",
      contactState = "",
      contactIds = "",
      contactViewSegment = "",
      sortBy = "created_at",
      sortOrder = "desc",
      countFrom = "",
      countTo = ""
    } = contactsExportQueryParams(req);
    const filterState = String(contactState || "").trim();
    const like = `%${q}%`;
    const seg = contactsSegmentClause(segment);
    const tagFrag = contactsTagFilterClause(tagFilter, tagTerm);
    const statusFilterFrag = contactsDropdownFieldFilterClause("status", status);
    const outcomeFilterFrag = contactsDropdownFieldFilterClause("outcome", outcome);
    const statusLabelFrag = contactsLabelFilterClause("status", statusLabelMode, statusLabelTerm);
    const outcomeLabelFrag = contactsLabelFilterClause("outcome", outcomeLabelMode, outcomeLabelTerm);
    const leadSourceFrag = contactsLabelFilterClause("lead_source", leadSourceMode, leadSourceTerm);
    const indianFrag = contactsLabelFilterClause("indian", indianMode, indianTerm);
    const genericQuickFilterFrag = contactsGenericQuickFilterClause(qfField, qfMode, qfTerm);
    const headerTagFrag = contactsHeaderTagClause(tags);
    const { createdRangeFrag, soldRangeFrag, closedRangeFrag } = contactsDateFilterFragments({
      createdFrom,
      createdTo,
      soldFrom,
      soldTo,
      closedFrom,
      closedTo,
      dateRangeType,
      soldIdColumn: "id",
      useSoldAtColumn: !req._soldAtColumnDisabled
    });
    const viewSegmentFrag = contactsViewSegmentClause(contactViewSegment);
    const contactIdsFilter = parseContactIds(contactIds);
    const contactIdsClause = contactIdsFilter.length
      ? ` AND id IN (${contactIdsFilter.map(() => "?").join(",")})`
      : "";
    const orderBy = buildContactsListOrderBy({
      sortBy,
      sortOrder,
      indianMode,
      indianSortFirst,
      idColumn: "id",
      indianColumn: "indian",
      useSoldAtColumn: !req._soldAtColumnDisabled
    });
    const exportWhere = `FROM contacts
       WHERE (full_name LIKE ? OR email LIKE ? OR phone LIKE ? OR COALESCE(notes,'') LIKE ? OR COALESCE(special_notes,'') LIKE ?)
       ${statusFilterFrag.sql}
       ${outcomeFilterFrag.sql}
       ${seg.sql}
       ${tagFrag.sql}
       ${statusLabelFrag.sql}
       ${outcomeLabelFrag.sql}
       ${leadSourceFrag.sql}
       ${indianFrag.sql}
       ${genericQuickFilterFrag.sql}
       ${headerTagFrag.sql}
       ${createdRangeFrag.sql}
       ${soldRangeFrag.sql}
       ${closedRangeFrag.sql}
       ${viewSegmentFrag.sql}
       ${contactIdsClause}
       AND (? = '' OR LOWER(TRIM(COALESCE(state,''))) = LOWER(TRIM(?)))`;
    const exportParams = [
      like,
      like,
      like,
      like,
      like,
      ...statusFilterFrag.params,
      ...outcomeFilterFrag.params,
      ...seg.params,
      ...tagFrag.params,
      ...statusLabelFrag.params,
      ...outcomeLabelFrag.params,
      ...leadSourceFrag.params,
      ...indianFrag.params,
      ...genericQuickFilterFrag.params,
      ...headerTagFrag.params,
      ...createdRangeFrag.params,
      ...soldRangeFrag.params,
      ...closedRangeFrag.params,
      ...viewSegmentFrag.params,
      ...contactIdsFilter,
      filterState,
      filterState
    ];
    let exportLimitSql = "";
    const exportLimitParams = [];
    if (parseContactCountBound(countFrom) != null || parseContactCountBound(countTo) != null) {
      const totalRow = await get(`SELECT COUNT(*) AS total ${exportWhere}`, exportParams);
      const matchedTotal = totalRow ? Number(totalRow.total || 0) : 0;
      const countWindow = contactCountWindow(countFrom, countTo, matchedTotal);
      if (countWindow) {
        exportLimitSql = " LIMIT ? OFFSET ?";
        exportLimitParams.push(countWindow.limit, countWindow.offset);
      }
    }
    const rows = await all(
      `SELECT id, full_name, email, phone, status, tags, notes, special_notes, app_id, created_at, updated_at
       ${exportWhere}
       ORDER BY ${orderBy}${exportLimitSql}`,
      [...exportParams, ...exportLimitParams]
    );
    const escapeCsv = (v) => {
      const s = String(v == null ? "" : v);
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const header = [
      "id",
      "full_name",
      "email",
      "phone",
      "status",
      "tags",
      "notes",
      "special_notes",
      "app_id",
      "created_at",
      "updated_at"
    ];
    const lines = [header.join(",")];
    for (const row of rows) {
      lines.push(header.map((key) => escapeCsv(row[key])).join(","));
    }
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="contacts-export.csv"`);
    res.send(lines.join("\n"));
  } catch (error) {
    const missingSoldAt = /no such column: .*outcome_sold_at/i.test(String(error && error.message ? error.message : error));
    if (missingSoldAt && !req._soldAtFilterRetry) {
      req._soldAtFilterRetry = 1;
      try {
        await ensureContactColumns();
      } catch (_) {
        req._soldAtColumnDisabled = true;
      }
      return handleContactsExportCsv(req, res);
    }
    if (missingSoldAt && req._soldAtFilterRetry === 1) {
      req._soldAtFilterRetry = 2;
      req._soldAtColumnDisabled = true;
      return handleContactsExportCsv(req, res);
    }
    res.status(500).json({ error: error.message });
  }
}

app.post("/api/contacts/bulk-send-email", async (req, res) => {
  try {
    const contactIds = parseContactIds(req.body && req.body.contactIds);
    const subject = req.body && req.body.subject != null ? String(req.body.subject) : "";
    const text = req.body && req.body.text != null ? String(req.body.text) : "";
    const attachmentIds = Array.isArray(req.body && req.body.attachmentIds)
      ? [...new Set(req.body.attachmentIds.map((n) => Number(n)).filter((n) => Number.isInteger(n) && n > 0))]
      : [];
    if (!contactIds.length) return res.status(400).json({ error: "contactIds is required" });

    let attachments = [];
    if (attachmentIds.length) {
      const placeholders = attachmentIds.map(() => "?").join(",");
      const docs = await all(`SELECT id, file_name, mime_type, storage_path FROM documents WHERE id IN (${placeholders})`, attachmentIds);
      attachments = docs
        .map((d) => {
          const diskPath = resolveStoredUploadPath(d.storage_path, "documents", d.file_name);
          if (!diskPath) return null;
          return {
            filename: d.file_name,
            path: diskPath,
            contentType: d.mime_type || undefined
          };
        })
        .filter(Boolean);
    }

    let sent = 0;
    let skipped = 0;
    for (const id of contactIds) {
      const contact = await get("SELECT id, email FROM contacts WHERE id = ?", [id]);
      if (!contact || !contact.email) {
        skipped += 1;
        continue;
      }
      await sendEmail({ to: contact.email, subject, text, attachments });
      await run(`UPDATE contacts SET last_emailed = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [id]);
      await logContactActivity(contact.id, "email", `Sent email: ${subject || "(no subject)"}`);
      sent += 1;
    }
    res.json({ sent, skipped });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/email/options", async (req, res) => {
  try {
    const options = [];
    const detailed = [];
    const seen = new Set();
    const pushIf = (v, source, label, id) => {
      const t = String(v || "").trim();
      if (!t) return;
      const key = t.toLowerCase();
      if (seen.has(key)) return;
      seen.add(key);
      options.push(t);
      detailed.push({
        email: t,
        label: String(label || "").trim(),
        source: String(source || ""),
        id: id == null ? null : Number(id)
      });
    };
    if (!isTrialWorkspaceSession(req)) {
      pushIf(process.env.SMTP_FROM, "smtp_from", "");
      pushIf(process.env.SMTP_USER, "smtp_user", "");
    }
    try {
      const rows = await all(
        `SELECT id, email_address, label, smtp_host FROM email_from_addresses ORDER BY created_at ASC, id ASC`
      );
      for (const row of Array.isArray(rows) ? rows : []) {
        const before = detailed.length;
        pushIf(row?.email_address, "custom", row?.label, row?.id);
        const emailKey = String(row?.email_address || "").trim().toLowerCase();
        const entry =
          detailed.length > before
            ? detailed[detailed.length - 1]
            : detailed.find((item) => String(item?.email || "").trim().toLowerCase() === emailKey);
        if (entry && String(row?.smtp_host || "").trim()) entry.hasSmtp = true;
      }
    } catch {
      // table may not yet exist on old DBs; env-only fallback
    }
    return res.json({ fromOptions: options, fromAddresses: detailed });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

function serializeFromAddressRow(row) {
  if (!row) return null;
  const port = row.smtp_port == null ? null : Number(row.smtp_port);
  return {
    id: Number(row.id),
    email: String(row.email_address || ""),
    label: String(row.label || ""),
    smtpHost: String(row.smtp_host || ""),
    smtpPort: Number.isFinite(port) && port > 0 ? port : null,
    smtpSecure: Number(row.smtp_secure || 0) === 1,
    smtpUser: String(row.smtp_user || ""),
    hasSmtpPass: Boolean(String(row.smtp_pass || "").length),
    replyTo: String(row.reply_to || ""),
    created_at: Number(row.created_at || 0)
  };
}

app.get("/api/email/from-addresses", async (req, res) => {
  try {
    const rows = await all(
      `SELECT id, email_address, label, smtp_host, smtp_port, smtp_secure, smtp_user, smtp_pass, reply_to, created_at
       FROM email_from_addresses
       ORDER BY created_at ASC, id ASC`
    );
    res.json((Array.isArray(rows) ? rows : []).map(serializeFromAddressRow));
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

function isLikelyValidEmail(value) {
  const s = String(value || "").trim();
  if (!s || s.length > 254) return false;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
}

app.post("/api/email/from-addresses", async (req, res) => {
  try {
    const email = String(req.body?.email || "").trim();
    const label = String(req.body?.label || "").trim();
    if (!isLikelyValidEmail(email)) {
      return res.status(400).json({ error: "Valid email address is required." });
    }
    const ins = await run(
      `INSERT INTO email_from_addresses (email_address, label) VALUES (?, ?)`,
      [email, label]
    );
    const row = await get(
      `SELECT id, email_address, label, smtp_host, smtp_port, smtp_secure, smtp_user, smtp_pass, reply_to, created_at
       FROM email_from_addresses WHERE id = ?`,
      [ins.lastID]
    );
    res.status(201).json(serializeFromAddressRow(row));
  } catch (error) {
    if (String(error?.message || "").toLowerCase().includes("unique")) {
      return res.status(409).json({ error: "Email address already exists." });
    }
    res.status(500).json({ error: error.message });
  }
});

app.patch("/api/email/from-addresses/:id/smtp", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const existing = await get(`SELECT * FROM email_from_addresses WHERE id = ?`, [id]);
    if (!existing) return res.status(404).json({ error: "Email address not found" });

    const body = req.body || {};
    const host = body.smtpHost == null ? existing.smtp_host : String(body.smtpHost || "").trim();
    const userName = body.smtpUser == null ? existing.smtp_user : String(body.smtpUser || "").trim();
    const replyTo = body.replyTo == null ? existing.reply_to : String(body.replyTo || "").trim();
    let port;
    if (body.smtpPort === null || body.smtpPort === "") {
      port = null;
    } else if (body.smtpPort === undefined) {
      port = existing.smtp_port == null ? null : Number(existing.smtp_port);
    } else {
      const n = Number(body.smtpPort);
      if (!Number.isFinite(n) || n < 1 || n > 65535) {
        return res.status(400).json({ error: "smtpPort must be a number between 1 and 65535." });
      }
      port = Math.floor(n);
    }
    const secure = body.smtpSecure == null ? Number(existing.smtp_secure || 0) : body.smtpSecure ? 1 : 0;
    let pass;
    if (body.clearPassword) {
      pass = "";
    } else if (typeof body.smtpPass === "string") {
      pass = body.smtpPass;
    } else {
      pass = String(existing.smtp_pass || "");
    }

    if (replyTo && !isLikelyValidEmail(replyTo)) {
      return res.status(400).json({ error: "Reply email is not a valid address." });
    }

    if (host && !userName) {
      return res.status(400).json({ error: "User name is required when an SMTP server is set." });
    }

    await run(
      `UPDATE email_from_addresses
         SET smtp_host = ?, smtp_port = ?, smtp_secure = ?, smtp_user = ?, smtp_pass = ?, reply_to = ?
       WHERE id = ?`,
      [host, port, secure, userName, pass, replyTo, id]
    );

    const row = await get(
      `SELECT id, email_address, label, smtp_host, smtp_port, smtp_secure, smtp_user, smtp_pass, reply_to, created_at
       FROM email_from_addresses WHERE id = ?`,
      [id]
    );
    invalidatePerAddressTransporters(existing.email_address);
    res.json(serializeFromAddressRow(row));
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.patch("/api/email/from-addresses/:id/label", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const label = String(req.body?.label || "").trim();
    const result = await run(`UPDATE email_from_addresses SET label = ? WHERE id = ?`, [label, id]);
    if (!result.changes) return res.status(404).json({ error: "Email address not found" });
    res.json({ ok: true, id, label });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete("/api/email/from-addresses/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const result = await run(`DELETE FROM email_from_addresses WHERE id = ?`, [id]);
    if (!result.changes) return res.status(404).json({ error: "Email address not found" });
    res.json({ ok: true, id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Automatic bounce processing — owner-only visibility + manual trigger.
app.get("/api/bounces/status", async (req, res) => {
  if (!isOwnerWorkspaceSession(req)) return res.status(403).json({ error: "Owner only." });
  try {
    await ensureBounceSchema(run);
    const total = await get(`SELECT COUNT(*) AS c FROM email_bounces`);
    const supp = await get(`SELECT COUNT(*) AS c FROM email_bounces WHERE suppressed = 1`);
    const recent = await all(
      `SELECT email, code, hard, suppressed, created_at FROM email_bounces ORDER BY id DESC LIMIT 25`
    );
    res.json({
      configured: bounceConfig().configured,
      lastRun: getBounceLastRun(),
      totalBounces: total ? total.c : 0,
      suppressed: supp ? supp.c : 0,
      recent: recent || []
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/bounces/run", async (req, res) => {
  if (!isOwnerWorkspaceSession(req)) return res.status(403).json({ error: "Owner only." });
  try {
    const result = await runBounceProcessing({ run, all, get });
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * Custom merge fields are user-defined `{{slug}}` tokens (agent name, license #,
 * holiday wishes, etc.) that should resolve everywhere built-in merge fields
 * do: composed email, drip steps, template previews. Keys are stored as their
 * canonical slug (e.g. "agent_license_number") and can be referenced by users
 * with any whitespace/case combination.
 */
function serializeCustomMergeFieldRow(row) {
  if (!row || typeof row !== "object") return null;
  return {
    id: Number(row.id),
    field_key: String(row.field_key || ""),
    field_value: String(row.field_value == null ? "" : row.field_value),
    label: String(row.label || ""),
    field_scope: normalizeMergeFieldScope(row.field_scope),
    created_at: row.created_at != null ? Number(row.created_at) : null,
    updated_at: row.updated_at != null ? Number(row.updated_at) : null
  };
}

app.get("/api/custom-merge-fields", async (req, res) => {
  try {
    const rows = await all(
      `SELECT id, field_key, field_value, label, field_scope, created_at, updated_at
       FROM custom_merge_fields
       ORDER BY field_scope COLLATE NOCASE ASC, field_key COLLATE NOCASE ASC, id ASC`
    );
    res.json(
      (Array.isArray(rows) ? rows : [])
        .map(serializeCustomMergeFieldRow)
        .filter((row) => {
          if (!row) return false;
          const slug = normalizeMergeKey(row.field_key);
          return !RESERVED_MERGE_FIELD_KEYS.has(slug) && !isPolicyRenewalMergeSlug(slug);
        })
    );
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/custom-merge-fields", async (req, res) => {
  try {
    const body = req.body || {};
    const rawKey = String(body.field_key == null ? body.key : body.field_key);
    const slug = normalizeMergeKey(rawKey);
    if (!slug) {
      return res.status(400).json({ error: "Field key is required (letters, numbers, spaces, underscores)." });
    }
    if (slug.length > 64) {
      return res.status(400).json({ error: "Field key must be 64 characters or fewer." });
    }
    if (RESERVED_MERGE_FIELD_KEYS.has(slug) || isPolicyRenewalMergeSlug(slug)) {
      return res.status(400).json({ error: `"${slug}" is a built-in merge field and cannot be redefined.` });
    }
    const value =
      normalizeMergeFieldScope(body.field_scope) === "contact"
        ? ""
        : String(body.field_value == null ? body.value || "" : body.field_value);
    const label = String(body.label == null ? "" : body.label).trim();
    const fieldScope = normalizeMergeFieldScope(body.field_scope);
    const now = Math.floor(Date.now() / 1000);
    const ins = await run(
      `INSERT INTO custom_merge_fields (field_key, field_value, label, field_scope, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [slug, value, label, fieldScope, now, now]
    );
    const row = await get(
      `SELECT id, field_key, field_value, label, field_scope, created_at, updated_at
       FROM custom_merge_fields WHERE id = ?`,
      [ins.lastID]
    );
    res.status(201).json(serializeCustomMergeFieldRow(row));
  } catch (error) {
    if (String(error?.message || "").toLowerCase().includes("unique")) {
      return res.status(409).json({ error: "A merge field with that key already exists." });
    }
    res.status(500).json({ error: error.message });
  }
});

app.patch("/api/custom-merge-fields/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const existing = await get(`SELECT * FROM custom_merge_fields WHERE id = ?`, [id]);
    if (!existing) return res.status(404).json({ error: "Custom merge field not found" });
    const body = req.body || {};

    let slug = existing.field_key;
    if (body.field_key !== undefined || body.key !== undefined) {
      const next = normalizeMergeKey(body.field_key == null ? body.key : body.field_key);
      if (!next) return res.status(400).json({ error: "Field key is required." });
      if (next.length > 64) return res.status(400).json({ error: "Field key must be 64 characters or fewer." });
      if (RESERVED_MERGE_FIELD_KEYS.has(next) || isPolicyRenewalMergeSlug(next)) {
        return res.status(400).json({ error: `"${next}" is a built-in merge field and cannot be redefined.` });
      }
      slug = next;
    }

    const fieldScope =
      body.field_scope === undefined
        ? normalizeMergeFieldScope(existing.field_scope)
        : normalizeMergeFieldScope(body.field_scope);
    const value =
      body.field_value === undefined && body.value === undefined
        ? existing.field_value
        : String(body.field_value == null ? body.value || "" : body.field_value);
    const label =
      body.label === undefined ? String(existing.label || "") : String(body.label || "").trim();
    const storedValue = fieldScope === "contact" ? "" : value;
    const now = Math.floor(Date.now() / 1000);
    await run(
      `UPDATE custom_merge_fields
         SET field_key = ?, field_value = ?, label = ?, field_scope = ?, updated_at = ?
       WHERE id = ?`,
      [slug, storedValue, label, fieldScope, now, id]
    );
    const row = await get(
      `SELECT id, field_key, field_value, label, field_scope, created_at, updated_at
       FROM custom_merge_fields WHERE id = ?`,
      [id]
    );
    res.json(serializeCustomMergeFieldRow(row));
  } catch (error) {
    if (String(error?.message || "").toLowerCase().includes("unique")) {
      return res.status(409).json({ error: "A merge field with that key already exists." });
    }
    res.status(500).json({ error: error.message });
  }
});

app.delete("/api/custom-merge-fields/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const result = await run(`DELETE FROM custom_merge_fields WHERE id = ?`, [id]);
    if (!result.changes) return res.status(404).json({ error: "Custom merge field not found" });
    res.json({ ok: true, id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/email/templates", async (req, res) => {
  try {
    const rows = await all(
      `SELECT et.id, et.name, et.subject, et.body, et.category_id, etc.name AS category_name, et.created_at
       FROM email_templates et
       LEFT JOIN email_template_categories etc ON etc.id = et.category_id
       ORDER BY et.created_at DESC, et.id DESC`
    );
    return res.json(rows);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/email/template-categories", async (req, res) => {
  try {
    const rows = await all(
      `SELECT id, name
       FROM email_template_categories
       ORDER BY LOWER(name) ASC, id ASC`
    );
    return res.json(rows);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/email/template-categories", async (req, res) => {
  try {
    const name = String((req.body && req.body.name) || "").trim();
    if (!name) return res.status(400).json({ error: "name is required" });
    const existingCategory = await get(
      `SELECT id, name FROM email_template_categories WHERE LOWER(name) = LOWER(?)`,
      [name]
    );
    if (existingCategory) {
      return res.json(existingCategory);
    }
    const result = await run(`INSERT INTO email_template_categories (name) VALUES (?)`, [name]);
    const created = await get(`SELECT id, name FROM email_template_categories WHERE id = ?`, [result.lastID]);
    return res.status(201).json(created);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/email/templates/seed-paradigmai-outreach", async (req, res) => {
  if (rejectUnlessOwnerWorkspace(req, res)) return;
  try {
    const result = await seedParadigmaiOutreachTemplates({ run, get });
    return res.json({ ok: true, ...result });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Could not add Paradigmai templates." });
  }
});

app.post("/api/email/templates/seed-cadence-outreach", async (req, res) => {
  if (rejectUnlessOwnerWorkspace(req, res)) return;
  try {
    const result = await seedCadenceOutreachTemplates({ run, get });
    return res.json({ ok: true, ...result });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Could not add Cadence outreach templates." });
  }
});

app.post("/api/email/templates", async (req, res) => {
  try {
    const name = String((req.body && req.body.name) || "").trim();
    const subject = String((req.body && req.body.subject) || "").trim();
    const body = String((req.body && req.body.body) || "").trim();
    const categoryName = String((req.body && req.body.category_name) || "").trim();
    if (!name) return res.status(400).json({ error: "name is required" });
    if (!subject) return res.status(400).json({ error: "subject is required" });
    if (!body) return res.status(400).json({ error: "body is required" });
    let categoryId = null;
    if (categoryName) {
      const existingCategory = await get(
        `SELECT id, name FROM email_template_categories WHERE LOWER(name) = LOWER(?)`,
        [categoryName]
      );
      if (existingCategory) {
        categoryId = Number(existingCategory.id);
      } else {
        const createdCategory = await run(`INSERT INTO email_template_categories (name) VALUES (?)`, [categoryName]);
        categoryId = Number(createdCategory.lastID);
      }
    }
    const result = await run(
      `INSERT INTO email_templates (name, subject, body, category_id) VALUES (?, ?, ?, ?)`,
      [name, subject, body, categoryId]
    );
    const created = await get(
      `SELECT et.id, et.name, et.subject, et.body, et.category_id, etc.name AS category_name, et.created_at
       FROM email_templates et
       LEFT JOIN email_template_categories etc ON etc.id = et.category_id
       WHERE et.id = ?`,
      [result.lastID]
    );
    return res.status(201).json(created);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.put("/api/email/templates/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const existingTemplate = await get(`SELECT id FROM email_templates WHERE id = ?`, [id]);
    if (!existingTemplate) return res.status(404).json({ error: "Template not found" });

    const name = String((req.body && req.body.name) || "").trim();
    const subject = String((req.body && req.body.subject) || "").trim();
    const body = String((req.body && req.body.body) || "").trim();
    const categoryName = String((req.body && req.body.category_name) || "").trim();
    if (!name) return res.status(400).json({ error: "name is required" });
    if (!subject) return res.status(400).json({ error: "subject is required" });
    if (!body) return res.status(400).json({ error: "body is required" });

    let categoryId = null;
    if (categoryName) {
      const existingCategory = await get(
        `SELECT id, name FROM email_template_categories WHERE LOWER(name) = LOWER(?)`,
        [categoryName]
      );
      if (existingCategory) {
        categoryId = Number(existingCategory.id);
      } else {
        const createdCategory = await run(`INSERT INTO email_template_categories (name) VALUES (?)`, [categoryName]);
        categoryId = Number(createdCategory.lastID);
      }
    }

    await run(
      `UPDATE email_templates SET name = ?, subject = ?, body = ?, category_id = ? WHERE id = ?`,
      [name, subject, body, categoryId, id]
    );
    const updated = await get(
      `SELECT et.id, et.name, et.subject, et.body, et.category_id, etc.name AS category_name, et.created_at
       FROM email_templates et
       LEFT JOIN email_template_categories etc ON etc.id = et.category_id
       WHERE et.id = ?`,
      [id]
    );
    return res.json(updated);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.delete("/api/email/templates/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const result = await run(`DELETE FROM email_templates WHERE id = ?`, [id]);
    if (!result.changes) return res.status(404).json({ error: "Template not found" });
    return res.json({ ok: true });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/landing-pages", async (req, res) => {
  try {
    const rows = await all(
      `SELECT id, name, website_url, landing_page_url, platform, notes, created_at, updated_at
       FROM landing_pages
       ORDER BY updated_at DESC, id DESC`
    );
    return res.json(rows);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/landing-pages", async (req, res) => {
  try {
    const name = String((req.body && req.body.name) || "").trim();
    const websiteUrl = String((req.body && req.body.websiteUrl) || "").trim();
    const landingPageUrl = String((req.body && req.body.landingPageUrl) || "").trim();
    const platform = String((req.body && req.body.platform) || "").trim();
    const notes = String((req.body && req.body.notes) || "").trim();
    if (!name) return res.status(400).json({ error: "name is required" });
    const result = await run(
      `INSERT INTO landing_pages (name, website_url, landing_page_url, platform, notes, updated_at)
       VALUES (?, ?, ?, ?, ?, CAST(strftime('%s','now') AS INTEGER))`,
      [name, websiteUrl, landingPageUrl, platform, notes]
    );
    const created = await get(
      `SELECT id, name, website_url, landing_page_url, platform, notes, created_at, updated_at
       FROM landing_pages WHERE id = ?`,
      [result.lastID]
    );
    return res.status(201).json(created);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.put("/api/landing-pages/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const existing = await get(`SELECT id FROM landing_pages WHERE id = ?`, [id]);
    if (!existing) return res.status(404).json({ error: "Landing page record not found" });
    const name = String((req.body && req.body.name) || "").trim();
    const websiteUrl = String((req.body && req.body.websiteUrl) || "").trim();
    const landingPageUrl = String((req.body && req.body.landingPageUrl) || "").trim();
    const platform = String((req.body && req.body.platform) || "").trim();
    const notes = String((req.body && req.body.notes) || "").trim();
    if (!name) return res.status(400).json({ error: "name is required" });
    await run(
      `UPDATE landing_pages
       SET name = ?, website_url = ?, landing_page_url = ?, platform = ?, notes = ?,
           updated_at = CAST(strftime('%s','now') AS INTEGER)
       WHERE id = ?`,
      [name, websiteUrl, landingPageUrl, platform, notes, id]
    );
    const updated = await get(
      `SELECT id, name, website_url, landing_page_url, platform, notes, created_at, updated_at
       FROM landing_pages WHERE id = ?`,
      [id]
    );
    return res.json(updated);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.delete("/api/landing-pages/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const result = await run(`DELETE FROM landing_pages WHERE id = ?`, [id]);
    if (!result.changes) return res.status(404).json({ error: "Landing page record not found" });
    return res.json({ ok: true });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

function parseHostedVideoUrl(rawUrl) {
  const raw = String(rawUrl || "").trim();
  if (!raw) return null;
  let u;
  try {
    u = new URL(raw);
  } catch {
    return null;
  }
  if (!/^https?:$/i.test(u.protocol)) return null;
  const host = u.hostname.toLowerCase().replace(/^www\./, "");

  if (host === "youtu.be") {
    const videoId = u.pathname.replace(/^\//, "").split(/[/?#]/)[0];
    if (!videoId) return null;
    return {
      provider: "youtube",
      videoId,
      thumbnailUrl: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
      canonicalUrl: raw
    };
  }
  if (host === "youtube.com" || host === "m.youtube.com" || host === "music.youtube.com") {
    let videoId = u.searchParams.get("v");
    if (!videoId) {
      const m = u.pathname.match(/\/(?:shorts|embed|live)\/([^/?#]+)/);
      videoId = m && m[1];
    }
    if (!videoId) return null;
    return {
      provider: "youtube",
      videoId,
      thumbnailUrl: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
      canonicalUrl: raw
    };
  }

  if (host === "vimeo.com" || host.endsWith(".vimeo.com")) {
    const m = u.pathname.match(/\/(\d+)(?:\/|$|[?#])/);
    const videoId = m && m[1];
    if (!videoId) return null;
    return { provider: "vimeo", videoId, thumbnailUrl: null, canonicalUrl: raw };
  }
  if (host === "player.vimeo.com") {
    const videoId = u.pathname.replace(/^\//, "").split("/")[0];
    if (!/^\d+$/.test(videoId)) return null;
    return {
      provider: "vimeo",
      videoId,
      thumbnailUrl: null,
      canonicalUrl: `https://vimeo.com/${videoId}`
    };
  }

  if (host === "loom.com" || host.endsWith(".loom.com")) {
    const m = u.pathname.match(/\/(?:share|embed)\/([a-zA-Z0-9]+)/);
    const videoId = m && m[1];
    if (!videoId) return null;
    return {
      provider: "loom",
      videoId,
      thumbnailUrl: `https://cdn.loom.com/sessions/thumbnails/${videoId}-with-play.jpg`,
      canonicalUrl: `https://www.loom.com/share/${videoId}`
    };
  }

  const path = u.pathname || "";
  if (/\.(mp4|webm|ogg|ogv|mov|m4v|avi|mkv|wmv|mpeg|mpg|3gp|3g2)(\?.*)?$/i.test(path)) {
    return { provider: "direct", videoId: null, thumbnailUrl: null, canonicalUrl: raw };
  }

  return null;
}

const HOSTED_VIDEO_URL_ERROR =
  "Unsupported video URL. Supports YouTube, Vimeo, Loom, and direct video links (.mp4, .mov, .webm).";

app.get("/api/videos", async (req, res) => {
  try {
    const rows = await all(
      `SELECT id, title, source_type, video_url, file_name, mime_type, size_bytes, notes, created_at
       FROM videos
       ORDER BY created_at DESC, id DESC`
    );
    return res.json(rows);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/videos", async (req, res) => {
  try {
    const title = String((req.body && req.body.title) || "").trim();
    const videoUrl = String((req.body && req.body.videoUrl) || "").trim();
    const notes = String((req.body && req.body.notes) || "").trim();
    if (!title) return res.status(400).json({ error: "title is required" });
    if (!videoUrl) return res.status(400).json({ error: "videoUrl is required" });
    const parsed = parseHostedVideoUrl(videoUrl);
    if (!parsed) return res.status(400).json({ error: HOSTED_VIDEO_URL_ERROR });
    const result = await run(
      `INSERT INTO videos (title, source_type, video_url, notes)
       VALUES (?, 'url', ?, ?)`,
      [title, parsed.canonicalUrl || videoUrl, notes]
    );
    const created = await get(
      `SELECT id, title, source_type, video_url, file_name, mime_type, size_bytes, notes, created_at
       FROM videos WHERE id = ?`,
      [result.lastID]
    );
    return res.status(201).json(created);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/videos/upload", (req, res, next) => {
  pcVideoUpload.single("video")(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message || "Upload failed" });
    next();
  });
}, async (req, res) => {
  try {
    const title = String((req.body && req.body.title) || "").trim();
    const notes = String((req.body && req.body.notes) || "").trim();
    if (!title) return res.status(400).json({ error: "title is required" });
    if (!req.file) return res.status(400).json({ error: "video file is required" });
    let mimeType = String(req.file.mimetype || "").trim();
    if (!mimeType || mimeType === "application/octet-stream") {
      mimeType = guessVideoMimeFromFilename(req.file.originalname) || "video/mp4";
    }
    const displayName = String(req.file.originalname || "video").replace(/[<>:"/\\|?*\x00-\x1F]/g, "_");
    const result = await run(
      `INSERT INTO videos (title, source_type, file_name, mime_type, storage_path, size_bytes, notes)
       VALUES (?, 'file', ?, ?, ?, ?, ?)`,
      [title, displayName, mimeType, toRelativeUploadPath("videos", req.file), req.file.size, notes]
    );
    const created = await get(
      `SELECT id, title, source_type, video_url, file_name, mime_type, size_bytes, notes, created_at
       FROM videos WHERE id = ?`,
      [result.lastID]
    );
    return res.status(201).json(created);
  } catch (error) {
    if (req.file && req.file.path && fs.existsSync(req.file.path)) {
      try {
        fs.unlinkSync(req.file.path);
      } catch {
        /* ignore */
      }
    }
    return res.status(500).json({ error: error.message });
  }
});

app.patch("/api/videos/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const title = String((req.body && req.body.title) || "").trim();
    if (!title) return res.status(400).json({ error: "title is required" });
    const row = await get(`SELECT id FROM videos WHERE id = ?`, [id]);
    if (!row) return res.status(404).json({ error: "Video not found" });
    await run(`UPDATE videos SET title = ? WHERE id = ?`, [title, id]);
    const updated = await get(
      `SELECT id, title, source_type, video_url, file_name, mime_type, size_bytes, notes, created_at
       FROM videos WHERE id = ?`,
      [id]
    );
    return res.json(updated);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/videos/:id/stream", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const row = await get(`SELECT * FROM videos WHERE id = ?`, [id]);
    if (!row) return res.status(404).json({ error: "Video not found" });
    if (String(row.source_type) !== "file") return res.status(400).json({ error: "Only file videos can be streamed" });
    const filePath = resolveStoredUploadPath(row.storage_path, "videos", row.file_name);
    if (!filePath) return res.status(404).json({ error: "Stored video file not found" });
    const stat = fs.statSync(filePath);
    const fileSize = stat.size;
    const contentType = row.mime_type || "video/mp4";
    const range = req.headers.range;
    if (range) {
      const parts = String(range).replace(/bytes=/, "").split("-");
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
      if (Number.isNaN(start) || Number.isNaN(end) || start > end || start >= fileSize) {
        res.status(416).setHeader("Content-Range", `bytes */${fileSize}`);
        return res.end();
      }
      const safeEnd = Math.min(end, fileSize - 1);
      const chunkSize = safeEnd - start + 1;
      res.writeHead(206, {
        "Content-Range": `bytes ${start}-${safeEnd}/${fileSize}`,
        "Accept-Ranges": "bytes",
        "Content-Length": chunkSize,
        "Content-Type": contentType
      });
      fs.createReadStream(filePath, { start, end: safeEnd }).pipe(res);
      return;
    }
    res.writeHead(200, {
      "Content-Length": fileSize,
      "Content-Type": contentType,
      "Accept-Ranges": "bytes"
    });
    fs.createReadStream(filePath).pipe(res);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.delete("/api/videos/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const row = await get(`SELECT * FROM videos WHERE id = ?`, [id]);
    if (!row) return res.status(404).json({ error: "Video not found" });
    await run(`DELETE FROM videos WHERE id = ?`, [id]);
    if (String(row.source_type) === "file" && row.storage_path) {
      const diskPath = resolveStoredUploadPath(row.storage_path, "videos", row.file_name);
      if (diskPath) fs.unlinkSync(diskPath);
    }
    return res.json({ ok: true });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/forms", async (req, res) => {
  try {
    const rows = await all(
      `SELECT id, title, source_type, form_url, file_name, mime_type, size_bytes, notes, created_at
       FROM saved_forms
       ORDER BY created_at DESC, id DESC`
    );
    return res.json(rows);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/forms", async (req, res) => {
  try {
    const title = String((req.body && req.body.title) || "").trim();
    const formUrl = String((req.body && req.body.formUrl) || "").trim();
    const notes = String((req.body && req.body.notes) || "").trim();
    if (!title) return res.status(400).json({ error: "title is required" });
    if (!formUrl) return res.status(400).json({ error: "formUrl is required" });
    const result = await run(
      `INSERT INTO saved_forms (title, source_type, form_url, notes)
       VALUES (?, 'url', ?, ?)`,
      [title, formUrl, notes]
    );
    const created = await get(
      `SELECT id, title, source_type, form_url, file_name, mime_type, size_bytes, notes, created_at
       FROM saved_forms WHERE id = ?`,
      [result.lastID]
    );
    return res.status(201).json(created);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/forms/upload", (req, res, next) => {
  pcFormUpload.single("form")(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message || "Upload failed" });
    next();
  });
}, async (req, res) => {
  try {
    const title = String((req.body && req.body.title) || "").trim();
    const notes = String((req.body && req.body.notes) || "").trim();
    if (!title) return res.status(400).json({ error: "title is required" });
    if (!req.file) return res.status(400).json({ error: "form file is required" });
    let mimeType = String(req.file.mimetype || "").trim();
    if (!mimeType || mimeType === "application/octet-stream") {
      mimeType = guessFormMimeFromFilename(req.file.originalname) || "application/octet-stream";
    }
    const displayName = String(req.file.originalname || "form").replace(/[<>:"/\\|?*\x00-\x1F]/g, "_");
    const result = await run(
      `INSERT INTO saved_forms (title, source_type, form_url, file_name, mime_type, storage_path, size_bytes, notes)
       VALUES (?, 'file', '', ?, ?, ?, ?, ?)`,
      [title, displayName, mimeType, toRelativeUploadPath("forms", req.file), req.file.size, notes]
    );
    const created = await get(
      `SELECT id, title, source_type, form_url, file_name, mime_type, size_bytes, notes, created_at
       FROM saved_forms WHERE id = ?`,
      [result.lastID]
    );
    return res.status(201).json(created);
  } catch (error) {
    if (req.file && req.file.path && fs.existsSync(req.file.path)) {
      try {
        fs.unlinkSync(req.file.path);
      } catch {
        /* ignore */
      }
    }
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/forms/:id/download", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const row = await get(`SELECT * FROM saved_forms WHERE id = ?`, [id]);
    if (!row) return res.status(404).json({ error: "Form not found" });
    if (String(row.source_type) !== "file") return res.status(400).json({ error: "Only uploaded files can be downloaded" });
    const diskPath = resolveStoredUploadPath(row.storage_path, "forms", row.file_name);
    if (!diskPath) return res.status(404).json({ error: "Stored file not found" });
    const safeName = String(row.file_name || "form").replace(/"/g, "");
    res.setHeader("Content-Type", row.mime_type || "application/octet-stream");
    res.setHeader("Content-Disposition", `attachment; filename="${safeName}"`);
    return res.sendFile(diskPath);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.delete("/api/forms/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const row = await get(`SELECT * FROM saved_forms WHERE id = ?`, [id]);
    if (!row) return res.status(404).json({ error: "Form not found" });
    await run(`DELETE FROM saved_forms WHERE id = ?`, [id]);
    if (String(row.source_type) === "file" && row.storage_path) {
      const diskPath = resolveStoredUploadPath(row.storage_path, "forms", row.file_name);
      if (diskPath) fs.unlinkSync(diskPath);
    }
    return res.json({ ok: true });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/email/send", async (req, res) => {
  try {
    const to = String((req.body && req.body.to) || "").trim();
    const cc = String((req.body && req.body.cc) || "").trim();
    const from = String((req.body && req.body.from) || "").trim();
    let subject = String((req.body && req.body.subject) || "").trim();
    let text = String((req.body && req.body.text) || "").trim();
    let html = String((req.body && req.body.html) || "").trim();
    const enableTracking = true;
    const templateId = Number(req.body && req.body.templateId);
    const attachmentIds = Array.isArray(req.body && req.body.attachmentIds)
      ? [...new Set(req.body.attachmentIds.map((n) => Number(n)).filter((n) => Number.isInteger(n) && n > 0))]
      : [];
    const directAttachments = Array.isArray(req.body && req.body.directAttachments) ? req.body.directAttachments : [];
    if (!to) return res.status(400).json({ error: "to is required" });

    if (Number.isInteger(templateId) && templateId > 0) {
      const tpl = await get(`SELECT subject, body FROM email_templates WHERE id = ?`, [templateId]);
      if (!tpl) return res.status(404).json({ error: "Template not found" });
      const tplSubject = String(tpl.subject || "");
      const tplBody = String(tpl.body || "");
      if (!subject.trim()) subject = tplSubject;
      const hadText = Boolean(text.trim());
      if (!hadText && tplBody) text = tplBody;
      const hadHtml = Boolean(html.trim());
      if (!hadText && tplBody) {
        const tplHtml = templateBodyToHtml(tplBody);
        if (!hadHtml) html = tplHtml;
        else html = `${tplHtml}<br><br>${html}`;
      }
    }
    if (!text.trim() && !html.trim()) return res.status(400).json({ error: "text or html is required" });

    let attachments = [];
    if (attachmentIds.length) {
      const placeholders = attachmentIds.map(() => "?").join(",");
      const docs = await all(`SELECT file_name, mime_type, storage_path FROM documents WHERE id IN (${placeholders})`, attachmentIds);
      attachments = docs
        .map((d) => {
          const diskPath = resolveStoredUploadPath(d.storage_path, "documents", d.file_name);
          if (!diskPath) return null;
          return {
            filename: d.file_name,
            path: diskPath,
            contentType: d.mime_type || undefined
          };
        })
        .filter(Boolean);
    }

    if (directAttachments.length) {
      const parsedDirect = [];
      for (const item of directAttachments) {
        if (!item || typeof item !== "object") continue;
        const fileName = String(item.fileName || "").trim();
        const mimeType = String(item.mimeType || "application/octet-stream").trim();
        const contentBase64 = String(item.contentBase64 || "").trim();
        if (!fileName || !contentBase64) continue;
        const buffer = Buffer.from(contentBase64, "base64");
        if (!buffer.length) continue;
        if (buffer.length > 10 * 1024 * 1024) {
          return res.status(400).json({ error: `Local attachment too large: ${fileName} (max 10MB each)` });
        }
        const safeName = fileName.replace(/[<>:"/\\|?*\x00-\x1F]/g, "_");
        parsedDirect.push({
          filename: safeName,
          content: buffer,
          contentType: mimeType || undefined
        });
      }
      attachments = [...attachments, ...parsedDirect];
    }

    const fromExplicit = recipientEmailsFromBody(req.body);
    const allRecipients = fromExplicit.length
      ? fromExplicit
      : [...splitEmailAddresses(to), ...splitEmailAddresses(cc)];
    let uniqueRecipients = [...new Set(allRecipients)];
    if (!uniqueRecipients.length) {
      return res.status(400).json({ error: "to is required" });
    }
    /* Hard stop for contacts flagged "Do Not Email" — opt-outs must be impossible
       to override from this endpoint (CAN-SPAM). */
    let skippedDoNotEmail = [];
    {
      const lowered = uniqueRecipients.map((e) => String(e).trim().toLowerCase());
      const ph = lowered.map(() => "?").join(",");
      const blockedRows = await all(
        `SELECT DISTINCT lower(trim(email)) AS em FROM contacts
         WHERE COALESCE(do_not_email, '') = '1' AND lower(trim(email)) IN (${ph})`,
        lowered
      );
      const blocked = new Set((Array.isArray(blockedRows) ? blockedRows : []).map((r) => String(r.em)));
      if (blocked.size) {
        skippedDoNotEmail = uniqueRecipients.filter((e) => blocked.has(String(e).trim().toLowerCase()));
        uniqueRecipients = uniqueRecipients.filter((e) => !blocked.has(String(e).trim().toLowerCase()));
      }
    }
    if (!uniqueRecipients.length) {
      return res.status(400).json({
        error:
          skippedDoNotEmail.length === 1
            ? `Not sent — this contact has "Do Not Email" set: ${skippedDoNotEmail[0]}`
            : `Not sent — all recipients have "Do Not Email" set: ${skippedDoNotEmail.join(", ")}`
      });
    }
    const envFromFallback = isTrialWorkspaceSession(req)
      ? ""
      : String(process.env.SMTP_FROM || process.env.SMTP_USER || "").trim();
    const resolvedFromForBulk = String(from || envFromFallback).trim();
    const useBccBulk = uniqueRecipients.length >= 2;
    if (useBccBulk && !resolvedFromForBulk) {
      return res.status(400).json({
        error:
          "Sending to two or more recipients hides addresses using Bcc. Choose a From address (or set SMTP_FROM / SMTP_USER) so that address appears as the only visible To recipient."
      });
    }
    let smtpTo = to;
    let smtpCc = cc || undefined;
    let smtpBcc;
    if (useBccBulk) {
      smtpTo = resolvedFromForBulk;
      smtpCc = undefined;
      smtpBcc = uniqueRecipients.join(", ");
    } else if (skippedDoNotEmail.length) {
      // Some recipients were filtered out; the raw to/cc strings still contain
      // them, so address the remaining recipient(s) explicitly.
      smtpTo = uniqueRecipients.join(", ");
      smtpCc = undefined;
    }
    const primaryRecipientRaw = uniqueRecipients[0] || "";
    const primaryRecipient = (() => {
      const s = String(primaryRecipientRaw || "").trim();
      const angled = s.match(/<([^>]+@[^>]+)>/);
      if (angled) return String(angled[1] || "").trim();
      const found = s.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
      return found ? String(found[0] || "").trim() : s;
    })();
    const mergeContactId = Number(req.body && req.body.contactId);
    let mergeContactRow = null;
    if (Number.isInteger(mergeContactId) && mergeContactId > 0) {
      mergeContactRow = await get(`SELECT * FROM contacts WHERE id = ?`, [mergeContactId]);
    }
    if (!mergeContactRow && primaryRecipient) {
      mergeContactRow = await get(`SELECT * FROM contacts WHERE lower(trim(email)) = lower(trim(?))`, [primaryRecipient]);
    }
    const customRows = await all(`SELECT field_key, field_value, field_scope FROM custom_merge_fields ORDER BY field_key`);
    const customFields = {};
    for (const row of customRows) {
      const key = normalizeMergeKey(row?.field_key);
      if (!key) continue;
      if (normalizeMergeFieldScope(row?.field_scope) === "contact") continue;
      customFields[key] = String(row?.field_value ?? "");
    }
    const mergeBase = mergeContactRow
      ? contactRowToMergeFields(mergeContactRow, primaryRecipient)
      : primaryRecipient
        ? contactRowToMergeFields({}, primaryRecipient)
        : {};
    const authSession = getAuthSession(req);
    const outboundTenantId = authSession?.tenantId || LEGACY_TENANT_ID;
    const _trackingOriginRowEarly = await get(`SELECT value FROM twilio_runtime_config WHERE key = ?`, ["crmPublicUrl"]);
    const _livePublicOriginEarly =
      normalizeCrmPublicUrl(String(_trackingOriginRowEarly?.value || "")) || getPublicOrigin(req);
    const preparedOutbound = prepareOutboundEmailWithUnsubscribe({
      subject,
      text,
      html,
      contact: mergeContactRow || (primaryRecipient ? { email: primaryRecipient } : null),
      tenantId: outboundTenantId,
      publicOrigin: _livePublicOriginEarly,
      mergeFields: mergeBase,
      customFields: overlayContactCustomFields(customFields, mergeContactRow),
      applyMergeFields
    });
    subject = preparedOutbound.subject;
    text = preparedOutbound.text;
    html = preparedOutbound.html;
    const outboundListUnsubscribeHeaders = preparedOutbound.listUnsubscribeHeaders?.headers || {};
    let contacts = [];
    if (uniqueRecipients.length) {
      const placeholders = uniqueRecipients.map(() => "?").join(",");
      contacts = await all(
        `SELECT id FROM contacts WHERE lower(trim(email)) IN (${placeholders})`,
        uniqueRecipients
      );
    }
    let trackedContactIds = [...new Set(contacts.map((row) => Number(row.id)).filter((n) => Number.isInteger(n) && n > 0))];
    if (Number.isInteger(mergeContactId) && mergeContactId > 0) {
      trackedContactIds = [...new Set([...trackedContactIds, mergeContactId])];
    }
    let trackingToken = "";
    let trackingWarning = "";
    // Read live public URL from DB so pixel URLs are always current, even if a
    // Phusion Passenger worker has a stale CRM_PUBLIC_URL env var from before a
    // Settings change.  Falls back to getPublicOrigin(req) when DB has no value.
    const _trackingOriginRow = await get(
      `SELECT value FROM twilio_runtime_config WHERE key = ?`, ["crmPublicUrl"]
    );
    const _livePublicOrigin =
      normalizeCrmPublicUrl(String(_trackingOriginRow?.value || "")) || getPublicOrigin(req);
    if (enableTracking) {
      const attached = await attachEmailOpenPixel({
        html: html || templateBodyToHtml(text),
        publicOrigin: _livePublicOrigin,
        run,
        contactIds: trackedContactIds.join(","),
        toEmails: uniqueRecipients.join(","),
        subject: subject || "(no subject)"
      });
      trackingToken = attached.token;
      if (attached.token) html = attached.html;
      if (!attached.token && isLocalhostLikeUrl(_livePublicOrigin)) {
        trackingWarning =
          "Open tracking link uses localhost. Set CRM_PUBLIC_URL to a public HTTPS URL so recipients can trigger open events.";
      } else if (attached.token) {
        const hostHint = buildPublicUrlTrackingHint(req, _livePublicOrigin);
        if (hostHint) trackingWarning = hostHint;
      }
      if (!trackingWarning && !trackedContactIds.length) {
        trackingWarning =
          "Recipient email does not match a contact record — open event will be detected but won't link to a contact.";
      }
    }
    const sent = await sendEmail({
      to: smtpTo,
      cc: smtpCc,
      bcc: smtpBcc,
      from: from || undefined,
      subject,
      text,
      html: html || undefined,
      attachments,
      headers: outboundListUnsubscribeHeaders
    });
    if (trackedContactIds.length) {
      const historyDetail = buildSentEmailHistoryDetail({
        from,
        to,
        cc,
        subject,
        text,
        html,
        bccBulk: useBccBulk
          ? { used: true, envelopeTo: resolvedFromForBulk, bccRecipients: uniqueRecipients.join(", ") }
          : undefined
      });
      for (const contactId of trackedContactIds) {
        await run(`UPDATE contacts SET last_emailed = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [contactId]);
        await logContactActivity(contactId, "email", historyDetail);
      }
    }
    return res.json({
      ok: true,
      ...sent,
      attachments: attachments.length,
      trackingEnabled: Boolean(trackingToken),
      trackingToken: trackingToken || undefined,
      trackingWarning: trackingWarning || undefined,
      skippedDoNotEmail: skippedDoNotEmail.length ? skippedDoNotEmail : undefined,
      bccBulk: useBccBulk,
      ...(useBccBulk ? { bccRecipientCount: uniqueRecipients.length, smtpVisibleTo: resolvedFromForBulk } : {})
    });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

/** One throttled-campaign recipient: merge fields, open-tone image, send, history. */
async function sendQueuedBulkEmail({ row, contact }) {
  let subject = String(row.subject || "");
  let text = String(row.body_text || "");
  let html = String(row.body_html || "");
  const originRow = await get(`SELECT value FROM twilio_runtime_config WHERE key = ?`, ["crmPublicUrl"]);
  const publicOrigin = normalizeCrmPublicUrl(String(originRow?.value || ""));
  let bulkListUnsubscribeHeaders = {};
  if (contact) {
    const customRows = await all(`SELECT field_key, field_value, field_scope FROM custom_merge_fields ORDER BY field_key`);
    const customFields = {};
    for (const r of customRows) {
      const key = normalizeMergeKey(r?.field_key);
      if (!key) continue;
      if (normalizeMergeFieldScope(r?.field_scope) === "contact") continue;
      customFields[key] = String(r?.field_value ?? "");
    }
    const merge = contactRowToMergeFields(contact, String(row.to_email || ""));
    const prepared = prepareOutboundEmailWithUnsubscribe({
      subject,
      text,
      html,
      contact,
      tenantId: LEGACY_TENANT_ID,
      publicOrigin,
      mergeFields: merge,
      customFields: overlayContactCustomFields(customFields, contact),
      applyMergeFields
    });
    subject = prepared.subject;
    text = prepared.text;
    html = prepared.html;
    bulkListUnsubscribeHeaders = prepared.listUnsubscribeHeaders?.headers || {};
  }
  const attachedOpen = await attachEmailOpenPixel({
    html: html || templateBodyToHtml(text),
    publicOrigin,
    run,
    contactIds: contact?.id ? String(contact.id) : "",
    toEmails: String(row.to_email || ""),
    subject
  });
  if (attachedOpen.token) html = attachedOpen.html;
  const envFrom = String(process.env.SMTP_FROM || process.env.SMTP_USER || "").trim();
  await sendEmail({
    to: String(row.to_email || ""),
    from: String(row.from_email || "").trim() || envFrom || undefined,
    subject,
    text,
    html: html || undefined,
    headers: bulkListUnsubscribeHeaders
  });
  if (contact?.id) {
    await run(`UPDATE contacts SET last_emailed = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [contact.id]);
    const detail = buildSentEmailHistoryDetail({
      from: String(row.from_email || ""),
      to: String(row.to_email || ""),
      cc: "",
      subject,
      text,
      html
    });
    await logContactActivity(contact.id, "email", detail);
  }
}

function bulkEmailProcessorDeps(maxPerTick = 5) {
  return { run, all, get, sendOne: sendQueuedBulkEmail, maxPerTick };
}

app.get("/api/email/bulk-campaign/preview", async (req, res) => {
  try {
    const skipAlreadySent = ["1", "true", "yes"].includes(String(req.query.skipSent || "").toLowerCase());
    const result = await previewEmailBulkCampaign({ all }, String(req.query.tag || ""), { skipAlreadySent, subject: String(req.query.subject || "") });
    return res.json(result);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

const MAX_CONCURRENT_BULK_CAMPAIGNS = 3;
app.post("/api/email/bulk-campaign", async (req, res) => {
  try {
    if (!(await isOutboundEmailReady())) {
      return res.status(503).json({
        error: "Outbound email is not configured. Complete SMTP setup in Settings before queueing a campaign."
      });
    }
    const activeBulkCampaigns = await emailBulkCampaignActiveList({ get, all });
    if (Array.isArray(activeBulkCampaigns.campaigns) && activeBulkCampaigns.campaigns.length >= MAX_CONCURRENT_BULK_CAMPAIGNS) {
      return res.status(409).json({
        error: `You already have ${MAX_CONCURRENT_BULK_CAMPAIGNS} campaigns sending at once, which is the maximum. Wait for one to finish or cancel one before starting another.`
      });
    }
    const tag = String(req.body?.tag || "").trim();
    let subject = String(req.body?.subject || "").trim();
    let html = String(req.body?.html || "").trim();
    let text = String(req.body?.text || "").trim();
    const templateId = Number(req.body?.templateId);
    if (Number.isInteger(templateId) && templateId > 0) {
      const tpl = await get(`SELECT subject, body FROM email_templates WHERE id = ?`, [templateId]);
      if (!tpl) return res.status(404).json({ error: "Template not found" });
      if (!subject) subject = String(tpl.subject || "").trim();
      if (!html && !text) {
        const tplBody = String(tpl.body || "");
        text = tplBody;
        html = templateBodyToHtml(tplBody);
      }
    }
    const result = await queueEmailBulkCampaign(
      { run, all },
      { tag, subject, html, text, from: String(req.body?.from || ""), perHour: req.body?.perHour, skipAlreadySent: Boolean(req.body?.skipAlreadySent) }
    );
    if (!result.queued) {
      return res.status(400).json({
        error: "No sendable contacts for that tag — they may be missing emails or marked Do Not Email.",
        ...result
      });
    }
    // Kick off sending in the background — don't block the response on SMTP round-trips.
    processDueBulkEmails(bulkEmailProcessorDeps(10)).catch((err) => console.error("[email-bulk] queue tick:", (err && err.message) || err));
    return res.json({ ok: true, ...result });
  } catch (error) {
    return res.status(400).json({ error: error.message });
  }
});

app.get("/api/email/bulk-campaign/status", async (req, res) => {
  try {
    const result = await emailBulkCampaignStatus({ get, all }, String(req.query.batchId || ""));
    // Status loads fast: nudge sending in the background instead of awaiting SMTP sends.
    processDueBulkEmails(bulkEmailProcessorDeps(15)).catch((err) => console.error("[email-bulk] status tick:", (err && err.message) || err));
    return res.json({ ...result, emailConfigured: await isOutboundEmailReady() });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/email/bulk-campaign/active", async (req, res) => {
  try {
    const result = await emailBulkCampaignActiveList({ get, all });
    return res.json({ ...result, emailConfigured: await isOutboundEmailReady() });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/email/bulk-campaign/cancel", async (req, res) => {
  try {
    const result = await cancelEmailBulkCampaign({ run }, String(req.body?.batchId || ""));
    return res.json({ ok: true, ...result });
  } catch (error) {
    return res.status(400).json({ error: error.message });
  }
});

app.post("/api/email/bulk-campaign/pause", async (req, res) => {
  try {
    const result = await pauseEmailBulkCampaign({ run }, String(req.body?.batchId || ""));
    return res.json({ ok: true, ...result });
  } catch (error) {
    return res.status(400).json({ error: error.message });
  }
});

app.post("/api/email/bulk-campaign/resume", async (req, res) => {
  try {
    const result = await resumeEmailBulkCampaign({ run }, String(req.body?.batchId || ""));
    // Nudge sending right away so resume feels immediate instead of waiting for the next tick.
    processDueBulkEmails(bulkEmailProcessorDeps(15)).catch((err) => console.error("[email-bulk] resume tick:", (err && err.message) || err));
    return res.json({ ok: true, ...result });
  } catch (error) {
    return res.status(400).json({ error: error.message });
  }
});

/** Email-open counts for the Live Dashboard cards (emails opened in the last 24h / 7d). */
app.get("/api/email/open-stats", async (req, res) => {
  try {
    const row = await get(
      `SELECT
         COUNT(CASE WHEN opened_at >= CAST(strftime('%s','now') AS INTEGER) - 86400 THEN 1 END) AS last24h,
         COUNT(CASE WHEN opened_at >= CAST(strftime('%s','now') AS INTEGER) - 604800 THEN 1 END) AS last7d
       FROM email_open_tracking
       WHERE opened_at IS NOT NULL`
    );
    res.json({ last24h: Number(row?.last24h || 0), last7d: Number(row?.last7d || 0) });
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to load email open stats" });
  }
});

/** Emails sent (tracked) for the Live Dashboard (sent in the last 7 days). */
app.get("/api/email/sent-stats", async (req, res) => {
  try {
    const row = await get(
      `SELECT
         COUNT(CASE WHEN created_at >= CAST(strftime('%s','now') AS INTEGER) - 86400 THEN 1 END) AS last24h,
         COUNT(CASE WHEN created_at >= CAST(strftime('%s','now') AS INTEGER) - 604800 THEN 1 END) AS last7d
       FROM email_open_tracking`
    );
    res.json({ last24h: Number(row?.last24h || 0), last7d: Number(row?.last7d || 0) });
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to load email sent stats" });
  }
});

/** De-botted email-click counts for the Live Dashboard.
 *  Raw click events are inflated by (a) email security scanners (Proofpoint,
 *  Mimecast, Microsoft Safe Links, Barracuda, etc.) that auto-click every link
 *  the instant a message is delivered, and (b) repeat / multi-link clicks by the
 *  same recipient. To approximate real human clicks we:
 *    1. Count DISTINCT emails clicked (by open_token) instead of raw events, so
 *       repeat and scanner hits on the same message collapse to one.
 *    2. Ignore clicks landing within CLICK_BOT_GRACE_SECONDS of send time (joined
 *       via email_open_tracking.created_at) — the instant-fire scanner signature.
 *       Clicks we can't time (no matching send row) are kept, to avoid over-filtering.
 *  Tune CLICK_BOT_GRACE_SECONDS up if scanners in your data click a bit later. */
app.get("/api/email/click-stats", async (req, res) => {
  try {
    const CLICK_BOT_GRACE_SECONDS = 10;
    const row = await get(
      `SELECT
         COUNT(DISTINCT CASE
           WHEN ce.clicked_at >= CAST(strftime('%s','now') AS INTEGER) - 86400
            AND (ot.created_at IS NULL OR ce.clicked_at - ot.created_at >= ${CLICK_BOT_GRACE_SECONDS})
           THEN NULLIF(ce.open_token, '') END) AS last24h,
         COUNT(DISTINCT CASE
           WHEN ce.clicked_at >= CAST(strftime('%s','now') AS INTEGER) - 604800
            AND (ot.created_at IS NULL OR ce.clicked_at - ot.created_at >= ${CLICK_BOT_GRACE_SECONDS})
           THEN NULLIF(ce.open_token, '') END) AS last7d
       FROM email_click_events ce
       LEFT JOIN email_open_tracking ot ON ot.open_token = ce.open_token`
    );
    res.json({ last24h: Number(row?.last24h || 0), last7d: Number(row?.last7d || 0) });
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to load email click stats" });
  }
});

app.get("/api/email/click/:token", async (req, res) => {
  try {
    const destination = await recordEmailClickAndGetDestination(
      { run, get, all, logContactActivity, platformAll, openTenantDatabase, withTenantContext, LEGACY_TENANT_ID },
      req.params.token
    );
    if (!destination) return res.status(404).send("Link not found.");
    return res.redirect(302, destination);
  } catch {
    return res.status(404).send("Link not found.");
  }
});

/** Latest opened emails with the matched contact — the "warm leads, call first" list. */
app.get("/api/email/recent-opens", async (req, res) => {
  try {
    const limitRaw = Number(req.query.limit);
    const limit = Number.isInteger(limitRaw) && limitRaw > 0 ? Math.min(limitRaw, 50) : 20;
    const rows = await all(
      `SELECT id, subject, to_emails, contact_ids, opened_at
       FROM email_open_tracking
       WHERE opened_at IS NOT NULL
       ORDER BY opened_at DESC
       LIMIT ?`,
      [limit]
    );
    const contactIds = [
      ...new Set(
        (Array.isArray(rows) ? rows : [])
          .map((r) => Number(String(r.contact_ids || "").split(",")[0]))
          .filter((n) => Number.isInteger(n) && n > 0)
      )
    ];
    const nameById = new Map();
    if (contactIds.length) {
      const ph = contactIds.map(() => "?").join(",");
      const contacts = await all(`SELECT id, full_name, phone FROM contacts WHERE id IN (${ph})`, contactIds);
      for (const c of Array.isArray(contacts) ? contacts : []) {
        nameById.set(Number(c.id), { name: String(c.full_name || "").trim(), phone: String(c.phone || "").trim() });
      }
    }
    const items = (Array.isArray(rows) ? rows : []).map((r) => {
      const firstContactId = Number(String(r.contact_ids || "").split(",")[0]) || 0;
      const info = nameById.get(firstContactId) || null;
      return {
        openedAt: Number(r.opened_at) || 0,
        subject: String(r.subject || "(no subject)"),
        toEmails: String(r.to_emails || ""),
        contactId: firstContactId || null,
        contactName: info?.name || "",
        contactPhone: info?.phone || ""
      };
    });
    return res.json({ items });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

async function resolveEmailOpenTrackingToken(token) {
  const cleanToken = String(token || "").trim();
  if (!cleanToken) return null;
  const tenantIds = [LEGACY_TENANT_ID];
  try {
    const tenantRows = await platformAll(`SELECT id FROM tenants WHERE id != ? ORDER BY id ASC`, [LEGACY_TENANT_ID]);
    for (const row of Array.isArray(tenantRows) ? tenantRows : []) {
      const tenantId = Number(row?.id);
      if (Number.isInteger(tenantId) && tenantId > 0 && tenantId !== LEGACY_TENANT_ID) {
        tenantIds.push(tenantId);
      }
    }
  } catch {
    // ignore tenant lookup errors; fallback to legacy DB only
  }
  for (const tenantId of tenantIds) {
    try {
      if (tenantId !== LEGACY_TENANT_ID) await openTenantDatabase(tenantId);
      const row = await withTenantContext(tenantId, () =>
        get(`SELECT * FROM email_open_tracking WHERE open_token = ?`, [cleanToken])
      );
      if (row) return { tenantId, row };
    } catch {
      // ignore missing/inaccessible tenant DB and keep searching
    }
  }
  return null;
}

app.get("/api/email/unsubscribe", (req, res) => {
  const token = String(req.query.token || "").trim();
  if (!token) return res.redirect("/email-unsubscribe.html");
  return res.redirect(`/email-unsubscribe.html?token=${encodeURIComponent(token)}`);
});

app.post("/api/email/unsubscribe", async (req, res) => {
  try {
    const token = String(req.body?.token || req.query?.token || "").trim();
    const emailRaw = String(req.body?.email || "").trim();
    const oneClick = String(req.body?.["List-Unsubscribe"] || "").trim() === "One-Click";
    if (token) {
      const parsed = verifyUnsubscribeToken(token);
      if (!parsed) return res.status(400).json({ error: "Invalid or expired unsubscribe link." });
      const tenantId = Number.isInteger(Number(parsed.tenantId)) ? Number(parsed.tenantId) : LEGACY_TENANT_ID;
      await openTenantDatabase(tenantId);
      const result = await withTenantContext(tenantId, () =>
        markEmailUnsubscribed(
          { run, all, get, logContactActivity },
          { email: parsed.email, tenantId, source: "one-click link", contactId: parsed.contactId }
        )
      );
      if (oneClick) return res.status(204).send();
      return res.json({
        ...result,
        message:
          result.updated > 0
            ? "You have been unsubscribed and will not receive further marketing emails from this sender."
            : "We saved your request. If you still receive mail, reply to the message with \"unsubscribe\"."
      });
    }
    if (oneClick) {
      return res.status(400).json({ error: "Invalid or expired unsubscribe link." });
    }
    if (emailRaw) {
      await openTenantDatabase(LEGACY_TENANT_ID);
      const result = await withTenantContext(LEGACY_TENANT_ID, () =>
        markEmailUnsubscribed(
          { run, all, get, logContactActivity },
          { email: emailRaw, tenantId: LEGACY_TENANT_ID, source: "manual form" }
        )
      );
      return res.json({
        ...result,
        message:
          result.updated > 0
            ? "You have been unsubscribed."
            : "We could not find that email in this workspace. Reply \"unsubscribe\" to the original message if you have one."
      });
    }
    return res.status(400).json({ error: "token or email is required." });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Unsubscribe failed." });
  }
});

app.post("/webhooks/email/inbound-reply", express.json({ limit: "512kb" }), async (req, res) => {
  try {
    const secret = String(process.env.EMAIL_UNSUBSCRIBE_WEBHOOK_SECRET || "").trim();
    const provided = String(req.get("x-cadence-webhook-secret") || req.body?.secret || "").trim();
    if (!secret || provided !== secret) {
      return res.status(401).json({ error: "Unauthorized webhook." });
    }
    const from = extractReplyEmailAddress(req.body?.from || req.body?.sender || req.body?.envelope?.from || "");
    const subject = String(req.body?.subject || "");
    const text = String(req.body?.text || req.body?.body || req.body?.bodyPlain || req.body?.stripped_text || "");
    if (!from) return res.status(400).json({ error: "from/sender is required." });
    if (!isUnsubscribeReplyContent(subject, text)) {
      return res.json({ ok: true, processed: false, reason: "not an unsubscribe reply" });
    }
    await openTenantDatabase(LEGACY_TENANT_ID);
    const result = await withTenantContext(LEGACY_TENANT_ID, () =>
      markEmailUnsubscribed(
        { run, all, get, logContactActivity },
        { email: from, tenantId: LEGACY_TENANT_ID, source: "reply webhook" }
      )
    );
    return res.json({ ok: true, processed: true, ...result });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Inbound reply webhook failed." });
  }
});

app.get("/api/email/open/:token", async (req, res) => {
  const pixel = Buffer.from(
    "R0lGODlhAQABAIABAP///wAAACwAAAAAAQABAAACAkQBADs=",
    "base64"
  );
  res.setHeader("Content-Type", "image/gif");
  res.setHeader("Content-Length", String(pixel.length));
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  res.setHeader("Pragma", "no-cache");
  res.setHeader("Expires", "0");
  try {
    const token = String(req.params.token || "").trim();
    if (!token) return res.status(200).send(pixel);
    const resolved = await resolveEmailOpenTrackingToken(token);
    if (!resolved) return res.status(200).send(pixel);
    await withTenantContext(resolved.tenantId, async () => {
      const row = resolved.row;
      const logEachAccess = String(process.env.EMAIL_OPEN_LOG_EACH_ACCESS || "").trim() === "1";
      const firstRecordedOpen = !row.opened_at;
      const nowUnix = Math.floor(Date.now() / 1000);
      // If this is the first fetch and it arrived suspiciously fast after the email
      // was created, it's almost certainly a scanner bot or email proxy prefetch —
      // NOT a real human open.  Skip recording it so the genuine open fires later.
      if (firstRecordedOpen && shouldIgnoreEarlyEmailOpen(row, nowUnix)) {
        return;
      }
      if (firstRecordedOpen) {
        await run(
          `UPDATE email_open_tracking SET opened_at = CAST(strftime('%s','now') AS INTEGER) WHERE id = ?`,
          [row.id]
        );
      }
      const contactIds = String(row.contact_ids || "")
        .split(",")
        .map((v) => Number(String(v || "").trim()))
        .filter((n) => Number.isInteger(n) && n > 0);
      let targetContactIds = [...new Set(contactIds)];
      if (!targetContactIds.length) {
        const recipients = splitEmailAddresses(String(row.to_emails || ""));
        if (recipients.length) {
          const placeholders = recipients.map(() => "?").join(",");
          const matchedContacts = await all(
            `SELECT id FROM contacts WHERE lower(trim(email)) IN (${placeholders})`,
            recipients
          );
          targetContactIds = [...new Set((Array.isArray(matchedContacts) ? matchedContacts : [])
            .map((r) => Number(r.id))
            .filter((n) => Number.isInteger(n) && n > 0))];
        }
      }
      const openedAtLabel = new Date().toLocaleString();
      const subjectLabel = String(row.subject || "(no subject)").trim() || "(no subject)";
      const shouldLogActivity = logEachAccess || firstRecordedOpen;
      if (shouldLogActivity) {
        for (const contactId of targetContactIds) {
          await logContactActivity(contactId, "email", `Email Opened\nSubject: ${subjectLabel}\nOpened At: ${openedAtLabel}`);
        }
      }
    });
    return res.status(200).send(pixel);
  } catch {
    return res.status(200).send(pixel);
  }
});

app.get("/api/server-time", (req, res) => {
  return res.json({ unix: Math.floor(Date.now() / 1000) });
});

app.get("/api/email/open-events", async (req, res) => {
  try {
    /* Every open CRM tab polls this endpoint, so piggyback the campaign queue
       here: bulk sends keep flowing while ANY page is open, even when cPanel
       Passenger recycles the background timer. Use the shared 25s throttle so
       this poll cannot stampede SQLite. */
    kickOutboundEmailQueues({ maxPerTick: 5 });
    const serverNowUnix = Math.floor(Date.now() / 1000);
    const sinceRaw = Number(req.query.since || 0);
    let since = Number.isFinite(sinceRaw) && sinceRaw > 0 ? Math.floor(sinceRaw) : 0;
    // If the browser persisted a cursor far in the future (clock skew / old bugs),
    // pull it back so new rows are not permanently hidden.
    if (since > serverNowUnix + 120) {
      since = Math.max(0, serverNowUnix - 10 * 60);
    }
    const sinceIdRaw = Number(req.query.sinceId || 0);
    const sinceId = Number.isFinite(sinceIdRaw) && sinceIdRaw > 0 ? Math.floor(sinceIdRaw) : 0;
    const sinceSql = `datetime(?, 'unixepoch')`;

    // Source 1: contact_activity rows (emails linked to a contact record).
    // Keep this index-friendly (activity_type + created_at). Wrapping columns in
    // LOWER()/strftime() forced a full scan on every 5s poll from every open tab.
    const activityRows = await all(
      `SELECT
         ca.id,
         ca.contact_id,
         ca.detail,
         ca.created_at,
         CAST(strftime('%s', ca.created_at) AS INTEGER) AS created_at_unix,
         COALESCE(c.full_name, '') AS contact_name
       FROM contact_activity ca
       LEFT JOIN contacts c ON c.id = ca.contact_id
       WHERE ca.activity_type = 'email'
         AND ca.detail LIKE 'email opened%'
         AND (
           ca.created_at > ${sinceSql}
           OR (
             ca.created_at = ${sinceSql}
             AND ca.id > ?
           )
         )
       ORDER BY ca.created_at ASC, ca.id ASC
       LIMIT 50`,
      [since, since, sinceId]
    );

    // Source 2: email_open_tracking rows where no contact was matched at send time
    // (contact_ids = '').  These are opens for emails sent to addresses not yet in
    // the CRM — e.g. test emails or future contacts.
    const trackingRows = await all(
      `SELECT id, to_emails, subject, opened_at
       FROM email_open_tracking
       WHERE contact_ids = ''
         AND opened_at IS NOT NULL
         AND opened_at > ?
       ORDER BY opened_at ASC
       LIMIT 50`,
      [since]
    );

    const tooOldOpenedAtCutoff = serverNowUnix - 2 * 60 * 60;
    const itemsFromActivity = (Array.isArray(activityRows) ? activityRows : [])
      .map((row) => ({
        id: Number(row.id || 0),
        contactId: Number(row.contact_id || 0),
        contactName: String(row.contact_name || "").trim(),
        detail: String(row.detail || "").trim(),
        createdAt: String(row.created_at || ""),
        createdAtUnix: Math.max(0, Number(row.created_at_unix || 0))
      }))
      .filter((item) => {
        const openedAtUnix = extractOpenedAtUnixFromHistoryDetail(item.detail);
        if (!openedAtUnix) return true;
        return openedAtUnix >= tooOldOpenedAtCutoff;
      });

    // Use negative IDs for tracking-only items so they never collide with
    // contact_activity IDs in the cursor tiebreaker.
    const itemsFromTracking = (Array.isArray(trackingRows) ? trackingRows : []).map((row) => {
      const openedAt = Number(row.opened_at || 0);
      const toEmails = String(row.to_emails || "").trim();
      const subject = String(row.subject || "(no subject)").trim();
      return {
        id: -(Number(row.id || 0)),
        contactId: 0,
        contactName: toEmails || "Unknown",
        detail: `Email Opened\nSubject: ${subject}`,
        createdAt: new Date(openedAt * 1000).toISOString().replace("T", " ").slice(0, 19),
        createdAtUnix: Math.max(0, openedAt)
      };
    });

    // Merge and sort by timestamp ascending; deduplicate by id.
    const merged = [...itemsFromActivity, ...itemsFromTracking].sort(
      (a, b) => a.createdAtUnix - b.createdAtUnix || a.id - b.id
    );

    return res.json({ items: merged.slice(0, 50), serverNowUnix });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/documents", async (req, res) => {
  try {
    const rows = await all(
      `SELECT id, file_name, mime_type, size_bytes, category_name, created_at
       FROM documents
       ORDER BY created_at DESC, id DESC`
    );
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/documents/health", async (req, res) => {
  try {
    const rows = await all(`SELECT id, file_name, storage_path FROM documents ORDER BY id ASC`);
    let resolvable = 0;
    let missing = 0;
    const missingSamples = [];
    for (const row of rows) {
      const diskPath = resolveStoredUploadPath(row.storage_path, "documents", row.file_name);
      if (diskPath) {
        resolvable += 1;
      } else {
        missing += 1;
        if (missingSamples.length < 5) {
          missingSamples.push({
            id: row.id,
            file_name: row.file_name,
            storage_path: row.storage_path
          });
        }
      }
    }
    const documentsDir = path.join(uploadsRootDir, "documents");
    let diskFileCount = 0;
    if (fs.existsSync(documentsDir)) {
      try {
        diskFileCount = fs
          .readdirSync(documentsDir, { withFileTypes: true })
          .filter((ent) => ent.isFile())
          .length;
      } catch {
        diskFileCount = 0;
      }
    }
    return res.json({
      dbCount: rows.length,
      resolvable,
      missing,
      diskFileCount,
      missingSamples
    });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/documents/delete-category", async (req, res) => {
  try {
    const categoryName = String((req.body && req.body.categoryName) || "").trim();
    if (!categoryName) return res.status(400).json({ error: "categoryName is required" });
    if (categoryName.toLowerCase() === "uncategorized") {
      return res.status(400).json({ error: "Cannot delete the Uncategorized category" });
    }
    const result = await run(
      `UPDATE documents SET category_name = 'Uncategorized'
       WHERE lower(trim(category_name)) = lower(trim(?))`,
      [categoryName]
    );
    res.json({ ok: true, movedCount: Number(result.changes || 0) });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

function sanitizeDocumentCategoryName(raw) {
  const cleaned = String(raw || "")
    .replace(/[\u0000-\u001F]/g, "")
    .trim()
    .slice(0, 80)
    .trim();
  return cleaned || "Uncategorized";
}

app.patch("/api/documents/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const doc = await get(`SELECT * FROM documents WHERE id = ?`, [id]);
    if (!doc) return res.status(404).json({ error: "Document not found" });
    const body = req.body && typeof req.body === "object" ? req.body : {};
    const hasFileName = Object.prototype.hasOwnProperty.call(body, "fileName");
    const hasCategory = Object.prototype.hasOwnProperty.call(body, "categoryName");
    if (!hasFileName && !hasCategory) {
      return res.status(400).json({ error: "fileName or categoryName is required" });
    }
    const updates = [];
    const params = [];
    if (hasFileName) {
      const fileName = String(body.fileName || "").trim();
      const safeName = fileName.replace(/[<>:"/\\|?*\x00-\x1F]/g, "_").trim();
      if (!safeName) return res.status(400).json({ error: "fileName is invalid" });
      updates.push("file_name = ?");
      params.push(safeName);
    }
    if (hasCategory) {
      updates.push("category_name = ?");
      params.push(sanitizeDocumentCategoryName(body.categoryName));
    }
    params.push(id);
    await run(`UPDATE documents SET ${updates.join(", ")} WHERE id = ?`, params);
    const updated = await get(
      `SELECT id, file_name, mime_type, size_bytes, category_name, created_at FROM documents WHERE id = ?`,
      [id]
    );
    res.json(updated);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/documents", async (req, res) => {
  try {
    const fileName = String((req.body && req.body.fileName) || "").trim();
    const mimeType = String((req.body && req.body.mimeType) || "application/octet-stream").trim();
    const rawCategoryName = String((req.body && req.body.categoryName) || "").trim();
    const categoryName = rawCategoryName || "Uncategorized";
    const contentBase64 = String((req.body && req.body.contentBase64) || "").trim();
    if (!fileName) return res.status(400).json({ error: "fileName is required" });
    if (!contentBase64) return res.status(400).json({ error: "contentBase64 is required" });
    const buffer = Buffer.from(contentBase64, "base64");
    if (!buffer.length) return res.status(400).json({ error: "File content is empty" });
    if (buffer.length > 15 * 1024 * 1024) return res.status(400).json({ error: "File too large (max 15MB)" });

    const safeName = fileName.replace(/[<>:"/\\|?*\x00-\x1F]/g, "_");
    const storedName = `${Date.now()}_${Math.floor(Math.random() * 1e6)}_${safeName}`;
    const storagePath = path.join(uploadsDir, storedName);
    fs.writeFileSync(storagePath, buffer);
    const storageKey = toRelativeUploadPath("documents", storedName);

    const result = await run(
      `INSERT INTO documents (file_name, mime_type, size_bytes, category_name, storage_path)
       VALUES (?, ?, ?, ?, ?)`,
      [safeName, mimeType || "application/octet-stream", buffer.length, categoryName, storageKey]
    );
    const created = await get(
      `SELECT id, file_name, mime_type, size_bytes, category_name, created_at FROM documents WHERE id = ?`,
      [result.lastID]
    );
    res.status(201).json(created);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/documents/:id/download", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const doc = await get(`SELECT * FROM documents WHERE id = ?`, [id]);
    if (!doc) return res.status(404).json({ error: "Document not found" });
    const diskPath = resolveStoredUploadPath(doc.storage_path, "documents", doc.file_name);
    if (!diskPath) {
      return res.status(404).json({ error: "Stored file not found" });
    }
    const disposition = String(req.query.inline || "") === "1" ? "inline" : "attachment";
    res.setHeader("Content-Type", doc.mime_type || "application/octet-stream");
    res.setHeader("Content-Disposition", `${disposition}; filename="${String(doc.file_name || "document").replace(/"/g, "")}"`);
    return res.sendFile(diskPath);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.delete("/api/documents/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const doc = await get(`SELECT * FROM documents WHERE id = ?`, [id]);
    if (!doc) return res.status(404).json({ error: "Document not found" });
    await run(`DELETE FROM documents WHERE id = ?`, [id]);
    if (doc.storage_path) {
      const diskPath = resolveStoredUploadPath(doc.storage_path, "documents", doc.file_name);
      if (diskPath) fs.unlinkSync(diskPath);
    }
    res.json({ ok: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ── SMS usage limits ──────────────────────────────────────────────────────────
const SMS_DAILY_LIMIT   = 150;
const SMS_MONTHLY_LIMIT = 1000;
const SMS_ALERT_PCT     = 0.80;

function smsDateKeys() {
  const now = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  const day   = `${now.getUTCFullYear()}-${pad(now.getUTCMonth() + 1)}-${pad(now.getUTCDate())}`;
  const month = `${now.getUTCFullYear()}-${pad(now.getUTCMonth() + 1)}`;
  return { day, month };
}

async function getSmsUsage() {
  const { day, month } = smsDateKeys();
  const [dayRow, monthRow] = await Promise.all([
    get(`SELECT COUNT(*) AS n FROM sms_usage WHERE day = ?`, [day]),
    get(`SELECT COUNT(*) AS n FROM sms_usage WHERE month = ?`, [month])
  ]);
  return { daily: dayRow?.n || 0, monthly: monthRow?.n || 0 };
}

function getSmsAgentEmail() {
  return String(process.env.CRM_LOGIN_EMAIL || "").trim().toLowerCase();
}
function getSmsOwnerEmail() {
  return String(process.env.CRM_OWNER_EMAIL || "support@crmcadence.com").trim().toLowerCase();
}

async function checkSmsLimit(count = 1) {
  const { daily, monthly } = await getSmsUsage();
  if (daily + count > SMS_DAILY_LIMIT) {
    // Notify agent and owner that daily limit is hit
    const agentEmail = getSmsAgentEmail();
    const ownerEmail = getSmsOwnerEmail();
    if (isEmailConfigured()) {
      if (agentEmail) sendEmail({
        to: agentEmail,
        subject: "Cadence CRM — Daily SMS limit reached",
        text: `Your daily SMS limit of ${SMS_DAILY_LIMIT} messages has been reached. SMS will resume automatically at midnight UTC. If you need assistance, contact support@crmcadence.com.`
      }).catch(() => {});
      if (ownerEmail && ownerEmail !== agentEmail) sendEmail({
        to: ownerEmail,
        subject: "Cadence CRM — Agent hit daily SMS limit",
        text: `Agent ${agentEmail || "unknown"} has hit their daily SMS limit (${SMS_DAILY_LIMIT}/day). Their SMS is blocked until midnight UTC.`
      }).catch(() => {});
    }
    throw new Error(`Daily SMS limit reached (${SMS_DAILY_LIMIT}/day). Resets at midnight UTC.`);
  }
  if (monthly + count > SMS_MONTHLY_LIMIT) {
    // Notify agent and owner that monthly limit is hit
    const agentEmail = getSmsAgentEmail();
    const ownerEmail = getSmsOwnerEmail();
    if (isEmailConfigured()) {
      if (agentEmail) sendEmail({
        to: agentEmail,
        subject: "Cadence CRM — Monthly SMS limit reached",
        text: `Your monthly SMS limit of ${SMS_MONTHLY_LIMIT} messages has been reached. SMS will resume at the start of next month. Contact support@crmcadence.com if you need your limit reviewed.`
      }).catch(() => {});
      if (ownerEmail && ownerEmail !== agentEmail) sendEmail({
        to: ownerEmail,
        subject: "Cadence CRM — Agent hit monthly SMS limit",
        text: `Agent ${agentEmail || "unknown"} has hit their monthly SMS limit (${SMS_MONTHLY_LIMIT}/month). Their SMS is blocked for the rest of this month.`
      }).catch(() => {});
    }
    throw new Error(`Monthly SMS limit reached (${SMS_MONTHLY_LIMIT}/month). Resets next month.`);
  }
}

async function recordSmsSent(count = 1) {
  const { day, month } = smsDateKeys();
  for (let i = 0; i < count; i++) {
    await run(`INSERT INTO sms_usage (day, month) VALUES (?, ?)`, [day, month]);
  }
  const { daily, monthly } = await getSmsUsage();
  const agentEmail = getSmsAgentEmail();
  const ownerEmail = getSmsOwnerEmail();
  if (!isEmailConfigured()) return;

  // 80% daily warning
  if (daily === Math.floor(SMS_DAILY_LIMIT * SMS_ALERT_PCT)) {
    if (agentEmail) sendEmail({
      to: agentEmail,
      subject: "Cadence CRM — Daily SMS at 80%",
      text: `Heads up — you have used ${daily} of your ${SMS_DAILY_LIMIT} daily SMS messages (80%). You have ${SMS_DAILY_LIMIT - daily} remaining today.`
    }).catch(() => {});
    if (ownerEmail && ownerEmail !== agentEmail) sendEmail({
      to: ownerEmail,
      subject: "Cadence CRM — Agent daily SMS at 80%",
      text: `Agent ${agentEmail || "unknown"} has used ${daily} of ${SMS_DAILY_LIMIT} daily SMS (80%). ${SMS_DAILY_LIMIT - daily} remaining today.`
    }).catch(() => {});
  }

  // 80% monthly warning
  if (monthly === Math.floor(SMS_MONTHLY_LIMIT * SMS_ALERT_PCT)) {
    if (agentEmail) sendEmail({
      to: agentEmail,
      subject: "Cadence CRM — Monthly SMS at 80%",
      text: `Heads up — you have used ${monthly} of your ${SMS_MONTHLY_LIMIT} monthly SMS messages (80%). You have ${SMS_MONTHLY_LIMIT - monthly} remaining this month.`
    }).catch(() => {});
    if (ownerEmail && ownerEmail !== agentEmail) sendEmail({
      to: ownerEmail,
      subject: "Cadence CRM — Agent monthly SMS at 80%",
      text: `Agent ${agentEmail || "unknown"} has used ${monthly} of ${SMS_MONTHLY_LIMIT} monthly SMS (80%). ${SMS_MONTHLY_LIMIT - monthly} remaining this month.`
    }).catch(() => {});
  }
}
// ── End SMS usage limits ──────────────────────────────────────────────────────

app.get("/api/sms/media/:id", (req, res) => {
  const id = String(req.params.id || "");
  if (!verifySmsMediaToken(getAuthSigningSecret(), id, req.query.e, req.query.s)) {
    return res.status(403).json({ error: "This photo link has expired." });
  }
  const photo = resolveSmsPhoto(uploadsSmsDir, id) || resolveSmsPhoto(uploadsSmsStepsDir, id);
  if (!photo) return res.status(404).json({ error: "Photo not found." });
  // Serve the file saved at upload time. Rewriting it while Twilio downloads the
  // picture makes the phone company drop the whole text, words included.
  const body = fs.readFileSync(photo.full);
  res.status(200);
  res.setHeader("Content-Type", photo.mime);
  res.setHeader("Content-Length", String(body.length));
  res.setHeader("Cache-Control", "public, max-age=86400");
  res.setHeader("Accept-Ranges", "none");
  res.setHeader("X-Content-Type-Options", "nosniff");
  return res.end(body);
});

app.post("/api/contacts/bulk-send-sms", smsPhotoUpload, async (req, res) => {
  try {
    const contactIds = parseContactIds(req.body && req.body.contactIds);
    const body = req.body && req.body.body != null ? String(req.body.body).trim() : "";
    let mediaUrl = "";
    try {
      mediaUrl = smsPhotoPublicUrl(req);
    } catch (err) {
      return res.status(err.status || 400).json({ error: err.message || "Could not read that photo." });
    }
    if (!contactIds.length) return res.status(400).json({ error: "contactIds is required" });
    if (!body && !mediaUrl) return res.status(400).json({ error: "Message or photo is required." });

    const twilioFrom = getTwilioFromLine(req.body);
    await rememberSmsEndingFromBody(req.body);
    const activity = smsActivityText(body, Boolean(mediaUrl));
    // Check limit before sending the whole batch
    await checkSmsLimit(contactIds.length);
    let sent = 0;
    let skipped = 0;
    let failed = 0;
    let photoDropped = false;
    let firstError = "";
    for (const id of contactIds) {
      const contact = await get("SELECT id, phone FROM contacts WHERE id = ?", [id]);
      if (!contact || !String(contact.phone || "").trim()) {
        skipped += 1;
        continue;
      }
      try {
        await checkSmsLimit(1);
        const result = await sendSms({ to: String(contact.phone).trim(), body, twilioFrom, mediaUrl });
        if (result && result.photoDropped) photoDropped = true;
        await recordSmsSent(1);
        await logContactActivity(contact.id, "sms", activity);
        await run(`UPDATE contacts SET last_sms = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [
          contact.id
        ]);
        sent += 1;
      } catch (err) {
        failed += 1;
        if (!firstError) firstError = err && err.message ? String(err.message) : String(err);
      }
    }
    res.json({ sent, skipped, failed, photoDropped, error: firstError || undefined });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/contacts/bulk-enroll-campaign", async (req, res) => {
  try {
    const contactIds = parseContactIds(req.body && req.body.contactIds);
    const campaignId = Number(req.body && req.body.campaignId);
    if (!contactIds.length) return res.status(400).json({ error: "contactIds is required" });
    if (!Number.isInteger(campaignId) || campaignId < 1) return res.status(400).json({ error: "campaignId is required" });

    const campaign = await get(`SELECT * FROM drip_campaigns WHERE id = ?`, [campaignId]);
    if (!campaign) return res.status(404).json({ error: "Campaign not found" });
    const steps = await all(`SELECT * FROM drip_steps WHERE campaign_id = ? ORDER BY step_order ASC`, [campaignId]);
    if (!steps.length) return res.status(400).json({ error: "Campaign has no steps" });

    let enrolled = 0;
    let skipped = 0;
    let duplicate = 0;
    for (const contactId of contactIds) {
      const contact = await get(`SELECT id FROM contacts WHERE id = ?`, [contactId]);
      if (!contact) {
        skipped += 1;
        continue;
      }
      const result = await enrollContactInCampaign(dbDeps(), campaignId, contactId);
      if (!result.ok) {
        if (result.reason === "already_active") duplicate += 1;
        else skipped += 1;
        continue;
      }
      await logContactActivity(contactId, "campaign", `Enrolled in campaign #${campaignId}`);
      enrolled += 1;
    }
    res.json({ enrolled, skipped, duplicate });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/twilio/send-sms", twilioSmsLimiter, smsPhotoUpload, async (req, res) => {
  try {
    const { contactId, phone, body } = req.body;
    const text = body != null ? String(body).trim() : "";
    let mediaUrl = "";
    try {
      mediaUrl = smsPhotoPublicUrl(req);
    } catch (err) {
      return res.status(err.status || 400).json({ error: err.message || "Could not read that photo." });
    }
    if (!text && !mediaUrl) return res.status(400).json({ error: "Message or photo is required." });
    const to = String(phone || "").trim();
    if (!to && !contactId) {
      return res.status(400).json({ error: "phone is required" });
    }
    let targetPhone = to;
    if (!targetPhone && contactId) {
      const contact = await get("SELECT * FROM contacts WHERE id = ?", [contactId]);
      if (!contact) return res.status(404).json({ error: "Contact not found" });
      if (!contact.phone) return res.status(400).json({ error: "Contact has no phone number" });
      targetPhone = String(contact.phone).trim();
    }
    await checkSmsLimit(1);
    await rememberSmsEndingFromBody(req.body);
    const result = await sendSms({ to: targetPhone, body: text, twilioFrom: getTwilioFromLine(req.body), mediaUrl });
    await recordSmsSent(1);
    const activity = smsActivityText(text, Boolean(mediaUrl));
    if (contactId) {
      await logContactActivity(contactId, "sms", activity);
      await run(`UPDATE contacts SET last_sms = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [
        contactId
      ]);
    } else {
      const byPhone = await all(`SELECT id FROM contacts WHERE phone = ? OR secondary_phone = ? LIMIT 10`, [targetPhone, targetPhone]);
      for (const c of byPhone) {
        await logContactActivity(c.id, "sms", activity);
      }
    }
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/twilio/start-call", twilioCallLimiter, async (req, res) => {
  try {
    const { contactId, phone, twimlUrl, to: toField } = req.body;
    const to = String(phone || toField || "").trim();
    if (!to && !contactId) {
      return res.status(400).json({ error: "phone is required" });
    }
    let targetPhone = to;
    let resolvedContactId = Number(contactId);
    if (!targetPhone && contactId) {
      const contact = await get("SELECT * FROM contacts WHERE id = ?", [contactId]);
      if (!contact) return res.status(404).json({ error: "Contact not found" });
      if (!contact.phone) return res.status(400).json({ error: "Contact has no phone number" });
      targetPhone = String(contact.phone).trim();
      resolvedContactId = Number(contact.id);
    }
    const wantRecord = await resolveShouldRecordCall(req, req.body);
    const publicOrigin = await getRecordingPublicOrigin(req);
    const canRecord = wantRecord && isRecordingCallbackReady(publicOrigin);
    const recordingStatusCallback = canRecord
      ? buildRecordingStatusCallbackUrl(publicOrigin, {
          contactId: resolvedContactId,
          phone: targetPhone
        })
      : "";
    const requestedProvider = req.body && req.body.voiceProvider;
    // Dial the contact from the Cadence number. Do not ring the agent's cell.
    const result = await startCall({
      to: targetPhone,
      twimlUrl,
      twilioFrom: getTwilioFromLine(req.body),
      record: canRecord,
      recordingStatusCallback,
      voiceProvider: requestedProvider
    });
    await recordCallStarted({
      contactId: resolvedContactId,
      phone: targetPhone,
      callSid: result.sid,
      record: canRecord
    });
    res.json({
      ...result,
      record: canRecord,
      bridged: false,
      voiceProvider: result.voiceProvider || getVoiceProvider()
    });
  } catch (error) {
    console.error(`[${getVoiceProvider()}] start-call failed:`, error.message || error);
    res.status(500).json({ error: error.message || "Failed to start call" });
  }
});

app.get("/api/twilio/call-status/:sid", async (req, res) => {
  try {
    const sid = String(req.params.sid || "").trim();
    if (!sid) return res.status(400).json({ error: "sid is required" });
    const status = await getCallStatus(sid);
    return res.json(status);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/twilio/end-call", async (req, res) => {
  try {
    const sid = String((req.body && req.body.sid) || "").trim();
    if (!sid) return res.status(400).json({ error: "sid is required" });
    const result = await endCall(sid);
    return res.json(result);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/twilio/from-numbers", async (req, res) => {
  try {
    const hiddenRows = await all(`SELECT line_key FROM twilio_hidden_lines`);
    const hidden = new Set((Array.isArray(hiddenRows) ? hiddenRows : []).map((r) => normalizeTwilioLineKey(r.line_key)));
    const labelRows = await all(`SELECT line_key, label FROM twilio_line_labels`);
    const labels = {};
    (Array.isArray(labelRows) ? labelRows : []).forEach((row) => {
      const key = normalizeTwilioLineKey(row.line_key);
      if (!key) return;
      labels[key] = String(row.label || "").trim();
    });
    const useBuiltinEnvLines = !isTrialWorkspaceSession(req);
    const primary =
      useBuiltinEnvLines && !hidden.has("primary") ? String(process.env.TWILIO_PHONE_NUMBER || "").trim() : "";
    const secondary =
      useBuiltinEnvLines && !hidden.has("secondary")
        ? String(process.env.TWILIO_PHONE_NUMBER_SECOND || "").trim()
        : "";
    const third =
      useBuiltinEnvLines && !hidden.has("third") ? String(process.env.TWILIO_PHONE_NUMBER_THIRD || "").trim() : "";
    const customRows = isOwnerWorkspaceSession(req)
      ? await all(
          `SELECT id, phone_number, label
           FROM twilio_from_numbers
           ORDER BY created_at ASC, id ASC`
        )
      : [];
    res.json({
      primary: primary || null,
      secondary: secondary || null,
      third: third || null,
      builtinLabels: {
        primary: String(labels.primary || ""),
        secondary: String(labels.secondary || ""),
        third: String(labels.third || "")
      },
      custom: sortCustomTwilioRows(
        (Array.isArray(customRows) ? customRows : []).map((r) => ({
          id: Number(r.id),
          number: String(r.phone_number || "").trim(),
          label: String(r.label || "").trim()
        }))
      )
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/* Twilio config endpoint.
   - GET returns ONLY masked previews for Auth Token + API Secret plus a
     `has*` flag, so a logged-in session can never read back the raw secret.
   - PUT accepts new values; empty string for a secret = leave existing value
     unchanged (so the user re-saves the form without retyping). Sentinel
     value of "__clear__" wipes the field. Secrets are stored encrypted with
     the master key (see encryptSecret). */
app.get("/api/twilio/config", async (req, res) => {
  try {
    const trial = isTrialWorkspaceSession(req);
    if (trial) await purgeInvalidTrialTwilioSecrets();
    const rows = await all(`SELECT key, value FROM twilio_runtime_config`);
    const map = new Map((Array.isArray(rows) ? rows : []).map((r) => [String(r.key || ""), String(r.value || "")]));
    const envOr = (key, envName) => (trial ? "" : process.env[envName] || "");
    let accountSid = String(map.get("accountSid") || envOr("accountSid", "TWILIO_ACCOUNT_SID")).trim();
    if (accountSid && !isLikelyTwilioAccountSid(accountSid)) accountSid = "";
    let authToken = String(decryptSecret(map.get("authToken")) || envOr("authToken", "TWILIO_AUTH_TOKEN")).trim();
    if (authToken && !isLikelyTwilioAuthToken(authToken)) authToken = "";
    const apiKey = String(map.get("apiKey") || envOr("apiKey", "TWILIO_API_KEY")).trim();
    const apiSecret = String(decryptSecret(map.get("apiSecret")) || envOr("apiSecret", "TWILIO_API_SECRET")).trim();
    const voiceTwimlAppSid = String(
      map.get("voiceTwimlAppSid") || envOr("voiceTwimlAppSid", "TWILIO_VOICE_TWIML_APP_SID")
    ).trim();
    const voiceIdentity = String(map.get("voiceIdentity") || envOr("voiceIdentity", "TWILIO_VOICE_IDENTITY")).trim();
    const inboundForwardTo = String(
      map.get("inboundForwardTo") || envOr("inboundForwardTo", "TWILIO_INBOUND_FORWARD_TO")
    ).trim();
    const callRecordingDefault = await getCallRecordingDefault(get);
    const provisionedPhone = String(map.get("phoneNumber") || "").trim();
    const residentState    = String(map.get("residentState") || "").trim();
    const agentName        = String(map.get("agentName")  || process.env.CRM_AGENT_NAME  || "").trim();
    const agentPhone       = String(map.get("agentPhone") || process.env.CRM_AGENT_PHONE || "").trim();
    return res.json({
      accountSid,
      apiKey,
      voiceTwimlAppSid,
      voiceIdentity,
      inboundForwardTo,
      callRecordingDefault,
      hasAuthToken: Boolean(authToken),
      authTokenMasked: maskSecret(authToken),
      hasApiSecret: Boolean(apiSecret),
      apiSecretMasked: maskSecret(apiSecret),
      provisionedPhone: provisionedPhone || null,
      residentState: residentState || null,
      agentName: agentName || null,
      agentPhone: agentPhone || null
    });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.put("/api/twilio/config", async (req, res) => {
  try {
    const accountSid = String(req.body?.accountSid || "").trim();
    /* `authToken` / `apiSecret` rules:
         - undefined / empty string -> leave whatever is stored alone
         - "__clear__"               -> wipe the value
         - anything else             -> store encrypted */
    const rawAuthToken = req.body?.authToken;
    const rawApiSecret = req.body?.apiSecret;
    const apiKey = String(req.body?.apiKey || "").trim();
    const voiceTwimlAppSid = String(req.body?.voiceTwimlAppSid || "").trim();
    const bodyHas = (key) => Object.prototype.hasOwnProperty.call(req.body || {}, key);
    const hasAgentName = Object.prototype.hasOwnProperty.call(req.body || {}, "agentName");
    const hasAgentPhone = Object.prototype.hasOwnProperty.call(req.body || {}, "agentPhone");
    const agentName = hasAgentName ? String(req.body?.agentName || "").trim() : "";
    const agentPhone = hasAgentPhone ? String(req.body?.agentPhone || "").trim() : "";
    const hasCallRecordingPref = Object.prototype.hasOwnProperty.call(req.body || {}, "callRecordingDefault");
    const callRecordingDefault =
      req.body?.callRecordingDefault === true ||
      req.body?.callRecordingDefault === 1 ||
      req.body?.callRecordingDefault === "1";

    const existingRows = await all(`SELECT key, value FROM twilio_runtime_config`);
    const existing = new Map(
      (Array.isArray(existingRows) ? existingRows : []).map((r) => [String(r.key || ""), String(r.value || "")])
    );

    async function upsertSecret(key, raw) {
      const provided = typeof raw === "string" ? raw : "";
      if (provided === "__clear__") {
        await run(`DELETE FROM twilio_runtime_config WHERE key = ?`, [key]);
        return "";
      }
      if (!provided.trim()) {
        const prev = decryptSecret(existing.get(key) || "");
        return prev;
      }
      const trimmed = provided.trim();
      if (key === "authToken" && !isLikelyTwilioAuthToken(trimmed)) {
        throw new Error(
          "Twilio Auth Token does not look valid. Paste the token from Twilio Console (32 characters), not your CRM login password."
        );
      }
      if (key === "apiSecret" && isLikelyTwilioAuthToken(trimmed)) {
        throw new Error(
          "That value is the Auth Token (32 hex characters). API Secret is the longer secret shown once when you create an API key in Twilio Console (Account → API keys & tokens)."
        );
      }
      if (key === "apiSecret" && !isLikelyTwilioApiSecret(trimmed)) {
        throw new Error(
          "Twilio API Secret does not look valid. Paste the secret from when you created the API key — not the Auth Token."
        );
      }
      const encrypted = encryptSecret(trimmed);
      await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, [key, encrypted]);
      return trimmed;
    }

    const existingAccountSid = String(existing.get("accountSid") || "").trim();
    const existingApiKey = String(existing.get("apiKey") || "").trim();
    const existingTwimlAppSid = String(existing.get("voiceTwimlAppSid") || "").trim();
    /* A save that only sends Account SID and Auth Token must not wipe the
       forwarding number or headset identity stored earlier. */
    const voiceIdentity = bodyHas("voiceIdentity")
      ? String(req.body.voiceIdentity || "").trim()
      : String(existing.get("voiceIdentity") || process.env.TWILIO_VOICE_IDENTITY || "").trim();
    const inboundForwardTo = bodyHas("inboundForwardTo")
      ? String(req.body.inboundForwardTo || "").trim()
      : String(existing.get("inboundForwardTo") || process.env.TWILIO_INBOUND_FORWARD_TO || "").trim();
    const nextAccountSid = accountSid || existingAccountSid;
    const nextApiKey = apiKey || existingApiKey;
    const nextTwimlAppSid = voiceTwimlAppSid || existingTwimlAppSid;

    if (nextAccountSid && !isLikelyTwilioAccountSid(nextAccountSid)) {
      return res.status(400).json({
        error: "Twilio Account SID must start with AC followed by 32 hex characters (from Twilio Console)."
      });
    }
    if (nextApiKey && !isLikelyTwilioApiKey(nextApiKey)) {
      return res.status(400).json({
        error:
          "Twilio API Key must be an API Key SID (starts with SK). Create one in Twilio Console → Account → API keys & tokens."
      });
    }

    const newAuthToken = await upsertSecret("authToken", rawAuthToken);
    const newApiSecret = await upsertSecret("apiSecret", rawApiSecret);
    const prevApiKey = String(existing.get("apiKey") || "").trim();
    if (apiKey && apiKey !== prevApiKey && !String(rawApiSecret || "").trim()) {
      return res.status(400).json({
        error:
          "You changed the API Key — re-enter the API Secret from the same Twilio API key on this save (Twilio only shows the secret once at creation)."
      });
    }
    if (nextApiKey && nextTwimlAppSid && nextAccountSid) {
      const storedApiSecret = String(decryptSecret(existing.get("apiSecret") || "") || "").trim();
      const secretToTest = newApiSecret || storedApiSecret;
      const changingVoiceKey = Boolean(String(apiKey || "").trim() || String(rawApiSecret || "").trim());
      if (!secretToTest) {
        if (changingVoiceKey) {
          return res.status(400).json({
            error:
              "API Secret is required for headset calling. Click the API Secret field, paste the secret from when you created the API key, and save again."
          });
        }
        /* Stored API secret cannot be read. Still save Account SID and Auth Token
           so phone calls work. Headset setup can create a new API key afterward. */
      } else {
        const voiceCredCheck = await verifyTwilioVoiceApiCredentials({
          accountSid: nextAccountSid,
          apiKey: nextApiKey,
          apiSecret: secretToTest,
          voiceTwimlAppSid: nextTwimlAppSid
        });
        if (!voiceCredCheck.ok && changingVoiceKey) {
          let hint = voiceCredCheck.error;
          if (/20003/i.test(String(voiceCredCheck.error || ""))) {
            hint +=
              " Also check: Account SID must be from the same Twilio account where you created the API key; remove any TWILIO_API_SECRET line from the server .env file if present.";
          }
          return res.status(400).json({ error: hint });
        }
      }
    }

    await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, ["accountSid", nextAccountSid]);
    await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, ["apiKey", nextApiKey]);
    await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, [
      "voiceTwimlAppSid",
      nextTwimlAppSid
    ]);
    await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, ["voiceIdentity", voiceIdentity]);
    await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, [
      "inboundForwardTo",
      inboundForwardTo
    ]);
    if (hasAgentName) {
      await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, ["agentName", agentName]);
      process.env.CRM_AGENT_NAME = agentName;
    }
    if (hasAgentPhone) {
      await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, ["agentPhone", agentPhone]);
      process.env.CRM_AGENT_PHONE = agentPhone;
    }
    if (hasCallRecordingPref) {
      await setCallRecordingDefault(run, callRecordingDefault);
    }
    if (nextAccountSid) process.env.TWILIO_ACCOUNT_SID = nextAccountSid;
    if (newAuthToken) {
      process.env.TWILIO_AUTH_TOKEN = newAuthToken;
      voiceBrowserRepairAttempted = false;
    }
    if (nextApiKey) process.env.TWILIO_API_KEY = nextApiKey;
    if (newApiSecret) process.env.TWILIO_API_SECRET = newApiSecret;
    if (nextTwimlAppSid) process.env.TWILIO_VOICE_TWIML_APP_SID = nextTwimlAppSid;
    process.env.TWILIO_VOICE_IDENTITY = voiceIdentity;
    process.env.TWILIO_INBOUND_FORWARD_TO = inboundForwardTo;
    let voiceWebhookSync = null;
    if (nextTwimlAppSid && nextApiKey && newApiSecret) {
      try {
        voiceWebhookSync = await ensureVoiceTwimlAppWebhookSynced(req, {
          appSid: nextTwimlAppSid,
          force: true
        });
      } catch (syncErr) {
        console.warn("[voice] TwiML app webhook sync failed:", syncErr.message || syncErr);
        voiceWebhookSync = { synced: false, error: syncErr.message || String(syncErr) };
      }
    }
    let voiceWebhookTest = null;
    if (isVoiceBrowserConfigured()) {
      try {
        voiceWebhookTest = await runVoiceWebhookReachabilityTest(req, { force: true });
      } catch (testErr) {
        voiceWebhookTest = { ok: false, hint: testErr.message || String(testErr) };
      }
    }
    return res.json({
      ok: true,
      hasAuthToken: Boolean(newAuthToken),
      authTokenMasked: maskSecret(newAuthToken),
      hasApiSecret: Boolean(newApiSecret),
      apiSecretMasked: maskSecret(newApiSecret),
      voiceWebhookSync,
      voiceWebhookTest
    });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/runtime/config", async (req, res) => {
  try {
    const rows = await all(`SELECT key, value FROM twilio_runtime_config`);
    const map = new Map((Array.isArray(rows) ? rows : []).map((r) => [String(r.key || ""), String(r.value || "")]));
    const crmPublicUrl = normalizeCrmPublicUrl(resolveCrmPublicUrlForRequest(req, map.get("crmPublicUrl")));
    const publicUrlTrackingHint = buildPublicUrlTrackingHint(req, crmPublicUrl);
    const loginEmail = String(map.get("loginEmail") || process.env.CRM_LOGIN_EMAIL || "")
      .trim()
      .toLowerCase();
    const hasLoginPassword = Boolean(String(map.get("loginPasswordHash") || "").trim());
    const targets = await getConfiguredSocialTargets();
    const socialExtraPlatforms = String(map.get("socialExtraPlatforms") || "").trim();
    const socialWebhooks = {};
    for (const target of targets) {
      const key = normalizeSocialTarget(target);
      if (!key) continue;
      socialWebhooks[key] = String(map.get(`socialWebhook:${key}`) || "").trim();
    }
    const login2faEnabled = String(map.get("login2faEnabled") || "").trim() === "1";
    return res.json({
      crmPublicUrl,
      publicUrlTrackingHint,
      loginEmail,
      hasLoginPassword,
      login2faEnabled,
      socialExtraPlatforms,
      socialWebhooks
    });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Failed to load runtime config" });
  }
});

app.get("/api/runtime/build-stamp", (req, res) => {
  const trialUiOnDisk = fs.existsSync(path.join(publicDir, "trialWorkspaceUi.js"));
  return res.json({
    buildStampText,
    deployUiStamp: DEPLOY_UI_STAMP,
    appBootStamp,
    trialWorkspaceUiFile: trialUiOnDisk
  });
});

app.get("/api/runtime/setup-status", sendSetupStatusJson);

app.post("/api/runtime/social-webhooks/test", async (req, res) => {
  const target = normalizeSocialTarget(req.body?.target || "test") || "test";
  const url = String(req.body?.url || "").trim();
  if (!/^https?:\/\/[^\s]+$/i.test(url)) {
    return res.status(400).json({ error: "Enter a full webhook URL that starts with http:// or https://." });
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "User-Agent": "CadenceCRM-Webhook-Test/1.0" },
      body: JSON.stringify({
        target,
        message: "Cadence CRM webhook test",
        mediaUrl: `${socialMediaPublicOrigin(req)}/og-share.png`,
        test: true,
        sentAt: new Date().toISOString()
      }),
      signal: controller.signal
    });
    const text = await response.text().catch(() => "");
    if (!response.ok) {
      return res.status(502).json({
        error: `Webhook returned ${response.status}.`,
        statusCode: response.status,
        responseText: String(text || "").slice(0, 500)
      });
    }
    return res.json({ ok: true, statusCode: response.status, responseText: String(text || "").slice(0, 500) });
  } catch (error) {
    const timedOut = error && error.name === "AbortError";
    return res.status(502).json({ error: timedOut ? "Webhook test timed out." : error.message || "Webhook test failed." });
  } finally {
    clearTimeout(timer);
  }
});

app.get("/api/runtime/agent-profile", async (req, res) => {
  try {
    const rows = await all(
      `SELECT key, value FROM twilio_runtime_config WHERE key IN ('agentName', 'agentPhone', 'smsEnding')`
    );
    const map = new Map((Array.isArray(rows) ? rows : []).map((r) => [String(r.key || ""), String(r.value || "")]));
    const smsEndingSaved = map.has("smsEnding");
    return res.json({
      agentName: String(map.get("agentName") || process.env.CRM_AGENT_NAME || "").trim(),
      agentPhone: String(map.get("agentPhone") || process.env.CRM_AGENT_PHONE || "").trim(),
      smsEnding: smsEndingSaved ? String(map.get("smsEnding") || "") : "Reply STOP to opt out.",
      smsEndingSaved
    });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.put("/api/runtime/agent-profile", async (req, res) => {
  try {
    const body = req.body || {};
    const touchesName = Object.prototype.hasOwnProperty.call(body, "agentName");
    const touchesPhone = Object.prototype.hasOwnProperty.call(body, "agentPhone");
    const touchesEnding = Object.prototype.hasOwnProperty.call(body, "smsEnding");
    let agentName = "";
    let agentPhone = "";
    let smsEnding = "";
    if (touchesName) {
      agentName = String(body.agentName || "").trim();
      await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, ["agentName", agentName]);
      process.env.CRM_AGENT_NAME = agentName;
    }
    if (touchesPhone) {
      agentPhone = String(body.agentPhone || "").trim();
      await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, ["agentPhone", agentPhone]);
      process.env.CRM_AGENT_PHONE = agentPhone;
    }
    if (touchesEnding) {
      smsEnding = String(body.smsEnding || "").replace(/[ \t\u00A0]+$/g, "").trim().slice(0, 300);
      await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, ["smsEnding", smsEnding]);
      process.env.CRM_SMS_ENDING = smsEnding;
    }
    return res.json({ ok: true, agentName, agentPhone, smsEnding });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

const DEFAULT_HEALTHSHERPA_URL = "https://www.healthsherpa.com/sessions/new";

function normalizeHealthSherpaUrl(raw) {
  const url = String(raw || "").trim();
  if (!url) return "";
  if (!/^https?:\/\/[^\s]+$/i.test(url)) return null;
  return url;
}

app.get("/api/runtime/healthsherpa", async (req, res) => {
  try {
    const row = await get(`SELECT value FROM twilio_runtime_config WHERE key = ?`, ["healthSherpaUrl"]);
    const stored = String(row?.value || "").trim();
    return res.json({
      url: stored || DEFAULT_HEALTHSHERPA_URL,
      custom: Boolean(stored)
    });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Failed to load HealthSherpa URL" });
  }
});

app.put("/api/runtime/healthsherpa", async (req, res) => {
  try {
    const normalized = normalizeHealthSherpaUrl(req.body?.url);
    if (normalized === null) {
      return res.status(400).json({ error: "HealthSherpa URL must start with http:// or https://" });
    }
    await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, [
      "healthSherpaUrl",
      normalized
    ]);
    return res.json({
      ok: true,
      url: normalized || DEFAULT_HEALTHSHERPA_URL,
      custom: Boolean(normalized)
    });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Failed to save HealthSherpa URL" });
  }
});

async function readStoredThanksIoApiKey() {
  const row = await get(`SELECT value FROM twilio_runtime_config WHERE key = ?`, ["thanksIoApiKey"]);
  const fromDb = String(decryptSecret(row?.value) || "").trim();
  if (fromDb) return fromDb;
  return String(process.env.THANKS_IO_API_KEY || "").trim();
}

app.get("/api/thanksio/config", async (req, res) => {
  try {
    const token = await readStoredThanksIoApiKey();
    return res.json({
      configured: Boolean(token),
      preview: maskThanksIoToken(token),
      appUrl: THANKS_IO_APP_URL
    });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Failed to load Thanks.io settings" });
  }
});

app.put("/api/thanksio/config", async (req, res) => {
  try {
    const raw = String(req.body?.apiKey ?? req.body?.token ?? "").trim();
    const clear = raw === "__clear__" || req.body?.clear === true;
    if (clear) {
      await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, [
        "thanksIoApiKey",
        ""
      ]);
      delete process.env.THANKS_IO_API_KEY;
      return res.json({ ok: true, configured: false, preview: "", appUrl: THANKS_IO_APP_URL });
    }
    if (!raw) {
      const existing = await readStoredThanksIoApiKey();
      return res.json({
        ok: true,
        configured: Boolean(existing),
        preview: maskThanksIoToken(existing),
        appUrl: THANKS_IO_APP_URL
      });
    }
    await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, [
      "thanksIoApiKey",
      encryptSecret(raw)
    ]);
    process.env.THANKS_IO_API_KEY = raw;
    return res.json({
      ok: true,
      configured: true,
      preview: maskThanksIoToken(raw),
      appUrl: THANKS_IO_APP_URL
    });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Failed to save Thanks.io API key" });
  }
});

app.post("/api/thanksio/test", async (req, res) => {
  try {
    const override = String(req.body?.apiKey || req.body?.token || "").trim();
    const token = override || (await readStoredThanksIoApiKey());
    const result = await verifyThanksIoApiKey(token);
    if (!result.ok) return res.status(400).json({ error: result.error || "Thanks.io test failed" });
    return res.json({ ok: true, configured: true, preview: maskThanksIoToken(token) });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Thanks.io test failed" });
  }
});


async function readStoredAnthropicApiKey() {
  if (isTrialTenantContext()) {
    return sanitizeAnthropicApiKey(process.env.ANTHROPIC_API_KEY || "");
  }
  const row = await get(`SELECT value FROM twilio_runtime_config WHERE key = ?`, ["anthropicApiKey"]);
  const fromDb = sanitizeAnthropicApiKey(decryptSecret(row?.value) || "");
  if (fromDb) return fromDb;
  return sanitizeAnthropicApiKey(process.env.ANTHROPIC_API_KEY || "");
}

function rejectCustomerClaudeKey(req, res) {
  if (!isTrialWorkspaceSession(req) && !isTrialTenantContext()) return false;
  res.status(403).json({
    error: "Claude is included with Cadence. Customers do not add an API key."
  });
  return true;
}

app.get("/api/anthropic/config", async (req, res) => {
  try {
    const token = await readStoredAnthropicApiKey();
    return res.json({
      configured: Boolean(token),
      preview: maskAnthropicApiKey(token)
    });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Failed to load Claude settings" });
  }
});

app.put("/api/anthropic/config", async (req, res) => {
  try {
    if (rejectCustomerClaudeKey(req, res)) return;
    const raw = sanitizeAnthropicApiKey(req.body?.apiKey ?? req.body?.token ?? "");
    const clear = raw === "__clear__" || req.body?.clear === true;
    if (clear) {
      await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, [
        "anthropicApiKey",
        ""
      ]);
      delete process.env.ANTHROPIC_API_KEY;
      return res.json({ ok: true, configured: false, preview: "" });
    }
    if (!raw) {
      const existing = await readStoredAnthropicApiKey();
      return res.json({
        ok: true,
        configured: Boolean(existing),
        preview: maskAnthropicApiKey(existing)
      });
    }
    if (!/^sk-ant-/.test(raw) || raw.length < 80) {
      return res.status(400).json({
        error: "Paste the full Claude API key from console.anthropic.com. It starts with sk-ant-."
      });
    }
    await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, [
      "anthropicApiKey",
      encryptSecret(raw)
    ]);
    process.env.ANTHROPIC_API_KEY = raw;
    return res.json({
      ok: true,
      configured: true,
      preview: maskAnthropicApiKey(raw)
    });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Failed to save Claude API key" });
  }
});

app.post("/api/anthropic/test", async (req, res) => {
  try {
    if (rejectCustomerClaudeKey(req, res)) return;
    const override = sanitizeAnthropicApiKey(req.body?.apiKey || req.body?.token || "");
    const token = override || (await readStoredAnthropicApiKey());
    const result = await verifyAnthropicApiKey(token);
    if (!result.ok) return res.status(400).json({ error: result.error || "Claude test failed" });
    return res.json({ ok: true, configured: true, preview: maskAnthropicApiKey(token) });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Claude test failed" });
  }
});

app.put("/api/runtime/config", async (req, res) => {
  try {
    let crmPublicUrl = normalizeCrmPublicUrl(req.body?.crmPublicUrl || "");
    const crmPublicUrlHadPath = crmPublicUrlHasPathSuffix(crmPublicUrl);
    if (crmPublicUrlHadPath) {
      crmPublicUrl = getWebhookPublicOrigin(crmPublicUrl);
    }
    if (isTrialWorkspaceSession(req)) {
      if (!crmPublicUrl || isLegacyOwnerPublicUrl(crmPublicUrl)) {
        crmPublicUrl = getTrialWelcomeLoginBase();
      }
    }
    const loginEmail = String(req.body?.loginEmail || "")
      .trim()
      .toLowerCase();
    const socialExtraPlatforms = String(req.body?.socialExtraPlatforms || "").trim();
    const socialWebhooksInput =
      req.body && typeof req.body.socialWebhooks === "object" && req.body.socialWebhooks ? req.body.socialWebhooks : {};
    const trialWorkspace = isTrialTenantContext();
    const clearLoginPassword = !trialWorkspace && Boolean(req.body?.clearLoginPassword);
    const loginPassword = trialWorkspace ? "" : String(req.body?.loginPassword ?? "");
    const loginPasswordConfirm = trialWorkspace ? "" : String(req.body?.loginPasswordConfirm ?? "");
    if (crmPublicUrl && !/^https?:\/\/[^\s]+$/i.test(crmPublicUrl)) {
      return res.status(400).json({ error: "CRM Public URL must start with http:// or https://" });
    }
    if (loginEmail && !isEmailLike(loginEmail)) {
      return res.status(400).json({ error: "Login email must be a valid email address." });
    }
    for (const value of Object.values(socialWebhooksInput)) {
      const url = String(value || "").trim();
      if (url && !/^https?:\/\/[^\s]+$/i.test(url)) {
        return res.status(400).json({ error: "Social webhook URLs must start with http:// or https://" });
      }
    }
    if (clearLoginPassword) {
      await run(`DELETE FROM twilio_runtime_config WHERE key = ?`, ["loginPasswordHash"]);
      process.env.CRM_LOGIN_PASSWORD_HASH = "";
    } else {
      const pw = loginPassword.trim();
      const pwc = loginPasswordConfirm.trim();
      if (pw || pwc) {
        if (!loginEmail) {
          return res.status(400).json({ error: "Set a login email before setting a login password." });
        }
        if (pw !== pwc) {
          return res.status(400).json({ error: "Login password and confirmation do not match." });
        }
        if (pw.length < 8) {
          return res.status(400).json({ error: "Login password must be at least 8 characters." });
        }
        const hashed = hashLoginPassword(pw);
        await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, [
          "loginPasswordHash",
          hashed
        ]);
        process.env.CRM_LOGIN_PASSWORD_HASH = hashed;
      }
    }
    await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, ["crmPublicUrl", crmPublicUrl]);
    if (!trialWorkspace) {
      await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, ["loginEmail", loginEmail]);
    }
    await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, [
      "socialExtraPlatforms",
      socialExtraPlatforms
    ]);
    const targets = await getConfiguredSocialTargets();
    for (const target of targets) {
      const norm = normalizeSocialTarget(target);
      if (!norm) continue;
      const webhook = String(socialWebhooksInput[norm] || socialWebhooksInput[target] || "").trim();
      await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, [`socialWebhook:${norm}`, webhook]);
    }
    process.env.CRM_PUBLIC_URL = crmPublicUrl;
    if (!trialWorkspace) {
      process.env.CRM_LOGIN_EMAIL = loginEmail;
      if (!loginEmail) {
        for (const [token, session] of authSessions) {
          if (!session?.tenantId || Number(session.tenantId) === LEGACY_TENANT_ID) authSessions.delete(token);
        }
        await run(`DELETE FROM twilio_runtime_config WHERE key = ?`, ["loginPasswordHash"]);
        process.env.CRM_LOGIN_PASSWORD_HASH = "";
      }
    }
    const hasLoginPassword = Boolean(getConfiguredLoginPasswordHash());
    let voiceWebhookResync = null;
    if (isVoiceBrowserConfigured()) {
      try {
        voiceWebhookResync = await ensureVoiceTwimlAppWebhookSynced(req, { force: true });
      } catch (syncErr) {
        voiceWebhookResync = { synced: false, error: syncErr.message || String(syncErr) };
      }
    }
    return res.json({
      ok: true,
      crmPublicUrl,
      crmPublicUrlHadPath,
      crmPublicUrlPathWarning: crmPublicUrlHadPath
        ? "Removed /crm (or other path) from CRM Public URL. Use the site root only so Twilio voice webhooks work."
        : null,
      voiceWebhookResync,
      loginEmail,
      hasLoginPassword,
      socialExtraPlatforms
    });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Failed to save runtime config" });
  }
});

app.delete("/api/twilio/builtin-from-numbers/:line", async (req, res) => {
  try {
    if (rejectUnlessOwnerWorkspace(req, res)) return;
    const line = normalizeTwilioLineKey(req.params.line);
    if (!line) return res.status(400).json({ error: "Invalid line key" });
    await run(`INSERT OR REPLACE INTO twilio_hidden_lines (line_key, hidden_at) VALUES (?, CAST(strftime('%s','now') AS INTEGER))`, [
      line
    ]);
    return res.json({ ok: true, line });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.patch("/api/twilio/builtin-from-numbers/:line/label", async (req, res) => {
  try {
    if (rejectUnlessOwnerWorkspace(req, res)) return;
    const line = normalizeTwilioLineKey(req.params.line);
    if (!line) return res.status(400).json({ error: "Invalid line key" });
    const label = String(req.body?.label || "").trim();
    await run(`INSERT OR REPLACE INTO twilio_line_labels (line_key, label) VALUES (?, ?)`, [line, label]);
    return res.json({ ok: true, line, label });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/twilio/custom-from-numbers", async (req, res) => {
  try {
    if (rejectUnlessOwnerWorkspace(req, res)) return;
    const number = normalizeTwilioPhoneInput(req.body?.number);
    const label = String(req.body?.label || "").trim();
    if (!number) return res.status(400).json({ error: "Valid phone number is required (E.164)." });
    const ins = await run(`INSERT INTO twilio_from_numbers (phone_number, label) VALUES (?, ?)`, [number, label]);
    const row = await get(`SELECT id, phone_number, label FROM twilio_from_numbers WHERE id = ?`, [ins.lastID]);
    return res.status(201).json({
      id: Number(row.id),
      number: String(row.phone_number || ""),
      label: String(row.label || "")
    });
  } catch (error) {
    if (String(error?.message || "").toLowerCase().includes("unique")) {
      return res.status(409).json({ error: "Phone number already exists." });
    }
    return res.status(500).json({ error: error.message });
  }
});

app.delete("/api/twilio/custom-from-numbers/:id", async (req, res) => {
  try {
    if (rejectUnlessOwnerWorkspace(req, res)) return;
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const result = await run(`DELETE FROM twilio_from_numbers WHERE id = ?`, [id]);
    if (!result.changes) return res.status(404).json({ error: "Number not found" });
    return res.json({ ok: true, id });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.patch("/api/twilio/custom-from-numbers/:id/label", async (req, res) => {
  try {
    if (rejectUnlessOwnerWorkspace(req, res)) return;
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    const label = String(req.body?.label || "").trim();
    const result = await run(`UPDATE twilio_from_numbers SET label = ? WHERE id = ?`, [label, id]);
    if (!result.changes) return res.status(404).json({ error: "Number not found" });
    return res.json({ ok: true, id, label });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

function isRecordingCallbackReady(publicOrigin) {
  const url = String(publicOrigin || "").trim();
  if (!/^https:\/\//i.test(url)) return false;
  return !isPrivateOrLocalHostname(hostnameFromUrlOrHost(url));
}

async function getRecordingPublicOrigin(req) {
  const fromEnv = String(process.env.CRM_PUBLIC_URL || "").trim().replace(/\/$/, "");
  if (fromEnv) return fromEnv;
  try {
    const row = await get(`SELECT value FROM twilio_runtime_config WHERE key = ?`, ["crmPublicUrl"]);
    const stored = resolveCrmPublicUrlForRequest(req, row?.value);
    if (stored) return String(stored).trim().replace(/\/$/, "");
  } catch {
    /* ignore */
  }
  return getPublicOrigin(req).replace(/\/$/, "");
}

function isPublicHttpsOrigin(origin) {
  const raw = getWebhookPublicOrigin(origin);
  if (!/^https:\/\//i.test(raw)) return false;
  return !isPrivateOrLocalHostname(hostnameFromUrlOrHost(raw));
}

/** Live HTTPS origin Twilio can actually reach. Never localhost — saving Twilio
 *  from the local app used to overwrite the TwiML App Voice URL with localhost,
 *  which breaks production headset calls and leaves local calls stuck on Starting. */
async function resolveVoiceWebhookPublicOrigin(req) {
  const candidates = [];
  const fromEnv = String(process.env.CRM_PUBLIC_URL || "").trim().replace(/\/$/, "");
  if (fromEnv) candidates.push(fromEnv);
  try {
    const row = await get(`SELECT value FROM twilio_runtime_config WHERE key = ?`, ["crmPublicUrl"]);
    const stored = resolveCrmPublicUrlForRequest(req, row?.value);
    if (stored) candidates.push(String(stored).trim().replace(/\/$/, ""));
  } catch {
    /* ignore */
  }
  const requestOrigin = getPublicOrigin(req).replace(/\/$/, "");
  if (requestOrigin) candidates.push(requestOrigin);
  for (const candidate of candidates) {
    const origin = getWebhookPublicOrigin(candidate);
    if (isPublicHttpsOrigin(origin)) return origin;
  }
  return "";
}

function buildVoiceWebhookUrl(publicOrigin) {
  const base = getWebhookPublicOrigin(publicOrigin);
  return base ? `${base}/webhooks/twilio/voice` : "";
}

async function probeVoiceWebhookUrl(url, authToken, testParams) {
  const target = String(url || "").trim().replace(/\/$/, "");
  if (!target || !authToken) {
    return { ok: false, status: 0, snippet: "", url: target };
  }
  let status = 0;
  let snippet = "";
  try {
    const signature = computeTwilioWebhookSignature(authToken, target, testParams);
    const formBody = new URLSearchParams(
      Object.entries(testParams).map(([k, v]) => [k, String(v)])
    ).toString();
    const extRes = await fetch(target, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "X-Twilio-Signature": signature
      },
      body: formBody,
      redirect: "follow"
    });
    status = extRes.status;
    snippet = String(await extRes.text()).slice(0, 240);
  } catch (err) {
    snippet = String(err.message || err).slice(0, 240);
  }
  const ok = status >= 200 && status < 300 && snippet.includes("<Response>");
  return { ok, status, snippet, url: target };
}

async function getVoiceTwimlAppDiagnostics(req) {
  const publicOrigin = await resolveVoiceWebhookPublicOrigin(req);
  const voiceWebhookUrl = buildVoiceWebhookUrl(publicOrigin);
  const appSid = String(process.env.TWILIO_VOICE_TWIML_APP_SID || "").trim();
  if (!isVoiceBrowserConfigured() || !appSid || !voiceWebhookUrl) {
    return {
      voiceWebhookUrl: voiceWebhookUrl || null,
      twimlAppVoiceUrl: null,
      voiceWebhookSynced: false
    };
  }
  try {
    const app = await fetchVoiceTwimlApp(appSid);
    const current = String(app.voiceUrl || "").trim().replace(/\/$/, "");
    const expected = voiceWebhookUrl.replace(/\/$/, "");
    return {
      voiceWebhookUrl: expected,
      twimlAppVoiceUrl: current || null,
      voiceWebhookSynced: current === expected
    };
  } catch (err) {
    console.warn("[voice] Could not read TwiML app:", err.message || err);
    return {
      voiceWebhookUrl: voiceWebhookUrl.replace(/\/$/, ""),
      twimlAppVoiceUrl: null,
      voiceWebhookSynced: false
    };
  }
}

async function ensureVoiceTwimlAppWebhookSynced(req, options = {}) {
  const publicOrigin = await resolveVoiceWebhookPublicOrigin(req);
  const voiceWebhookUrl = buildVoiceWebhookUrl(publicOrigin);
  const appSid = String(
    options.appSid || process.env.TWILIO_VOICE_TWIML_APP_SID || ""
  ).trim();
  if (!appSid || !voiceWebhookUrl || !isVoiceBrowserConfigured()) {
    return {
      synced: false,
      skipped: true,
      voiceWebhookUrl: voiceWebhookUrl || null,
      error: voiceWebhookUrl
        ? null
        : "CRM Public URL must be a live HTTPS site (not localhost) so Twilio can reach /webhooks/twilio/voice."
    };
  }
  const diagnostics = await getVoiceTwimlAppDiagnostics(req);
  if (diagnostics.voiceWebhookSynced && !options.force) {
    if (diagnostics.twimlAppVoiceUrl) {
      cachedTwimlAppVoiceUrl = String(diagnostics.twimlAppVoiceUrl).trim().replace(/\/$/, "");
    }
    return {
      synced: true,
      skipped: false,
      voiceWebhookUrl: diagnostics.voiceWebhookUrl,
      twimlAppVoiceUrl: diagnostics.twimlAppVoiceUrl
    };
  }
  const updated = await syncVoiceTwimlAppUrl({ appSid, voiceWebhookUrl });
  cachedTwimlAppVoiceUrl = String(updated.voiceUrl || voiceWebhookUrl).trim().replace(/\/$/, "");
  return {
    synced: true,
    skipped: false,
    voiceWebhookUrl: String(updated.voiceUrl || voiceWebhookUrl).trim(),
    twimlAppVoiceUrl: String(updated.voiceUrl || "").trim()
  };
}

let voiceBrowserRepairAttempted = false;

async function persistTwilioRuntimeValue(key, value) {
  await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, [key, value]);
}

/** If REST calling works (Account SID + Auth Token) but headset tokens fail, create a matching API key / TwiML app. */
async function ensureVoiceBrowserCredentials(req) {
  try {
    await loadTwilioRuntimeConfigFromDb();
  } catch {
    /* ignore */
  }
  const configured = isVoiceBrowserConfigured();
  let check = configured
    ? await verifyTwilioVoiceApiCredentials()
    : { ok: false, error: "Computer audio is missing API Key, API Secret, or TwiML App SID." };
  if (check.ok) return check;
  if (voiceBrowserRepairAttempted) return check;
  voiceBrowserRepairAttempted = true;

  const accountSid = String(process.env.TWILIO_ACCOUNT_SID || "").trim();
  const authToken = String(process.env.TWILIO_AUTH_TOKEN || "").trim();
  if (!accountSid || !authToken) {
    return {
      ok: false,
      error:
        "Computer audio needs Twilio Account SID and Auth Token in Settings → Twilio so Cadence can create a Voice API key."
    };
  }

  const credErr = String(check.error || "");
  const needNewKey =
    !String(process.env.TWILIO_API_KEY || "").trim() ||
    !String(process.env.TWILIO_API_SECRET || "").trim() ||
    /20003|API Key\/Secret|authenticate|do not match/i.test(credErr);
  if (needNewKey) {
    try {
      const keys = await provisionVoiceApiKey({ accountSid, authToken });
      await persistTwilioRuntimeValue("apiKey", keys.apiKey);
      await persistTwilioRuntimeValue("apiSecret", encryptSecret(keys.apiSecret));
      process.env.TWILIO_API_KEY = keys.apiKey;
      process.env.TWILIO_API_SECRET = keys.apiSecret;
      console.log("[voice] Auto-provisioned Twilio API key", keys.apiKey);
    } catch (err) {
      const message = err && err.message ? err.message : String(err);
      console.warn("[voice] API key auto-provision failed:", message);
      return {
        ok: false,
        error:
          "Cadence could not create a voice API key with the saved Auth Token. In Settings → Your phone number, open Computer calling and paste a new API Key and API Secret from the same Twilio key. " +
          message
      };
    }
  }

  if (!String(process.env.TWILIO_VOICE_TWIML_APP_SID || "").trim()) {
    try {
      const publicOrigin = await resolveVoiceWebhookPublicOrigin(req);
      const voiceWebhookUrl = buildVoiceWebhookUrl(publicOrigin);
      const app = await createVoiceTwimlApp({ voiceWebhookUrl });
      if (app.sid) {
        await persistTwilioRuntimeValue("voiceTwimlAppSid", app.sid);
        process.env.TWILIO_VOICE_TWIML_APP_SID = app.sid;
        console.log("[voice] Auto-provisioned TwiML app", app.sid);
      }
    } catch (err) {
      console.warn("[voice] TwiML app auto-provision failed:", err.message || err);
    }
  } else {
    try {
      await ensureVoiceTwimlAppWebhookSynced(req, { force: true, appSid: process.env.TWILIO_VOICE_TWIML_APP_SID });
    } catch (err) {
      console.warn("[voice] TwiML webhook sync failed:", err.message || err);
    }
  }

  if (!isVoiceBrowserConfigured()) {
    return {
      ok: false,
      error: "Computer audio still needs API Key, API Secret, and a TwiML App SID in Settings → Twilio."
    };
  }
  return verifyTwilioVoiceApiCredentials();
}

app.get("/api/twilio/voice-config", async (req, res) => {
  try {
    await ensureVoiceBrowserCredentials(req);
  } catch {
    try {
      await loadTwilioRuntimeConfigFromDb();
    } catch {
      /* ignore */
    }
  }
  const missingEnv = listVoiceBrowserConfigGaps();
  const publicOrigin = await getRecordingPublicOrigin(req);
  let callRecordingDefault = true;
  try {
    callRecordingDefault = await getCallRecordingDefault(get);
  } catch {
    callRecordingDefault = true;
  }
  const voiceProviderMode = getVoiceProviderMode() || (isSignalWireVoiceReady() ? "both" : "twilio");
  const signalwireReady = isSignalWireVoiceReady();
  const signalwireMissing = getSignalWireMissing();
  const twilioRestReady = isTwilioSmsReady();
  const voiceDiagnostics = await getVoiceTwimlAppDiagnostics(req);
  let voiceApiCredentials = { ok: false, error: null };
  const voiceFieldsPresent = isVoiceBrowserConfigured();
  if (voiceFieldsPresent) {
    voiceApiCredentials = await verifyTwilioVoiceApiCredentials();
  }
  let voiceWebhookTest = null;
  if (voiceFieldsPresent && voiceApiCredentials.ok) {
    try {
      voiceWebhookTest = await runVoiceWebhookReachabilityTest(req);
    } catch (err) {
      voiceWebhookTest = { ok: false, hint: err.message || String(err) };
    }
  }
  const voiceWebhookReachable = Boolean(voiceWebhookTest && voiceWebhookTest.ok);
  const crmPublicUrlStored = await get(`SELECT value FROM twilio_runtime_config WHERE key = 'crmPublicUrl'`).catch(() => null);
  const crmPublicUrlPathWarning = crmPublicUrlHasPathSuffix(
    resolveCrmPublicUrlForRequest(req, crmPublicUrlStored?.value)
  )
    ? "CRM Public URL must be the site root only (e.g. https://crmcadence.com) — not https://crmcadence.com/crm. A /crm path breaks headset calling (Twilio error 31005)."
    : null;
  const headsetHint = getVoiceBrowserSetupHint();
  const bothHint = signalwireReady
    ? "Headset / computer audio uses Twilio when it is set up. Phone-line Start Call can use SignalWire or Twilio — pick one on the call form."
    : headsetHint;
  res.json({
    browserCallReady: voiceFieldsPresent && voiceApiCredentials.ok,
    voiceProvider: getVoiceProvider(),
    voiceProviderMode,
    signalwireReady,
    signalwireMissing: signalwireReady ? [] : signalwireMissing,
    twilioRestReady,
    voiceApiCredentialsValid: voiceApiCredentials.ok,
    voiceApiCredentialsError: voiceApiCredentials.error || null,
    voiceWebhookReachable,
    voiceWebhookTestHint: voiceWebhookTest?.hint || crmPublicUrlPathWarning || null,
    crmPublicUrlPathWarning,
    missingEnv,
    voiceWebhookPath: "/webhooks/twilio/voice",
    voiceWebhookUrl: voiceDiagnostics.voiceWebhookUrl,
    twimlAppVoiceUrl: voiceDiagnostics.twimlAppVoiceUrl,
    voiceWebhookSynced: voiceDiagnostics.voiceWebhookSynced,
    hint: bothHint,
    publicOrigin: publicOrigin || null,
    callRecordingDefault,
    recordingReady: isRecordingCallbackReady(publicOrigin)
  });
});

app.post("/api/twilio/sync-voice-webhook", async (req, res) => {
  try {
    if (!isVoiceBrowserConfigured()) {
      return res.status(503).json({
        error: "Browser calling is not configured (API key + TwiML app).",
        missingEnv: listVoiceBrowserConfigGaps()
      });
    }
    const result = await ensureVoiceTwimlAppWebhookSynced(req, { force: true });
    return res.json({ ok: true, ...result });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

let voiceWebhookTestCache = { at: 0, result: null };
const VOICE_WEBHOOK_TEST_TTL_MS = 120_000;

async function runVoiceWebhookReachabilityTest(req, options = {}) {
  const force = Boolean(options.force);
  if (
    !force &&
    voiceWebhookTestCache.result &&
    Date.now() - voiceWebhookTestCache.at < VOICE_WEBHOOK_TEST_TTL_MS
  ) {
    return voiceWebhookTestCache.result;
  }
  if (!isVoiceBrowserConfigured()) {
    return {
      ok: false,
      skipped: true,
      hint: "Add API Key, API Secret, and Voice TwiML App SID first."
    };
  }
  const authToken = String(process.env.TWILIO_AUTH_TOKEN || "").trim();
  if (!authToken) {
    return { ok: false, hint: "Twilio Auth Token is not configured." };
  }
  const publicOrigin = await resolveVoiceWebhookPublicOrigin(req);
  const voiceWebhookUrl = buildVoiceWebhookUrl(publicOrigin);
  if (!voiceWebhookUrl) {
    return {
      ok: false,
      hint: "Set CRM Public URL in Settings → Runtime to your live HTTPS site (not localhost), then re-save Twilio."
    };
  }
  const diagnostics = await getVoiceTwimlAppDiagnostics(req);
  const testParams = {
    CallSid: `CA${"0".repeat(32)}`,
    AccountSid: String(process.env.TWILIO_ACCOUNT_SID || "").trim(),
    From: "client:crm-voice-webhook-test",
    Direction: "inbound",
    dialTo: "+15555550100",
    twilioFrom: "primary"
  };
  let internalOk = false;
  let internalSnippet = "";
  try {
    const mockRes = {
      _type: "text/xml",
      _body: "",
      type(t) {
        this._type = t;
        return this;
      },
      send(body) {
        this._body = String(body || "");
      }
    };
    await handleTwilioVoiceWebhook(
      {
        body: testParams,
        query: {},
        originalUrl: "/webhooks/twilio/voice",
        url: "/webhooks/twilio/voice",
        method: "POST",
        get: () => ""
      },
      mockRes
    );
    internalSnippet = mockRes._body.slice(0, 240);
    internalOk = mockRes._body.includes("<Dial") && mockRes._body.includes("<Number>");
  } catch (err) {
    internalSnippet = String(err.message || err).slice(0, 240);
  }

  const expectedProbe = await probeVoiceWebhookUrl(voiceWebhookUrl, authToken, testParams);
  const twimlAppUrl = String(diagnostics.twimlAppVoiceUrl || "").trim().replace(/\/$/, "");
  const expectedUrl = voiceWebhookUrl.replace(/\/$/, "");
  let twimlAppProbe = null;
  if (twimlAppUrl && twimlAppUrl !== expectedUrl) {
    twimlAppProbe = await probeVoiceWebhookUrl(twimlAppUrl, authToken, testParams);
  }
  const externalStatus = expectedProbe.status;
  const externalSnippet = expectedProbe.snippet;
  const signatureUrl = expectedProbe.url || expectedUrl;
  const externalOk = expectedProbe.ok;
  const twimlAppOk = !twimlAppProbe || twimlAppProbe.ok;
  const ok = internalOk && externalOk && twimlAppOk;
  const result = {
    ok,
    voiceWebhookUrl,
    signatureUrl,
    voiceWebhookSynced: diagnostics.voiceWebhookSynced,
    twimlAppVoiceUrl: diagnostics.twimlAppVoiceUrl,
    internalOk,
    internalSnippet,
    externalStatus,
    externalSnippet,
    twimlAppProbeStatus: twimlAppProbe?.status || 0,
    twimlAppProbeSnippet: twimlAppProbe?.snippet || "",
    hint: ok
      ? "Voice webhook is reachable and returns TwiML."
      : twimlAppProbe && !twimlAppProbe.ok
        ? twimlAppProbe.status === 404
          ? `Twilio TwiML App points to ${twimlAppUrl}, which returns 404. Save Twilio settings again — the voice URL must be ${expectedUrl} (no /crm path).`
          : `Twilio TwiML App voice URL (${twimlAppUrl}) is not reachable. Save Twilio settings to sync it to ${expectedUrl}.`
        : internalOk && !externalOk
          ? externalStatus === 403
            ? "Twilio cannot reach your voice webhook (signature rejected). Re-save Auth Token in Settings → Twilio and confirm CRM Public URL in Settings → Runtime is https://crmcadence.com with no path."
            : externalStatus === 404
              ? `Voice webhook URL ${expectedUrl} returned 404. CRM Public URL must be the site root only (https://crmcadence.com), not a /crm subpath.`
            : externalStatus === 500
              ? "Voice webhook returned HTTP 500. Restart the Node app after deploying."
              : externalStatus === 0
                ? "Could not reach your voice webhook URL. Confirm CRM Public URL in Settings → Runtime is https://crmcadence.com (no /crm path)."
                : "Voice webhook returned an unexpected response. Confirm CRM Public URL is https://crmcadence.com with no path."
          : !internalOk
            ? internalSnippet
              ? `Voice handler failed: ${internalSnippet}`
              : "Voice handler did not return dial TwiML. Check Twilio from-numbers in Settings."
            : "Voice webhook test failed. Set CRM Public URL to https://crmcadence.com (no path), then re-save Twilio."
  };
  voiceWebhookTestCache = { at: Date.now(), result };
  return result;
}

app.post("/api/twilio/test-voice-webhook", async (req, res) => {
  try {
    const result = await runVoiceWebhookReachabilityTest(req, { force: true });
    if (result.skipped) {
      return res.status(503).json({
        error: "Browser calling is not configured (API key + TwiML app).",
        missingEnv: listVoiceBrowserConfigGaps(),
        ...result
      });
    }
    return res.json(result);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/twilio/voice-token", voiceTokenLimiter, async (req, res) => {
  try {
    const repaired = await ensureVoiceBrowserCredentials(req);
    if (!isVoiceBrowserConfigured()) {
      const repairError = String(repaired?.error || "").trim();
      return res.status(503).json({
        error: repairError || "Browser calling is not configured (API key + TwiML app).",
        missingEnv: listVoiceBrowserConfigGaps(),
        hint: repairError ? "" : getVoiceBrowserSetupHint()
      });
    }
    const voiceCredCheck = repaired && repaired.ok ? repaired : await verifyTwilioVoiceApiCredentials();
    if (!voiceCredCheck.ok) {
      return res.status(503).json({
        error: voiceCredCheck.error,
        code: "voice_api_credentials",
        hint:
          "In Twilio Console → Account → API keys & tokens: create a new Standard API key. Paste SK... into API Key and the secret (shown once) into API Secret. Do not use the Auth Token as API Secret."
      });
    }
    const jwt = createVoiceAccessToken();
    if (!jwt) {
      return res.status(503).json({ error: "Could not create voice token." });
    }
    return res.json({ token: jwt });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/twilio/notify-browser-call", async (req, res) => {
  try {
    const { contactId, phone, callSid } = req.body || {};
    const record = await resolveShouldRecordCall(req, req.body || {});
    const sid = String(callSid || "").trim();
    await recordCallStarted({ contactId, phone, callSid: sid, record });
    if (record && sid) {
      const publicOrigin = await getRecordingPublicOrigin(req);
      const callbackUrl = buildRecordingStatusCallbackUrl(publicOrigin, {
        contactId: Number(contactId) || undefined,
        callSid: sid,
        phone: String(phone || "").trim()
      });
      if (callbackUrl) {
        const cid = Number(contactId);
        await trackCallRecordingPending(run, {
          callSid: sid,
          contactId: Number.isInteger(cid) && cid > 0 ? cid : 0,
          phone: String(phone || "").trim()
        }).catch((err) => console.error("trackCallRecordingPending:", err));
        try {
          await startCallRecording({ callSid: sid, recordingStatusCallback: callbackUrl });
        } catch (err) {
          console.error("browser call REST recording:", err.message || err);
        }
      }
    }
    res.json({ ok: true, record });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/twilio/sync-call-recordings", async (req, res) => {
  try {
    const contactId = Number(req.body?.contactId);
    const callSid = String(req.body?.callSid || "").trim();
    const phone = String(req.body?.phone || "").trim();
    if (!Number.isInteger(contactId) || contactId < 1) {
      return res.status(400).json({ error: "contactId is required" });
    }
    const result = await syncCallRecordingsFromTwilio(
      { run, get, all, logContactActivity },
      { contactId, callSid, phone }
    );
    const items = await listContactCallRecordings({ run, get, all, logContactActivity }, contactId);
    return res.json({ ok: true, imported: result.imported, items });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/twilio/recordings/:recordingSid/audio", async (req, res) => {
  try {
    const recordingSid = String(req.params.recordingSid || "").trim();
    if (!recordingSid) return res.status(400).send("recordingSid required");
    const accountSid = String(process.env.TWILIO_ACCOUNT_SID || "").trim();
    const authToken = String(process.env.TWILIO_AUTH_TOKEN || "").trim();
    if (!accountSid || !authToken) {
      return res.status(503).send("Twilio not configured");
    }
    const mediaUrl = `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Recordings/${recordingSid}.mp3`;
    const requestHeaders = {
      Authorization: `Basic ${Buffer.from(`${accountSid}:${authToken}`).toString("base64")}`
    };
    const range = String(req.headers.range || "").trim();
    if (range) requestHeaders.Range = range;
    const twilioRes = await fetch(mediaUrl, {
      headers: requestHeaders,
      redirect: "follow"
    });
    if (!twilioRes.ok) {
      return res.status(twilioRes.status === 404 ? 404 : 502).send("Recording unavailable");
    }
    const contentType = twilioRes.headers.get("content-type") || "audio/mpeg";
    res.status(twilioRes.status === 206 ? 206 : 200);
    res.setHeader("Content-Type", contentType);
    res.setHeader("Cache-Control", "private, max-age=3600");
    res.setHeader("Accept-Ranges", twilioRes.headers.get("accept-ranges") || "bytes");
    const contentRange = twilioRes.headers.get("content-range");
    const contentLength = twilioRes.headers.get("content-length");
    if (contentRange) res.setHeader("Content-Range", contentRange);
    if (contentLength) res.setHeader("Content-Length", contentLength);
    const buf = Buffer.from(await twilioRes.arrayBuffer());
    return res.end(buf);
  } catch (error) {
    console.error("Recording audio proxy error:", error);
    return res.status(500).send("Failed to load recording");
  }
});

/** E.164 for Dial: form-urlencoded '+' often becomes space; normalize digits. */
function normalizeWebhookDialNumber(raw) {
  let s = String(raw || "").trim();
  if (!s) return "";
  s = s.replace(/\s+/g, "").replace(/\u00a0/g, "");
  if (s.startsWith("+")) return s;
  const digits = s.replace(/\D/g, "");
  if (digits.length === 10) return "+1" + digits;
  if (digits.length === 11 && digits.startsWith("1")) return "+" + digits;
  if (digits.length >= 8 && digits.length <= 15) return "+" + digits;
  return s;
}

function getConfiguredTwilioInboundNumbers() {
  return [
    String(process.env.TWILIO_PHONE_NUMBER || "").trim(),
    String(process.env.TWILIO_PHONE_NUMBER_SECOND || "").trim(),
    String(process.env.TWILIO_PHONE_NUMBER_THIRD || "").trim()
  ]
    .map((v) => normalizeWebhookDialNumber(v))
    .filter(Boolean);
}

async function getConfiguredTwilioInboundNumbersWithProvisioned() {
  const numbers = getConfiguredTwilioInboundNumbers();
  try {
    const row = await get(`SELECT value FROM twilio_runtime_config WHERE key = 'phoneNumber'`);
    const provisioned = normalizeWebhookDialNumber(row?.value || "");
    if (provisioned && !numbers.includes(provisioned)) numbers.push(provisioned);
  } catch (_) {}
  return numbers;
}

function normalizeInboundForwardNumber(raw) {
  const n = normalizeWebhookDialNumber(raw);
  return /^\+[1-9]\d{6,14}$/.test(n) ? n : "";
}

function isE164Number(raw) {
  return /^\+[1-9]\d{6,14}$/.test(String(raw || "").trim());
}

function extractVoiceWebhookTo(body, query) {
  const b = body && typeof body === "object" ? body : {};
  const q = query && typeof query === "object" ? query : {};
  let raw = String(
    b.dialTo ||
      b.DialTo ||
      b.crmTo ||
      b.CrmTo ||
      b.phoneNumber ||
      b.PhoneNumber ||
      b.number ||
      b.Number ||
      q.dialTo ||
      q.DialTo ||
      q.crmTo ||
      q.CrmTo ||
      q.phoneNumber ||
      q.PhoneNumber ||
      b.To ||
      b.to ||
      b.Called ||
      b.called ||
      q.To ||
      q.to ||
      q.Called ||
      ""
  ).trim();
  if (!raw && b && typeof b === "object") {
    for (const v of Object.values(b)) {
      if (typeof v !== "string") continue;
      const n = normalizeWebhookDialNumber(v);
      if (isE164Number(n)) {
        raw = v.trim();
        break;
      }
    }
  }
  return raw;
}

async function handleTwilioVoiceWebhook(req, res) {
  let recordingStartXml = "";
  try {
  const body = req.body && typeof req.body === "object" ? req.body : {};
  const direction = String(body.Direction || body.direction || "").toLowerCase();
  if (direction !== "inbound") {
    console.info(
      `[voice-webhook] ${direction || "outbound"} From=${String(body.From || "").trim()} dialTo=${String(
        body.dialTo || body.DialTo || ""
      ).trim()}`
    );
  }
  const rawFrom = String(body.From || body.Caller || "").trim();
  const from = normalizeWebhookDialNumber(rawFrom);
  const called = normalizeWebhookDialNumber(body.To || body.Called || "");
  // Browser headset calls: From=client:identity and/or custom dialTo param from Device.connect().
  const dialToParam = String(
    body.dialTo || body.DialTo || body.phoneNumber || body.PhoneNumber || ""
  ).trim();
  const isBrowserClientLeg = /^client:/i.test(rawFrom);
  // Read forwarding number from DB first, fall back to env
  const forwardRow = await get(`SELECT value FROM twilio_runtime_config WHERE key = 'inboundForwardTo'`).catch(() => null);
  const inboundForwardTo = normalizeInboundForwardNumber(
    forwardRow?.value || process.env.TWILIO_INBOUND_FORWARD_TO || ""
  );
  // A call placed in the CRM carries dialTo/phoneNumber (or From=client:…).
  // Those stay on the computer and dial the contact. Only a real inbound
  // call to the Twilio number may be forwarded to the cell.
  const crmPlacedCall = isBrowserClientLeg || Boolean(dialToParam);
  const isPstnInbound =
    !crmPlacedCall &&
    (direction === "inbound" || (direction === "" && isE164Number(from)));

  if (isPstnInbound && inboundForwardTo) {
    const callerIdAttr = /^\+[1-9]\d{6,14}$/.test(from) ? ` callerId="${twilioXmlEscape(from)}"` : "";
    const twimlForward = `<?xml version="1.0" encoding="UTF-8"?><Response><Dial answerOnBridge="true"${callerIdAttr}><Number>${twilioXmlEscape(
      inboundForwardTo
    )}</Number></Dial></Response>`;
    return res.type("text/xml").send(twimlForward);
  }

  if (isPstnInbound && !inboundForwardTo) {
    return res.type("text/xml").send(
      `<?xml version="1.0" encoding="UTF-8"?><Response><Say>Thank you for calling. Our agent will be with you shortly. Please try again or leave a text message.</Say></Response>`
    );
  }
  const toRaw = extractVoiceWebhookTo(body, req.query);
  const to = normalizeWebhookDialNumber(toRaw);
  const twilioFrom = normalizeTwilioFromLine(body.twilioFrom || body.TwilioFrom || "secondary");
  if (!to || !isE164Number(to)) {
    const paramKeys = Object.keys(body).filter((k) => /to|dial|phone|number/i.test(k));
    console.warn(
      `[voice-webhook] missing dial target; param keys: ${paramKeys.join(", ") || "(none)"}`
    );
    return res
      .type("text/xml")
      .send('<?xml version="1.0" encoding="UTF-8"?><Response><Say>Missing phone number.</Say></Response>');
  }
  let callerId;
  try {
    callerId = resolveFromNumberWithFallback(twilioFrom);
  } catch (error) {
    return res
      .type("text/xml")
      .send(
        `<?xml version="1.0" encoding="UTF-8"?><Response><Say>${twilioXmlEscape(error.message)}</Say></Response>`
      );
  }
  const record = await resolveVoiceWebhookRecordEnabled(body, get);
  const publicOrigin = await getRecordingPublicOrigin(req);
  let contactId = Number(body.contactId || body.ContactId || req.query?.contactId || 0);
  if (!Number.isInteger(contactId) || contactId < 1) {
    const matched = await resolveContactIdByPhone(get, to);
    if (matched) contactId = matched;
  }
  const callSid = String(body.CallSid || "").trim();
  recordingStartXml = "";
  let dialRecordAttrs = "";
  const recordingCallbackUrl = record
    ? buildRecordingStatusCallbackUrl(publicOrigin, {
        contactId: Number.isInteger(contactId) && contactId > 0 ? contactId : undefined,
        callSid,
        phone: to
      })
    : "";
  if (record && recordingCallbackUrl) {
    if (callSid) {
      trackCallRecordingPending(run, {
        callSid,
        contactId,
        phone: to
      }).catch((err) => console.error("trackCallRecordingPending:", err));
    }
    if (isBrowserClientLeg) {
      // Recording via REST in /api/twilio/notify-browser-call — Dial record breaks WebRTC audio.
      dialRecordAttrs = "";
    } else {
      recordingStartXml = `<Start><Recording playBeep="false" recordingStatusCallback="${twilioXmlEscape(
        recordingCallbackUrl
      )}" recordingStatusCallbackMethod="POST" recordingStatusCallbackEvent="completed" /></Start>`;
    }
  } else if (record) {
    console.warn(
      "Twilio voice: recording requested but no public callback URL (set CRM_PUBLIC_URL in .env or Settings → Runtime)"
    );
  }
  // Never use <Start><Recording> on browser legs — it breaks WebRTC audio. Dial-level record only.
  if (isBrowserClientLeg) recordingStartXml = "";
  const twiml = `<?xml version="1.0" encoding="UTF-8"?><Response>${recordingStartXml}<Dial answerOnBridge="true" callerId="${twilioXmlEscape(
    callerId
  )}"${dialRecordAttrs}><Number>${twilioXmlEscape(to)}</Number></Dial></Response>`;
  if (isBrowserClientLeg) {
    console.info(
      `[voice-webhook] browser dial TwiML From=${rawFrom} dialTo=${dialToParam || to} record=${record ? "yes" : "no"}`
    );
  }
  return res.type("text/xml").send(twiml);
  } catch (err) {
    console.error("[voice-webhook] ERROR:", err.message || err);
    return res.type("text/xml").send(`<?xml version="1.0" encoding="UTF-8"?><Response><Say>We are sorry, an error occurred. Please try again.</Say></Response>`);
  }
}

function runTwilioVoiceWebhook(req, res) {
  Promise.resolve(handleTwilioVoiceWebhook(req, res)).catch((err) => {
    console.error("[voice-webhook] unhandled:", err && err.stack ? err.stack : err);
    if (res.headersSent) return;
    res
      .status(200)
      .type("text/xml")
      .send(
        '<?xml version="1.0" encoding="UTF-8"?><Response><Say>We are sorry, an error occurred. Please try again.</Say></Response>'
      );
  });
}

app.post(
  "/webhooks/twilio/voice",
  reloadTwilioConfigForWebhook,
  twilioWebhookGuard,
  runTwilioVoiceWebhook
);
app.get(
  "/webhooks/twilio/voice",
  reloadTwilioConfigForWebhook,
  twilioWebhookGuard,
  runTwilioVoiceWebhook
);

app.post("/webhooks/twilio/recording-status", reloadTwilioConfigForWebhook, twilioWebhookGuard, (req, res) =>
  handleTwilioRecordingStatusWebhook({ run, get, all, logContactActivity }, req, res)
);

registerDripRoutes(app, { run, all, get, publicOrigin: socialMediaPublicOrigin });
registerAssistantRoutes(app, { all, get, createRateLimiter });
registerRolePlayRoutes(app, { all, get, createRateLimiter, getAuthSession });
registerAiContentRoutes(app, { createRateLimiter, isOwnerWorkspaceSession });
marketingBlog
  .ensureMarketingBlogSchema()
  .catch((e) => console.error("Marketing blog schema init failed:", e));
registerAiCampaignRoute(app, { createRateLimiter });
registerReengageRoute(app, { all, getAuthSession, createRateLimiter });
registerImportRoutes(app, {
  createRateLimiter,
  run,
  get,
  scheduleAutoLeadScore,
  dbDeps,
  isOwnerWorkspaceSession
});
registerAiFeatureRoutes(app, { run, get, all, createRateLimiter });
registerEmailVerificationRoutes(app, { get, all, run, isOwnerWorkspaceSession, getAuthSession });
registerInsuranceApplicationRoutes(app, {
  platformGet,
  withTenantContext,
  openTenantDatabase,
  run,
  get,
  logContactActivity,
  LEGACY_TENANT_ID,
  publicFormsLimiter,
  sendNotifyEmail: async ({ to, subject, text }) => {
    const { sendSystemNotificationEmail } = require("./emailService");
    await sendSystemNotificationEmail({ to, subject, text });
  }
});
registerClientIntakeRoutes(app, {
  platformGet,
  withTenantContext,
  openTenantDatabase,
  run,
  get,
  logContactActivity,
  LEGACY_TENANT_ID,
  publicFormsLimiter,
  sendNotifyEmail: async ({ to, subject, text }) => {
    const { sendSystemNotificationEmail } = require("./emailService");
    await sendSystemNotificationEmail({ to, subject, text });
  }
});
registerContactWorkspaceOptionsRoutes(app, { run, get, all, isTrialWorkspaceSession, isOwnerWorkspaceSession });
registerEmailSignatureSettingsRoutes(app, { run, get });
registerEmailTemplateBrandingRoutes(app, {
  run,
  get,
  platformRun,
  platformGet,
  openTenantDatabase,
  withTenantContext,
  getAuthSession
});
registerWebinarRoutes(app, { run, all, get, withTenantContext, LEGACY_TENANT_ID });

app.get("/", (req, res) => {
  // A real login session is required. The local-setup bypass must not show
  // the Contacts app to a logged-out visitor on the public site.
  if (!getAuthSession(req)) {
    if (isCrmMarketingHost(req)) return sendMarketingPage(req, res, "crm-home.html");
    return sendMarketingPage(req, res, "welcome.html");
  }
  return res.redirect(302, "/index.html");
});

app.get("/index.html", (req, res) => {
  if (!getAuthSession(req)) {
    return res.redirect(302, "/");
  }
  sendDashboardHtml(req, res);
});

app.get(["/welcome.html", "/welcome"], (req, res) => {
  sendMarketingPage(req, res, "welcome.html");
});

app.get(["/crm-home.html", "/crm-home"], (req, res) => {
  if (!isCrmMarketingHost(req)) return res.redirect(301, "/");
  sendMarketingPage(req, res, "crm-home.html");
});

app.get(["/signup.html", "/signup"], (req, res) => {
  sendMarketingPage(req, res, "signup.html");
});

app.get(["/billing.html", "/billing"], (req, res) => {
  sendMarketingPage(req, res, "billing.html");
});

app.get(["/contact-sales.html", "/contact-sales"], (req, res) => {
  sendMarketingPage(req, res, "contact-sales.html");
});

app.get(["/agent-demo.html", "/agent-demo"], (req, res) => {
  sendMarketingPage(req, res, "agent-demo.html");
});

app.get(["/webinars.html", "/webinars"], (req, res) => {
  sendMarketingPage(req, res, "webinars.html");
});

// Public Cadence marketing blog. The index (blog.html) is server-rendered so
// AI-published posts appear alongside the hand-built cards; each post lives at
// /blog/<slug> as a fully server-rendered, indexable page. No auth (public).
app.get(["/blog", "/blog.html"], async (req, res) => {
  if (isCrmMarketingHost(req)) return res.redirect(301, "https://cadencecrm.pro/blog.html");
  try {
    const posts = await marketingBlog.listPosts({ status: "published" });
    let html = fs.readFileSync(path.join(publicDir, "blog.html"), "utf8");
    html = marketingBlog.injectPostsIntoIndex(html, posts);
    html = rewriteHeadOrigin(html, marketingOriginForRequest(req));
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
    res.type("html").send(html);
  } catch (err) {
    console.error("Blog index render failed:", err);
    if (!res.headersSent) sendMarketingPage(req, res, "blog.html");
  }
});

app.get("/blog/:slug", async (req, res) => {
  if (isCrmMarketingHost(req)) {
    return res.redirect(301, `https://cadencecrm.pro/blog/${encodeURIComponent(req.params.slug)}`);
  }
  try {
    const post = await marketingBlog.getPostBySlug(req.params.slug);
    if (!post || post.status !== "published") {
      return res.redirect(302, "/blog.html");
    }
    const origin = `${req.protocol}://${req.get("host")}`;
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
    res.type("html").send(marketingBlog.renderPostPageHtml(post, { origin }));
  } catch (err) {
    console.error("Blog post render failed:", err);
    if (!res.headersSent) res.status(500).send("Post unavailable");
  }
});

// Public JSON feed of published posts. The static blog.html fetches this and
// prepends cards client-side (the host serves blog.html directly, bypassing the
// server-side index route above).
app.get("/blog-feed.json", async (req, res) => {
  try {
    const posts = await marketingBlog.listPublishedCards();
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
    res.json({ posts });
  } catch (err) {
    console.error("Blog feed failed:", err);
    if (!res.headersSent) res.json({ posts: [] });
  }
});

app.get("/robots.txt", (req, res) => {
  const origin = isCrmMarketingHost(req) ? "https://crmcadence.com" : "https://cadencecrm.pro";
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  res.type("text/plain").send(buildRobotsTxt(origin));
});

app.get("/sitemap.xml", async (req, res) => {
  const crm = isCrmMarketingHost(req);
  const origin = crm ? "https://crmcadence.com" : "https://cadencecrm.pro";
  let xml = buildSitemapXml(origin, crm ? CRM_SITEMAP_PATHS : INSURANCE_SITEMAP_PATHS);
  if (!crm) {
    try {
      const posts = await marketingBlog.listPosts({ status: "published" });
      xml = marketingBlog.injectPostsIntoSitemap(xml, posts, origin);
    } catch (err) {
      console.error("Sitemap posts skipped:", err);
    }
  }
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  res.type("application/xml").send(xml);
});

app.get("/ai-content.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "ai-content.html");
});

app.get("/webinar-admin.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "webinar-admin.html");
});

app.post("/api/sales/contact", salesContactLimiter, async (req, res) => {
  try {
    const fullName = String(req.body?.name || req.body?.fullName || "").trim();
    const email = String(req.body?.email || "")
      .trim()
      .toLowerCase();
    const phone = String(req.body?.phone || "").trim();
    const country = String(req.body?.country || "").trim();
    const companyName = String(req.body?.companyName || req.body?.company_name || "").trim();
    const companySize = String(req.body?.companySize || req.body?.company_size || "").trim();
    const hearAbout = String(req.body?.hearAbout || req.body?.hear_about || "").trim();
    const message = String(req.body?.message || "").trim();

    if (!fullName) {
      return res.status(400).json({ error: "Name is required." });
    }
    if (!isEmailLike(email)) {
      return res.status(400).json({ error: "Enter a valid email address." });
    }
    if (!country) {
      return res.status(400).json({ error: "Country is required." });
    }
    if (!companyName) {
      return res.status(400).json({ error: "Company name is required." });
    }
    if (!companySize) {
      return res.status(400).json({ error: "Company size is required." });
    }
    if (!hearAbout) {
      return res.status(400).json({ error: "Please tell us how you heard about Cadence." });
    }

    await run(
      `INSERT INTO sales_inquiries (
         full_name, email, phone, country, company_name, company_size, hear_about, message
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [fullName, email, phone, country, companyName, companySize, hearAbout, message]
    );

    console.log(
      `[sales] Contact request: ${email} (${fullName}) company=${companyName} size=${companySize} country=${country}`
    );

    try {
      const notified = await notifyContactSalesByEmail({
        fullName,
        email,
        phone,
        country,
        companyName,
        companySize,
        hearAbout,
        message
      });
      if (notified) {
        console.log(`[sales] Contact sales notification emailed to ${getContactSalesNotificationRecipients().join(", ")}`);
      } else if (!getContactSalesNotificationRecipients().length) {
        console.warn("[sales] Contact sales saved but no notify recipients — set CONTACT_SALES_NOTIFY_EMAIL in .env");
      } else if (!(await canSendSystemNotificationEmail())) {
        console.warn(
          "[sales] Contact sales saved but no SMTP for notifications — set SMTP_* in .env, TRIAL_WELCOME_SMTP_*, or joseph@ SMTP in Settings → Email Sender Addresses"
        );
      }
    } catch (notifyErr) {
      console.error("[sales] Contact sales notify failed:", notifyErr.message || notifyErr);
    }

    return res.status(201).json({ ok: true, email });
  } catch (err) {
    console.error("Sales contact error:", err);
    return res.status(500).json({ error: "Could not submit your request. Please try again." });
  }
});

app.get(["/contact.html", "/contact-details", "/contact-details.html"], (req, res) => {
  if (shouldProtectPageRoute("/contact.html") && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "contact.html");
});

app.get("/campaigns.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "campaigns.html");
});

app.get("/calendar.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "calendar.html");
});

app.get("/journey.html", (req, res) => {
  res.redirect(302, "/automations.html");
});

app.get("/automations.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "automations.html");
});

app.get("/documents.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "documents.html");
});

app.get("/email.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "email.html");
});

app.get("/landing-pages.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "landing-pages.html");
});

app.get("/lead-capture.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "lead-capture.html");
});

app.get("/videos.html", (req, res) => {
  res.redirect(302, "/social.html#video-library");
});

app.get("/forms.html", (req, res) => {
  res.redirect(302, "/landing-pages.html");
});

app.get("/email-templates.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "email-templates.html");
});

function normalizeSocialTarget(raw) {
  return String(raw || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, "");
}

function getDefaultSocialTargets() {
  const out = ["facebook", "instagram", "x", "linkedin"];
  const extra = String(process.env.SOCIAL_EXTRA_PLATFORMS || "")
    .split(",")
    .map((s) => normalizeSocialTarget(s))
    .filter(Boolean);
  for (const t of extra) {
    if (!out.includes(t)) out.push(t);
  }
  return out.filter((t) => t !== "yelp");
}

async function getRuntimeConfigMap() {
  try {
    const rows = await all(`SELECT key, value FROM twilio_runtime_config`);
    return new Map((Array.isArray(rows) ? rows : []).map((row) => [String(row.key || ""), String(row.value || "")]));
  } catch {
    return new Map();
  }
}

async function getConfiguredSocialTargets() {
  const out = getDefaultSocialTargets();
  const configMap = await getRuntimeConfigMap();
  const extra = String(configMap.get("socialExtraPlatforms") || "")
    .split(",")
    .map((s) => normalizeSocialTarget(s))
    .filter(Boolean);
  for (const t of extra) {
    if (!out.includes(t)) out.push(t);
  }
  return out.filter((t) => t !== "yelp");
}

async function getSocialWebhookForTarget(target) {
  const norm = normalizeSocialTarget(target);
  if (!norm) return "";
  const configMap = await getRuntimeConfigMap();
  const dbWebhook = String(configMap.get(`socialWebhook:${norm}`) || "").trim();
  if (dbWebhook) return dbWebhook;
  const key = normalizeSocialTarget(target).toUpperCase().replace(/[^A-Z0-9]/g, "_");
  if (!key) return "";
  return String(process.env[`SOCIAL_${key}_WEBHOOK_URL`] || "").trim();
}

function buildPublicApiUrl(pathSegment) {
  const base = String(process.env.CRM_PUBLIC_URL || "").trim().replace(/\/$/, "");
  const path = String(pathSegment || "").startsWith("/") ? pathSegment : `/${pathSegment || ""}`;
  return base ? `${base}${path}` : path;
}

/** Picture links sent to Zapier and Facebook. Never use the old wisehealth domain. */
function socialMediaPublicOrigin(req) {
  if (req) {
    const proto = String(req.headers["x-forwarded-proto"] || req.protocol || "https").split(",")[0].trim() || "https";
    const host = String(req.headers["x-forwarded-host"] || req.get("host") || "").split(",")[0].trim();
    if (host && !isPrivateOrLocalHostname(hostnameFromUrlOrHost(host)) && !isLegacyOwnerPublicUrl(host)) {
      return `${proto}://${host}`.replace(/\/$/, "");
    }
  }
  const configured = normalizeCrmPublicUrl(String(process.env.CRM_PUBLIC_URL || "").trim());
  if (
    configured &&
    !isLegacyOwnerPublicUrl(configured) &&
    !isPrivateOrLocalHostname(hostnameFromUrlOrHost(configured))
  ) {
    return String(configured).replace(/\/$/, "");
  }
  return "https://crmcadence.com";
}

/** Long-lived: a scheduled post can fire weeks later, and Make.com/Facebook may
 *  re-fetch the image while processing. These are public marketing images. */
const SOCIAL_MEDIA_URL_TTL_MS = 1000 * 60 * 60 * 24 * 400;

function signSocialMediaToken(tenantId, mediaId, exp) {
  const data = `social-media:${Number(tenantId)}:${Number(mediaId)}:${Number(exp)}`;
  return crypto.createHmac("sha256", getAuthSigningSecret()).update(data).digest("base64url");
}

/** Signed link Make.com/Facebook can fetch WITHOUT a CRM login. The token pins
 *  the tenant + media id + expiry so it can't be used to enumerate other media. */
function buildSignedSocialMediaPath(tenantId, mediaId) {
  const tid = Number(tenantId) >= 1 ? Number(tenantId) : LEGACY_TENANT_ID;
  const exp = Date.now() + SOCIAL_MEDIA_URL_TTL_MS;
  const sig = signSocialMediaToken(tid, mediaId, exp);
  const qs = new URLSearchParams({ t: String(tid), e: String(exp), s: sig }).toString();
  return `/api/social/media/${Number(mediaId)}/download?${qs}`;
}

/** Returns the signed tenantId if the request carries a valid, unexpired token for
 *  this media id, else 0. */
function verifySocialMediaToken(req, mediaId) {
  const t = Number(req.query?.t);
  const e = Number(req.query?.e);
  const s = String(req.query?.s || "");
  if (!Number.isInteger(t) || t < 1 || !Number.isFinite(e) || e <= 0 || !s) return 0;
  if (Date.now() > e) return 0;
  const expected = signSocialMediaToken(t, mediaId, e);
  const got = Buffer.from(s);
  const want = Buffer.from(expected);
  if (got.length !== want.length || !crypto.timingSafeEqual(got, want)) return 0;
  return t;
}

/** Owning tenant for a post's media: the signed-in workspace for manual posts,
 *  else the legacy workspace (the social scheduler runs as legacy). */
function socialPostTenantId(req) {
  if (req) {
    const session = getAuthSession(req);
    if (session?.tenantId) return session.tenantId;
  }
  return LEGACY_TENANT_ID;
}

function resolveSocialPostMediaUrl({ mediaRow, videoRow, req }) {
  const origin = socialMediaPublicOrigin(req);
  if (mediaRow?.id) {
    return `${origin}${buildSignedSocialMediaPath(socialPostTenantId(req), mediaRow.id)}`;
  }
  if (videoRow?.id) {
    if (String(videoRow.source_type) === "file") {
      return `${origin}/api/videos/${videoRow.id}/stream`;
    }
    return String(videoRow.video_url || "").trim();
  }
  return "";
}

async function postSocialTargetViaWebhook({ target, message, mediaUrl }) {
  const webhook = await getSocialWebhookForTarget(target);
  if (!webhook) {
    const slug = normalizeSocialTarget(target).toUpperCase().replace(/[^A-Z0-9]/g, "_");
    return {
      status: "failed",
      responseText: `Not connected. Add an HTTPS webhook in Settings → Social webhooks${slug ? ` for ${target}` : ""}.`
    };
  }
  const payload = {
    target,
    message: String(message || ""),
    mediaUrl: String(mediaUrl || "")
  };
  const response = await fetch(webhook, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  const text = await response.text();
  if (!response.ok) {
    return {
      status: "failed",
      responseText: `Webhook ${response.status}: ${String(text || "").slice(0, 500)}`
    };
  }
  return { status: "sent", responseText: String(text || "Posted successfully").slice(0, 500) };
}

app.get("/api/social/platforms", async (req, res) => {
  try {
    const targets = await getConfiguredSocialTargets();
    const platforms = [];
    for (const target of targets) {
      const webhook = await getSocialWebhookForTarget(target);
      platforms.push({
        target,
        connected: Boolean(webhook)
      });
    }
    const connectedCount = platforms.filter((p) => p.connected).length;
    return res.json({ targets, platforms, connectedCount });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/social/media/upload", (req, res, next) => {
  pcSocialMediaUpload.single("media")(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message || "Upload failed" });
    return next();
  });
}, async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "media file is required" });
    const fileName = String(req.file.originalname || req.file.filename || "").trim();
    const mimeType = String(req.file.mimetype || "").trim();
    const categoryName = String(req.body?.categoryName || "Uncategorized").trim() || "Uncategorized";
    const storageKey = toRelativeUploadPath("social", req.file);
    const sizeBytes = Number(req.file.size || 0);
    const insert = await run(
      `INSERT INTO social_media_assets (file_name, mime_type, storage_path, size_bytes, category_name) VALUES (?, ?, ?, ?, ?)`,
      [fileName, mimeType, storageKey, sizeBytes, categoryName]
    );
    const created = await get(
      `SELECT id, file_name, mime_type, size_bytes, category_name, created_at FROM social_media_assets WHERE id = ?`,
      [insert.lastID]
    );
    return res.status(201).json(created);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/social/media", async (req, res) => {
  try {
    const limitRaw = Number(req.query.limit);
    const limit = Number.isInteger(limitRaw) && limitRaw > 0 ? Math.min(limitRaw, 200) : 100;
    const rows = await all(
      `SELECT id, file_name, mime_type, size_bytes, category_name, created_at
       FROM social_media_assets
       ORDER BY created_at DESC, id DESC
       LIMIT ?`,
      [limit]
    );
    return res.json(Array.isArray(rows) ? rows : []);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

async function sendSocialMediaAsset(res, id) {
  const row = await get(`SELECT id, file_name, mime_type, storage_path FROM social_media_assets WHERE id = ?`, [id]);
  if (!row) return res.status(404).json({ error: "Media not found" });
  const diskPath = resolveStoredUploadPath(row.storage_path, "social", row.file_name);
  if (!diskPath) {
    return res.status(404).json({ error: "Stored media file not found" });
  }
  if (row.mime_type) res.type(row.mime_type);
  return res.sendFile(diskPath);
}

app.get("/api/social/media/:id/download", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
    // In-app request with a session: tenant context is already set by middleware.
    if (getAuthSession(req)?.tenantId) {
      return await sendSocialMediaAsset(res, id);
    }
    // External fetch (Make.com / Facebook posting an image) must present a valid
    // signed token; we then serve from that token's tenant workspace.
    const tokenTenantId = verifySocialMediaToken(req, id);
    if (!tokenTenantId) {
      return res.status(403).json({ error: "A valid media token is required." });
    }
    await openTenantDatabase(tokenTenantId);
    return await withTenantContext(tokenTenantId, () => sendSocialMediaAsset(res, id));
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

async function deleteSocialMediaById(rawId) {
  const id = Number(rawId);
  if (!Number.isInteger(id) || id < 1) {
    return { status: 400, body: { error: "Invalid id" } };
  }
  const row = await get(
    `SELECT id, file_name, storage_path FROM social_media_assets WHERE id = ?`,
    [id]
  );
  if (!row) {
    return { status: 404, body: { error: "Media not found" } };
  }
  await run(`DELETE FROM social_media_assets WHERE id = ?`, [id]);
  if (row.storage_path) {
    const diskPath = resolveStoredUploadPath(row.storage_path, "social", row.file_name);
    if (diskPath) {
      try {
        fs.unlinkSync(diskPath);
      } catch {
        /* ignore missing file on disk */
      }
    }
  }
  return { status: 200, body: { ok: true, id } };
}

app.post("/api/social/media/delete", async (req, res) => {
  try {
    const result = await deleteSocialMediaById(req.body?.id ?? req.body?.mediaId);
    return res.status(result.status).json(result.body);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.delete("/api/social/media/:id", async (req, res) => {
  try {
    const result = await deleteSocialMediaById(req.params.id);
    return res.status(result.status).json(result.body);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/social/publish", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    const mediaId = Number(req.body?.mediaId);
    const videoId = Number(req.body?.videoId);
    const targetsInput = Array.isArray(req.body?.targets) ? req.body.targets : [];
    const targets = [...new Set(targetsInput.map((t) => normalizeSocialTarget(t)).filter(Boolean))];
    const scheduleAtRaw = req.body?.scheduleAt;
    if (!message) return res.status(400).json({ error: "message is required" });
    if (!targets.length) return res.status(400).json({ error: "Select at least one platform" });
    const hasMedia = Number.isInteger(mediaId) && mediaId > 0;
    const hasVideo = Number.isInteger(videoId) && videoId > 0;
    if (hasMedia && hasVideo) {
      return res.status(400).json({ error: "Select either media library or video library attachment, not both" });
    }

    let scheduledAt = null;
    if (scheduleAtRaw != null && String(scheduleAtRaw).trim() !== "") {
      const parsed = scheduleAtRaw;
      scheduledAt =
        typeof parsed === "number" && Number.isFinite(parsed)
          ? Math.floor(parsed)
          : Math.floor(new Date(String(parsed)).getTime() / 1000);
      if (!Number.isFinite(scheduledAt) || scheduledAt <= Math.floor(Date.now() / 1000)) {
        return res.status(400).json({ error: "Schedule time must be in the future" });
      }
    }

    let mediaRow = null;
    let videoRow = null;
    if (hasMedia) {
      mediaRow = await get(`SELECT id, file_name, storage_path FROM social_media_assets WHERE id = ?`, [mediaId]);
      if (!mediaRow) return res.status(404).json({ error: "Selected media not found" });
    }
    if (hasVideo) {
      videoRow = await get(`SELECT id, title, source_type, video_url FROM videos WHERE id = ?`, [videoId]);
      if (!videoRow) return res.status(404).json({ error: "Selected video not found" });
    }

    if (scheduledAt) {
      const postIns = await run(
        `INSERT INTO social_posts (content, media_asset_id, video_id, scheduled_at, publish_status, targets_json) VALUES (?, ?, ?, ?, 'scheduled', ?)`,
        [message, mediaRow?.id || null, videoRow?.id || null, scheduledAt, JSON.stringify(targets)]
      );
      return res.status(201).json({
        id: Number(postIns.lastID),
        message,
        mediaId: mediaRow?.id || null,
        videoId: videoRow?.id || null,
        scheduled: true,
        scheduledAt,
        targets
      });
    }

    const postIns = await run(
      `INSERT INTO social_posts (content, media_asset_id, video_id, publish_status, targets_json) VALUES (?, ?, ?, 'published', '[]')`,
      [message, mediaRow?.id || null, videoRow?.id || null]
    );
    const postId = Number(postIns.lastID);
    const mediaUrl = resolveSocialPostMediaUrl({ mediaRow, videoRow, req });
    const delivery = [];

    for (const target of targets) {
      const result = await postSocialTargetViaWebhook({ target, message, mediaUrl });
      await run(
        `INSERT INTO social_post_targets (post_id, target, status, response_text, posted_at) VALUES (?, ?, ?, ?, ?)`,
        [postId, target, result.status, result.responseText || "", result.status === "sent" ? Math.floor(Date.now() / 1000) : null]
      );
      delivery.push({ target, status: result.status, detail: result.responseText || "" });
    }

    return res.status(201).json({
      id: postId,
      message,
      mediaId: mediaRow?.id || null,
      videoId: videoRow?.id || null,
      results: delivery
    });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post("/api/social/publish-bulk", async (req, res) => {
  try {
    const targetsInput = Array.isArray(req.body?.targets) ? req.body.targets : [];
    const targets = [...new Set(targetsInput.map((t) => normalizeSocialTarget(t)).filter(Boolean))];
    const postsInput = Array.isArray(req.body?.posts) ? req.body.posts : [];
    if (!targets.length) return res.status(400).json({ error: "Select at least one platform" });
    if (!postsInput.length) return res.status(400).json({ error: "No posts to schedule" });
    if (postsInput.length > 100) return res.status(400).json({ error: "Too many posts in one batch (max 100)" });

    const nowSec = Math.floor(Date.now() / 1000);
    const results = [];
    let scheduledCount = 0;

    for (let i = 0; i < postsInput.length; i++) {
      const item = postsInput[i] || {};
      try {
        const message = String(item.message || "").trim();
        if (!message) throw new Error("Message is empty");

        const raw = item.scheduleAt;
        let scheduledAt = null;
        if (raw != null && String(raw).trim() !== "") {
          scheduledAt =
            typeof raw === "number" && Number.isFinite(raw)
              ? Math.floor(raw)
              : Math.floor(new Date(String(raw)).getTime() / 1000);
        }
        if (!Number.isFinite(scheduledAt) || scheduledAt <= nowSec) {
          throw new Error("Schedule time must be a valid future date/time");
        }

        const mediaId = Number(item.mediaId);
        const videoId = Number(item.videoId);
        const hasMedia = Number.isInteger(mediaId) && mediaId > 0;
        const hasVideo = Number.isInteger(videoId) && videoId > 0;
        if (hasMedia && hasVideo) throw new Error("Choose either an image or a video, not both");

        let mediaRow = null;
        let videoRow = null;
        if (hasMedia) {
          mediaRow = await get(`SELECT id FROM social_media_assets WHERE id = ?`, [mediaId]);
          if (!mediaRow) throw new Error("Attached image not found in media library");
        }
        if (hasVideo) {
          videoRow = await get(`SELECT id FROM videos WHERE id = ?`, [videoId]);
          if (!videoRow) throw new Error("Attached video not found");
        }

        const ins = await run(
          `INSERT INTO social_posts (content, media_asset_id, video_id, scheduled_at, publish_status, targets_json) VALUES (?, ?, ?, ?, 'scheduled', ?)`,
          [message, mediaRow?.id || null, videoRow?.id || null, scheduledAt, JSON.stringify(targets)]
        );
        scheduledCount += 1;
        results.push({ index: i, ok: true, id: Number(ins.lastID), scheduledAt });
      } catch (err) {
        results.push({ index: i, ok: false, error: err.message || "Failed to schedule" });
      }
    }

    return res.status(201).json({ scheduledCount, total: postsInput.length, targets, results });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/social/posts", async (req, res) => {
  try {
    const limitRaw = Number(req.query.limit);
    const limit = Number.isInteger(limitRaw) && limitRaw > 0 ? Math.min(limitRaw, 200) : 100;
    const rows = await all(
      `SELECT
         sp.id,
         sp.content,
         sp.media_asset_id,
         sp.video_id,
         sp.created_at,
         sp.scheduled_at,
         sp.publish_status,
         sp.targets_json,
         sma.file_name AS media_file_name,
         sma.mime_type AS media_mime_type,
         sma.size_bytes AS media_size_bytes,
         v.title AS video_title,
         v.source_type AS video_source_type,
         v.video_url AS video_url
       FROM social_posts sp
       LEFT JOIN social_media_assets sma ON sma.id = sp.media_asset_id
       LEFT JOIN videos v ON v.id = sp.video_id
       ORDER BY sp.created_at DESC, sp.id DESC
       LIMIT ?`,
      [limit]
    );
    const postIds = (Array.isArray(rows) ? rows : [])
      .map((row) => Number(row.id))
      .filter((n) => Number.isInteger(n) && n > 0);
    let targetsByPost = new Map();
    if (postIds.length) {
      const placeholders = postIds.map(() => "?").join(", ");
      const targetRows = await all(
        `SELECT post_id, target, status, response_text, posted_at
         FROM social_post_targets
         WHERE post_id IN (${placeholders})
         ORDER BY id ASC`,
        postIds
      );
      targetsByPost = new Map();
      for (const row of targetRows) {
        const postId = Number(row.post_id);
        if (!targetsByPost.has(postId)) targetsByPost.set(postId, []);
        targetsByPost.get(postId).push({
          target: String(row.target || ""),
          status: String(row.status || ""),
          detail: String(row.response_text || ""),
          posted_at: Number(row.posted_at || 0)
        });
      }
    }
    const parsed = (Array.isArray(rows) ? rows : []).map((row) => {
      let targetResults = targetsByPost.get(Number(row.id)) || [];
      if (String(row.publish_status || "") === "scheduled") {
        let pendingTargets = [];
        try {
          const raw = JSON.parse(String(row.targets_json || "[]"));
          pendingTargets = Array.isArray(raw) ? raw : [];
        } catch {
          pendingTargets = [];
        }
        targetResults = pendingTargets.map((target) => ({
          target: String(target || ""),
          status: "scheduled",
          detail: row.scheduled_at ? `Scheduled for ${new Date(Number(row.scheduled_at) * 1000).toISOString()}` : "Scheduled",
          posted_at: 0
        }));
      }
      return {
        id: row.id,
        content: row.content,
        media_asset_id: row.media_asset_id,
        media_file_name: row.media_file_name || "",
        media_mime_type: row.media_mime_type || "",
        media_size_bytes: Number(row.media_size_bytes || 0),
        video_id: row.video_id,
        video_title: row.video_title || "",
        video_source_type: row.video_source_type || "",
        video_url: row.video_url || "",
        created_at: Number(row.created_at || 0),
        scheduled_at: Number(row.scheduled_at || 0) || null,
        publish_status: String(row.publish_status || "published"),
        target_results: targetResults
      };
    });
    return res.json(parsed);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

async function clearSocialPostById(rawId) {
  const id = Number(rawId);
  if (!Number.isInteger(id) || id < 1) {
    return { status: 400, body: { error: "Invalid id" } };
  }
  const row = await get(`SELECT id FROM social_posts WHERE id = ?`, [id]);
  if (!row) {
    return { status: 404, body: { error: "Post not found" } };
  }
  await run(`DELETE FROM social_posts WHERE id = ?`, [id]);
  return { status: 200, body: { ok: true, id } };
}

app.post("/api/social/posts/clear", async (req, res) => {
  try {
    const result = await clearSocialPostById(req.body?.id ?? req.body?.postId);
    return res.status(result.status).json(result.body);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.delete("/api/social/posts/:id", async (req, res) => {
  try {
    const result = await clearSocialPostById(req.params.id);
    return res.status(result.status).json(result.body);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/home.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "home.html");
});

app.get("/drip.html", (req, res) => {
  res.redirect(302, "/home.html#sales-automation");
});

app.get("/pipeline.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "pipeline.html");
});

app.get("/activities.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "activities.html");
});

app.get("/reports.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "reports.html");
});

app.get("/renewals.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "renewals.html");
});

app.get("/attention.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "attention.html");
});

app.get(["/tasks.html", "/tasks"], (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "tasks.html");
});

app.get("/social.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "social.html");
});

app.get("/contact-import.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "contact-import.html");
});

app.get("/assistant.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "assistant.html");
});

app.get(["/role-play.html", "/role-play"], (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "role-play.html");
});

app.get("/login.html", (req, res) => {
  sendHtmlPageWithTwilio(req, res, "login.html");
});

app.get("/settings.html", (req, res) => {
  if (shouldProtectPageRoute(req.path) && !isRequestAuthenticated(req)) {
    return redirectToLogin(req, res);
  }
  sendHtmlPageWithTwilio(req, res, "settings.html");
});

app.get("/lib/twilio-voice.min.js", (req, res) => {
  res.type("application/javascript");
  res.sendFile(path.join(__dirname, "..", "node_modules", "@twilio", "voice-sdk", "dist", "twilio.min.js"));
});

app.get("/favicon.ico", (_req, res) => {
  res.redirect(301, "/favicon.svg");
});

// PWA icon routes — redirect PNG requests to SVG (browsers that support SVA icons use the manifest entry)
app.get("/icon-192.png", (_req, res) => res.redirect(302, "/favicon.svg"));
app.get("/icon-512.png", (_req, res) => res.redirect(302, "/favicon.svg"));
app.get("/apple-touch-icon.png", (_req, res) => res.redirect(302, "/favicon.svg"));
app.get("/apple-touch-icon-precomposed.png", (_req, res) => res.redirect(302, "/favicon.svg"));

for (const paradigmaiFile of ["paradigmai-cadence-import.csv", "paradigmai-source-template.csv"]) {
  app.get(`/${paradigmaiFile}`, (req, res) => {
    if (!isOwnerWorkspaceSession(req)) {
      return res.status(404).type("text/plain").send("Not found");
    }
    return res.sendFile(path.join(publicDir, paradigmaiFile));
  });
}

app.use(
  express.static(publicDir, {
    index: false,
    setHeaders: (res, filePath) => {
      const lower = String(filePath || "").toLowerCase();
      if (lower.endsWith(".html") || lower.endsWith(`${path.sep}settings.js`) || lower.endsWith("/settings.js")) {
        res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
      } else if (
        lower.endsWith(".js") ||
        lower.endsWith(".css") ||
        lower.endsWith(".svg") ||
        lower.endsWith(".png") ||
        lower.endsWith(".jpg") ||
        lower.endsWith(".jpeg") ||
        lower.endsWith(".webp") ||
        lower.endsWith(".woff") ||
        lower.endsWith(".woff2") ||
        lower.endsWith(".json") ||
        lower.endsWith(".mp4") ||
        lower.includes(`${path.sep}screenshots${path.sep}`) ||
        lower.includes(`${path.sep}media${path.sep}`)
      ) {
        // HTML stays no-store so deploys pick up new ?v= asset URLs. Cache the
        // assets themselves so each page click does not re-download app.js/CSS.
        res.setHeader("Cache-Control", "public, max-age=300");
      }
    }
  })
);

app.post("/webhooks/twilio/sms-status", twilioWebhookGuard, (req, res) => {
  /* Don't log full body — message content can contain PII. Only log SID and
     status for traceability. */
  const sid = (req.body && (req.body.MessageSid || req.body.SmsSid)) || "";
  const status = (req.body && req.body.MessageStatus) || "";
  console.log(`Twilio SMS status: sid=${sid} status=${status}`);
  res.status(200).send("OK");
});

app.post("/webhooks/twilio/inbound-sms", twilioWebhookGuard, (req, res) => {
  const sid = (req.body && (req.body.MessageSid || req.body.SmsSid)) || "";
  const fromMasked = maskSecret(String((req.body && req.body.From) || ""));
  console.log(`Twilio inbound SMS: sid=${sid} from=${fromMasked}`);
  res.type("text/xml").send("<Response></Response>");
});

const auth2faApi = registerAuth2faRoutes(app, {
  all,
  run,
  encryptSecret,
  decryptSecret,
  getConfiguredLoginEmail,
  getConfiguredLoginPasswordHash,
  verifyLoginPassword,
  issueSignedAuthToken,
  setAuthCookie,
  isRequestAuthenticated,
  getAuthSigningSecret,
  authLoginLimiter,
  createRateLimiter,
  reloadRuntimeConfig: loadTwilioRuntimeConfigFromDb
});
auth2faState.completeLoginOrChallenge = auth2faApi.completeLoginOrChallenge;

/* ─────────────────────────────────────────────────────────────────────────
   LEAD CAPTURE FORM
   Public hosted form:   GET  /capture/:formKey
   Public submission:    POST /api/capture/:formKey
   Authenticated config: GET/POST /api/lead-capture/settings
                         POST /api/lead-capture/key/regenerate
───────────────────────────────────────────────────────────────────────── */

// Serve the hosted public form
app.get("/capture/:formKey", async (req, res) => {
  try {
    const formKey = String(req.params.formKey || "").replace(/[^a-f0-9]/g, "");
    if (!formKey) return res.status(400).send("Invalid form link.");
    const cfg = await platformGet(
      `SELECT tenant_id FROM lead_capture_config WHERE form_key = ?`,
      [formKey]
    );
    if (!cfg) return res.status(404).send("Form not found. The link may have been regenerated — check Lead Capture Form in your CRM for the current link.");
    // Get agency name for display
    let agencyName = "Your Insurance Agent";
    if (cfg.tenant_id !== LEGACY_TENANT_ID) {
      const signup = await platformGet(
        `SELECT agency_name FROM subscription_signups WHERE tenant_id = ?`,
        [cfg.tenant_id]
      );
      if (signup && signup.agency_name) agencyName = signup.agency_name;
    }
    res.removeHeader("X-Frame-Options");
    res.setHeader("Content-Security-Policy", "frame-ancestors *");
    res.type("html").send(buildPublicCaptureFormHtml(formKey, agencyName));
  } catch (err) {
    console.error("[lead-capture] GET /capture error:", err.message || err);
    res.status(500).send("Something went wrong. Please try again.");
  }
});

// Process public form submission
app.post("/api/capture/:formKey", publicFormsLimiter, async (req, res) => {
  try {
    const formKey = String(req.params.formKey || "").replace(/[^a-f0-9]/g, "");
    if (!formKey) return res.status(400).json({ error: "Invalid form link." });
    const cfg = await platformGet(
      `SELECT tenant_id, notify_email FROM lead_capture_config WHERE form_key = ?`,
      [formKey]
    );
    if (!cfg) return res.status(404).json({ error: "Form not found." });

    const body = req.body || {};
    const firstName = String(body.first_name || "").trim().slice(0, 100);
    const lastName  = String(body.last_name  || "").trim().slice(0, 100);
    const email     = String(body.email      || "").trim().slice(0, 200);
    const phone     = String(body.phone      || "").trim().slice(0, 50);
    const interest  = String(body.interest   || "").trim().slice(0, 100);
    const message   = String(body.message    || "").trim().slice(0, 2000);

    if (!firstName) return res.status(400).json({ error: "First name is required." });
    if (!email || !email.includes("@")) return res.status(400).json({ error: "A valid email address is required." });

    const fullName = [firstName, lastName].filter(Boolean).join(" ");
    const notes    = message || "";
    const tags     = interest ? `web-lead,${interest.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9,-]/g, "")}` : "web-lead";

    await withTenantContext(cfg.tenant_id, () =>
      run(
        `INSERT INTO contacts (full_name, email, phone, status, tags, notes, lead_source, updated_at)
         VALUES (?, ?, ?, 'New Lead', ?, ?, 'Web Form', CURRENT_TIMESTAMP)`,
        [fullName, email, phone, tags, notes]
      )
    );

    // Optional notification email
    if (cfg.notify_email) {
      try {
        const { sendTrialWelcomeEmail } = require("./emailService");
        const subject = `New lead from your Cadence capture form: ${fullName}`;
        const text = [
          `New lead submitted via your Cadence CRM capture form.`,
          ``,
          `Name:     ${fullName}`,
          `Email:    ${email}`,
          `Phone:    ${phone || "(not provided)"}`,
          `Interest: ${interest || "(not provided)"}`,
          `Message:  ${message || "(none)"}`,
          ``,
          `This contact has been added to your CRM automatically.`
        ].join("\n");
        await sendTrialWelcomeEmail({ to: cfg.notify_email, subject, text });
      } catch (notifyErr) {
        console.warn("[lead-capture] Notification email failed:", notifyErr.message || notifyErr);
      }
    }

    res.json({ ok: true });
  } catch (err) {
    console.error("[lead-capture] POST /api/capture error:", err.message || err);
    res.status(500).json({ error: "Something went wrong. Please try again." });
  }
});

// Debug endpoint — shows raw DB state for diagnosing "Form not found" (authenticated)
app.get("/api/lead-capture/debug", async (req, res) => {
  try {
    if (!isRequestAuthenticated(req)) return res.status(401).json({ error: "Not authenticated." });
    const session = getAuthSession(req);
    const tenantId = Number(session?.tenantId || LEGACY_TENANT_ID);
    // Check table exists
    const tableCheck = await platformGet(
      `SELECT name FROM sqlite_master WHERE type='table' AND name='lead_capture_config'`
    );
    // All rows in the table
    const allRows = tableCheck
      ? await platformAll(`SELECT id, tenant_id, form_key, notify_email, created_at FROM lead_capture_config`)
      : [];
    // Row for this tenant
    const myRow = tableCheck
      ? await platformGet(`SELECT * FROM lead_capture_config WHERE tenant_id = ?`, [tenantId])
      : null;
    res.json({
      sessionTenantId: session?.tenantId,
      resolvedTenantId: tenantId,
      LEGACY_TENANT_ID,
      tableExists: !!tableCheck,
      totalRows: allRows.length,
      allRows,
      myRow: myRow || null
    });
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

// Get lead capture settings (authenticated)
app.get("/api/lead-capture/settings", async (req, res) => {
  try {
    if (!isRequestAuthenticated(req)) return res.status(401).json({ error: "Not authenticated." });
    const session = getAuthSession(req);
    const tenantId = Number(session?.tenantId || LEGACY_TENANT_ID);
    const cfg = await getOrCreateLeadCaptureConfig(tenantId);
    const base = resolveLeadCaptureBase(req);
    const ownerTools = isOwnerWorkspaceSession(req);
    res.json({
      formKey: cfg.form_key,
      notifyEmail: cfg.notify_email || "",
      ownerTools,
      hostedUrl: `${base}/capture/${cfg.form_key}`,
      applicationUrl: ownerTools ? customerFormUrl(`/apply/${cfg.form_key}`) : "",
      intakeUrl: ownerTools ? customerFormUrl(`/intake/${cfg.form_key}`) : "",
      intakeUrlWithKey: ownerTools ? customerFormUrl(`/intake/${cfg.form_key}`) : "",
      embedCode: `<iframe src="${base}/capture/${cfg.form_key}" width="100%" height="580" frameborder="0" style="border:0;border-radius:12px;" allowtransparency="true" title="Contact Form"></iframe>`
    });
  } catch (err) {
    console.error("[lead-capture] GET /api/lead-capture/settings error:", err.message || err);
    res.status(500).json({ error: "Server error." });
  }
});

// Update lead capture settings (authenticated)
app.post("/api/lead-capture/settings", async (req, res) => {
  try {
    if (!isRequestAuthenticated(req)) return res.status(401).json({ error: "Not authenticated." });
    const session = getAuthSession(req);
    const tenantId = Number(session?.tenantId || LEGACY_TENANT_ID);
    const notifyEmail = String((req.body && req.body.notifyEmail) || "").trim().slice(0, 200);
    await getOrCreateLeadCaptureConfig(tenantId);
    await platformRun(
      `UPDATE lead_capture_config SET notify_email = ? WHERE tenant_id = ?`,
      [notifyEmail, tenantId]
    );
    res.json({ ok: true });
  } catch (err) {
    console.error("[lead-capture] POST /api/lead-capture/settings error:", err.message || err);
    res.status(500).json({ error: "Server error." });
  }
});

// Regenerate form key (authenticated)
app.post("/api/lead-capture/key/regenerate", async (req, res) => {
  try {
    if (!isRequestAuthenticated(req)) return res.status(401).json({ error: "Not authenticated." });
    const session = getAuthSession(req);
    const tenantId = Number(session?.tenantId || LEGACY_TENANT_ID);
    await getOrCreateLeadCaptureConfig(tenantId);
    const newKey = crypto.randomBytes(20).toString("hex");
    await platformRun(
      `UPDATE lead_capture_config SET form_key = ? WHERE tenant_id = ?`,
      [newKey, tenantId]
    );
    const base = resolveLeadCaptureBase(req);
    const ownerTools = isOwnerWorkspaceSession(req);
    res.json({
      ok: true,
      formKey: newKey,
      ownerTools,
      hostedUrl: `${base}/capture/${newKey}`,
      applicationUrl: ownerTools ? customerFormUrl(`/apply/${newKey}`) : "",
      intakeUrl: ownerTools ? customerFormUrl(`/intake/${newKey}`) : "",
      intakeUrlWithKey: ownerTools ? customerFormUrl(`/intake/${newKey}`) : "",
      embedCode: `<iframe src="${base}/capture/${newKey}" width="100%" height="580" frameborder="0" style="border:0;border-radius:12px;" allowtransparency="true" title="Contact Form"></iframe>`
    });
  } catch (err) {
    console.error("[lead-capture] POST /api/lead-capture/key/regenerate error:", err.message || err);
    res.status(500).json({ error: "Server error." });
  }
});

// ── Owner admin: tenant provisioning overview ─────────────────────────────────
function enrichAdminTenantRow(tenant) {
  const trial = computeTrialState(tenant || {});
  return {
    ...tenant,
    trialDaysLeft: trial.daysLeft,
    trialEndsAt: Number(tenant?.trial_ends_at || trial.trialEndsAt || 0)
  };
}

function requireOwnerAdminSession(req, res) {
  if (!isOwnerWorkspaceSession(req)) {
    res.status(403).json({
      error: "Owner admin is only available on the main operator workspace. Log in with your Settings sign-in email."
    });
    return false;
  }
  return true;
}

app.get("/api/admin/tenants", async (req, res) => {
  try {
    if (!requireOwnerAdminSession(req, res)) return;
    const session = getAuthSession(req);
    let tenants = [];
    try {
      const rows = await platformAll(
        `SELECT id, slug, agency_name, owner_email, owner_first_name, owner_last_name, plan, status, trial_ends_at, created_at FROM tenants ORDER BY created_at DESC`
      );
      if (Array.isArray(rows) && rows.length) tenants = rows;
    } catch (schemaErr) {
      console.error("[admin] tenants query failed:", schemaErr.message || schemaErr);
    }
    if (!tenants.length) {
      let provisionedPhone = null;
      let residentState = null;
      try {
        await withTenantContext(LEGACY_TENANT_ID, async () => {
          const phoneRow = await get(`SELECT value FROM twilio_runtime_config WHERE key = 'phoneNumber'`);
          const stateRow = await get(`SELECT value FROM twilio_runtime_config WHERE key = 'residentState'`);
          provisionedPhone = phoneRow?.value || null;
          residentState = stateRow?.value || null;
        });
      } catch (_) {}
      return res.json([
        enrichAdminTenantRow({
          id: LEGACY_TENANT_ID,
          slug: "legacy",
          agency_name: String(process.env.CRM_AGENCY_NAME || "Your Account").trim(),
          owner_email: String(process.env.CRM_LOGIN_EMAIL || session?.email || "").trim(),
          status: "active",
          plan: "pro",
          provisionedPhone,
          residentState
        })
      ]);
    }
    const result = await Promise.all(
      tenants.map(async (t) => {
        let provisionedPhone = null;
        let residentState = null;
        try {
          await withTenantContext(t.id, async () => {
            const phoneRow = await get(`SELECT value FROM twilio_runtime_config WHERE key = 'phoneNumber'`);
            const stateRow = await get(`SELECT value FROM twilio_runtime_config WHERE key = 'residentState'`);
            provisionedPhone = phoneRow?.value || null;
            residentState = stateRow?.value || null;
          });
        } catch (err) {
          console.warn(`[admin] tenant ${t.id} phone lookup failed:`, err.message || err);
        }
        return enrichAdminTenantRow({ ...t, provisionedPhone, residentState });
      })
    );
    res.json(result);
  } catch (e) {
    console.error("[admin] GET /api/admin/tenants error:", e.message || e);
    res.status(500).json({ error: e.message || "Could not load tenants." });
  }
});

app.post("/api/admin/tenants/:tenantId/provision-number", async (req, res) => {
  try {
    if (!requireOwnerAdminSession(req, res)) return;
    const { purchaseNumberForTenant } = require("./twilioProvisioning");
    const tenantIdRaw = req.params.tenantId;
    const tenantId = tenantIdRaw === "legacy" ? LEGACY_TENANT_ID : Number(tenantIdRaw);
    const residentState = String(req.body?.residentState || "").trim().toUpperCase();
    const crmBase = String(process.env.CRM_PUBLIC_URL || "https://crmcadence.com").trim().replace(/\/$/, "");
    const phone = await purchaseNumberForTenant({
      residentState,
      voiceWebhookUrl: `${crmBase}/webhooks/twilio/voice`,
      messagingServiceSid: String(process.env.TWILIO_MESSAGING_SERVICE_SID || "").trim() || undefined
    });
    await withTenantContext(tenantId, async () => {
      await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('phoneNumber', ?)`, [phone]);
      if (residentState) {
        await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('residentState', ?)`, [residentState]);
      }
    });
    if (tenantId === LEGACY_TENANT_ID) process.env.TWILIO_PHONE_NUMBER = phone;
    res.json({ ok: true, phone });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});
app.post("/api/admin/tenants/:tenantId/release-number", async (req, res) => {
  try {
    if (!requireOwnerAdminSession(req, res)) return;
    const { releaseNumber } = require("./twilioProvisioning");
    const tenantIdRaw = req.params.tenantId;
    const tenantId = tenantIdRaw === "legacy" ? LEGACY_TENANT_ID : Number(tenantIdRaw);
    let phoneNumber = null;
    await withTenantContext(tenantId, async () => {
      const row = await get(`SELECT value FROM twilio_runtime_config WHERE key = 'phoneNumber'`);
      phoneNumber = row?.value || null;
    });
    if (!phoneNumber) return res.status(400).json({ error: "No number assigned to this tenant." });
    await releaseNumber(phoneNumber);
    await withTenantContext(tenantId, async () => {
      await run(`DELETE FROM twilio_runtime_config WHERE key = 'phoneNumber'`);
      await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('phoneReleased', '1')`);
    });
    if (tenantId === LEGACY_TENANT_ID && process.env.TWILIO_PHONE_NUMBER === phoneNumber) {
      delete process.env.TWILIO_PHONE_NUMBER;
    }
    res.json({ ok: true, released: phoneNumber });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post("/api/admin/tenants/:tenantId/change-number", async (req, res) => {
  try {
    if (!requireOwnerAdminSession(req, res)) return;
    const { purchaseNumberForTenant, releaseNumber } = require("./twilioProvisioning");
    const tenantIdRaw = req.params.tenantId;
    const tenantId = tenantIdRaw === "legacy" ? LEGACY_TENANT_ID : Number(tenantIdRaw);
    const residentState = String(req.body?.residentState || "").trim().toUpperCase();
    // Release old number first
    let oldPhone = null;
    await withTenantContext(tenantId, async () => {
      const row = await get(`SELECT value FROM twilio_runtime_config WHERE key = 'phoneNumber'`);
      oldPhone = row?.value || null;
    });
    if (oldPhone) {
      try { await releaseNumber(oldPhone); } catch (_) {}
    }
    // Buy new number
    const crmBase2 = String(process.env.CRM_PUBLIC_URL || "https://crmcadence.com").trim().replace(/\/$/, "");
    const newPhone = await purchaseNumberForTenant({
      residentState,
      voiceWebhookUrl: `${crmBase2}/webhooks/twilio/voice`,
      messagingServiceSid: String(process.env.TWILIO_MESSAGING_SERVICE_SID || "").trim() || undefined
    });
    await withTenantContext(tenantId, async () => {
      await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('phoneNumber', ?)`, [newPhone]);
      await run(`DELETE FROM twilio_runtime_config WHERE key = 'phoneReleased'`);
      if (residentState) {
        await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('residentState', ?)`, [residentState]);
      }
    });
    if (tenantId === LEGACY_TENANT_ID) process.env.TWILIO_PHONE_NUMBER = newPhone;
    res.json({ ok: true, oldPhone, newPhone });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});
app.post("/api/admin/tenants/:tenantId/seed-voice", async (req, res) => {
  try {
    if (!requireOwnerAdminSession(req, res)) return;
    const tenantIdRaw = req.params.tenantId;
    const tenantId = tenantIdRaw === "legacy" ? LEGACY_TENANT_ID : Number(tenantIdRaw);
    const masterSid       = String(process.env.TWILIO_ACCOUNT_SID || "").trim();
    const masterToken     = String(process.env.TWILIO_AUTH_TOKEN || "").trim();
    const masterApiKey    = String(process.env.TWILIO_API_KEY || "").trim();
    const masterApiSecret = String(process.env.TWILIO_API_SECRET || "").trim();
    const twimlAppSid     = String(process.env.TWILIO_VOICE_TWIML_APP_SID || "").trim();
    const voiceIdentity   = String(process.env.TWILIO_VOICE_IDENTITY || "crm-agent").trim();
    if (!masterApiKey || !twimlAppSid) {
      return res.status(400).json({ error: "TWILIO_API_KEY or TWILIO_VOICE_TWIML_APP_SID not set in .env." });
    }
    await withTenantContext(tenantId, async () => {
      if (masterSid)       await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('accountSid', ?)`, [masterSid]);
      if (masterToken)     await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('authToken', ?)`, [masterToken]);
      if (masterApiKey)    await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('apiKey', ?)`, [masterApiKey]);
      if (masterApiSecret) await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('apiSecret', ?)`, [masterApiSecret]);
      if (twimlAppSid)     await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('voiceTwimlAppSid', ?)`, [twimlAppSid]);
      if (voiceIdentity)   await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('voiceIdentity', ?)`, [voiceIdentity]);
    });
    // Update process.env immediately so setup status reflects without restart
    if (masterSid)       process.env.TWILIO_ACCOUNT_SID          = masterSid;
    if (masterToken)     process.env.TWILIO_AUTH_TOKEN            = masterToken;
    if (masterApiKey)    process.env.TWILIO_API_KEY               = masterApiKey;
    if (masterApiSecret) process.env.TWILIO_API_SECRET            = masterApiSecret;
    if (twimlAppSid)     process.env.TWILIO_VOICE_TWIML_APP_SID  = twimlAppSid;
    if (voiceIdentity)   process.env.TWILIO_VOICE_IDENTITY        = voiceIdentity;
    res.json({ ok: true, seeded: { masterApiKey: !!masterApiKey, twimlAppSid, voiceIdentity } });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post("/api/admin/tenants/:tenantId/fix-messaging", async (req, res) => {
  try {
    if (!requireOwnerAdminSession(req, res)) return;
    const { addNumberToMessagingService } = require("./twilioProvisioning");
    const tenantIdRaw = req.params.tenantId;
    const tenantId = tenantIdRaw === "legacy" ? LEGACY_TENANT_ID : Number(tenantIdRaw);
    const messagingServiceSid = String(process.env.TWILIO_MESSAGING_SERVICE_SID || "").trim();
    if (!messagingServiceSid) return res.status(400).json({ error: "TWILIO_MESSAGING_SERVICE_SID not configured." });
    let phoneNumber = null;
    await withTenantContext(tenantId, async () => {
      const row = await get(`SELECT value FROM twilio_runtime_config WHERE key = 'phoneNumber'`);
      phoneNumber = row?.value || null;
    });
    if (!phoneNumber) return res.status(400).json({ error: "No provisioned number for this tenant." });
    await addNumberToMessagingService(phoneNumber, messagingServiceSid);
    res.json({ ok: true, phone: phoneNumber, messagingServiceSid });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});
app.delete("/api/admin/tenants/:tenantId", async (req, res) => {
  try {
    if (!requireOwnerAdminSession(req, res)) return;
    const tenantIdRaw = req.params.tenantId;
    if (tenantIdRaw === "legacy") {
      return res.status(400).json({ error: "Cannot delete the primary workspace." });
    }
    const tenantId = Number(tenantIdRaw);
    if (!Number.isInteger(tenantId) || tenantId < 1) {
      return res.status(400).json({ error: "Invalid tenant ID." });
    }
    const tenantRow = await platformGet(
      `SELECT agency_name, owner_email FROM tenants WHERE id = ?`,
      [tenantId]
    );
    if (!tenantRow) return res.status(404).json({ error: "Account not found." });
    const typedName = String(req.body?.confirmName || "").trim().toLowerCase();
    const expectedNames = [tenantRow.agency_name, tenantRow.owner_email]
      .map((value) => String(value || "").trim().toLowerCase())
      .filter(Boolean);
    if (!typedName || !expectedNames.includes(typedName)) {
      return res.status(400).json({
        error: "Type the account name exactly to delete it. Nothing was deleted."
      });
    }

    // 1. Release provisioned phone number
    let phoneNumber = null;
    try {
      await withTenantContext(tenantId, async () => {
        const row = await get(`SELECT value FROM twilio_runtime_config WHERE key = 'phoneNumber'`);
        phoneNumber = row?.value || null;
      });
      if (phoneNumber) {
        const { releaseNumber } = require("./twilioProvisioning");
        await releaseNumber(phoneNumber);
        console.log(`[admin] Released phone ${phoneNumber} for deleted tenant ${tenantId}`);
      }
    } catch (e) {
      console.error(`[admin] Phone release failed for tenant ${tenantId}:`, e.message);
    }

    // 2. Close and delete tenant database file
    try {
      const tenantDbPath = path.join(__dirname, "..", "tenant-data", String(tenantId), "crm.sqlite");
      if (fs.existsSync(tenantDbPath)) {
        fs.unlinkSync(tenantDbPath);
        console.log(`[admin] Deleted DB for tenant ${tenantId}`);
      }
    } catch (e) {
      console.error(`[admin] DB delete failed for tenant ${tenantId}:`, e.message);
    }

    // 3. Remove from platform tables
    await platformRun(`DELETE FROM tenant_users WHERE tenant_id = ?`, [tenantId]);
    await platformRun(`DELETE FROM subscription_signups WHERE tenant_id = ?`, [tenantId]);
    await platformRun(`DELETE FROM tenants WHERE id = ?`, [tenantId]);

    res.json({ ok: true, tenantId, releasedPhone: phoneNumber });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});
// ── End owner admin ───────────────────────────────────────────────────────────

/** Public marketing tour video (welcome page) — explicit route so catch-all does not serve HTML. */
function sendPublicMarketingAsset(res, relativePath, contentType) {
  const filePath = path.join(publicDir, relativePath);
  if (!fs.existsSync(filePath)) {
    return res.status(404).type("text/plain").send("Not found");
  }
  res.setHeader("Cache-Control", "public, max-age=604800");
  res.type(contentType);
  return res.sendFile(filePath);
}

app.get("/media/cadence-product-tour.mp4", (req, res) => {
  sendPublicMarketingAsset(res, "media/cadence-product-tour.mp4", "video/mp4");
});

app.get("/media/cadence-product-tour-poster.jpg", (req, res) => {
  sendPublicMarketingAsset(res, "media/cadence-product-tour-poster.jpg", "image/jpeg");
});

app.get("/videos/cadence-product-tour.mp4", (req, res) => {
  res.redirect(301, "/media/cadence-product-tour.mp4");
});

app.get("/videos/cadence-product-tour-poster.jpg", (req, res) => {
  res.redirect(301, "/media/cadence-product-tour-poster.jpg");
});

app.use((req, res, next) => {
  if (req.path.startsWith("/api")) {
    return res.status(404).json({ error: "Not found" });
  }
  next();
});

app.get("*", (req, res) => {
  if (req.path.startsWith("/api")) {
    return res.status(404).json({ error: "Not found" });
  }
  // Public hosted forms — never fall through to the Contacts dashboard.
  if (
    req.path.startsWith("/apply/") ||
    req.path === "/apply-form" ||
    req.path === "/applyform" ||
    req.path.startsWith("/capture/") ||
    req.path.startsWith("/intake/") ||
    req.path === "/intake-form" ||
    req.path === "/intakeform"
  ) {
    return res
      .status(404)
      .type("html")
      .send(
        "<!doctype html><meta charset=utf-8><title>Form not found</title>" +
          "<body style='font-family:system-ui;padding:40px;text-align:center'>" +
          "<h1>Form not found</h1>" +
          "<p>This application form link is missing or the Health Insurance Application routes are not deployed on this server.</p>" +
          "</body>"
      );
  }
  sendNotFoundPage(res);
});

function getLanIpv4Addresses() {
  const nets = os.networkInterfaces();
  const out = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net && net.family === "IPv4" && !net.internal) {
        out.push(net.address);
      }
    }
  }
  return out;
}

function writeStartupLog(line) {
  try {
    const logPath = path.join(__dirname, "..", "startup.log");
    fs.appendFileSync(logPath, `${new Date().toISOString()} ${line}\n`);
  } catch {
    /* ignore on read-only filesystem */
  }
}

// ── SMS usage API ─────────────────────────────────────────────────────────────
app.get("/api/sms/usage", async (req, res) => {
  try {
    const session = getAuthSession(req);
    if (!session) return res.status(401).json({ error: "Unauthorized" });
    const usage = await getSmsUsage();
    res.json({
      daily:        usage.daily,
      monthly:      usage.monthly,
      dailyLimit:   SMS_DAILY_LIMIT,
      monthlyLimit: SMS_MONTHLY_LIMIT,
      dailyPct:     Math.round((usage.daily  / SMS_DAILY_LIMIT)   * 100),
      monthlyPct:   Math.round((usage.monthly / SMS_MONTHLY_LIMIT) * 100)
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});
// ── End SMS usage API ─────────────────────────────────────────────────────────

function reminderJobDeps() {
  return { run, all, get, prepareRuntime: () => loadTwilioRuntimeConfigFromDb() };
}

/** Ask our own public site for /api/health so cPanel counts a visit and leaves the app running. */
function startPublicKeepAlive() {
  const ping = () => {
    const origin = String(process.env.CRM_PUBLIC_URL || "").trim().replace(/\/$/, "");
    if (!/^https:\/\//i.test(origin)) return;
    const timer = typeof AbortSignal !== "undefined" && typeof AbortSignal.timeout === "function" ? AbortSignal.timeout(15000) : undefined;
    fetch(`${origin}/api/health`, timer ? { signal: timer } : undefined).catch((err) => {
      console.error("[keep-alive]", (err && err.message) || err);
    });
  };
  setInterval(ping, 4 * 60 * 1000);
  setTimeout(ping, 20000);
}

function startHttpServer() {
  const onReady = (label) => {
    console.log(`CRM server ${label}`);
    writeStartupLog(label);
    startDripScheduler({ run, all, get, getSigningSecret: getAuthSigningSecret });
    startFollowUpReminderScheduler(reminderJobDeps());
    startPublicKeepAlive();
    startTrialOnboardingScheduler({ run, all, get });
    startPhoneCleanupScheduler({ platformAll, withTenantContext, run, get });
    startBounceScheduler({ run, all, get });
    startSocialScheduler({
      run,
      all,
      get,
      postSocialTargetViaWebhook,
      buildMediaUrl: (mediaAssetId) => `${socialMediaPublicOrigin()}/api/social/media/${mediaAssetId}/download`,
      resolveSocialPostMediaUrl
    });
    startEmailBulkScheduler({ run, all, get, sendOne: sendQueuedBulkEmail });
    // After startup (off the boot path), clear the completed/canceled backlog that
    // bloats the queue after big campaigns — batched so the write lock is only held
    // briefly and the site stays responsive — then (re)build the batch index on the
    // now-lean table. Repeat hourly so it can't re-bloat.
    const runBulkQueueMaintenance = () => {
      pruneEmailBulkQueue({ run })
        .then(async ({ deleted }) => {
          if (deleted) console.log(`[email-bulk] pruned ${deleted} completed queue rows`);
          await run(
            `CREATE INDEX IF NOT EXISTS idx_email_bulk_queue_batch ON email_bulk_queue (batch_id, status)`
          ).catch(() => {});
        })
        .catch((err) => console.error("[email-bulk] queue maintenance failed:", (err && err.message) || err));
    };
    setTimeout(runBulkQueueMaintenance, 20000);
    const bulkMaintTimer = setInterval(runBulkQueueMaintenance, 60 * 60 * 1000);
    if (typeof bulkMaintTimer.unref === "function") bulkMaintTimer.unref();
  };

  const cpanelPort = Number(process.env.PORT);

  /* LiteSpeed / cPanel often proxy to 127.0.0.1:PORT — listen there before Passenger. */
  if (Number.isFinite(cpanelPort) && cpanelPort > 0) {
    app.listen(cpanelPort, "127.0.0.1", () => onReady(`listening 127.0.0.1:${cpanelPort}`));
    return;
  }

  if (typeof PhusionPassenger !== "undefined") {
    PhusionPassenger.configure({ autoInstall: false });
    app.listen("passenger", () => onReady("listening passenger (PhusionPassenger)"));
    return;
  }

  if (process.env.PASSENGER_APP_ENV) {
    app.listen("passenger", () => onReady("listening passenger (PASSENGER_APP_ENV)"));
    return;
  }

  const host = String(process.env.HOST || "0.0.0.0").trim() || "0.0.0.0";
  app.listen(port, host, () => {
    onReady(`listening ${host}:${port}`);
    const lan = getLanIpv4Addresses();
    for (const ip of lan) {
      console.log(`  On your network:  http://${ip}:${port}/welcome.html`);
    }
  });
}

initDb()
  .then(async () => {
    await loadTwilioRuntimeConfigFromDb();
    await refreshCachedTwimlAppVoiceUrl();
    await normalizeSoldLeadScores(run);
    ensureVapidKeys();
    /* Owner-workspace marketing letters (idempotent: skips templates that
       already exist, so UI edits are never overwritten). Trial tenant DBs
       are seeded separately and never get these. */
    try {
      const outreachSeed = await seedCadenceOutreachTemplates({ run, get });
      if (outreachSeed.created.length) {
        console.log(`[startup] Cadence outreach templates added: ${outreachSeed.created.length}`);
      }
    } catch (err) {
      console.error("[startup] Cadence outreach template seed failed:", err.message || err);
    }
    if (isTrialWelcomeSmtpConfigured()) {
      const v = await verifyTrialWelcomeSmtp();
      if (v.ok) {
        console.log(
          `[startup] Trial welcome email: ${getTrialWelcomeFromAddress()} via ${getTrialWelcomeSmtpHost()} (verified)`
        );
        writeStartupLog(`trial welcome SMTP verified (${getTrialWelcomeFromAddress()})`);
      } else {
        console.error(`[startup] Trial welcome SMTP configured but verify failed: ${v.error}`);
        writeStartupLog(`trial welcome SMTP verify failed: ${v.error}`);
      }
    } else {
      const miss = getTrialWelcomeSmtpMissing().join(", ");
      console.warn(`[startup] Trial welcome SMTP not loaded (missing: ${miss}) — welcome mail may use Gmail.`);
      writeStartupLog(`trial welcome SMTP missing: ${miss}`);
    }
    try {
      const canNotify = await canSendSystemNotificationEmail();
      const salesRecipients = getContactSalesNotificationRecipients();
      if (canNotify && salesRecipients.length) {
        console.log(`[startup] Contact Sales notifications → ${salesRecipients.join(", ")}`);
        writeStartupLog(`Contact Sales notify: ${salesRecipients.join(", ")}`);
      } else if (salesRecipients.length) {
        console.warn(
          `[startup] Contact Sales recipients set (${salesRecipients.join(", ")}) but SMTP not ready — set SMTP_* or per-address SMTP in Settings`
        );
        writeStartupLog("Contact Sales notify: recipients set, SMTP missing");
      } else {
        console.warn("[startup] Contact Sales notifications disabled — set CONTACT_SALES_NOTIFY_EMAIL in .env");
        writeStartupLog("Contact Sales notify: no recipients");
      }
    } catch (err) {
      console.warn("[startup] Contact Sales notify check failed:", err.message || err);
    }
    const stripeCfg = getStripeConfigSummary();
    if (stripeCfg.ready) {
      console.log(`[startup] Stripe billing ready ($${stripeCfg.monthlyUsd}/mo, price ${stripeCfg.priceId})`);
      writeStartupLog("Stripe billing ready");
    } else if (stripeCfg.secretKeySet || stripeCfg.priceIdSet) {
      const miss = [];
      if (!stripeCfg.secretKeySet) miss.push("STRIPE_SECRET_KEY");
      if (!stripeCfg.priceIdSet) miss.push("STRIPE_PRICE_ID");
      if (!stripeCfg.webhookSecretSet) miss.push("STRIPE_WEBHOOK_SECRET");
      console.warn(`[startup] Stripe incomplete (missing: ${miss.join(", ")}) — trials cannot self-serve pay.`);
      writeStartupLog(`Stripe incomplete: ${miss.join(", ")}`);
    } else {
      console.warn("[startup] Stripe not configured — set STRIPE_* in .env for post-trial billing.");
      writeStartupLog("Stripe not configured");
    }
    const contactRow = await get("SELECT COUNT(*) AS total FROM contacts");
    const contactTotal = Number(contactRow && contactRow.total) || 0;
    const appRoot = path.resolve(__dirname, "..");
    const resolvedDb = path.resolve(dbPath);
    const dbOutsideThisSite =
      resolvedDb !== appRoot && !resolvedDb.startsWith(appRoot + path.sep);
    const siteDbLine = dbFileExistedBeforeOpen
      ? `existing database ${resolvedDb} — ${contactTotal} contacts in this website folder only`
      : `NEW empty database created at ${resolvedDb} — ${contactTotal} contacts. If this site already had contacts, restore this folder's crm.sqlite from a Spaceship backup. Do not copy crm.sqlite or tenant-data from the other website.`;
    if (dbOutsideThisSite) {
      console.warn(
        `[site] CRM_DB_PATH is outside this website folder (${resolvedDb}). cadencecrm.pro and crmcadence.com must not share one database file.`
      );
      writeStartupLog(`database path is outside this site folder: ${resolvedDb}`);
    }
    console.log(`[site] ${siteDbLine}`);
    writeStartupLog(siteDbLine);
    writeStartupLog("database ready");
    startHttpServer();
  })
  .catch((error) => {
    writeStartupLog(`database error: ${error && error.message ? error.message : error}`);
    console.error("Failed to initialize database:", error);
    console.error(
      "Check that crm.sqlite exists in the app folder and is writable (chmod 664)."
    );
    process.exit(1);
  });

module.exports = app;
