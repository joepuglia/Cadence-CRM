#!/usr/bin/env node
"use strict";

/**
 * Rebuild a damaged crm.sqlite so the site can load again.
 * Stop the Node app first, then from cPanel run the JS script db:recover.
 * Contacts and templates that SQLite can still read are kept.
 * The damaged file is copied beside the database before it is replaced.
 */

const { recoverAll } = require("./sqliteRecover");

try {
  const results = recoverAll();
  const rebuilt = results.filter((r) => r.recovered);
  if (!rebuilt.length) {
    console.log("[db-recover] No damaged database found. Start the Node app again.");
  } else {
    console.log(`[db-recover] Rebuilt ${rebuilt.length} database file(s). Start the Node app again.`);
  }
} catch (err) {
  console.error("[db-recover] FAILED: " + (err && err.message ? err.message : err));
  process.exit(1);
}
