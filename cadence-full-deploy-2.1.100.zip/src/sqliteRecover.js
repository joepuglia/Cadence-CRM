"use strict";

const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

const BUNDLED_SQLITE = path.join(__dirname, "..", "bin", "sqlite3");

function log(msg) {
  console.log(`[db-recover] ${msg}`);
}

function sqliteBin() {
  if (fs.existsSync(BUNDLED_SQLITE)) {
    try {
      fs.chmodSync(BUNDLED_SQLITE, 0o755);
    } catch {
      /* ignore */
    }
    const probe = spawnSync(BUNDLED_SQLITE, ["-version"], { encoding: "utf8" });
    if (probe.status === 0) return BUNDLED_SQLITE;
    log(`bundled sqlite3 did not run (${(probe.stderr || probe.error || "").toString().trim()})`);
  }
  const system = spawnSync("sh", ["-c", "command -v sqlite3"], { encoding: "utf8" });
  const found = String(system.stdout || "").trim();
  return found || "";
}

function combinedOutput(result) {
  return `${result.stdout || ""}\n${result.stderr || ""}`.trim();
}

function checkDatabase(bin, filePath) {
  const result = spawnSync(bin, [filePath, "PRAGMA quick_check(1);"], {
    encoding: "utf8",
    timeout: 10 * 60 * 1000
  });
  const detail = combinedOutput(result);
  if (/unable to open database file|database is locked/i.test(detail)) {
    return { state: "locked", detail };
  }
  const stdout = String(result.stdout || "").trim();
  if (result.status === 0 && stdout === "ok") return { state: "ok", detail };
  if (/malformed|SQLITE_CORRUPT|error code 11|btreeInitPage/i.test(detail) || stdout !== "ok") {
    return { state: "corrupt", detail: detail || `sqlite3 exited ${result.status}` };
  }
  return { state: "ok", detail };
}

function copySidecars(src, dest) {
  for (const suf of ["-wal", "-shm", "-journal"]) {
    if (fs.existsSync(src + suf)) {
      fs.copyFileSync(src + suf, dest + suf);
    }
  }
}

function removeSidecars(filePath) {
  for (const suf of ["-wal", "-shm", "-journal"]) {
    fs.rmSync(filePath + suf, { force: true });
  }
}

function fileBytes(filePath) {
  let total = 0;
  for (const suf of ["", "-wal", "-shm", "-journal"]) {
    try {
      total += fs.statSync(filePath + suf).size;
    } catch {
      /* missing sidecar */
    }
  }
  return total;
}

function freeBytes(dir) {
  try {
    const stat = fs.statfsSync(dir);
    return Number(stat.bavail) * Number(stat.bsize);
  } catch {
    return null;
  }
}

function recoverFile(bin, filePath) {
  const dir = path.dirname(filePath);
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const backup = path.join(dir, `${path.basename(filePath)}.corrupt-${stamp}`);
  const recovered = path.join(dir, `${path.basename(filePath)}.recovered-${stamp}`);
  const needed = fileBytes(filePath) * 3;
  const free = freeBytes(dir);
  if (free != null && needed > 0 && free < needed) {
    throw new Error(
      `Not enough free disk space to rebuild ${filePath}. Need about ${Math.ceil(needed / 1e6)} MB free and have ${Math.ceil(free / 1e6)} MB.`
    );
  }

  log(`backing up damaged database to ${backup}`);
  fs.copyFileSync(filePath, backup);
  copySidecars(filePath, backup);

  log(`rebuilding a readable copy of ${filePath}`);
  fs.rmSync(recovered, { force: true });
  const rebuilt = spawnSync(
    "sh",
    ["-c", '"$0" "$1" ".recover" | "$0" "$2"', bin, filePath, recovered],
    { stdio: ["ignore", "inherit", "inherit"] }
  );
  if (rebuilt.status !== 0 || !fs.existsSync(recovered)) {
    fs.rmSync(recovered, { force: true });
    throw new Error(`sqlite3 .recover failed for ${filePath} (exit ${rebuilt.status})`);
  }

  const after = checkDatabase(bin, recovered);
  if (after.state !== "ok") {
    fs.rmSync(recovered, { force: true });
    throw new Error(`rebuilt database is still damaged: ${after.detail}`);
  }

  const replaced = `${backup}.replaced`;
  fs.renameSync(filePath, replaced);
  fs.renameSync(recovered, filePath);
  removeSidecars(filePath);
  fs.rmSync(replaced, { force: true });
  log(`database rebuilt. Damaged original kept at ${backup}`);
  return backup;
}

function ensureDatabaseReadable(filePath) {
  if (!filePath || !fs.existsSync(filePath)) return { recovered: false };
  const bin = sqliteBin();
  if (!bin) {
    log("sqlite3 is not available, so a damaged database cannot be rebuilt automatically.");
    return { recovered: false, skipped: true };
  }
  const check = checkDatabase(bin, filePath);
  if (check.state === "ok") return { recovered: false };
  if (check.state === "locked") {
    log(`database is in use, so it was not rebuilt: ${check.detail}`);
    return { recovered: false, locked: true };
  }
  log(`damaged database detected: ${check.detail.split("\n")[0]}`);
  const backup = recoverFile(bin, filePath);
  return { recovered: true, backup };
}

function databasePaths(rootDir) {
  const root = rootDir || path.join(__dirname, "..");
  const paths = [];
  const main = process.env.CRM_DB_PATH
    ? path.resolve(process.env.CRM_DB_PATH)
    : path.join(root, "crm.sqlite");
  paths.push(main);
  const tenantRoot = path.join(root, "tenant-data");
  if (fs.existsSync(tenantRoot)) {
    for (const entry of fs.readdirSync(tenantRoot, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue;
      const tenantDb = path.join(tenantRoot, entry.name, "crm.sqlite");
      if (fs.existsSync(tenantDb)) paths.push(tenantDb);
    }
  }
  return paths;
}

function recoverAll(rootDir) {
  const paths = databasePaths(rootDir).filter((p) => fs.existsSync(p));
  if (!paths.length) {
    log("no crm.sqlite file found");
    return [];
  }
  return paths.map((filePath) => {
    log(`checking ${filePath}`);
    return { filePath, ...ensureDatabaseReadable(filePath) };
  });
}

module.exports = {
  ensureDatabaseReadable,
  recoverAll,
  checkDatabase,
  sqliteBin
};
