const webpush = require("web-push");
const {
  sendEmail,
  isEmailConfigured,
  sendSystemNotificationEmail,
  canSendSystemNotificationEmail
} = require("./emailService");
const { sendSms, isTwilioSmsReady, listAccountSmsNumbers } = require("./twilioService");
const { applyVapidToWebPush } = require("./vapidKeys");

const REMINDER_LABELS = {
  day_of: "on the follow-up date",
  day_before: "1 day before the follow-up",
  three_days_before: "3 days before the follow-up",
  week_before: "1 week before the follow-up"
};

const REMINDER_TIME_ZONE = String(process.env.CRM_TIMEZONE || "America/Bogota").trim() || "America/Bogota";

function zonedParts(d) {
  try {
    const fmt = new Intl.DateTimeFormat("en-US", {
      timeZone: REMINDER_TIME_ZONE,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hourCycle: "h23"
    });
    const parts = fmt.formatToParts(d);
    const pick = (type) => parts.find((p) => p.type === type)?.value || "";
    let hour = Number(pick("hour"));
    if (!Number.isFinite(hour) || hour === 24) hour = 0;
    let minute = Number(pick("minute"));
    if (!Number.isFinite(minute) || minute < 0 || minute > 59) minute = 0;
    return { year: pick("year"), month: pick("month"), day: pick("day"), hour, minute };
  } catch {
    return {
      year: String(d.getFullYear()),
      month: String(d.getMonth() + 1).padStart(2, "0"),
      day: String(d.getDate()).padStart(2, "0"),
      hour: d.getHours(),
      minute: d.getMinutes()
    };
  }
}

function ymdLocal(d) {
  const p = zonedParts(d);
  return `${p.year}-${p.month}-${p.day}`;
}

/** Calendar date (YYYY-MM-DD) when the reminder should fire. */
function reminderNotifyOnYmd(followUpYmd, reminderKind) {
  const raw = String(followUpYmd || "").trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) return null;
  const [yy, mm, dd] = raw.split("-").map(Number);
  const base = new Date(yy, mm - 1, dd);
  if (!Number.isFinite(base.getTime())) return null;
  const d = new Date(base.getFullYear(), base.getMonth(), base.getDate());
  switch (String(reminderKind || "").trim().toLowerCase()) {
    case "day_of":
      break;
    case "day_before":
      d.setDate(d.getDate() - 1);
      break;
    case "three_days_before":
      d.setDate(d.getDate() - 3);
      break;
    case "week_before":
      d.setDate(d.getDate() - 7);
      break;
    default:
      return null;
  }
  return ymdLocal(d);
}

function reminderSendClock(followUpTimeStr) {
  const t = String(followUpTimeStr || "").trim();
  const tm = /^(\d{1,2}):(\d{2})/.exec(t);
  if (tm) {
    const hour = Number(tm[1]);
    const minute = Number(tm[2]);
    if (hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59) return { hour, minute };
  }
  const hour = Number(process.env.FOLLOW_UP_REMINDER_SEND_HOUR || 9);
  return { hour: Number.isFinite(hour) ? hour : 9, minute: 0 };
}

/** True once America/Bogota has reached the task's date and minute. Five minutes ahead waits those five minutes. */
function shouldSendNow(notifyYmd, followUpTimeStr, now = new Date()) {
  if (ymdLocal(now) !== notifyYmd) return false;
  const due = reminderSendClock(followUpTimeStr);
  const clock = zonedParts(now);
  if (clock.hour > due.hour) return true;
  if (clock.hour < due.hour) return false;
  return clock.minute >= due.minute;
}

function getReminderEmailTo() {
  const raw = process.env.FOLLOW_UP_REMINDER_EMAIL || process.env.REMINDER_EMAIL || "";
  const list = raw
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  if (list.length) return list.join(",");
  const login = String(process.env.CRM_LOGIN_EMAIL || "").trim();
  if (login) return login;
  if (isEmailConfigured()) {
    return String(process.env.SMTP_FROM || process.env.SMTP_USER || "").trim();
  }
  return "";
}

/** Where the reminder email goes: the saved reminder address, the sign-in email, or the first sender. */
async function resolveReminderEmailTo(get) {
  const direct = getReminderEmailTo();
  if (direct) return direct;
  if (typeof get === "function") {
    try {
      const stored = await readRuntimeValue(get, "loginEmail");
      if (stored) return stored;
    } catch {
      /* the sign-in email may only live in the environment */
    }
  }
  try {
    const { get: dbGet } = require("./db");
    const row = await dbGet(
      `SELECT email_address FROM email_from_addresses ORDER BY created_at ASC, id ASC LIMIT 1`
    );
    const addr = String(row?.email_address || "").trim();
    if (addr) return addr;
  } catch {
    /* no saved sender */
  }
  return "";
}

async function reminderEmailCanSend() {
  if (typeof canSendSystemNotificationEmail === "function") {
    try {
      return await canSendSystemNotificationEmail();
    } catch {
      return false;
    }
  }
  return isEmailConfigured();
}

/** Uses the mail server saved under Email Sender Addresses, then the server SMTP. */
async function deliverReminderEmail({ to, subject, text }) {
  if (typeof sendSystemNotificationEmail === "function") {
    return sendSystemNotificationEmail({ to, subject, text });
  }
  return sendEmail({ to, subject, text });
}

async function readRuntimeValue(get, key) {
  const row = await get(`SELECT value FROM twilio_runtime_config WHERE key = ?`, [key]);
  return String(row?.value || "").trim();
}

function phoneDigits(raw) {
  const digits = String(raw || "").replace(/\D/g, "");
  if (digits.length === 11 && digits.startsWith("1")) return digits.slice(1);
  return digits;
}

/** Personal cell for task texts. A Cadence business number is never used as the destination. */
async function pickReminderSmsTo(get, fromNumbers) {
  const blocked = new Set((Array.isArray(fromNumbers) ? fromNumbers : []).map(phoneDigits).filter((d) => d.length >= 10));
  const raws = [];
  const override = String(process.env.FOLLOW_UP_REMINDER_SMS || process.env.REMINDER_SMS || "").trim();
  if (override) raws.push(override);
  if (typeof get === "function") {
    try {
      raws.push(await readRuntimeValue(get, "inboundForwardTo"));
      raws.push(await readRuntimeValue(get, "agentPhone"));
    } catch {
      /* fall through to the process env copy */
    }
  }
  raws.push(String(process.env.TWILIO_INBOUND_FORWARD_TO || "").trim());
  raws.push(String(process.env.CRM_AGENT_PHONE || "").trim());
  let sawBusinessLine = false;
  for (const raw of raws) {
    const value = String(raw || "").trim();
    const digits = phoneDigits(value);
    if (digits.length < 10) continue;
    if (blocked.has(digits)) {
      sawBusinessLine = true;
      continue;
    }
    return { to: value, blockedBusinessLine: false };
  }
  return { to: "", blockedBusinessLine: sawBusinessLine };
}

/** The cell saved under Settings → Your phone number. Task texts go here, never to the contact. */
async function getReminderSmsTo(get, fromNumbers) {
  const picked = await pickReminderSmsTo(get, fromNumbers);
  return picked.to;
}

function toE164(raw) {
  let t = String(raw || "")
    .trim()
    .replace(/[^\d+]/g, "");
  if (!t) return "";
  if (t.startsWith("++")) return "";
  if (!t.startsWith("+") && t.length === 10) t = `+1${t}`;
  if (!t.startsWith("+") && t.length === 11 && t.startsWith("1")) t = `+${t}`;
  if (!t.startsWith("+")) t = `+${t}`;
  return /^\+[1-9]\d{6,14}$/.test(t) ? t : "";
}

function localSmsFromNumbers() {
  const numbers = [];
  for (const name of ["TWILIO_PHONE_NUMBER", "TWILIO_PHONE_NUMBER_SECOND", "TWILIO_PHONE_NUMBER_THIRD"]) {
    const num = String(process.env[name] || "").trim();
    if (num && !numbers.includes(num)) numbers.push(num);
  }
  return numbers;
}

let accountSmsNumbersCache = { at: 0, numbers: [] };

/** Saved lines and extra numbers first. An old assigned number is used only when those are empty. */
async function listTaskSmsFromNumbers(all, get) {
  const numbers = [];
  const push = (raw) => {
    const num = toE164(raw);
    if (num && !numbers.includes(num)) numbers.push(num);
  };
  for (const num of localSmsFromNumbers()) push(num);
  if (typeof all === "function") {
    try {
      const rows = await all(
        `SELECT phone_number FROM twilio_from_numbers ORDER BY created_at ASC, id ASC`
      );
      for (const row of Array.isArray(rows) ? rows : []) push(row?.phone_number);
    } catch {
      /* extra numbers are optional */
    }
  }
  if (!numbers.length && typeof get === "function") {
    try {
      push(await readRuntimeValue(get, "phoneNumber"));
    } catch {
      /* the assigned number is also copied into the environment at startup */
    }
  }
  if (isTwilioSmsReady() && typeof listAccountSmsNumbers === "function") {
    const now = Date.now();
    if (now - accountSmsNumbersCache.at > 10 * 60 * 1000) {
      try {
        const remote = await listAccountSmsNumbers();
        accountSmsNumbersCache = { at: now, numbers: Array.isArray(remote) ? remote : [] };
      } catch (err) {
        accountSmsNumbersCache = { at: now, numbers: [] };
        console.error("[task reminder] could not list Twilio numbers:", err.message || err);
      }
    }
    for (const num of accountSmsNumbersCache.numbers) push(num);
  }
  return numbers;
}

async function describeTaskSmsRoute(get, all) {
  const fromNumbers = await listTaskSmsFromNumbers(all, get);
  const picked = await pickReminderSmsTo(get, fromNumbers);
  let lastTaskSmsError = "";
  if (typeof get === "function") {
    try {
      lastTaskSmsError = await readRuntimeValue(get, "taskSmsLastError");
    } catch {
      lastTaskSmsError = "";
    }
  }
  return {
    taskSmsTo: picked.to,
    taskSmsBlockedBusinessLine: picked.blockedBusinessLine,
    taskSmsFrom: fromNumbers[0] || "",
    taskSmsFromNumbers: fromNumbers,
    lastTaskSmsError
  };
}

/** Missing setting stays on. Stored 0, false, off, or no turns task texts off. */
async function isTaskSmsRemindersEnabled(get) {
  if (typeof get !== "function") return true;
  try {
    const row = await get(`SELECT value FROM twilio_runtime_config WHERE key = ?`, ["taskSmsReminders"]);
    if (!row) return true;
    const v = String(row.value ?? "").trim().toLowerCase();
    return !["0", "false", "off", "no", "disabled"].includes(v);
  } catch {
    return true;
  }
}

function taskReminderSmsBody({ taskLabel, action, name }) {
  const actionBit = action ? ` (${action})` : "";
  return `Task due today: ${taskLabel}${actionBit} for ${name}.`;
}

async function prepareReminderRuntime(deps) {
  if (typeof deps.prepareRuntime !== "function") return;
  try {
    await deps.prepareRuntime();
  } catch (err) {
    console.error("[task reminder] could not load phone settings:", (err && err.message) || err);
  }
}

function getPublicBaseUrl() {
  const u = String(process.env.CRM_PUBLIC_URL || "").trim().replace(/\/$/, "");
  if (u) return u;
  const port = Number(process.env.PORT || 3000);
  return `http://localhost:${port}`;
}

async function alreadySent(get, contactId, channel, reminderKind, followUpDate) {
  const row = await get(
    `SELECT id FROM follow_up_reminder_sent
     WHERE contact_id = ? AND channel = ? AND reminder_kind = ? AND follow_up_date = ?`,
    [contactId, channel, reminderKind, followUpDate]
  );
  return !!row;
}

function escapeHtml(s) {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

let processing = false;
let taskProcessing = false;
let lastTaskSmsError = "";

function getLastTaskSmsError() {
  return lastTaskSmsError;
}

function sameDay(stamp, ymd) {
  return String(stamp || "").trim().slice(0, 10) === ymd;
}

async function processFollowUpReminders(deps) {
  const { all, get, run } = deps;
  if (processing) return;
  processing = true;
  try {
    const rows = await all(`
      SELECT id, full_name, email, phone, follow_up_date, follow_up_time, follow_up_reminder
      FROM contacts
      WHERE follow_up_date IS NOT NULL AND trim(follow_up_date) != ''
        AND follow_up_reminder IS NOT NULL AND lower(trim(follow_up_reminder)) NOT IN ('', 'none')
    `);

    const now = new Date();
    const emailTo = await resolveReminderEmailTo(get);
    const canEmail = (await reminderEmailCanSend()) && emailTo;
    const pushReady = applyVapidToWebPush();
    const subs = pushReady ? await all(`SELECT id, endpoint, subscription_json FROM push_subscriptions`) : [];

    for (const row of rows) {
      const fuDate = String(row.follow_up_date || "").trim();
      const kind = String(row.follow_up_reminder || "").trim().toLowerCase();
      const notifyYmd = reminderNotifyOnYmd(fuDate, kind);
      if (!notifyYmd || notifyYmd !== ymdLocal(now)) continue;
      if (!shouldSendNow(notifyYmd, row.follow_up_time, now)) continue;

      const label = REMINDER_LABELS[kind] || kind;
      const baseUrl = getPublicBaseUrl();
      const contactUrl = `${baseUrl}/contact.html?id=${row.id}`;
      const name = String(row.full_name || "").trim() || `Contact #${row.id}`;

      if (canEmail) {
        const sent = await alreadySent(get, row.id, "email", kind, fuDate);
        if (!sent) {
          try {
            await deliverReminderEmail({
              to: emailTo,
              subject: `[CRM] Follow-up reminder: ${name}`,
              text: `Follow-up (${label}) for ${name}.\nScheduled date: ${fuDate}\nOpen: ${contactUrl}`
            });
            await run(
              `INSERT INTO follow_up_reminder_sent (contact_id, channel, reminder_kind, follow_up_date)
               VALUES (?, 'email', ?, ?)`,
              [row.id, kind, fuDate]
            );
          } catch (err) {
            console.error("[follow-up reminder] email failed:", err.message || err);
          }
        }
      }

      if (pushReady && subs.length) {
        const sentPush = await alreadySent(get, row.id, "push", kind, fuDate);
        if (!sentPush) {
          const payload = JSON.stringify({
            title: "CRM follow-up reminder",
            body: `${name} — scheduled ${fuDate} (${label})`,
            url: `/contact.html?id=${row.id}`,
            tag: `crm-followup-${row.id}-${fuDate}-${kind}`
          });
          let anyOk = false;
          for (const sub of subs) {
            try {
              let subscription;
              try {
                subscription = JSON.parse(sub.subscription_json || "{}");
              } catch {
                continue;
              }
              if (!subscription.endpoint) continue;
              await webpush.sendNotification(subscription, payload, {
                TTL: 86400,
                urgency: "normal"
              });
              anyOk = true;
            } catch (err) {
              const code = err && err.statusCode;
              if (code === 404 || code === 410) {
                await run(`DELETE FROM push_subscriptions WHERE endpoint = ?`, [sub.endpoint]);
              } else {
                console.error("[follow-up reminder] push failed:", err.message || err);
              }
            }
          }
          if (anyOk) {
            await run(
              `INSERT INTO follow_up_reminder_sent (contact_id, channel, reminder_kind, follow_up_date)
               VALUES (?, 'push', ?, ?)`,
              [row.id, kind, fuDate]
            );
          }
        }
      }
    }
  } finally {
    processing = false;
  }
}

async function buildTaskReminderContext(deps) {
  const sendEmailFn = typeof deps.sendEmail === "function" ? deps.sendEmail : deliverReminderEmail;
  const sendSmsFn = typeof deps.sendSms === "function" ? deps.sendSms : sendSms;
  const emailReady = deps.emailReady === true || (deps.emailReady !== false && (await reminderEmailCanSend()));
  let smsReady = typeof deps.isSmsReady === "function" ? deps.isSmsReady() : isTwilioSmsReady();
  const emailTo = typeof deps.reminderEmailTo === "string" ? deps.reminderEmailTo : await resolveReminderEmailTo(deps.get);
  const fromPreview =
    typeof deps.listSmsFromNumbers === "function"
      ? await deps.listSmsFromNumbers()
      : await listTaskSmsFromNumbers(deps.all, deps.get);
  const picked = await pickReminderSmsTo(deps.get, Array.isArray(fromPreview) ? fromPreview : []);
  const smsTo = picked.to;
  if (!smsReady && process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN) {
    const fromNumbers =
      typeof deps.listSmsFromNumbers === "function"
        ? await deps.listSmsFromNumbers()
        : await listTaskSmsFromNumbers(deps.all, deps.get);
    if (Array.isArray(fromNumbers) && fromNumbers.length) smsReady = true;
  }
  const smsAllowed =
    deps.taskSmsEnabled === false
      ? false
      : deps.taskSmsEnabled === true
        ? true
        : await isTaskSmsRemindersEnabled(deps.get);
  return {
    sendEmailFn,
    sendSmsFn,
    emailTo,
    smsTo,
    canEmail: Boolean(emailReady && emailTo),
    canSms: Boolean(smsReady && smsTo && smsAllowed),
    smsBlockedBusinessLine: picked.blockedBusinessLine === true,
    smsReady,
    smsAllowed,
    baseUrl: getPublicBaseUrl(),
    listSmsFromNumbers: deps.listSmsFromNumbers,
    all: deps.all,
    get: deps.get
  };
}

async function sendDueTaskChannels(ctx, row, options = {}) {
  const skipEmail = options.skipEmail === true;
  const skipSms = options.skipSms === true;
  const name = String(row.full_name || "").trim() || `Contact #${row.contact_id}`;
  const taskLabel = String(row.task_name || "Task").trim() || "Task";
  const action = String(row.action_type || "").trim();
  const contactUrl = `${ctx.baseUrl}/contact.html?id=${row.contact_id}`;
  const result = {
    taskId: row.id,
    emailSent: false,
    emailTo: ctx.emailTo || "",
    emailError: "",
    smsSent: false,
    smsTo: ctx.smsTo || "",
    smsFrom: "",
    smsError: ""
  };
  if (!skipSms) {
    if (!ctx.canSms) {
      if (!ctx.smsAllowed) result.smsError = "Text reminders are turned off.";
      else if (!ctx.smsTo && ctx.smsBlockedBusinessLine) {
        result.smsError =
          "The number under Your phone number is your Cadence business number. Enter your personal cell there.";
      } else if (!ctx.smsTo) result.smsError = "No personal cell is saved under Settings → Your phone number.";
      else result.smsError = "The business number is not connected for texts.";
    } else {
      const body = taskReminderSmsBody({ taskLabel, action, name, contactUrl });
      const fromNumbers =
        typeof ctx.listSmsFromNumbers === "function"
          ? await ctx.listSmsFromNumbers()
          : await listTaskSmsFromNumbers(ctx.all, ctx.get);
      const attempts = Array.isArray(fromNumbers) && fromNumbers.length ? fromNumbers : [""];
      let lastErr = null;
      for (const from of attempts) {
        try {
          const payload = { to: ctx.smsTo, body };
          if (from) payload.twilioFrom = from;
          await ctx.sendSmsFn(payload);
          result.smsSent = true;
          result.smsFrom = from || "";
          break;
        } catch (err) {
          lastErr = err;
        }
      }
      if (!result.smsSent) {
        result.smsError = (lastErr && lastErr.message) || "Text failed.";
        console.error("[task reminder] sms failed:", result.smsError);
      }
    }
    if (result.smsSent) lastTaskSmsError = "";
    else if (result.smsError) lastTaskSmsError = result.smsError;
  }
  if (!skipEmail) {
    if (!ctx.canEmail) {
      result.emailError = ctx.emailTo ? "Mail is not connected." : "No email address is saved for reminders.";
    } else {
      const textLines = [];
      if (result.smsSent) textLines.push(`Text sent to ${result.smsTo}.`);
      else if (result.smsError) textLines.push(`Text did not send: ${result.smsError}`);
      textLines.push(`Task "${taskLabel}"${action ? ` (${action})` : ""} is due today for ${name}.`);
      textLines.push(`Open: ${contactUrl}`);
      try {
        await ctx.sendEmailFn({
          to: ctx.emailTo,
          subject: `[CRM] Task due today: ${taskLabel} — ${name}`,
          text: textLines.join("\n")
        });
        result.emailSent = true;
      } catch (err) {
        result.emailError = (err && err.message) || "Email failed.";
        console.error("[task reminder] email failed:", result.emailError);
      }
    }
  }
  return result;
}

async function rememberTaskSmsResult(run, sent) {
  if (typeof run !== "function" || !sent) return;
  const value = sent.smsSent ? "" : String(sent.smsError || "").slice(0, 500);
  if (!sent.smsSent && !sent.smsError) return;
  try {
    await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('taskSmsLastError', ?)`, [value]);
  } catch {
    /* the settings page can still use the in-memory error */
  }
}

async function stampTaskReminder(run, today, taskId, sent) {
  if (typeof run !== "function") return;
  const sets = [];
  const params = [];
  if (sent.emailSent) {
    sets.push("reminder_sent_date = ?");
    params.push(today);
  }
  if (sent.smsSent) {
    sets.push("reminder_sms_sent_date = ?");
    params.push(today);
  }
  if (!sets.length) return;
  params.push(taskId);
  await run(`UPDATE contact_tasks SET ${sets.join(", ")} WHERE id = ?`, params);
}

/** Send the email and text for one task once its Bogota minute has arrived. */
async function remindTaskById(deps, taskId) {
  const id = Number(taskId);
  if (!Number.isInteger(id) || id < 1) return { missing: true };
  await prepareReminderRuntime(deps);
  const row = await deps.get(
    `SELECT t.id, t.task_name, t.action_type, t.task_date, t.task_time, t.condition,
            t.reminder_sent_date, t.reminder_sms_sent_date,
            c.id AS contact_id, c.full_name
     FROM contact_tasks t
     JOIN contacts c ON c.id = t.contact_id
     WHERE t.id = ?`,
    [id]
  );
  if (!row) return { missing: true };
  if (String(row.condition || "").trim().toLowerCase() === "completed") return { skipped: true, reason: "completed" };
  const now = new Date();
  const today = ymdLocal(now);
  const date = String(row.task_date || "").trim().slice(0, 10);
  if (date !== today || !shouldSendNow(today, row.task_time, now)) return { waiting: true };
  const skipEmail = sameDay(row.reminder_sent_date, today);
  const skipSms = sameDay(row.reminder_sms_sent_date, today);
  if (skipEmail && skipSms) return { alreadySent: true };
  const ctx = await buildTaskReminderContext(deps);
  const result = await sendDueTaskChannels(ctx, row, { skipEmail, skipSms });
  await stampTaskReminder(deps.run, today, id, result);
  await rememberTaskSmsResult(deps.run, result);
  return result;
}

/** Tasks due today email, text, and push the agent.
 *  One reminder per task per day, deduped via contact_tasks.reminder_sent_date.
 *  The text goes to the phone in Settings, not to the contact. */
async function processTaskReminders(deps) {
  const { all, get, run } = deps;
  if (taskProcessing) return;
  taskProcessing = true;
  try {
    await prepareReminderRuntime(deps);
    const now = new Date();
    const todayYmd = ymdLocal(now);
    const rows = await all(
      `SELECT t.id, t.task_name, t.action_type, t.task_time,
              t.reminder_sent_date, t.reminder_sms_sent_date,
              c.id AS contact_id, c.full_name
       FROM contact_tasks t
       JOIN contacts c ON c.id = t.contact_id
       WHERE t.task_date = ?
         AND lower(trim(COALESCE(t.condition, ''))) != 'completed'
         AND (
           COALESCE(t.reminder_sent_date, '') != ?
           OR COALESCE(t.reminder_sms_sent_date, '') != ?
         )`,
      [todayYmd, todayYmd, todayYmd]
    );
    if (!Array.isArray(rows) || !rows.length) return;

    const ctx = await buildTaskReminderContext(deps);
    const pushReady = applyVapidToWebPush();
    const subs = pushReady ? await all(`SELECT id, endpoint, subscription_json FROM push_subscriptions`) : [];

    for (const row of rows) {
      if (!shouldSendNow(todayYmd, row.task_time, now)) continue;
      const sent = await sendDueTaskChannels(ctx, row, {
        skipEmail: sameDay(row.reminder_sent_date, todayYmd),
        skipSms: sameDay(row.reminder_sms_sent_date, todayYmd)
      });
      const taskLabel = String(row.task_name || "Task").trim() || "Task";
      const name = String(row.full_name || "").trim() || `Contact #${row.contact_id}`;

      if (pushReady && subs.length) {
        const payload = JSON.stringify({
          title: "CRM task due today",
          body: `${taskLabel} — ${name}`,
          url: `/contact.html?id=${row.contact_id}`,
          tag: `crm-task-${row.id}-${todayYmd}`
        });
        for (const sub of subs) {
          try {
            let subscription;
            try {
              subscription = JSON.parse(sub.subscription_json || "{}");
            } catch {
              continue;
            }
            if (!subscription.endpoint) continue;
            await webpush.sendNotification(subscription, payload, { TTL: 86400, urgency: "normal" });
          } catch (err) {
            const code = err && err.statusCode;
            if (code === 404 || code === 410) {
              await run(`DELETE FROM push_subscriptions WHERE endpoint = ?`, [sub.endpoint]);
            } else {
              console.error("[task reminder] push failed:", err.message || err);
            }
          }
        }
      }

      await stampTaskReminder(run, todayYmd, row.id, sent);
      await rememberTaskSmsResult(run, sent);
    }
  } finally {
    taskProcessing = false;
  }
}

function startFollowUpReminderScheduler(deps) {
  const tickMs = Number(process.env.FOLLOW_UP_REMINDER_TICK_MS || 20000);
  const tick = () => {
    processFollowUpReminders(deps).catch((err) => console.error("Follow-up reminder scheduler error:", err));
    processTaskReminders(deps).catch((err) => console.error("Task reminder scheduler error:", err));
  };
  const id = setInterval(tick, tickMs);
  setTimeout(tick, 5000);
  return () => clearInterval(id);
}

module.exports = {
  startFollowUpReminderScheduler,
  processFollowUpReminders,
  processTaskReminders,
  getReminderEmailTo,
  resolveReminderEmailTo,
  reminderEmailCanSend,
  getReminderSmsTo,
  listTaskSmsFromNumbers,
  describeTaskSmsRoute,
  isTaskSmsRemindersEnabled,
  taskReminderSmsBody,
  reminderNotifyOnYmd,
  ymdLocal,
  shouldSendNow,
  remindTaskById,
  getLastTaskSmsError,
  getPublicBaseUrl
};
