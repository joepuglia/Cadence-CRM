const EMAIL_SIGNATURE_KEY = "crm.emailSignatureSettings";
const EMAIL_INCLUDE_SIGNATURE_KEY = "crm.emailIncludeSignature";

const settingsBackBtn = document.getElementById("settingsBackBtn");
const emailSignatureForm = document.getElementById("emailSignatureForm");
const emailSignatureEditor = document.getElementById("emailSignatureEditor");
const emailIncludeSignature = document.getElementById("emailIncludeSignature");
const emailSignatureLinkText = document.getElementById("emailSignatureLinkText");
const emailSignatureLinkUrl = document.getElementById("emailSignatureLinkUrl");
const emailSignatureImageUrl = document.getElementById("emailSignatureImageUrl");
const emailSignatureImageFile = document.getElementById("emailSignatureImageFile");
const signatureSaveFeedback = document.getElementById("signatureSaveFeedback");
const signatureSettingsMessage = document.getElementById("signatureSettingsMessage");
const twilioNumberForm = document.getElementById("twilioNumberForm");
const twilioNumberInput = document.getElementById("twilioNumberInput");
const twilioNumberLabelInput = document.getElementById("twilioNumberLabelInput");
const twilioNumbersList = document.getElementById("twilioNumbersList");
const twilioNumberMessage = document.getElementById("twilioNumberMessage");
const emailFromAddressForm = document.getElementById("emailFromAddressForm");
const emailFromAddressInput = document.getElementById("emailFromAddressInput");
const emailFromLabelInput = document.getElementById("emailFromLabelInput");
const emailFromAddressesList = document.getElementById("emailFromAddressesList");
const emailFromAddressMessage = document.getElementById("emailFromAddressMessage");
const twilioConfigForm = document.getElementById("twilioConfigForm");
const twilioAccountSidInput = document.getElementById("twilioAccountSidInput");
const twilioAuthTokenInput = document.getElementById("twilioAuthTokenInput");
const twilioApiKeyInput = document.getElementById("twilioApiKeyInput");
const twilioApiSecretInput = document.getElementById("twilioApiSecretInput");
const twilioVoiceTwimlAppSidInput = document.getElementById("twilioVoiceTwimlAppSidInput");
const twilioVoiceWebhookStatus = document.getElementById("twilioVoiceWebhookStatus");
const twilioVoiceIdentityInput = document.getElementById("twilioVoiceIdentityInput");
const twilioInboundForwardToInput = document.getElementById("twilioInboundForwardToInput");
const agentNameInput  = document.getElementById("agentNameInput");
const agentPhoneInput = document.getElementById("agentPhoneInput");
const twilioCallRecordingDefaultInput = document.getElementById("twilioCallRecordingDefaultInput");
const resetEmailOpenAlertsBtn = document.getElementById("resetEmailOpenAlertsBtn");
const resetEmailOpenAlertsMessage = document.getElementById("resetEmailOpenAlertsMessage");
const runtimeConfigForm = document.getElementById("runtimeConfigForm");
const crmPublicUrlInput = document.getElementById("crmPublicUrlInput");
const healthSherpaUrlInput = document.getElementById("healthSherpaUrlInput");
const crmPublicUrlTrackingHint = document.getElementById("crmPublicUrlTrackingHint");
const loginEmailInput = document.getElementById("loginEmailInput");
const loginPasswordInput = document.getElementById("loginPasswordInput");
const loginPasswordConfirmInput = document.getElementById("loginPasswordConfirmInput");
const loginPasswordConfiguredHint = document.getElementById("loginPasswordConfiguredHint");
const socialExtraPlatformsInput = document.getElementById("socialExtraPlatformsInput");
const socialWebhookFacebookInput = document.getElementById("socialWebhookFacebookInput");
const socialWebhookInstagramInput = document.getElementById("socialWebhookInstagramInput");
const socialWebhookXInput = document.getElementById("socialWebhookXInput");
const socialWebhookLinkedinInput = document.getElementById("socialWebhookLinkedinInput");
const socialExtraWebhooksHost = document.getElementById("socialExtraWebhooksHost");
const socialExtraWebhooksHostEmpty = document.getElementById("socialExtraWebhooksHostEmpty");
const saveSocialWebhooksBtn = document.getElementById("saveSocialWebhooksBtn");
const socialWebhooksSaveStatus = document.getElementById("socialWebhooksSaveStatus");
const runtimeConfigMessage = document.getElementById("runtimeConfigMessage");
const login2faStatusPill = document.getElementById("login2faStatusPill");
const login2faStatusHint = document.getElementById("login2faStatusHint");
const login2faSetupBeginBtn = document.getElementById("login2faSetupBeginBtn");
const login2faSetupCancelBtn = document.getElementById("login2faSetupCancelBtn");
const login2faSetupPanel = document.getElementById("login2faSetupPanel");
const login2faQrImage = document.getElementById("login2faQrImage");
const login2faSecretValue = document.getElementById("login2faSecretValue");
const login2faSetupCodeInput = document.getElementById("login2faSetupCodeInput");
const login2faConfirmBtn = document.getElementById("login2faConfirmBtn");
const login2faBackupCodesBox = document.getElementById("login2faBackupCodesBox");
const login2faBackupCodes = document.getElementById("login2faBackupCodes");
const login2faDownloadBackupCodesBtn = document.getElementById("login2faDownloadBackupCodesBtn");
const login2faDisablePasswordInput = document.getElementById("login2faDisablePasswordInput");
const login2faDisableCodeInput = document.getElementById("login2faDisableCodeInput");
const login2faDisableBtn = document.getElementById("login2faDisableBtn");
const login2faMessage = document.getElementById("login2faMessage");
const buildStampFooter = document.getElementById("crmBuildStampFooter");

const BUILTIN_SOCIAL_TARGETS = new Set(["facebook", "instagram", "x", "linkedin"]);
let lastLoadedSocialWebhooks = {};

function normalizeSocialTargetLocal(raw) {
  return String(raw || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, "");
}

function escapeAttr(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;");
}

function collectExtraWebhookValuesFromDom() {
  const out = {};
  if (!socialExtraWebhooksHost) return out;
  socialExtraWebhooksHost.querySelectorAll(".social-webhook-extra-input").forEach((el) => {
    const t = el.getAttribute("data-social-target");
    if (t) out[t] = String(el.value || "").trim();
  });
  return out;
}

function renderExtraSocialWebhookInputs() {
  if (!socialExtraWebhooksHost) return;
  const merged = { ...lastLoadedSocialWebhooks, ...collectExtraWebhookValuesFromDom() };
  const extras = String(socialExtraPlatformsInput?.value || "")
    .split(",")
    .map((s) => normalizeSocialTargetLocal(s))
    .filter((t) => t && !BUILTIN_SOCIAL_TARGETS.has(t));
  const uniq = [...new Set(extras)];
  if (socialExtraWebhooksHostEmpty) {
    socialExtraWebhooksHostEmpty.hidden = uniq.length > 0;
  }
  if (!uniq.length) {
    socialExtraWebhooksHost.innerHTML = "";
    return;
  }
  socialExtraWebhooksHost.innerHTML = uniq
    .map((t) => {
      const v = String(merged[t] || "").trim();
      const safeId = `socialWebhookExtra_${t.replace(/[^a-z0-9_-]/gi, "_")}`;
      return `<div class="contact-field-box">
        <label class="contact-modal-field-label" for="${safeId}">${escapeAttr(t)} webhook URL</label>
        <div class="settings-webhook-row">
          <input id="${safeId}" class="social-webhook-extra-input" type="url" data-social-target="${escapeAttr(
            t
          )}" placeholder="e.g. https://hooks.example.com/webhook123" value="${escapeAttr(v)}" />
          <button type="button" class="settings-webhook-test-btn" data-webhook-input="${safeId}">Test</button>
        </div>
        <span class="settings-webhook-status" data-webhook-status-for="${safeId}">Untested</span>
      </div>`;
    })
    .join("");
}

function showSignatureMessage(text, isError = false) {
  if (!signatureSettingsMessage) return;
  signatureSettingsMessage.textContent = text || "";
  signatureSettingsMessage.style.color = isError ? "#b91c1c" : "#475569";
}

function setSignatureSaveFeedback(text, isError = false) {
  if (!signatureSaveFeedback) return;
  signatureSaveFeedback.textContent = text || "";
  signatureSaveFeedback.classList.toggle("signature-save-feedback--error", Boolean(isError));
}

function getSignatureEditorHtml() {
  return String(emailSignatureEditor?.innerHTML || "").trim();
}

function getSignatureEditorText() {
  return String(emailSignatureEditor?.textContent || "").trim();
}

function setSignatureEditorHtml(html) {
  if (!emailSignatureEditor) return;
  emailSignatureEditor.innerHTML = String(html || "").trim();
}

function applySignatureToSettingsForm(settings) {
  const data = settings && typeof settings === "object" ? settings : {};
  const signatureHtml = String(data.html || "").trim();
  const signatureText = String(data.text || "").trim();
  if (signatureHtml) setSignatureEditorHtml(signatureHtml);
  else if (signatureText) setSignatureEditorHtml(signatureText.replace(/\r?\n/g, "<br>"));
  if (emailSignatureLinkText) emailSignatureLinkText.value = String(data.linkText || "");
  if (emailSignatureLinkUrl) emailSignatureLinkUrl.value = String(data.linkUrl || "");
  if (emailSignatureImageUrl) emailSignatureImageUrl.value = String(data.imageUrl || "");
  if (emailIncludeSignature) {
    emailIncludeSignature.checked = data.include !== false;
  }
}

async function loadSavedSignature() {
  try {
    if (typeof window.fetchEmailSignatureFromServer === "function") {
      const payload = await window.fetchEmailSignatureFromServer();
      const settings = payload?.settings && typeof payload.settings === "object" ? payload.settings : {};
      applySignatureToSettingsForm({ ...settings, include: payload.include !== false });
      return;
    }
  } catch (error) {
    showSignatureMessage(
      (error && error.message) || "Could not load signature from server; showing this browser's saved copy.",
      true
    );
  }
  try {
    const raw = window.localStorage.getItem(EMAIL_SIGNATURE_KEY);
    const settings = raw ? JSON.parse(raw) : {};
    applySignatureToSettingsForm(settings);
    const includeRaw = window.localStorage.getItem(EMAIL_INCLUDE_SIGNATURE_KEY);
    if (emailIncludeSignature) emailIncludeSignature.checked = includeRaw == null ? true : includeRaw === "1";
  } catch {
    if (emailIncludeSignature) emailIncludeSignature.checked = true;
  }
}

function collectKnownFromAddressesForSignature() {
  return [...lastLoadedFromAddressEmails];
}

function execEditorCommand(command, value) {
  if (!emailSignatureEditor) return;
  emailSignatureEditor.focus();
  document.execCommand(command, false, value);
}

const signatureMergeFieldSelect = document.getElementById("signatureMergeFieldSelect");

function insertSignatureMergeToken(token) {
  const t = String(token || "").trim();
  if (!t || !emailSignatureEditor) return;
  emailSignatureEditor.focus();
  const ok = document.execCommand("insertText", false, t);
  if (!ok) {
    document.execCommand("insertHTML", false, t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"));
  }
}

function normalizeSignatureMergeKeySlug(raw) {
  return String(raw || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function rebuildSignatureMergeFieldDropdownCustomGroup(rows) {
  if (!signatureMergeFieldSelect) return;
  const existing = signatureMergeFieldSelect.querySelector('optgroup[data-custom-merge-group="1"]');
  if (existing) existing.remove();
  if (!Array.isArray(rows) || rows.length === 0) return;
  const group = document.createElement("optgroup");
  group.label = "Merge fields";
  group.setAttribute("data-custom-merge-group", "1");
  for (const row of rows) {
    const slug = normalizeSignatureMergeKeySlug(row?.field_key ?? row?.slug);
    if (!slug) continue;
    const token = `{{${slug}}}`;
    const label = String(row?.label || "").trim();
    const opt = document.createElement("option");
    opt.value = token;
    opt.textContent = label ? `${token} (${label})` : token;
    group.appendChild(opt);
  }
  signatureMergeFieldSelect.appendChild(group);
}

async function refreshSignatureMergeFieldDropdown() {
  if (!signatureMergeFieldSelect) return;
  try {
    const rows = await fetchApiJson("/api/custom-merge-fields");
    const list = Array.isArray(rows) ? rows : [];
    rebuildSignatureMergeFieldDropdownCustomGroup(
      list.map((row) => ({
        field_key: row?.field_key,
        label: row?.label
      }))
    );
  } catch {
    rebuildSignatureMergeFieldDropdownCustomGroup([]);
  }
}

function getCrmApiBase() {
  const injected =
    typeof window.__CRM_API_ORIGIN__ === "string" ? window.__CRM_API_ORIGIN__.trim().replace(/\/$/, "") : "";
  if (injected) return injected;
  const fromMeta = document.querySelector('meta[name="crm-api-base"]')?.getAttribute("content") || "";
  return String(fromMeta || "").trim().replace(/\/$/, "");
}

function apiUrl(path) {
  if (/^https?:\/\//i.test(String(path || ""))) return String(path);
  const p = String(path || "").startsWith("/") ? String(path) : `/${path}`;
  const base = getCrmApiBase();
  return base ? `${base}${p}` : p;
}

function redirectToLoginForExpiredSession() {
  const next = encodeURIComponent(window.location.pathname + window.location.search);
  const idleMin = 60;
  const msg = `You were signed out after ${idleMin} minutes of inactivity.`;
  try {
    sessionStorage.setItem("crm_login_timeout_msg", msg);
    sessionStorage.setItem("crm_login_timeout_at", String(Date.now()));
    localStorage.setItem("crm_login_timeout_msg", msg);
    localStorage.setItem("crm_login_timeout_at", String(Date.now()));
    localStorage.setItem("crm_had_authenticated_session", "1");
  } catch {
    /* ignore */
  }
  window.location.href = `/login.html?timeout=1&sessionExpired=1&idle=${idleMin}&next=${next}`;
}

function isSessionExpiredApiError(response, payload, message) {
  if (response?.status !== 401) return false;
  if (payload && payload.sessionExpired) return true;
  return /session expired due to inactivity/i.test(String(message || ""));
}

async function fetchApiJson(url, options = {}) {
  const resolved = apiUrl(url);
  const fetchOpts = { credentials: "include", ...options };
  const response = await fetch(resolved, fetchOpts);
  let payload = null;
  try {
    payload = await response.json();
  } catch {
    payload = null;
  }
  if (!response.ok) {
    const message =
      (payload && (payload.error || payload.message)) || `${response.status} ${response.statusText || "Request failed"}`;
    if (isSessionExpiredApiError(response, payload, message)) {
      redirectToLoginForExpiredSession();
      throw new Error(message);
    }
    throw new Error(message);
  }
  return payload;
}

async function ensureActiveCrmSession() {
  try {
    const response = await fetch(apiUrl("/api/auth/activity"), {
      method: "POST",
      credentials: "include"
    });
    let payload = null;
    try {
      payload = await response.json();
    } catch {
      payload = null;
    }
    if (response.status === 401 || (payload && payload.sessionExpired)) {
      redirectToLoginForExpiredSession();
      return false;
    }
    return response.ok;
  } catch {
    return true;
  }
}

async function fetchSetupStatusPayload() {
  try {
    return await fetchApiJson("/api/setup/status");
  } catch (err) {
    const msg = String(err?.message || "");
    if (/404|not found/i.test(msg)) {
      return await fetchApiJson("/api/runtime/setup-status");
    }
    throw err;
  }
}

function showTwilioNumberMessage(text, isError = false) {
  if (!twilioNumberMessage) return;
  twilioNumberMessage.textContent = text || "";
  twilioNumberMessage.style.color = isError ? "#b91c1c" : "#047857";
}

function showEmailFromAddressMessage(text, isError = false) {
  if (!emailFromAddressMessage) return;
  emailFromAddressMessage.textContent = text || "";
  emailFromAddressMessage.style.color = isError ? "#b91c1c" : "#047857";
}

function escapeHtmlText(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/** Cache of the latest custom from-address rows for inline SMTP edit. */
let cachedCustomFromAddresses = [];
let lastLoadedFromAddressEmails = [];

function renderEmailFromAddresses(payload) {
  if (!emailFromAddressesList) return;
  const envEntries = Array.isArray(payload?.envEntries) ? payload.envEntries : [];
  const customEntries = Array.isArray(payload?.customEntries) ? payload.customEntries : [];
  cachedCustomFromAddresses = customEntries;
  lastLoadedFromAddressEmails = [
    ...envEntries.map((entry) => String(entry?.email || "").trim()),
    ...customEntries.map((entry) => String(entry?.email || "").trim())
  ].filter(Boolean);

  if (!envEntries.length && !customEntries.length) {
    emailFromAddressesList.innerHTML = `<p class="hint">No email address yet. Add the address you send from.</p>`;
    return;
  }

  const envHtml = envEntries
    .map((entry) => {
      const email = String(entry?.email || "").trim();
      const label = String(entry?.label || "").trim();
      const display = label ? `${escapeHtmlText(label)}: ${escapeHtmlText(email)}` : escapeHtmlText(email);
      return `<div class="campaign-category-child-wrap">
        <div class="campaign-category-child">${display}</div>
        <div class="campaign-category-child-details is-active">
          <div class="campaign-card-actions campaign-category-inline-actions">
            <span class="hint" style="margin: 0">Already on this account. It cannot be removed here.</span>
          </div>
        </div>
      </div>`;
    })
    .join("");

  const customHtml = customEntries
    .map((entry) => {
      const id = Number(entry?.id || 0);
      const email = String(entry?.email || "").trim();
      const label = String(entry?.label || "").trim();
      const display = label ? `${escapeHtmlText(label)}: ${escapeHtmlText(email)}` : escapeHtmlText(email);
      const smtpHost = String(entry?.smtpHost || "").trim();
      const smtpStatus = smtpHost
        ? `<span class="hint" style="margin: 0">Mail server: ${escapeHtmlText(smtpHost)}</span>`
        : `<span class="hint" style="margin: 0">Email settings not added yet</span>`;
      return `<div class="campaign-category-child-wrap" data-email-from-id="${id}">
        <div class="campaign-category-child">${display}</div>
        <div class="campaign-category-child-details is-active">
          <div class="campaign-card-actions campaign-category-inline-actions">
            ${smtpStatus}
            <button type="button" class="email-from-smtp-btn" data-id="${id}">${smtpHost ? "Edit email settings" : "Email settings"}</button>
            <button type="button" class="email-from-label-btn" data-id="${id}" data-current-label="${escapeHtmlText(label)}">Add Label</button>
            <button type="button" class="danger email-from-remove-btn" data-id="${id}">Remove</button>
          </div>
          <div class="email-from-smtp-form-host" data-smtp-host-id="${id}" hidden></div>
        </div>
      </div>`;
    })
    .join("");

  emailFromAddressesList.innerHTML = `${envHtml}${customHtml}`;
}

function buildSmtpFormHtml(entry) {
  const id = Number(entry?.id || 0);
  const host = String(entry?.smtpHost || "").trim();
  const port = entry?.smtpPort != null ? String(entry.smtpPort) : "587";
  const secure = Boolean(entry?.smtpSecure);
  const user = String(entry?.smtpUser || "").trim();
  const replyTo = String(entry?.replyTo || "").trim();
  const hasPass = Boolean(entry?.hasSmtpPass);
  return `<form class="contact-modal-form email-from-smtp-form" data-smtp-form-id="${id}" autocomplete="off">
    <p class="hint" style="margin: 0 0 8px">
      Paste the app password for <strong>${escapeHtmlText(String(entry?.email || ""))}</strong>.
      Gmail is filled in. Open Different email provider only if this address is not Gmail.
    </p>
    <div class="contact-modal-grid">
      <div class="contact-field-box">
        <label class="contact-modal-field-label">App password</label>
        <input class="email-from-smtp-pass-input" type="password" placeholder="${hasPass ? "Leave blank to keep the current password" : "App password"}" autocomplete="new-password" />
        ${hasPass ? `<label class="settings-check-row document-attach" style="margin-top: 6px"><input type="checkbox" class="email-from-smtp-clear-pass" /><span>Clear stored password</span></label>` : ""}
      </div>
      <div class="contact-field-box">
        <label class="contact-modal-field-label">Reply email</label>
        <input class="email-from-smtp-reply-input" type="email" placeholder="reply-to@example.com" value="${escapeHtmlText(replyTo)}" />
      </div>
    </div>
    <details class="settings-advanced-details">
      <summary>Different email provider</summary>
      <div class="settings-advanced-body">
        <div class="contact-modal-grid">
          <div class="contact-field-box">
            <label class="contact-modal-field-label">Mail server</label>
            <input class="email-from-smtp-host-input" type="text" placeholder="smtp.gmail.com" value="${escapeHtmlText(host || "smtp.gmail.com")}" />
          </div>
          <div class="contact-field-box">
            <label class="contact-modal-field-label">Port</label>
            <input class="email-from-smtp-port-input" type="number" min="1" max="65535" placeholder="587" value="${escapeHtmlText(port || "587")}" />
          </div>
          <div class="contact-field-box">
            <label class="contact-modal-field-label">Email address</label>
            <input class="email-from-smtp-user-input" type="text" placeholder="you@gmail.com" value="${escapeHtmlText(user)}" />
          </div>
          <div class="contact-field-box">
            <label class="settings-check-row document-attach" style="margin-top: 22px">
              <input type="checkbox" class="email-from-smtp-secure-input" ${secure ? "checked" : ""} />
              <span>Use a secure port 465 connection. Leave this off for Gmail.</span>
            </label>
          </div>
        </div>
      </div>
    </details>
    <div class="contact-modal-actions">
      <button type="submit">Save email settings</button>
      <button type="button" class="email-from-smtp-cancel">Cancel</button>
      ${host ? `<button type="button" class="danger email-from-smtp-clear">Remove email server</button>` : ""}
    </div>
  </form>`;
}

function toggleSmtpFormForId(id, forceOpen) {
  const idNum = Number(id);
  if (!Number.isInteger(idNum) || idNum < 1) return;
  const host = emailFromAddressesList?.querySelector(`[data-smtp-host-id="${idNum}"]`);
  if (!host) return;
  const willOpen = forceOpen != null ? Boolean(forceOpen) : host.hidden;
  if (!willOpen) {
    host.hidden = true;
    host.innerHTML = "";
    return;
  }
  const entry = cachedCustomFromAddresses.find((e) => Number(e?.id) === idNum);
  if (!entry) return;
  host.innerHTML = buildSmtpFormHtml(entry);
  host.hidden = false;
  const firstInput = host.querySelector("input");
  if (firstInput && typeof firstInput.focus === "function") firstInput.focus();
}

async function loadEmailFromAddresses() {
  if (!emailFromAddressesList) return;
  try {
    const [optionsData, customData] = await Promise.all([
      fetchApiJson("/api/email/options").catch(() => null),
      fetchApiJson("/api/email/from-addresses").catch(() => [])
    ]);
    const allDetailed = Array.isArray(optionsData?.fromAddresses) ? optionsData.fromAddresses : [];
    const envEntries = allDetailed.filter(
      (entry) => entry?.source === "smtp_from" || entry?.source === "smtp_user"
    );
    const customEntries = Array.isArray(customData) ? customData : [];
    renderEmailFromAddresses({ envEntries, customEntries });
    const addresses = collectKnownFromAddressesForSignature();
    if (typeof window.prefillSignatureForAllFromAddresses === "function") {
      const prefilled = window.prefillSignatureForAllFromAddresses(addresses);
      if (prefilled && typeof window.persistEmailSignatureToServer === "function") {
        try {
          await window.persistEmailSignatureToServer(window.buildEmailSignaturePayloadFromLocal());
        } catch {
          /* non-fatal */
        }
      }
    }
  } catch (error) {
    renderEmailFromAddresses({ envEntries: [], customEntries: [] });
    showEmailFromAddressMessage(error.message || "Failed to load sender email addresses.", true);
  }
}

function showResetEmailOpenAlertsMessage(text, isError = false) {
  if (!resetEmailOpenAlertsMessage) return;
  resetEmailOpenAlertsMessage.textContent = text || "";
  resetEmailOpenAlertsMessage.style.color = isError ? "#b91c1c" : "#047857";
}

function showRuntimeConfigMessage(text, isError = false) {
  if (runtimeConfigMessage) {
    runtimeConfigMessage.textContent = text || "";
    runtimeConfigMessage.style.color = isError ? "#b91c1c" : "#047857";
  }
  const signInMessage = document.getElementById("signInMessage");
  if (signInMessage) {
    signInMessage.textContent = text || "";
    signInMessage.style.color = isError ? "#b91c1c" : "#047857";
  }
}

function showLogin2faMessage(text, isError = false) {
  if (!login2faMessage) return;
  login2faMessage.textContent = text || "";
  login2faMessage.style.color = isError ? "#b91c1c" : "#047857";
}

function setLogin2faPanelVisible(show) {
  if (!login2faSetupPanel) return;
  login2faSetupPanel.classList.toggle("hidden", !show);
  login2faSetupPanel.setAttribute("aria-hidden", show ? "false" : "true");
}

function setLogin2faBackupCodes(codes) {
  const rows = Array.isArray(codes) ? codes.map((c) => String(c || "").trim()).filter(Boolean) : [];
  if (login2faBackupCodes) login2faBackupCodes.textContent = rows.join("\n");
  if (login2faDownloadBackupCodesBtn) login2faDownloadBackupCodesBtn.disabled = rows.length === 0;
  if (login2faBackupCodesBox) {
    const show = rows.length > 0;
    login2faBackupCodesBox.classList.toggle("hidden", !show);
    login2faBackupCodesBox.setAttribute("aria-hidden", show ? "false" : "true");
  }
}

function downloadLogin2faBackupCodes() {
  const text = String(login2faBackupCodes?.textContent || "").trim();
  if (!text) {
    showLogin2faMessage("No backup codes to download yet.", true);
    return;
  }
  const lines = [
    "Cadence CRM 2FA Backup Codes",
    `Generated: ${new Date().toISOString()}`,
    "",
    text,
    "",
    "Each backup code can be used once.",
    "Store these in a secure place."
  ];
  const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  const date = new Date().toISOString().slice(0, 10).replace(/-/g, "");
  a.download = `cadence-2fa-backup-codes-${date}.txt`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  showLogin2faMessage("Backup codes downloaded.");
}

function setLogin2faStatusUi({ enabled, pendingSetup, hasBackupCodes }) {
  if (login2faStatusPill) {
    login2faStatusPill.textContent = enabled ? "2FA: On" : pendingSetup ? "2FA: Setup in progress" : "2FA: Off";
    login2faStatusPill.style.color = enabled ? "#047857" : pendingSetup ? "#b45309" : "#475569";
  }
  if (login2faStatusHint) {
    if (enabled && hasBackupCodes) {
      login2faStatusHint.textContent = "Two-factor is enabled. Keep backup codes somewhere safe.";
    } else if (enabled) {
      login2faStatusHint.textContent = "Two-factor is enabled. Generate/store backup codes before signing out.";
    } else if (pendingSetup) {
      login2faStatusHint.textContent = "Scan the QR and confirm a code to finish setup.";
    } else {
      login2faStatusHint.textContent = "Protect sign-in with a 6-digit authenticator app code.";
    }
  }
  if (login2faSetupBeginBtn) login2faSetupBeginBtn.disabled = enabled;
  if (login2faSetupCancelBtn) login2faSetupCancelBtn.classList.toggle("hidden", !pendingSetup);
}

async function loadLogin2faStatus() {
  if (!login2faStatusPill) return;
  try {
    const status = await fetchApiJson("/api/auth/2fa/status");
    setLogin2faStatusUi({
      enabled: Boolean(status?.enabled),
      pendingSetup: Boolean(status?.pendingSetup),
      hasBackupCodes: Boolean(status?.hasBackupCodes)
    });
    if (!status?.pendingSetup) setLogin2faPanelVisible(false);
  } catch (error) {
    showLogin2faMessage(error.message || "Failed to load 2FA status.", true);
  }
}

function sortTwilioNumbersForDisplay(rows) {
  if (window.CrmTwilioNumberSort && typeof window.CrmTwilioNumberSort.sortTwilioFromEntries === "function") {
    return window.CrmTwilioNumberSort.sortTwilioFromEntries(rows);
  }
  const lineOrder = { primary: 0, secondary: 1, third: 2, custom: 3 };
  return [...rows].sort((a, b) => {
    const da = String(a.number || "").replace(/\D/g, "") || "0";
    const db = String(b.number || "").replace(/\D/g, "") || "0";
    if (da.length !== db.length) return da.length - db.length;
    if (da < db) return -1;
    if (da > db) return 1;
    return (lineOrder[a.line] ?? 9) - (lineOrder[b.line] ?? 9);
  });
}

function renderTwilioNumbers(data) {
  if (!twilioNumbersList) return;
  const builtIn = [];
  const primary = String(data?.primary || "").trim();
  const secondary = String(data?.secondary || "").trim();
  const third = String(data?.third || "").trim();
  const builtinLabels = data?.builtinLabels || {};
  if (primary) builtIn.push({ line: "primary", number: primary, label: String(builtinLabels.primary || "").trim() });
  if (secondary) builtIn.push({ line: "secondary", number: secondary, label: String(builtinLabels.secondary || "").trim() });
  if (third) builtIn.push({ line: "third", number: third, label: String(builtinLabels.third || "").trim() });
  const items = Array.isArray(data?.custom) ? data.custom : [];
  const rows = [
    ...builtIn.map((row) => ({ kind: "builtin", ...row })),
    ...items
      .map((row) => ({
        kind: "custom",
        line: "custom",
        id: Number(row?.id || 0),
        number: String(row?.number || "").trim(),
        label: String(row?.label || "").trim()
      }))
      .filter((row) => row.number)
  ];

  if (!rows.length) {
    twilioNumbersList.innerHTML = `<p class="hint">No additional Twilio numbers added yet.</p>`;
    return;
  }

  twilioNumbersList.innerHTML = sortTwilioNumbersForDisplay(rows)
    .map((row) => {
      if (row.kind === "builtin") {
        return `<div class="campaign-category-child-wrap">
        <div class="campaign-category-child">${row.label ? `${row.label}: ` : ""}${row.number}</div>
        <div class="campaign-category-child-details is-active">
          <div class="campaign-card-actions campaign-category-inline-actions">
            <button type="button" class="twilio-number-label-btn" data-kind="builtin" data-line="${row.line}" data-current-label="${String(
              row.label || ""
            ).replace(/"/g, "&quot;")}">Add Label</button>
            <button type="button" class="danger twilio-number-remove-btn" data-kind="builtin" data-line="${row.line}">Remove</button>
          </div>
        </div>
      </div>`;
      }
      const display = row.label ? `${row.label}: ${row.number}` : row.number;
      return `<div class="campaign-category-child-wrap">
        <div class="campaign-category-child">${display}</div>
        <div class="campaign-category-child-details is-active">
          <div class="campaign-card-actions campaign-category-inline-actions">
            <button type="button" class="twilio-number-label-btn" data-kind="custom" data-id="${row.id}" data-current-label="${String(
              row.label || ""
            ).replace(/"/g, "&quot;")}">Add Label</button>
            <button type="button" class="danger twilio-number-remove-btn" data-kind="custom" data-id="${row.id}">Remove</button>
          </div>
        </div>
      </div>`;
    })
    .join("");
}

/** Block password managers from treating Twilio/API secrets as CRM login credentials. */
function guardNonLoginSecretInput(input) {
  if (!input) return;
  input.setAttribute("autocomplete", "off");
  input.setAttribute("data-lpignore", "true");
  input.setAttribute("data-1p-ignore", "true");
  input.setAttribute("data-bwignore", "true");
  input.setAttribute("data-form-type", "other");
  if (
    input === twilioAuthTokenInput ||
    input === twilioApiKeyInput ||
    input === twilioApiSecretInput
  ) {
    input.type = "text";
    input.dataset.crmSensitiveMask = "1";
    input.classList.add("crm-sensitive-masked");
  }
  input.readOnly = true;
  const unlock = () => {
    input.readOnly = false;
  };
  input.addEventListener("focus", unlock, { once: true });
  input.addEventListener("pointerdown", unlock, { once: true });
}

function guardTwilioCredentialFields() {
  guardNonLoginSecretInput(twilioAccountSidInput);
  guardNonLoginSecretInput(twilioAuthTokenInput);
  guardNonLoginSecretInput(twilioApiKeyInput);
  guardNonLoginSecretInput(twilioApiSecretInput);
}

async function applyOwnerExtraNumbers() {
  const box = document.getElementById("ownerExtraNumbersBox");
  if (!box) return;
  try {
    const res = await fetch("/api/auth/status", { credentials: "same-origin" });
    const status = res.ok ? await res.json() : null;
    const tenantId = Number(status?.workspace?.tenantId);
    const owner =
      Boolean(status?.authenticated) &&
      status?.workspace?.type !== "trial" &&
      !status?.subscription?.tenantId &&
      !(Number.isInteger(tenantId) && tenantId > 1);
    box.hidden = !owner;
    if (owner) await loadTwilioNumbers();
  } catch {
    box.hidden = true;
  }
}

async function loadTwilioNumbers() {
  if (!twilioNumbersList) return;
  try {
    const data = await fetchApiJson("/api/twilio/from-numbers");
    renderTwilioNumbers(data || {});
  } catch (error) {
    renderTwilioNumbers({});
    showTwilioNumberMessage(error.message || "Failed to load Twilio numbers.", true);
  }
}

function renderTwilioVoiceWebhookStatus(data) {
  if (!twilioVoiceWebhookStatus) return;
  if (!data?.browserCallReady) {
    const credErr = String(data?.voiceApiCredentialsError || "").trim();
    if (credErr) {
      twilioVoiceWebhookStatus.textContent = credErr;
      twilioVoiceWebhookStatus.style.color = "#c62828";
      return;
    }
    twilioVoiceWebhookStatus.textContent =
      "To use your computer or headset on calls, add API Key, API Secret, and Voice TwiML App SID above, then save.";
    twilioVoiceWebhookStatus.style.color = "#64748b";
    return;
  }
  if (data.crmPublicUrlPathWarning) {
    twilioVoiceWebhookStatus.textContent = String(data.crmPublicUrlPathWarning).trim();
    twilioVoiceWebhookStatus.style.color = "#c62828";
    return;
  }
  if (data.voiceWebhookReachable === false) {
    twilioVoiceWebhookStatus.textContent =
      String(data.voiceWebhookTestHint || "").trim() ||
      "Voice webhook is not reachable — headset calls will fail until CRM Public URL and Twilio Auth Token are correct.";
    twilioVoiceWebhookStatus.style.color = "#c62828";
    return;
  }
  if (data.voiceWebhookSynced) {
    twilioVoiceWebhookStatus.textContent =
      "Headset / computer calling is ready — this is how you hear and speak on CRM calls.";
    twilioVoiceWebhookStatus.style.color = "#1b5e20";
    return;
  }
  const expected = String(data.voiceWebhookUrl || "").trim();
  const actual = String(data.twimlAppVoiceUrl || "").trim();
  if (expected && actual && actual.replace(/\/$/, "") !== expected.replace(/\/$/, "")) {
    twilioVoiceWebhookStatus.textContent =
      `Twilio TwiML App voice URL is still ${actual} — it must be ${expected}. Click Save Twilio Credentials below.`;
    twilioVoiceWebhookStatus.style.color = "#c62828";
    return;
  }
  twilioVoiceWebhookStatus.textContent =
    "Almost ready — save Twilio credentials once more to finish headset setup.";
  twilioVoiceWebhookStatus.style.color = "#b45309";
}

async function loadTwilioVoiceWebhookStatus(options = {}) {
  if (!twilioVoiceWebhookStatus) return null;
  try {
    let data = await fetchApiJson("/api/twilio/voice-config");
    renderTwilioVoiceWebhookStatus(data);
    return data;
  } catch (error) {
    twilioVoiceWebhookStatus.textContent = error.message || "Could not load headset voice status.";
    twilioVoiceWebhookStatus.style.color = "#c62828";
    return null;
  }
}

async function loadTwilioConfig() {
  try {
    const data = await fetchApiJson("/api/twilio/config");
    if (twilioConfigForm) {
    if (twilioAccountSidInput) twilioAccountSidInput.value = String(data?.accountSid || "");
    if (twilioApiKeyInput) twilioApiKeyInput.value = String(data?.apiKey || "");
    if (twilioVoiceTwimlAppSidInput) twilioVoiceTwimlAppSidInput.value = String(data?.voiceTwimlAppSid || "");
    if (twilioVoiceIdentityInput) twilioVoiceIdentityInput.value = String(data?.voiceIdentity || "");
    if (twilioInboundForwardToInput) twilioInboundForwardToInput.value = String(data?.inboundForwardTo || "");
    if (twilioCallRecordingDefaultInput) {
      twilioCallRecordingDefaultInput.checked = Boolean(data?.callRecordingDefault);
    }
    /* Auth token + API secret are never returned in clear from the server
       (see SECURITY review #3). We show a masked preview as the placeholder
       and leave the input empty so the user can leave it blank to keep the
       existing value or type a new one to replace it. */
    if (twilioAuthTokenInput) {
      twilioAuthTokenInput.value = "";
      twilioAuthTokenInput.placeholder = data?.hasAuthToken
        ? `Stored: ${String(data?.authTokenMasked || "••••")} — leave blank to keep, type to replace`
        : "Twilio auth token";
      twilioAuthTokenInput.dataset.hasValue = data?.hasAuthToken ? "1" : "0";
    }
    if (twilioApiSecretInput) {
      twilioApiSecretInput.value = "";
      twilioApiSecretInput.placeholder = data?.hasApiSecret
        ? `Stored: ${String(data?.apiSecretMasked || "••••")} — leave blank to keep, type to replace`
        : "Twilio API key secret";
      twilioApiSecretInput.dataset.hasValue = data?.hasApiSecret ? "1" : "0";
    }
    guardTwilioCredentialFields();
    await loadTwilioVoiceWebhookStatus();
    }

    // Sync forward number top input
    const forwardTopEl = document.getElementById("twilioInboundForwardToInputTop");
    if (forwardTopEl) forwardTopEl.value = String(data?.inboundForwardTo || "");

    // Show provisioned phone number banner
    const bannerEl = document.getElementById("provisionedPhoneBanner");
    if (bannerEl) {
      if (data?.provisionedPhone) {
        const raw = String(data.provisionedPhone).replace(/\D/g, "");
        const digits = raw.startsWith("1") ? raw.slice(1) : raw;
        const formatted = digits.length === 10
          ? `(${digits.slice(0,3)}) ${digits.slice(3,6)}-${digits.slice(6)}`
          : data.provisionedPhone;
        bannerEl.innerHTML = `✅ Your business number: <span style="font-size:1.25rem;font-weight:800;letter-spacing:0.02em;">${formatted}</span>${data.residentState ? ` <span style="font-size:0.85rem;opacity:0.8;">(${data.residentState})</span>` : ""} — ready to use for SMS &amp; calls.`;
        bannerEl.style.display = "";
        bannerEl.style.background = "#d1fae5";
        bannerEl.style.borderColor = "#6ee7b7";
        bannerEl.style.color = "#065f46";
      } else {
        bannerEl.textContent = "📞 No business number assigned yet. Contact support@crmcadence.com to get your number set up.";
        bannerEl.style.display = "";
        bannerEl.style.background = "#fef9c3";
        bannerEl.style.borderColor = "#fde047";
        bannerEl.style.color = "#713f12";
      }
    }
  } catch (error) {
    showTwilioNumberMessage(error.message || "Failed to load Twilio config.", true);
  }
}

function normalizeCrmPublicUrlClient(raw) {
  let s = String(raw || "").trim();
  if (!s) return "";
  if (!/^https?:\/\//i.test(s)) s = `https://${s}`;
  return s.replace(/\/$/, "");
}

function plainPublicUrlHint(message) {
  const raw = String(message || "").trim();
  if (!raw) return "";
  const crossHost = raw.match(/will use ([^,]+), but you are signed in on ([^.]+)\./i);
  if (crossHost) {
    const configured = crossHost[1].trim();
    const here = crossHost[2].trim();
    return `You are signed in at ${here}. Change this to https://${here}.`;
  }
  if (/open-tracking|tracking pixel|public CRM URL/i.test(raw)) {
    return "Enter the website address for this site so email opens and calls work.";
  }
  if (/invalid/i.test(raw)) {
    return "Enter a full address, like https://crmcadence.com.";
  }
  return raw;
}

function renderCrmPublicUrlTrackingHint(message) {
  if (!crmPublicUrlTrackingHint) return;
  const text = plainPublicUrlHint(message);
  crmPublicUrlTrackingHint.textContent = text;
  crmPublicUrlTrackingHint.classList.toggle("hidden", !text);
}


async function applyTrialSignInNotice() {
  try {
    const res = await fetch("/api/auth/status", { credentials: "same-origin" });
    if (!res.ok) return;
    const status = await res.json();
    const extraNumbers = document.getElementById("ownerExtraNumbersBox");
    if (status?.workspace?.type !== "trial") return;
    window.__cadenceTrialWorkspace = true;
    if (extraNumbers) extraNumbers.hidden = true;
    document.querySelectorAll('a[data-section="anthropic"]').forEach((el) => {
      el.hidden = true;
    });
    const claudeSection = document.getElementById("anthropicSettingsSection");
    if (claudeSection) claudeSection.hidden = true;
    if (typeof renderApiCatalogGrid === "function") renderApiCatalogGrid();
    const block = document.querySelector("#runtimeConfigForm .settings-signin-block");
    if (block) block.hidden = true;
    const note = document.getElementById("trialPasswordNote");
    if (note) note.hidden = false;
    const lead = document.getElementById("ownerSignInLead");
    if (lead) lead.hidden = true;
  } catch {
    /* The sign-in form stays available if status cannot be read. */
  }
}

async function loadRuntimeConfig() {
  if (!runtimeConfigForm) return;
  await applyTrialSignInNotice();
  try {
    const data = await fetchApiJson("/api/runtime/config");
    const signedInHere = signedInSiteOrigin();
    if (crmPublicUrlInput) {
      crmPublicUrlInput.value = signedInHere || String(data?.crmPublicUrl || "");
      crmPublicUrlInput.readOnly = true;
    }
    renderCrmPublicUrlTrackingHint("");
    try {
      const hs = await fetchApiJson("/api/runtime/healthsherpa");
      if (healthSherpaUrlInput) {
        healthSherpaUrlInput.value = hs?.custom ? String(hs.url || "") : "";
        healthSherpaUrlInput.placeholder = String(hs?.url || "https://www.healthsherpa.com/sessions/new");
      }
    } catch {
      /* optional */
    }
    if (loginEmailInput) loginEmailInput.value = String(data?.loginEmail || "");
    if (loginPasswordInput) loginPasswordInput.value = "";
    if (loginPasswordConfirmInput) loginPasswordConfirmInput.value = "";
    if (loginPasswordConfiguredHint) {
      loginPasswordConfiguredHint.textContent = data?.hasLoginPassword
        ? "A login password is currently set — email plus password is required to sign in."
        : "";
    }
    setLogin2faStatusUi({
      enabled: Boolean(data?.login2faEnabled),
      pendingSetup: false,
      hasBackupCodes: false
    });
    if (socialExtraPlatformsInput) socialExtraPlatformsInput.value = String(data?.socialExtraPlatforms || "");
    const socialWebhooks = data && typeof data.socialWebhooks === "object" && data.socialWebhooks ? data.socialWebhooks : {};
    lastLoadedSocialWebhooks = { ...socialWebhooks };
    if (socialWebhookFacebookInput) socialWebhookFacebookInput.value = String(socialWebhooks.facebook || "");
    if (socialWebhookInstagramInput) socialWebhookInstagramInput.value = String(socialWebhooks.instagram || "");
    if (socialWebhookXInput) socialWebhookXInput.value = String(socialWebhooks.x || "");
    if (socialWebhookLinkedinInput) socialWebhookLinkedinInput.value = String(socialWebhooks.linkedin || "");
    renderExtraSocialWebhookInputs();
    if (socialWebhooksSaveStatus) socialWebhooksSaveStatus.textContent = "Saved ✓";
    await keepWebsiteAddressOnThisSite(data?.crmPublicUrl, String(data?.loginEmail || "").trim());
  } catch (error) {
    showRuntimeConfigMessage(error.message || "Could not load sign-in settings.", true);
  }
}

function signedInSiteOrigin() {
  if (window.location.protocol !== "https:") return "";
  if (/^(localhost|127\.0\.0\.1)$/i.test(window.location.hostname)) return "";
  return String(window.location.origin || "").replace(/\/$/, "");
}

let publicUrlAutoCorrected = false;

async function keepWebsiteAddressOnThisSite(storedUrl, loginEmail) {
  if (window.__cadenceTrialWorkspace) return;
  const here = signedInSiteOrigin();
  const email = String(loginEmail || "").trim();
  if (!here || !email || publicUrlAutoCorrected) return;
  const stored = String(storedUrl || "").replace(/\/$/, "");
  if (stored === here) return;
  publicUrlAutoCorrected = true;
  if (crmPublicUrlInput) crmPublicUrlInput.value = here;
  try {
    await fetchApiJson("/api/runtime/config", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        crmPublicUrl: here,
        loginEmail: email,
        clearLoginPassword: false,
        loginPassword: "",
        loginPasswordConfirm: "",
        socialExtraPlatforms: String(socialExtraPlatformsInput?.value || "").trim(),
        socialWebhooks: { ...lastLoadedSocialWebhooks }
      })
    });
  } catch {
    publicUrlAutoCorrected = false;
  }
}

async function loadBuildStampFooter() {
  if (!buildStampFooter) return;
  try {
    const data = await fetchApiJson("/api/runtime/build-stamp");
    const text = String(data?.buildStampText || "").trim();
    if (text) buildStampFooter.textContent = text;
  } catch {
    // Keep placeholder text if runtime build stamp is unavailable.
  }
}

const SETUP_STATUS_KEYS = [
  "smtp",
  "login",
  "crmPublicUrl",
  "anthropic",
  "openAiWhisper",
  "twilioSms",
  "twilioVoiceBrowser",
  "googleCalendar",
  "thanksIo"
];

const SETUP_STATUS_LINKS = {
  smtp:               "/settings.html?section=email-senders",
  login:              "/settings.html?section=general",
  crmPublicUrl:       "/settings.html?section=general",
  anthropic:          "/settings.html?section=anthropic",
  openAiWhisper:      "/settings.html?section=integrations",
  twilioSms:          "/settings.html?section=twilio",
  twilioVoiceBrowser: "/settings.html?section=twilio",
  googleCalendar:     "/settings.html?section=calendar",
  thanksIo:           "/settings.html?section=thanksio"
};

function checkSetupCelebration(data) {
  const STORAGE_KEY = "cadence_setup_celebrated";
  if (!data || localStorage.getItem(STORAGE_KEY)) return;
  const allOk = ["login", "smtp", "crmPublicUrl"].every((k) => String(data[k]?.level || "").toLowerCase() === "ok");
  if (!allOk) return;
  localStorage.setItem(STORAGE_KEY, "1");
  const toast = document.createElement("div");
  toast.style.cssText = "position:fixed;top:24px;left:50%;transform:translateX(-50%);z-index:9999;background:#d1fae5;border:1.5px solid #6ee7b7;border-radius:14px;padding:14px 28px;font-size:1rem;font-weight:700;color:#065f46;box-shadow:0 8px 32px rgba(6,95,70,0.15);display:flex;align-items:center;gap:10px;pointer-events:none;";
  toast.innerHTML = `<span style="font-size:1.4rem;">🎉</span> All systems go — Cadence CRM is fully set up!`;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 5000);
}

function setupStatusLevelClass(level) {
  const l = String(level || "").toLowerCase();
  if (l === "ok") return "settings-setup-level--ok";
  if (l === "warn" || l === "partial") return "settings-setup-level--warn";
  if (l === "error") return "settings-setup-level--error";
  return "settings-setup-level--off";
}

function setupStatusBadgeText(level) {
  const l = String(level || "").toLowerCase();
  if (l === "ok") return "OK";
  if (l === "partial") return "Partial";
  if (l === "warn") return "Attention";
  if (l === "error") return "Action needed";
  if (l === "off") return "Off";
  return "—";
}

let apiCatalogLastSetup = null;

const API_CATALOG_ITEMS = [
  {
    tabs: ["all"],
    keywords: "general login password public url tracking workspace sign in security",
    title: "Workspace & sign-in",
    desc: "CRM public URL, secure login email, password, and optional social webhook defaults.",
    href: "/settings.html?section=general",
    badges: [["Core", "core"]],
    icon: "🏢",
    statusMerge: "login,crmPublicUrl"
  },
  {
    tabs: ["all", "email"],
    keywords: "smtp sender from reply mail email nodemailer",
    title: "Email senders & SMTP",
    desc: "Global and per-address SMTP, From lines for campaigns and one-off email.",
    href: "/settings.html?section=email-senders",
    badges: [["Popular", "popular"]],
    icon: "✉️",
    statusKey: "smtp"
  },
  {
    tabs: ["all", "email"],
    keywords: "signature signoff footer rich text",
    title: "Email signature",
    desc: "Rich-text signature with links and images for outbound email.",
    href: "/settings.html?section=signature",
    badges: [],
    icon: "✍️",
    statusKey: null
  },
  {
    tabs: ["all", "email"],
    keywords: "merge fields tokens placeholders templates",
    title: "Merge Fields",
    desc: "Add, edit, and delete {{tokens}} for templates, drips, and the email composer.",
    href: "/settings.html?section=merge-fields",
    badges: [],
    icon: "{}",
    statusKey: null
  },
  {
    tabs: ["all", "messaging"],
    keywords: "twilio sms mms voice caller id phone numbers api",
    title: "Twilio (SMS & voice)",
    desc: "Your business number is already assigned. Forward calls to your cell if you want.",
    href: "/settings.html?section=twilio",
    badges: [["Popular", "popular"]],
    icon: "📞",
    statusKey: "twilioSms"
  },
  {
    tabs: ["all"],
    keywords: "anthropic claude ai assistant lead scoring api key",
    title: "Anthropic / Claude",
    desc: "Powers the AI Assistant, lead scoring, summaries, and recommendations.",
    href: "/settings.html?section=anthropic",
    badges: [["AI", "new"]],
    icon: "AI",
    statusKey: "anthropic"
  },
  {
    tabs: ["all"],
    keywords: "openai whisper transcription call recording voice api key",
    title: "OpenAI Whisper",
    desc: "Optional speech-to-text support for call recordings and voice workflows.",
    href: "/settings.html?section=twilio",
    badges: [["Voice", "core"]],
    icon: "STT",
    statusKey: "openAiWhisper"
  },
  {
    tabs: ["all", "calendar"],
    keywords: "google calendar oauth sync tasks meetings",
    title: "Google Calendar",
    desc: "Connect Google to sync tasks and meetings with Cadence.",
    href: "/settings.html?section=calendar",
    badges: [["New", "new"]],
    icon: "📅",
    statusKey: "googleCalendar"
  },
  {
    tabs: ["all", "mail"],
    keywords: "thanks.io thanksio postcard postcards handwritten direct mail thank you card",
    title: "Thanks.io",
    desc: "Handwritten postcards and direct mail. Save an API key, then open Thanks.io from a contact.",
    href: "/settings.html?section=thanksio",
    badges: [["New", "new"]],
    icon: "📮",
    statusKey: "thanksIo"
  },
  {
    tabs: ["all", "social"],
    keywords: "social marketing facebook instagram webhooks publish",
    title: "Social Marketing webhooks",
    desc: "Receive JSON when you publish from Social Marketing to external automations.",
    href: "/settings.html?section=social",
    badges: [],
    icon: "🔗",
    statusKey: null
  },
  {
    tabs: ["all", "social"],
    keywords: "reminders follow up push notifications email alerts",
    title: "Follow-up reminders",
    desc: "Email and browser push reminders for contacts with follow-up dates.",
    href: "/settings.html?section=reminders",
    badges: [],
    icon: "🔔",
    statusKey: null
  }
];

function apiCatalogRank(level) {
  const l = String(level || "").toLowerCase();
  if (l === "error") return 3;
  if (l === "warn" || l === "partial") return 2;
  if (l === "off") return 1;
  if (l === "ok") return 0;
  return 1;
}

function apiCatalogStatusClassFromRank(r) {
  if (r >= 3) return "settings-api-catalog-status--error";
  if (r >= 2) return "settings-api-catalog-status--warn";
  if (r >= 1) return "settings-api-catalog-status--off";
  return "settings-api-catalog-status--ok";
}

function apiCatalogLabelFromRank(r) {
  if (r >= 3) return "Action needed";
  if (r >= 2) return "Needs attention";
  if (r >= 1) return "Optional";
  return "Ready";
}

function renderApiCatalogBadges(badges) {
  if (!Array.isArray(badges) || !badges.length) return "";
  return badges
    .map(([text, variant]) => {
      const v = String(variant || "core").toLowerCase();
      const cls =
        v === "popular" ? "settings-api-catalog-badge--popular" : v === "new" ? "settings-api-catalog-badge--new" : "settings-api-catalog-badge--core";
      return `<span class="settings-api-catalog-badge ${cls}">${escapeHtmlText(text)}</span>`;
    })
    .join("");
}

function resetApiCatalogToAllTab() {
  const tabsRoot = document.getElementById("apiCatalogTabs");
  if (tabsRoot) {
    tabsRoot.querySelectorAll(".settings-api-catalog-tab[data-api-tab]").forEach((b) => {
      const isAll = b.getAttribute("data-api-tab") === "all";
      b.classList.toggle("is-active", isAll);
      b.setAttribute("aria-selected", isAll ? "true" : "false");
    });
  }
  const search = document.getElementById("apiCatalogSearchInput");
  if (search) search.value = "";
}

function renderApiCatalogGrid() {
  const grid = document.getElementById("apiCatalogGrid");
  const empty = document.getElementById("apiCatalogEmpty");
  const tabsRoot = document.getElementById("apiCatalogTabs");
  const tabBtn = tabsRoot?.querySelector(".settings-api-catalog-tab.is-active");
  let tab = String(tabBtn?.getAttribute("data-api-tab") || "all").toLowerCase();
  if (!["all", "email", "messaging", "calendar", "mail", "social"].includes(tab)) tab = "all";
  const q = String(document.getElementById("apiCatalogSearchInput")?.value || "")
    .trim()
    .toLowerCase();
  if (!grid) return;
  const rows = API_CATALOG_ITEMS.filter((item) => {
    if (window.__cadenceTrialWorkspace && item.statusKey === "anthropic") return false;
    const inTab = tab === "all" || item.tabs.includes(tab);
    if (!inTab) return false;
    if (!q) return true;
    const blob = `${item.title} ${item.desc} ${item.keywords}`.toLowerCase();
    return blob.includes(q);
  });
  if (empty) empty.hidden = rows.length > 0;
  grid.innerHTML = rows
    .map((item) => {
      const badges = renderApiCatalogBadges(item.badges);
      let statusAttrs = "";
      if (item.statusMerge) {
        statusAttrs = ` data-api-status-merge="${escapeAttr(item.statusMerge)}"`;
      } else if (item.statusKey) {
        statusAttrs = ` data-api-status-key="${escapeAttr(item.statusKey)}"`;
      }
      const statusHtml = item.statusKey || item.statusMerge
        ? `<span class="settings-api-catalog-status settings-api-catalog-status--off"${statusAttrs}>—</span>`
        : `<span class="settings-api-catalog-status settings-api-catalog-status--off">—</span>`;
      return `<article class="settings-api-catalog-card">
        <div class="settings-api-catalog-card-inner">
          <div class="settings-api-catalog-card-copy">
            <div class="settings-api-catalog-card-badges">${badges}</div>
            <h3 class="settings-api-catalog-card-title">${escapeHtmlText(item.title)}</h3>
            <p class="settings-api-catalog-card-desc">${escapeHtmlText(item.desc)}</p>
          </div>
          <div class="settings-api-catalog-card-visual" aria-hidden="true">${item.icon}</div>
        </div>
        <div class="settings-api-catalog-card-footer">
          ${statusHtml}
          <a class="settings-api-catalog-connect" href="${escapeAttr(item.href)}">Configure</a>
        </div>
      </article>`;
    })
    .join("");
  updateApiIntegrationStatuses(apiCatalogLastSetup);
}

function updateApiIntegrationStatuses(data) {
  if (!data) return;
  document.querySelectorAll("[data-api-status-key]").forEach((el) => {
    const key = el.getAttribute("data-api-status-key");
    const row = key ? data[key] : null;
    if (!row || !row.level) {
      el.textContent = "—";
      el.className = "settings-api-catalog-status settings-api-catalog-status--off";
      el.removeAttribute("title");
      return;
    }
    const r = apiCatalogRank(row.level);
    el.textContent = setupStatusBadgeText(row.level);
    el.className = `settings-api-catalog-status ${apiCatalogStatusClassFromRank(r)}`;
    el.title = String(row.detail || "").trim() || el.textContent;
  });
  document.querySelectorAll("[data-api-status-merge]").forEach((el) => {
    const raw = el.getAttribute("data-api-status-merge") || "";
    const keys = raw.split(",").map((s) => s.trim()).filter(Boolean);
    let worst = 0;
    const details = [];
    for (const k of keys) {
      const row = data[k];
      if (!row) continue;
      worst = Math.max(worst, apiCatalogRank(row.level));
      if (row.detail) details.push(row.detail);
    }
    el.textContent = apiCatalogLabelFromRank(worst);
    el.className = `settings-api-catalog-status ${apiCatalogStatusClassFromRank(worst)}`;
    el.title = details.join(" · ") || el.textContent;
  });
}

function wireApiIntegrationsCatalog() {
  const grid = document.getElementById("apiCatalogGrid");
  const tabsRoot = document.getElementById("apiCatalogTabs");
  if (!grid || !tabsRoot) return;
  resetApiCatalogToAllTab();
  tabsRoot.querySelectorAll(".settings-api-catalog-tab[data-api-tab]").forEach((btn) => {
    btn.addEventListener("click", () => {
      tabsRoot.querySelectorAll(".settings-api-catalog-tab[data-api-tab]").forEach((b) => {
        b.classList.toggle("is-active", b === btn);
        b.setAttribute("aria-selected", b === btn ? "true" : "false");
      });
      renderApiCatalogGrid();
    });
  });
  const search = document.getElementById("apiCatalogSearchInput");
  if (search) {
    search.addEventListener("input", () => {
      window.clearTimeout(search._apiCatT);
      search._apiCatT = window.setTimeout(() => renderApiCatalogGrid(), 120);
    });
  }
  renderApiCatalogGrid();
}

const FIRST_RUN_STATUS_KEYS = ["login", "smtp", "crmPublicUrl", "twilioSms", "googleCalendar"];

function agentFacingSetupRow(key, row) {
  const level = String(row?.level || "").toLowerCase();
  if (key === "login") {
    return {
      label: "Sign-in",
      detail: level === "ok" ? "Email and password are set." : "Set the email and password you use to sign in.",
      level
    };
  }
  if (key === "smtp") {
    return {
      label: "Send email",
      detail: level === "ok" ? "Cadence can send email." : "Add the Gmail or email address you send from.",
      level
    };
  }
  if (key === "crmPublicUrl") {
    return {
      label: "Website address",
      detail: "This is the site you are signed in on.",
      level: level === "error" ? "error" : "ok"
    };
  }
  if (key === "twilioSms") {
    return {
      label: "Phone number",
      detail: level === "error"
        ? "If texts are not sending, email support@crmcadence.com."
        : "Your business number is already on this account.",
      level: level === "error" ? "error" : "ok"
    };
  }
  if (key === "googleCalendar") {
    if (level === "ok") return { label: "Google Calendar", detail: "Connected.", level: "ok" };
    return {
      label: "Google Calendar",
      detail: "Optional. Connect later if you want tasks on your calendar.",
      level: "off",
      badge: "Optional"
    };
  }
  return { label: row?.label || key, detail: row?.detail || "", level };
}

async function loadSetupStatus() {
  const grid = document.getElementById("setupStatusGrid");
  const errEl = document.getElementById("setupStatusFetchError");
  const updatedEl = document.getElementById("setupStatusUpdated");
  if (errEl) {
    errEl.hidden = true;
    errEl.textContent = "";
  }
  if (updatedEl) updatedEl.textContent = "Loading…";
  try {
    const data = await fetchSetupStatusPayload();
    if (grid) {
      grid.innerHTML = FIRST_RUN_STATUS_KEYS.map((key) => {
        const row = data && data[key];
        if (!row) return "";
        const shown = agentFacingSetupRow(key, row);
        const level = shown.level || row.level;
        const lvl = setupStatusLevelClass(level);
        const badge = shown.badge || setupStatusBadgeText(level);
        const aria = `${String(shown.label || key)}: ${badge}`;
        const href = SETUP_STATUS_LINKS[key] || "#";
        return `<a href="${escapeAttr(href)}" class="settings-setup-status-card ${lvl} settings-setup-status-card--link" role="status" aria-label="${escapeAttr(aria)}" title="Go to ${escapeAttr(shown.label || key)}">
        <span class="settings-setup-dot ${lvl}" aria-hidden="true"></span>
        <div class="settings-setup-status-card-body">
          <div class="settings-setup-status-card-top">
            <span class="settings-setup-name">${escapeHtmlText(shown.label || key)}</span>
            <span class="settings-setup-badge ${lvl}">${escapeHtmlText(badge)}</span>
          </div>
          <p class="settings-setup-detail">${escapeHtmlText(shown.detail || "")}</p>
        </div>
      </a>`;
      }).join("");
    }
    if (updatedEl) {
      updatedEl.textContent = `Updated ${new Date().toLocaleString()}`;
    }
    apiCatalogLastSetup = data;
    updateApiIntegrationStatuses(data);
    checkSetupCelebration(data);
  } catch (e) {
    if (/session expired due to inactivity/i.test(String(e?.message || ""))) return;
    if (grid) grid.innerHTML = "";
    if (errEl) {
      errEl.hidden = false;
      errEl.textContent = e.message || "Could not load setup status.";
    }
    if (updatedEl) updatedEl.textContent = "";
  }
}

document.getElementById("setupStatusRefreshBtn")?.addEventListener("click", () => {
  loadSetupStatus();
});

if (settingsBackBtn) {
  settingsBackBtn.addEventListener("click", () => {
    window.location.href = "/index.html";
  });
}

if (emailSignatureForm) {
  emailSignatureForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      const defaultBlock = {
        text: getSignatureEditorText(),
        html: getSignatureEditorHtml(),
        linkText: String(emailSignatureLinkText?.value || ""),
        linkUrl: String(emailSignatureLinkUrl?.value || ""),
        imageUrl: String(emailSignatureImageUrl?.value || "")
      };
      const include = Boolean(emailIncludeSignature?.checked);
      const fromAddresses = collectKnownFromAddressesForSignature();
      try {
        window.localStorage.setItem(EMAIL_INCLUDE_SIGNATURE_KEY, include ? "1" : "0");
      } catch {
        //
      }
      if (typeof window.syncByFromWithDefaultForAddresses === "function" && fromAddresses.length) {
        window.syncByFromWithDefaultForAddresses(fromAddresses, defaultBlock);
      } else {
        window.localStorage.setItem(EMAIL_SIGNATURE_KEY, JSON.stringify(defaultBlock));
      }
      if (typeof window.persistEmailSignatureToServer === "function") {
        const payload =
          typeof window.buildEmailSignaturePayloadFromLocal === "function"
            ? window.buildEmailSignaturePayloadFromLocal(include)
            : { settings: defaultBlock, include };
        await window.persistEmailSignatureToServer(payload);
      }
      setSignatureSaveFeedback("Signature Saved");
      showSignatureMessage("Saved to your account. Send Email will use this signature on any device.");
    } catch (error) {
      setSignatureSaveFeedback("Failed to save signature.", true);
      showSignatureMessage((error && error.message) || "Failed to save signature.", true);
    }
  });
}

const signatureBoldBtn = document.getElementById("signatureBoldBtn");
const signatureItalicBtn = document.getElementById("signatureItalicBtn");
const signatureUnderlineBtn = document.getElementById("signatureUnderlineBtn");
const signatureAlignLeftBtn = document.getElementById("signatureAlignLeftBtn");
const signatureAlignCenterBtn = document.getElementById("signatureAlignCenterBtn");
const signatureAlignRightBtn = document.getElementById("signatureAlignRightBtn");
const signatureIndentBtn = document.getElementById("signatureIndentBtn");
const signatureOutdentBtn = document.getElementById("signatureOutdentBtn");
const signatureLinkBtn = document.getElementById("signatureLinkBtn");
const signatureInsertPhotoBtn = document.getElementById("signatureInsertPhotoBtn");
const signatureInsertGraphicUrlBtn = document.getElementById("signatureInsertGraphicUrlBtn");
const signatureInlineColor = document.getElementById("signatureInlineColor");
const signatureInlineFontSize = document.getElementById("signatureInlineFontSize");
const signatureClearFormatBtn = document.getElementById("signatureClearFormatBtn");
const signatureAddImageUrlBtn = document.getElementById("signatureAddImageUrlBtn");

if (signatureBoldBtn) signatureBoldBtn.addEventListener("click", () => execEditorCommand("bold"));
if (signatureItalicBtn) signatureItalicBtn.addEventListener("click", () => execEditorCommand("italic"));
if (signatureUnderlineBtn) signatureUnderlineBtn.addEventListener("click", () => execEditorCommand("underline"));
if (signatureAlignLeftBtn) signatureAlignLeftBtn.addEventListener("click", () => execEditorCommand("justifyLeft"));
if (signatureAlignCenterBtn) signatureAlignCenterBtn.addEventListener("click", () => execEditorCommand("justifyCenter"));
if (signatureAlignRightBtn) signatureAlignRightBtn.addEventListener("click", () => execEditorCommand("justifyRight"));
if (signatureIndentBtn) signatureIndentBtn.addEventListener("click", () => execEditorCommand("indent"));
if (signatureOutdentBtn) signatureOutdentBtn.addEventListener("click", () => execEditorCommand("outdent"));

if (signatureLinkBtn) {
  signatureLinkBtn.addEventListener("click", () => {
    const href = window.prompt("Enter link URL:", "https://");
    if (!href || !href.trim()) return;
    execEditorCommand("createLink", href.trim());
  });
}

if (signatureMergeFieldSelect) {
  signatureMergeFieldSelect.addEventListener("change", () => {
    const token = String(signatureMergeFieldSelect.value || "").trim();
    if (!token) return;
    insertSignatureMergeToken(token);
    signatureMergeFieldSelect.value = "";
  });
  refreshSignatureMergeFieldDropdown();
}

if (signatureInlineColor) {
  signatureInlineColor.addEventListener("change", () => {
    execEditorCommand("foreColor", signatureInlineColor.value || "#1f2937");
  });
}

if (signatureInlineFontSize) {
  signatureInlineFontSize.addEventListener("change", () => {
    const size = Number(signatureInlineFontSize.value || 0);
    if (!Number.isFinite(size) || size < 8 || size > 72 || !emailSignatureEditor) return;
    emailSignatureEditor.focus();
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) return;
    const range = selection.getRangeAt(0);
    if (selection.isCollapsed) return;
    const span = document.createElement("span");
    span.style.fontSize = `${Math.round(size)}px`;
    try {
      range.surroundContents(span);
    } catch {
      const text = range.toString();
      range.deleteContents();
      span.textContent = text;
      range.insertNode(span);
    }
  });
}

if (signatureClearFormatBtn) {
  signatureClearFormatBtn.addEventListener("click", () => execEditorCommand("removeFormat"));
}

function insertImageIntoEditor(src) {
  const safeSrc = String(src || "").trim();
  if (!safeSrc) return;
  execEditorCommand("insertImage", safeSrc);
}

if (signatureAddImageUrlBtn) {
  signatureAddImageUrlBtn.addEventListener("click", () => {
    const url = String(emailSignatureImageUrl?.value || "").trim();
    if (!url) {
      showSignatureMessage("Enter an image URL first.", true);
      return;
    }
    insertImageIntoEditor(url);
    showSignatureMessage("Image added.");
  });
}

if (signatureInsertGraphicUrlBtn) {
  signatureInsertGraphicUrlBtn.addEventListener("click", () => {
    const current = String(emailSignatureImageUrl?.value || "").trim() || "https://";
    const url = String(window.prompt("Enter image URL:", current) || "").trim();
    if (!url || url === "https://") return;
    if (emailSignatureImageUrl) emailSignatureImageUrl.value = url;
    insertImageIntoEditor(url);
    showSignatureMessage("Image added.");
  });
}

if (signatureInsertPhotoBtn && emailSignatureImageFile) {
  signatureInsertPhotoBtn.addEventListener("click", () => emailSignatureImageFile.click());
}

if (emailSignatureImageFile) {
  emailSignatureImageFile.addEventListener("change", async () => {
    const file = emailSignatureImageFile.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ""));
        reader.onerror = () => reject(new Error(`Failed to read ${file.name}`));
        reader.readAsDataURL(file);
      });
      insertImageIntoEditor(dataUrl);
      showSignatureMessage("Photo added.");
    } catch (error) {
      showSignatureMessage(error.message || "Failed to add photo.", true);
    }
  });
}

if (twilioNumberForm) {
  twilioNumberForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      const number = String(twilioNumberInput?.value || "").trim();
      const label = String(twilioNumberLabelInput?.value || "").trim();
      await fetchApiJson("/api/twilio/custom-from-numbers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ number, label })
      });
      if (twilioNumberInput) twilioNumberInput.value = "";
      if (twilioNumberLabelInput) twilioNumberLabelInput.value = "";
      showTwilioNumberMessage("Twilio number added.");
      await loadTwilioNumbers();
    } catch (error) {
      showTwilioNumberMessage(error.message || "Failed to add number.", true);
    }
  });
}

if (twilioConfigForm) {
  twilioConfigForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      const accountSid = String(twilioAccountSidInput?.value || "").trim();
      const apiKey = String(twilioApiKeyInput?.value || "").trim();
      const voiceTwimlAppSid = String(twilioVoiceTwimlAppSidInput?.value || "").trim();
      const voiceIdentity = String(twilioVoiceIdentityInput?.value || "").trim();
      const inboundForwardTo = String(twilioInboundForwardToInput?.value || "").trim();
      /* For secrets: empty input = "keep existing value" (the server treats
         an empty/missing field as a no-op). Anything else replaces. */
      const authTokenTyped = String(twilioAuthTokenInput?.value || "");
      const apiSecretTyped = String(twilioApiSecretInput?.value || "");
      const payload = {
        accountSid,
        apiKey,
        voiceTwimlAppSid,
        voiceIdentity,
        inboundForwardTo,
        callRecordingDefault: twilioCallRecordingDefaultInput?.checked === true
      };
      if (authTokenTyped.trim()) payload.authToken = authTokenTyped.trim();
      if (apiSecretTyped.trim()) payload.apiSecret = apiSecretTyped.trim();
      const data = await fetchApiJson("/api/twilio/config", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      /* Reset inputs and refresh masked previews from the response. */
      if (twilioAuthTokenInput) {
        twilioAuthTokenInput.value = "";
        twilioAuthTokenInput.placeholder = data?.hasAuthToken
          ? `Stored: ${String(data?.authTokenMasked || "••••")} — leave blank to keep, type to replace`
          : "Twilio auth token";
      }
      if (twilioApiSecretInput) {
        twilioApiSecretInput.value = "";
        twilioApiSecretInput.placeholder = data?.hasApiSecret
          ? `Stored: ${String(data?.apiSecretMasked || "••••")} — leave blank to keep, type to replace`
          : "Twilio API key secret";
      }
      if (data?.voiceWebhookTest && data.voiceWebhookTest.ok === false) {
        showTwilioNumberMessage(
          data.voiceWebhookTest.hint || "Twilio saved, but voice webhook test failed — headset calls may error 31005.",
          true
        );
      } else {
        showTwilioNumberMessage("Twilio credentials saved.");
      }
      await loadTwilioVoiceWebhookStatus();
      await loadSetupStatus();
    } catch (error) {
      showTwilioNumberMessage(error.message || "Failed to save Twilio config.", true);
    }
  });
}

if (twilioNumbersList) {
  twilioNumbersList.addEventListener("click", async (event) => {
    const target = event.target instanceof Element ? event.target : null;
    if (!target) return;
    const labelBtn = target.closest(".twilio-number-label-btn");
    if (labelBtn) {
      try {
        const kind = String(labelBtn.getAttribute("data-kind") || "").trim().toLowerCase();
        const currentLabel = String(labelBtn.getAttribute("data-current-label") || "").trim();
        const nextLabel = String(window.prompt("Enter label for this Twilio number:", currentLabel) || "").trim();
        if (kind === "builtin") {
          const line = String(labelBtn.getAttribute("data-line") || "").trim().toLowerCase();
          if (!line) return;
          await fetchApiJson(`/api/twilio/builtin-from-numbers/${encodeURIComponent(line)}/label`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ label: nextLabel })
          });
        } else {
          const id = Number(labelBtn.getAttribute("data-id"));
          if (!Number.isInteger(id) || id < 1) return;
          await fetchApiJson(`/api/twilio/custom-from-numbers/${encodeURIComponent(String(id))}/label`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ label: nextLabel })
          });
        }
        showTwilioNumberMessage("Twilio label saved.");
        await loadTwilioNumbers();
      } catch (error) {
        showTwilioNumberMessage(error.message || "Failed to save label.", true);
      }
      return;
    }
    const btn = target.closest(".twilio-number-remove-btn");
    if (!btn) return;
    try {
      const kind = String(btn.getAttribute("data-kind") || "").trim().toLowerCase();
      if (kind === "builtin") {
        const line = String(btn.getAttribute("data-line") || "").trim().toLowerCase();
        if (!line) return;
        await fetchApiJson(`/api/twilio/builtin-from-numbers/${encodeURIComponent(line)}`, { method: "DELETE" });
        showTwilioNumberMessage("Twilio number removed.");
      } else {
        const id = Number(btn.getAttribute("data-id"));
        if (!Number.isInteger(id) || id < 1) return;
        await fetchApiJson(`/api/twilio/custom-from-numbers/${encodeURIComponent(String(id))}`, { method: "DELETE" });
        showTwilioNumberMessage("Twilio number removed.");
      }
      await loadTwilioNumbers();
    } catch (error) {
      showTwilioNumberMessage(error.message || "Failed to remove number.", true);
    }
  });
}

if (emailFromAddressForm) {
  emailFromAddressForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      const email = String(emailFromAddressInput?.value || "").trim();
      const label = String(emailFromLabelInput?.value || "").trim();
      if (!email) {
        showEmailFromAddressMessage("Email address is required.", true);
        return;
      }
      await fetchApiJson("/api/email/from-addresses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, label })
      });
      if (emailFromAddressInput) emailFromAddressInput.value = "";
      if (emailFromLabelInput) emailFromLabelInput.value = "";
      showEmailFromAddressMessage("Email address added.");
      await loadEmailFromAddresses();
    } catch (error) {
      showEmailFromAddressMessage(error.message || "Failed to add email address.", true);
    }
  });
}

async function saveSmtpForId(formEl) {
  const id = Number(formEl.getAttribute("data-smtp-form-id"));
  if (!Number.isInteger(id) || id < 1) return;
  const smtpHost = String(formEl.querySelector(".email-from-smtp-host-input")?.value || "").trim();
  const smtpPortRaw = String(formEl.querySelector(".email-from-smtp-port-input")?.value || "").trim();
  const smtpUser = String(formEl.querySelector(".email-from-smtp-user-input")?.value || "").trim();
  const smtpPassRaw = String(formEl.querySelector(".email-from-smtp-pass-input")?.value || "");
  const replyTo = String(formEl.querySelector(".email-from-smtp-reply-input")?.value || "").trim();
  const smtpSecure = Boolean(formEl.querySelector(".email-from-smtp-secure-input")?.checked);
  const clearPassword = Boolean(formEl.querySelector(".email-from-smtp-clear-pass")?.checked);
  const payload = {
    smtpHost,
    smtpPort: smtpPortRaw === "" ? null : Number(smtpPortRaw),
    smtpUser,
    smtpSecure,
    replyTo
  };
  if (clearPassword) payload.clearPassword = true;
  else if (smtpPassRaw) payload.smtpPass = smtpPassRaw;
  await fetchApiJson(`/api/email/from-addresses/${encodeURIComponent(String(id))}/smtp`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  showEmailFromAddressMessage("SMTP settings saved.");
  await loadEmailFromAddresses();
}

async function clearSmtpForId(id) {
  const idNum = Number(id);
  if (!Number.isInteger(idNum) || idNum < 1) return;
  const ok = window.confirm("Remove the SMTP server settings for this address? It will fall back to the global SMTP.");
  if (!ok) return;
  await fetchApiJson(`/api/email/from-addresses/${encodeURIComponent(String(idNum))}/smtp`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      smtpHost: "",
      smtpPort: null,
      smtpUser: "",
      smtpSecure: false,
      replyTo: "",
      clearPassword: true
    })
  });
  showEmailFromAddressMessage("SMTP settings removed.");
  await loadEmailFromAddresses();
}

if (emailFromAddressesList) {
  emailFromAddressesList.addEventListener("click", async (event) => {
    const target = event.target instanceof Element ? event.target : null;
    if (!target) return;
    const smtpBtn = target.closest(".email-from-smtp-btn");
    if (smtpBtn) {
      const id = Number(smtpBtn.getAttribute("data-id"));
      toggleSmtpFormForId(id);
      return;
    }
    const cancelSmtpBtn = target.closest(".email-from-smtp-cancel");
    if (cancelSmtpBtn) {
      const form = cancelSmtpBtn.closest("[data-smtp-form-id]");
      const id = form ? Number(form.getAttribute("data-smtp-form-id")) : 0;
      toggleSmtpFormForId(id, false);
      return;
    }
    const clearSmtpBtn = target.closest(".email-from-smtp-clear");
    if (clearSmtpBtn) {
      try {
        const form = clearSmtpBtn.closest("[data-smtp-form-id]");
        const id = form ? Number(form.getAttribute("data-smtp-form-id")) : 0;
        await clearSmtpForId(id);
      } catch (error) {
        showEmailFromAddressMessage(error.message || "Failed to remove SMTP settings.", true);
      }
      return;
    }
    const labelBtn = target.closest(".email-from-label-btn");
    if (labelBtn) {
      try {
        const id = Number(labelBtn.getAttribute("data-id"));
        if (!Number.isInteger(id) || id < 1) return;
        const currentLabel = String(labelBtn.getAttribute("data-current-label") || "").trim();
        const nextLabel = String(window.prompt("Enter a label for this email address:", currentLabel) || "").trim();
        await fetchApiJson(`/api/email/from-addresses/${encodeURIComponent(String(id))}/label`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ label: nextLabel })
        });
        showEmailFromAddressMessage("Email address label saved.");
        await loadEmailFromAddresses();
      } catch (error) {
        showEmailFromAddressMessage(error.message || "Failed to save label.", true);
      }
      return;
    }
    const removeBtn = target.closest(".email-from-remove-btn");
    if (!removeBtn) return;
    try {
      const id = Number(removeBtn.getAttribute("data-id"));
      if (!Number.isInteger(id) || id < 1) return;
      const ok = window.confirm("Remove this email sender address? Existing campaigns using it will fall back to the campaign default.");
      if (!ok) return;
      await fetchApiJson(`/api/email/from-addresses/${encodeURIComponent(String(id))}`, { method: "DELETE" });
      showEmailFromAddressMessage("Email address removed.");
      await loadEmailFromAddresses();
    } catch (error) {
      showEmailFromAddressMessage(error.message || "Failed to remove email address.", true);
    }
  });

  emailFromAddressesList.addEventListener("submit", async (event) => {
    const form = event.target instanceof Element ? event.target.closest(".email-from-smtp-form") : null;
    if (!form) return;
    event.preventDefault();
    try {
      await saveSmtpForId(form);
    } catch (error) {
      showEmailFromAddressMessage(error.message || "Failed to save SMTP settings.", true);
    }
  });
}

if (resetEmailOpenAlertsBtn) {
  resetEmailOpenAlertsBtn.addEventListener("click", () => {
    if (typeof window.crmResetEmailOpenAlertsCursor === "function") {
      window.crmResetEmailOpenAlertsCursor();
      showResetEmailOpenAlertsMessage(
        "Open-email alert cursor reset. You can be notified again for opens in the last 5 minutes."
      );
      return;
    }
    showResetEmailOpenAlertsMessage("Open-email notifier is not loaded on this page yet. Refresh and try again.", true);
  });
}

if (socialExtraPlatformsInput) {
  socialExtraPlatformsInput.addEventListener("input", () => {
    renderExtraSocialWebhookInputs();
  });
}

function setWebhookStatus(inputId, text, status = "neutral") {
  const el = document.querySelector(`[data-webhook-status-for="${CSS.escape(String(inputId || ""))}"]`);
  if (!el) return;
  el.textContent = text || "";
  el.classList.toggle("settings-webhook-status--ok", status === "ok");
  el.classList.toggle("settings-webhook-status--error", status === "error");
  el.classList.toggle("settings-webhook-status--pending", status === "pending");
}

async function testSocialWebhook(inputId, button) {
  const input = inputId ? document.getElementById(inputId) : null;
  const url = String(input?.value || "").trim();
  if (!input || !url) {
    setWebhookStatus(inputId, "Add a URL first", "error");
    return;
  }
  if (!/^https?:\/\/[^\s]+$/i.test(url)) {
    setWebhookStatus(inputId, "Failed - enter a full URL", "error");
    return;
  }
  const target = String(input.getAttribute("data-social-target") || inputId || "webhook").trim();
  setWebhookStatus(inputId, "Testing...", "pending");
  if (button) button.disabled = true;
  try {
    await fetchApiJson("/api/runtime/social-webhooks/test", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ target, url })
    });
    setWebhookStatus(inputId, "Connected", "ok");
  } catch (error) {
    setWebhookStatus(inputId, "Failed", "error");
  } finally {
    if (button) button.disabled = false;
  }
}

document.addEventListener("click", (event) => {
  const btn = event.target?.closest?.(".settings-webhook-test-btn");
  if (!btn) return;
  event.preventDefault();
  testSocialWebhook(btn.getAttribute("data-webhook-input"), btn);
});

document.addEventListener("input", (event) => {
  const input = event.target?.closest?.("input[data-social-target]");
  if (!input) return;
  setWebhookStatus(input.id, "Untested", "neutral");
  if (socialWebhooksSaveStatus) socialWebhooksSaveStatus.textContent = "Unsaved changes";
});

if (saveSocialWebhooksBtn) {
  saveSocialWebhooksBtn.addEventListener("click", () => {
    if (socialWebhooksSaveStatus) socialWebhooksSaveStatus.textContent = "Saving...";
    runtimeConfigForm?.requestSubmit();
  });
}

if (runtimeConfigForm) {
  runtimeConfigForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      const crmPublicUrl = normalizeCrmPublicUrlClient(crmPublicUrlInput?.value || "");
      if (crmPublicUrlInput) crmPublicUrlInput.value = crmPublicUrl;
      const loginEmail = String(loginEmailInput?.value || "")
        .trim()
        .toLowerCase();
      const loginPassword = String(loginPasswordInput?.value || "");
      const loginPasswordConfirm = String(loginPasswordConfirmInput?.value || "");
      const socialExtraPlatforms = String(socialExtraPlatformsInput?.value || "").trim();
      const socialWebhooks = {
        facebook: String(socialWebhookFacebookInput?.value || "").trim(),
        instagram: String(socialWebhookInstagramInput?.value || "").trim(),
        x: String(socialWebhookXInput?.value || "").trim(),
        linkedin: String(socialWebhookLinkedinInput?.value || "").trim()
      };
      if (socialExtraWebhooksHost) {
        socialExtraWebhooksHost.querySelectorAll(".social-webhook-extra-input").forEach((el) => {
          const t = el.getAttribute("data-social-target");
          if (t) socialWebhooks[t] = String(el.value || "").trim();
        });
      }
      await fetchApiJson("/api/runtime/config", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          crmPublicUrl,
          loginEmail,
          clearLoginPassword: false,
          loginPassword,
          loginPasswordConfirm,
          socialExtraPlatforms,
          socialWebhooks
        })
      });
      await fetchApiJson("/api/runtime/healthsherpa", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: String(healthSherpaUrlInput?.value || "").trim() })
      });
      lastLoadedSocialWebhooks = { ...lastLoadedSocialWebhooks, ...socialWebhooks };
      renderExtraSocialWebhookInputs();
      await loadRuntimeConfig();
      showRuntimeConfigMessage("Saved.");
      if (socialWebhooksSaveStatus) socialWebhooksSaveStatus.textContent = "Saved ✓";
      await loadSetupStatus();
    } catch (error) {
      showRuntimeConfigMessage(error.message || "Could not save.", true);
    }
  });
}

if (login2faSetupBeginBtn) {
  login2faSetupBeginBtn.addEventListener("click", async () => {
    try {
      showLogin2faMessage("Generating QR code...");
      const data = await fetchApiJson("/api/auth/2fa/setup/begin", { method: "POST" });
      if (login2faQrImage) login2faQrImage.src = String(data?.qrUrl || "");
      if (login2faSecretValue) login2faSecretValue.textContent = String(data?.secretBase32 || "");
      setLogin2faPanelVisible(true);
      if (login2faSetupCodeInput) {
        login2faSetupCodeInput.value = "";
        login2faSetupCodeInput.focus();
      }
      setLogin2faBackupCodes([]);
      if (login2faSetupCancelBtn) login2faSetupCancelBtn.classList.remove("hidden");
      showLogin2faMessage("Scan QR, then enter the 6-digit code to confirm.");
    } catch (error) {
      showLogin2faMessage(error.message || "Could not start 2FA setup.", true);
    }
  });
}

if (login2faConfirmBtn) {
  login2faConfirmBtn.addEventListener("click", async () => {
    try {
      const code = String(login2faSetupCodeInput?.value || "").trim();
      if (!code) throw new Error("Enter the 6-digit code from your authenticator app.");
      showLogin2faMessage("Enabling 2FA...");
      const data = await fetchApiJson("/api/auth/2fa/setup/confirm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code })
      });
      setLogin2faBackupCodes(data?.backupCodes || []);
      setLogin2faPanelVisible(false);
      await loadRuntimeConfig();
      await loadLogin2faStatus();
      showLogin2faMessage("2FA enabled. Save your backup codes now.");
      await loadSetupStatus();
    } catch (error) {
      showLogin2faMessage(error.message || "Could not enable 2FA.", true);
    }
  });
}

if (login2faSetupCancelBtn) {
  login2faSetupCancelBtn.addEventListener("click", async () => {
    try {
      await fetchApiJson("/api/auth/2fa/setup/cancel", { method: "POST" });
      setLogin2faPanelVisible(false);
      if (login2faSetupCancelBtn) login2faSetupCancelBtn.classList.add("hidden");
      showLogin2faMessage("2FA setup canceled.");
      await loadLogin2faStatus();
    } catch (error) {
      showLogin2faMessage(error.message || "Could not cancel setup.", true);
    }
  });
}

if (login2faDisableBtn) {
  login2faDisableBtn.addEventListener("click", async () => {
    try {
      const password = String(login2faDisablePasswordInput?.value || "");
      const code = String(login2faDisableCodeInput?.value || "").trim();
      if (!password.trim()) throw new Error("Enter your current password.");
      if (!code) throw new Error("Enter an authenticator code or backup code.");
      showLogin2faMessage("Disabling 2FA...");
      await fetchApiJson("/api/auth/2fa/disable", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password, code })
      });
      if (login2faDisablePasswordInput) login2faDisablePasswordInput.value = "";
      if (login2faDisableCodeInput) login2faDisableCodeInput.value = "";
      setLogin2faBackupCodes([]);
      await loadRuntimeConfig();
      await loadLogin2faStatus();
      showLogin2faMessage("2FA disabled.");
      await loadSetupStatus();
    } catch (error) {
      showLogin2faMessage(error.message || "Could not disable 2FA.", true);
    }
  });
}

if (login2faDownloadBackupCodesBtn) {
  login2faDownloadBackupCodesBtn.addEventListener("click", downloadLogin2faBackupCodes);
}

const CALENDAR_TZ_STORAGE_KEY = "cadence_calendar_timezone";
const calendarTimezoneSelect = document.getElementById("calendarTimezoneSelect");
const calendarTimezoneHint = document.getElementById("calendarTimezoneHint");

function loadCalendarTimezoneSetting() {
  if (!calendarTimezoneSelect) return;
  try {
    const stored = localStorage.getItem(CALENDAR_TZ_STORAGE_KEY);
    const browserTz = Intl.DateTimeFormat().resolvedOptions().timeZone || "";
    if (stored) {
      calendarTimezoneSelect.value = stored;
      if (calendarTimezoneHint) calendarTimezoneHint.textContent = "Saved for this browser - change if needed.";
      return;
    }
    if (browserTz && [...calendarTimezoneSelect.options].some((o) => o.value === browserTz)) {
      calendarTimezoneSelect.value = browserTz;
      if (calendarTimezoneHint) {
        calendarTimezoneHint.textContent = `Detected from your browser (${browserTz}) - change if needed.`;
      }
    } else if (calendarTimezoneHint) {
      calendarTimezoneHint.textContent = "Detected from your browser where possible - change if needed.";
    }
  } catch {
    // ignore
  }
}

if (calendarTimezoneSelect) {
  loadCalendarTimezoneSetting();
  calendarTimezoneSelect.addEventListener("change", () => {
    try {
      localStorage.setItem(CALENDAR_TZ_STORAGE_KEY, calendarTimezoneSelect.value);
      if (calendarTimezoneHint) calendarTimezoneHint.textContent = "Saved for this browser - change if needed.";
      showGoogleCalendarMessage("Calendar time zone saved.");
    } catch {
      showGoogleCalendarMessage("Could not save time zone.", true);
    }
  });
}

const googleCalendarStatusEl = document.getElementById("googleCalendarStatus");
const googleCalendarConnectBtn = document.getElementById("googleCalendarConnectBtn");
const googleCalendarSyncBtn = document.getElementById("googleCalendarSyncBtn");
const googleCalendarDisconnectBtn = document.getElementById("googleCalendarDisconnectBtn");
const googleCalendarMessageEl = document.getElementById("googleCalendarMessage");
let googleCalendarOAuthConfigured = false;

function showGoogleCalendarMessage(text, isError = false) {
  if (!googleCalendarMessageEl) return;
  googleCalendarMessageEl.textContent = text || "";
  googleCalendarMessageEl.style.color = isError ? "#b91c1c" : "#047857";
}

async function loadGoogleCalendarStatus() {
  if (!googleCalendarStatusEl) return;
  try {
    const data = await fetchApiJson("/api/google/calendar/status");
    googleCalendarOAuthConfigured = Boolean(data.configured);
    if (!data.configured) {
      googleCalendarStatusEl.textContent =
        "Not configured yet: add a Google Client ID and Client Secret from Google Cloud Console, or contact support and we will walk you through it.";
      if (googleCalendarConnectBtn) googleCalendarConnectBtn.hidden = false;
      if (googleCalendarSyncBtn) googleCalendarSyncBtn.hidden = true;
      if (googleCalendarDisconnectBtn) googleCalendarDisconnectBtn.hidden = true;
      return;
    }
    if (data.connected) {
      const lastSync = data.lastSyncAt ? new Date(data.lastSyncAt * 1000).toLocaleString() : "Never";
      googleCalendarStatusEl.textContent =
        `Connected${data.accountEmail ? ` as ${data.accountEmail}` : ""}. Last sync: ${lastSync}.`;
      if (googleCalendarConnectBtn) googleCalendarConnectBtn.hidden = true;
      if (googleCalendarSyncBtn) googleCalendarSyncBtn.hidden = false;
      if (googleCalendarDisconnectBtn) googleCalendarDisconnectBtn.hidden = false;
    } else {
      googleCalendarStatusEl.textContent = "Not connected.";
      if (googleCalendarConnectBtn) googleCalendarConnectBtn.hidden = false;
      if (googleCalendarSyncBtn) googleCalendarSyncBtn.hidden = true;
      if (googleCalendarDisconnectBtn) googleCalendarDisconnectBtn.hidden = true;
    }
  } catch (err) {
    googleCalendarStatusEl.textContent = `Error: ${err.message || "status check failed"}`;
  }
}

if (googleCalendarConnectBtn) {
  googleCalendarConnectBtn.addEventListener("click", async () => {
    showGoogleCalendarMessage("");
    if (!googleCalendarOAuthConfigured) {
      showGoogleCalendarMessage(
        "Google OAuth is not configured on this server. Add GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET to .env, then restart the app.",
        true
      );
      return;
    }
    const prevLabel = googleCalendarConnectBtn.textContent;
    googleCalendarConnectBtn.disabled = true;
    googleCalendarConnectBtn.textContent = "Connecting...";
    try {
      const data = await fetchApiJson(
        `/api/google/calendar/auth-url?next=${encodeURIComponent("/settings.html?section=calendar")}`
      );
      const url = String(data?.url || "").trim();
      if (!url) {
        throw new Error(
          "No Google sign-in URL returned. Check GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, and GOOGLE_REDIRECT_URI in .env."
        );
      }
      window.location.assign(url);
    } catch (err) {
      showGoogleCalendarMessage(err.message || "Failed to connect Google Calendar.", true);
    } finally {
      googleCalendarConnectBtn.disabled = false;
      googleCalendarConnectBtn.textContent = prevLabel || "Connect Google Calendar";
    }
  });
}

if (googleCalendarDisconnectBtn) {
  googleCalendarDisconnectBtn.addEventListener("click", async () => {
    if (!window.confirm("Disconnect Google Calendar? Synced events will remain locally but will no longer be updated.")) return;
    showGoogleCalendarMessage("");
    try {
      await fetchApiJson("/api/google/calendar/disconnect", { method: "POST" });
      showGoogleCalendarMessage("Google Calendar disconnected.");
      await loadGoogleCalendarStatus();
      await loadSetupStatus();
    } catch (err) {
      showGoogleCalendarMessage(err.message || "Failed to disconnect.", true);
    }
  });
}

if (googleCalendarSyncBtn) {
  googleCalendarSyncBtn.addEventListener("click", async () => {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth(), 1);
    const end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    const pad = (n) => String(n).padStart(2, "0");
    const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    showGoogleCalendarMessage("Syncing...");
    try {
      const data = await fetchApiJson("/api/google/calendar/sync", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ start: iso(start), end: iso(end) })
      });
      showGoogleCalendarMessage(
        `Synced. Imported: ${data.imported || 0}, updated: ${data.updated || 0}, pushed: ${data.pushed || 0}.`
      );
      await loadGoogleCalendarStatus();
    } catch (err) {
      showGoogleCalendarMessage(err.message || "Sync failed.", true);
    }
  });
}

(function checkGoogleCalendarReturn() {
  const params = new URLSearchParams(window.location.search);
  if (params.get("google_connected") === "1") {
    showGoogleCalendarMessage("Google Calendar connected successfully.");
    loadSetupStatus();
    if (window.history && window.history.replaceState) {
      const url = new URL(window.location.href);
      url.searchParams.delete("google_connected");
      window.history.replaceState({}, "", url.toString());
    }
  } else if (params.get("google_error")) {
    showGoogleCalendarMessage(`Google connection error: ${params.get("google_error")}`, true);
  }
})();

(function wireThanksIoSettings() {
  const form = document.getElementById("thanksIoConfigForm");
  const keyInput = document.getElementById("thanksIoApiKeyInput");
  const statusEl = document.getElementById("thanksIoStatus");
  const messageEl = document.getElementById("thanksIoMessage");
  const testBtn = document.getElementById("thanksIoTestBtn");
  const openLink = document.getElementById("thanksIoOpenAppLink");
  if (!form && !statusEl) return;

  function showThanksIoMessage(text, isError = false) {
    if (!messageEl) return;
    messageEl.textContent = text || "";
    messageEl.style.color = isError ? "#b91c1c" : "#047857";
  }

  async function loadThanksIoConfig() {
    if (!statusEl) return;
    try {
      const data = await fetchApiJson("/api/thanksio/config");
      if (openLink && data?.appUrl) openLink.href = String(data.appUrl);
      if (data?.configured) {
        statusEl.textContent = `Connected. Saved key ${data.preview || "••••"}.`;
        if (keyInput) keyInput.placeholder = data.preview ? `Saved (${data.preview})` : "Leave blank to keep the saved key";
      } else {
        statusEl.textContent = "Not connected. Paste a Thanks.io Personal Access Token and save.";
      }
    } catch (err) {
      statusEl.textContent = err.message || "Could not load Thanks.io settings.";
    }
  }

  form?.addEventListener("submit", async (event) => {
    event.preventDefault();
    showThanksIoMessage("Saving…");
    try {
      const raw = String(keyInput?.value || "").trim();
      const data = await fetchApiJson("/api/thanksio/config", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(raw === "__clear__" ? { clear: true } : { apiKey: raw })
      });
      if (keyInput) keyInput.value = "";
      if (data?.configured) {
        showThanksIoMessage("Thanks.io API key saved.");
      } else {
        showThanksIoMessage("Thanks.io API key cleared.");
      }
      await loadThanksIoConfig();
      if (typeof loadSetupStatus === "function") loadSetupStatus();
    } catch (err) {
      showThanksIoMessage(err.message || "Could not save Thanks.io key.", true);
    }
  });

  testBtn?.addEventListener("click", async () => {
    showThanksIoMessage("Testing Thanks.io…");
    try {
      const raw = String(keyInput?.value || "").trim();
      await fetchApiJson("/api/thanksio/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(raw && raw !== "__clear__" ? { apiKey: raw } : {})
      });
      showThanksIoMessage("Thanks.io accepted the API key.");
    } catch (err) {
      showThanksIoMessage(err.message || "Thanks.io test failed.", true);
    }
  });

  if (typeof guardNonLoginSecretInput === "function") guardNonLoginSecretInput(keyInput);
  loadThanksIoConfig();
})();


(function wireAnthropicSettings() {
  const form = document.getElementById("anthropicConfigForm");
  const keyInput = document.getElementById("anthropicApiKeyInput");
  const statusEl = document.getElementById("anthropicStatus");
  const messageEl = document.getElementById("anthropicMessage");
  const testBtn = document.getElementById("anthropicTestBtn");
  if (!form && !statusEl) return;

  function showAnthropicMessage(text, isError = false) {
    if (!messageEl) return;
    messageEl.textContent = text || "";
    messageEl.style.color = isError ? "#b91c1c" : "#047857";
  }

  async function loadAnthropicConfig() {
    if (!statusEl) return;
    try {
      const data = await fetchApiJson("/api/anthropic/config");
      if (data?.configured) {
        statusEl.textContent = `Connected. Saved key ${data.preview || "••••"}.`;
        if (keyInput) keyInput.placeholder = data.preview ? `Saved (${data.preview})` : "Leave blank to keep the saved key";
      } else {
        statusEl.textContent = "Not connected. Paste the site Claude key and save. Customers never add one.";
      }
    } catch (err) {
      statusEl.textContent = err.message || "Could not load Claude settings.";
    }
  }

  form?.addEventListener("submit", async (event) => {
    event.preventDefault();
    showAnthropicMessage("Saving…");
    try {
      const raw = String(keyInput?.value || "").trim();
      const data = await fetchApiJson("/api/anthropic/config", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(raw === "__clear__" ? { clear: true } : { apiKey: raw })
      });
      if (keyInput) keyInput.value = "";
      if (data?.configured) showAnthropicMessage("Claude API key saved.");
      else showAnthropicMessage("Claude API key cleared.");
      await loadAnthropicConfig();
      if (typeof loadSetupStatus === "function") loadSetupStatus();
    } catch (err) {
      showAnthropicMessage(err.message || "Could not save Claude key.", true);
    }
  });

  testBtn?.addEventListener("click", async () => {
    showAnthropicMessage("Testing Claude…");
    try {
      const raw = String(keyInput?.value || "").trim();
      await fetchApiJson("/api/anthropic/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(raw && raw !== "__clear__" ? { apiKey: raw } : {})
      });
      showAnthropicMessage("Claude accepted the API key.");
    } catch (err) {
      showAnthropicMessage(err.message || "Claude test failed.", true);
    }
  });

  if (typeof guardNonLoginSecretInput === "function") guardNonLoginSecretInput(keyInput);
  loadAnthropicConfig();
})();

// ── SMS usage display ─────────────────────────────────────────────────────────
(function loadSmsUsage() {
  async function refresh() {
    try {
      const res = await fetch("/api/sms/usage");
      if (!res.ok) return;
      const d = await res.json();
      function update(labelId, barId, limitId, used, limit, pct) {
        const labelEl = document.getElementById(labelId);
        const barEl   = document.getElementById(barId);
        const limitEl = document.getElementById(limitId);
        if (labelEl) labelEl.textContent = used;
        if (limitEl) limitEl.textContent = `${used} / ${limit}`;
        if (barEl) {
          barEl.style.width = `${Math.min(pct, 100)}%`;
          barEl.className = "settings-sms-usage-bar" + (pct >= 100 ? " danger" : pct >= 80 ? " warn" : "");
        }
      }
      update("smsUsageDaily",   "smsUsageDailyBar",   "smsUsageDailyLimit",   d.daily,   d.dailyLimit,   d.dailyPct);
      update("smsUsageMonthly", "smsUsageMonthlyBar", "smsUsageMonthlyLimit", d.monthly, d.monthlyLimit, d.monthlyPct);
    } catch (_) {}
  }
  refresh();
})();
// ─────────────────────────────────────────────────────────────────────────────

// ── Call forward quick-save ───────────────────────────────────────────────────
(function wireForwardNumber() {
  const btn   = document.getElementById("saveForwardNumberBtn");
  const input = document.getElementById("twilioInboundForwardToInputTop");
  const msg   = document.getElementById("saveForwardNumberMsg");
  if (!btn || !input) return;
  btn.addEventListener("click", async () => {
    const val = input.value.trim();
    msg.style.color = "#64748b";
    msg.textContent = "Saving…";
    try {
      const res = await fetch("/api/twilio/config", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ inboundForwardTo: val })
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "Save failed");
      // Keep the hidden form field in sync
      if (twilioInboundForwardToInput) twilioInboundForwardToInput.value = val;
      msg.style.color = "#059669";
      msg.textContent = val ? `✅ Calls to your Cadence number will forward to ${val}` : "✅ Call forwarding cleared.";
    } catch (e) {
      msg.style.color = "#dc2626";
      msg.textContent = `❌ ${e.message}`;
    }
  });
})();
// ─────────────────────────────────────────────────────────────────────────────

// ── Owner admin panel ─────────────────────────────────────────────────────────
(function wireOwnerAdmin() {
  const section  = document.getElementById("ownerAdminSection");
  const navLink  = document.getElementById("ownerAdminNavLink");
  const loading  = document.getElementById("adminTenantsLoading");
  const table    = document.getElementById("adminTenantsTable");
  const tbody    = document.getElementById("adminTenantsBody");
  const msgEl    = document.getElementById("adminTenantsMsg");
  if (!section) return;

  function showMsg(msg, isError) {
    if (!msgEl) return;
    msgEl.textContent = msg;
    msgEl.style.color = isError ? "#dc2626" : "#059669";
  }

  async function callAdminApi(url, body, btn, loadingText) {
    btn.disabled = true;
    const orig = btn.textContent;
    btn.textContent = loadingText;
    showMsg("", false);
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "Failed");
      return d;
    } catch (e) {
      showMsg(`❌ ${e.message}`, true);
      btn.disabled = false;
      btn.textContent = orig;
      throw e;
    }
  }

  async function provisionNumber(tenantId, state, btn) {
    try {
      const d = await callAdminApi(`/api/admin/tenants/${tenantId}/provision-number`, { residentState: state }, btn, "Provisioning…");
      showMsg(`✅ Provisioned ${d.phone}`, false);
      loadTenants();
    } catch (_) {}
  }

  async function deleteTenant(tenantId, name, btn) {
    const label = String(name || "").trim();
    if (!label) {
      showMsg("This account has no name to confirm. Nothing was deleted.", true);
      return;
    }
    const typed = window.prompt(
      `Delete "${label}"?\n\nThis releases their phone number and deletes their contacts. It cannot be undone.\n\nType the account name to confirm:`
    );
    if (typed == null) return;
    if (typed.trim().toLowerCase() !== label.toLowerCase()) {
      showMsg("Account name did not match. Nothing was deleted.", true);
      return;
    }
    btn.disabled = true;
    btn.textContent = "Deleting…";
    showMsg("", false);
    try {
      const res = await fetch(`/api/admin/tenants/${tenantId}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ confirmName: label })
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "Delete failed");
      showMsg(`✅ Tenant "${name}" deleted${d.releasedPhone ? ` — released ${d.releasedPhone}` : ""}`, false);
      loadTenants();
    } catch (e) {
      showMsg(`❌ ${e.message}`, true);
      btn.disabled = false;
      btn.textContent = "Delete";
    }
  }

  async function seedVoice(tenantId, btn) {
    try {
      await callAdminApi(`/api/admin/tenants/${tenantId}/seed-voice`, {}, btn, "Seeding…");
      showMsg(`✅ Voice credentials seeded — click-to-call is now ready for this tenant`, false);
      loadTenants();
    } catch (_) {}
  }

  async function fixMessaging(tenantId, phone, btn) {
    try {
      const d = await callAdminApi(`/api/admin/tenants/${tenantId}/fix-messaging`, {}, btn, "Fixing…");
      showMsg(`✅ ${phone} added to messaging service — SMS should work now`, false);
      loadTenants();
    } catch (_) {}
  }

  async function releaseNumber(tenantId, phone, btn) {
    if (!confirm(`Release ${phone} from this tenant? This cannot be undone.`)) return;
    try {
      await callAdminApi(`/api/admin/tenants/${tenantId}/release-number`, {}, btn, "Releasing…");
      showMsg(`✅ Released ${phone}`, false);
      loadTenants();
    } catch (_) {}
  }

  async function changeNumber(tenantId, state, btn) {
    if (!confirm(`Replace the current number with a new ${state} number? The old number will be released.`)) return;
    try {
      const d = await callAdminApi(`/api/admin/tenants/${tenantId}/change-number`, { residentState: state }, btn, "Changing…");
      showMsg(`✅ Changed to ${d.newPhone} (released ${d.oldPhone || "old number"})`, false);
      loadTenants();
    } catch (_) {}
  }

  let allTenants = [];

  function formatAdminTenantTrial(t) {
    const status = String(t.status || "").trim().toLowerCase();
    if (status === "active") return { text: "Active plan", color: "#059669" };
    const days = t.trialDaysLeft;
    if (days == null && status !== "trial") {
      if (status === "expired" || status === "cancelled") return { text: "Trial expired", color: "#dc2626" };
      return null;
    }
    if (days === 0 || status === "expired") return { text: "Trial expired", color: "#dc2626" };
    if (typeof days === "number" && days > 0) {
      return {
        text: `${days} day${days === 1 ? "" : "s"} left in trial`,
        color: "#1d4ed8"
      };
    }
    return null;
  }

  function renderTenants(tenants) {
    const container = document.getElementById("adminTenantCards");
    const countEl   = document.getElementById("adminTenantCount");
    if (!container) return;
    container.innerHTML = "";
    if (countEl) countEl.textContent = `${tenants.length} tenant${tenants.length !== 1 ? "s" : ""}`;
    if (!tenants.length) {
      container.innerHTML = `<p class="hint">No tenants match your search.</p>`;
      return;
    }
      for (const t of tenants) {
        const statusColor = t.status === "trial" ? "#1e40af" : t.status === "active" ? "#059669" : "#9ca3af";
        const trialMeta = formatAdminTenantTrial(t);
        const trialHtml = trialMeta
          ? `<div class="admin-tenant-card-trial" style="color:${trialMeta.color};font-weight:700;font-size:0.88rem;margin-top:4px;">${escapeHtmlText(trialMeta.text)}</div>`
          : "";
        const card = document.createElement("div");
        card.className = "admin-tenant-card";
        card.innerHTML = `
          <div class="admin-tenant-card-top">
            <div class="admin-tenant-card-name">${escapeHtmlText(t.agency_name || t.slug || "—")}</div>
            <span class="admin-tenant-card-status" style="color:${statusColor};border-color:${statusColor};">${escapeHtmlText(t.status || "—")}</span>
          </div>
          <div class="admin-tenant-card-email">${escapeHtmlText(t.owner_email || "—")}</div>
          ${trialHtml}
          <div class="admin-tenant-card-phone">${t.provisionedPhone
            ? `<span style="color:#059669;font-weight:700;">✅ ${t.provisionedPhone}</span>`
            : `<span style="color:#94a3b8;">No number assigned</span>`
          }</div>
          <div class="admin-tenant-card-action"></div>
        `;
        const actionEl = card.querySelector(".admin-tenant-card-action");
        const wrap = document.createElement("div");
        wrap.style.cssText = "display:flex;align-items:center;gap:8px;margin-top:10px;flex-wrap:wrap;";

        const stateLabel = document.createElement("span");
        stateLabel.textContent = "State:";
        stateLabel.style.cssText = "font-size:0.82rem;font-weight:600;color:#374151;";
        const stateInput = document.createElement("input");
        stateInput.placeholder = "FL";
        stateInput.maxLength = 2;
        stateInput.value = t.residentState || "";
        stateInput.style.cssText = "width:52px;padding:7px 8px;border:1px solid #e2e8f0;border-radius:8px;font-size:0.88rem;text-transform:uppercase;text-align:center;";

        wrap.appendChild(stateLabel);
        wrap.appendChild(stateInput);

        if (!t.provisionedPhone) {
          const btn = document.createElement("button");
          btn.textContent = "Provision Number";
          btn.style.cssText = "padding:7px 16px;background:#4f46e5;color:#fff;border:none;border-radius:8px;font-size:0.88rem;font-weight:600;cursor:pointer;white-space:nowrap;";
          btn.addEventListener("click", () => provisionNumber(t.id, stateInput.value.trim().toUpperCase(), btn));
          wrap.appendChild(btn);
        } else {
          const seedVoiceBtn = document.createElement("button");
          seedVoiceBtn.textContent = "Seed Voice";
          seedVoiceBtn.title = "Copy master Twilio voice credentials to enable click-to-call";
          seedVoiceBtn.style.cssText = "padding:7px 16px;background:#7c3aed;color:#fff;border:none;border-radius:8px;font-size:0.88rem;font-weight:600;cursor:pointer;white-space:nowrap;";
          seedVoiceBtn.addEventListener("click", () => seedVoice(t.id, seedVoiceBtn));

          const fixBtn = document.createElement("button");
          fixBtn.textContent = "Fix SMS";
          fixBtn.title = "Add to messaging service for A2P compliance";
          fixBtn.style.cssText = "padding:7px 16px;background:#059669;color:#fff;border:none;border-radius:8px;font-size:0.88rem;font-weight:600;cursor:pointer;white-space:nowrap;";
          fixBtn.addEventListener("click", () => fixMessaging(t.id, t.provisionedPhone, fixBtn));

          const changeBtn = document.createElement("button");
          changeBtn.textContent = "Change Number";
          changeBtn.style.cssText = "padding:7px 16px;background:#0369a1;color:#fff;border:none;border-radius:8px;font-size:0.88rem;font-weight:600;cursor:pointer;white-space:nowrap;";
          changeBtn.addEventListener("click", () => changeNumber(t.id, stateInput.value.trim().toUpperCase() || t.residentState || "FL", changeBtn));

          const releaseBtn = document.createElement("button");
          releaseBtn.textContent = "Deactivate";
          releaseBtn.style.cssText = "padding:7px 16px;background:#dc2626;color:#fff;border:none;border-radius:8px;font-size:0.88rem;font-weight:600;cursor:pointer;white-space:nowrap;";
          releaseBtn.addEventListener("click", () => releaseNumber(t.id, t.provisionedPhone, releaseBtn));

          wrap.appendChild(seedVoiceBtn);
          wrap.appendChild(fixBtn);
          wrap.appendChild(changeBtn);
          wrap.appendChild(releaseBtn);
        }

        // Delete button — not for legacy/primary workspace
        if (t.id !== "legacy" && t.slug !== "legacy") {
          const deleteWrap = document.createElement("div");
          deleteWrap.style.cssText = "margin-top:8px;padding-top:8px;border-top:1px solid #f1f5f9;";
          const deleteBtn = document.createElement("button");
          deleteBtn.textContent = "🗑 Delete Tenant";
          deleteBtn.style.cssText = "padding:5px 12px;background:none;color:#dc2626;border:1px solid #dc2626;border-radius:8px;font-size:0.82rem;font-weight:600;cursor:pointer;white-space:nowrap;";
          deleteBtn.addEventListener("click", () => deleteTenant(t.id, t.agency_name || t.owner_email, deleteBtn));
          deleteWrap.appendChild(deleteBtn);
          actionEl.appendChild(deleteWrap);
        }

        actionEl.appendChild(wrap);
        container.appendChild(card);
      }
  }

  async function loadTenants() {
    if (loading) {
      loading.style.display = "";
      loading.textContent = "Loading tenants…";
    }
    const container = document.getElementById("adminTenantCards");
    if (container) container.innerHTML = "";
    try {
      const res = await fetch("/api/admin/tenants", { credentials: "same-origin" });
      let data = {};
      try {
        data = await res.json();
      } catch (_) {
        data = {};
      }
      if (!res.ok) {
        throw new Error(data.error || `Could not load tenants (${res.status}).`);
      }
      allTenants = Array.isArray(data) ? data : [];
      if (loading) loading.style.display = "none";
      const q = String(document.getElementById("adminTenantSearch")?.value || "").trim().toLowerCase();
      renderTenants(q ? allTenants.filter(t => filterTenant(t, q)) : allTenants);
    } catch (e) {
      const message = e?.message || "Failed to load tenants.";
      if (loading) {
        loading.style.display = "";
        loading.textContent = message;
      }
      showMsg(`❌ ${message}`, true);
    }
  }

  function filterTenant(t, q) {
    return (
      String(t.agency_name || "").toLowerCase().includes(q) ||
      String(t.owner_email || "").toLowerCase().includes(q) ||
      String(t.owner_first_name || "").toLowerCase().includes(q) ||
      String(t.owner_last_name || "").toLowerCase().includes(q) ||
      String(t.provisionedPhone || "").replace(/\D/g, "").includes(q.replace(/\D/g, "")) ||
      String(t.slug || "").toLowerCase().includes(q)
    );
  }

  function runSearch() {
    const q = String(document.getElementById("adminTenantSearch")?.value || "").trim().toLowerCase();
    renderTenants(q ? allTenants.filter(t => filterTenant(t, q)) : allTenants);
  }

  const searchInput = document.getElementById("adminTenantSearch");
  if (searchInput) {
    searchInput.addEventListener("input", runSearch);
    searchInput.addEventListener("keydown", (e) => { if (e.key === "Enter") runSearch(); });
  }
  const searchBtn = document.getElementById("adminTenantSearchBtn");
  if (searchBtn) searchBtn.addEventListener("click", runSearch);

  function canSeeOwnerAdmin(status) {
    if (!status?.authenticated) return false;
    if (status?.workspace?.type === "trial") return false;
    if (status?.subscription?.tenantId) return false;
    const tenantId = Number(status?.workspace?.tenantId);
    if (Number.isInteger(tenantId) && tenantId > 1) return false;
    return true;
  }

  async function initOwnerAdmin() {
    try {
      const res = await fetch("/api/auth/status", { credentials: "same-origin" });
      const status = res.ok ? await res.json() : null;
      if (!canSeeOwnerAdmin(status)) {
        if (section) section.style.display = "none";
        if (navLink) navLink.style.display = "none";
        return;
      }
      if (section) section.style.display = "";
      if (navLink) navLink.style.display = "";
      await loadTenants();
    } catch (e) {
      if (loading) loading.textContent = "Could not verify admin access.";
      showMsg(`❌ ${e?.message || "Could not verify admin access."}`, true);
    }
  }

  initOwnerAdmin();
})();
// ── End owner admin panel ─────────────────────────────────────────────────────

// ── Test SMS & Test Call buttons ──────────────────────────────────────────────
(function wireTestButtons() {
  const smsBtnEl  = document.getElementById("testSmsBtn");
  const callBtnEl = document.getElementById("testCallBtn");
  const msgEl     = document.getElementById("testActionMsg");

  function showMsg(msg, isError) {
    if (!msgEl) return;
    msgEl.textContent = msg;
    msgEl.style.color = isError ? "#dc2626" : "#059669";
  }

  if (smsBtnEl) {
    smsBtnEl.addEventListener("click", async () => {
      const phone = prompt("Send test SMS to (your cell number, e.g. +15551234567):");
      if (!phone) return;
      smsBtnEl.disabled = true;
      showMsg("Sending test SMS…", false);
      try {
        const res = await fetch("/api/twilio/send-sms", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ phone, body: "✅ Test SMS from Cadence CRM — your texting is working!" })
        });
        const d = await res.json();
        if (!res.ok) throw new Error(d.error || "Failed");
        showMsg(`✅ Test SMS sent to ${phone}!`, false);
      } catch (e) {
        showMsg(`❌ ${e.message}`, true);
      } finally {
        smsBtnEl.disabled = false;
      }
    });
  }

  if (callBtnEl) {
    callBtnEl.addEventListener("click", async () => {
      const phone = prompt("Call this number directly (e.g. +15551234567). Cadence will not ring a second phone:");
      if (!phone) return;
      callBtnEl.disabled = true;
      showMsg("Starting test call…", false);
      try {
        const res = await fetch("/api/twilio/start-call", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ phone })
        });
        const d = await res.json();
        if (!res.ok) throw new Error(d.error || "Failed");
        showMsg(`✅ Calling ${phone} directly. Your cell is not bridged onto this call.`, false);
      } catch (e) {
        showMsg(`❌ ${e.message}`, true);
      } finally {
        callBtnEl.disabled = false;
      }
    });
  }
})();
// ── End test buttons ──────────────────────────────────────────────────────────

loadSavedSignature().catch(() => {});
applyOwnerExtraNumbers();
loadTwilioConfig();
loadEmailFromAddresses();
loadRuntimeConfig();
loadLogin2faStatus();
loadBuildStampFooter();
ensureActiveCrmSession().then(() => {
  loadSetupStatus();
  loadEmailTemplateBrandingSettings();
});
wireApiIntegrationsCatalog();
loadGoogleCalendarStatus();
if (typeof window.crmInitPasswordToggles === "function") {
  window.crmInitPasswordToggles(document);
}

(function wireHelpSearch() {
  const inputs = [...document.querySelectorAll("[data-help-search]")];
  const list = document.getElementById("helpTopicsList");
  const empty = document.getElementById("helpEmptyMessage");
  const emptyTop = document.getElementById("helpSearchEmptyHintTop");
  if (!inputs.length || !list) return;
  const topics = [...list.querySelectorAll(".help-topic")].map((node) => {
    const summary = node.querySelector("summary");
    const tags = String(node.getAttribute("data-tags") || "").toLowerCase();
    const summaryText = String(summary?.textContent || "").toLowerCase();
    const bodyText = String(node.querySelector(".help-body")?.textContent || "").toLowerCase();
    return { node, summary, summaryText, bodyText, tags };
  });
  function syncQuery(raw) {
    for (const el of inputs) {
      if (el.value !== raw) el.value = raw;
    }
  }
  function applyFilterFrom(raw) {
    syncQuery(raw);
    const q = String(raw || "").trim().toLowerCase();
    let visibleCount = 0;
    for (const t of topics) {
      const match = !q || t.summaryText.includes(q) || t.bodyText.includes(q) || t.tags.includes(q);
      t.node.hidden = !match;
      if (match) visibleCount += 1;
      if (q && match) {
        t.node.open = true;
      } else if (!q) {
        t.node.open = false;
      }
    }
    if (empty) empty.hidden = visibleCount > 0;
    if (emptyTop) emptyTop.hidden = visibleCount > 0;
  }
  for (const el of inputs) {
    el.addEventListener("input", () => applyFilterFrom(el.value));
  }
  applyFilterFrom("");
})();

/**
 * Settings Directory filter: hides cards whose title/desc/keywords don't match
 * the input. Pure DOM/text-based; never round-trips to the server.
 */
let moreSettingsOpenedByUser = false;

(function wireSettingsDirectoryFilter() {
  const input = document.getElementById("settingsDirectoryFilter");
  const grid = document.getElementById("settingsDirectoryGrid");
  const empty = document.getElementById("settingsDirectoryEmpty");
  const moreBtn = document.getElementById("settingsMoreBtn");
  if (!input || !grid) return;
  const links = [...grid.querySelectorAll(".settings-nav-link")].map((node) => {
    const title = String(node.querySelector(".settings-nav-link-title")?.textContent || "").toLowerCase();
    const desc = String(node.querySelector(".settings-nav-link-desc")?.textContent || "").toLowerCase();
    const keywords = String(node.getAttribute("data-keywords") || "").toLowerCase();
    return { node, title, desc, keywords, more: node.classList.contains("settings-more-link") };
  });
  const groupLabels = [...grid.querySelectorAll(".settings-nav-group-label")];
  function applyFilter() {
    const q = String(input.value || "").trim().toLowerCase();
    let visible = 0;
    let moreMatch = 0;
    for (const c of links) {
      const match = !q || c.title.includes(q) || c.desc.includes(q) || c.keywords.includes(q);
      if (c.more) {
        if (match) moreMatch += 1;
        const show = match && (moreSettingsOpenedByUser || Boolean(q));
        c.node.hidden = !show;
        if (show) visible += 1;
      } else {
        c.node.hidden = !match;
        if (match) visible += 1;
      }
    }
    if (moreBtn) {
      moreBtn.hidden = Boolean(q) && moreMatch === 0;
      moreBtn.setAttribute("aria-expanded", moreSettingsOpenedByUser ? "true" : "false");
    }
    for (const label of groupLabels) {
      let next = label.nextElementSibling;
      let groupHasVisible = false;
      while (next && !next.classList.contains("settings-nav-group-label")) {
        if (next.classList.contains("settings-nav-link") && !next.hidden) groupHasVisible = true;
        next = next.nextElementSibling;
      }
      label.hidden = Boolean(q) && !groupHasVisible;
    }
    if (empty) empty.hidden = visible > 0;
  }
  window.cadenceApplySettingsNavFilter = applyFilter;
  moreBtn?.addEventListener("click", () => {
    moreSettingsOpenedByUser = !moreSettingsOpenedByUser;
    applyFilter();
  });
  input.addEventListener("input", applyFilter);
  applyFilter();
})();

/**
 * Reorder main panels to match sidebar nav (group labels + link order) and wrap in category blocks.
 */
(function alignSettingsMainToSidebar() {
  const main = document.getElementById("settingsMain");
  const nav = document.getElementById("settingsDirectoryGrid");
  if (!main || !nav) return;

  function panelForSectionId(id) {
    const el = document.getElementById(id);
    if (!el) return null;
    if (el.classList.contains("panel")) return el;
    return el.closest("section.panel");
  }

  const panels = new Map();
  for (const section of main.querySelectorAll(":scope > section.panel")) {
    if (section.id) panels.set(section.id, section);
  }

  const groups = [];
  let current = { label: "", linkIds: [] };
  for (const node of nav.children) {
    if (node.classList.contains("settings-nav-group-label")) {
      if (current.linkIds.length) groups.push(current);
      current = { label: String(node.textContent || "").trim(), linkIds: [] };
    } else if (node.classList.contains("settings-nav-link")) {
      const id = String(node.getAttribute("data-section-id") || "").trim();
      if (id) current.linkIds.push(id);
    }
  }
  if (current.linkIds.length) groups.push(current);

  const fragment = document.createDocumentFragment();
  const placed = new Set();

  /* One wrapper per section so sidebar nav shows exactly one panel (not a whole category batch). */
  for (const group of groups) {
    for (const id of group.linkIds) {
      const panel = panelForSectionId(id);
      if (!panel || placed.has(panel.id)) continue;

      const wrap = document.createElement("div");
      wrap.className = "settings-category-group";
      wrap.setAttribute("data-category", group.label);
      wrap.setAttribute("data-settings-section-id", id);

      const body = document.createElement("div");
      body.className = "settings-category-body";
      body.appendChild(panel);
      wrap.appendChild(body);
      fragment.appendChild(wrap);
      placed.add(panel.id);
    }
  }

  for (const [id, panel] of panels) {
    if (placed.has(id)) continue;
    const wrap = document.createElement("div");
    wrap.className = "settings-category-group settings-category-group--misc";
    const body = document.createElement("div");
    body.className = "settings-category-body";
    body.appendChild(panel);
    wrap.appendChild(body);
    fragment.appendChild(wrap);
  }

  const buildStamp = document.getElementById("crmBuildStampFooter");
  main.replaceChildren(fragment);
  if (buildStamp) main.appendChild(buildStamp);
})();

/** One settings section per URL (?section=slug); sidebar opens separate pages instead of long scroll. */
const SETTINGS_SECTION_SLUGS = {
  setup: "newAgentSetupSection",
  integrations: "apiIntegrationsSection",
  "email-senders": "emailFromAddressesSection",
  twilio: "twilioNumbersSection",
  "owner-admin": "ownerAdminSection",
  signature: "emailSignatureSettingsSection",
  "sidebar-branding": "emailTemplateBrandingSection",
  "merge-fields": "customMergeFieldsSection",
  calendar: "googleCalendarSettingsSection",
  thanksio: "thanksIoSettingsSection",
  anthropic: "anthropicSettingsSection",
  social: "socialMarketingWebhooksSection",
  reminders: "followUpRemindersSection",
  labels: "contactWorkspaceLabelsSection",
  appearance: "appearanceSettingsSection",
  general: "generalSettingsSection",
  help: "helpSection",
  support: "contactSupportSection"
};
const SETTINGS_DEFAULT_SLUG = "setup";
const SETTINGS_SLUG_BY_SECTION_ID = Object.fromEntries(
  Object.entries(SETTINGS_SECTION_SLUGS).map(([slug, id]) => [id, slug])
);

function settingsPageUrl(slug) {
  const s = String(slug || "").trim() || SETTINGS_DEFAULT_SLUG;
  return `/settings.html?section=${encodeURIComponent(s)}`;
}

window.cadenceSettingsPageUrl = settingsPageUrl;

(function wireSettingsSectionPages() {
  const grid = document.getElementById("settingsDirectoryGrid");
  const main = document.getElementById("settingsMain");
  if (!grid || !main) return;

  document.body.classList.add("settings-single-section");

  const links = [...grid.querySelectorAll(".settings-nav-link")];
  const linkBySlug = new Map();
  for (const link of links) {
    const slug = String(link.getAttribute("data-section") || "").trim();
    if (slug) linkBySlug.set(slug, link);
  }

  function resolveSlug() {
    const params = new URLSearchParams(window.location.search);
    let slug = String(params.get("section") || "").trim().toLowerCase();
    if (!slug) {
      const hash = String(window.location.hash || "").replace(/^#/, "");
      if (hash && SETTINGS_SECTION_SLUGS[hash]) slug = hash;
      else if (hash && SETTINGS_SLUG_BY_SECTION_ID[hash]) slug = SETTINGS_SLUG_BY_SECTION_ID[hash];
    }
    return SETTINGS_SECTION_SLUGS[slug] ? slug : SETTINGS_DEFAULT_SLUG;
  }

  function setActiveLink(activeLink) {
    for (const link of links) {
      link.classList.toggle("is-active", link === activeLink);
    }
    activeLink?.scrollIntoView?.({ block: "nearest", behavior: "smooth" });
  }

  function showSection(slug, { replaceUrl = true } = {}) {
    const resolved = SETTINGS_SECTION_SLUGS[slug] ? slug : SETTINGS_DEFAULT_SLUG;
    const sectionId = SETTINGS_SECTION_SLUGS[resolved];
    const activeLink = linkBySlug.get(resolved) || linkBySlug.get(SETTINGS_DEFAULT_SLUG);
    const panel = document.getElementById(sectionId);

    for (const group of main.querySelectorAll(".settings-category-group")) {
      const groupSectionId = String(group.getAttribute("data-settings-section-id") || "").trim();
      const match =
        groupSectionId === sectionId ||
        (groupSectionId === "" && Boolean(group.querySelector(`#${sectionId}`)));
      group.hidden = !match;
      group.classList.toggle("is-active-settings-page", match);
    }

    for (const el of main.querySelectorAll("section.panel")) {
      const isActive = el.id === sectionId;
      el.hidden = !isActive;
      el.classList.toggle("is-active-settings-page", isActive);
    }

    if (!panel && !main.querySelector(".settings-category-group.is-active-settings-page")) {
      showSection(SETTINGS_DEFAULT_SLUG, { replaceUrl });
      return;
    }

    setActiveLink(activeLink);
    if (activeLink?.classList.contains("settings-more-link")) {
      moreSettingsOpenedByUser = true;
      window.cadenceApplySettingsNavFilter?.();
    }
    window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });

    const nextUrl = settingsPageUrl(resolved);
    if (replaceUrl && history.replaceState) {
      history.replaceState({ settingsSection: resolved }, "", nextUrl);
    }
    document.title = activeLink
      ? `Cadence CRM — ${String(activeLink.querySelector(".settings-nav-link-title")?.textContent || "Settings").trim()}`
      : "Cadence CRM — Account Settings";

    const sectionHook = window.cadenceSettingsSectionHooks?.[resolved];
    if (typeof sectionHook === "function") {
      try {
        sectionHook();
      } catch {
        /* ignore */
      }
    }
  }

  function slugFromNavLink(link) {
    let slug = String(link.getAttribute("data-section") || "").trim();
    if (slug && SETTINGS_SECTION_SLUGS[slug]) return slug;
    try {
      const fromUrl = new URL(link.href, window.location.origin).searchParams.get("section");
      slug = String(fromUrl || "").trim().toLowerCase();
      if (slug && SETTINGS_SECTION_SLUGS[slug]) return slug;
    } catch {
      /* ignore */
    }
    const sectionId = String(link.getAttribute("data-section-id") || "").trim();
    return SETTINGS_SLUG_BY_SECTION_ID[sectionId] || "";
  }

  for (const link of links) {
    link.addEventListener("click", (event) => {
      const slug = slugFromNavLink(link);
      if (!slug || !SETTINGS_SECTION_SLUGS[slug]) return;
      if (
        event.metaKey ||
        event.ctrlKey ||
        event.shiftKey ||
        event.altKey ||
        event.button !== 0
      ) {
        return;
      }
      event.preventDefault();
      showSection(slug, { replaceUrl: true });
    });
  }

  main.addEventListener("click", (event) => {
    const anchor = event.target.closest?.('a[href^="#"]');
    if (!anchor || !main.contains(anchor)) return;
    const id = String(anchor.getAttribute("href") || "").replace(/^#/, "");
    const slug = SETTINGS_SLUG_BY_SECTION_ID[id];
    if (!slug) return;
    event.preventDefault();
    showSection(slug, { replaceUrl: true });
  });

  window.addEventListener("popstate", () => {
    showSection(resolveSlug(), { replaceUrl: false });
  });

  const initial = resolveSlug();
  const hash = String(window.location.hash || "").replace(/^#/, "");
  if (hash && !window.location.search.includes("section=")) {
    const fromHash = SETTINGS_SECTION_SLUGS[hash]
      ? hash
      : SETTINGS_SLUG_BY_SECTION_ID[hash];
    if (fromHash) {
      showSection(fromHash, { replaceUrl: true });
      return;
    }
  }
  if (!window.location.search.includes("section=")) {
    showSection(initial, { replaceUrl: true });
  } else {
    showSection(initial, { replaceUrl: false });
  }
})();

/**
 * Merge Fields admin section: built-in contact tokens (read-only) plus custom
 * fields loaded from the API with add / edit / delete.
 */
const BUILT_IN_MERGE_FIELD_CATALOG = [
  { slug: "full_name", label: "Full name", source: "Contact record" },
  { slug: "first_name", label: "First name", source: "Contact record" },
  { slug: "last_name", label: "Last name", source: "Contact record" },
  { slug: "age", label: "Age", source: "Contact record" },
  { slug: "email", label: "Email", source: "Contact record" },
  { slug: "phone", label: "Phone", source: "Contact record" },
  { slug: "state", label: "State", source: "Contact record" },
  { slug: "date_of_contact", label: "Date of contact", source: "Contact record" },
  { slug: "quote", label: "Quote", source: "Contact record" },
  { slug: "policy_number", label: "Policy number", source: "Contact record (Policy Number)" },
  { slug: "coverage_start_date", label: "Coverage start date", source: "Contact record" },
  { slug: "policy_renewal", label: "Policy renewal date", source: "Contact record" },
  { slug: "upon_approval", label: "Upon approval", source: "Contact record" },
  { slug: "vcall", label: "Verification call", source: "Contact record" },
  { slug: "insurance_type", label: "Insurance type", source: "Contact record" },
  { slug: "good_through", label: "Good through", source: "Auto (today + 7 days)" },
  { slug: "agent_name", label: "Your name", source: "Your agent info (above)" },
  { slug: "agent_phone", label: "Your phone", source: "Your agent info (above)" }
];

const agentProfileForm = document.getElementById("agentProfileForm");
const agentProfileMessage = document.getElementById("agentProfileMessage");

function showAgentProfileMessage(text, isError = false) {
  if (!agentProfileMessage) return;
  agentProfileMessage.textContent = String(text || "");
  agentProfileMessage.style.color = isError ? "#c62828" : "#1b5e20";
}

async function loadAgentProfile() {
  if (!agentNameInput && !agentPhoneInput) return;
  try {
    const data = await fetchApiJson("/api/runtime/agent-profile");
    if (agentNameInput) agentNameInput.value = String(data?.agentName || "");
    if (agentPhoneInput) agentPhoneInput.value = String(data?.agentPhone || "");
    const smsEndingInput = document.getElementById("smsEndingInput");
    if (smsEndingInput && typeof data?.smsEnding === "string") smsEndingInput.value = data.smsEnding;
  } catch (error) {
    showAgentProfileMessage(error.message || "Could not load agent info.", true);
  }
}

if (agentProfileForm) {
  agentProfileForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      const agentName = String(agentNameInput?.value || "").trim();
      const agentPhone = String(agentPhoneInput?.value || "").trim();
      const smsEndingInput = document.getElementById("smsEndingInput");
      const smsEnding = String(smsEndingInput?.value || "").trim();
      await fetchApiJson("/api/runtime/agent-profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ agentName, agentPhone, smsEnding })
      });
      showAgentProfileMessage("Saved.");
    } catch (error) {
      showAgentProfileMessage(error.message || "Failed to save agent info.", true);
    }
  });
}

const customMergeFieldsAddForm = document.getElementById("customMergeFieldsAddForm");
const customMergeKeyInput = document.getElementById("customMergeKeyInput");
const customMergeValueInput = document.getElementById("customMergeValueInput");
const customMergeLabelInput = document.getElementById("customMergeLabelInput");
const customMergeScopeSelect = document.getElementById("customMergeScopeSelect");
const customMergeValueFieldWrap = document.getElementById("customMergeValueFieldWrap");
const customMergeFieldsMessage = document.getElementById("customMergeFieldsMessage");
const customMergeFieldsTableBody = document.getElementById("customMergeFieldsTableBody");
const builtinMergeFieldsTableBody = document.getElementById("builtinMergeFieldsTableBody");

function getAddMergeFieldScope() {
  return String(customMergeScopeSelect?.value || "contact").toLowerCase() === "shared" ? "shared" : "contact";
}

function syncAddMergeFieldValueVisibility() {
  const isContact = getAddMergeFieldScope() === "contact";
  if (customMergeValueFieldWrap) {
    customMergeValueFieldWrap.hidden = isContact;
    customMergeValueFieldWrap.classList.toggle("is-hidden", isContact);
  }
  if (customMergeValueInput) {
    customMergeValueInput.required = !isContact;
    if (isContact) customMergeValueInput.value = "";
  }
}

function renderBuiltInMergeFieldsRows() {
  if (!builtinMergeFieldsTableBody) return;
  builtinMergeFieldsTableBody.innerHTML = BUILT_IN_MERGE_FIELD_CATALOG.map((def) => {
    const slug = escapeHtmlText(def.slug);
    const label = escapeHtmlText(def.label);
    const source = escapeHtmlText(def.source);
    return `
      <tr class="merge-row-builtin">
        <td><span class="merge-token">{{${slug}}}</span></td>
        <td>${label}</td>
        <td class="merge-source-cell">${source}</td>
      </tr>
    `;
  }).join("");
}

function showCustomMergeMessage(text, isError = false) {
  if (!customMergeFieldsMessage) return;
  customMergeFieldsMessage.textContent = text || "";
  customMergeFieldsMessage.style.color = isError ? "#b91c1c" : "#047857";
}

function maybeRefreshComposerCustomMergeCache() {
  try {
    const fn = window.__cadenceRefreshCustomMergeFields;
    if (typeof fn === "function") fn();
  } catch {
    // Ignore — composer page just won't see new fields until next load.
  }
}

function mergeFieldRowHtml(row) {
  const id = Number(row.id);
  const key = escapeHtmlText(row.field_key || "");
  const keySize = Math.max(10, Math.min(64, String(row.field_key || "").length + 2));
  const label = escapeHtmlText(row.label || "");
  const value = escapeHtmlText(row.field_value || "");
  const isContact = String(row.field_scope || "").toLowerCase() === "contact";
  const valueCell = isContact
    ? `<td class="merge-type-cell">On Contact Details</td>`
    : `
          <td>
            <input
              class="merge-value-input"
              type="text"
              value="${value}"
              aria-label="Value for ${key}"
              data-field="value"
              data-id="${id}"
            />
          </td>`;
  return `
        <tr data-id="${id}" class="merge-row-custom" data-scope="${isContact ? "contact" : "shared"}">
          <td>
            <div class="merge-token-edit">
              <span class="merge-token-prefix">{{</span>
              <input
                class="merge-key-input"
                type="text"
                value="${key}"
                size="${keySize}"
                maxlength="64"
                aria-label="Token key for ${key}"
                data-field="key"
                data-id="${id}"
              />
              <span class="merge-token-prefix">}}</span>
            </div>
          </td>
          <td>
            <input
              class="merge-label-input"
              type="text"
              value="${label}"
              maxlength="120"
              aria-label="Label for ${key}"
              data-field="label"
              data-id="${id}"
            />
          </td>
          <td class="merge-type-cell">${isContact ? "Per contact" : "Everyone"}</td>
          ${valueCell}
          <td>
            <div class="merge-row-actions">
              <button
                type="button"
                class="merge-save-btn"
                data-action="save"
                data-id="${id}"
                disabled
              >Save</button>
              <button
                type="button"
                class="merge-delete-btn"
                data-action="delete"
                data-id="${id}"
              >Delete</button>
            </div>
          </td>
        </tr>
      `;
}

function renderCustomMergeFieldsRows(rows) {
  if (!customMergeFieldsTableBody) return;
  const list = Array.isArray(rows) ? rows.filter(Boolean) : [];
  if (!list.length) {
    customMergeFieldsTableBody.innerHTML = `
      <tr><td colspan="5" class="merge-empty">No custom merge fields yet. Add one above.</td></tr>
    `;
    return;
  }
  customMergeFieldsTableBody.innerHTML = list.map((row) => mergeFieldRowHtml(row)).join("");
}

async function loadCustomMergeFields() {
  renderBuiltInMergeFieldsRows();
  if (!customMergeFieldsTableBody) return;
  customMergeFieldsTableBody.innerHTML = `
    <tr><td colspan="5" class="merge-empty">Loading your merge fields...</td></tr>
  `;
  try {
    const rows = await fetchApiJson("/api/custom-merge-fields");
    const list = Array.isArray(rows) ? rows.filter(Boolean) : [];
    renderCustomMergeFieldsRows(list);
    rebuildSignatureMergeFieldDropdownCustomGroup(
      list.map((row) => ({
        field_key: row?.field_key,
        label: row?.label
      }))
    );
  } catch (err) {
    customMergeFieldsTableBody.innerHTML = `
      <tr><td colspan="5" class="merge-empty">Failed to load: ${escapeHtmlText(err.message || String(err))}</td></tr>
    `;
    rebuildSignatureMergeFieldDropdownCustomGroup([]);
  }
}

if (customMergeFieldsAddForm) {
  customMergeScopeSelect?.addEventListener("change", syncAddMergeFieldValueVisibility);
  syncAddMergeFieldValueVisibility();
  customMergeFieldsAddForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const rawKey = String(customMergeKeyInput?.value || "").trim();
    const scope = getAddMergeFieldScope();
    const value = scope === "contact" ? "" : String(customMergeValueInput?.value || "");
    const label = String(customMergeLabelInput?.value || "").trim();
    if (!rawKey) {
      showCustomMergeMessage("Enter a key (token name).", true);
      return;
    }
    if (scope === "shared" && !String(value).trim()) {
      showCustomMergeMessage("Enter a value, or choose “Different for each contact.”", true);
      return;
    }
    showCustomMergeMessage("Saving...", false);
    try {
      await fetchApiJson("/api/custom-merge-fields", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ field_key: rawKey, field_value: value, label, field_scope: scope })
      });
      if (customMergeKeyInput) customMergeKeyInput.value = "";
      if (customMergeValueInput) customMergeValueInput.value = "";
      if (customMergeLabelInput) customMergeLabelInput.value = "";
      showCustomMergeMessage(
        scope === "contact"
          ? "Per-contact field added. Open a contact to fill in the value."
          : "Shared merge field added."
      );
      await loadCustomMergeFields();
      maybeRefreshComposerCustomMergeCache();
    } catch (err) {
      showCustomMergeMessage(err.message || "Failed to add merge field.", true);
    }
  });
}

function bindMergeFieldTableEvents(tbody) {
  if (!tbody) return;
  tbody.addEventListener("input", (event) => {
    const target = event.target;
    if (!(target instanceof HTMLInputElement)) return;
    const id = Number(target.getAttribute("data-id"));
    if (!Number.isInteger(id) || id < 1) return;
    const row = tbody.querySelector(`tr[data-id="${id}"]`);
    const saveBtn = row?.querySelector('button[data-action="save"]');
    if (saveBtn) saveBtn.disabled = false;
  });

  tbody.addEventListener("click", async (event) => {
    const btn = event.target instanceof HTMLElement ? event.target.closest("button[data-action]") : null;
    if (!btn || !tbody.contains(btn)) return;
    const action = btn.getAttribute("data-action");
    const id = Number(btn.getAttribute("data-id"));
    if (!Number.isInteger(id) || id < 1) return;

    if (action === "delete") {
      const row = tbody.querySelector(`tr[data-id="${id}"]`);
      const keyInput = row?.querySelector(`input.merge-key-input[data-id="${id}"]`);
      const tokenName = String(keyInput?.value || "this merge field").trim() || "this merge field";
      if (!confirm(`Delete {{${tokenName}}}? This cannot be undone.`)) return;
      showCustomMergeMessage("Deleting...", false);
      try {
        await fetchApiJson(`/api/custom-merge-fields/${id}`, { method: "DELETE" });
        showCustomMergeMessage("Merge field deleted.");
        await loadCustomMergeFields();
        maybeRefreshComposerCustomMergeCache();
      } catch (err) {
        showCustomMergeMessage(err.message || "Failed to delete.", true);
      }
      return;
    }

    if (action === "save") {
      const row = tbody.querySelector(`tr[data-id="${id}"]`);
      const keyInput = row?.querySelector(`input.merge-key-input[data-id="${id}"]`);
      const valueInput = row?.querySelector(`input.merge-value-input[data-id="${id}"]`);
      const labelInput = row?.querySelector(`input.merge-label-input[data-id="${id}"]`);
      const scope = String(row?.getAttribute("data-scope") || "shared");
      const body = {
        field_key: String(keyInput?.value || "").trim(),
        field_value: scope === "contact" ? "" : String(valueInput?.value || ""),
        label: String(labelInput?.value || "").trim(),
        field_scope: scope === "contact" ? "contact" : "shared"
      };
      if (!body.field_key) {
        showCustomMergeMessage("Enter a key (token name) before saving.", true);
        return;
      }
      showCustomMergeMessage("Saving...", false);
      try {
        await fetchApiJson(`/api/custom-merge-fields/${id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body)
        });
        btn.disabled = true;
        showCustomMergeMessage("Merge field updated.");
        maybeRefreshComposerCustomMergeCache();
      } catch (err) {
        showCustomMergeMessage(err.message || "Failed to save.", true);
      }
    }
  });
}

bindMergeFieldTableEvents(customMergeFieldsTableBody);

loadAgentProfile();
loadCustomMergeFields();

window.cadenceSettingsSectionHooks = window.cadenceSettingsSectionHooks || {};
window.cadenceSettingsSectionHooks["merge-fields"] = () => {
  void loadAgentProfile();
  void loadCustomMergeFields();
};
window.cadenceSettingsSectionHooks.labels = () => {
  void loadContactWorkspaceLabelsSettings();
};

const QUICK_FILTER_FIELD_DEFS_BASE = [
  { value: "tags", label: "Tags" },
  { value: "status", label: "Status" },
  { value: "outcome", label: "Outcome" },
  { value: "lead_source", label: "Lead Source" },
  { value: "insurance_type", label: "Insurance Type" }
];
const QUICK_FILTER_FIELD_INDIAN_OWNER = { value: "indian", label: "Indian" };

const SORT_BY_FIELD_INDIAN_OWNER = { value: "indian", label: "Indian" };

function getQuickFilterFieldDefs() {
  const catalog = window.CrmContactWorkspaceOptions?.getQuickFilterFieldCatalog?.();
  if (Array.isArray(catalog) && catalog.length) {
    return catalog.map((f) => ({ ...f }));
  }
  const fields = QUICK_FILTER_FIELD_DEFS_BASE.map((f) => ({ ...f }));
  if (!window.__CRM_OMIT_INDIAN_WORKSPACE__) {
    fields.push({ ...QUICK_FILTER_FIELD_INDIAN_OWNER });
  }
  return fields;
}

function getQuickFilterValueSet() {
  return new Set(getQuickFilterFieldDefs().map((f) => f.value));
}

function getSortByFieldDefs() {
  const catalog = window.CrmContactWorkspaceOptions?.getSortByFieldCatalog?.();
  if (Array.isArray(catalog) && catalog.length) {
    return catalog.map((f) => ({ ...f }));
  }
  const fields = (window.CrmContactWorkspaceOptions?.defaults?.sortByOptions || []).map((f) => ({ ...f }));
  if (!fields.length) return [{ value: "newest", label: "Newest" }];
  if (!window.__CRM_OMIT_INDIAN_WORKSPACE__ && !fields.some((f) => f.value === "indian")) {
    fields.push({ ...SORT_BY_FIELD_INDIAN_OWNER });
  }
  return fields;
}

function getSortByValueSet() {
  return new Set(getSortByFieldDefs().map((f) => f.value));
}

const contactWorkspaceLabelsForm = document.getElementById("contactWorkspaceLabelsForm");
const contactWorkspaceQuickFilterList = document.getElementById("contactWorkspaceQuickFilterList");
const contactWorkspaceSortByList = document.getElementById("contactWorkspaceSortByList");
const contactWorkspaceStatusList = document.getElementById("contactWorkspaceStatusList");
const contactWorkspaceOutcomeList = document.getElementById("contactWorkspaceOutcomeList");
const contactWorkspaceLeadSourceList = document.getElementById("contactWorkspaceLeadSourceList");
const contactWorkspaceLabelsMessage = document.getElementById("contactWorkspaceLabelsMessage");

function showContactWorkspaceLabelsMessage(text, isError) {
  const messageEl = document.getElementById("contactWorkspaceLabelsMessage");
  if (messageEl) {
    messageEl.textContent = text || "";
    messageEl.style.color = isError ? "#b91c1c" : "#047857";
  }
  /* Errors also surface in the floating save bar so feedback appears right
     where the user clicked, not below the fold. */
  if (isError && text && typeof setContactWorkspaceStickyStatus === "function") {
    setContactWorkspaceStickyStatus(String(text), "error");
  }
}

function getContactWorkspaceSortByListEl() {
  return document.getElementById("contactWorkspaceSortByList");
}

function defaultLabelForQuickFilterValue(value) {
  const found = getQuickFilterFieldDefs().find((f) => f.value === value);
  return found ? found.label : value;
}

function defaultLabelForSortByValue(value) {
  const found = getSortByFieldDefs().find((f) => f.value === value);
  return found ? found.label : value;
}

function buildQuickFilterFieldSelectOptions(selectedValue) {
  return getQuickFilterFieldDefs().map((f) => {
    const sel = f.value === selectedValue ? " selected" : "";
    return `<option value="${escapeAttr(f.value)}"${sel}>${escapeAttr(f.label)}</option>`;
  })    .join("");
}

function buildSortByFieldSelectOptions(selectedValue, usedByOtherRows = null) {
  const selected = String(selectedValue || "").trim();
  const blocked =
    usedByOtherRows instanceof Set ? usedByOtherRows : new Set(usedByOtherRows || []);
  const defs = getSortByFieldDefs().filter((f) => f.value === selected || !blocked.has(f.value));
  const knownValues = new Set(defs.map((f) => f.value));
  let html = defs
    .map((f) => {
      const sel = f.value === selected ? " selected" : "";
      return `<option value="${escapeAttr(f.value)}"${sel}>${escapeAttr(f.label)}</option>`;
    })
    .join("");
  if (selected && !knownValues.has(selected)) {
    const orphan = `<option value="${escapeAttr(selected)}" selected>${escapeAttr(
      defaultLabelForSortByValue(selected)
    )}</option>`;
    html = orphan + html;
  }
  return html;
}

function buildSortByFieldSelectOptionsForNewRow(usedValues) {
  const used = usedValues instanceof Set ? usedValues : new Set(usedValues || []);
  const unused = getSortByFieldDefs().filter((f) => !used.has(f.value));
  const options = unused
    .map((f) => `<option value="${escapeAttr(f.value)}">${escapeAttr(f.label)}</option>`)
    .join("");
  return `<option value="" selected disabled>Choose sort field…</option>${options}`;
}

function hasEmptySortByRowsInDom() {
  const listEl = getContactWorkspaceSortByListEl();
  if (!listEl) return false;
  return [...listEl.querySelectorAll(".crm-sort-by-value")].some((select) => !String(select.value || "").trim());
}

function dedupeSortByRows(fields) {
  const out = [];
  const seen = new Set();
  for (const row of Array.isArray(fields) ? fields : []) {
    const value = String(row?.value || "").trim();
    if (!value || seen.has(value)) continue;
    seen.add(value);
    const label = String(row?.label || "").trim() || defaultLabelForSortByValue(value);
    out.push({ value, label });
  }
  return out;
}

function sortByOptionValues(options) {
  return (Array.isArray(options) ? options : []).map((row) => String(row?.value || "").trim()).filter(Boolean);
}

function findMissingSortByOptions(submitted, verified) {
  const verifiedSet = new Set(sortByOptionValues(verified));
  return sortByOptionValues(submitted).filter((value) => !verifiedSet.has(value));
}

function quickFilterOptionValues(options) {
  return (Array.isArray(options) ? options : []).map((row) => String(row?.value || "").trim()).filter(Boolean);
}

function findMissingQuickFilterOptions(submitted, verified) {
  const verifiedSet = new Set(quickFilterOptionValues(verified));
  return quickFilterOptionValues(submitted).filter((value) => !verifiedSet.has(value));
}

function labelsMissingFromVerified(submitted, verified) {
  const verifiedSet = new Set(
    (Array.isArray(verified) ? verified : []).map((label) => String(label || "").trim().toLowerCase()).filter(Boolean)
  );
  return (Array.isArray(submitted) ? submitted : [])
    .map((label) => String(label || "").trim())
    .filter((label) => label && !verifiedSet.has(label.toLowerCase()));
}

/* ── Chip label editor: usage counts, sticky save bar, drag-to-reorder ──── */
let contactWorkspaceUsage = { status: {}, outcome: {}, leadSource: {} };
let contactWorkspaceStickyBar = null;

function usageKindForList(listEl) {
  if (listEl === contactWorkspaceStatusList) return "status";
  if (listEl === contactWorkspaceOutcomeList) return "outcome";
  if (listEl === contactWorkspaceLeadSourceList) return "leadSource";
  return "";
}

function usageCountFor(kindKey, label) {
  if (!kindKey) return 0;
  const map = contactWorkspaceUsage?.[kindKey] || {};
  return Number(map[String(label || "").trim().toLowerCase()] || 0);
}

async function fetchContactWorkspaceUsage() {
  try {
    const usage = await fetchApiJson("/api/settings/contact-workspace-options/usage");
    contactWorkspaceUsage = {
      status: usage?.status || {},
      outcome: usage?.outcome || {},
      leadSource: usage?.leadSource || {}
    };
  } catch {
    contactWorkspaceUsage = { status: {}, outcome: {}, leadSource: {} };
  }
}

function markContactWorkspaceDirty() {
  contactWorkspaceStickyBar?.classList.add("is-visible");
}

let contactWorkspaceStickyHideTimer = null;

function clearContactWorkspaceDirty() {
  window.clearTimeout(contactWorkspaceStickyHideTimer);
  if (!contactWorkspaceStickyBar) return;
  contactWorkspaceStickyBar.classList.remove("is-visible", "is-saving", "is-saved", "is-error");
  const status = contactWorkspaceStickyBar.querySelector(".crm-labels-sticky-bar-status");
  if (status) status.textContent = "";
  const saveBtn = contactWorkspaceStickyBar.querySelector(".crm-labels-sticky-bar-save");
  if (saveBtn) saveBtn.disabled = false;
}

/** Feedback inside the floating bar: kind = "saving" | "saved" | "error" | "". */
function setContactWorkspaceStickyStatus(text, kind) {
  if (!contactWorkspaceStickyBar) return;
  window.clearTimeout(contactWorkspaceStickyHideTimer);
  contactWorkspaceStickyBar.classList.remove("is-saving", "is-saved", "is-error");
  const status = contactWorkspaceStickyBar.querySelector(".crm-labels-sticky-bar-status");
  if (status) status.textContent = text || "";
  const saveBtn = contactWorkspaceStickyBar.querySelector(".crm-labels-sticky-bar-save");
  if (saveBtn) saveBtn.disabled = kind === "saving";
  if (kind) {
    contactWorkspaceStickyBar.classList.add(`is-${kind}`, "is-visible");
  }
  if (kind === "saved") {
    contactWorkspaceStickyHideTimer = window.setTimeout(() => clearContactWorkspaceDirty(), 2600);
  }
}

function ensureContactWorkspaceStickyBar() {
  if (contactWorkspaceStickyBar || !contactWorkspaceLabelsForm) return;
  const bar = document.createElement("div");
  bar.className = "crm-labels-sticky-bar";
  bar.innerHTML = `<span class="crm-labels-sticky-bar-text">Unsaved label changes</span>
    <span class="crm-labels-sticky-bar-status" role="status" aria-live="polite"></span>
    <button type="button" class="crm-labels-sticky-bar-save">Save Contact Workspace labels</button>`;
  bar.querySelector("button")?.addEventListener("click", () => {
    if (typeof contactWorkspaceLabelsForm.requestSubmit === "function") {
      contactWorkspaceLabelsForm.requestSubmit();
    } else {
      contactWorkspaceLabelsForm.dispatchEvent(new Event("submit", { cancelable: true }));
    }
  });
  document.body.appendChild(bar);
  contactWorkspaceStickyBar = bar;
}

function wireChipDragReorder(listEl) {
  if (!listEl || listEl.dataset.dragWired === "1") return;
  listEl.dataset.dragWired = "1";
  let dragged = null;
  listEl.addEventListener("dragstart", (event) => {
    const chip = event.target?.closest?.(".crm-label-chip[draggable='true']");
    if (!chip) return;
    dragged = chip;
    chip.classList.add("is-dragging");
    try {
      event.dataTransfer.effectAllowed = "move";
      event.dataTransfer.setData("text/plain", "");
    } catch {
      /* ignore */
    }
  });
  listEl.addEventListener("dragover", (event) => {
    if (!dragged) return;
    event.preventDefault();
    const over = event.target?.closest?.(".crm-label-chip");
    if (!over || over === dragged || over.parentElement !== listEl) return;
    const rect = over.getBoundingClientRect();
    const before = event.clientX < rect.left + rect.width / 2;
    listEl.insertBefore(dragged, before ? over : over.nextSibling);
  });
  const finishDrag = () => {
    if (!dragged) return;
    dragged.classList.remove("is-dragging");
    dragged = null;
    markContactWorkspaceDirty();
  };
  listEl.addEventListener("drop", (event) => {
    event.preventDefault();
    finishDrag();
  });
  listEl.addEventListener("dragend", finishDrag);
}

function chipHtml({ kind, value, label, count = 0, draggable = true, renamable = false }) {
  const countHtml =
    count > 0
      ? `<span class="crm-label-chip-count" title="${count} contact${count === 1 ? "" : "s"} currently use this value">${count}</span>`
      : "";
  const renameAttrs = renamable ? ` data-renamable="1" title="Click name to rename · drag to reorder"` : "";
  return `<span class="crm-label-chip" data-row-kind="${escapeAttr(kind)}" data-value="${escapeAttr(value)}" draggable="${
    draggable ? "true" : "false"
  }"${renameAttrs}><span class="crm-label-chip-text">${escapeAttr(label)}</span>${countHtml}<button type="button" class="crm-label-chip-x" data-action="delete-row" aria-label="Remove ${escapeAttr(label)}">&times;</button></span>`;
}

function chipAddSelectHtml(ariaLabel, defs) {
  /* Always render the picker so the affordance is consistent across lists.
     When every field is already added there is nothing to choose, so show a
     disabled "All fields added" state instead of the picker disappearing. */
  if (!defs.length) {
    return `<select class="crm-label-chip-add-select crm-label-chip-add-select--full" aria-label="${escapeAttr(
      ariaLabel
    )}" disabled title="Every available field is already added"><option>All fields added ✓</option></select>`;
  }
  const opts = defs
    .map((f) => `<option value="${escapeAttr(f.value)}">${escapeAttr(f.label)}</option>`)
    .join("");
  return `<select class="crm-label-chip-add-select" aria-label="${escapeAttr(ariaLabel)}"><option value="" selected>+ Add field…</option>${opts}</select>`;
}

function renderSortByRows(fields) {
  const listEl = getContactWorkspaceSortByListEl();
  if (!listEl) return;
  let rows = dedupeSortByRows(fields);
  if (window.__CRM_OMIT_INDIAN_WORKSPACE__) {
    rows = rows.filter((row) => String(row?.value || "").trim() !== "indian");
  }
  listEl.classList.add("crm-label-chip-list");
  const used = new Set(rows.map((row) => String(row.value || "").trim()));
  let unused = getSortByFieldDefs().filter((f) => !used.has(f.value));
  if (window.__CRM_OMIT_INDIAN_WORKSPACE__) {
    unused = unused.filter((f) => f.value !== "indian");
  }
  const chips = rows
    .map((row) => {
      const value = String(row.value || "").trim();
      return chipHtml({ kind: "sort-by", value, label: defaultLabelForSortByValue(value) });
    })
    .join("");
  listEl.innerHTML =
    (chips || `<p class="hint" style="margin:0">No Sort By options yet — pick one below.</p>`) +
    chipAddSelectHtml("Add sort field", unused);
  listEl.querySelector(".crm-label-chip-add-select")?.addEventListener("change", (event) => {
    const value = String(event.target.value || "").trim();
    if (!value) return;
    const current = collectSortByFromDom();
    current.push({ value, label: defaultLabelForSortByValue(value) });
    renderSortByRows(current);
    markContactWorkspaceDirty();
    showContactWorkspaceLabelsMessage("");
  });
  wireChipDragReorder(listEl);
}

async function fetchContactWorkspaceLabelsFromServer() {
  return fetchApiJson("/api/settings/contact-workspace-options");
}

function renderQuickFilterRows(fields) {
  if (!contactWorkspaceQuickFilterList) return;
  let rows = Array.isArray(fields) ? fields : [];
  if (window.__CRM_OMIT_INDIAN_WORKSPACE__) {
    rows = rows.filter((row) => String(row?.value || "").trim() !== "indian");
  }
  contactWorkspaceQuickFilterList.classList.add("crm-label-chip-list");
  const used = new Set(rows.map((row) => String(row?.value || "").trim()));
  let unused = getQuickFilterFieldDefs().filter((f) => !used.has(f.value));
  if (window.__CRM_OMIT_INDIAN_WORKSPACE__) {
    unused = unused.filter((f) => f.value !== "indian");
  }
  const chips = rows
    .map((row) => {
      const value = String(row?.value || "").trim();
      return chipHtml({ kind: "quick-filter", value, label: defaultLabelForQuickFilterValue(value) });
    })
    .join("");
  contactWorkspaceQuickFilterList.innerHTML =
    (chips || `<p class="hint" style="margin:0">No Quick Filter fields yet — pick one below.</p>`) +
    chipAddSelectHtml("Add Quick Filter field", unused);
  contactWorkspaceQuickFilterList.querySelector(".crm-label-chip-add-select")?.addEventListener("change", (event) => {
    const value = String(event.target.value || "").trim();
    if (!value) return;
    const current = collectQuickFilterFromDom();
    current.push({ value, label: defaultLabelForQuickFilterValue(value) });
    renderQuickFilterRows(current);
    markContactWorkspaceDirty();
    showContactWorkspaceLabelsMessage("");
  });
  wireChipDragReorder(contactWorkspaceQuickFilterList);
}

function renderLabelRows(listEl, labels, placeholder) {
  if (!listEl) return;
  const rows = (Array.isArray(labels) ? labels : []).map((label) => String(label || "").trim()).filter(Boolean);
  const kindKey = usageKindForList(listEl);
  /* Lead sources are kept alphabetical (the list is rebuilt from contacts), so
     dragging them would not stick — only status/outcome order is meaningful. */
  const draggable = listEl !== contactWorkspaceLeadSourceList;
  listEl.classList.add("crm-label-chip-list");
  const chips = rows
    .map((label) =>
      chipHtml({
        kind: "label",
        value: label,
        label,
        count: usageCountFor(kindKey, label),
        draggable,
        renamable: true
      })
    )
    .join("");
  listEl.innerHTML = `${chips}<input type="text" class="crm-label-chip-add-input" placeholder="+ Add — type &amp; press Enter" aria-label="Add ${escapeAttr(placeholder)}" />`;
  wireChipDragReorder(listEl);
}

function collectQuickFilterFromDom() {
  if (!contactWorkspaceQuickFilterList) return [];
  const out = [];
  const seen = new Set();
  contactWorkspaceQuickFilterList.querySelectorAll(".crm-label-chip[data-row-kind='quick-filter']").forEach((chip) => {
    const value = String(chip.dataset.value || "").trim();
    if (!getQuickFilterValueSet().has(value) || seen.has(value)) return;
    seen.add(value);
    const label = defaultLabelForQuickFilterValue(value);
    out.push({ value, label });
  });
  return out;
}

function collectSortByFromDom() {
  const listEl = getContactWorkspaceSortByListEl();
  if (!listEl) return [];
  const out = [];
  const seen = new Set();
  listEl.querySelectorAll(".crm-label-chip[data-row-kind='sort-by']").forEach((chip) => {
    const value = String(chip.dataset.value || "").trim();
    if (!value || seen.has(value)) return;
    seen.add(value);
    out.push({ value, label: defaultLabelForSortByValue(value) });
  });
  return out;
}

function mergeLeadSourceLabelLists(configured, inUse) {
  const out = [];
  const seen = new Set();
  for (const item of [...(Array.isArray(configured) ? configured : []), ...(Array.isArray(inUse) ? inUse : [])]) {
    const label = String(item || "").trim();
    if (!label) continue;
    const key = label.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(label);
  }
  return out.sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));
}

async function fetchLeadSourcesInUse() {
  try {
    const payload = await fetchApiJson("/api/contacts/lead-sources-in-use");
    return Array.isArray(payload?.leadSources) ? payload.leadSources : [];
  } catch {
    return [];
  }
}

function collectLabelsFromDom(listEl) {
  if (!listEl) return [];
  const out = [];
  const seen = new Set();
  listEl.querySelectorAll(".crm-label-chip[data-row-kind='label']").forEach((chip) => {
    /* A chip mid-rename holds its current text in an inline input. */
    const editInput = chip.querySelector(".crm-label-chip-edit");
    const label = String(editInput ? editInput.value : chip.dataset.value || "").trim();
    if (!label) return;
    const key = label.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    out.push(label);
  });
  return out;
}

function renderContactWorkspaceLabelsEditor(options, { inUseLeadSources = [] } = {}) {
  const defaults = window.CrmContactWorkspaceOptions?.defaults || {};
  const quickFilterFields =
    options?.quickFilterFields?.length
      ? options.quickFilterFields
      : defaults.quickFilterFields || getQuickFilterFieldDefs();
  const sortByOptions =
    options?.sortByOptions?.length
      ? options.sortByOptions
      : defaults.sortByOptions || getSortByFieldDefs();
  const statusLabels = options?.statusLabels?.length ? options.statusLabels : defaults.statusLabels || [];
  const outcomeLabels = options?.outcomeLabels?.length ? options.outcomeLabels : defaults.outcomeLabels || [];
  const configuredLeadSources = options?.leadSourceLabels?.length
    ? options.leadSourceLabels
    : defaults.leadSourceLabels || [];
  renderQuickFilterRows(quickFilterFields);
  renderSortByRows(sortByOptions);
  renderLabelRows(contactWorkspaceStatusList, statusLabels, "Status label");
  renderLabelRows(contactWorkspaceOutcomeList, outcomeLabels, "Outcome label");
  renderLabelRows(
    contactWorkspaceLeadSourceList,
    mergeLeadSourceLabelLists(configuredLeadSources, inUseLeadSources),
    "Lead source label"
  );
}

async function restoreContactWorkspaceLabelsFromServer() {
  const restored = await fetchApiJson("/api/settings/contact-workspace-options/restore", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: "{}"
  });
  if (window.CrmContactWorkspaceOptions && typeof window.CrmContactWorkspaceOptions.setCache === "function") {
    window.CrmContactWorkspaceOptions.setCache(restored);
  }
  return restored;
}

async function loadContactWorkspaceLabelsSettings() {
  if (!contactWorkspaceLabelsForm) return;
  if (window.__CRM_WORKSPACE_UI_READY__) {
    try {
      await window.__CRM_WORKSPACE_UI_READY__;
    } catch {
      /* continue */
    }
  }
  try {
    const options = await fetchApiJson("/api/settings/contact-workspace-options");
    if (window.CrmContactWorkspaceOptions?.setCache) {
      window.CrmContactWorkspaceOptions.setCache(options);
    }
    await fetchContactWorkspaceUsage();
    const inUseLeadSources = await fetchLeadSourcesInUse();
    renderContactWorkspaceLabelsEditor(options, { inUseLeadSources });
    clearContactWorkspaceDirty();
    showContactWorkspaceLabelsMessage("");
  } catch (error) {
    renderContactWorkspaceLabelsEditor(window.CrmContactWorkspaceOptions?.defaults || {});
    showContactWorkspaceLabelsMessage(
      (error.message || "Failed to load Contact Workspace labels.") +
        " Click Restore labels from contacts to rebuild, then Save.",
      true
    );
  }
}

function contactWorkspacePersistedShapeError(persisted) {
  if (!persisted || typeof persisted !== "object") {
    return "Server returned no saved label data.";
  }
  const missing = [];
  if (!Array.isArray(persisted.quickFilterFields) || !persisted.quickFilterFields.length) {
    missing.push("Quick Filter fields");
  }
  if (!Array.isArray(persisted.sortByOptions) || !persisted.sortByOptions.length) {
    missing.push("Sort By options");
  }
  if (!Array.isArray(persisted.statusLabels) || !persisted.statusLabels.length) {
    missing.push("Status labels");
  }
  if (!Array.isArray(persisted.outcomeLabels) || !persisted.outcomeLabels.length) {
    missing.push("Outcome labels");
  }
  if (!Array.isArray(persisted.leadSourceLabels) || !persisted.leadSourceLabels.length) {
    missing.push("Lead Source labels");
  }
  if (!missing.length) return "";
  return `Server response is missing: ${missing.join(", ")}.`;
}

function commitLabelAddInput(addInput) {
  if (!addInput) return false;
  const listEl = addInput.parentElement;
  if (!listEl) return false;
  const label = String(addInput.value || "").trim();
  if (!label) return false;
  const exists = collectLabelsFromDom(listEl).some((item) => item.toLowerCase() === label.toLowerCase());
  if (exists) {
    addInput.value = "";
    showContactWorkspaceLabelsMessage(`"${label}" is already in the list.`, true);
    return false;
  }
  const kindKey = usageKindForList(listEl);
  addInput.insertAdjacentHTML(
    "beforebegin",
    chipHtml({
      kind: "label",
      value: label,
      label,
      count: usageCountFor(kindKey, label),
      draggable: listEl !== contactWorkspaceLeadSourceList,
      renamable: true
    })
  );
  addInput.value = "";
  markContactWorkspaceDirty();
  showContactWorkspaceLabelsMessage("");
  return true;
}

function commitAllPendingLabelAdds() {
  if (!contactWorkspaceLabelsForm) return;
  contactWorkspaceLabelsForm.querySelectorAll(".crm-label-chip-add-input").forEach((input) => {
    commitLabelAddInput(input);
  });
}

function failContactWorkspaceLabelSave(message) {
  showContactWorkspaceLabelsMessage(message, true);
  setContactWorkspaceStickyStatus(message, "error");
}

async function saveContactWorkspaceLabels(event) {
  event.preventDefault();
  commitAllPendingLabelAdds();
  setContactWorkspaceStickyStatus("Saving…", "saving");
  const quickFilterFields = collectQuickFilterFromDom();
  const sortByOptions = collectSortByFromDom();
  const statusLabels = collectLabelsFromDom(contactWorkspaceStatusList);
  const outcomeLabels = collectLabelsFromDom(contactWorkspaceOutcomeList);
  const leadSourceLabels = collectLabelsFromDom(contactWorkspaceLeadSourceList);
  if (hasEmptySortByRowsInDom()) {
    failContactWorkspaceLabelSave("Choose a sort field for each new row, or delete empty rows.");
    return;
  }
  if (!quickFilterFields.length) {
    failContactWorkspaceLabelSave("Add at least one Quick Filter field.");
    return;
  }
  if (!sortByOptions.length) {
    failContactWorkspaceLabelSave("Add at least one Sort By option.");
    return;
  }
  if (!statusLabels.length) {
    failContactWorkspaceLabelSave("Add at least one status label.");
    return;
  }
  if (!outcomeLabels.length) {
    failContactWorkspaceLabelSave("Add at least one outcome label.");
    return;
  }
  if (!leadSourceLabels.length) {
    failContactWorkspaceLabelSave("Add at least one lead source label.");
    return;
  }
  try {
    const submitted = { quickFilterFields, sortByOptions, statusLabels, outcomeLabels, leadSourceLabels };
    const payload = JSON.stringify(submitted);
    const request = {
      headers: { "Content-Type": "application/json" },
      body: payload
    };
    try {
      await fetchApiJson("/api/settings/contact-workspace-options", { ...request, method: "PUT" });
    } catch (error) {
      try {
        await fetchApiJson("/api/settings/contact-workspace-options", { ...request, method: "POST" });
      } catch (postError) {
        throw postError || error;
      }
    }
    const persisted = await fetchContactWorkspaceLabelsFromServer();
    const shapeError = contactWorkspacePersistedShapeError(persisted);
    if (shapeError) {
      throw new Error(
        `${shapeError} Restart the CRM app (or deploy the latest build), then save again.`
      );
    }
    const missingSort = findMissingSortByOptions(submitted.sortByOptions, persisted.sortByOptions);
    if (missingSort.length) {
      throw new Error(
        `These sort options did not save: ${missingSort.map((v) => defaultLabelForSortByValue(v) || v).join(", ")}. Restart the Node app or deploy the latest CRM build, then save again.`
      );
    }
    const missingQuickFilter = findMissingQuickFilterOptions(submitted.quickFilterFields, persisted.quickFilterFields);
    if (missingQuickFilter.length) {
      throw new Error(
        `These Quick Filter fields did not save: ${missingQuickFilter.map((v) => defaultLabelForQuickFilterValue(v) || v).join(", ")}. Restart the Node app or deploy the latest CRM build, then save again.`
      );
    }
    const missingStatus = labelsMissingFromVerified(submitted.statusLabels, persisted.statusLabels);
    if (missingStatus.length) {
      throw new Error(`These status labels did not save: ${missingStatus.join(", ")}. Try saving again.`);
    }
    const missingOutcome = labelsMissingFromVerified(submitted.outcomeLabels, persisted.outcomeLabels);
    if (missingOutcome.length) {
      throw new Error(`These outcome labels did not save: ${missingOutcome.join(", ")}. Try saving again.`);
    }
    if (window.CrmContactWorkspaceOptions && typeof window.CrmContactWorkspaceOptions.setCache === "function") {
      window.CrmContactWorkspaceOptions.setCache(persisted);
    }
    renderQuickFilterRows(persisted.quickFilterFields);
    renderSortByRows(persisted.sortByOptions);
    renderLabelRows(contactWorkspaceStatusList, persisted.statusLabels, "Status label");
    renderLabelRows(contactWorkspaceOutcomeList, persisted.outcomeLabels, "Outcome label");
    const inUseLeadSources = await fetchLeadSourcesInUse().catch(() => []);
    renderLabelRows(
      contactWorkspaceLeadSourceList,
      mergeLeadSourceLabelLists(persisted.leadSourceLabels, inUseLeadSources),
      "Lead source label"
    );
    try {
      window.localStorage.setItem("crm.contactWorkspaceOptions.v1", JSON.stringify(persisted));
    } catch {
      /* ignore */
    }
    showContactWorkspaceLabelsMessage(
      "Contact Workspace labels saved. Open Contacts or refresh contact pages to update dropdowns."
    );
    /* Show the green confirmation in the bar, then slide it away. */
    setContactWorkspaceStickyStatus("✓ Saved", "saved");
  } catch (error) {
    showContactWorkspaceLabelsMessage(error.message || "Failed to save Contact Workspace labels.", true);
    setContactWorkspaceStickyStatus(error.message || "Failed to save Contact Workspace labels.", "error");
  }
}

async function handleRestoreContactWorkspaceLabelsClick() {
  try {
    const restored = await restoreContactWorkspaceLabelsFromServer();
    const inUseLeadSources = await fetchLeadSourcesInUse();
    renderContactWorkspaceLabelsEditor(restored, { inUseLeadSources });
    markContactWorkspaceDirty();
    showContactWorkspaceLabelsMessage(
      "Restored labels from your contacts and Cadence defaults. Review and click Save to keep them.",
      false
    );
  } catch (error) {
    showContactWorkspaceLabelsMessage(error.message || "Failed to restore Contact Workspace labels.", true);
  }
}

function initContactWorkspaceLabelsSettings() {
  if (!contactWorkspaceLabelsForm) return;
  contactWorkspaceLabelsForm.addEventListener("submit", saveContactWorkspaceLabels);
  document.getElementById("contactWorkspaceRestoreLabelsBtn")?.addEventListener(
    "click",
    handleRestoreContactWorkspaceLabelsClick
  );

  const labelPlaceholderForList = (listEl) => {
    if (listEl === contactWorkspaceStatusList) return "Status label";
    if (listEl === contactWorkspaceLeadSourceList) return "Lead source label";
    return "Outcome label";
  };

  const usageNounForList = (listEl) => {
    if (listEl === contactWorkspaceStatusList) return "status";
    if (listEl === contactWorkspaceOutcomeList) return "outcome";
    if (listEl === contactWorkspaceLeadSourceList) return "lead source";
    return "";
  };

  const onDelete = (listEl) => (event) => {
    const btn = event.target?.closest?.("button[data-action='delete-row']");
    if (!btn || !listEl?.contains(btn)) return;
    const chip = btn.closest(".crm-label-chip");
    if (!chip) return;
    const isPending = chip.classList.contains("crm-label-chip--pending");
    const label = String(chip.dataset.value || "").trim();
    const count = usageCountFor(usageKindForList(listEl), label);
    if (!isPending && count > 0) {
      const noun = usageNounForList(listEl) || "value";
      const confirmed = window.confirm(
        `${count} contact${count === 1 ? "" : "s"} currently use the ${noun} "${label}".\n\nRemove it from the dropdown anyway? (Contacts keep their saved value — it just stops being offered.)`
      );
      if (!confirmed) return;
    }
    chip.remove();
    if (listEl === contactWorkspaceQuickFilterList) {
      const remaining = collectQuickFilterFromDom();
      if (!remaining.length) renderQuickFilterRows([]);
    } else if (listEl === contactWorkspaceSortByList) {
      const remaining = collectSortByFromDom();
      if (!remaining.length) renderSortByRows([]);
    } else {
      const remaining = collectLabelsFromDom(listEl);
      if (!remaining.length) renderLabelRows(listEl, [], labelPlaceholderForList(listEl));
    }
    if (!isPending) markContactWorkspaceDirty();
    showContactWorkspaceLabelsMessage("");
  };
  contactWorkspaceQuickFilterList?.addEventListener("click", onDelete(contactWorkspaceQuickFilterList));
  contactWorkspaceSortByList?.addEventListener("click", onDelete(contactWorkspaceSortByList));
  contactWorkspaceStatusList?.addEventListener("click", onDelete(contactWorkspaceStatusList));
  contactWorkspaceOutcomeList?.addEventListener("click", onDelete(contactWorkspaceOutcomeList));
  contactWorkspaceLeadSourceList?.addEventListener("click", onDelete(contactWorkspaceLeadSourceList));

  contactWorkspaceLabelsForm.addEventListener("focusout", (event) => {
    const addInput = event.target?.closest?.(".crm-label-chip-add-input");
    if (!addInput) return;
    commitLabelAddInput(addInput);
  });

  /* Inline add: type in the box at the end of a chip list and press Enter. */
  contactWorkspaceLabelsForm.addEventListener("keydown", (event) => {
    const addInput = event.target?.closest?.(".crm-label-chip-add-input");
    if (addInput && event.key === "Enter") {
      event.preventDefault();
      if (!commitLabelAddInput(addInput)) return;
      if (typeof contactWorkspaceLabelsForm.requestSubmit === "function") {
        contactWorkspaceLabelsForm.requestSubmit();
      } else {
        contactWorkspaceLabelsForm.dispatchEvent(new Event("submit", { cancelable: true }));
      }
      return;
    }
    const editInput = event.target?.closest?.(".crm-label-chip-edit");
    if (editInput) {
      if (event.key === "Enter") {
        event.preventDefault();
        editInput.blur();
      } else if (event.key === "Escape") {
        editInput.dataset.cancel = "1";
        editInput.blur();
      }
    }
  });

  /* Click a chip's name to rename it in place. */
  contactWorkspaceLabelsForm.addEventListener("click", (event) => {
    const textEl = event.target?.closest?.(".crm-label-chip-text");
    const chip = textEl?.closest?.(".crm-label-chip[data-renamable='1']");
    if (!chip || chip.querySelector(".crm-label-chip-edit")) return;
    const listEl = chip.parentElement;
    const original = String(chip.dataset.value || "");
    textEl.outerHTML = `<input type="text" class="crm-label-chip-edit" value="${escapeAttr(original)}" />`;
    const editEl = chip.querySelector(".crm-label-chip-edit");
    editEl.focus();
    editEl.select();
    editEl.addEventListener(
      "blur",
      () => {
        const canceled = editEl.dataset.cancel === "1";
        const next = canceled ? original : String(editEl.value || "").trim() || original;
        chip.dataset.value = next;
        editEl.outerHTML = `<span class="crm-label-chip-text">${escapeAttr(next)}</span>`;
        chip.querySelector(".crm-label-chip-count")?.remove();
        const count = usageCountFor(usageKindForList(listEl), next);
        if (count > 0) {
          chip
            .querySelector(".crm-label-chip-text")
            ?.insertAdjacentHTML(
              "afterend",
              `<span class="crm-label-chip-count" title="${count} contact${count === 1 ? "" : "s"} currently use this value">${count}</span>`
            );
        }
        if (!canceled && next !== original) markContactWorkspaceDirty();
      },
      { once: true }
    );
  });

  ensureContactWorkspaceStickyBar();
  loadContactWorkspaceLabelsSettings();
}

initContactWorkspaceLabelsSettings();

const emailTemplateBrandingForm = document.getElementById("emailTemplateBrandingForm");
const emailTemplateBrandingEnabled = document.getElementById("emailTemplateBrandingEnabled");
const emailTemplateBrandingCompany = document.getElementById("emailTemplateBrandingCompany");
const emailTemplateBrandingPhotoFile = document.getElementById("emailTemplateBrandingPhotoFile");
const emailTemplateBrandingPhotoPreview = document.getElementById("emailTemplateBrandingPhotoPreview");
const emailTemplateBrandingPhotoImg = document.getElementById("emailTemplateBrandingPhotoImg");
const emailTemplateBrandingRemovePhotoBtn = document.getElementById("emailTemplateBrandingRemovePhotoBtn");
const emailTemplateBrandingFeedback = document.getElementById("emailTemplateBrandingFeedback");

function showEmailTemplateBrandingFeedback(text, isError) {
  if (!emailTemplateBrandingFeedback) return;
  emailTemplateBrandingFeedback.textContent = text || "";
  emailTemplateBrandingFeedback.classList.toggle("signature-save-feedback--error", Boolean(isError));
}

function hideSidebarBrandingPhotoPreview() {
  if (emailTemplateBrandingPhotoPreview) emailTemplateBrandingPhotoPreview.hidden = true;
  if (emailTemplateBrandingPhotoImg) emailTemplateBrandingPhotoImg.removeAttribute("src");
}

let sidebarBrandingSavedPhotoUrl = "";

function showSidebarBrandingPhotoPreview(url) {
  const src = String(url || "").trim();
  if (!emailTemplateBrandingPhotoPreview || !emailTemplateBrandingPhotoImg || !src) return;
  emailTemplateBrandingPhotoImg.onerror = () => hideSidebarBrandingPhotoPreview();
  emailTemplateBrandingPhotoImg.onload = () => {
    emailTemplateBrandingPhotoPreview.hidden = false;
  };
  emailTemplateBrandingPhotoImg.src = src;
  if (src.startsWith("data:")) {
    emailTemplateBrandingPhotoPreview.hidden = false;
  }
}

function applyEmailTemplateBrandingForm(data) {
  const d = data && typeof data === "object" ? data : {};
  if (emailTemplateBrandingEnabled) emailTemplateBrandingEnabled.checked = d.enabled === true;
  if (emailTemplateBrandingCompany) emailTemplateBrandingCompany.value = String(d.companyName || "");
  const url = String(d.photoUrl || "").trim();
  sidebarBrandingSavedPhotoUrl = url;
  if (url) {
    showSidebarBrandingPhotoPreview(url);
  } else {
    hideSidebarBrandingPhotoPreview();
  }
}

async function loadEmailTemplateBrandingSettings() {
  if (!emailTemplateBrandingForm) return;
  try {
    const data = await fetchApiJson("/api/email/template-branding");
    applyEmailTemplateBrandingForm(data);
  } catch (error) {
    if (/session expired due to inactivity/i.test(String(error?.message || ""))) return;
    showEmailTemplateBrandingFeedback(error.message || "Could not load template header settings.", true);
  }
}

async function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || "");
      const comma = result.indexOf(",");
      resolve(comma >= 0 ? result.slice(comma + 1) : result);
    };
    reader.onerror = () => reject(new Error(`Failed to read ${file.name}`));
    reader.readAsDataURL(file);
  });
}

if (emailTemplateBrandingPhotoFile) {
  emailTemplateBrandingPhotoFile.addEventListener("change", () => {
    const file = emailTemplateBrandingPhotoFile.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = String(reader.result || "").trim();
        if (dataUrl) showSidebarBrandingPhotoPreview(dataUrl);
      };
      reader.onerror = () => showEmailTemplateBrandingFeedback("Could not read that photo.", true);
      reader.readAsDataURL(file);
      if (emailTemplateBrandingEnabled && !emailTemplateBrandingEnabled.checked) {
        emailTemplateBrandingEnabled.checked = true;
      }
      return;
    }
    if (sidebarBrandingSavedPhotoUrl) {
      showSidebarBrandingPhotoPreview(sidebarBrandingSavedPhotoUrl);
    } else {
      hideSidebarBrandingPhotoPreview();
    }
  });
}

if (emailTemplateBrandingForm) {
  emailTemplateBrandingForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      const companyName = String(emailTemplateBrandingCompany?.value || "").trim();
      const file = emailTemplateBrandingPhotoFile?.files?.[0];
      let enabled = emailTemplateBrandingEnabled?.checked === true;
      if (!enabled && (companyName || file)) {
        enabled = true;
        if (emailTemplateBrandingEnabled) emailTemplateBrandingEnabled.checked = true;
      }
      let data = await fetchApiJson("/api/email/template-branding", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled, companyName })
      });

      if (file) {
        const contentBase64 = await fileToBase64(file);
        data = await fetchApiJson("/api/email/template-branding/photo", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contentBase64,
            mimeType: file.type || "image/jpeg",
            fileName: file.name
          })
        });
        if (emailTemplateBrandingPhotoFile) emailTemplateBrandingPhotoFile.value = "";
      }
      applyEmailTemplateBrandingForm(data);
      window.dispatchEvent(new CustomEvent("crm:template-branding-updated"));
      showEmailTemplateBrandingFeedback("Sidebar branding saved.");
    } catch (error) {
      showEmailTemplateBrandingFeedback(error.message || "Failed to save.", true);
    }
  });
}

function renderImportedBookStatus(data) {
  const hint = document.getElementById("importedBookStatusHint");
  if (!hint) return;
  const tagged = Number(data?.taggedCount || 0);
  const untaggedNew = Number(data?.untaggedNewCount || 0);
  if (tagged > 0 && untaggedNew === 0) {
    hint.textContent = `${tagged.toLocaleString("en-US")} contact(s) are excluded from new-lead counts.`;
    return;
  }
  if (tagged > 0) {
    hint.textContent = `${tagged.toLocaleString("en-US")} contact(s) are excluded. ${untaggedNew.toLocaleString("en-US")} NEW contact(s) still count as new leads.`;
    return;
  }
  if (untaggedNew > 0) {
    hint.textContent = `${untaggedNew.toLocaleString("en-US")} NEW contact(s) currently count as new leads in Morning Briefing.`;
    return;
  }
  hint.textContent = "No imported-book tags yet. Use this after uploading contacts from another CRM.";
}

async function loadImportedBookSettings() {
  const hint = document.getElementById("importedBookStatusHint");
  if (!hint) return;
  try {
    const data = await fetchApiJson("/api/contacts/imported-book");
    renderImportedBookStatus(data);
  } catch (error) {
    hint.textContent = error.message || "Could not load imported book status.";
  }
}

async function updateImportedBook(action, confirmText) {
  const message = document.getElementById("importedBookMessage");
  if (confirmText && !window.confirm(confirmText)) return;
  if (message) message.textContent = "Updating…";
  try {
    const data = await fetchApiJson("/api/contacts/imported-book", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action })
    });
    renderImportedBookStatus(data);
    if (message) {
      message.textContent =
        action === "clear"
          ? "Imported-book tags were removed. Those contacts can count as new leads again."
          : `Excluded ${Number(data?.newlyTagged || 0).toLocaleString("en-US")} NEW contact(s) from new-lead counts.`;
    }
  } catch (error) {
    if (message) message.textContent = error.message || "Could not update imported book tags.";
  }
}

document.getElementById("importedBookMarkBtn")?.addEventListener("click", () => {
  updateImportedBook(
    "mark-new",
    "Exclude NEW contacts with no Cadence activity for 7+ days from Morning Briefing and Pipeline new-lead counts? Contacts you add later will still count as new."
  );
});
document.getElementById("importedBookClearBtn")?.addEventListener("click", () => {
  updateImportedBook(
    "clear",
    "Remove imported-book tags so those contacts can appear as new leads again?"
  );
});
loadImportedBookSettings();

if (emailTemplateBrandingRemovePhotoBtn) {
  emailTemplateBrandingRemovePhotoBtn.addEventListener("click", async () => {
    try {
      const data = await fetchApiJson("/api/email/template-branding/photo", { method: "DELETE" });
      applyEmailTemplateBrandingForm(data);
      window.dispatchEvent(new CustomEvent("crm:template-branding-updated"));
      if (emailTemplateBrandingPhotoFile) emailTemplateBrandingPhotoFile.value = "";
      showEmailTemplateBrandingFeedback("Photo removed.");
    } catch (error) {
      showEmailTemplateBrandingFeedback(error.message || "Failed to remove photo.", true);
    }
  });
}

