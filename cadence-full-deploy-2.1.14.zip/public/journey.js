(function () {
  const board = document.getElementById("journeyBoard");
  const svg = document.getElementById("journeyConnections");
  const resetBtn = document.getElementById("journeyResetLayoutBtn");
  const saveCampaignBtn = document.getElementById("journeySaveCampaignBtn");
  const duplicateCampaignBtn = document.getElementById("journeyDuplicateCampaignBtn");
  const saveAsCampaignBtn = document.getElementById("journeySaveAsCampaignBtn");
  const refreshCampaignsBtn = document.getElementById("journeyRefreshCampaignsBtn");
  const journeyCampaignCategoryList = document.getElementById("journeyCampaignCategoryList");
  const journeyCampaignSubtitle = document.getElementById("journeyCampaignSubtitle");
  const journeyNewCampaignBtn = document.getElementById("journeyNewCampaignBtn");
  const journeyCampaignNameInput = document.getElementById("journeyCampaignNameInput");
  const journeyCampaignCategorySelect = document.getElementById("journeyCampaignCategorySelect");
  const journeyAddCategoryBtn = document.getElementById("journeyAddCategoryBtn");
  const journeyAddCategorySidebarBtn = document.getElementById("journeyAddCategorySidebarBtn");
  const journeyCategoryDialog = document.getElementById("journeyCategoryDialog");
  const journeyCategoryDialogForm = document.getElementById("journeyCategoryDialogForm");
  const journeyCategoryDialogName = document.getElementById("journeyCategoryDialogName");
  const journeyCategoryDialogCancel = document.getElementById("journeyCategoryDialogCancel");
  const journeySettingsDetails = document.getElementById("journeySettingsDetails");
  const journeyIncludeSignatureEl = document.getElementById("journeyIncludeSignature");
  if (!board || !svg) return;

  const CAMPAIGN_GRAPH_PREFIX = "crm.journeyCampaignGraph.v1.";
  const EMAIL_SIGNATURE_STORAGE_KEY = "crm.emailSignatureSettings";
  const EMAIL_INCLUDE_SIGNATURE_STORAGE_KEY = "crm.emailIncludeSignature";
  const JOURNEY_SIGNATURE_IMAGE_MAX_PX = 160;
  const GRID_SIZE = 32;

  const TYPE_CONFIG = {
    start: { icon: "▶", className: "journey-node-card--start", label: "Trigger" },
    email: { icon: "✉", className: "journey-node-card--email", label: "Email" },
    sms: { icon: "💬", className: "journey-node-card--sms", label: "SMS" },
    call: { icon: "📞", className: "journey-node-card--call", label: "Call" },
    delay: { icon: "⏱", className: "journey-node-card--delay", label: "Delay" },
    condition: { icon: "◇", className: "journey-node-card--condition", label: "Condition" },
    success: { icon: "✓", className: "journey-node-card--success", label: "Complete" }
  };
  const FLOW_CARD_WIDTH = 260;
  const FLOW_ROW_GAP = 16;
  const FLOW_START_Y = 24;
  const FLOW_SLOT_HEIGHT = 12;
  const FLOW_ADD_HEIGHT = 24;
  const TYPE_OPTIONS = ["start", "email", "sms", "call", "delay", "condition", "success"];

  let selectedCampaignId = null;
  let cachedCampaignCategories = [];
  let cachedCampaigns = [];
  /** False until the first successful category and campaign fetch. Avoids painting All 0 / Uncategorized before the real list. */
  let campaignListsLoaded = false;
  let selectedPickerCategoryId = "__all__";
  const expandedPickerCategories = new Set();
  let journeyEmailTemplateRowsCache = [];
  let journeySavedContactTags = [];
  let journeyIsDraftCampaign = false;

  const state = { nodes: [], links: [] };
  const nodeEls = new Map();
  let contextTargetNodeId = "";
  let contextPos = { x: 0, y: 0 };
  let connectFromNodeId = "";
  /** Drag from a node's output connector to another node to add a link. */
  let linkDragFromId = "";
  let linkDragPreviewPath = null;
  let activeFlowInsertBeforeId = "";
  let suppressNodeClickUntil = 0;
  let toastTimer = null;
  let journeyDrawRaf = 0;

  const contextMenu = document.createElement("div");
  contextMenu.id = "journeyContextMenu";
  contextMenu.className = "journey-context-menu hidden";
  contextMenu.innerHTML = `
    <button type="button" data-action="add-node">Add Node Here</button>
    <button type="button" data-action="add-child">Add Connected Node</button>
    <button type="button" data-action="branch">Add Yes/No Branch</button>
    <button type="button" data-action="connect-start">Connect To...</button>
    <button type="button" data-action="delete-node" class="danger">Delete Node</button>
  `;
  document.body.appendChild(contextMenu);

  const toastEl = document.createElement("div");
  toastEl.className = "journey-toast hidden";
  document.body.appendChild(toastEl);
  const stepDialog = document.createElement("dialog");
  stepDialog.className = "journey-step-dialog";
  stepDialog.innerHTML = `
    <div class="journey-step-dialog-inner">
      <button type="button" class="journey-step-dialog-close" aria-label="Close">&times;</button>
      <h3 class="journey-step-dialog-heading">Step details</h3>
      <div class="journey-step-dialog-body"></div>
    </div>
  `;
  document.body.appendChild(stepDialog);
  const stepDialogHeading = stepDialog.querySelector(".journey-step-dialog-heading");
  const stepDialogBody = stepDialog.querySelector(".journey-step-dialog-body");

  function uid(prefix) {
    return `${prefix}-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
  }

  function campaignGraphStorageKey(id) {
    return `${CAMPAIGN_GRAPH_PREFIX}${Math.floor(Number(id))}`;
  }

  function getCrmApiBase() {
    const injected =
      typeof window.__CRM_API_ORIGIN__ === "string" ? window.__CRM_API_ORIGIN__.trim().replace(/\/$/, "") : "";
    if (injected) return injected;
    const fromMeta = document.querySelector('meta[name="crm-api-base"]')?.getAttribute("content") || "";
    return String(fromMeta || "").trim().replace(/\/$/, "");
  }

  function apiUrl(path) {
    const p = path.startsWith("/") ? path : `/${path}`;
    const base = getCrmApiBase();
    return base ? `${base}${p}` : p;
  }

  async function fetchApiJson(path, init) {
    const response = await fetch(apiUrl(path), init);
    const text = await response.text();
    let data = {};
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      data = {};
    }
    return { response, data };
  }

  function escapeHtml(text) {
    return String(text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function textToHtmlLines(value) {
    return escapeHtml(String(value || "")).replace(/\r?\n/g, "<br>");
  }

  function signatureStorageHasVisibleContent(signatureHtml, signatureText) {
    if (String(signatureText || "").trim()) return true;
    const raw = String(signatureHtml || "").trim();
    if (!raw) return false;
    if (/<img[\s>]/i.test(raw)) return true;
    const stripped = raw
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/gi, " ")
      .replace(/\s+/g, " ")
      .trim();
    return stripped.length > 0;
  }

  function stripImgTagDimensionAttrs(imgTag) {
    return String(imgTag || "")
      .replace(/\swidth=(['"]?)[^'"\s>]+\1/gi, "")
      .replace(/\sheight=(['"]?)[^'"\s>]+\1/gi, "");
  }

  function clampSignatureImageHtml(rawHtml) {
    const raw = String(rawHtml || "");
    if (!raw || !/<img[\s>]/i.test(raw)) return raw;
    const maxW = JOURNEY_SIGNATURE_IMAGE_MAX_PX;
    const normalizeImgTag = (imgTag) => {
      let out = stripImgTagDimensionAttrs(imgTag);
      const styleMatch = out.match(/\sstyle=(['"])([\s\S]*?)\1/i);
      const styleRaw = styleMatch ? String(styleMatch[2] || "") : "";
      const cleaned = styleRaw
        .replace(/(?:^|;)\s*width\s*:[^;]*/gi, "")
        .replace(/(?:^|;)\s*max-width\s*:[^;]*/gi, "")
        .replace(/(?:^|;)\s*height\s*:[^;]*/gi, "")
        .replace(/(?:^|;)\s*display\s*:[^;]*/gi, "")
        .replace(/(?:^|;)\s*margin-bottom\s*:[^;]*/gi, "")
        .trim();
      // Gmail needs width= attribute; CSS max-width alone is not enough.
      const styleFinal = `${cleaned ? `${cleaned};` : ""}width:${maxW}px;max-width:${maxW}px;height:auto;display:block;margin-bottom:12px;`;
      if (styleMatch) out = out.replace(/\sstyle=(['"])([\s\S]*?)\1/i, ` style="${styleFinal}"`);
      else out = out.replace(/<img\b/i, `<img style="${styleFinal}"`);
      out = out.replace(/\s+width\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, "");
      out = out.replace(/<img\b/i, `<img width="${maxW}"`);
      if (!/\salt=/i.test(out)) out = out.replace(/<img\b/i, '<img alt="Signature image"');
      return out;
    };
    return raw.replace(/<img\b[^>]*>/gi, (tag) => normalizeImgTag(tag));
  }

  function stripCampaignSignatureBlocks(html) {
    const raw = String(html || "");
    if (!raw.trim()) return raw;
    const host = document.createElement("div");
    host.innerHTML = raw;
    host.querySelectorAll(".campaign-email-signature-block").forEach((el) => el.remove());
    return host.innerHTML;
  }

  function isJourneyIncludeSignatureEnabled() {
    if (journeyIncludeSignatureEl) return Boolean(journeyIncludeSignatureEl.checked);
    const includeRaw = window.localStorage.getItem(EMAIL_INCLUDE_SIGNATURE_STORAGE_KEY);
    return includeRaw == null ? true : includeRaw === "1";
  }

  function buildStoredSignatureBlockHtml(hasMainAbove, includeOverride = null) {
    try {
      const include = includeOverride == null ? isJourneyIncludeSignatureEnabled() : Boolean(includeOverride);
      if (!include) return "";
      const raw = window.localStorage.getItem(EMAIL_SIGNATURE_STORAGE_KEY);
      const settings = raw ? JSON.parse(raw) : {};
      const signatureHtml = String(settings.html || "").trim();
      const signatureText = String(settings.text || "").trim();
      const fontSize = Number(settings.fontSize || 16);
      const color = String(settings.color || "#1f2937").trim();
      const linkText = String(settings.linkText || "").trim();
      const linkUrl = String(settings.linkUrl || "").trim();
      const imageUrl = String(settings.imageUrl || "").trim();
      const signatureTextHtml = clampSignatureImageHtml(
        signatureHtml || (signatureText ? textToHtmlLines(signatureText) : "")
      );
      const signatureHasInlineImage = /<img[\s>]/i.test(signatureHtml);
      const hasSignatureContent =
        signatureStorageHasVisibleContent(signatureHtml, signatureText) ||
        signatureHasInlineImage ||
        (linkText && linkUrl) ||
        Boolean(imageUrl);
      if (!hasSignatureContent) return "";
      const safeFontSize = Number.isFinite(fontSize) ? Math.min(36, Math.max(10, Math.round(fontSize))) : 16;
      const safeColor = /^#[0-9a-fA-F]{6}$/.test(color) ? color : "#1f2937";
      const linkHtml =
        linkText && linkUrl
          ? `<div style="margin-top:8px;"><a href="${escapeHtml(linkUrl)}" target="_blank" rel="noopener noreferrer">${escapeHtml(
              linkText
            )}</a></div>`
          : "";
      const imageHtml = imageUrl
        ? `<div style="margin-top:8px;"><img src="${escapeHtml(imageUrl)}" alt="Signature image" style="max-width:${JOURNEY_SIGNATURE_IMAGE_MAX_PX}px;height:auto;display:block;border:0;margin-bottom:12px;" /></div>`
        : "";
      const sigSep = hasMainAbove
        ? "margin-top:18px;padding-top:14px;border-top:1px solid #e5e7eb;"
        : "margin-top:0;padding-top:0;";
      return `<div class="campaign-email-signature-block" style="${sigSep}font-family:system-ui,Segoe UI,Arial,sans-serif;font-size:${safeFontSize}px;color:${safeColor};line-height:1.45;">${signatureTextHtml}${linkHtml}${imageHtml}</div>`;
    } catch {
      return "";
    }
  }

  function appendStoredSignatureToEmailHtml(mainHtml, includeSignature = true) {
    const base = stripCampaignSignatureBlocks(String(mainHtml || "")).trim();
    const sig = buildStoredSignatureBlockHtml(Boolean(base), includeSignature);
    if (!sig) return base || "<p></p>";
    return `${base}${sig}`;
  }

  function composeJourneyEmailBodyForSave(editorHtml) {
    const cleaned = stripCampaignSignatureBlocks(String(editorHtml || "")).trim() || "<p></p>";
    if (!isJourneyIncludeSignatureEnabled()) return cleaned;
    return appendStoredSignatureToEmailHtml(cleaned, true);
  }

  function initJourneyIncludeSignatureToggle() {
    if (!journeyIncludeSignatureEl) return;
    const includeRaw = window.localStorage.getItem(EMAIL_INCLUDE_SIGNATURE_STORAGE_KEY);
    journeyIncludeSignatureEl.checked = includeRaw == null ? true : includeRaw === "1";
    journeyIncludeSignatureEl.addEventListener("change", () => {
      window.localStorage.setItem(
        EMAIL_INCLUDE_SIGNATURE_STORAGE_KEY,
        journeyIncludeSignatureEl.checked ? "1" : "0"
      );
    });
  }

  function normalizeState(input) {
    const safe = input && typeof input === "object" ? input : {};
    const nodes = Array.isArray(safe.nodes)
      ? safe.nodes.map((n) => {
          const node = {
            id: String(n?.id || uid("node")),
            label: String(n?.label ?? "Step"),
            type: TYPE_OPTIONS.includes(String(n?.type)) ? String(n.type) : "email",
            x: snap(Number(n?.x) || 0),
            y: snap(Number(n?.y) || 0)
          };
          const off = Number(n?.dripOffsetHours);
          if (Number.isFinite(off) && off >= 0) node.dripOffsetHours = off;
          if (n && typeof n === "object" && "dripSubject" in n) node.dripSubject = String(n.dripSubject ?? "");
          if (n && typeof n === "object" && "dripBody" in n) node.dripBody = String(n.dripBody ?? "");
          if (n && typeof n === "object" && "dripCallTwimlUrl" in n)
            node.dripCallTwimlUrl = String(n.dripCallTwimlUrl ?? "");
          if (n && typeof n === "object" && ("dripTwilioFrom" in n || "twilio_from" in n)) {
            node.dripTwilioFrom = String(n.dripTwilioFrom ?? n.twilio_from ?? "").trim();
          }
          if (n && typeof n === "object" && ("dripEmailFrom" in n || "email_from" in n)) {
            node.dripEmailFrom = String(n.dripEmailFrom ?? n.email_from ?? "").trim();
          }
          if (n && typeof n === "object" && ("dripSmsMediaId" in n || "sms_media_id" in n)) {
            node.dripSmsMediaId = String(n.dripSmsMediaId ?? n.sms_media_id ?? "").trim().toLowerCase();
          }
          if (n && typeof n === "object" && "conditionRule" in n) node.conditionRule = String(n.conditionRule ?? "");
          if (n && typeof n === "object" && "conditionWindowDays" in n)
            node.conditionWindowDays = String(n.conditionWindowDays ?? "");
          const delayUnit = String(n?.dripDelayUnit || "").toLowerCase();
          if (delayUnit === "minutes" || delayUnit === "hours" || delayUnit === "days") {
            node.dripDelayUnit = delayUnit;
          }
          const enrollTag = String(n?.dripEnrollTag ?? "").trim();
          if (enrollTag) node.dripEnrollTag = enrollTag;
          return node;
        })
      : [];
    const links = Array.isArray(safe.links)
      ? safe.links.map((link) => ({
          id: String(link?.id || uid("link")),
          from: String(link?.from || ""),
          to: String(link?.to || ""),
          label: String(link?.label || "")
        }))
      : [];
    return { nodes, links };
  }

  function loadCampaignGraphFromStorage(campaignId) {
    try {
      const raw = window.localStorage.getItem(campaignGraphStorageKey(campaignId));
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed?.nodes) || !Array.isArray(parsed?.links)) return null;
      return normalizeState(parsed);
    } catch {
      return null;
    }
  }

  function applyState(next) {
    const n = normalizeState(next);
    state.nodes = n.nodes;
    state.links = n.links;
  }

  function persistCurrentState() {
    if (selectedCampaignId == null || !Number.isFinite(Number(selectedCampaignId))) return;
    const payload = normalizeState(state);
    try {
      window.localStorage.setItem(campaignGraphStorageKey(selectedCampaignId), JSON.stringify(payload));
    } catch {
      // ignore storage failures
    }
  }

  function showToast(text, tone = "success") {
    if (!toastEl) return;
    toastEl.textContent = String(text || "").trim();
    if (!toastEl.textContent) return;
    toastEl.classList.remove("journey-toast--success", "journey-toast--danger");
    toastEl.classList.add(tone === "danger" ? "journey-toast--danger" : "journey-toast--success");
    toastEl.classList.remove("hidden");
    if (toastTimer) window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => {
      toastEl.classList.add("hidden");
      toastTimer = null;
    }, 1700);
  }

  function snap(value) {
    return Math.round(Number(value || 0) / GRID_SIZE) * GRID_SIZE;
  }

  function boardRect() {
    return board.getBoundingClientRect();
  }

  function clampPos(x, y, el) {
    const rect = boardRect();
    const maxX = Math.max(0, rect.width - el.offsetWidth - 8);
    const maxY = Math.max(0, rect.height - el.offsetHeight - 8);
    return {
      x: Math.min(Math.max(8, snap(x)), maxX),
      y: Math.min(Math.max(8, snap(y)), maxY)
    };
  }

  /** Clamp to board bounds without grid snap — used while dragging for smooth motion. */
  function clampPosRaw(x, y, el) {
    const rect = boardRect();
    const maxX = Math.max(0, rect.width - el.offsetWidth - 8);
    const maxY = Math.max(0, rect.height - el.offsetHeight - 8);
    return {
      x: Math.min(Math.max(8, x), maxX),
      y: Math.min(Math.max(8, y), maxY)
    };
  }

  function getNode(id) {
    return state.nodes.find((n) => n.id === id) || null;
  }

  function isFlowLayout() {
    return board.classList.contains("journey-board--flow");
  }

  function findStartNodeId() {
    const starts = state.nodes.filter((n) => n.type === "start" || /-start$/i.test(String(n.id)));
    if (starts.length === 1) return starts[0].id;
    return starts[0]?.id || "";
  }

  function flowNodeHeight(node) {
    if (!node) return 56;
    return node.type === "start" || node.type === "success" ? 52 : 60;
  }

  function compareOutgoingLinks(a, b) {
    const rank = (label) => {
      const s = String(label || "").trim().toLowerCase();
      if (!s) return 0;
      if (s === "yes") return 1;
      if (s === "no") return 2;
      return 3;
    };
    const ra = rank(a.label);
    const rb = rank(b.label);
    if (ra !== rb) return ra - rb;
    return String(a.to).localeCompare(String(b.to));
  }

  function isCompleteNode(node) {
    if (!node) return false;
    return (
      node.type === "success" ||
      /-end$/i.test(String(node.id)) ||
      String(node.label || "").trim() === "Complete"
    );
  }

  /** Primary path from Start for vertical flow display and reorder. */
  function getFlowOrderedNodeIds() {
    const startId = findStartNodeId();
    if (!startId) {
      return pinCompleteLast(
        [...state.nodes]
          .sort((a, b) => a.y - b.y || a.x - b.x)
          .map((n) => n.id)
      );
    }
    const ordered = [];
    let cur = startId;
    const visited = new Set();
    while (cur && !visited.has(cur)) {
      visited.add(cur);
      ordered.push(cur);
      if (isCompleteNode(getNode(cur))) break;
      const outs = state.links.filter((l) => l.from === cur).sort(compareOutgoingLinks);
      if (!outs.length) break;
      cur = outs[0].to;
      if (ordered.length > 300) break;
    }
    const leftoverSteps = [];
    const leftoverComplete = [];
    state.nodes.forEach((n) => {
      if (ordered.includes(n.id)) return;
      if (isCompleteNode(n)) leftoverComplete.push(n.id);
      else leftoverSteps.push(n.id);
    });
    const successIdx = ordered.findIndex((id) => isCompleteNode(getNode(id)));
    if (successIdx >= 0) ordered.splice(successIdx, 0, ...leftoverSteps);
    else ordered.push(...leftoverSteps);
    leftoverComplete.forEach((id) => {
      if (!ordered.includes(id)) ordered.push(id);
    });
    return pinCompleteLast(ordered);
  }

  function pinCompleteLast(ids) {
    const complete = [];
    const rest = [];
    ids.forEach((id) => {
      if (isCompleteNode(getNode(id))) complete.push(id);
      else rest.push(id);
    });
    return rest.concat(complete);
  }

  function applyFlowLayoutPositions() {
    if (!isFlowLayout()) return;
    rebuildLinearChain(getFlowOrderedNodeIds());
    const ordered = getFlowOrderedNodeIds();
    const boardW = board.clientWidth || 760;
    const centerX = Math.max(16, Math.round((boardW - Math.min(FLOW_CARD_WIDTH, boardW - 32)) / 2));
    let y = FLOW_START_Y;
    ordered.forEach((id) => {
      const node = getNode(id);
      if (!node) return;
      node.x = centerX;
      node.y = y;
      y += flowNodeHeight(node) + FLOW_ROW_GAP + FLOW_SLOT_HEIGHT + FLOW_ADD_HEIGHT;
    });
  }

  /** After cards are in the DOM, re-stack using measured heights so arrows align. */
  function syncFlowLayoutFromDom() {
    if (!isFlowLayout()) return;
    const ordered = getFlowOrderedNodeIds();
    const boardW = board.clientWidth || 760;
    const centerX = Math.max(16, Math.round((boardW - Math.min(FLOW_CARD_WIDTH, boardW - 32)) / 2));
    let y = FLOW_START_Y;
    const gap = FLOW_ROW_GAP + FLOW_SLOT_HEIGHT + FLOW_ADD_HEIGHT;
    ordered.forEach((id) => {
      const node = getNode(id);
      const el = nodeEls.get(id);
      if (!node || !el) return;
      node.x = centerX;
      node.y = y;
      el.style.left = `${node.x}px`;
      el.style.top = `${node.y}px`;
      y += (el.offsetHeight || flowNodeHeight(node)) + gap;
    });
  }

  function renderFreshFlowLayout({ persist = true } = {}) {
    applyFlowLayoutPositions();
    renderNodes();
    if (isFlowLayout()) {
      syncFlowLayoutFromDom();
      resizeBoardToGraphBounds();
      placeFlowChrome(getFlowOrderedNodeIds());
      drawConnections();
    }
    if (persist) persistCurrentState();
  }

  function rebuildLinearChain(orderedIds) {
    const pinned = pinCompleteLast(orderedIds);
    const pairs = [];
    for (let i = 0; i < pinned.length - 1; i += 1) {
      const from = pinned[i];
      const to = pinned[i + 1];
      if (isCompleteNode(getNode(from))) break;
      const existing = state.links.find((l) => l.from === from && l.to === to);
      pairs.push(
        existing
          ? { ...existing, label: String(existing.label || "").trim() }
          : { id: uid("link"), from, to, label: "" }
      );
    }
    state.links = pairs;
  }

  function reorderNodeInFlow(draggedId, insertBeforeId) {
    if (!draggedId || draggedId === insertBeforeId) return;
    const dragged = getNode(draggedId);
    if (!dragged || dragged.type === "start" || dragged.type === "success") return;

    const ordered = getFlowOrderedNodeIds();
    const fromIdx = ordered.indexOf(draggedId);
    if (fromIdx < 0) return;
    ordered.splice(fromIdx, 1);
    let insertIdx = insertBeforeId ? ordered.indexOf(insertBeforeId) : ordered.length;
    if (insertIdx < 0) insertIdx = ordered.length;
    const successIdx = ordered.findIndex((id) => getNode(id)?.type === "success" || /-end$/i.test(String(id)));
    if (successIdx >= 0 && insertIdx > successIdx) insertIdx = successIdx;
    const startIdx = ordered.findIndex((id) => getNode(id)?.type === "start" || id === "start");
    if (startIdx >= 0 && insertIdx <= startIdx) insertIdx = Math.min(startIdx + 1, ordered.length);
    ordered.splice(insertIdx, 0, draggedId);
    rebuildLinearChain(ordered);
    applyFlowLayoutPositions();
    persistCurrentState();
    renderNodes();
    showToast("Step reordered", "success");
  }

  function insertStepAfter(afterNodeId, channel) {
    const after = getNode(afterNodeId);
    if (!after) return;
    const safeChannel = TYPE_OPTIONS.includes(channel) ? channel : "email";
    if (safeChannel === "start" || safeChannel === "success") return;

    const labels = { email: "New Email", sms: "New SMS", call: "New Call", delay: "Wait 1 day", condition: "Condition" };
    const newId = uid("node");
    const newNode = {
      id: newId,
      label: labels[safeChannel] || "New Step",
      type: safeChannel,
      x: snap(Number(after.x || 0)),
      y: snap(Number(after.y || 0) + flowNodeHeight(after) + FLOW_ROW_GAP + FLOW_SLOT_HEIGHT + FLOW_ADD_HEIGHT)
    };
    if (safeChannel === "email" || safeChannel === "sms" || safeChannel === "call") {
      newNode.dripOffsetHours = 0;
    }
    if (safeChannel === "delay") {
      newNode.dripOffsetHours = 24;
      newNode.dripDelayUnit = "days";
    }
    if (safeChannel === "condition") {
      newNode.conditionRule = "email_opened";
      newNode.conditionWindowDays = "3";
      newNode.label = "If email opened";
    }
    state.nodes.push(newNode);

    const ordered = getFlowOrderedNodeIds();
    const idx = ordered.indexOf(afterNodeId);
    if (idx >= 0) {
      let insertAt = isCompleteNode(after) ? idx : idx + 1;
      const successIdx = ordered.findIndex((id) => isCompleteNode(getNode(id)));
      if (successIdx >= 0 && insertAt > successIdx) insertAt = successIdx;
      ordered.splice(insertAt, 0, newId);
      rebuildLinearChain(ordered);
    } else {
      addLink(afterNodeId, newId, "");
    }

    persistCurrentState();
    renderFreshFlowLayout();
    showToast("Step added", "success");
    showNodeStepDetails(newNode);
  }

  function boardClientToLocal(clientX, clientY) {
    const br = boardRect();
    return { x: clientX - br.left, y: clientY - br.top };
  }

  function linkEndpointOut(el) {
    const br = boardRect();
    const r = el.getBoundingClientRect();
    if (isFlowLayout()) {
      const menuBtn = el.querySelector(".journey-node-menu-btn");
      if (menuBtn) {
        const btnR = menuBtn.getBoundingClientRect();
        return { x: btnR.left - br.left + btnR.width / 2, y: btnR.top - br.top + btnR.height / 2 };
      }
      return { x: r.right - br.left - 8, y: r.top - br.top + r.height / 2 };
    }
    const btn = el.querySelector(".journey-node-connector-out");
    if (btn) {
      const btnR = btn.getBoundingClientRect();
      return { x: btnR.left - br.left + btnR.width / 2, y: btnR.top - br.top + btnR.height / 2 };
    }
    return { x: r.right - br.left - 6, y: r.top - br.top + r.height / 2 };
  }

  function linkEndpointIn(el) {
    const br = boardRect();
    const r = el.getBoundingClientRect();
    if (isFlowLayout()) {
      return { x: r.left - br.left + r.width / 2, y: r.top - br.top };
    }
    return { x: r.left - br.left, y: r.top - br.top + r.height / 2 };
  }

  function buildPath(from, to) {
    if (isFlowLayout()) {
      const midY = from.y + (to.y - from.y) * 0.5;
      return `M ${from.x} ${from.y} L ${from.x} ${midY} L ${to.x} ${midY} L ${to.x} ${to.y}`;
    }
    const midX = from.x + (to.x - from.x) * 0.5;
    return `M ${from.x} ${from.y} L ${midX} ${from.y} L ${midX} ${to.y} L ${to.x} ${to.y}`;
  }

  function removeLinkDragPreview() {
    if (linkDragPreviewPath && linkDragPreviewPath.parentNode) {
      linkDragPreviewPath.parentNode.removeChild(linkDragPreviewPath);
    }
    linkDragPreviewPath = null;
  }

  function cleanupLinkDragSurface() {
    document.removeEventListener("pointermove", onLinkDragPointerMove);
    document.removeEventListener("pointerup", onLinkDragPointerUp);
    document.removeEventListener("pointercancel", onLinkDragPointerUp);
    removeLinkDragPreview();
    linkDragFromId = "";
    board.classList.remove("is-link-dragging");
  }

  function updateLinkDragPreview(clientX, clientY) {
    if (!linkDragFromId || !linkDragPreviewPath) return;
    const fromEl = nodeEls.get(linkDragFromId);
    if (!fromEl) return;
    const from = linkEndpointOut(fromEl);
    const to = boardClientToLocal(clientX, clientY);
    linkDragPreviewPath.setAttribute("d", buildPath(from, to));
  }

  function onLinkDragPointerMove(e) {
    if (!linkDragFromId) return;
    updateLinkDragPreview(e.clientX, e.clientY);
  }

  function onLinkDragPointerUp(e) {
    const fromId = linkDragFromId;
    if (!fromId) return;
    const target = document.elementFromPoint(e.clientX, e.clientY);
    const card = target && typeof target.closest === "function" ? target.closest(".journey-node-card") : null;
    const toId = card ? String(card.getAttribute("data-node-id") || "") : "";
    cleanupLinkDragSurface();
    if (toId && toId !== fromId) {
      addLink(fromId, toId, "");
      persistCurrentState();
      drawConnections();
      suppressNodeClickUntil = performance.now() + 400;
    }
  }

  function startLinkDragFromNode(fromNodeId, clientX, clientY) {
    if (!fromNodeId || !nodeEls.get(fromNodeId)) return;
    connectFromNodeId = "";
    board.classList.remove("is-connecting");
    cleanupLinkDragSurface();
    linkDragFromId = fromNodeId;
    board.classList.add("is-link-dragging");
    linkDragPreviewPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
    linkDragPreviewPath.setAttribute("class", "journey-link-path journey-link-path--drag-preview");
    linkDragPreviewPath.setAttribute("pointer-events", "none");
    svg.appendChild(linkDragPreviewPath);
    updateLinkDragPreview(clientX, clientY);
    document.addEventListener("pointermove", onLinkDragPointerMove);
    document.addEventListener("pointerup", onLinkDragPointerUp);
    document.addEventListener("pointercancel", onLinkDragPointerUp);
  }

  function splitOffsetParts(totalHours) {
    const t = Number(totalHours);
    if (!Number.isFinite(t) || t < 0) return { days: 0, hours: 0, minutes: 0 };
    const days = Math.floor(t / 24);
    let rem = t - days * 24;
    let hours = Math.floor(rem);
    let minutes = Math.round((rem - hours) * 60);
    if (minutes >= 60) {
      hours += Math.floor(minutes / 60);
      minutes %= 60;
    }
    return { days, hours, minutes };
  }

  function offsetPartsToHours(days, hours, minutes) {
    const d = Math.max(0, Math.floor(Number(days) || 0));
    const h = Math.max(0, Number(hours) || 0);
    const m = Math.max(0, Math.min(59, Math.floor(Number(minutes) || 0)));
    return d * 24 + h + m / 60;
  }

  /** Match Campaign Builder drip preview wording (days, hours, minutes). */
  function formatOffsetLabel(totalHours) {
    const { days, hours, minutes } = splitOffsetParts(totalHours);
    const parts = [];
    if (days) parts.push(`${days}d`);
    if (hours) parts.push(`${hours}h`);
    if (minutes || parts.length === 0) parts.push(`${minutes}m`);
    return parts.join(" ");
  }

  function inferDelayUnit(totalHours) {
    const t = Number(totalHours);
    if (!Number.isFinite(t) || t <= 0) return { amount: 1, unit: "days" };
    const minutes = t * 60;
    if (Math.abs(t * 60 - Math.round(t * 60)) < 1e-6 && t < 1) {
      return { amount: Math.max(1, Math.round(minutes)), unit: "minutes" };
    }
    if (Math.abs(t / 24 - Math.round(t / 24)) < 1e-6 && t >= 24) {
      return { amount: Math.max(1, Math.round(t / 24)), unit: "days" };
    }
    if (Math.abs(t - Math.round(t)) < 1e-6) {
      return { amount: Math.max(1, Math.round(t)), unit: "hours" };
    }
    return { amount: Math.max(1, Math.round(minutes)), unit: "minutes" };
  }

  function delayAmountToHours(amount, unit) {
    const n = Math.max(0, Number(amount) || 0);
    const u = String(unit || "hours").toLowerCase();
    if (u === "minutes") return n / 60;
    if (u === "days") return n * 24;
    return n;
  }

  function plainTextSnippet(html, maxLen) {
    const raw = String(html || "")
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/gi, " ")
      .replace(/\s+/g, " ")
      .trim();
    if (raw.length <= maxLen) return raw;
    return `${raw.slice(0, Math.max(0, maxLen - 1))}…`;
  }

  /**
   * Minimal sanitizer for the read-only email preview inside the Journey
   * "View message" dialog. Removes <script> blocks and any `on*` event-handler
   * attributes; keeps paragraphs, links, images, lists, tables, and the saved
   * signature block (`<div class="campaign-email-signature-block">...`).
   */
  function sanitizeJourneyEmailHtml(rawHtml) {
    const stripped = String(rawHtml || "")
      .replace(/<script[\s\S]*?<\/script>/gi, "")
      .replace(/<style[\s\S]*?<\/style>/gi, (m) => m); // keep <style> blocks already inside the saved HTML
    try {
      const template = document.createElement("template");
      template.innerHTML = stripped;
      template.content.querySelectorAll("*").forEach((node) => {
        [...node.attributes].forEach((attr) => {
          const name = attr.name.toLowerCase();
          if (name.startsWith("on")) node.removeAttribute(attr.name);
          if (name === "href" && /^\s*javascript:/i.test(attr.value || "")) {
            node.setAttribute("href", "#");
          }
        });
      });
      return template.innerHTML;
    } catch {
      return stripped;
    }
  }

  const JOURNEY_MERGE_FIELDS = [
    { slug: "full_name", label: "Full name" },
    { slug: "first_name", label: "First name" },
    { slug: "last_name", label: "Last name" },
    { slug: "age", label: "Age" },
    { slug: "email", label: "Email" },
    { slug: "phone", label: "Phone" },
    { slug: "state", label: "State" },
    { slug: "date_of_contact", label: "Date of contact" },
    { slug: "quote", label: "Quote" },
    { slug: "policy_number", label: "Policy number" },
    { slug: "coverage_start_date", label: "Coverage start date" },
    { slug: "policy_renewal", label: "Policy renewal date" },
    { slug: "upon_approval", label: "Upon approval" },
    { slug: "vcall", label: "Verification call" },
    { slug: "insurance_type", label: "Insurance type" },
    { slug: "good_through", label: "Good through" },
    { slug: "unsubscribe_url", label: "Unsubscribe link" }
  ];
  const JOURNEY_MERGE_SLUGS = new Set(JOURNEY_MERGE_FIELDS.map((row) => row.slug));
  let journeyCustomMergeRows = null;

  function normalizeJourneyMergeSlug(raw) {
    return String(raw || "")
      .toLowerCase()
      .replace(/[\s-]+/g, "_")
      .replace(/[^a-z0-9_]/g, "")
      .replace(/_+/g, "_")
      .replace(/^_+|_+$/g, "");
  }

  function rememberJourneyMergeRange(editor) {
    if (!editor) return;
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return;
    const range = sel.getRangeAt(0);
    if (!editor.contains(range.commonAncestorContainer)) return;
    editor._journeyMergeRange = range.cloneRange();
  }

  function insertJourneyMergeToken(target, token) {
    const text = String(token || "");
    if (!target || !text) return;
    const tag = String(target.tagName || "").toUpperCase();
    if (tag === "TEXTAREA" || tag === "INPUT") {
      const start = Number.isInteger(target.selectionStart) ? target.selectionStart : target.value.length;
      const end = Number.isInteger(target.selectionEnd) ? target.selectionEnd : start;
      target.value = target.value.slice(0, start) + text + target.value.slice(end);
      const caret = start + text.length;
      target.focus();
      target.selectionStart = caret;
      target.selectionEnd = caret;
      return;
    }
    target.focus();
    const sel = window.getSelection();
    if (target._journeyMergeRange && sel) {
      sel.removeAllRanges();
      try {
        sel.addRange(target._journeyMergeRange);
      } catch {
        /* The saved caret can go stale if the message was replaced. */
      }
    }
    const inserted = document.execCommand("insertText", false, text);
    if (!inserted) document.execCommand("insertHTML", false, escapeHtml(text));
    rememberJourneyMergeRange(target);
  }

  function fillJourneyMergeSelect(selectEl, customRows) {
    if (!selectEl || !selectEl.isConnected) return;
    selectEl.innerHTML = "";
    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = "Choose merge field";
    selectEl.appendChild(placeholder);
    JOURNEY_MERGE_FIELDS.forEach((def) => {
      const opt = document.createElement("option");
      opt.value = `{{${def.slug}}}`;
      opt.textContent = `${def.label} ({{${def.slug}}})`;
      selectEl.appendChild(opt);
    });
    const rows = Array.isArray(customRows) ? customRows : [];
    if (!rows.length) return;
    const header = document.createElement("option");
    header.disabled = true;
    header.textContent = "Your merge fields";
    selectEl.appendChild(header);
    rows.forEach((row) => {
      const slug = normalizeJourneyMergeSlug(row.slug);
      if (!slug || JOURNEY_MERGE_SLUGS.has(slug)) return;
      const opt = document.createElement("option");
      opt.value = `{{${slug}}}`;
      opt.textContent = row.label ? `${row.label} ({{${slug}}})` : `{{${slug}}}`;
      selectEl.appendChild(opt);
    });
  }

  function wireJourneyMergeSelect(selectEl, getTarget) {
    if (!selectEl) return;
    fillJourneyMergeSelect(selectEl, journeyCustomMergeRows || []);
    selectEl.addEventListener("change", () => {
      const token = String(selectEl.value || "").trim();
      if (!token) return;
      insertJourneyMergeToken(getTarget(), token);
      selectEl.value = "";
    });
    if (journeyCustomMergeRows) return;
    fetchApiJson("/api/custom-merge-fields")
      .then(({ response, data }) => {
        if (!response.ok || !Array.isArray(data)) return;
        journeyCustomMergeRows = data
          .map((row) => ({
            slug: normalizeJourneyMergeSlug(row && row.field_key),
            label: String((row && row.label) || "").trim()
          }))
          .filter((row) => row.slug && !JOURNEY_MERGE_SLUGS.has(row.slug));
        fillJourneyMergeSelect(selectEl, journeyCustomMergeRows);
      })
      .catch(() => {});
  }

  /**
   * Render the journey node detail dialog as an editable form. Saving it
   * updates the in-memory node, refreshes the on-board label, and — when the
   * journey is linked to a campaign — pushes the change straight to the
   * Campaign Builder so the two views stay in sync.
   */
  function showNodeStepDetails(node) {
    if (!stepDialog || !stepDialogHeading || !stepDialogBody || !node) return;
    const type = String(node.type || "").toLowerCase();
    const baseTitle = String(node.label || "Step").trim() || "Step";
    stepDialogHeading.textContent = baseTitle;

    const isStartOrEnd = type === "start" || type === "success";
    const isEditableStep = ["email", "sms", "call", "delay"].includes(type);

    let formInnerHtml = "";

    if (isStartOrEnd) {
      const noteText =
        type === "start"
          ? "Entry point for this journey. Connect the first real step (email, SMS, call, or delay) from here."
          : "Marks the end of the drip on the Campaigns page. Every path should end here.";
      let enrollTagValue = String(node.dripEnrollTag || "").trim();
      if (!enrollTagValue && type === "start" && selectedCampaignId != null) {
        const camp = cachedCampaigns.find((row) => Number(row.id) === Math.floor(Number(selectedCampaignId)));
        if (camp) enrollTagValue = getEnrollTagFromCampaign(camp);
      }
      const startTagRow =
        type === "start"
          ? `
        <div class="journey-step-edit-row">
          <label class="journey-step-edit-label" for="journeyEnrollTagPick">Enrollment trigger tag</label>
          <select id="journeyEnrollTagPick" aria-label="Existing enrollment tags">
            <option value="">Choose a tag</option>
          </select>
          <div class="journey-category-controls">
            <input id="journeyEditEnrollTag" name="dripEnrollTag" type="text" autocomplete="off" spellcheck="false"
              placeholder="Type a new tag"
              value="${escapeHtml(enrollTagValue)}" />
            <button type="button" id="journeyAddEnrollTagBtn">Add tag</button>
          </div>
          <p class="journey-step-edit-note" style="margin: 0">Type a new tag and click Add tag, or choose one above. Contacts enter this journey when that tag is applied.</p>
        </div>`
          : "";
      formInnerHtml = `
        <div class="journey-step-edit-row">
          <label class="journey-step-edit-label">Node type</label>
          <input type="text" readonly value="${escapeHtml(type === "start" ? "Start" : "Complete / success")}" />
        </div>
        ${startTagRow}
        <div class="journey-step-edit-row">
          <label class="journey-step-edit-label" for="journeyEditLabel">Board label</label>
          <input id="journeyEditLabel" name="label" type="text" value="${escapeHtml(String(node.label || ""))}" />
        </div>
        <p class="journey-step-edit-note">${escapeHtml(noteText)}</p>
      `;
    } else if (isEditableStep) {
      if (type === "delay") {
        const hours =
          Number.isFinite(Number(node.dripOffsetHours)) && Number(node.dripOffsetHours) > 0
            ? Number(node.dripOffsetHours)
            : 24;
        const inferred = inferDelayUnit(hours);
        const unit =
          node.dripDelayUnit === "minutes" || node.dripDelayUnit === "hours" || node.dripDelayUnit === "days"
            ? node.dripDelayUnit
            : inferred.unit;
        const amount =
          unit === "days" ? hours / 24 : unit === "minutes" ? hours * 60 : hours;
        const amountShown = Number.isInteger(amount) ? String(amount) : String(Math.round(amount * 1000) / 1000);
        formInnerHtml = `
        <div class="journey-step-edit-row">
          <label class="journey-step-edit-label">Step type</label>
          <input type="text" readonly value="Delay" />
        </div>
        <div class="journey-step-edit-row">
          <span class="journey-step-edit-label">Wait before the next step</span>
          <div class="journey-step-offset-group">
            <label><span>Amount</span><input id="journeyEditDelayAmount" name="dripDelayAmount" type="number" min="1" step="1" value="${escapeHtml(amountShown)}" required /></label>
            <label><span>Unit</span>
              <select id="journeyEditDelayUnit" name="dripDelayUnit">
                <option value="minutes"${unit === "minutes" ? " selected" : ""}>Minutes</option>
                <option value="hours"${unit === "hours" ? " selected" : ""}>Hours</option>
                <option value="days"${unit === "days" ? " selected" : ""}>Days</option>
              </select>
            </label>
          </div>
        </div>
        <p class="journey-step-edit-note">Contacts wait this long after the previous step, then continue. Email, SMS, and Call still send at the total wait from enrollment.</p>
      `;
      } else {
      const usesDelayTiming = state.nodes.some((n) => n.type === "delay");
      const offsetTotal =
        Number.isFinite(Number(node.dripOffsetHours)) && Number(node.dripOffsetHours) >= 0
          ? Number(node.dripOffsetHours)
          : 0;
      const { days: offsetDays, hours: offsetHours, minutes: offsetMinutes } = splitOffsetParts(offsetTotal);
      formInnerHtml = `
        <div class="journey-step-edit-row">
          <label class="journey-step-edit-label">Channel</label>
          <input type="text" readonly value="${escapeHtml(type.toUpperCase())}" />
        </div>
        ${
          usesDelayTiming
            ? `<p class="journey-step-edit-note">Timing comes from Delay steps before this one. Add or edit a Delay to wait minutes, hours, or days.</p>`
            : `<div class="journey-step-edit-row">
          <span class="journey-step-edit-label">When to send</span>
          <div class="journey-step-offset-group">
            <label><span>Days</span><input id="journeyEditOffsetDays" name="dripOffsetDays" type="number" min="0" step="1" value="${escapeHtml(String(offsetDays))}" /></label>
            <label><span>Hours</span><input id="journeyEditOffsetHours" name="dripOffsetHoursPart" type="number" min="0" step="1" value="${escapeHtml(String(offsetHours))}" /></label>
            <label><span>Minutes</span><input id="journeyEditOffsetMinutes" name="dripOffsetMinutes" type="number" min="0" max="59" step="1" value="${escapeHtml(String(offsetMinutes))}" /></label>
          </div>
          <p class="journey-step-edit-note" style="margin: 6px 0 0">Use 0, 0, and 0 to send as soon as the contact gets the tag.</p>
        </div>`
        }
      `;
      if (type === "email") {
        const rawBody = String(node.dripBody || "");
        // Editor shows message only — signature is appended on save when enabled.
        const bodyWithoutSig = stripCampaignSignatureBlocks(rawBody);
        let bodyEditorHtml = "";
        if (bodyWithoutSig.trim() && /<[a-z][\s\S]*>/i.test(bodyWithoutSig)) {
          bodyEditorHtml = sanitizeJourneyEmailHtml(bodyWithoutSig);
        } else if (bodyWithoutSig.trim()) {
          bodyEditorHtml = `<p>${escapeHtml(bodyWithoutSig.trim()).replace(/\r?\n/g, "<br>")}</p>`;
        } else {
          bodyEditorHtml = "<p></p>";
        }
        const includeChecked = isJourneyIncludeSignatureEnabled() ? " checked" : "";
        formInnerHtml += `
          <div class="journey-step-edit-row">
            <label class="journey-step-edit-label" for="journeyEditEmailFrom">Send from</label>
            <select id="journeyEditEmailFrom" name="dripEmailFrom" aria-label="Email address to send from">
              <option value="">Choose an email address</option>
            </select>
            <p id="journeyEditEmailFromNote" class="journey-step-edit-note" style="margin: 4px 0 0">
              <span id="journeyEditEmailFromNoteText">Leave this on Choose an email address to use the campaign From email.</span>
              <a href="/settings.html?section=email-senders">Add addresses in Settings</a>.
            </p>
          </div>
          <div class="journey-step-edit-row">
            <label class="journey-step-edit-label" for="journeyEditEmailTemplate">Email template</label>
            <select id="journeyEditEmailTemplate" class="journey-step-email-template" name="emailTemplateId">
              <option value="">Load from saved template…</option>
            </select>
          </div>
          <div class="journey-step-edit-row">
            <label class="journey-step-edit-label" for="journeyEditSubject">Subject</label>
            <input id="journeyEditSubject" name="dripSubject" type="text" value="${escapeHtml(String(node.dripSubject || ""))}" />
          </div>
          <div class="journey-step-edit-row">
            <label class="journey-step-edit-label" for="journeyEditEmailMerge">Merge field</label>
            <select id="journeyEditEmailMerge" aria-label="Insert merge field into the subject or email">
              <option value="">Choose merge field</option>
            </select>
          </div>
          <div class="journey-step-edit-row">
            <label class="journey-step-edit-label">Email body</label>
            <div class="journey-email-html-preview journey-step-html-editor" contenteditable="true" data-field="dripBody" spellcheck="false">${bodyEditorHtml}</div>
          </div>
          <div class="journey-step-edit-row">
            <label class="journey-step-edit-label journey-signature-toggle-row" for="journeyEditIncludeSignature">
              <input type="checkbox" id="journeyEditIncludeSignature" name="includeSignature"${includeChecked} />
              <span>Include email signature</span>
            </label>
            <p class="journey-step-edit-note" style="margin: 4px 0 0">Appends your saved signature from Settings when you save this step.</p>
          </div>
        `;
      } else if (type === "sms") {
        formInnerHtml += `
          <div class="journey-step-edit-row">
            <label class="journey-step-edit-label" for="journeyEditSmsFrom">Text from</label>
            <select id="journeyEditSmsFrom" name="dripTwilioFrom" aria-label="Phone number to text from">
              <option value="">Choose a phone number</option>
            </select>
            <p id="journeyEditSmsFromNote" class="journey-step-edit-note" style="margin: 0" hidden>No phone numbers yet. Add one in Settings, then reopen this step.</p>
          </div>
          <div class="journey-step-edit-row">
            <label class="journey-step-edit-label" for="journeyEditSmsMerge">Merge field</label>
            <select id="journeyEditSmsMerge" aria-label="Insert merge field into the SMS message">
              <option value="">Choose merge field</option>
            </select>
          </div>
          <div class="journey-step-edit-row">
            <label class="journey-step-edit-label" for="journeyEditSmsBody">SMS message</label>
            <textarea id="journeyEditSmsBody" name="dripBody" rows="5">${escapeHtml(String(node.dripBody || ""))}</textarea>
            <p class="journey-step-edit-note" style="margin: 4px 0 0">Sent exactly as written. Phone numbers are not changed.</p>
          </div>
          <div class="journey-step-edit-row">
            <label class="journey-step-edit-label" for="journeyEditSmsEnding">Added under this text</label>
            <textarea id="journeyEditSmsEnding" data-sms-ending rows="2" maxlength="300">Reply STOP to opt out.</textarea>
            <p class="journey-step-edit-note" style="margin: 4px 0 0">This line is saved for every text, including single texts. Clear it to send only the message.</p>
          </div>
          <div class="journey-step-edit-row">
            <span class="journey-step-edit-label">Photo</span>
            <div class="sms-photo-row">
              <label class="sms-photo-attach" for="journeyEditSmsPhoto">Attach photo</label>
              <input id="journeyEditSmsPhoto" class="sms-photo-input" type="file" accept="image/jpeg,image/jpg,image/pjpeg,image/png,image/gif,image/webp,.jpg,.jpeg,.JPG,.JPEG,.png,.gif,.webp" />
              <button type="button" id="journeyEditSmsPhotoRemove" class="sms-photo-clear" hidden>Remove photo</button>
            </div>
            <img id="journeyEditSmsPhotoPreview" alt="" hidden style="width:72px;height:72px;object-fit:cover;border-radius:8px;border:1px solid #cbd5e1;background:#f8fafc;margin-top:8px;" />
            <p class="journey-step-edit-note" style="margin: 4px 0 0">Optional. The picture is sent with this text the same way as a single text. JPG or PNG, under 5 MB.</p>
          </div>
        `;
      } else if (type === "call") {
        formInnerHtml += `
          <div class="journey-step-edit-row">
            <label class="journey-step-edit-label" for="journeyEditCallUrl">TwiML URL</label>
            <input id="journeyEditCallUrl" name="dripCallTwimlUrl" type="text" value="${escapeHtml(String(node.dripCallTwimlUrl || ""))}" placeholder="https://example.com/twiml.xml" />
          </div>
        `;
      }
      formInnerHtml += `
        <p class="journey-step-edit-note">${
          selectedCampaignId != null || journeyCampaignNameValue()
            ? "Save stores this step on the campaign."
            : "Enter a campaign name, then Save."
        }</p>
      `;
      }
    } else if (type === "condition") {
      const rule = String(node.conditionRule || "email_opened");
      const windowDays = String(node.conditionWindowDays || "3");
      formInnerHtml = `
        <div class="journey-step-edit-row">
          <label class="journey-step-edit-label" for="journeyEditConditionRule">Condition</label>
          <select id="journeyEditConditionRule" name="conditionRule">
            <option value="email_opened"${rule === "email_opened" ? " selected" : ""}>Email opened</option>
            <option value="email_clicked"${rule === "email_clicked" ? " selected" : ""}>Email clicked</option>
            <option value="replied"${rule === "replied" ? " selected" : ""}>Contact replied</option>
            <option value="not_responded"${rule === "not_responded" ? " selected" : ""}>No response</option>
          </select>
        </div>
        <div class="journey-step-edit-row">
          <label class="journey-step-edit-label" for="journeyEditConditionWindow">Within days</label>
          <input id="journeyEditConditionWindow" name="conditionWindowDays" type="number" min="1" step="1" value="${escapeHtml(windowDays)}" />
        </div>
        <p class="journey-step-edit-note">Condition nodes are visible planning aids on this canvas. Campaign saving still requires one linear path until branch execution is enabled.</p>
      `;
    } else {
      formInnerHtml = `<p class="journey-step-edit-note">No editable fields for this node type.</p>`;
    }

    const saveLabel = "Save";

    stepDialogBody.innerHTML = `
      <form id="journeyStepEditForm" class="journey-step-edit-form" autocomplete="off">
        ${formInnerHtml}
        <div class="journey-step-edit-actions">
          <button type="button" class="journey-step-cancel-btn">Cancel</button>
          ${isStartOrEnd || isEditableStep || type === "condition"
            ? `<button type="submit" class="journey-step-save-btn">${escapeHtml(saveLabel)}</button>`
            : ""}
        </div>
      </form>
    `;

    const form = stepDialogBody.querySelector("#journeyStepEditForm");
    if (form) {
      form.addEventListener("submit", (event) => {
        event.preventDefault();
        saveStepEditsFromDialog(node, form);
      });
      const cancelBtn = form.querySelector(".journey-step-cancel-btn");
      if (cancelBtn) {
        cancelBtn.addEventListener("click", () => {
          try { stepDialog.close(); } catch { /* dialog may already be closed */ }
        });
      }
      if (type === "start") {
        const tagInput = form.querySelector("#journeyEditEnrollTag");
        const tagPick = form.querySelector("#journeyEnrollTagPick");
        const addTagBtn = form.querySelector("#journeyAddEnrollTagBtn");
        const showTags = () => fillJourneyEnrollTagSelect(tagPick, tagInput?.value);
        loadJourneySavedTags()
          .then(showTags)
          .catch(showTags);
        if (tagPick && tagInput) {
          tagPick.addEventListener("change", () => {
            if (tagPick.value) tagInput.value = tagPick.value;
          });
        }
        if (addTagBtn && tagInput) {
          addTagBtn.addEventListener("click", () => {
            addJourneyEnrollTag(tagInput.value)
              .then((tag) => {
                if (!tag) return;
                tagInput.value = tag;
                fillJourneyEnrollTagSelect(tagPick, tag);
                showToast(`Tag “${tag}” added. Click Save to use it on this campaign.`, "success");
              })
              .catch((err) => showToast(err.message || "Could not add that tag.", "danger"));
          });
        }
      }
      if (type === "email") {
        const templateSel = form.querySelector(".journey-step-email-template");
        populateJourneyEmailTemplateSelect(templateSel);
        loadJourneyEmailTemplates()
          .then(() => populateJourneyEmailTemplateSelect(templateSel))
          .catch(() => {});
        if (templateSel) {
          templateSel.addEventListener("change", () => {
            const templateId = Number(templateSel.value);
            if (!Number.isInteger(templateId) || templateId < 1) return;
            const picked = journeyEmailTemplateRowsCache.find((t) => Number(t.id) === templateId);
            if (!picked) return;
            const subjectEl = form.querySelector("#journeyEditSubject");
            const bodyEditor = form.querySelector('[data-field="dripBody"]');
            if (subjectEl) subjectEl.value = String(picked.subject || "");
            if (bodyEditor) {
              const htmlBody = String(picked.body || "");
              bodyEditor.innerHTML = htmlBody
                ? sanitizeJourneyEmailHtml(htmlBody)
                : "<p><br></p>";
            }
          });
        }
        const subjectEl = form.querySelector("#journeyEditSubject");
        const bodyEditor = form.querySelector('[data-field="dripBody"]');
        let emailMergeTarget = bodyEditor;
        if (subjectEl) {
          subjectEl.addEventListener("focus", () => {
            emailMergeTarget = subjectEl;
          });
        }
        if (bodyEditor) {
          const remember = () => {
            emailMergeTarget = bodyEditor;
            rememberJourneyMergeRange(bodyEditor);
          };
          bodyEditor.addEventListener("keyup", remember);
          bodyEditor.addEventListener("mouseup", remember);
          bodyEditor.addEventListener("focus", remember);
        }
        wireJourneyMergeSelect(form.querySelector("#journeyEditEmailMerge"), () => emailMergeTarget || bodyEditor);
        const emailFromSel = form.querySelector("#journeyEditEmailFrom");
        const emailFromNote = form.querySelector("#journeyEditEmailFromNoteText");
        loadJourneyEmailFromData()
          .then(() => fillJourneyEmailFromSelect(emailFromSel, node.dripEmailFrom, emailFromNote))
          .catch(() => fillJourneyEmailFromSelect(emailFromSel, node.dripEmailFrom, emailFromNote));
      }
      if (type === "sms") {
        wireJourneySmsPhoto(form, node);
        wireJourneyMergeSelect(form.querySelector("#journeyEditSmsMerge"), () => form.querySelector("#journeyEditSmsBody"));
        if (window.cadenceSmsEnding) window.cadenceSmsEnding.load(false);
        const fromSel = form.querySelector("#journeyEditSmsFrom");
        const fromNote = form.querySelector("#journeyEditSmsFromNote");
        loadJourneyTwilioFromData()
          .then(() => fillJourneySmsFromSelect(fromSel, node.dripTwilioFrom, fromNote))
          .catch(() => fillJourneySmsFromSelect(fromSel, node.dripTwilioFrom, fromNote));
      }
    }

    stepDialog.showModal();
  }

  /**
   * Rebuilds the board label string for a node from its current drip fields.
   * Mirrors the format used by buildGraphFromCampaign so the visual node stays
   * in sync with the underlying campaign step after an in-popup edit.
   */
  function computeBoardLabelForNode(node) {
    const t = String(node?.type || "");
    if (t === "start") return String(node?.label || "Start").trim() || "Start";
    if (t === "success") return String(node?.label || "Complete").trim() || "Complete";
    const offHours = Number(node?.dripOffsetHours) || 0;
    const off = offHours > 0 ? `${formatOffsetLabel(offHours)} · ` : "";
    if (t === "email") {
      const sub = String(node?.dripSubject || "").trim() || "Email";
      return `${off}${sub.slice(0, 72)}${sub.length > 72 ? "…" : ""}`.trim();
    }
    if (t === "sms") {
      const hasPhoto = Boolean(String(node?.dripSmsMediaId || "").trim());
      const snippet = plainTextSnippet(String(node?.dripBody || ""), 48) || (hasPhoto ? "Photo" : "—");
      const photoNote = hasPhoto && snippet !== "Photo" ? " + photo" : "";
      return `${off}SMS · ${snippet}${photoNote}`.trim();
    }
    if (t === "call") {
      const tw = String(node?.dripCallTwimlUrl || "").trim();
      return `${off}Call · ${tw ? tw.slice(0, 52) + (tw.length > 52 ? "…" : "") : "voice"}`.trim();
    }
    if (t === "condition") {
      return String(node?.label || "Condition");
    }
    if (t === "delay") {
      const wait = formatOffsetLabel(Number(node?.dripOffsetHours) || 24);
      return `Wait ${wait}`;
    }
    return String(node?.label || "Step");
  }

  /**
   * Persist the form values back onto the node, refresh the on-board label
   * without disturbing the user's custom layout, and — when a campaign is
   * loaded — push the change to the backend so the Campaign Builder reflects
   * it immediately.
   */
  function showJourneySmsPhotoPreview(form, src) {
    const img = form.querySelector("#journeyEditSmsPhotoPreview");
    const removeBtn = form.querySelector("#journeyEditSmsPhotoRemove");
    if (!img) return;
    if (!src) {
      img.hidden = true;
      img.removeAttribute("src");
      if (removeBtn) removeBtn.hidden = true;
      return;
    }
    img.src = src;
    img.hidden = false;
    if (removeBtn) removeBtn.hidden = false;
  }

  async function uploadJourneySmsPhoto(file) {
    if (!file) return "";
    if (window.prepareSmsPhotoFile) file = await window.prepareSmsPhotoFile(file);
    if (file.size > 5 * 1024 * 1024) {
      throw new Error("That photo is too large for a text. Use a picture under 5 MB.");
    }
    const body = new FormData();
    body.append("photo", file);
    const { response, data } = await fetchApiJson("/api/drip/sms-photo", { method: "POST", body });
    if (!response.ok || !data?.id) throw new Error(data?.error || "Could not add that photo.");
    return String(data.id);
  }

  function wireJourneySmsPhoto(form, node) {
    const input = form.querySelector("#journeyEditSmsPhoto");
    const removeBtn = form.querySelector("#journeyEditSmsPhotoRemove");
    if (!input) return;
    const existing = String(node?.dripSmsMediaId || "").trim();
    form.dataset.removeSmsPhoto = "0";
    if (existing) showJourneySmsPhotoPreview(form, `/api/drip/sms-photo/${existing}`);
    input.addEventListener("change", () => {
      const file = input.files && input.files[0];
      form.dataset.removeSmsPhoto = "0";
      if (!file) {
        showJourneySmsPhotoPreview(form, existing ? `/api/drip/sms-photo/${existing}` : "");
        return;
      }
      if (file.size > 5 * 1024 * 1024) {
        input.value = "";
        showToast("That photo is too large for a text. Use a picture under 5 MB.", "error");
        showJourneySmsPhotoPreview(form, existing ? `/api/drip/sms-photo/${existing}` : "");
        return;
      }
      showJourneySmsPhotoPreview(form, URL.createObjectURL(file));
    });
    if (removeBtn) {
      removeBtn.addEventListener("click", () => {
        input.value = "";
        form.dataset.removeSmsPhoto = "1";
        showJourneySmsPhotoPreview(form, "");
      });
    }
  }

  async function saveStepEditsFromDialog(node, form) {
    if (!node || !form) return;
    const fd = new FormData(form);
    const t = String(node.type || "").toLowerCase();

    if (t === "start" || t === "success") {
      const newLabel = String(fd.get("label") || "").trim();
      node.label = newLabel || (t === "start" ? "Start" : "Complete");
      if (t === "start") {
        const enrollTag = String(fd.get("dripEnrollTag") || "").trim();
        if (enrollTag) node.dripEnrollTag = enrollTag;
        else delete node.dripEnrollTag;
      }
    } else if (["email", "sms", "call"].includes(t)) {
      if (form.querySelector("#journeyEditOffsetDays")) {
        const oh = offsetPartsToHours(fd.get("dripOffsetDays"), fd.get("dripOffsetHoursPart"), fd.get("dripOffsetMinutes"));
        if (Number.isFinite(oh) && oh >= 0) node.dripOffsetHours = oh;
      }

      if (t === "email") {
        node.dripSubject = String(fd.get("dripSubject") || "").trim();
        const bodyEditor = form.querySelector('[data-field="dripBody"]');
        const stepIncludeEl = form.querySelector("#journeyEditIncludeSignature");
        if (stepIncludeEl && journeyIncludeSignatureEl) {
          journeyIncludeSignatureEl.checked = Boolean(stepIncludeEl.checked);
          window.localStorage.setItem(
            EMAIL_INCLUDE_SIGNATURE_STORAGE_KEY,
            journeyIncludeSignatureEl.checked ? "1" : "0"
          );
        } else if (stepIncludeEl) {
          window.localStorage.setItem(
            EMAIL_INCLUDE_SIGNATURE_STORAGE_KEY,
            stepIncludeEl.checked ? "1" : "0"
          );
        }
        if (bodyEditor) {
          node.dripBody = composeJourneyEmailBodyForSave(bodyEditor.innerHTML);
        }
        node.dripEmailFrom = String(fd.get("dripEmailFrom") || "").trim();
      } else if (t === "sms") {
        node.dripBody = String(fd.get("dripBody") || "");
        node.dripTwilioFrom = String(fd.get("dripTwilioFrom") || "").trim();
        const photoInput = form.querySelector("#journeyEditSmsPhoto");
        const photoFile = photoInput && photoInput.files && photoInput.files[0];
        try {
          if (photoFile) {
            node.dripSmsMediaId = await uploadJourneySmsPhoto(photoFile);
          } else if (form.dataset.removeSmsPhoto === "1") {
            node.dripSmsMediaId = "";
          }
        } catch (err) {
          showToast(err.message || "Could not add that photo.", "error");
          return;
        }
      } else if (t === "call") {
        node.dripCallTwimlUrl = String(fd.get("dripCallTwimlUrl") || "").trim();
      }
      node.label = computeBoardLabelForNode(node);
    } else if (t === "delay") {
      const unitRaw = String(fd.get("dripDelayUnit") || "days").toLowerCase();
      const unit = unitRaw === "minutes" || unitRaw === "hours" || unitRaw === "days" ? unitRaw : "days";
      const hours = delayAmountToHours(fd.get("dripDelayAmount"), unit);
      if (!Number.isFinite(hours) || hours <= 0) {
        showToast("Enter a delay greater than 0.", "error");
        return;
      }
      node.dripDelayUnit = unit;
      node.dripOffsetHours = hours;
      node.label = computeBoardLabelForNode(node);
    } else if (t === "condition") {
      const rule = String(fd.get("conditionRule") || "email_opened").trim();
      const windowDays = Math.max(1, Math.floor(Number(fd.get("conditionWindowDays") || 3)));
      const labels = {
        email_opened: "If email opened",
        email_clicked: "If email clicked",
        replied: "If contact replied",
        not_responded: "If no response"
      };
      node.conditionRule = rule;
      node.conditionWindowDays = String(windowDays);
      node.label = labels[rule] || "Condition";
    } else {
      try { stepDialog.close(); } catch { /* */ }
      return;
    }

    // Update the on-board label in place to avoid a full re-render (which
    // would re-run layout heuristics and could shift positions).
    const cardEl = nodeEls.get(node.id);
    if (cardEl) {
      const titleEl = cardEl.querySelector(".journey-node-title");
      const subtitleEl = cardEl.querySelector(".journey-node-subtitle");
      const textEl = cardEl.querySelector(".journey-node-text");
      if (titleEl) titleEl.textContent = nodeDisplayTitle(node);
      else if (textEl && textEl.textContent !== node.label) textEl.textContent = node.label;
      if (subtitleEl) subtitleEl.textContent = nodeCardSubtitle(node);
      cardEl.setAttribute("title", nodeTooltipText(node, getFlowOrderedNodeIds().indexOf(node.id) + 1 || 1));
    }
    persistCurrentState();

    const saveBtn = form.querySelector(".journey-step-save-btn");
    if (saveBtn) saveBtn.disabled = true;

    const storeOnCampaign =
      (selectedCampaignId != null && Number.isFinite(Number(selectedCampaignId))) ||
      Boolean(journeyCampaignNameValue());
    if (storeOnCampaign) {
      try {
        const ok = await saveCampaignJourneyToServer({ silent: true });
        if (ok) {
          showToast("Saved.", "success");
        } else {
          showToast("The step is on the board. The campaign was not saved.", "danger");
        }
      } catch (err) {
        showToast(String(err?.message || "The campaign was not saved."), "danger");
      }
    } else {
      showToast("Enter a campaign name, then click Save.", "danger");
    }

    if (saveBtn) saveBtn.disabled = false;
    drawConnections();
    try { stepDialog.close(); } catch { /* dialog may already be closed */ }
  }

  function parseOffsetHoursFromLabel(label) {
    const s = String(label || "").trim();
    let total = 0;
    let rest = s;
    const dm = rest.match(/^(\d+)d\s*/i);
    if (dm) {
      total += Number(dm[1]) * 24;
      rest = rest.slice(dm[0].length);
    }
    const hm = rest.match(/^(\d+)h\s*/i);
    if (hm) {
      total += Number(hm[1]);
      rest = rest.slice(hm[0].length);
    }
    const mm = rest.match(/^(\d+)m\s*/i);
    if (mm) {
      total += Number(mm[1]) / 60;
      rest = rest.slice(mm[0].length);
    }
    if (rest.startsWith("·") || total > 0) {
      return Number.isFinite(total) ? total : NaN;
    }
    const legacyH = s.match(/^([\d.]+)h\s*·\s*/i);
    if (legacyH) {
      total += Number(legacyH[1]);
      return Number.isFinite(total) ? total : NaN;
    }
    return NaN;
  }

  function stripOffsetPrefix(label) {
    return String(label || "")
      .replace(/^(\d+d\s*)?(\d+h\s*)?(\d+m\s*)?/i, "")
      .replace(/^[\d.]+\s*h\s*/i, "")
      .replace(/^\s*·\s*/, "")
      .trim();
  }

  function emailBodyHasContent(html) {
    const s = String(html || "");
    if (/<img\s/i.test(s)) return true;
    const text = s
      .replace(/<[^>]+>/g, "")
      .replace(/&nbsp;/gi, " ")
      .replace(/\s+/g, " ")
      .trim();
    return text.length > 0;
  }

  function parseCampaignTagRules(c) {
    try {
      if (Array.isArray(c?.tag_rules)) return c.tag_rules;
      const raw = c?.tag_config;
      if (typeof raw === "string") return JSON.parse(raw || "[]");
      return [];
    } catch {
      return [];
    }
  }

  function getEnrollTagFromCampaignRules(tagRules) {
    const rules = Array.isArray(tagRules) ? tagRules : [];
    const enrollRule = rules.find((tr) => String(tr?.function || "").toLowerCase() === "enroll");
    return String(enrollRule?.tag || rules[0]?.tag || "").trim();
  }

  function getEnrollTagFromCampaign(c) {
    return getEnrollTagFromCampaignRules(parseCampaignTagRules(c));
  }

  function buildTagRulesFromEnrollTag(tag) {
    const t = String(tag || "").trim();
    if (!t) return [];
    return [{ tag: t, function: "enroll" }];
  }

  function getStartNode(graphState) {
    const nodes = graphState?.nodes || state.nodes;
    return nodes.find((n) => n.type === "start" || /-start$/i.test(String(n.id)));
  }

  function resolveTagRulesForSave(c, graphState) {
    const start = getStartNode(graphState);
    const fromStart = String(start?.dripEnrollTag ?? "").trim();
    if (fromStart) return buildTagRulesFromEnrollTag(fromStart);
    return parseCampaignTagRules(c);
  }

  function getJourneyEmailTemplateLabel(templateRow) {
    const category = String(templateRow?.category_name || "").trim();
    const name = String(templateRow?.name || "").trim() || "Template";
    return category ? `${category} - ${name}` : name;
  }

  function populateJourneyEmailTemplateSelect(selectEl) {
    if (!selectEl) return;
    const prev = String(selectEl.value || "");
    selectEl.innerHTML = '<option value="">Load from saved template…</option>';
    const sortedTemplates = [...journeyEmailTemplateRowsCache].sort((a, b) =>
      getJourneyEmailTemplateLabel(a).localeCompare(getJourneyEmailTemplateLabel(b), undefined, {
        sensitivity: "base"
      })
    );
    for (const row of sortedTemplates) {
      const opt = document.createElement("option");
      opt.value = String(row.id);
      opt.textContent = getJourneyEmailTemplateLabel(row);
      selectEl.appendChild(opt);
    }
    if (prev && [...selectEl.options].some((o) => o.value === prev)) {
      selectEl.value = prev;
    }
  }

  async function loadJourneyEmailTemplates() {
    const { response, data } = await fetchApiJson("/api/email/templates");
    if (!response.ok) throw new Error(data?.error || "Failed to load email templates");
    journeyEmailTemplateRowsCache = Array.isArray(data) ? data : [];
    document.querySelectorAll(".journey-step-email-template").forEach((selectEl) => {
      populateJourneyEmailTemplateSelect(selectEl);
    });
  }

  function syncJourneyTagsDatalist(extraTags) {
    let dl = document.getElementById("journeySavedTagsList");
    if (!dl) {
      dl = document.createElement("datalist");
      dl.id = "journeySavedTagsList";
      document.body.appendChild(dl);
    }
    const merged = new Set(journeySavedContactTags.map((t) => String(t).trim()).filter(Boolean));
    (extraTags || []).forEach((t) => {
      const v = String(t || "").trim();
      if (v) merged.add(v);
    });
    const sorted = [...merged].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));
    dl.innerHTML = sorted.map((t) => `<option value="${escapeHtml(t)}"></option>`).join("");
  }

  function journeyTagNames() {
    return [...new Set(journeySavedContactTags.map((t) => String(t || "").trim()).filter(Boolean))].sort((a, b) =>
      a.localeCompare(b, undefined, { sensitivity: "base" })
    );
  }

  function fillJourneyEnrollTagSelect(selectEl, selected) {
    if (!selectEl) return;
    const current = String(selected || "").trim();
    const tags = journeyTagNames();
    if (current && !tags.includes(current)) tags.push(current);
    tags.sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));
    selectEl.innerHTML = '<option value="">Choose a tag</option>';
    tags.forEach((tag) => {
      const opt = document.createElement("option");
      opt.value = tag;
      opt.textContent = tag;
      selectEl.appendChild(opt);
    });
    selectEl.value = current && tags.includes(current) ? current : "";
  }

  async function addJourneyEnrollTag(raw) {
    const tag = String(raw || "").trim();
    if (!tag) {
      showToast("Type a tag name first.", "danger");
      return "";
    }
    const { response, data } = await fetchApiJson("/api/contacts/tags", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tag })
    });
    if (!response.ok) {
      throw new Error((data && data.error) || "Could not add that tag.");
    }
    if (data && Array.isArray(data.tags)) journeySavedContactTags = data.tags;
    else if (!journeyTagNames().includes(tag)) journeySavedContactTags = [...journeySavedContactTags, tag];
    syncJourneyTagsDatalist([tag]);
    return tag;
  }

  let journeyTwilioFromData = null;

  async function loadJourneyTwilioFromData() {
    if (journeyTwilioFromData) return journeyTwilioFromData;
    const { response, data } = await fetchApiJson("/api/twilio/from-numbers");
    journeyTwilioFromData =
      response.ok && data && typeof data === "object"
        ? data
        : { primary: null, secondary: null, third: null, custom: [], builtinLabels: {} };
    return journeyTwilioFromData;
  }

  function fillJourneySmsFromSelect(selectEl, selected, noteEl) {
    if (!selectEl) return;
    const data = journeyTwilioFromData || {};
    if (typeof window.applyTwilioFromToStepSelect === "function") {
      window.applyTwilioFromToStepSelect(selectEl, data);
      const first = selectEl.options[0];
      if (first && first.value === "") first.textContent = "Choose a phone number";
    } else {
      selectEl.innerHTML = "";
      const placeholder = document.createElement("option");
      placeholder.value = "";
      placeholder.textContent = "Choose a phone number";
      selectEl.appendChild(placeholder);
      const labels = data.builtinLabels || {};
      [
        ["primary", data.primary, labels.primary],
        ["secondary", data.secondary, labels.secondary],
        ["third", data.third, labels.third]
      ].forEach(([value, number, label]) => {
        const num = String(number || "").trim();
        if (!num) return;
        const opt = document.createElement("option");
        opt.value = value;
        opt.textContent = label ? `${label}: ${num}` : num;
        selectEl.appendChild(opt);
      });
      (Array.isArray(data.custom) ? data.custom : []).forEach((row) => {
        const num = String(row && row.number ? row.number : "").trim();
        if (!num) return;
        const label = String((row && row.label) || "").trim();
        const opt = document.createElement("option");
        opt.value = num;
        opt.textContent = label ? `${label}: ${num}` : num;
        selectEl.appendChild(opt);
      });
    }
    const current = String(selected || "").trim();
    if (current && [...selectEl.options].some((opt) => opt.value === current)) selectEl.value = current;
    else selectEl.value = "";
    const hasNumbers = [...selectEl.options].some((opt) => opt.value);
    if (noteEl) noteEl.hidden = hasNumbers;
  }

  let journeyEmailFromData = null;

  async function loadJourneyEmailFromData() {
    if (journeyEmailFromData) return journeyEmailFromData;
    const { response, data } = await fetchApiJson("/api/email/options");
    const detailed =
      response.ok && data && Array.isArray(data.fromAddresses) && data.fromAddresses.length
        ? data.fromAddresses
        : response.ok && data && Array.isArray(data.fromOptions)
          ? data.fromOptions.map((addr) => ({ email: addr, label: "" }))
          : [];
    journeyEmailFromData = detailed
      .map((entry) => ({
        email: String((entry && entry.email) || "").trim(),
        label: String((entry && entry.label) || "").trim()
      }))
      .filter((entry) => entry.email);
    return journeyEmailFromData;
  }

  function fillJourneyEmailFromSelect(selectEl, selected, noteEl) {
    if (!selectEl) return;
    const list = Array.isArray(journeyEmailFromData) ? journeyEmailFromData : [];
    selectEl.innerHTML = "";
    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = "Choose an email address";
    selectEl.appendChild(placeholder);
    for (const entry of list) {
      const opt = document.createElement("option");
      opt.value = entry.email;
      opt.textContent = entry.label ? `${entry.label} — ${entry.email}` : entry.email;
      selectEl.appendChild(opt);
    }
    const current = String(selected || "").trim();
    const matched = current
      ? [...selectEl.options].find((opt) => opt.value.toLowerCase() === current.toLowerCase())
      : null;
    selectEl.value = matched ? matched.value : "";
    if (noteEl) {
      noteEl.textContent = list.length
        ? "Leave this on Choose an email address to use the campaign From email."
        : "No sender addresses yet. Add one in Settings, then reopen this step.";
    }
  }

  async function loadJourneySavedTags() {
    const { response, data } = await fetchApiJson("/api/contacts/tags");
    if (response.ok && data && Array.isArray(data.tags)) {
      journeySavedContactTags = data.tags;
    } else {
      journeySavedContactTags = [];
    }
    syncJourneyTagsDatalist();
  }

  /** Campaign drip supports one linear path only (matches DB model). */
  function extractLinearDripNodes(graphState) {
    const starts = graphState.nodes.filter((n) => n.type === "start" || /-start$/i.test(String(n.id)));
    if (starts.length !== 1) {
      throw new Error('Exactly one Start node is required (use type "Start" or load from a campaign).');
    }
    let curId = starts[0].id;
    const stepNodes = [];
    const visited = new Set();
    for (;;) {
      if (visited.has(curId)) throw new Error("Journey has a loop; fix connections before saving.");
      visited.add(curId);
      const outs = graphState.links.filter((l) => l.from === curId);
      if (outs.length === 0) {
        throw new Error('Connect steps through to the Complete node (success type).');
      }
      if (outs.length > 1) {
        throw new Error(
          "Saving requires a linear drip with no branches. Use only one outgoing connection from each step."
        );
      }
      const nextId = outs[0].to;
      const cur = graphState.nodes.find((n) => n.id === nextId);
      if (!cur) throw new Error("Broken connection — target node missing.");
      if (cur.type === "success" || /-end$/i.test(String(cur.id)) || String(cur.label || "").trim() === "Complete") {
        break;
      }
      if (cur.type === "start") throw new Error("Invalid path — Start appeared twice.");
      if (cur.type === "condition") {
        throw new Error("Condition branches are visual planning aids right now. Remove condition nodes before saving this campaign.");
      }
      if (cur.type === "delay") {
        stepNodes.push(cur);
        curId = cur.id;
        if (stepNodes.length > 250) throw new Error("Path too long.");
        continue;
      }
      if (!["email", "sms", "call"].includes(cur.type)) {
        throw new Error(`Step "${cur.label}" must be Email, SMS, Call, or Delay to save.`);
      }
      stepNodes.push(cur);
      curId = cur.id;
      if (stepNodes.length > 250) throw new Error("Path too long.");
    }
    if (!stepNodes.some((n) => ["email", "sms", "call"].includes(n.type))) {
      throw new Error("Add at least one Email, SMS, or Call step between Start and Complete.");
    }
    return stepNodes;
  }

  function buildDripStepsPayload(linearNodes) {
    const hasDelay = linearNodes.some((n) => n.type === "delay");
    let elapsed = 0;
    const sendNodes = [];
    for (const node of linearNodes) {
      if (node.type === "delay") {
        let wait = Number(node.dripOffsetHours);
        if (!Number.isFinite(wait) || wait < 0) wait = 24;
        elapsed += wait;
        continue;
      }
      sendNodes.push({ node, elapsed });
    }
    if (!sendNodes.length) {
      throw new Error("Add at least one Email, SMS, or Call step between Start and Complete.");
    }
    return sendNodes.map(({ node, elapsed: waitBefore }, index) => {
      const channel = node.type;
      let offset_hours = hasDelay ? waitBefore : Number(node.dripOffsetHours);
      if (!hasDelay) {
        if (!Number.isFinite(offset_hours) || offset_hours < 0) {
          offset_hours = parseOffsetHoursFromLabel(node.label);
        }
        if (!Number.isFinite(offset_hours) || offset_hours < 0) {
          offset_hours = 0;
        }
      } else if (!Number.isFinite(offset_hours) || offset_hours < 0) {
        offset_hours = 0;
      }

      let subject = String(node.dripSubject ?? "").trim();
      let body = String(node.dripBody ?? "").trim();
      let call_twiml_url = String(node.dripCallTwimlUrl ?? "").trim();
      const stripped = stripOffsetPrefix(node.label);

      if (channel === "email") {
        if (!subject) subject = stripped || `Step ${index + 1}`;
        if (!emailBodyHasContent(body)) {
          body = `<p>${escapeHtml(stripped || subject)}</p>`;
        }
        body = composeJourneyEmailBodyForSave(body);
      } else if (channel === "sms") {
        if (!body) body = stripped || "SMS";
      }

      if (channel === "call" && call_twiml_url && !/^https?:\/\//i.test(call_twiml_url)) {
        throw new Error(`Call step "${node.label || "Call"}": TwiML URL must start with http:// or https://`);
      }

      return {
        offset_hours,
        channel,
        subject: channel === "email" ? subject : "",
        body: channel === "email" || channel === "sms" ? body : "",
        call_twiml_url: channel === "call" ? call_twiml_url : "",
        twilio_from: channel === "sms" || channel === "call" ? String(node.dripTwilioFrom || "").trim() : "",
        email_from: channel === "email" ? String(node.dripEmailFrom || "").trim() : "",
        sms_media_id: channel === "sms" ? String(node.dripSmsMediaId || "").trim() : ""
      };
    });
  }


  function defaultNewCampaignGraph() {
    return normalizeState({
      nodes: [
        { id: "draft-start", label: "Start", type: "start", x: 40, y: 40 },
        {
          id: "draft-step-1",
          label: "0h · Welcome SMS",
          type: "sms",
          x: 40,
          y: 120,
          dripOffsetHours: 0,
          dripBody: "Thanks for connecting — we'll be in touch soon."
        },
        { id: "draft-end", label: "Complete", type: "success", x: 40, y: 200 }
      ],
      links: [
        { id: uid("link"), from: "draft-start", to: "draft-step-1", label: "" },
        { id: uid("link"), from: "draft-step-1", to: "draft-end", label: "" }
      ]
    });
  }

  function populateJourneyCategorySelect() {
    if (!journeyCampaignCategorySelect) return;
    const prev = String(journeyCampaignCategorySelect.value || "");
    const cats = Array.isArray(cachedCampaignCategories) ? cachedCampaignCategories : [];
    journeyCampaignCategorySelect.innerHTML = '<option value="">No category</option>';
    for (const c of cats) {
      const opt = document.createElement("option");
      opt.value = String(c.id);
      opt.textContent = String(c.name || `Category ${c.id}`);
      journeyCampaignCategorySelect.appendChild(opt);
    }
    if (prev && [...journeyCampaignCategorySelect.options].some((o) => o.value === prev)) {
      journeyCampaignCategorySelect.value = prev;
    }
  }

  function promptJourneyCategoryName() {
    if (!journeyCategoryDialog || !journeyCategoryDialogForm || !journeyCategoryDialogName) {
      return Promise.resolve(String(window.prompt("Category name", "") || "").trim());
    }
    return new Promise((resolve) => {
      const finish = (value) => {
        journeyCategoryDialogForm.removeEventListener("submit", onSubmit);
        journeyCategoryDialog.removeEventListener("cancel", onCancel);
        journeyCategoryDialog.removeEventListener("close", onClose);
        if (journeyCategoryDialogCancel) journeyCategoryDialogCancel.removeEventListener("click", onCancelClick);
        resolve(String(value || "").trim());
      };
      const onSubmit = (event) => {
        event.preventDefault();
        const value = String(journeyCategoryDialogName.value || "").trim();
        if (!value) return;
        journeyCategoryDialog.close("submit");
        finish(value);
      };
      const onCancelClick = () => journeyCategoryDialog.close("cancel");
      const onCancel = (event) => {
        event.preventDefault();
        journeyCategoryDialog.close("cancel");
      };
      const onClose = () => {
        if (journeyCategoryDialog.returnValue === "submit") return;
        finish("");
      };
      journeyCategoryDialogForm.addEventListener("submit", onSubmit);
      journeyCategoryDialog.addEventListener("cancel", onCancel);
      journeyCategoryDialog.addEventListener("close", onClose);
      if (journeyCategoryDialogCancel) journeyCategoryDialogCancel.addEventListener("click", onCancelClick);
      journeyCategoryDialogName.value = "";
      journeyCategoryDialog.showModal();
      window.setTimeout(() => journeyCategoryDialogName.focus(), 0);
    });
  }

  async function createJourneyCategory() {
    const name = await promptJourneyCategoryName();
    if (!name) return null;
    const { response, data } = await fetchApiJson("/api/drip/categories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name })
    });
    if (!response.ok) throw new Error((data && data.error) || "Failed to create category");
    const { response: catRes, data: catData } = await fetchApiJson("/api/drip/categories");
    if (catRes.ok && Array.isArray(catData)) cachedCampaignCategories = catData;
    populateJourneyCategorySelect();
    const newId = String(data.id);
    if (journeyCampaignCategorySelect) journeyCampaignCategorySelect.value = newId;
    expandedPickerCategories.add(newId);
    selectedPickerCategoryId = newId;
    if (campaignListsLoaded) renderCampaignCategoryPicker();
    if (journeySettingsDetails) journeySettingsDetails.open = true;
    showToast(`Created category “${data.name}”. Save the campaign to keep it assigned.`, "success");
    return data;
  }

  function readJourneyCampaignMetaFromForm() {
    const name = journeyCampaignNameInput ? String(journeyCampaignNameInput.value || "").trim() : "";
    const categoryRaw = journeyCampaignCategorySelect
      ? String(journeyCampaignCategorySelect.value || "").trim()
      : "";
    const categoryNum = categoryRaw ? Number(categoryRaw) : NaN;
    return {
      name,
      category_id: Number.isFinite(categoryNum) && categoryNum > 0 ? Math.floor(categoryNum) : null
    };
  }

  function syncJourneyCampaignMetaForm() {
    if (!journeyCampaignNameInput && !journeyCampaignCategorySelect) return;
    if (selectedCampaignId != null && !journeyIsDraftCampaign) {
      const c = cachedCampaigns.find((row) => Number(row.id) === Number(selectedCampaignId));
      if (journeyCampaignNameInput) journeyCampaignNameInput.value = c ? String(c.name || "") : "";
      if (journeyCampaignCategorySelect) {
        journeyCampaignCategorySelect.value =
          c?.category_id != null && Number(c.category_id) > 0 ? String(c.category_id) : "";
      }
      return;
    }
  }

  function journeyCampaignNameValue() {
    return journeyCampaignNameInput ? String(journeyCampaignNameInput.value || "").trim() : "";
  }

  function getEnrollTagForSave() {
    const start = getStartNode(state);
    const fromNode = String(start?.dripEnrollTag ?? "").trim();
    if (fromNode) return fromNode;
    if (selectedCampaignId != null) {
      const c = cachedCampaigns.find((row) => Number(row.id) === Number(selectedCampaignId));
      const existing = c ? getEnrollTagFromCampaign(c) : "";
      if (existing) return existing;
    }
    const name = journeyCampaignNameValue();
    if (name && start) start.dripEnrollTag = name;
    return name;
  }

  function buildCampaignPayloadFromJourney(campaignRow, meta, stepsPayload) {
    const enrollTag = getEnrollTagForSave();
    if (!enrollTag) throw new Error("Set an enrollment tag on the Start node before saving.");
    return {
      name: String(meta.name || "").trim(),
      description: campaignRow ? String(campaignRow.description ?? "").trim() : "",
      schedule_mode: "on_tag",
      start_at: null,
      end_at: null,
      tag_rules: buildTagRulesFromEnrollTag(enrollTag),
      steps: stepsPayload,
      twilio_from: campaignRow?.twilio_from != null ? String(campaignRow.twilio_from) : "secondary",
      email_from: campaignRow?.email_from != null ? String(campaignRow.email_from) : "",
      category_id: meta.category_id
    };
  }

  function startNewCampaignDraft(options = {}) {
    const quiet = Boolean(options.quiet);
    persistCurrentState();
    cleanupLinkDragSurface();
    clearConnectMode(true);
    journeyIsDraftCampaign = true;
    selectedCampaignId = null;
    selectedPickerCategoryId = "__all__";
    applyState(defaultNewCampaignGraph());
    applyFlowLayoutPositions();
    if (journeySettingsDetails) journeySettingsDetails.open = true;
    if (journeyCampaignNameInput) {
      journeyCampaignNameInput.value = "";
      if (!quiet) journeyCampaignNameInput.focus();
    }
    if (journeyCampaignCategorySelect) journeyCampaignCategorySelect.value = "";
    updateCampaignSubtitle();
    renderCampaignCategoryPicker();
    renderNodes();
    updateSaveButtonState();
    if (!quiet) showToast("New campaign. Set the name, then click Save.", "success");
  }

  /**
   * Push the current journey state to the backend campaign. The popup edit flow
   * calls this with `silent: true` so it can show its own contextual toast.
   * Node x/y positions are preserved across the round-trip — the server response
   * gets re-applied to refresh drip fields, then layout is restored by id match.
   */
  function nextCopyCampaignName(baseName, campaigns) {
    const rawBase = String(baseName || "").trim() || "Campaign";
    const stripped = rawBase.replace(/\s+\(Copy(?:\s+\d+)?\)$/i, "").trim() || rawBase;
    const existing = new Set(
      (Array.isArray(campaigns) ? campaigns : [])
        .map((row) => String(row?.name || "").trim().toLowerCase())
        .filter(Boolean)
    );
    const first = `${stripped} (Copy)`;
    if (!existing.has(first.toLowerCase())) return first;
    for (let i = 2; i < 10000; i += 1) {
      const candidate = `${stripped} (Copy ${i})`;
      if (!existing.has(candidate.toLowerCase())) return candidate;
    }
    return `${stripped} (Copy ${Date.now()})`;
  }

  async function saveCampaignJourneyToServer({ silent = false, asNew = false, nameOverride = "", verb = "save" } = {}) {
    const isCreate = asNew || journeyIsDraftCampaign || selectedCampaignId == null;
    const copiedFromSavedCampaign = asNew && !journeyIsDraftCampaign && selectedCampaignId != null;
    const existingId = !isCreate ? Math.floor(Number(selectedCampaignId)) : null;
    let c =
      existingId != null ? cachedCampaigns.find((row) => Number(row.id) === existingId) : null;
    if (!isCreate && !c) {
      if (!silent) showToast("Campaign not found. Click Refresh.", "danger");
      return false;
    }

    let linearNodes;
    let stepsPayload;
    let meta;
    try {
      meta = readJourneyCampaignMetaFromForm();
      const override = String(nameOverride || "").trim();
      if (override) meta = { ...meta, name: override };
      if (!meta.name) throw new Error("Campaign name is required.");
      linearNodes = extractLinearDripNodes(state);
      stepsPayload = buildDripStepsPayload(linearNodes);
    } catch (err) {
      if (!silent) showToast(err.message || "Invalid journey", "danger");
      else throw err;
      return false;
    }

    let payload;
    try {
      payload = buildCampaignPayloadFromJourney(c, meta, stepsPayload);
    } catch (err) {
      if (!silent) showToast(err.message || "Invalid campaign", "danger");
      else throw err;
      return false;
    }

    if (saveCampaignBtn) saveCampaignBtn.disabled = true;
    try {
      const url = isCreate ? "/api/drip/campaigns" : `/api/drip/campaigns/${existingId}`;
      const method = isCreate ? "POST" : "PUT";
      const { response, data } = await fetchApiJson(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!response.ok) {
        const msg = String(data?.error || data?.message || `Save failed (${response.status})`);
        if (silent) throw new Error(msg);
        showToast(msg, "danger");
        return false;
      }
      const updated = data;
      const savedId = Math.floor(Number(updated?.id || existingId || 0));
      if (!Number.isFinite(savedId) || savedId < 1) {
        if (!silent) showToast("Save succeeded but campaign id was missing.", "danger");
        return false;
      }

      journeyIsDraftCampaign = false;
      selectedCampaignId = savedId;
      const idx = cachedCampaigns.findIndex((row) => Number(row.id) === savedId);
      if (idx >= 0) cachedCampaigns[idx] = { ...cachedCampaigns[idx], ...updated };
      else cachedCampaigns.push(updated);

      const prevPositions = new Map();
      state.nodes.forEach((n) => {
        prevPositions.set(n.id, { x: n.x, y: n.y });
      });

      applyState(buildGraphFromCampaign(updated));
      state.nodes.forEach((n) => {
        const p = prevPositions.get(n.id);
        if (p) {
          n.x = p.x;
          n.y = p.y;
        }
      });

      syncJourneyCampaignMetaForm();
      persistCurrentState();
      renderNodes();
      renderCampaignCategoryPicker();
      updateCampaignSubtitle();
      updateSaveButtonState();
      if (!silent) {
        const savedName = String(meta.name || "Campaign");
        const keptOriginal = copiedFromSavedCampaign ? " The original campaign was left unchanged." : "";
        if (verb === "duplicate") {
          showToast(`Duplicated as “${savedName}”.${keptOriginal}`, "success");
        } else if (verb === "save-as") {
          showToast(`Saved as “${savedName}”.${keptOriginal}`, "success");
        } else {
          showToast(
            isCreate ? "Campaign created and saved." : "Campaign updated — visible on Campaigns page.",
            "success"
          );
        }
      }
      return true;
    } finally {
      updateSaveButtonState();
    }
  }

  async function duplicateJourneyCampaign() {
    const named = Boolean(journeyCampaignNameValue());
    const linked = selectedCampaignId != null && Number.isFinite(Number(selectedCampaignId));
    if (!named && !linked && !journeyIsDraftCampaign) {
      showToast("Open a campaign, or start a new one, before duplicating.", "danger");
      return;
    }
    const meta = readJourneyCampaignMetaFromForm();
    const name = nextCopyCampaignName(meta.name || "Campaign", cachedCampaigns);
    await saveCampaignJourneyToServer({ asNew: true, nameOverride: name, verb: "duplicate" });
  }

  async function saveJourneyCampaignAs() {
    const named = Boolean(journeyCampaignNameValue());
    const linked = selectedCampaignId != null && Number.isFinite(Number(selectedCampaignId));
    if (!named && !linked && !journeyIsDraftCampaign) {
      showToast("Open a campaign, or start a new one, before saving a copy.", "danger");
      return;
    }
    const meta = readJourneyCampaignMetaFromForm();
    const suggested = nextCopyCampaignName(meta.name || "Campaign", cachedCampaigns);
    const entered = window.prompt("Save this automation as", suggested);
    if (entered == null) return;
    const name = String(entered).trim();
    if (!name) {
      showToast("Campaign name is required.", "danger");
      return;
    }
    await saveCampaignJourneyToServer({ asNew: true, nameOverride: name, verb: "save-as" });
  }

  function updateSaveButtonState() {
    const named = Boolean(journeyCampaignNameValue());
    const linked = selectedCampaignId != null && Number.isFinite(Number(selectedCampaignId));
    const canSave = named || linked || journeyIsDraftCampaign;
    [saveCampaignBtn, document.getElementById("journeySaveCampaignSideBtn")].forEach((btn) => {
      if (!btn) return;
      btn.disabled = !canSave;
      btn.textContent = "Save Campaign";
    });
    if (duplicateCampaignBtn) duplicateCampaignBtn.disabled = !canSave;
    if (saveAsCampaignBtn) saveAsCampaignBtn.disabled = !canSave;
  }

  function buildGraphFromCampaign(campaign) {
    const cid = Math.floor(Number(campaign?.id) || 0);
    const prefix = `camp-${cid}`;
    const nodes = [];
    const links = [];
    const steps = Array.isArray(campaign?.steps)
      ? [...campaign.steps].sort((a, b) => Number(a.step_order) - Number(b.step_order))
      : [];

    function normChannel(ch) {
      const c = String(ch || "").toLowerCase();
      if (c === "sms") return "sms";
      if (c === "call") return "call";
      return "email";
    }

    function stepLabel(step) {
      const off = formatOffsetLabel(step.offset_hours);
      const ch = normChannel(step.channel);
      if (ch === "email") {
        const sub = String(step.subject || "Email").trim();
        return `${off} · ${sub.slice(0, 72)}${sub.length > 72 ? "…" : ""}`;
      }
      if (ch === "sms") {
        const hasPhoto = Boolean(String(step.sms_media_id || "").trim());
        const snippet = plainTextSnippet(step.body, 48) || (hasPhoto ? "Photo" : "—");
        const photoNote = hasPhoto && snippet !== "Photo" ? " + photo" : "";
        return `${off} · SMS · ${snippet}${photoNote}`;
      }
      const tw = String(step.call_twiml_url || "").trim();
      return `${off} · Call · ${tw ? tw.slice(0, 52) + (tw.length > 52 ? "…" : "") : "voice"}`;
    }

    const enrollTag = getEnrollTagFromCampaign(campaign);
    nodes.push({
      id: `${prefix}-start`,
      label: "Start",
      type: "start",
      x: 40,
      y: 120,
      ...(enrollTag ? { dripEnrollTag: enrollTag } : {})
    });
    let prevId = `${prefix}-start`;
    let x = 240;
    let prevOffset = 0;
    let delaySeq = 0;
    steps.forEach((step) => {
      const off = Number(step.offset_hours);
      const offsetHours = Number.isFinite(off) && off >= 0 ? off : 0;
      const gap = offsetHours - prevOffset;
      if (gap > 1 / 120) {
        delaySeq += 1;
        const delayId = `${prefix}-delay-${delaySeq}`;
        const inferred = inferDelayUnit(gap);
        nodes.push({
          id: delayId,
          label: `Wait ${formatOffsetLabel(gap)}`,
          type: "delay",
          x,
          y: 120,
          dripOffsetHours: gap,
          dripDelayUnit: inferred.unit
        });
        links.push({ id: uid("link"), from: prevId, to: delayId, label: "" });
        prevId = delayId;
        x += 220;
      }
      const id = `${prefix}-step-${step.step_order}`;
      const ty = normChannel(step.channel);
      nodes.push({
        id,
        label: stepLabel(step),
        type: ty,
        x,
        y: 120,
        dripOffsetHours: 0,
        dripSubject: String(step.subject ?? ""),
        dripBody: String(step.body ?? ""),
        dripCallTwimlUrl: String(step.call_twiml_url ?? ""),
        dripTwilioFrom: String(step.twilio_from || step.twilioFrom || "").trim(),
        dripEmailFrom: String(step.email_from || step.emailFrom || "").trim(),
        dripSmsMediaId: String(step.sms_media_id || "").trim().toLowerCase()
      });
      links.push({ id: uid("link"), from: prevId, to: id, label: "" });
      prevId = id;
      prevOffset = offsetHours;
      x += 220;
    });
    const endId = `${prefix}-end`;
    nodes.push({ id: endId, label: "Complete", type: "success", x, y: 120 });
    links.push({ id: uid("link"), from: prevId, to: endId, label: "" });
    return normalizeState({ nodes, links });
  }

  function updateCampaignSubtitle() {
    if (!journeyCampaignSubtitle) return;
    if (journeyIsDraftCampaign) {
      journeyCampaignSubtitle.textContent =
        "New campaign draft. Set the name and enrollment tag, then click Save.";
      return;
    }
    if (selectedCampaignId == null) {
      const name = journeyCampaignNameValue();
      journeyCampaignSubtitle.textContent = name
        ? `${name} is not saved yet. Click Save.`
        : "New campaign. Set the name and enrollment tag, then click Save.";
      return;
    }
    const c = cachedCampaigns.find((row) => Number(row.id) === Number(selectedCampaignId));
    const name = c ? String(c.name || `Campaign #${c.id}`) : `Campaign #${selectedCampaignId}`;
    const cat = c?.category_name ? String(c.category_name) : "Uncategorized";
    journeyCampaignSubtitle.textContent = `Editing: ${name} (${cat}). Click Save to store changes.`;
  }

  function renderCampaignCategoryPicker() {
    if (!journeyCampaignCategoryList) return;
    if (!campaignListsLoaded) {
      journeyCampaignCategoryList.setAttribute("aria-busy", "true");
      journeyCampaignCategoryList.innerHTML =
        '<p class="campaign-category-empty">Loading categories…</p>';
      return;
    }
    journeyCampaignCategoryList.removeAttribute("aria-busy");
    const cats = Array.isArray(cachedCampaignCategories) ? cachedCampaignCategories : [];
    const rows = Array.isArray(cachedCampaigns) ? cachedCampaigns : [];
    const countFor = (idRaw) =>
      rows.filter((c) => {
        if (idRaw === "") return !Number(c.category_id);
        return String(c.category_id || "") === String(idRaw);
      }).length;
    const total = rows.length;
    const uncategorizedCount = countFor("");
    const categoryItems = [
      { label: "Uncategorized", value: "", count: uncategorizedCount },
      ...cats.map((c) => ({
        label: String(c.name || ""),
        value: String(c.id),
        count: countFor(c.id)
      }))
    ];

    const quickFiltersHtml = `<div class="campaign-category-quick-filters">
    <button type="button" class="campaign-category-quick-btn${selectedPickerCategoryId === "__all__" ? " is-active" : ""}" data-journey-cat="__all__">
      <span>All</span><strong>${total}</strong>
    </button>
  </div>`;

    const groupsHtml = categoryItems
      .map((item) => {
        const value = String(item.value);
        const categoryCampaigns =
          value === ""
            ? rows.filter((c) => !Number(c.category_id))
            : rows.filter((c) => String(c.category_id || "") === value);
        const isActive = String(selectedPickerCategoryId) === value;
        const isOpen = expandedPickerCategories.has(value);
        const childrenHtml = categoryCampaigns.length
          ? categoryCampaigns
              .map((c) => {
                const legacySchedule = c.schedule_mode === "scheduled";
                const schedBadge = legacySchedule ? "Legacy" : "Tag";
                const isCampaignActive = Number(selectedCampaignId) === Number(c.id);
                return `<button type="button" class="campaign-category-child${isCampaignActive ? " is-active" : ""}" data-journey-campaign-id="${c.id}" data-journey-cat-value="${escapeHtml(value)}">
                <span class="campaign-category-child-name">${escapeHtml(String(c.name || `Campaign #${c.id}`))}</span>
                <span class="campaign-category-child-badge">${escapeHtml(schedBadge)}</span>
              </button>`;
              })
              .join("")
          : '<div class="campaign-category-empty">No campaigns</div>';
        return `<details class="campaign-category-group${isActive ? " is-active" : ""}" data-journey-cat-value="${escapeHtml(
          value
        )}" ${isOpen ? "open" : ""}>
        <summary class="campaign-category-item${isActive ? " is-active" : ""}">
          <span>${escapeHtml(item.label)}</span>
          <strong>${item.count}</strong>
        </summary>
        <div class="campaign-category-children">${childrenHtml}</div>
      </details>`;
      })
      .join("");

    journeyCampaignCategoryList.innerHTML = `${quickFiltersHtml}${groupsHtml}`;

    journeyCampaignCategoryList.querySelectorAll("[data-journey-cat]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const value = String(btn.getAttribute("data-journey-cat") || "__all__");
        if (value !== "__all__") return;
        const allCategoryValues = categoryItems.map((item) => String(item.value));
        const isAllAlreadySelected = selectedPickerCategoryId === "__all__";
        const areAllExpanded =
          allCategoryValues.length > 0 && allCategoryValues.every((v) => expandedPickerCategories.has(v));
        if (isAllAlreadySelected && areAllExpanded) {
          expandedPickerCategories.clear();
        } else {
          expandedPickerCategories.clear();
          allCategoryValues.forEach((v) => expandedPickerCategories.add(v));
        }
        selectedPickerCategoryId = "__all__";
        renderCampaignCategoryPicker();
      });
    });

    journeyCampaignCategoryList.querySelectorAll(".campaign-category-group").forEach((group) => {
      const value = String(group.getAttribute("data-journey-cat-value") || "");
      const summary = group.querySelector("summary.campaign-category-item");
      if (summary) {
        summary.addEventListener("click", (event) => {
          event.preventDefault();
          const isOpen = expandedPickerCategories.has(value);
          if (isOpen) expandedPickerCategories.delete(value);
          else expandedPickerCategories.add(value);
          selectedPickerCategoryId = value;
          renderCampaignCategoryPicker();
        });
      }
    });

    journeyCampaignCategoryList.querySelectorAll("[data-journey-campaign-id]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const id = Number(btn.getAttribute("data-journey-campaign-id"));
        if (!Number.isFinite(id) || id < 1) return;
        selectCampaignById(id);
      });
    });
  }

  function selectCampaignById(campaignId) {
    const id = Number(campaignId);
    if (!Number.isFinite(id) || id < 1) return;
    persistCurrentState();
    cleanupLinkDragSurface();
    clearConnectMode(true);
    selectedPickerCategoryId = "__all__";
    const camp = cachedCampaigns.find((c) => Number(c.id) === id);
    if (!camp) {
      showToast("Campaign not found. Refresh the list.", "danger");
      updateSaveButtonState();
      return;
    }
    selectedCampaignId = id;
    journeyIsDraftCampaign = false;
    if (journeySettingsDetails) journeySettingsDetails.open = false;
    const stored = loadCampaignGraphFromStorage(id);
    applyState(stored || buildGraphFromCampaign(camp));
    applyFlowLayoutPositions();
    persistCurrentState();
    syncJourneyCampaignMetaForm();
    updateCampaignSubtitle();
    renderCampaignCategoryPicker();
    renderNodes();
    updateSaveButtonState();
    showToast(`Loaded: ${String(camp.name || `Campaign #${id}`)}`, "success");
  }

  async function refreshCampaignData() {
    const { response: catRes, data: catData } = await fetchApiJson("/api/drip/categories");
    const { response: campRes, data: campData } = await fetchApiJson("/api/drip/campaigns");
    if (!catRes.ok || !campRes.ok) {
      const msg =
        (campData && campData.error) || (catData && catData.error) || `Could not load campaigns (${campRes.status}).`;
      if (journeyCampaignCategoryList && !campaignListsLoaded) {
        journeyCampaignCategoryList.removeAttribute("aria-busy");
        journeyCampaignCategoryList.innerHTML =
          '<p class="campaign-category-empty">Could not load categories. Click Refresh.</p>';
      }
      showToast(msg, "danger");
      updateSaveButtonState();
      return false;
    }
    cachedCampaignCategories = Array.isArray(catData) ? catData : [];
    cachedCampaigns = Array.isArray(campData) ? campData : [];
    campaignListsLoaded = true;
    populateJourneyCategorySelect();
    syncJourneyCampaignMetaForm();
    await Promise.all([
      loadJourneySavedTags().catch(() => {}),
      loadJourneyEmailTemplates().catch(() => {})
    ]);
    renderCampaignCategoryPicker();
    updateCampaignSubtitle();
    updateSaveButtonState();
    return true;
  }

  function scheduleDrawConnections() {
    if (journeyDrawRaf) return;
    journeyDrawRaf = window.requestAnimationFrame(() => {
      journeyDrawRaf = 0;
      drawConnections();
    });
  }

  /**
   * The board is inside a scrollable panel, but the graph itself can be wider
   * than the visible viewport (long campaign journeys such as Quote Journey).
   * Grow the board to the node bounds so right-side nodes and connections are
   * reachable instead of clipped by the visible panel width.
   */
  function resizeBoardToGraphBounds() {
    const padding = 80;
    let maxRight = 0;
    let maxBottom = 0;
    nodeEls.forEach((el) => {
      const left = Number.parseFloat(el.style.left || "0") || 0;
      const top = Number.parseFloat(el.style.top || "0") || 0;
      maxRight = Math.max(maxRight, left + el.offsetWidth);
      maxBottom = Math.max(maxBottom, top + el.offsetHeight);
    });

    const parentWidth = board.parentElement ? board.parentElement.clientWidth : 0;
    const wrapH = board.parentElement ? board.parentElement.clientHeight : 0;
    const boardTop = Math.max(0, Math.round(board.getBoundingClientRect().top));
    const viewportFill = Math.max(0, document.documentElement.clientHeight - boardTop - 8);
    const nextWidth = Math.max(parentWidth, maxRight + padding, 760);
    const nextHeight = Math.max(560, maxBottom + padding, wrapH, viewportFill);
    board.style.minWidth = `${Math.ceil(nextWidth)}px`;
    board.style.minHeight = `${Math.ceil(nextHeight)}px`;
  }

  function drawConnections() {
    if (journeyDrawRaf) {
      window.cancelAnimationFrame(journeyDrawRaf);
      journeyDrawRaf = 0;
    }

    svg.setAttribute("width", String(board.clientWidth));
    svg.setAttribute("height", String(board.clientHeight));

    let defs = svg.querySelector("defs");
    let linksLayer = svg.querySelector("g.journey-links-layer");
    if (!defs || !linksLayer) {
      svg.replaceChildren();
      defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
      const marker = document.createElementNS("http://www.w3.org/2000/svg", "marker");
      marker.setAttribute("id", "journeyArrowHead");
      marker.setAttribute("markerWidth", "10");
      marker.setAttribute("markerHeight", "7");
      marker.setAttribute("refX", "9");
      marker.setAttribute("refY", "3.5");
      marker.setAttribute("orient", "auto");
      const markerPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
      markerPath.setAttribute("d", "M0,0 L10,3.5 L0,7 z");
      markerPath.setAttribute("fill", "#4f46e5");
      marker.appendChild(markerPath);
      defs.appendChild(marker);
      svg.appendChild(defs);
      linksLayer = document.createElementNS("http://www.w3.org/2000/svg", "g");
      linksLayer.setAttribute("class", "journey-links-layer");
      svg.appendChild(linksLayer);
    }

    linksLayer.replaceChildren();

    state.links.forEach((link) => {
      const fromEl = nodeEls.get(link.from);
      const toEl = nodeEls.get(link.to);
      if (!fromEl || !toEl) return;
      const from = linkEndpointOut(fromEl);
      const to = linkEndpointIn(toEl);
      const linkId = String(link.id || "");

      const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
      path.setAttribute("d", buildPath(from, to));
      path.setAttribute("class", "journey-link-path");
      path.setAttribute("marker-end", "url(#journeyArrowHead)");
      path.setAttribute("data-link-id", linkId);
      const pathTitle = document.createElementNS("http://www.w3.org/2000/svg", "title");
      pathTitle.textContent = "Double-click line to delete";
      path.appendChild(pathTitle);
      linksLayer.appendChild(path);

      const midX = Math.round((from.x + to.x) / 2);
      const midY = Math.round((from.y + to.y) / 2);
      const label = String(link.label || "").trim();
      if (label) {
        const text = document.createElementNS("http://www.w3.org/2000/svg", "text");
        text.setAttribute("x", String(midX));
        text.setAttribute("y", String(midY - 8));
        text.setAttribute("text-anchor", "middle");
        text.setAttribute("class", "journey-link-label");
        text.textContent = label;
        linksLayer.appendChild(text);
      }

      const deleteGroup = document.createElementNS("http://www.w3.org/2000/svg", "g");
      deleteGroup.setAttribute("class", "journey-link-delete");
      deleteGroup.setAttribute("data-link-id", linkId);
      deleteGroup.setAttribute("transform", `translate(${midX - 24}, ${midY})`);
      const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
      circle.setAttribute("r", "9");
      const xText = document.createElementNS("http://www.w3.org/2000/svg", "text");
      xText.setAttribute("text-anchor", "middle");
      xText.setAttribute("dominant-baseline", "central");
      xText.textContent = "×";
      const deleteTitle = document.createElementNS("http://www.w3.org/2000/svg", "title");
      deleteTitle.textContent = "Delete connection";
      deleteGroup.append(deleteTitle, circle, xText);
      linksLayer.appendChild(deleteGroup);
    });
  }

  function removeLinkById(linkId) {
    const lid = String(linkId || "");
    if (!lid) return false;
    const before = state.links.length;
    state.links = state.links.filter((row) => String(row.id || "") !== lid);
    if (state.links.length === before) return false;
    persistCurrentState();
    drawConnections();
    showToast("Connection removed", "danger");
    return true;
  }

  svg.addEventListener("click", (event) => {
    const target = event.target;
    const deleteControl = typeof target.closest === "function" ? target.closest(".journey-link-delete") : null;
    if (!deleteControl || !svg.contains(deleteControl)) return;
    event.preventDefault();
    event.stopPropagation();
    removeLinkById(deleteControl.getAttribute("data-link-id"));
  });

  svg.addEventListener("dblclick", (event) => {
    const target = event.target;
    const path = typeof target.closest === "function" ? target.closest(".journey-link-path") : null;
    if (!path || !svg.contains(path)) return;
    event.preventDefault();
    event.stopPropagation();
    const lid = String(path.getAttribute("data-link-id") || "");
    removeLinkById(lid);
  });

  function applyNodeType(el, type) {
    const safeType = TYPE_CONFIG[type] ? type : "email";
    TYPE_OPTIONS.forEach((t) => el.classList.remove(TYPE_CONFIG[t].className));
    el.classList.add(TYPE_CONFIG[safeType].className);
    const icon = el.querySelector(".journey-node-icon");
    if (icon) icon.textContent = TYPE_CONFIG[safeType].icon;
    const typeLabel = el.querySelector(".journey-node-type-label");
    if (typeLabel) typeLabel.textContent = TYPE_CONFIG[safeType].label || safeType;
  }

  function nodeCardSubtitle(node) {
    if (!node) return "";
    if (node.type === "start") {
      const tag = String(node.dripEnrollTag || "").trim();
      if (tag) return `Starts when tag “${tag}” is applied`;
      return "When a contact enters this campaign";
    }
    if (node.type === "success") return "Journey finished";
    if (node.type === "condition") {
      const days = Math.max(1, Math.floor(Number(node.conditionWindowDays || 3)));
      return `Branch check within ${days} day${days === 1 ? "" : "s"}`;
    }
    if (node.type === "delay") {
      const wait = formatOffsetLabel(Number(node.dripOffsetHours) || 24);
      return `Wait ${wait} after the previous step`;
    }
    if (state.nodes.some((n) => n.type === "delay")) {
      return "Sends after the previous wait";
    }
    const offHours = Number(node.dripOffsetHours);
    if (Number.isFinite(offHours)) {
      if (offHours <= 0) return "Sends immediately after enrollment";
      return `Runs ${formatOffsetLabel(offHours)} after enrollment`;
    }
    const parsed = parseOffsetHoursFromLabel(node.label);
    if (Number.isFinite(parsed)) return `Runs ${formatOffsetLabel(parsed)} after enrollment`;
    return "Click to set timing and content";
  }

  function nodeTooltipText(node, stepNumber) {
    if (!node) return "";
    const type = String(node.type || "").toLowerCase();
    const typeLabel = TYPE_CONFIG[type]?.label || type || "Step";
    const lines = [`Step ${stepNumber}: ${typeLabel}`];
    if (type === "email") {
      const subject = String(node.dripSubject || "").trim();
      const body = plainTextSnippet(String(node.dripBody || ""), 220);
      if (subject) lines.push(`Subject: ${subject}`);
      if (body) lines.push(`Preview: ${body}`);
    } else if (type === "sms") {
      const body = plainTextSnippet(String(node.dripBody || ""), 220);
      if (body) lines.push(`Preview: ${body}`);
    } else if (type === "call") {
      const url = String(node.dripCallTwimlUrl || "").trim();
      lines.push(url ? `TwiML: ${url}` : "Voice call step");
    } else if (type === "condition") {
      lines.push(nodeCardSubtitle(node));
      lines.push("Branches: Yes / No");
    } else if (type === "delay") {
      lines.push(nodeCardSubtitle(node));
    } else {
      lines.push(String(node.label || typeLabel));
    }
    return lines.join("\n");
  }

  function nodeDisplayTitle(node) {
    const type = String(node?.type || "").toLowerCase();
    if (type === "start") return "Start";
    if (type === "success") return "Complete";
    if (type === "condition") return "Condition";
    if (type === "delay") return "Delay";
    return TYPE_CONFIG[type]?.label || "Step";
  }

  const addStepMenu = document.createElement("div");
  addStepMenu.className = "journey-add-step-menu hidden";
  addStepMenu.innerHTML = `
    <button type="button" data-channel="email">Add Email</button>
    <button type="button" data-channel="sms">Add SMS</button>
    <button type="button" data-channel="call">Add Call</button>
    <button type="button" data-channel="delay">Add Delay</button>
    <button type="button" data-channel="condition">Add Condition</button>
  `;
  document.body.appendChild(addStepMenu);
  let addStepAfterNodeId = "";

  function hideAddStepMenu() {
    addStepMenu.classList.add("hidden");
    addStepAfterNodeId = "";
  }

  function placeOnScreen(menu, left, top) {
    const margin = 8;
    menu.classList.remove("hidden");
    menu.style.maxHeight = `${Math.max(120, window.innerHeight - margin * 2)}px`;
    menu.style.overflowY = "auto";
    menu.style.left = `${Math.round(left)}px`;
    menu.style.top = `${Math.round(top)}px`;
    const rect = menu.getBoundingClientRect();
    const maxRight = window.innerWidth - margin;
    const maxBottom = window.innerHeight - margin;
    let nextLeft = left;
    let nextTop = top;
    if (rect.right > maxRight) nextLeft -= rect.right - maxRight;
    if (rect.bottom > maxBottom) nextTop -= rect.bottom - maxBottom;
    if (nextLeft < margin) nextLeft = margin;
    if (nextTop < margin) nextTop = margin;
    menu.style.left = `${Math.round(nextLeft)}px`;
    menu.style.top = `${Math.round(nextTop)}px`;
  }

  function showAddStepMenu(anchorEl, afterNodeId) {
    addStepAfterNodeId = afterNodeId;
    const rect = anchorEl.getBoundingClientRect();
    placeOnScreen(addStepMenu, rect.left + rect.width / 2 - 80, rect.bottom + 8);
  }

  addStepMenu.addEventListener("click", (event) => {
    const btn = event.target.closest("button[data-channel]");
    if (!btn || !addStepAfterNodeId) return;
    const channel = String(btn.getAttribute("data-channel") || "email");
    const afterId = addStepAfterNodeId;
    hideAddStepMenu();
    insertStepAfter(afterId, channel);
  });

  function clearFlowChrome() {
    board.querySelectorAll(".journey-flow-drop-slot, .journey-flow-connector, .journey-flow-add-wrap").forEach((el) => {
      el.remove();
    });
  }

  function placeFlowChrome(orderedIds) {
    clearFlowChrome();
    if (!isFlowLayout()) return;

    orderedIds.forEach((nodeId, index) => {
      const node = getNode(nodeId);
      const el = nodeEls.get(nodeId);
      if (!node || !el) return;
      const nodeLeft = Number.parseFloat(el.style.left || String(node.x || 0)) || 0;
      const nodeTop = Number.parseFloat(el.style.top || String(node.y || 0)) || 0;
      const nodeWidth = el.offsetWidth || FLOW_CARD_WIDTH;
      const nodeHeight = el.offsetHeight || flowNodeHeight(node);
      const nodeCenterX = nodeLeft + nodeWidth / 2;

      const slot = document.createElement("div");
      slot.className = "journey-flow-drop-slot";
      slot.dataset.insertBefore = nodeId;
      slot.style.top = `${Math.max(0, nodeTop - FLOW_SLOT_HEIGHT - 8)}px`;
      wireFlowDropSlot(slot);
      board.appendChild(slot);

      const isLast = index === orderedIds.length - 1;
      if (!isLast && !isCompleteNode(node)) {
        const nodeBottom = nodeTop + nodeHeight;
        const conn = document.createElement("div");
        conn.className = "journey-flow-connector";
        conn.style.left = `${nodeCenterX}px`;
        conn.style.top = `${nodeBottom + 6}px`;
        board.appendChild(conn);

        const addWrap = document.createElement("div");
        addWrap.className = "journey-flow-add-wrap";
        addWrap.style.left = `${nodeCenterX + 36}px`;
        addWrap.style.top = `${nodeBottom + 18}px`;
        const addBtn = document.createElement("button");
        addBtn.type = "button";
        addBtn.className = "journey-flow-add-btn";
        addBtn.setAttribute("aria-label", "Add step after this one");
        addBtn.textContent = "+";
        addBtn.addEventListener("click", (event) => {
          event.stopPropagation();
          showAddStepMenu(addBtn, nodeId);
        });
        addWrap.appendChild(addBtn);
        board.appendChild(addWrap);
      }
    });
  }

  function insertStepBeforeComplete(channel) {
    const ordered = getFlowOrderedNodeIds();
    let afterId = findStartNodeId();
    const completeIdx = ordered.findIndex((id) => {
      const n = getNode(id);
      return n && (n.type === "success" || /-end$/i.test(String(n.id)));
    });
    if (completeIdx > 0) afterId = ordered[completeIdx - 1];
    else if (ordered.length > 1) afterId = ordered[ordered.length - 2];
    insertStepAfter(afterId, channel);
  }

  function wireFlowDropSlot(slot) {
    slot.addEventListener("dragover", (event) => {
      event.preventDefault();
      event.stopPropagation();
      event.dataTransfer.dropEffect = "move";
      slot.classList.add("is-drag-over");
    });
    slot.addEventListener("dragleave", () => slot.classList.remove("is-drag-over"));
    slot.addEventListener("drop", (event) => {
      event.preventDefault();
      event.stopPropagation();
      slot.classList.remove("is-drag-over");
      const channel = event.dataTransfer.getData("application/x-journey-step-type");
      const insertBefore = String(slot.dataset.insertBefore || "");
      if (channel) {
        const ordered = getFlowOrderedNodeIds();
        const idx = ordered.indexOf(insertBefore);
        const afterId = idx > 0 ? ordered[idx - 1] : findStartNodeId();
        if (afterId) insertStepAfter(afterId, channel);
        return;
      }
      const draggedId = event.dataTransfer.getData("text/plain");
      if (draggedId) reorderNodeInFlow(draggedId, insertBefore);
    });
  }

  function getFlowInsertBeforeIdFromClientY(clientY) {
    if (!isFlowLayout()) return "";
    const ordered = getFlowOrderedNodeIds();
    const candidates = ordered.filter((id) => {
      const node = getNode(id);
      return node && node.type !== "start";
    });
    if (!candidates.length) return "";
    const localY = clientY - boardRect().top;
    for (const id of candidates) {
      const node = getNode(id);
      const el = nodeEls.get(id);
      if (!node) continue;
      const height = el ? el.offsetHeight : flowNodeHeight(node);
      if (localY < node.y + height / 2) return id;
    }
    const completeId = candidates.find((id) => {
      const node = getNode(id);
      return node && (node.type === "success" || /-end$/i.test(String(node.id)));
    });
    return completeId || candidates[candidates.length - 1];
  }

  function highlightFlowInsertTarget(insertBeforeId) {
    activeFlowInsertBeforeId = insertBeforeId || "";
    board.querySelectorAll(".journey-flow-drop-slot").forEach((slot) => {
      slot.classList.toggle("is-drag-over", String(slot.dataset.insertBefore || "") === activeFlowInsertBeforeId);
    });
  }

  function clearFlowInsertHighlight() {
    activeFlowInsertBeforeId = "";
    board.querySelectorAll(".journey-flow-drop-slot.is-drag-over").forEach((slot) => {
      slot.classList.remove("is-drag-over");
    });
  }

  function insertDraggedStepAt(channel, insertBefore) {
    const ordered = getFlowOrderedNodeIds();
    const idx = ordered.indexOf(insertBefore);
    const afterId = idx > 0 ? ordered[idx - 1] : findStartNodeId();
    if (afterId) insertStepAfter(afterId, channel);
  }

  function dragHasType(event, type) {
    const types = event?.dataTransfer?.types;
    if (!types) return false;
    if (typeof types.includes === "function") return types.includes(type);
    if (typeof types.contains === "function") return types.contains(type);
    return Array.from(types).includes(type);
  }

  function wireFlowBoardDrop() {
    board.addEventListener("dragover", (event) => {
      if (!isFlowLayout()) return;
      const channel = dragHasType(event, "application/x-journey-step-type");
      const nodeDrag = dragHasType(event, "text/plain");
      if (!channel && !nodeDrag) return;
      event.preventDefault();
      event.dataTransfer.dropEffect = channel ? "copy" : "move";
      highlightFlowInsertTarget(getFlowInsertBeforeIdFromClientY(event.clientY));
    });

    board.addEventListener("dragleave", (event) => {
      if (event.relatedTarget && board.contains(event.relatedTarget)) return;
      clearFlowInsertHighlight();
    });

    board.addEventListener("drop", (event) => {
      if (!isFlowLayout()) return;
      const channel = event.dataTransfer.getData("application/x-journey-step-type");
      const draggedId = event.dataTransfer.getData("text/plain");
      if (!channel && !draggedId) return;
      event.preventDefault();
      const insertBefore = activeFlowInsertBeforeId || getFlowInsertBeforeIdFromClientY(event.clientY);
      clearFlowInsertHighlight();
      if (channel) {
        insertDraggedStepAt(channel, insertBefore);
      } else {
        reorderNodeInFlow(draggedId, insertBefore);
      }
    });
  }

  function wireFlowReorder(el, nodeId) {
    const node = getNode(nodeId);
    if (!node || node.type === "start" || node.type === "success") {
      el.removeAttribute("draggable");
      return;
    }
    el.setAttribute("draggable", "true");
    el.addEventListener("dragstart", (event) => {
      event.dataTransfer.setData("text/plain", nodeId);
      event.dataTransfer.effectAllowed = "move";
      el.classList.add("is-dragging");
    });
    el.addEventListener("dragend", () => {
      el.classList.remove("is-dragging");
      clearFlowInsertHighlight();
    });
  }

  function wireMenuButtonLinkDrag(menuBtn, nodeId) {
    let pending = false;
    let started = false;
    let startX = 0;
    let startY = 0;

    menuBtn.title = "Click for options, drag to connect";

    menuBtn.addEventListener("pointerdown", (event) => {
      if (event.button != null && event.button !== 0) return;
      pending = true;
      started = false;
      startX = event.clientX;
      startY = event.clientY;
      event.stopPropagation();
      try {
        menuBtn.setPointerCapture(event.pointerId);
      } catch {
        // no-op
      }
    });

    menuBtn.addEventListener("pointermove", (event) => {
      if (!pending || started) return;
      if (Math.abs(event.clientX - startX) <= 4 && Math.abs(event.clientY - startY) <= 4) return;
      started = true;
      pending = false;
      suppressNodeClickUntil = performance.now() + 450;
      hideContextMenu();
      hideAddStepMenu();
      startLinkDragFromNode(nodeId, event.clientX, event.clientY);
      event.preventDefault();
      event.stopPropagation();
    });

    function finishPointer(event) {
      pending = false;
      try {
        menuBtn.releasePointerCapture(event.pointerId);
      } catch {
        // no-op
      }
    }

    menuBtn.addEventListener("pointerup", finishPointer);
    menuBtn.addEventListener("pointercancel", finishPointer);

    menuBtn.addEventListener("click", (event) => {
      if (started) {
        started = false;
        event.preventDefault();
        event.stopPropagation();
      }
    });
  }

  function bindNodeCard(el, node, stepNumber) {
    if (isFlowLayout()) {
      const titleEl = el.querySelector(".journey-node-title");
      const subtitleEl = el.querySelector(".journey-node-subtitle");
      const badgeEl = el.querySelector(".journey-node-step-badge");
      const countEl = el.querySelector(".journey-node-count-badge");
      el.setAttribute("title", nodeTooltipText(node, stepNumber));
      if (titleEl) titleEl.textContent = nodeDisplayTitle(node);
      if (subtitleEl) subtitleEl.textContent = nodeCardSubtitle(node);
      if (badgeEl) badgeEl.textContent = String(stepNumber);
      if (countEl) countEl.textContent = "0";
      const menuBtn = el.querySelector(".journey-node-menu-btn");
      if (menuBtn) {
        wireMenuButtonLinkDrag(menuBtn, node.id);
        menuBtn.addEventListener("click", (event) => {
          if (performance.now() < suppressNodeClickUntil) {
            event.preventDefault();
            event.stopPropagation();
            return;
          }
          event.stopPropagation();
          contextTargetNodeId = node.id;
          showContextMenu(event.clientX, event.clientY, node.id);
        });
      }
      wireDrag(el);
    } else {
      const textEl = el.querySelector(".journey-node-text");
      const typeEl = el.querySelector(".journey-node-type");
      if (textEl) {
        textEl.textContent = String(node.label || "Step");
        textEl.addEventListener("input", () => {
          const row = getNode(node.id);
          if (!row) return;
          row.label = String(textEl.textContent || "").trim() || "Step";
          persistCurrentState();
        });
      }
      if (typeEl) {
        typeEl.value = TYPE_OPTIONS.includes(node.type) ? node.type : "email";
        typeEl.addEventListener("change", () => {
          const row = getNode(node.id);
          if (!row) return;
          row.type = String(typeEl.value || "email");
          if (row.type === "delay") {
            if (!Number.isFinite(Number(row.dripOffsetHours)) || Number(row.dripOffsetHours) <= 0) {
              row.dripOffsetHours = 24;
            }
            if (row.dripDelayUnit !== "minutes" && row.dripDelayUnit !== "hours" && row.dripDelayUnit !== "days") {
              row.dripDelayUnit = "days";
            }
            row.label = computeBoardLabelForNode(row);
            if (textEl) textEl.textContent = row.label;
          }
          applyNodeType(el, row.type);
          const vb = el.querySelector(".journey-node-view-content");
          if (vb) vb.hidden = ["start", "success"].includes(row.type);
          persistCurrentState();
        });
      }
      const viewBtn = el.querySelector(".journey-node-view-content");
      if (viewBtn) {
        viewBtn.addEventListener("click", (event) => {
          event.stopPropagation();
          if (performance.now() < suppressNodeClickUntil) return;
          showNodeStepDetails(getNode(node.id));
        });
        viewBtn.hidden = ["start", "success"].includes(String(node.type));
      }
      const connectorOut = el.querySelector(".journey-node-connector-out");
      if (connectorOut) {
        connectorOut.addEventListener("pointerdown", (event) => {
          event.stopPropagation();
          event.preventDefault();
          startLinkDragFromNode(node.id, event.clientX, event.clientY);
        });
      }
      wireDrag(el);
    }

    applyNodeType(el, node.type);

    el.addEventListener("click", () => {
      if (performance.now() < suppressNodeClickUntil) return;
      const targetId = String(el.getAttribute("data-node-id") || "");
      if (!targetId) return;
      if (connectFromNodeId) {
        if (targetId === connectFromNodeId) return;
        nodeEls.forEach((card) => card.classList.remove("is-connect-target"));
        addLink(connectFromNodeId, targetId, "");
        persistCurrentState();
        clearConnectMode(true);
        drawConnections();
        return;
      }
      const clicked = getNode(targetId);
      if (!clicked) return;
      showNodeStepDetails(clicked);
    });
  }

  function renderNodes() {
    cleanupLinkDragSurface();
    clearFlowChrome();
    [...board.querySelectorAll(".journey-node-card")].forEach((el) => el.remove());
    nodeEls.clear();

    const ordered = isFlowLayout() ? getFlowOrderedNodeIds() : state.nodes.map((n) => n.id);
    const nodesToRender = isFlowLayout()
      ? ordered.map((id) => getNode(id)).filter(Boolean)
      : state.nodes;

    nodesToRender.forEach((node, displayIndex) => {
      const el = document.createElement("div");
      el.className = "journey-node-card";
      el.setAttribute("data-node-id", node.id);
      el.style.left = `${snap(node.x)}px`;
      el.style.top = `${snap(node.y)}px`;

      if (isFlowLayout()) {
        el.innerHTML = `
          <div class="journey-node-icon"></div>
          <span class="journey-node-step-badge" aria-hidden="true"></span>
          <div class="journey-node-main">
            <div class="journey-node-type-label"></div>
            <div class="journey-node-title"></div>
            <div class="journey-node-subtitle"></div>
          </div>
          <span class="journey-node-count-badge" title="Contacts currently at this step">0</span>
          <button type="button" class="journey-node-menu-btn" aria-label="Step options">&#8942;</button>
        `;
        board.appendChild(el);
        bindNodeCard(el, node, displayIndex + 1);
      } else {
        el.innerHTML = `
          <div class="journey-node-icon"></div>
          <div class="journey-node-body">
            <div class="journey-node-text" contenteditable="true" spellcheck="false"></div>
            <select class="journey-node-type" aria-label="Node type">
              <option value="start">Start</option>
              <option value="email">Email</option>
              <option value="sms">SMS</option>
              <option value="call">Call</option>
              <option value="delay">Delay</option>
              <option value="condition">Condition</option>
              <option value="success">Success</option>
            </select>
            <button type="button" class="journey-node-view-content" aria-label="View saved subject and message">View message</button>
          </div>
          <button type="button" class="journey-node-connector-out" aria-label="Drag to another step to connect" title="Drag to another step to connect"></button>
        `;

        const textEl = el.querySelector(".journey-node-text");
        const typeEl = el.querySelector(".journey-node-type");
        if (textEl) {
          textEl.textContent = String(node.label || "Step");
          textEl.addEventListener("input", () => {
            const row = getNode(node.id);
            if (!row) return;
            row.label = String(textEl.textContent || "").trim() || "Step";
            persistCurrentState();
          });
        }
        if (typeEl) {
          typeEl.value = TYPE_OPTIONS.includes(node.type) ? node.type : "email";
          typeEl.addEventListener("change", () => {
            const row = getNode(node.id);
            if (!row) return;
            row.type = String(typeEl.value || "email");
            if (row.type === "delay") {
              if (!Number.isFinite(Number(row.dripOffsetHours)) || Number(row.dripOffsetHours) <= 0) {
                row.dripOffsetHours = 24;
              }
              if (row.dripDelayUnit !== "minutes" && row.dripDelayUnit !== "hours" && row.dripDelayUnit !== "days") {
                row.dripDelayUnit = "days";
              }
              row.label = computeBoardLabelForNode(row);
              if (textEl) textEl.textContent = row.label;
            }
            applyNodeType(el, row.type);
            const vb = el.querySelector(".journey-node-view-content");
            if (vb) vb.hidden = ["start", "success"].includes(row.type);
            persistCurrentState();
          });
        }

        const viewBtn = el.querySelector(".journey-node-view-content");
        if (viewBtn) {
          viewBtn.addEventListener("click", (event) => {
            event.stopPropagation();
            if (performance.now() < suppressNodeClickUntil) return;
            showNodeStepDetails(getNode(node.id));
          });
        }

        applyNodeType(el, node.type);
        if (viewBtn && typeEl) {
          viewBtn.hidden = ["start", "success"].includes(String(typeEl.value));
        }
        board.appendChild(el);
        bindNodeCard(el, node, displayIndex + 1);
      }

      nodeEls.set(node.id, el);
    });

    if (isFlowLayout()) {
      placeFlowChrome(ordered);
    }

    resizeBoardToGraphBounds();
    drawConnections();
  }

  function wireDrag(el) {
    let dragging = false;
    let didMove = false;
    let dx = 0;
    let dy = 0;
    let startX = 0;
    let startY = 0;

    el.addEventListener("pointerdown", (event) => {
      if (event.button != null && event.button !== 0) return;
      if (
        event.target.closest(".journey-node-text") ||
        event.target.closest(".journey-node-type") ||
        event.target.closest(".journey-node-view-content") ||
        event.target.closest(".journey-node-connector-out") ||
        event.target.closest(".journey-node-menu-btn") ||
        event.target.closest(".journey-node-count-badge")
      )
        return;
      hideContextMenu();
      hideAddStepMenu();
      dragging = true;
      didMove = false;
      startX = event.clientX;
      startY = event.clientY;
      el.setPointerCapture(event.pointerId);
      const br = boardRect();
      const currentX = Number.parseFloat(el.style.left || "0");
      const currentY = Number.parseFloat(el.style.top || "0");
      dx = event.clientX - br.left - currentX;
      dy = event.clientY - br.top - currentY;
      el.classList.add("is-dragging");
      event.preventDefault();
    });

    el.addEventListener("pointermove", (event) => {
      if (!dragging) return;
      if (Math.abs(event.clientX - startX) > 3 || Math.abs(event.clientY - startY) > 3) {
        didMove = true;
      }
      const br = boardRect();
      const next = clampPosRaw(event.clientX - br.left - dx, event.clientY - br.top - dy, el);
      el.style.left = `${next.x}px`;
      el.style.top = `${next.y}px`;
      if (isFlowLayout()) placeFlowChrome(getFlowOrderedNodeIds());
      scheduleDrawConnections();
    });

    function endDrag(event) {
      if (!dragging) return;
      dragging = false;
      try {
        el.releasePointerCapture(event.pointerId);
      } catch {
        // no-op
      }
      el.classList.remove("is-dragging");
      if (didMove) {
        suppressNodeClickUntil = performance.now() + 450;
      }
      const id = String(el.getAttribute("data-node-id") || "");
      const row = getNode(id);
      if (row) {
        row.x = snap(Number.parseFloat(el.style.left || "0"));
        row.y = snap(Number.parseFloat(el.style.top || "0"));
        el.style.left = `${row.x}px`;
        el.style.top = `${row.y}px`;
      }
      persistCurrentState();
      resizeBoardToGraphBounds();
      if (isFlowLayout()) placeFlowChrome(getFlowOrderedNodeIds());
      drawConnections();
    }

    el.addEventListener("pointerup", endDrag);
    el.addEventListener("pointercancel", endDrag);
  }

  function hideContextMenu() {
    contextMenu.classList.add("hidden");
  }

  function showContextMenu(x, y, nodeId) {
    contextTargetNodeId = nodeId || "";
    contextPos = { x, y };
    const hasNode = Boolean(nodeId);
    contextMenu.querySelector('[data-action="add-child"]').disabled = !hasNode;
    contextMenu.querySelector('[data-action="branch"]').disabled = !hasNode;
    contextMenu.querySelector('[data-action="connect-start"]').disabled = !hasNode;
    contextMenu.querySelector('[data-action="delete-node"]').disabled = !hasNode || state.nodes.length <= 1;
    placeOnScreen(contextMenu, x, y);
  }

  function clearConnectMode(silent) {
    const hadMode = Boolean(connectFromNodeId);
    connectFromNodeId = "";
    board.classList.remove("is-connecting");
    nodeEls.forEach((card) => card.classList.remove("is-connect-target"));
    if (hadMode && !silent) showToast("Connect mode canceled", "danger");
  }

  function addNodeAt(x, y, config = {}) {
    const node = {
      id: uid("node"),
      label: String(config.label || "New Step"),
      type: TYPE_OPTIONS.includes(config.type) ? config.type : "email",
      x: snap(x),
      y: snap(y)
    };
    if (node.type === "condition") {
      node.conditionRule = String(config.conditionRule || "email_opened");
      node.conditionWindowDays = String(config.conditionWindowDays || "3");
    }
    if (node.type === "delay") {
      node.dripOffsetHours = Number.isFinite(Number(config.dripOffsetHours))
        ? Number(config.dripOffsetHours)
        : 24;
      node.dripDelayUnit = String(config.dripDelayUnit || "days");
      node.label = String(config.label || computeBoardLabelForNode(node));
    }
    state.nodes.push(node);
    persistCurrentState();
    renderNodes();
    return node.id;
  }

  function addLink(from, to, label = "") {
    if (!from || !to || from === to) return;
    if (!getNode(from) || !getNode(to)) return;
    if (state.links.some((l) => l.from === from && l.to === to && String(l.label || "") === String(label || ""))) return;
    state.links.push({ id: uid("link"), from, to, label: String(label || "").trim() });
    showToast("Connection added", "success");
  }

  function addChildNode(parentId) {
    const parentEl = nodeEls.get(parentId);
    if (!parentEl) return;
    const parentX = Number.parseFloat(parentEl.style.left || "0");
    const parentY = Number.parseFloat(parentEl.style.top || "0");
    const childId = addNodeAt(parentX + 220, parentY + 100, { label: "New Step", type: "email" });
    addLink(parentId, childId, "");
    persistCurrentState();
    renderNodes();
  }

  function addYesNoBranch(parentId) {
    const parentEl = nodeEls.get(parentId);
    if (!parentEl) return;
    const parentX = Number.parseFloat(parentEl.style.left || "0");
    const parentY = Number.parseFloat(parentEl.style.top || "0");
    const conditionId = addNodeAt(parentX + 220, parentY, {
      label: "If email opened",
      type: "condition",
      conditionRule: "email_opened",
      conditionWindowDays: "3"
    });
    const yesId = addNodeAt(parentX + 460, parentY - 80, { label: "Yes Path", type: "email" });
    const noId = addNodeAt(parentX + 460, parentY + 120, { label: "No Path", type: "sms" });
    addLink(parentId, conditionId, "");
    addLink(conditionId, yesId, "Yes");
    addLink(conditionId, noId, "No");
    persistCurrentState();
    renderNodes();
    showToast("Condition branch added. Branches are visual until branch execution is enabled.", "success");
  }

  function deleteNode(nodeId) {
    if (!nodeId) return;
    state.nodes = state.nodes.filter((n) => n.id !== nodeId);
    state.links = state.links.filter((l) => l.from !== nodeId && l.to !== nodeId);
    persistCurrentState();
    renderNodes();
  }

  board.addEventListener("contextmenu", (event) => {
    event.preventDefault();
    const nodeEl = event.target.closest(".journey-node-card");
    const nodeId = nodeEl ? String(nodeEl.getAttribute("data-node-id") || "") : "";
    showContextMenu(event.clientX, event.clientY, nodeId);
  });

  contextMenu.addEventListener("click", (event) => {
    const btn = event.target.closest("button[data-action]");
    if (!btn || btn.disabled) return;
    const action = String(btn.getAttribute("data-action") || "");
    hideContextMenu();

    const boardBounds = boardRect();
    const localX = contextPos.x - boardBounds.left;
    const localY = contextPos.y - boardBounds.top;

    if (action === "add-node") {
      addNodeAt(localX, localY, {});
      return;
    }
    if (action === "add-child" && contextTargetNodeId) {
      addChildNode(contextTargetNodeId);
      return;
    }
    if (action === "branch" && contextTargetNodeId) {
      addYesNoBranch(contextTargetNodeId);
      return;
    }
    if (action === "connect-start" && contextTargetNodeId) {
      connectFromNodeId = contextTargetNodeId;
      board.classList.add("is-connecting");
      nodeEls.forEach((card) =>
        card.classList.toggle("is-connect-target", String(card.getAttribute("data-node-id") || "") !== connectFromNodeId)
      );
      showToast("Click another step to connect", "success");
      return;
    }
    if (action === "delete-node" && contextTargetNodeId) {
      deleteNode(contextTargetNodeId);
    }
  });

  document.addEventListener("click", (event) => {
    if (!event.target.closest(".journey-add-step-menu") && !event.target.closest(".journey-flow-add-btn")) {
      hideAddStepMenu();
    }
    if (contextMenu.classList.contains("hidden")) return;
    if (event.target.closest("#journeyContextMenu")) return;
    hideContextMenu();
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      hideContextMenu();
      if (linkDragFromId) {
        cleanupLinkDragSurface();
        showToast("Connect canceled", "danger");
      }
      clearConnectMode(false);
      if (stepDialog.open) stepDialog.close();
    }
  });
  stepDialog.addEventListener("click", (event) => {
    if (event.target === stepDialog) stepDialog.close();
  });
  const stepDialogCloseBtn = stepDialog.querySelector(".journey-step-dialog-close");
  if (stepDialogCloseBtn) {
    stepDialogCloseBtn.addEventListener("click", () => stepDialog.close());
  }

  if (resetBtn) {
    resetBtn.addEventListener("click", () => {
      if (selectedCampaignId != null) {
        try {
          window.localStorage.removeItem(campaignGraphStorageKey(selectedCampaignId));
        } catch {
          // ignore
        }
        const camp = cachedCampaigns.find((c) => Number(c.id) === Number(selectedCampaignId));
        if (camp) {
          applyState(buildGraphFromCampaign(camp));
          renderFreshFlowLayout();
          showToast("Campaign journey reset from saved drip steps", "success");
        }
      } else {
        journeyIsDraftCampaign = true;
        applyState(defaultNewCampaignGraph());
        renderFreshFlowLayout();
        showToast("Journey reset", "success");
      }
    });
  }

  if (journeyNewCampaignBtn) {
    journeyNewCampaignBtn.addEventListener("click", () => startNewCampaignDraft());
  }

  if (saveCampaignBtn) {
    saveCampaignBtn.addEventListener("click", () => saveCampaignJourneyToServer());
  }

  if (duplicateCampaignBtn) {
    duplicateCampaignBtn.addEventListener("click", () => {
      duplicateJourneyCampaign().catch((err) => showToast(err.message || "Could not duplicate campaign", "danger"));
    });
  }

  if (saveAsCampaignBtn) {
    saveAsCampaignBtn.addEventListener("click", () => {
      saveJourneyCampaignAs().catch((err) => showToast(err.message || "Could not save campaign", "danger"));
    });
  }

  const saveCampaignSideBtn = document.getElementById("journeySaveCampaignSideBtn");
  if (saveCampaignSideBtn) {
    saveCampaignSideBtn.addEventListener("click", () => saveCampaignJourneyToServer());
  }

  const journeyCampaignMetaForm = document.getElementById("journeyCampaignMetaForm");
  if (journeyCampaignMetaForm) {
    journeyCampaignMetaForm.addEventListener("submit", (event) => {
      event.preventDefault();
      saveCampaignJourneyToServer();
    });
  }

  if (journeyCampaignNameInput) {
    journeyCampaignNameInput.addEventListener("input", () => {
      updateSaveButtonState();
      if (selectedCampaignId == null) updateCampaignSubtitle();
    });
  }

  if (refreshCampaignsBtn) {
    refreshCampaignsBtn.addEventListener("click", () => {
      refreshCampaignData().then((ok) => {
        if (ok) showToast("Campaign list refreshed", "success");
      });
    });
  }

  function initJourneyPalette() {
    document.querySelectorAll(".journey-palette-item[data-step-type]").forEach((btn) => {
      const channel = String(btn.getAttribute("data-step-type") || "email");
      btn.addEventListener("dragstart", (event) => {
        event.dataTransfer.setData("application/x-journey-step-type", channel);
        event.dataTransfer.effectAllowed = "copy";
      });
      btn.addEventListener("click", () => insertStepBeforeComplete(channel));
    });
  }

  try {
    window.localStorage.removeItem("crm.journeyLayout.v3");
  } catch {
    // ignore
  }
  startNewCampaignDraft({ quiet: true });
  populateJourneyCategorySelect();
  if (isFlowLayout()) {
    syncFlowLayoutFromDom();
    resizeBoardToGraphBounds();
    placeFlowChrome(getFlowOrderedNodeIds());
    drawConnections();
    persistCurrentState();
    window.requestAnimationFrame(() => {
      resizeBoardToGraphBounds();
      drawConnections();
    });
  }
  updateSaveButtonState();
  window.addEventListener("resize", () => {
    resizeBoardToGraphBounds();
    drawConnections();
  });
  wireFlowBoardDrop();
  initJourneyPalette();
  initJourneyIncludeSignatureToggle();
  if (journeyAddCategoryBtn) {
    journeyAddCategoryBtn.addEventListener("click", () => {
      createJourneyCategory().catch((err) => showToast(err.message || "Could not create category", "danger"));
    });
  }
  if (journeyAddCategorySidebarBtn) {
    journeyAddCategorySidebarBtn.addEventListener("click", () => {
      createJourneyCategory().catch((err) => showToast(err.message || "Could not create category", "danger"));
    });
  }
  refreshCampaignData();
  loadJourneySavedTags().catch(() => {});
  loadJourneyEmailTemplates().catch(() => {});
})();
