const webpush = require("web-push");
const { sendEmail, isEmailConfigured } = require("./emailService");
const { applyVapidToWebPush } = require("./vapidKeys");

const REMINDER_LABELS = {
  day_of: "on the follow-up date",
  day_before: "1 day before the follow-up",
  three_days_before: "3 days before the follow-up",
  week_before: "1 week before the follow-up"
};

function ymdLocal(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

/** Calendar date (YYYY-MM-DD) when the reminder should fire. */
function reminderNotifyOnYmd(followUpYmd, reminderKind) {
  const raw = String(followUpYmd || "").trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) return null;
  const [yy, mm, dd] = raw.split("-").map(Number);
  const base = new Date(yy, mm - 1, dd);
  if (!Number.isFinite(base.getTime())) return null;
  const d = new Date(base.getFullYear(), base.getMonth(), base.getDate());
  switch (String(reminderKind || "").trim().toLowerCase()) {
    case "day_of":
      break;
    case "day_before":
      d.setDate(d.getDate() - 1);
      break;
    case "three_days_before":
      d.setDate(d.getDate() - 3);
      break;
    case "week_before":
      d.setDate(d.getDate() - 7);
      break;
    default:
      return null;
  }
  return ymdLocal(d);
}

function reminderSendHour(followUpTimeStr) {
  const t = String(followUpTimeStr || "").trim();
  const tm = /^(\d{1,2}):(\d{2})/.exec(t);
  if (tm) {
    const h = Number(tm[1]);
    if (Number.isFinite(h) && h >= 0 && h <= 23) return h;
  }
  return Number(process.env.FOLLOW_UP_REMINDER_SEND_HOUR || 9);
}

/** True when today is notifyYmd and local clock has reached the send hour. */
function shouldSendNow(notifyYmd, followUpTimeStr, now = new Date()) {
  if (ymdLocal(now) !== notifyYmd) return false;
  return now.getHours() >= reminderSendHour(followUpTimeStr);
}

function getReminderEmailTo() {
  const raw = process.env.FOLLOW_UP_REMINDER_EMAIL || process.env.REMINDER_EMAIL || "";
  const list = raw
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  if (list.length) return list.join(",");
  if (isEmailConfigured()) {
    return String(process.env.SMTP_FROM || process.env.SMTP_USER || "").trim();
  }
  return "";
}

function getPublicBaseUrl() {
  const u = String(process.env.CRM_PUBLIC_URL || "").trim().replace(/\/$/, "");
  if (u) return u;
  const port = Number(process.env.PORT || 3000);
  return `http://localhost:${port}`;
}

async function alreadySent(get, contactId, channel, reminderKind, followUpDate) {
  const row = await get(
    `SELECT id FROM follow_up_reminder_sent
     WHERE contact_id = ? AND channel = ? AND reminder_kind = ? AND follow_up_date = ?`,
    [contactId, channel, reminderKind, followUpDate]
  );
  return !!row;
}

function escapeHtml(s) {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

let processing = false;
let taskProcessing = false;

async function processFollowUpReminders(deps) {
  const { all, get, run } = deps;
  if (processing) return;
  processing = true;
  try {
    const rows = await all(`
      SELECT id, full_name, email, phone, follow_up_date, follow_up_time, follow_up_reminder
      FROM contacts
      WHERE follow_up_date IS NOT NULL AND trim(follow_up_date) != ''
        AND follow_up_reminder IS NOT NULL AND lower(trim(follow_up_reminder)) NOT IN ('', 'none')
    `);

    const now = new Date();
    const emailTo = getReminderEmailTo();
    const canEmail = isEmailConfigured() && emailTo;
    const pushReady = applyVapidToWebPush();
    const subs = pushReady ? await all(`SELECT id, endpoint, subscription_json FROM push_subscriptions`) : [];

    for (const row of rows) {
      const fuDate = String(row.follow_up_date || "").trim();
      const kind = String(row.follow_up_reminder || "").trim().toLowerCase();
      const notifyYmd = reminderNotifyOnYmd(fuDate, kind);
      if (!notifyYmd || notifyYmd !== ymdLocal(now)) continue;
      if (!shouldSendNow(notifyYmd, row.follow_up_time, now)) continue;

      const label = REMINDER_LABELS[kind] || kind;
      const baseUrl = getPublicBaseUrl();
      const contactUrl = `${baseUrl}/contact.html?id=${row.id}`;
      const name = String(row.full_name || "").trim() || `Contact #${row.id}`;

      if (canEmail) {
        const sent = await alreadySent(get, row.id, "email", kind, fuDate);
        if (!sent) {
          try {
            await sendEmail({
              to: emailTo,
              subject: `[CRM] Follow-up reminder: ${name}`,
              text: `Follow-up (${label}) for ${name}.\nScheduled date: ${fuDate}\nOpen: ${contactUrl}`,
              html: `<p><strong>Follow-up reminder</strong> (${escapeHtml(label)})</p>
<p><strong>${escapeHtml(name)}</strong></p>
<p>Scheduled follow-up date: <strong>${escapeHtml(fuDate)}</strong></p>
<p><a href="${escapeHtml(contactUrl)}">Open contact</a></p>`
            });
            await run(
              `INSERT INTO follow_up_reminder_sent (contact_id, channel, reminder_kind, follow_up_date)
               VALUES (?, 'email', ?, ?)`,
              [row.id, kind, fuDate]
            );
          } catch (err) {
            console.error("[follow-up reminder] email failed:", err.message || err);
          }
        }
      }

      if (pushReady && subs.length) {
        const sentPush = await alreadySent(get, row.id, "push", kind, fuDate);
        if (!sentPush) {
          const payload = JSON.stringify({
            title: "CRM follow-up reminder",
            body: `${name} — scheduled ${fuDate} (${label})`,
            url: `/contact.html?id=${row.id}`,
            tag: `crm-followup-${row.id}-${fuDate}-${kind}`
          });
          let anyOk = false;
          for (const sub of subs) {
            try {
              let subscription;
              try {
                subscription = JSON.parse(sub.subscription_json || "{}");
              } catch {
                continue;
              }
              if (!subscription.endpoint) continue;
              await webpush.sendNotification(subscription, payload, {
                TTL: 86400,
                urgency: "normal"
              });
              anyOk = true;
            } catch (err) {
              const code = err && err.statusCode;
              if (code === 404 || code === 410) {
                await run(`DELETE FROM push_subscriptions WHERE endpoint = ?`, [sub.endpoint]);
              } else {
                console.error("[follow-up reminder] push failed:", err.message || err);
              }
            }
          }
          if (anyOk) {
            await run(
              `INSERT INTO follow_up_reminder_sent (contact_id, channel, reminder_kind, follow_up_date)
               VALUES (?, 'push', ?, ?)`,
              [row.id, kind, fuDate]
            );
          }
        }
      }
    }
  } finally {
    processing = false;
  }
}

/** Tasks due today email + push the agent, mirroring follow-up reminders.
 *  One reminder per task per day, deduped via contact_tasks.reminder_sent_date. */
async function processTaskReminders(deps) {
  const { all, get, run } = deps;
  if (taskProcessing) return;
  taskProcessing = true;
  try {
    const now = new Date();
    const todayYmd = ymdLocal(now);
    const rows = await all(
      `SELECT t.id, t.task_name, t.action_type, t.task_time, c.id AS contact_id, c.full_name
       FROM contact_tasks t
       JOIN contacts c ON c.id = t.contact_id
       WHERE t.task_date = ?
         AND lower(trim(COALESCE(t.condition, ''))) != 'completed'
         AND COALESCE(t.reminder_sent_date, '') != ?`,
      [todayYmd, todayYmd]
    );
    if (!Array.isArray(rows) || !rows.length) return;

    const emailTo = getReminderEmailTo();
    const canEmail = isEmailConfigured() && emailTo;
    const pushReady = applyVapidToWebPush();
    const subs = pushReady ? await all(`SELECT id, endpoint, subscription_json FROM push_subscriptions`) : [];
    const baseUrl = getPublicBaseUrl();

    for (const row of rows) {
      if (!shouldSendNow(todayYmd, row.task_time, now)) continue;
      const name = String(row.full_name || "").trim() || `Contact #${row.contact_id}`;
      const taskLabel = String(row.task_name || "Task").trim() || "Task";
      const action = String(row.action_type || "").trim();
      const contactUrl = `${baseUrl}/contact.html?id=${row.contact_id}`;
      let delivered = false;

      if (canEmail) {
        try {
          await sendEmail({
            to: emailTo,
            subject: `[CRM] Task due today: ${taskLabel} — ${name}`,
            text: `Task "${taskLabel}"${action ? ` (${action})` : ""} is due today for ${name}.\nOpen: ${contactUrl}`,
            html: `<p><strong>Task due today</strong></p>
<p><strong>${escapeHtml(taskLabel)}</strong>${action ? ` (${escapeHtml(action)})` : ""}</p>
<p>Contact: <strong>${escapeHtml(name)}</strong></p>
<p><a href="${escapeHtml(contactUrl)}">Open contact</a></p>`
          });
          delivered = true;
        } catch (err) {
          console.error("[task reminder] email failed:", err.message || err);
        }
      }

      if (pushReady && subs.length) {
        const payload = JSON.stringify({
          title: "CRM task due today",
          body: `${taskLabel} — ${name}`,
          url: `/contact.html?id=${row.contact_id}`,
          tag: `crm-task-${row.id}-${todayYmd}`
        });
        for (const sub of subs) {
          try {
            let subscription;
            try {
              subscription = JSON.parse(sub.subscription_json || "{}");
            } catch {
              continue;
            }
            if (!subscription.endpoint) continue;
            await webpush.sendNotification(subscription, payload, { TTL: 86400, urgency: "normal" });
            delivered = true;
          } catch (err) {
            const code = err && err.statusCode;
            if (code === 404 || code === 410) {
              await run(`DELETE FROM push_subscriptions WHERE endpoint = ?`, [sub.endpoint]);
            } else {
              console.error("[task reminder] push failed:", err.message || err);
            }
          }
        }
      }

      if (delivered) {
        await run(`UPDATE contact_tasks SET reminder_sent_date = ? WHERE id = ?`, [todayYmd, row.id]);
      }
    }
  } finally {
    taskProcessing = false;
  }
}

function startFollowUpReminderScheduler(deps) {
  const hosted = String(process.env.NODE_ENV || "").toLowerCase() === "production";
  const tickMs = Number(process.env.FOLLOW_UP_REMINDER_TICK_MS || (hosted ? 60_000 : 180_000));
  const tick = () => {
    processFollowUpReminders(deps).catch((err) => console.error("Follow-up reminder scheduler error:", err));
    processTaskReminders(deps).catch((err) => console.error("Task reminder scheduler error:", err));
  };
  const id = setInterval(tick, tickMs);
  setTimeout(tick, hosted ? 8000 : 30000);
  return () => clearInterval(id);
}

module.exports = {
  startFollowUpReminderScheduler,
  processFollowUpReminders,
  processTaskReminders,
  getReminderEmailTo,
  reminderNotifyOnYmd,
  ymdLocal,
  shouldSendNow,
  getPublicBaseUrl
};
