"use strict";

// Marketing blog store + server-side rendering for the public Cadence site.
// Posts published from the AI Content tool live in the GLOBAL platform DB
// (platformRun/All/Get) so the public, unauthenticated /blog routes can read
// them with no tenant context. Pages are server-rendered to match the existing
// hand-built marketing articles (welcome.css) for SEO.

const { platformRun, platformAll, platformGet } = require("./db");

let schemaReady = false;
async function ensureMarketingBlogSchema() {
  if (schemaReady) return;
  await platformRun(
    `CREATE TABLE IF NOT EXISTS marketing_blog_posts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      slug TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL,
      meta_description TEXT NOT NULL DEFAULT '',
      focus_keyword TEXT NOT NULL DEFAULT '',
      keywords_json TEXT NOT NULL DEFAULT '[]',
      eyebrow TEXT NOT NULL DEFAULT '',
      body_html TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'published',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      published_at TEXT
    )`
  );
  await platformRun(
    `CREATE INDEX IF NOT EXISTS idx_marketing_blog_status ON marketing_blog_posts(status, published_at)`
  );
  schemaReady = true;
}

function escapeHtml(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function slugify(s) {
  return (
    String(s || "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 80) || "post"
  );
}

async function uniqueSlug(base, excludeId) {
  const root = slugify(base);
  let slug = root;
  let n = 1;
  // Append -2, -3, ... until the slug is free (ignoring the row being updated).
  for (;;) {
    const row = await platformGet(`SELECT id FROM marketing_blog_posts WHERE slug = ?`, [slug]);
    if (!row || (excludeId && Number(row.id) === Number(excludeId))) return slug;
    n += 1;
    slug = `${root}-${n}`;
  }
}

function rowToPost(row) {
  if (!row) return null;
  let keywords = [];
  try {
    keywords = JSON.parse(row.keywords_json || "[]");
  } catch (e) {
    keywords = [];
  }
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    metaDescription: row.meta_description || "",
    focusKeyword: row.focus_keyword || "",
    keywords: Array.isArray(keywords) ? keywords : [],
    eyebrow: row.eyebrow || "",
    bodyHtml: row.body_html || "",
    status: row.status || "published",
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    publishedAt: row.published_at
  };
}

async function listPosts({ status } = {}) {
  await ensureMarketingBlogSchema();
  const rows = status
    ? await platformAll(
        `SELECT * FROM marketing_blog_posts WHERE status = ? ORDER BY COALESCE(published_at, created_at) DESC, id DESC`,
        [status]
      )
    : await platformAll(
        `SELECT * FROM marketing_blog_posts ORDER BY COALESCE(published_at, created_at) DESC, id DESC`
      );
  return rows.map(rowToPost);
}

async function getPostBySlug(slug) {
  await ensureMarketingBlogSchema();
  return rowToPost(await platformGet(`SELECT * FROM marketing_blog_posts WHERE slug = ?`, [String(slug || "")]));
}

async function getPostById(id) {
  return rowToPost(await platformGet(`SELECT * FROM marketing_blog_posts WHERE id = ?`, [Number(id)]));
}

// Lightweight published-post list for the public blog index (client-side fetch),
// since the static blog.html is served directly by the host and can't be
// server-injected on this setup.
async function listPublishedCards() {
  const posts = await listPosts({ status: "published" });
  return posts.map((p) => ({
    slug: p.slug,
    title: p.title,
    metaDescription: p.metaDescription,
    eyebrow: p.eyebrow || "Article",
    date: formatDate(p.publishedAt || p.createdAt)
  }));
}

async function savePost(input) {
  await ensureMarketingBlogSchema();
  const id = input.id ? Number(input.id) : null;
  const title = String(input.title || "").trim() || "Untitled";
  const slug = await uniqueSlug(input.slug || title, id);
  const meta = String(input.metaDescription || "").trim();
  const focus = String(input.focusKeyword || "").trim();
  const eyebrow = String(input.eyebrow || "").trim();
  const keywords = Array.isArray(input.keywords)
    ? input.keywords.map((k) => String(k || "").trim()).filter(Boolean)
    : [];
  const body = String(input.bodyHtml || "");
  const status = input.status === "draft" ? "draft" : "published";
  const now = new Date().toISOString();
  if (id) {
    await platformRun(
      `UPDATE marketing_blog_posts
       SET slug=?, title=?, meta_description=?, focus_keyword=?, keywords_json=?, eyebrow=?, body_html=?, status=?, updated_at=?,
           published_at=COALESCE(published_at, ?)
       WHERE id=?`,
      [slug, title, meta, focus, JSON.stringify(keywords), eyebrow, body, status, now, status === "published" ? now : null, id]
    );
    return getPostById(id);
  }
  const res = await platformRun(
    `INSERT INTO marketing_blog_posts
      (slug, title, meta_description, focus_keyword, keywords_json, eyebrow, body_html, status, created_at, updated_at, published_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    [slug, title, meta, focus, JSON.stringify(keywords), eyebrow, body, status, now, now, status === "published" ? now : null]
  );
  return getPostById(res.lastID);
}

async function deletePost(id) {
  await ensureMarketingBlogSchema();
  await platformRun(`DELETE FROM marketing_blog_posts WHERE id = ?`, [Number(id)]);
}

async function setStatus(id, status) {
  await ensureMarketingBlogSchema();
  const s = status === "published" ? "published" : "draft";
  const now = new Date().toISOString();
  await platformRun(
    `UPDATE marketing_blog_posts SET status=?, updated_at=?, published_at=COALESCE(published_at, ?) WHERE id=?`,
    [s, now, s === "published" ? now : null, Number(id)]
  );
  return getPostById(id);
}

function formatDate(iso) {
  try {
    const d = new Date(iso || Date.now());
    if (isNaN(d.getTime())) return "";
    return d.toLocaleDateString("en-US", { month: "long", year: "numeric" });
  } catch (e) {
    return "";
  }
}

// Exact header/footer from the existing hand-built articles so published posts
// look identical to the rest of the marketing site.
const SITE_HEADER = `    <header class="welcome-header">
      <div class="welcome-header-inner">
        <a href="/welcome.html" class="welcome-brand">
          <img src="/favicon.svg" alt="" width="36" height="36" decoding="async" />
          Cadence CRM
        </a>
        <nav class="welcome-nav" aria-label="Primary">
          <a href="/welcome.html#ai">AI</a>
          <a href="/welcome.html#features">Features</a>
          <a href="/welcome.html#pricing">Pricing</a>
          <a href="/welcome.html#faq">FAQ</a>
          <a href="/blog.html">Blog</a>
        </nav>
        <div class="welcome-header-actions">
          <a href="/login.html" class="welcome-login-link" aria-label="Agent Log In"><svg class="welcome-login-icon" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><circle cx="12" cy="8" r="3.75" fill="none" stroke="currentColor" stroke-width="1.75"/><path fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" d="M5 20c0-3.87 3.13-7 7-7s7 3.13 7 7"/></svg><span class="welcome-login-text"><span class="welcome-login-line">Agent</span><span class="welcome-login-line">Log In</span></span></a>
          <a href="/signup.html" class="welcome-btn welcome-btn--primary">Start Free Trial</a>
        </div>
      </div>
    </header>`;

const SITE_FOOTER = `    <footer class="welcome-footer">
      <div class="welcome-footer-inner">
        <span>&copy; Cadence CRM &middot; Health Insurance Agents</span>
        <span><a href="/welcome.html">Home</a> &middot; <a href="/blog.html">Blog</a> &middot; <a href="/login.html">Agent Login</a></span>
      </div>
    </footer>`;

function renderPostPageHtml(post, { origin } = {}) {
  const base = origin || "https://crmcadence.com";
  const url = `${base}/blog/${post.slug}`;
  const title = escapeHtml(post.title);
  const metaDesc = escapeHtml(post.metaDescription || post.title);
  const eyebrow = escapeHtml(post.eyebrow || "Cadence CRM Blog");
  const ld = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: post.title,
    description: post.metaDescription || "",
    datePublished: post.publishedAt || post.createdAt,
    dateModified: post.updatedAt || post.publishedAt || post.createdAt,
    author: { "@type": "Organization", name: "Cadence CRM" },
    publisher: { "@type": "Organization", name: "Cadence CRM", url: "https://crmcadence.com" },
    mainEntityOfPage: url
  };
  const ldJson = JSON.stringify(ld).replace(/</g, "\\u003c");
  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="${metaDesc}" />
    <meta name="robots" content="index, follow" />
    <link rel="canonical" href="${escapeHtml(url)}" />
    <meta property="og:type" content="article" />
    <meta property="og:site_name" content="Cadence CRM" />
    <meta property="og:title" content="${title}" />
    <meta property="og:description" content="${metaDesc}" />
    <meta property="og:url" content="${escapeHtml(url)}" />
    <title>${title} | Cadence CRM</title>
    <link rel="stylesheet" href="/welcome.css" />
    <link rel="icon" type="image/svg+xml" href="/favicon.svg" />
    <script type="application/ld+json">${ldJson}</script>
  </head>
  <body class="welcome-page">
${SITE_HEADER}
    <main class="welcome-article">
      <article class="welcome-article-card">
        <a href="/blog.html" class="welcome-article-back">&#8592; All Articles</a>
        <p class="welcome-section-eyebrow">${eyebrow}</p>
        <h1>${title}</h1>
${post.bodyHtml}
        <div class="welcome-article-cta">
          <h2>Try Cadence CRM</h2>
          <p>Full Pro access for 14 days. Then $79/month. No tiers.</p>
          <a href="/signup.html" class="welcome-btn welcome-btn--primary welcome-btn--lg">Start Free Trial</a>
        </div>
      </article>
    </main>
${SITE_FOOTER}
  </body>
</html>`;
}

function renderIndexCardsHtml(posts) {
  return (posts || [])
    .map((p) => {
      const url = `/blog/${escapeHtml(p.slug)}`;
      const tag = escapeHtml(p.eyebrow || "Article");
      const title = escapeHtml(p.title);
      const desc = escapeHtml(p.metaDescription || "");
      const date = escapeHtml(formatDate(p.publishedAt || p.createdAt));
      return `          <a href="${url}" class="welcome-blog-card">
            <div class="welcome-blog-card-body">
              <span class="welcome-blog-tag">${tag}</span>
              <h2>${title}</h2>
              <p>${desc}</p>
            </div>
            <div class="welcome-blog-card-footer">
              <span class="welcome-blog-date">${date}</span>
              <span class="welcome-blog-read-more">Read article &rarr;</span>
            </div>
          </a>`;
    })
    .join("\n");
}

// Prepend published posts (newest first) into the static blog index grid.
function injectPostsIntoIndex(indexHtml, posts) {
  const cards = renderIndexCardsHtml(posts);
  if (!cards) return indexHtml;
  const marker = '<div class="welcome-blog-grid">';
  if (!indexHtml.includes(marker)) return indexHtml;
  return indexHtml.replace(marker, `${marker}\n${cards}`);
}

function injectPostsIntoSitemap(sitemapXml, posts, origin) {
  const base = origin || "https://crmcadence.com";
  const entries = (posts || [])
    .map((p) => {
      const loc = `${base}/blog/${p.slug}`;
      const lastmod = String(p.updatedAt || p.publishedAt || p.createdAt || "").slice(0, 10);
      return `  <url>\n    <loc>${escapeHtml(loc)}</loc>${lastmod ? `\n    <lastmod>${lastmod}</lastmod>` : ""}\n  </url>`;
    })
    .join("\n");
  if (!entries) return sitemapXml;
  if (sitemapXml.includes("</urlset>")) return sitemapXml.replace("</urlset>", `${entries}\n</urlset>`);
  return sitemapXml;
}

module.exports = {
  ensureMarketingBlogSchema,
  slugify,
  savePost,
  listPosts,
  listPublishedCards,
  getPostBySlug,
  getPostById,
  deletePost,
  setStatus,
  renderPostPageHtml,
  renderIndexCardsHtml,
  injectPostsIntoIndex,
  injectPostsIntoSitemap
};
