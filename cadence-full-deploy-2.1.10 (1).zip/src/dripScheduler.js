const { sendSms, normalizeTwilioFromLine, resolveFromNumber } = require("./twilioService");
const { sendEmail, isEmailConfigured } = require("./emailService");
const { startCall } = require("./twilioService");
const {
  contactRowToMergeFields,
  applyMergeFields,
  overlayContactCustomFields,
  normalizeMergeKey,
  normalizeMergeFieldScope
} = require("./mergeFields");
const { prepareOutboundEmailWithUnsubscribe } = require("./emailUnsubscribe");
const { wrapEmailLinksForClickTracking } = require("./emailClickTracking");
const crypto = require("crypto");

function nowUnix() {
  return Math.floor(Date.now() / 1000);
}

function normalizePhoneDigits(value) {
  return String(value || "").replace(/\D/g, "");
}

function chooseSmsLineAvoidingRecipient(toPhone, preferredLine) {
  const toDigits = normalizePhoneDigits(toPhone);
  const lineOrder = [normalizeTwilioFromLine(preferredLine), "primary", "secondary", "third"];
  const seen = new Set();
  for (const line of lineOrder) {
    if (seen.has(line)) continue;
    seen.add(line);
    try {
      const fromDigits = normalizePhoneDigits(resolveFromNumber(line));
      if (!toDigits || !fromDigits || toDigits !== fromDigits) return line;
    } catch {
      // Line is not configured; skip it.
    }
  }
  return null;
}

function htmlEmailToPlainText(html) {
  return String(html || "")
    .replace(/<\/(p|div|h[1-6]|li|tr)>/gi, "\n")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/gi, " ")
    .replace(/\n{3,}/g, "\n\n")
    .replace(/[ \t]+\n/g, "\n")
    .trim();
}

function escapeHtmlPlain(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function xmlEscape(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function ensureTrackingPixelHtml(html, pixelUrl) {
  const body = String(html || "").trim();
  const pixel = `<img src="${xmlEscape(pixelUrl)}" alt="" width="1" height="1" style="display:block;width:1px;height:1px;border:0;opacity:0;" />`;
  if (!body) return pixel;
  if (/<\/body>/i.test(body)) return body.replace(/<\/body>/i, `${pixel}</body>`);
  return `${body}${pixel}`;
}

function buildEmailOpenPixelUrlFromEnv(token) {
  const base = String(process.env.CRM_PUBLIC_URL || "").trim().replace(/\/$/, "");
  if (!base) return "";
  return `${base}/api/email/open/${encodeURIComponent(String(token || "").trim())}`;
}

/** Wrap stored body as HTML for mail clients; detects rich HTML vs plain text */
function formatEmailHtmlFragment(inner) {
  const raw = String(inner || "").trim();
  if (!raw) return "<p></p>";
  if (/<[a-z][\s\S]*>/i.test(raw)) {
    return raw;
  }
  return `<pre style="white-space:pre-wrap;font-family:inherit;margin:0">${escapeHtmlPlain(raw)}</pre>`;
}

/**
 * Email clients (especially Gmail) often ignore CSS max-width and render remote
 * signature photos at full native size. Force a pixel width attribute + styles.
 */
const DRIP_BODY_IMAGE_MAX_PX = 560;
const DRIP_SIGNATURE_IMAGE_MAX_PX = 160;

function clampImgTagForEmail(imgTag, maxWidthPx) {
  let out = String(imgTag || "");
  const safeMax = Math.max(48, Math.round(Number(maxWidthPx) || 160));
  const styleMatch = out.match(/\sstyle=(['"])([\s\S]*?)\1/i);
  const styleRaw = styleMatch ? String(styleMatch[2] || "") : "";
  let fixedPx = 0;
  const sW = styleRaw.match(/(?:^|;)\s*width\s*:\s*(\d+(?:\.\d+)?)px/i);
  if (sW) fixedPx = Math.round(Number(sW[1]));
  if (!fixedPx) {
    const aW = out.match(/\swidth\s*=\s*["']?(\d+(?:\.\d+)?)(?:px)?["']?/i);
    if (aW) fixedPx = Math.round(Number(aW[1]));
  }
  let maxPx = safeMax;
  const sMaxW = styleRaw.match(/(?:^|;)\s*max-width\s*:\s*(\d+(?:\.\d+)?)px/i);
  if (sMaxW) maxPx = Math.min(maxPx, Math.round(Number(sMaxW[1])));
  if (fixedPx > 0) maxPx = Math.min(maxPx, fixedPx);
  // If the image had no explicit size, still force the cap — otherwise Cloudinary
  // originals (800–2000px) blow up the signature in Gmail.
  if (!fixedPx) fixedPx = maxPx;
  else fixedPx = Math.min(fixedPx, maxPx);

  const cleaned = styleRaw
    .replace(/(?:^|;)\s*max-width\s*:[^;]*/gi, "")
    .replace(/(?:^|;)\s*min-width\s*:[^;]*/gi, "")
    .replace(/(?:^|;)\s*height\s*:[^;]*/gi, "")
    .replace(/(?:^|;)\s*width\s*:\s*[^;]*/gi, "")
    .trim();
  const styleFinal = `${cleaned ? `${cleaned};` : ""}width:${fixedPx}px;max-width:${fixedPx}px;height:auto;display:inline-block;border:0;`;
  if (styleMatch) out = out.replace(/\sstyle=(['"])([\s\S]*?)\1/i, ` style="${styleFinal}"`);
  else out = out.replace(/<img\b/i, `<img style="${styleFinal}"`);
  out = out.replace(/\s+width\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, "");
  out = out.replace(/\s+height\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, "");
  out = out.replace(/<img\b/i, `<img width="${fixedPx}"`);
  return out;
}

/** Clamp body images; use a tighter cap inside saved signature blocks. */
function clampDripEmailImages(html) {
  const raw = String(html || "");
  if (!raw) return raw;
  // Signature blocks: shrink layout tables + images (Gmail ignores CSS-only caps).
  let out = raw.replace(
    /<div\b[^>]*class=(['"])[^'"]*campaign-email-signature-block[^'"]*\1[^>]*>[\s\S]*?<\/div>/gi,
    (block) => {
      let b = String(block || "");
      b = b.replace(/\swidth\s*=\s*("|')?\d+("%?)?\1?/gi, (m, _q, pct) => (pct === "%" ? m : ""));
      b = b.replace(/style=(['"])([\s\S]*?)\1/gi, (full, q, styleRaw) => {
        const cleaned = String(styleRaw || "")
          .replace(/(?:^|;)\s*width\s*:\s*\d+(?:\.\d+)?px\b[^;]*/gi, "")
          .replace(/(?:^|;)\s*min-width\s*:\s*[^;]*/gi, "")
          .trim();
        const next = `${cleaned ? `${cleaned};` : ""}max-width:100%;`;
        return `style=${q}${next}${q}`;
      });
      b = b.replace(/<img\b[^>]*>/gi, (tag) => clampImgTagForEmail(tag, DRIP_SIGNATURE_IMAGE_MAX_PX));
      return b;
    }
  );
  if (/<img[\s>]/i.test(out)) {
    out = out.replace(/<img\b[^>]*>/gi, (tag) => {
      if (/\swidth\s*=\s*["']?160\b/i.test(tag) && /max-width\s*:\s*160px/i.test(tag)) return tag;
      return clampImgTagForEmail(tag, DRIP_BODY_IMAGE_MAX_PX);
    });
  }
  return out;
}

let processing = false;

async function loadCustomMergeFieldsMap(all) {
  try {
    const rows = await all(`SELECT field_key, field_value, field_scope FROM custom_merge_fields`);
    const out = {};
    for (const r of rows || []) {
      if (normalizeMergeFieldScope(r?.field_scope) === "contact") continue;
      const key = normalizeMergeKey(r.field_key);
      if (!key) continue;
      out[key] = String(r.field_value == null ? "" : r.field_value);
    }
    return out;
  } catch {
    return {};
  }
}

function normalizePublicOrigin(raw) {
  return String(raw || "").trim().replace(/\/$/, "");
}

async function processDueDripSends({ all, run, get }) {
  if (processing) return;
  processing = true;
  try {
    const customFields = await loadCustomMergeFieldsMap(all);
    const due = await all(`
    SELECT q.id AS queue_id,
           s.channel AS channel,
           s.subject AS subject,
           s.body AS body,
           s.call_twiml_url AS call_twiml_url,
           s.twilio_from AS step_twilio_from,
           s.email_from AS step_email_from,
           s.step_order AS step_order,
           e.id AS enrollment_id,
           e.status AS enrollment_status,
           dc.schedule_mode AS campaign_schedule_mode,
           dc.start_at AS campaign_start_at,
           dc.end_at AS campaign_end_at,
           dc.twilio_from AS campaign_twilio_from,
           dc.email_from AS campaign_email_from,
           c.id AS contact_id,
           c.full_name AS full_name,
           c.email AS email,
           c.phone AS phone,
           c.do_not_email AS do_not_email,
           c.age AS age,
           c.state AS state,
           c.date_of_contact AS date_of_contact,
           c.quote AS quote,
           c.app_id AS app_id,
           c.upon_approval AS upon_approval,
           c.coverage_start_date AS coverage_start_date,
           c.policy_renewal AS policy_renewal,
           c.vcall AS vcall,
           c.insurance_type AS insurance_type,
           c.custom_fields AS custom_fields
    FROM drip_send_queue q
    JOIN drip_steps s ON s.id = q.step_id
    JOIN drip_enrollments e ON e.id = q.enrollment_id
    JOIN drip_campaigns dc ON dc.id = e.campaign_id
    JOIN contacts c ON c.id = e.contact_id
    WHERE q.status = 'pending'
      AND q.scheduled_at <= ?
      AND e.status = 'active'
    ORDER BY q.scheduled_at ASC, s.step_order ASC, q.id ASC
    LIMIT 25
  `, [nowUnix()]);

    for (const row of due) {
    const merge = contactRowToMergeFields(
      {
        full_name: row.full_name,
        email: row.email,
        phone: row.phone,
        age: row.age,
        state: row.state,
        date_of_contact: row.date_of_contact,
        quote: row.quote,
        app_id: row.app_id,
        upon_approval: row.upon_approval,
        coverage_start_date: row.coverage_start_date,
        policy_renewal: row.policy_renewal,
        vcall: row.vcall,
        insurance_type: row.insurance_type
      },
      String(row.email || "").trim()
    );
    const rowCustomFields = overlayContactCustomFields(customFields, {
      custom_fields: row.custom_fields
    });
    const isEmailStep = row.channel === "email";
    const body = isEmailStep
      ? row.body
      : applyMergeFields(row.body, merge, { keepHtmlNbsp: false, customFields: rowCustomFields });
    const subject = isEmailStep
      ? row.subject || ""
      : applyMergeFields(row.subject || "", merge, { keepHtmlNbsp: false, customFields: rowCustomFields });
    const now = nowUnix();
    const twilioFromLine =
      row.campaign_twilio_from != null && String(row.campaign_twilio_from).trim() !== ""
        ? normalizeTwilioFromLine(row.campaign_twilio_from)
        : "secondary";

    try {
      const enforceCampaignWindow =
        String(row.campaign_schedule_mode || "")
          .trim()
          .toLowerCase() === "scheduled";
      if (enforceCampaignWindow) {
        const campStart = row.campaign_start_at;
        if (campStart != null && Number.isFinite(Number(campStart)) && now < Number(campStart)) {
          continue;
        }
        const campEnd = row.campaign_end_at;
        if (campEnd != null && Number.isFinite(Number(campEnd)) && now > Number(campEnd)) {
          await run(
            `UPDATE drip_send_queue SET status = 'skipped', sent_at = ?, error_message = ? WHERE id = ? AND status = 'pending'`,
            [now, "Campaign end date has passed.", row.queue_id]
          );
          continue;
        }
      }
      if (row.channel === "sms") {
        if (!row.phone || !String(row.phone).trim()) {
          await run(
            `UPDATE drip_send_queue SET status = 'skipped', sent_at = ?, error_message = ? WHERE id = ? AND status = 'pending'`,
            [nowUnix(), "Contact has no phone number.", row.queue_id]
          );
          continue;
        }
        const preferredSmsLine =
          row.step_twilio_from != null && String(row.step_twilio_from).trim() !== ""
            ? normalizeTwilioFromLine(String(row.step_twilio_from).trim())
            : twilioFromLine;
        const safeSmsLine = chooseSmsLineAvoidingRecipient(row.phone.trim(), preferredSmsLine);
        if (!safeSmsLine) {
          await run(
            `UPDATE drip_send_queue SET status = 'failed', sent_at = ?, error_message = ? WHERE id = ? AND status = 'pending'`,
            [nowUnix(), "No usable Twilio from number is configured for SMS.", row.queue_id]
          );
          continue;
        }
        // Check SMS limit before sending drip SMS
        const now2 = new Date();
        const pad2 = (n) => String(n).padStart(2, "0");
        const dayKey   = `${now2.getUTCFullYear()}-${pad2(now2.getUTCMonth()+1)}-${pad2(now2.getUTCDate())}`;
        const monthKey = `${now2.getUTCFullYear()}-${pad2(now2.getUTCMonth()+1)}`;
        const [dRow, mRow] = await Promise.all([
          get(`SELECT COUNT(*) AS n FROM sms_usage WHERE day = ?`, [dayKey]),
          get(`SELECT COUNT(*) AS n FROM sms_usage WHERE month = ?`, [monthKey])
        ]);
        if ((dRow?.n || 0) >= 150 || (mRow?.n || 0) >= 1000) {
          await run(
            `UPDATE drip_send_queue SET status = 'failed', sent_at = ?, error_message = ? WHERE id = ? AND status = 'pending'`,
            [nowUnix(), "SMS limit reached. Contact support@crmcadence.com.", row.queue_id]
          );
          continue;
        }
        await sendSms({ to: row.phone.trim(), body, twilioFrom: safeSmsLine });
        await run(`INSERT INTO sms_usage (day, month) VALUES (?, ?)`, [dayKey, monthKey]);
        await run(
          `UPDATE drip_send_queue SET status = 'sent', sent_at = ?, error_message = NULL WHERE id = ? AND status = 'pending'`,
          [nowUnix(), row.queue_id]
        );
      } else if (row.channel === "email") {
        if (!isEmailConfigured()) {
          await run(
            `UPDATE drip_send_queue SET status = 'failed', sent_at = ?, error_message = ? WHERE id = ? AND status = 'pending'`,
            [nowUnix(), "SMTP email is not configured (missing env vars).", row.queue_id]
          );
          continue;
        }
        if (!row.email || !String(row.email).trim()) {
          await run(
            `UPDATE drip_send_queue SET status = 'skipped', sent_at = ?, error_message = ? WHERE id = ? AND status = 'pending'`,
            [nowUnix(), "Contact has no email address.", row.queue_id]
          );
          continue;
        }
        if (String(row.do_not_email || "").trim() === "1") {
          await run(
            `UPDATE drip_send_queue SET status = 'skipped', sent_at = ?, error_message = ? WHERE id = ? AND status = 'pending'`,
            [nowUnix(), 'Contact has "Do Not Email" set — skipped (CAN-SPAM).', row.queue_id]
          );
          continue;
        }
        let publicOrigin = normalizePublicOrigin(process.env.CRM_PUBLIC_URL || "");
        if (typeof get === "function") {
          try {
            const originRow = await get(`SELECT value FROM twilio_runtime_config WHERE key = ?`, ["crmPublicUrl"]);
            publicOrigin = normalizePublicOrigin(originRow?.value || publicOrigin);
          } catch {
            /* keep env fallback */
          }
        }
        const prepared = prepareOutboundEmailWithUnsubscribe({
          subject,
          text: htmlEmailToPlainText(body) || "",
          html: body || "",
          contact: {
            id: row.contact_id,
            full_name: row.full_name,
            email: row.email,
            phone: row.phone,
            age: row.age,
            state: row.state,
            date_of_contact: row.date_of_contact,
            quote: row.quote,
            app_id: row.app_id,
            upon_approval: row.upon_approval,
            coverage_start_date: row.coverage_start_date,
            policy_renewal: row.policy_renewal,
            vcall: row.vcall,
            insurance_type: row.insurance_type
          },
          tenantId: "legacy",
          publicOrigin,
          mergeFields: merge,
          customFields: rowCustomFields,
          applyMergeFields
        });
        const sendSubject = prepared.subject || "Message";
        const sendText = prepared.text || htmlEmailToPlainText(prepared.html) || "(HTML message)";
        const htmlInner = clampDripEmailImages(formatEmailHtmlFragment(prepared.html || body));
        let htmlWrapped = `<div style="font-family:Segoe UI,Roboto,Helvetica Neue,sans-serif;font-size:15px;line-height:1.55;color:#1e293b;max-width:640px;">${htmlInner}</div>`;
        const stepEmailFromRaw =
          row.step_email_from != null && String(row.step_email_from).trim() !== ""
            ? String(row.step_email_from).trim()
            : "";
        const campaignEmailFromRaw =
          row.campaign_email_from != null && String(row.campaign_email_from).trim() !== ""
            ? String(row.campaign_email_from).trim()
            : "";
        const emailFrom = stepEmailFromRaw || campaignEmailFromRaw || undefined;
        const trackingToken = crypto.randomBytes(24).toString("hex");
        const trackingUrl = buildEmailOpenPixelUrlFromEnv(trackingToken);
        if (trackingUrl) {
          htmlWrapped = ensureTrackingPixelHtml(htmlWrapped, trackingUrl);
          htmlWrapped = await wrapEmailLinksForClickTracking({
            html: htmlWrapped,
            publicOrigin,
            run,
            contactIds: String(row.contact_id || ""),
            toEmails: row.email.trim().toLowerCase(),
            subject: sendSubject,
            openToken: trackingToken,
            tag: ""
          });
        }
        await sendEmail({
          to: row.email.trim(),
          from: emailFrom,
          subject: sendSubject,
          text: sendText,
          html: htmlWrapped,
          headers: prepared.listUnsubscribeHeaders?.headers || {}
        });
        if (trackingUrl) {
          await run(
            `INSERT INTO email_open_tracking (open_token, contact_ids, to_emails, subject)
             VALUES (?, ?, ?, ?)`,
            [trackingToken, String(row.contact_id || ""), row.email.trim().toLowerCase(), sendSubject]
          );
        }
        await run(
          `UPDATE drip_send_queue SET status = 'sent', sent_at = ?, error_message = NULL WHERE id = ? AND status = 'pending'`,
          [nowUnix(), row.queue_id]
        );
      } else if (row.channel === "call") {
        if (!row.phone || !String(row.phone).trim()) {
          await run(
            `UPDATE drip_send_queue SET status = 'skipped', sent_at = ?, error_message = ? WHERE id = ? AND status = 'pending'`,
            [nowUnix(), "Contact has no phone number.", row.queue_id]
          );
          continue;
        }
        const callFromLine =
          row.step_twilio_from != null && String(row.step_twilio_from).trim() !== ""
            ? normalizeTwilioFromLine(String(row.step_twilio_from).trim())
            : twilioFromLine;
        await startCall({
          to: row.phone.trim(),
          twimlUrl: row.call_twiml_url || undefined,
          twilioFrom: callFromLine
        });
        await run(
          `UPDATE drip_send_queue SET status = 'sent', sent_at = ?, error_message = NULL WHERE id = ? AND status = 'pending'`,
          [nowUnix(), row.queue_id]
        );
      } else {
        await run(
          `UPDATE drip_send_queue SET status = 'failed', sent_at = ?, error_message = ? WHERE id = ? AND status = 'pending'`,
          [nowUnix(), "Unknown channel.", row.queue_id]
        );
      }
    } catch (err) {
      const msg = err && err.message ? err.message : String(err);
      await run(
        `UPDATE drip_send_queue SET status = 'failed', sent_at = ?, error_message = ? WHERE id = ? AND status = 'pending'`,
        [nowUnix(), msg.slice(0, 500), row.queue_id]
      );
    }
  }
    await run(
      `UPDATE drip_enrollments
       SET status = 'cancelled'
       WHERE status = 'active'
         AND NOT EXISTS (
           SELECT 1
           FROM drip_send_queue q
           WHERE q.enrollment_id = drip_enrollments.id
             AND q.status = 'pending'
         )`
    );
  } finally {
    processing = false;
  }
}

function startDripScheduler(deps) {
  const hosted = String(process.env.NODE_ENV || "").toLowerCase() === "production";
  const tickMs = Number(process.env.DRIP_TICK_MS || (hosted ? 45_000 : 120_000));
  const tick = () => {
    processDueDripSends(deps).catch((err) => console.error("Drip scheduler error:", err));
  };
  const id = setInterval(tick, tickMs);
  setTimeout(tick, hosted ? 3000 : 20000);
  return () => clearInterval(id);
}

module.exports = {
  startDripScheduler,
  processDueDripSends
};
