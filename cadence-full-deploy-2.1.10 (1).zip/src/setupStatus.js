"use strict";

const { getSmtpMissing, loadAllowedFromAddresses } = require("./emailService");
const { sanitizeAnthropicApiKey } = require("./claudeClient");
const { isTwilioSmsReady, getTwilioSmsMissing, verifyTwilioVoiceApiCredentials } = require("./twilioService");
const googleCal = require("./googleCalendar");

function envTrim(name) {
  return String(process.env[name] || "").trim();
}

/**
 * Aggregated readiness for the Settings "new agent" checklist.
 * All checks use the running process env + DB (same sources as sending mail / Twilio).
 */
module.exports = function createGetSetupStatus(deps) {
  const {
    getConfiguredLoginEmail,
    getConfiguredLoginPasswordHash,
    isVoiceBrowserConfigured,
    listVoiceBrowserConfigGaps
  } = deps;

  return async function getSetupStatus() {
    const smtpMissing = getSmtpMissing();
    let smtp = {
      level: smtpMissing.length ? "error" : "ok",
      missing: smtpMissing,
      label: "Email Setup",
      detail: smtpMissing.length ? "Connect your email so Cadence can send emails and campaigns on your behalf." : "Your email is connected and ready to send."
    };
    if (smtp.level === "ok") {
      try {
        const addrs = await loadAllowedFromAddresses();
        if (!addrs.length) {
          smtp = {
            level: "warn",
            missing: [],
            label: smtp.label,
            detail: "Add a sender email address under Email Sender Addresses so Cadence knows who to send from."
          };
        }
      } catch {
        // leave ok
      }
    }

    const email = getConfiguredLoginEmail();
    const passwordSet = Boolean(getConfiguredLoginPasswordHash());
    let login = {
      level: "error",
      emailSet: Boolean(email),
      passwordSet,
      label: "Sign-in (Settings → General)",
      detail: "Set login email and password, then save."
    };
    if (email && passwordSet) {
      login = { ...login, level: "ok", detail: "Login email and password are configured." };
    } else if (email && !passwordSet) {
      login = { ...login, level: "warn", detail: "Login email is set but no password is stored yet." };
    }

    const rawUrl = envTrim("CRM_PUBLIC_URL");
    let crmPublicUrl = {
      level: "error",
      set: false,
      label: "Email Open Tracking",
      detail: "Enable email open tracking so you know when clients read your emails."
    };
    if (rawUrl) {
      try {
        const u = new URL(rawUrl);
        const https = u.protocol === "https:";
        crmPublicUrl = {
          level: https ? "ok" : "warn",
          set: true,
          https,
          label: crmPublicUrl.label,
          detail: https ? "Email open tracking is active — you'll see when clients open your emails." : "Email tracking is set up but not fully secured. Contact support if needed."
        };
      } catch {
        crmPublicUrl = {
          level: "warn",
          set: true,
          label: crmPublicUrl.label,
          detail: "Public URL may be invalid; check the value in General."
        };
      }
    }

    const smsMissing = getTwilioSmsMissing();
    const smsOk = isTwilioSmsReady();
    const hasSid = Boolean(envTrim("TWILIO_ACCOUNT_SID"));
    const hasToken = Boolean(envTrim("TWILIO_AUTH_TOKEN"));
    const accountOk = hasSid && hasToken;
    const onlyOneCred = (hasSid || hasToken) && !accountOk;

    let twilioSms = {
      level: "off",
      missing: smsMissing,
      label: "Twilio SMS",
      detail: "Optional until you send SMS. No Twilio account credentials in the running environment."
    };
    if (accountOk) {
      if (smsOk) {
        twilioSms = {
          level: "ok",
          missing: [],
          label: twilioSms.label,
          detail: "Account SID, auth token, and at least one From number are set."
        };
      } else {
        twilioSms = {
          level: "partial",
          missing: smsMissing,
          label: twilioSms.label,
          detail: "Credentials present; add at least one Twilio phone number for SMS."
        };
      }
    } else if (onlyOneCred) {
      twilioSms = {
        level: "partial",
        missing: smsMissing,
        label: twilioSms.label,
        detail: "Incomplete Twilio credentials — set both Account SID and Auth Token."
      };
    }

    const voiceGaps = listVoiceBrowserConfigGaps();
    const voiceFieldsPresent = isVoiceBrowserConfigured();
    let voiceCredCheck = { ok: false, error: null };
    if (voiceFieldsPresent) {
      try {
        voiceCredCheck = await verifyTwilioVoiceApiCredentials();
      } catch (err) {
        voiceCredCheck = { ok: false, error: err.message || String(err) };
      }
    }
    const voiceOk = voiceFieldsPresent && voiceCredCheck.ok;
    let twilioVoiceBrowser = {
      level: "off",
      missing: [],
      label: "Twilio Voice (browser)",
      detail: "Optional: API key, secret, and TwiML App for headset / this-computer calling."
    };
    if (voiceOk) {
      twilioVoiceBrowser = {
        level: "ok",
        missing: [],
        label: twilioVoiceBrowser.label,
        detail: "Headset / browser calling verified with Twilio."
      };
    } else if (voiceFieldsPresent && !voiceCredCheck.ok) {
      twilioVoiceBrowser = {
        level: "error",
        missing: [],
        label: twilioVoiceBrowser.label,
        detail:
          voiceCredCheck.error ||
          "API Key and API Secret do not match — create a new API key in Twilio Console and save both values."
      };
    } else if (accountOk) {
      twilioVoiceBrowser = {
        level: "warn",
        missing: voiceGaps,
        label: twilioVoiceBrowser.label,
        detail: `Not ready for in-browser calling. Missing: ${voiceGaps.join(", ") || "see .env.example"}.`
      };
    }

    let googleCalendar = {
      level: "off",
      configured: false,
      connected: false,
      label: "Google Calendar",
      detail: "Optional. Add a Google Client ID and Secret to enable Calendar sync."
    };
    try {
      if (googleCal.isConfigured()) {
        const st = await googleCal.getStatus();
        const connected = Boolean(st.connected);
        googleCalendar = {
          level: connected ? "ok" : "warn",
          configured: true,
          connected,
          label: googleCalendar.label,
          detail: connected
            ? "Google Calendar is connected."
            : "OAuth is configured — connect your Google account under Google Calendar below."
        };
      }
    } catch (err) {
      googleCalendar = {
        level: "warn",
        configured: false,
        connected: false,
        label: googleCalendar.label,
        detail: err && err.message ? String(err.message) : "Unable to read Google Calendar status."
      };
    }

    const anthropicKey = sanitizeAnthropicApiKey(process.env.ANTHROPIC_API_KEY);
    const anthropicKeyLooksValid =
      Boolean(anthropicKey) && /^sk-ant-/.test(anthropicKey) && anthropicKey.length >= 80;
    const anthropic = anthropicKey
      ? anthropicKeyLooksValid
        ? {
            level: "ok",
            configured: true,
            label: "Anthropic / Claude",
            detail:
              "Claude API key is configured for AI Assistant, lead scoring, and summaries."
          }
        : {
            level: "warn",
            configured: true,
            label: "Anthropic / Claude",
            detail: `API key is set but looks truncated or malformed (length ${anthropicKey.length}; expected ~95+). Re-paste the full key from console.anthropic.com, then restart the app.`
          }
      : {
          level: "off",
          configured: false,
          label: "Anthropic / Claude",
          detail: "Optional AI features are off until an Anthropic API key is added."
        };

    const openAiWhisper = envTrim("OPENAI_API_KEY")
      ? {
          level: "ok",
          configured: true,
          label: "OpenAI Whisper",
          detail: "OpenAI API key is configured for speech-to-text workflows."
        }
      : {
          level: "off",
          configured: false,
          label: "OpenAI Whisper",
          detail: "Optional transcription is off until an OpenAI API key is added."
        };

    const thanksIoKey = envTrim("THANKS_IO_API_KEY");
    const thanksIo = thanksIoKey
      ? {
          level: "ok",
          configured: true,
          label: "Thanks.io",
          detail: "Thanks.io API key is saved. Open Settings → Thanks.io to test or send postcards."
        }
      : {
          level: "off",
          configured: false,
          label: "Thanks.io",
          detail: "Optional direct mail. Add a Thanks.io Personal Access Token to connect."
        };

    return { smtp, login, crmPublicUrl, anthropic, openAiWhisper, twilioSms, twilioVoiceBrowser, googleCalendar, thanksIo };
  };
};
