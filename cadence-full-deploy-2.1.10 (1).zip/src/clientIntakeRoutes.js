"use strict";

/**
 * Lightweight client intake form (household snapshot).
 * Same visual style as the Health Insurance Application.
 *
 * GET  /intake/:formKey
 * POST /api/intake/:formKey
 *
 * Reuses lead_capture_config.form_key for tenant routing + notify email.
 */

function escapeHtml(s) {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function str(v, max) {
  return String(v == null ? "" : v).trim().slice(0, max || 200);
}

function buildClientIntakeHtml(formKey, agencyName, options = {}) {
  const safeAgency = escapeHtml(agencyName || "Your Insurance Agent");
  const safeKey = String(formKey || "").replace(/[^a-f0-9]/g, "");
  const apiPath = String(options.apiPath || `/api/intake/${safeKey}`).replace(/"/g, "");

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Client Intake Form — ${safeAgency}</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Segoe UI',system-ui,sans-serif;background:#f1f5f9;min-height:100vh;padding:28px 16px 48px;color:#0f172a}
  .wrap{width:100%;max-width:640px;margin:0 auto}
  .card{background:#fff;border-radius:16px;box-shadow:0 8px 32px rgba(15,23,42,.10);overflow:hidden}
  .card-header{background:#fff;padding:24px 32px 20px;border-bottom:1px solid #e2e8f0;text-align:center}
  .card-header .logo{display:block;max-width:280px;width:100%;height:auto;margin:0 auto 16px}
  .card-header h1{color:#002677;font-size:1.35rem;font-weight:800;letter-spacing:-.01em;margin-bottom:6px}
  .card-header p{color:#475569;font-size:.9rem;line-height:1.45}
  .card-body{padding:28px 32px 32px}
  .section{margin-bottom:22px;padding-bottom:8px;border-bottom:1px solid #e2e8f0}
  .section:last-of-type{border-bottom:none;margin-bottom:12px}
  .section-title{font-size:1rem;font-weight:800;color:#002677;margin-bottom:4px}
  .section-hint{font-size:.84rem;color:#64748b;margin-bottom:14px;line-height:1.4}
  .field{margin-bottom:14px}
  label{display:block;font-size:.78rem;font-weight:600;color:#475569;margin-bottom:5px;text-transform:uppercase;letter-spacing:.04em}
  .req::after{content:" *";color:#dc2626}
  input,select{width:100%;border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.95rem;color:#0f172a;background:#fff}
  input:focus,select:focus{outline:none;border-color:#002677}
  .row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  .toggle{display:flex;align-items:center;gap:10px;margin-bottom:14px;padding:10px 12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px}
  .toggle input{width:auto;margin:0}
  .toggle label{margin:0;text-transform:none;letter-spacing:0;font-size:.92rem;font-weight:600;color:#334155;cursor:pointer}
  .hidden{display:none !important}
  .btn{display:block;width:100%;padding:14px;background:#002677;color:#fff;font-weight:700;font-size:1rem;border:none;border-radius:999px;cursor:pointer;margin-top:8px}
  .btn:hover{opacity:.92}
  .btn:disabled{opacity:.6;cursor:not-allowed}
  .success{display:none;text-align:center;padding:40px 16px}
  .success-icon{width:56px;height:56px;border-radius:50%;background:#ecfdf5;color:#059669;display:inline-flex;align-items:center;justify-content:center;font-size:1.6rem;font-weight:800;margin-bottom:14px}
  .success h2{color:#002677;font-size:1.2rem;margin-bottom:8px}
  .success p{color:#475569;font-size:.95rem;line-height:1.5}
  .err{color:#dc2626;font-size:.88rem;margin:10px 0;display:none}
  .footer{margin-top:18px;text-align:center;font-size:.78rem;color:#94a3b8}
  .footer a{color:#002677;text-decoration:none}
  @media(max-width:640px){.row{grid-template-columns:1fr}.card-body{padding:20px}.card-header{padding:20px}.card-header .logo{max-width:220px}}
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="card-header">
      <img class="logo" src="/united-healthcare-logo.png" alt="UnitedHealthcare" width="280" height="56" />
      <h1>Client Intake Form</h1>
      <p>Quick household info for ${safeAgency}. Takes about one minute.</p>
    </div>
    <div class="card-body">
      <form id="ci-form" autocomplete="off">

        <div class="section">
          <div class="section-title">Primary Insured</div>
          <p class="section-hint">The main person who will be on the policy.</p>
          <div class="field">
            <label class="req" for="full_name">Full name</label>
            <input id="full_name" name="full_name" type="text" required maxlength="200" autocomplete="name" />
          </div>
          <div class="field">
            <label class="req" for="primary_age">Age of primary insured</label>
            <input id="primary_age" name="primary_age" type="number" required min="0" max="120" inputmode="numeric" placeholder="e.g. 42" />
          </div>
          <div class="row">
            <div class="field">
              <label class="req" for="email">Email address</label>
              <input id="email" name="email" type="email" required maxlength="200" autocomplete="email" />
            </div>
            <div class="field">
              <label class="req" for="zip_code">ZIP code</label>
              <input id="zip_code" name="zip_code" type="text" required maxlength="12" inputmode="numeric" autocomplete="postal-code" placeholder="e.g. 75001" />
            </div>
          </div>
        </div>

        <div class="section">
          <div class="section-title">Spouse</div>
          <div class="toggle">
            <input type="checkbox" id="has_spouse" />
            <label for="has_spouse">Include spouse (if applicable)</label>
          </div>
          <div id="spouse-fields" class="hidden">
            <div class="row">
              <div class="field">
                <label class="req" for="spouse_name">Spouse full name</label>
                <input id="spouse_name" name="spouse_name" type="text" maxlength="200" />
              </div>
              <div class="field">
                <label for="spouse_age">Spouse age</label>
                <input id="spouse_age" name="spouse_age" type="number" min="0" max="120" inputmode="numeric" />
              </div>
            </div>
          </div>
        </div>

        <div class="section">
          <div class="section-title">Children</div>
          <div class="toggle">
            <input type="checkbox" id="has_child1" />
            <label for="has_child1">Include Child 1 (if applicable)</label>
          </div>
          <div id="child1-fields" class="hidden">
            <div class="row">
              <div class="field">
                <label class="req" for="child1_name">Child 1 full name</label>
                <input id="child1_name" name="child1_name" type="text" maxlength="200" />
              </div>
              <div class="field">
                <label for="child1_age">Child 1 age</label>
                <input id="child1_age" name="child1_age" type="number" min="0" max="120" inputmode="numeric" />
              </div>
            </div>
          </div>
          <div class="toggle">
            <input type="checkbox" id="has_child2" />
            <label for="has_child2">Include Child 2 (if applicable)</label>
          </div>
          <div id="child2-fields" class="hidden">
            <div class="row">
              <div class="field">
                <label class="req" for="child2_name">Child 2 full name</label>
                <input id="child2_name" name="child2_name" type="text" maxlength="200" />
              </div>
              <div class="field">
                <label for="child2_age">Child 2 age</label>
                <input id="child2_age" name="child2_age" type="number" min="0" max="120" inputmode="numeric" />
              </div>
            </div>
          </div>
        </div>

        <p class="err" id="ci-err"></p>
        <button type="submit" class="btn" id="ci-submit">Submit Intake Form</button>
      </form>

      <div class="success" id="ci-success">
        <div class="success-icon">✓</div>
        <h2>Thank you</h2>
        <p>Your information was submitted to ${safeAgency}. They will follow up shortly.</p>
      </div>
    </div>
  </div>
  <div class="footer">Powered by <a href="https://crmcadence.com" target="_blank" rel="noopener">Cadence CRM</a></div>
</div>
<script>
(function () {
  function wireToggle(checkId, panelId, requiredIds) {
    var check = document.getElementById(checkId);
    var panel = document.getElementById(panelId);
    function sync() {
      var on = check.checked;
      panel.classList.toggle("hidden", !on);
      (requiredIds || []).forEach(function (id) {
        var el = document.getElementById(id);
        if (el) el.required = on;
      });
    }
    check.addEventListener("change", sync);
    sync();
  }
  wireToggle("has_spouse", "spouse-fields", ["spouse_name"]);
  wireToggle("has_child1", "child1-fields", ["child1_name"]);
  wireToggle("has_child2", "child2-fields", ["child2_name"]);

  var form = document.getElementById("ci-form");
  var err = document.getElementById("ci-err");
  var btn = document.getElementById("ci-submit");
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    err.style.display = "none";
    err.textContent = "";
    btn.disabled = true;
    btn.textContent = "Submitting…";
    var payload = {
      full_name: document.getElementById("full_name").value.trim(),
      primary_age: document.getElementById("primary_age").value.trim(),
      email: document.getElementById("email").value.trim(),
      zip_code: document.getElementById("zip_code").value.trim(),
      has_spouse: document.getElementById("has_spouse").checked,
      spouse_name: document.getElementById("spouse_name").value.trim(),
      spouse_age: document.getElementById("spouse_age").value.trim(),
      has_child1: document.getElementById("has_child1").checked,
      child1_name: document.getElementById("child1_name").value.trim(),
      child1_age: document.getElementById("child1_age").value.trim(),
      has_child2: document.getElementById("has_child2").checked,
      child2_name: document.getElementById("child2_name").value.trim(),
      child2_age: document.getElementById("child2_age").value.trim()
    };
    fetch("${apiPath}", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    })
      .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, data: d }; }); })
      .then(function (res) {
        if (!res.ok) throw new Error((res.data && res.data.error) || "Submit failed.");
        form.style.display = "none";
        document.getElementById("ci-success").style.display = "block";
      })
      .catch(function (ex) {
        err.textContent = ex.message || "Something went wrong. Please try again.";
        err.style.display = "block";
        btn.disabled = false;
        btn.textContent = "Submit Intake Form";
      });
  });
})();
</script>
</body>
</html>`;
}

function validateIntake(body) {
  if (!str(body.full_name, 200)) return "Full name is required.";
  const age = Number(body.primary_age);
  if (!Number.isFinite(age) || age < 0 || age > 120) return "Enter a valid age for the primary insured.";
  const email = str(body.email, 200);
  if (!email || !email.includes("@")) return "A valid email address is required.";
  if (!str(body.zip_code, 20)) return "ZIP code is required.";
  if (body.has_spouse && !str(body.spouse_name, 200)) return "Spouse name is required when spouse is included.";
  if (body.has_child1 && !str(body.child1_name, 200)) return "Child 1 name is required when Child 1 is included.";
  if (body.has_child2 && !str(body.child2_name, 200)) return "Child 2 name is required when Child 2 is included.";
  return null;
}

function buildIntakeNotes(body) {
  const lines = [
    "Client intake form submitted via Cadence.",
    "",
    `Primary: ${str(body.full_name, 200)} (age ${str(body.primary_age, 10)})`,
    `Email: ${str(body.email, 200)}`,
    `ZIP: ${str(body.zip_code, 20)}`
  ];
  if (body.has_spouse) {
    lines.push(
      `Spouse: ${str(body.spouse_name, 200)}${str(body.spouse_age, 10) ? ` (age ${str(body.spouse_age, 10)})` : ""}`
    );
  }
  if (body.has_child1) {
    lines.push(
      `Child 1: ${str(body.child1_name, 200)}${str(body.child1_age, 10) ? ` (age ${str(body.child1_age, 10)})` : ""}`
    );
  }
  if (body.has_child2) {
    lines.push(
      `Child 2: ${str(body.child2_name, 200)}${str(body.child2_age, 10) ? ` (age ${str(body.child2_age, 10)})` : ""}`
    );
  }
  return lines.join("\n");
}

function splitPersonName(fullName) {
  const parts = str(fullName, 200).split(/\s+/).filter(Boolean);
  if (!parts.length) return { first_name: "", last_name: "" };
  if (parts.length === 1) return { first_name: parts[0], last_name: "" };
  return { first_name: parts[0], last_name: parts.slice(1).join(" ") };
}

function householdMemberRecord(id, relationship, fullName) {
  const name = splitPersonName(fullName);
  if (!name.first_name && !name.last_name) return null;
  return {
    id,
    relationship,
    first_name: name.first_name,
    last_name: name.last_name,
    date_of_birth: "",
    gender: "",
    tobacco: ""
  };
}

function buildIntakeHouseholdMembers(body) {
  const members = [];
  if (body.has_spouse) {
    const spouse = householdMemberRecord("hm_spouse", "Spouse", body.spouse_name);
    if (spouse) members.push(spouse);
  }
  if (body.has_child1) {
    const child = householdMemberRecord("hm_child1", "Child", body.child1_name);
    if (child) members.push(child);
  }
  if (body.has_child2) {
    const child = householdMemberRecord("hm_child2", "Child", body.child2_name);
    if (child) members.push(child);
  }
  return members;
}

function resolveIntakeMirrorUrl() {
  const full = String(process.env.CLIENT_INTAKE_MIRROR_URL || "").trim().replace(/\/$/, "");
  if (full) return full;
  const base = String(
    process.env.CLIENT_INTAKE_MIRROR_BASE || process.env.INSURANCE_APP_MIRROR_BASE || ""
  )
    .trim()
    .replace(/\/$/, "");
  if (base) return `${base}/api/intake-form`;
  const applyUrl = String(process.env.INSURANCE_APP_MIRROR_APPLY_URL || "").trim();
  if (applyUrl) {
    try {
      return `${new URL(applyUrl).origin}/api/intake-form`;
    } catch {
      /* ignore invalid URL */
    }
  }
  return "";
}

async function mirrorClientIntake(body, req) {
  if (String(req.get("x-cadence-mirror") || "") === "1") return;
  const url = resolveIntakeMirrorUrl();
  if (!url) return;
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 15000);
    const resp = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Cadence-Mirror": "1"
      },
      body: JSON.stringify(body),
      signal: controller.signal
    });
    clearTimeout(timer);
    if (!resp.ok) {
      const text = await resp.text().catch(() => "");
      console.warn(
        `[client-intake] Mirror to ${url} failed: HTTP ${resp.status} ${String(text).slice(0, 200)}`
      );
    } else {
      console.log(`[client-intake] Mirrored intake to ${url}`);
    }
  } catch (err) {
    console.warn("[client-intake] Mirror request failed:", err.message || err);
  }
}

function registerClientIntakeRoutes(app, deps) {
  const {
    platformGet,
    withTenantContext,
    openTenantDatabase,
    run,
    get,
    LEGACY_TENANT_ID,
    sendNotifyEmail,
    logContactActivity,
    publicFormsLimiter
  } = deps;

  const rateLimit = typeof publicFormsLimiter === "function" ? publicFormsLimiter : (_req, _res, next) => next();

  async function ensureTenantDb(tenantId) {
    const id = Number(tenantId);
    if (!Number.isInteger(id) || id <= 0) throw new Error("Invalid tenant id");
    if (id === Number(LEGACY_TENANT_ID)) return;
    if (typeof openTenantDatabase === "function") await openTenantDatabase(id);
  }

  async function resolveAgencyName(tenantId) {
    let agencyName = "Your Insurance Agent";
    if (Number(tenantId) !== Number(LEGACY_TENANT_ID)) {
      const signup = await platformGet(
        `SELECT agency_name FROM subscription_signups WHERE tenant_id = ?`,
        [tenantId]
      );
      if (signup && signup.agency_name) agencyName = signup.agency_name;
    }
    return agencyName;
  }

  async function resolveDefaultIntakeConfig() {
    let cfg = await platformGet(
      `SELECT form_key, tenant_id, notify_email FROM lead_capture_config WHERE tenant_id = ?`,
      [LEGACY_TENANT_ID]
    );
    if (!cfg) {
      cfg = await platformGet(
        `SELECT form_key, tenant_id, notify_email FROM lead_capture_config ORDER BY id ASC LIMIT 1`
      );
    }
    return cfg || null;
  }

  async function handleIntakeSubmit(cfg, body, res, req) {
    const validationError = validateIntake(body);
    if (validationError) return res.status(400).json({ error: validationError });

    const fullName = str(body.full_name, 200);
    const email = str(body.email, 200);
    const zipCode = str(body.zip_code, 20);
    const notes = buildIntakeNotes(body);
    const tags = "client-intake,web-lead";
    const householdMembers = buildIntakeHouseholdMembers(body);
    const householdJson = JSON.stringify(householdMembers);
    const householdSize = String(1 + householdMembers.length);
    const isMirror = Boolean(req && String(req.get("x-cadence-mirror") || "") === "1");

    await ensureTenantDb(cfg.tenant_id);

    let contactId = null;
    await withTenantContext(cfg.tenant_id, async () => {
      const existing = await get(
        `SELECT id, notes, tags, household_members FROM contacts
          WHERE lower(trim(COALESCE(email, ''))) = lower(trim(?))
          ORDER BY id ASC LIMIT 1`,
        [email]
      );
      if (existing && existing.id) {
        contactId = existing.id;
        const prevNotes = String(existing.notes || "").trim();
        const mergedNotes = prevNotes ? `${prevNotes}\n\n${notes}` : notes;
        const prevTags = String(existing.tags || "");
        const tagSet = new Set(
          prevTags
            .split(/[,;]/)
            .map((t) => t.trim())
            .filter(Boolean)
            .map((t) => t.toLowerCase())
        );
        ["client-intake", "web-lead"].forEach((t) => tagSet.add(t));
        const keepHousehold = String(existing.household_members || "").trim();
        await run(
          `UPDATE contacts SET
             full_name = ?, age = ?, zip_code = ?, notes = ?, tags = ?,
             household_size = ?,
             household_members = CASE WHEN trim(COALESCE(household_members, '')) = '' THEN ? ELSE household_members END,
             lead_source = COALESCE(NULLIF(trim(lead_source), ''), 'Client Intake'),
             updated_at = CURRENT_TIMESTAMP
           WHERE id = ?`,
          [
            fullName,
            str(body.primary_age, 10),
            zipCode,
            mergedNotes,
            [...tagSet].join(","),
            householdSize,
            keepHousehold ? keepHousehold : householdJson,
            contactId
          ]
        );
      } else {
        const result = await run(
          `INSERT INTO contacts
             (full_name, email, age, zip_code, household_size, household_members,
              status, tags, notes, lead_source, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, 'New Lead', ?, ?, 'Client Intake', CURRENT_TIMESTAMP)`,
          [fullName, email, str(body.primary_age, 10), zipCode, householdSize, householdJson, tags, notes]
        );
        contactId = result && (result.lastID || result.id) ? Number(result.lastID || result.id) : null;
        if (!contactId) {
          const created = await get(
            `SELECT id FROM contacts
              WHERE lower(trim(COALESCE(email, ''))) = lower(trim(?))
              ORDER BY id DESC LIMIT 1`,
            [email]
          );
          contactId = created && created.id ? Number(created.id) : null;
        }
      }
      if (!contactId) {
        throw new Error("Intake saved but contact id could not be confirmed.");
      }
      if (typeof logContactActivity === "function") {
        try {
          await logContactActivity(contactId, "intake", "Client intake form submitted");
        } catch {
          /* ignore */
        }
      }
    });

    console.log(
      `[client-intake] Saved contact ${contactId} (${email}) tenant=${cfg.tenant_id}${isMirror ? " mirror" : ""}`
    );

    const notifyTo =
      str(cfg.notify_email, 200) ||
      str(process.env.TRIAL_SIGNUP_NOTIFY_EMAIL, 200) ||
      str(process.env.CONTACT_SALES_NOTIFY_EMAIL, 200) ||
      str(process.env.SMTP_FROM || process.env.SMTP_USER, 200);

    if (notifyTo && typeof sendNotifyEmail === "function") {
      try {
        await sendNotifyEmail({
          to: notifyTo,
          subject: `New client intake: ${fullName}`,
          text: [
            "A client submitted your Cadence Client Intake Form.",
            "",
            notes,
            "",
            "This contact was added/updated in your CRM automatically."
          ].join("\n")
        });
        console.log(`[client-intake] Notification email sent to ${notifyTo}`);
      } catch (notifyErr) {
        console.warn("[client-intake] Notification email failed:", notifyErr.message || notifyErr);
      }
    } else {
      console.warn(
        "[client-intake] No notification email configured. Set Lead Capture → Lead Notification Email (or TRIAL_SIGNUP_NOTIFY_EMAIL / SMTP_FROM)."
      );
    }

    if (req) void mirrorClientIntake(body, req);

    return res.json({ ok: true, contactId });
  }

  async function serveIntakePage(res, formKey, tenantId, apiPath) {
    const agencyName = await resolveAgencyName(tenantId);
    res.removeHeader("X-Frame-Options");
    res.setHeader("Content-Security-Policy", "frame-ancestors *");
    res.type("html").send(buildClientIntakeHtml(formKey, agencyName, { apiPath }));
  }

  // Friendly short URL for phone / SMS (no long key in the link).
  app.get(["/intake-form", "/intakeform"], async (req, res) => {
    try {
      const cfg = await resolveDefaultIntakeConfig();
      if (!cfg || !cfg.form_key) {
        return res
          .status(404)
          .send("Intake form is not set up yet. Open Lead Capture Form in Cadence to create your link.");
      }
      await serveIntakePage(res, cfg.form_key, cfg.tenant_id, "/api/intake-form");
    } catch (err) {
      console.error("[client-intake] GET /intake-form error:", err.message || err);
      res.status(500).send("Something went wrong. Please try again.");
    }
  });

  app.post("/api/intake-form", rateLimit, async (req, res) => {
    try {
      const cfg = await resolveDefaultIntakeConfig();
      if (!cfg) return res.status(404).json({ error: "Form not found." });
      await handleIntakeSubmit(cfg, req.body || {}, res, req);
    } catch (err) {
      console.error("[client-intake] POST /api/intake-form error:", err.message || err);
      res.status(500).json({ error: "Something went wrong. Please try again." });
    }
  });

  app.get("/intake/:formKey", async (req, res) => {
    try {
      const formKey = String(req.params.formKey || "").replace(/[^a-f0-9]/g, "");
      if (!formKey) return res.status(400).send("Invalid form link.");
      const cfg = await platformGet(
        `SELECT tenant_id FROM lead_capture_config WHERE form_key = ?`,
        [formKey]
      );
      if (!cfg) {
        return res
          .status(404)
          .send(
            "Form not found. The link may have been regenerated — check Lead Capture Form in your CRM for the current link."
          );
      }
      await serveIntakePage(res, formKey, cfg.tenant_id, `/api/intake/${formKey}`);
    } catch (err) {
      console.error("[client-intake] GET /intake error:", err.message || err);
      res.status(500).send("Something went wrong. Please try again.");
    }
  });

  app.post("/api/intake/:formKey", rateLimit, async (req, res) => {
    try {
      const formKey = String(req.params.formKey || "").replace(/[^a-f0-9]/g, "");
      if (!formKey) return res.status(400).json({ error: "Invalid form link." });
      const cfg = await platformGet(
        `SELECT tenant_id, notify_email FROM lead_capture_config WHERE form_key = ?`,
        [formKey]
      );
      if (!cfg) return res.status(404).json({ error: "Form not found." });
      await handleIntakeSubmit(cfg, req.body || {}, res, req);
    } catch (err) {
      console.error("[client-intake] POST /api/intake error:", err.message || err);
      res.status(500).json({ error: "Something went wrong. Please try again." });
    }
  });
}

module.exports = {
  registerClientIntakeRoutes,
  buildClientIntakeHtml
};
