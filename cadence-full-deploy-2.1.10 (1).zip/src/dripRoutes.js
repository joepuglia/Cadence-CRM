const { isTwilioSmsReady, getTwilioSmsMissing, normalizeTwilioFromLine } = require("./twilioService");
const { normalizeCampaignEmailFrom, loadAllowedFromAddresses, isEmailConfigured, getSmtpMissing } = require("./emailService");
const { enrollContactInCampaign } = require("./dripEnrollment");
const { rememberTags } = require("./savedTags");

const TAG_CAMPAIGN_FUNCTIONS = new Set(["none", "enroll"]);

function normalizeScheduleMode(raw) {
  const s = String(raw || "")
    .trim()
    .toLowerCase();
  if (s === "scheduled" || s === "schedule") return "scheduled";
  return "on_tag";
}

function normalizeTagRules(raw) {
  let arr = raw;
  if (raw == null || raw === "") return [];
  if (typeof raw === "string") {
    try {
      arr = JSON.parse(raw);
    } catch {
      throw new Error("tag_rules must be valid JSON");
    }
  }
  if (!Array.isArray(arr)) throw new Error("tag_rules must be an array");
  const seen = new Map();
  for (const item of arr) {
    const o = item || {};
    const tag = o.tag != null ? String(o.tag).trim() : "";
    if (!tag) continue;
    /** Missing `function` means tag-trigger enrollment (matches campaign UI). Absent must not default to "none". */
    let fn;
    if (!Object.prototype.hasOwnProperty.call(o, "function")) {
      fn = "enroll";
    } else {
      const raw = o.function;
      fn = raw == null ? "" : String(raw).trim().toLowerCase();
      if (fn === "") fn = "none";
    }
    if (!TAG_CAMPAIGN_FUNCTIONS.has(fn)) {
      throw new Error(`Unknown campaign function "${fn}" for tag "${tag}"`);
    }
    seen.set(tag.toLowerCase(), { tag, function: fn });
  }
  return [...seen.values()];
}

function stringifyTagRules(rules) {
  return JSON.stringify(rules);
}

function normalizeCampaignTwilioFrom(body) {
  if (!body || typeof body !== "object") return normalizeTwilioFromLine("secondary");
  const fromSnake = body.twilio_from;
  const fromCamel = body.twilioFrom;
  let raw = null;
  if (fromSnake !== undefined && fromSnake !== null && String(fromSnake).trim() !== "") raw = fromSnake;
  else if (fromCamel !== undefined && fromCamel !== null && String(fromCamel).trim() !== "") raw = fromCamel;
  return normalizeTwilioFromLine(raw != null ? String(raw).trim() : "secondary");
}

/** Empty string = inherit campaign default Twilio line for SMS steps. */
function normalizeOptionalStepTwilioFrom(raw) {
  const t = raw == null ? "" : String(raw).trim();
  if (!t) return "";
  return normalizeTwilioFromLine(t);
}

async function normalizeCampaignCategoryId(get, rawCategoryId) {
  if (rawCategoryId == null || rawCategoryId === "") return null;
  const id = Number(rawCategoryId);
  if (!Number.isFinite(id) || id < 1) throw new Error("Invalid category_id");
  const row = await get(`SELECT id FROM campaign_categories WHERE id = ?`, [Math.floor(id)]);
  if (!row) throw new Error("Category not found");
  return Math.floor(id);
}

function pickCampaignEmailFromBody(body) {
  if (!body) return "";
  if (body.email_from != null) return body.email_from;
  if (body.emailFrom != null) return body.emailFrom;
  return "";
}

function pickStepEmailFromValue(step) {
  if (!step || typeof step !== "object") return "";
  if (step.email_from != null && String(step.email_from).trim() !== "") return String(step.email_from).trim();
  if (step.emailFrom != null && String(step.emailFrom).trim() !== "") return String(step.emailFrom).trim();
  return "";
}

/**
 * Validate optional per-step email_from against the allowed senders. Empty = inherit campaign default.
 */
function normalizeOptionalStepEmailFrom(raw, allowedAddresses) {
  const s = String(raw ?? "").trim();
  if (!s) return "";
  const list = Array.isArray(allowedAddresses) ? allowedAddresses : [];
  const match = list.find((a) => a.toLowerCase() === s.toLowerCase());
  if (!match) {
    throw new Error(
      list.length
        ? `email_from must be empty or one of: ${list.join(", ")}`
        : "No sender addresses configured. Set SMTP_FROM or SMTP_USER, or add an address in Settings."
    );
  }
  return match;
}

/** True if HTML email has visible text or at least one image */
function emailBodyHasContent(body) {
  const s = String(body || "");
  if (/<img\s/i.test(s)) return true;
  const text = s
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
  return text.length > 0;
}

function attachTagRules(row) {
  if (!row) return row;
  try {
    const parsed = typeof row.tag_config === "string" ? JSON.parse(row.tag_config || "[]") : row.tag_config;
    row.tag_rules = Array.isArray(parsed) ? parsed : [];
  } catch {
    row.tag_rules = [];
  }
  return row;
}

/** Rows from drip_send_queue joined to drip_steps before campaign step rewrite */
function buildCompletedEnrollmentStepOrders(rows) {
  const done = new Set();
  for (const r of rows) {
    done.add(`${Number(r.enrollment_id)}:${Number(r.step_order)}`);
  }
  return done;
}

async function rescheduleQueuesAfterCampaignStepRewrite(run, all, campaignId, completedEnrollmentStepOrders) {
  const enrollments = await all(`SELECT id, started_at FROM drip_enrollments WHERE campaign_id = ? AND status = 'active'`, [
    campaignId
  ]);
  const newSteps = await all(
    `SELECT id, step_order, offset_hours FROM drip_steps WHERE campaign_id = ? ORDER BY step_order ASC`,
    [campaignId]
  );
  for (const en of enrollments) {
    const startedAt = Number(en.started_at);
    if (!Number.isFinite(startedAt)) continue;
    for (const step of newSteps) {
      const order = Number(step.step_order);
      const key = `${Number(en.id)}:${order}`;
      if (completedEnrollmentStepOrders.has(key)) continue;
      const scheduledAt = startedAt + Math.round(Number(step.offset_hours) * 3600);
      await run(`INSERT INTO drip_send_queue (enrollment_id, step_id, scheduled_at, status) VALUES (?, ?, ?, 'pending')`, [
        en.id,
        step.id,
        scheduledAt
      ]);
    }
  }
}

function normalizeSteps(rawSteps, allowedEmailAddresses = []) {
  if (!Array.isArray(rawSteps) || rawSteps.length === 0) {
    throw new Error("steps must be a non-empty array");
  }
  return rawSteps.map((s, index) => {
    const channel = String(s.channel || "").toLowerCase();
    if (channel !== "sms" && channel !== "email" && channel !== "call") {
      throw new Error(`Step ${index + 1}: channel must be "sms", "email", or "call"`);
    }
    const offset = Number(s.offset_hours);
    if (!Number.isFinite(offset) || offset < 0) {
      throw new Error(`Step ${index + 1}: offset_hours must be a number >= 0`);
    }
    const body = s.body == null ? "" : channel === "email" ? String(s.body) : String(s.body).trim();
    if (channel === "sms" && !String(body).trim()) {
      throw new Error(`Step ${index + 1}: body is required`);
    }
    if (channel === "email" && !emailBodyHasContent(body)) {
      throw new Error(`Step ${index + 1}: email body is required`);
    }
    const callTwimlUrl = s.call_twiml_url == null ? "" : String(s.call_twiml_url).trim();
    if (channel === "call" && callTwimlUrl && !/^https?:\/\//i.test(callTwimlUrl)) {
      throw new Error(`Step ${index + 1}: call_twiml_url must start with http:// or https://`);
    }
    const subject = s.subject == null ? "" : String(s.subject);
    if (channel === "email" && !String(subject).trim()) {
      throw new Error(`Step ${index + 1}: subject is required for email`);
    }
    const twilioFromRaw =
      channel === "sms" || channel === "call"
        ? s.twilio_from !== undefined && s.twilio_from !== null
          ? s.twilio_from
          : s.twilioFrom
        : "";
    const twilio_from =
      channel === "sms" || channel === "call" ? normalizeOptionalStepTwilioFrom(twilioFromRaw) : "";
    let email_from = "";
    if (channel === "email") {
      try {
        email_from = normalizeOptionalStepEmailFrom(pickStepEmailFromValue(s), allowedEmailAddresses);
      } catch (e) {
        throw new Error(`Step ${index + 1}: ${e.message}`);
      }
    }
    return {
      step_order: index,
      offset_hours: offset,
      channel,
      subject: channel === "email" ? subject.trim() : "",
      body,
      call_twiml_url: channel === "call" ? callTwimlUrl : "",
      twilio_from,
      email_from
    };
  });
}

function rememberCampaignPickerTags(db, name, tagRules) {
  const tags = [];
  const campaignName = String(name || "").trim();
  if (campaignName) tags.push(campaignName);
  for (const r of Array.isArray(tagRules) ? tagRules : []) {
    const tag = String(r?.tag || "").trim();
    const fn = String(r?.function || "enroll")
      .trim()
      .toLowerCase();
    if (tag && fn !== "none") tags.push(tag);
  }
  return rememberTags(db, tags).catch((err) => {
    console.error("Remember campaign tags:", err);
  });
}

function registerDripRoutes(app, { run, all, get }) {
  /** Clear queue rows for this campaign (by enrollment or step) before replacing steps or deleting campaign. */
  function deleteSendQueueForCampaign(campaignId) {
    return run(
      `DELETE FROM drip_send_queue WHERE enrollment_id IN (SELECT id FROM drip_enrollments WHERE campaign_id = ?)
       OR step_id IN (SELECT id FROM drip_steps WHERE campaign_id = ?)`,
      [campaignId, campaignId]
    );
  }

  app.get("/api/drip/setup-status", (req, res) => {
    res.json({
      sms: { ready: isTwilioSmsReady(), missing: getTwilioSmsMissing() },
      email: { ready: isEmailConfigured(), missing: getSmtpMissing() },
      note: "Drip messages are sent while this server is running (checked every 30s by default). Set DRIP_TICK_MS to change interval."
    });
  });

  async function attachEnrollmentStatsToCampaigns(campaigns) {
    if (!Array.isArray(campaigns) || !campaigns.length) return;
    const rows = await all(
      `SELECT e.campaign_id,
              SUM(CASE
                    WHEN e.status = 'active' AND EXISTS (
                      SELECT 1 FROM drip_send_queue q
                      WHERE q.enrollment_id = e.id AND q.status = 'pending'
                    ) THEN 1
                    ELSE 0
                  END) AS active_contacts,
              SUM(CASE
                    WHEN e.status = 'active'
                     AND NOT EXISTS (
                      SELECT 1 FROM drip_send_queue q
                      WHERE q.enrollment_id = e.id AND q.status = 'pending'
                    )
                     AND EXISTS (
                      SELECT 1 FROM drip_send_queue q
                      WHERE q.enrollment_id = e.id AND q.status IN ('sent', 'skipped', 'failed')
                    ) THEN 1
                    ELSE 0
                  END) AS completed_contacts
       FROM drip_enrollments e
       GROUP BY e.campaign_id`
    );
    const byId = new Map(rows.map((r) => [Number(r.campaign_id), r]));
    for (const c of campaigns) {
      const row = byId.get(Number(c.id)) || {};
      c.enrollment_stats = {
        active: Number(row.active_contacts || 0),
        completed: Number(row.completed_contacts || 0)
      };
    }
  }

  app.get("/api/drip/campaigns", async (req, res) => {
    try {
      const campaigns = await all(
        `SELECT dc.*, cc.name AS category_name
         FROM drip_campaigns dc
         LEFT JOIN campaign_categories cc ON cc.id = dc.category_id
         ORDER BY dc.id DESC`
      );
      for (const c of campaigns) {
        attachTagRules(c);
        c.steps = await all(
          `SELECT id, campaign_id, step_order, offset_hours, channel, subject, body, call_twiml_url, twilio_from, email_from
           FROM drip_steps WHERE campaign_id = ? ORDER BY step_order ASC`,
          [c.id]
        );
      }
      await attachEnrollmentStatsToCampaigns(campaigns);
      res.json(campaigns);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/drip/campaigns", async (req, res) => {
    try {
      const name = req.body && req.body.name != null ? String(req.body.name).trim() : "";
      const description = req.body && req.body.description != null ? String(req.body.description).trim() : "";
      if (!name) return res.status(400).json({ error: "name is required" });
      const scheduleMode = normalizeScheduleMode(req.body && req.body.schedule_mode);
      const startAtInput = Number(req.body && req.body.start_at);
      const endAtInput = Number(req.body && req.body.end_at);
      const startAt = Number.isFinite(startAtInput) ? Math.floor(startAtInput) : null;
      const endAt = Number.isFinite(endAtInput) ? Math.floor(endAtInput) : null;
      if (scheduleMode === "scheduled") {
        if (startAt == null || endAt == null) {
          return res.status(400).json({ error: "Scheduled campaigns require start_at and end_at" });
        }
        if (endAt < startAt) {
          return res.status(400).json({ error: "end_at must be after start_at" });
        }
      }
      const tagRules = normalizeTagRules(req.body && req.body.tag_rules);
      const tagConfigJson = stringifyTagRules(tagRules);
      const twilioFromLine = normalizeCampaignTwilioFrom(req.body);
      let categoryId = null;
      let emailFromStored = null;
      let allowedEmailAddresses = [];
      let steps;
      try {
        allowedEmailAddresses = await loadAllowedFromAddresses();
        emailFromStored = await normalizeCampaignEmailFrom(pickCampaignEmailFromBody(req.body));
        categoryId = await normalizeCampaignCategoryId(get, req.body && req.body.category_id);
        steps = normalizeSteps(req.body && req.body.steps, allowedEmailAddresses);
      } catch (e) {
        return res.status(400).json({ error: e.message || "Invalid campaign settings" });
      }

      await run("BEGIN");
      try {
        const ins = await run(
          `INSERT INTO drip_campaigns (name, description, start_at, end_at, tag_config, schedule_mode, twilio_from, email_from, category_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [name, description, startAt, endAt, tagConfigJson, scheduleMode, twilioFromLine, emailFromStored, categoryId]
        );
        const campaignId = ins.lastID;
        for (const st of steps) {
          await run(
            `INSERT INTO drip_steps (campaign_id, step_order, offset_hours, channel, subject, body, call_twiml_url, twilio_from, email_from)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              campaignId,
              st.step_order,
              st.offset_hours,
              st.channel,
              st.subject,
              st.body,
              st.call_twiml_url,
              st.twilio_from,
              st.email_from
            ]
          );
        }
        await run("COMMIT");
        const created = await get(
          `SELECT dc.*, cc.name AS category_name
           FROM drip_campaigns dc
           LEFT JOIN campaign_categories cc ON cc.id = dc.category_id
           WHERE dc.id = ?`,
          [campaignId]
        );
        attachTagRules(created);
        created.steps = await all(
          `SELECT id, campaign_id, step_order, offset_hours, channel, subject, body, call_twiml_url, twilio_from, email_from
           FROM drip_steps WHERE campaign_id = ? ORDER BY step_order ASC`,
          [campaignId]
        );
        await rememberCampaignPickerTags({ get, run }, name, tagRules);
        res.status(201).json(created);
      } catch (e) {
        await run("ROLLBACK");
        throw e;
      }
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });

  app.put("/api/drip/campaigns/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (!Number.isFinite(id) || id < 1) return res.status(400).json({ error: "Invalid id" });
      const existing = await get(`SELECT * FROM drip_campaigns WHERE id = ?`, [id]);
      if (!existing) return res.status(404).json({ error: "Campaign not found" });

      const name = req.body && req.body.name != null ? String(req.body.name).trim() : "";
      const descriptionRaw = req.body && req.body.description != null ? String(req.body.description).trim() : "";
      const description = descriptionRaw || name || String(existing.description || "").trim();
      if (!name) return res.status(400).json({ error: "name is required" });
      const scheduleMode = normalizeScheduleMode(req.body && req.body.schedule_mode);
      const startAtInput = Number(req.body && req.body.start_at);
      const endAtInput = Number(req.body && req.body.end_at);
      const startAt = Number.isFinite(startAtInput) ? Math.floor(startAtInput) : null;
      const endAt = Number.isFinite(endAtInput) ? Math.floor(endAtInput) : null;
      if (scheduleMode === "scheduled") {
        if (startAt == null || endAt == null) {
          return res.status(400).json({ error: "Scheduled campaigns require start_at and end_at" });
        }
        if (endAt < startAt) {
          return res.status(400).json({ error: "end_at must be after start_at" });
        }
      }
      const tagRules = normalizeTagRules(req.body && req.body.tag_rules);
      const tagConfigJson = stringifyTagRules(tagRules);
      const twilioFromLine = normalizeCampaignTwilioFrom(req.body);
      let categoryId = null;
      let emailFromStored = null;
      let allowedEmailAddresses = [];
      let steps;
      try {
        allowedEmailAddresses = await loadAllowedFromAddresses();
        emailFromStored = await normalizeCampaignEmailFrom(pickCampaignEmailFromBody(req.body));
        categoryId = await normalizeCampaignCategoryId(get, req.body && req.body.category_id);
        steps = normalizeSteps(req.body && req.body.steps, allowedEmailAddresses);
      } catch (e) {
        return res.status(400).json({ error: e.message || "Invalid campaign settings" });
      }

      await run("BEGIN");
      try {
        await run(
          `UPDATE drip_campaigns SET name = ?, description = ?, start_at = ?, end_at = ?, tag_config = ?, schedule_mode = ?, twilio_from = ?, email_from = ?, category_id = ? WHERE id = ?`,
          [name, description, startAt, endAt, tagConfigJson, scheduleMode, twilioFromLine, emailFromStored, categoryId, id]
        );
        const finishedSteps = await all(
          `SELECT q.enrollment_id, s.step_order
           FROM drip_send_queue q
           INNER JOIN drip_steps s ON s.id = q.step_id
           WHERE s.campaign_id = ? AND q.status IN ('sent', 'skipped')`,
          [id]
        );
        const completedEnrollmentStepOrders = buildCompletedEnrollmentStepOrders(finishedSteps);
        await deleteSendQueueForCampaign(id);
        await run(`DELETE FROM drip_steps WHERE campaign_id = ?`, [id]);
        for (const st of steps) {
          await run(
            `INSERT INTO drip_steps (campaign_id, step_order, offset_hours, channel, subject, body, call_twiml_url, twilio_from, email_from)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              id,
              st.step_order,
              st.offset_hours,
              st.channel,
              st.subject,
              st.body,
              st.call_twiml_url,
              st.twilio_from,
              st.email_from
            ]
          );
        }
        await rescheduleQueuesAfterCampaignStepRewrite(run, all, id, completedEnrollmentStepOrders);
        await run("COMMIT");
      } catch (e) {
        await run("ROLLBACK");
        throw e;
      }

      const updated = await get(
        `SELECT dc.*, cc.name AS category_name
         FROM drip_campaigns dc
         LEFT JOIN campaign_categories cc ON cc.id = dc.category_id
         WHERE dc.id = ?`,
        [id]
      );
      attachTagRules(updated);
      updated.steps = await all(
        `SELECT id, campaign_id, step_order, offset_hours, channel, subject, body, call_twiml_url, twilio_from, email_from
         FROM drip_steps WHERE campaign_id = ? ORDER BY step_order ASC`,
        [id]
      );
      await rememberCampaignPickerTags({ get, run }, name, tagRules);
      res.json(updated);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/drip/campaigns/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (!Number.isFinite(id)) return res.status(400).json({ error: "Invalid id" });
      await deleteSendQueueForCampaign(id);
      const result = await run(`DELETE FROM drip_campaigns WHERE id = ?`, [id]);
      if (result.changes === 0) return res.status(404).json({ error: "Campaign not found" });
      res.json({ ok: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/drip/categories", async (req, res) => {
    try {
      const rows = await all(`SELECT id, name FROM campaign_categories ORDER BY LOWER(name) ASC, id ASC`);
      res.json(rows);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/drip/categories", async (req, res) => {
    try {
      const name = String((req.body && req.body.name) || "").trim();
      if (!name) return res.status(400).json({ error: "Category name is required" });
      const existing = await get(`SELECT id FROM campaign_categories WHERE LOWER(name) = LOWER(?)`, [name]);
      if (existing) return res.status(409).json({ error: "Category already exists" });
      const ins = await run(`INSERT INTO campaign_categories (name) VALUES (?)`, [name]);
      const row = await get(`SELECT id, name FROM campaign_categories WHERE id = ?`, [ins.lastID]);
      res.status(201).json(row);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });

  app.put("/api/drip/categories/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (!Number.isFinite(id) || id < 1) return res.status(400).json({ error: "Invalid category id" });
      const name = String((req.body && req.body.name) || "").trim();
      if (!name) return res.status(400).json({ error: "Category name is required" });
      const existing = await get(`SELECT id, name FROM campaign_categories WHERE id = ?`, [id]);
      if (!existing) return res.status(404).json({ error: "Category not found" });
      const duplicate = await get(`SELECT id FROM campaign_categories WHERE LOWER(name) = LOWER(?) AND id <> ?`, [name, id]);
      if (duplicate) return res.status(409).json({ error: "Category already exists" });
      await run(`UPDATE campaign_categories SET name = ? WHERE id = ?`, [name, id]);
      const updated = await get(`SELECT id, name FROM campaign_categories WHERE id = ?`, [id]);
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/drip/categories/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (!Number.isFinite(id) || id < 1) return res.status(400).json({ error: "Invalid category id" });
      const existing = await get(`SELECT id, name FROM campaign_categories WHERE id = ?`, [id]);
      if (!existing) return res.status(404).json({ error: "Category not found" });
      await run(`UPDATE drip_campaigns SET category_id = NULL WHERE category_id = ?`, [id]);
      const result = await run(`DELETE FROM campaign_categories WHERE id = ?`, [id]);
      if (!result.changes) return res.status(404).json({ error: "Category not found" });
      res.json({ ok: true, id, name: existing.name });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/drip/enroll", async (req, res) => {
    try {
      const campaignId = Number(req.body && req.body.campaignId);
      const contactId = Number(req.body && req.body.contactId);
      if (!Number.isFinite(campaignId) || !Number.isFinite(contactId)) {
        return res.status(400).json({ error: "campaignId and contactId are required numbers" });
      }

      const campaign = await get(`SELECT * FROM drip_campaigns WHERE id = ?`, [campaignId]);
      if (!campaign) return res.status(404).json({ error: "Campaign not found" });
      const contact = await get(`SELECT * FROM contacts WHERE id = ?`, [contactId]);
      if (!contact) return res.status(404).json({ error: "Contact not found" });

      const result = await enrollContactInCampaign({ run, get, all }, campaignId, contactId);
      if (!result.ok) {
        if (result.reason === "already_active") {
          return res.status(409).json({ error: "Contact is already actively enrolled in this campaign" });
        }
        if (result.reason === "no_steps") {
          return res.status(400).json({ error: "Campaign has no steps" });
        }
        return res.status(400).json({ error: "Could not enroll contact" });
      }
      res.status(201).json({
        enrollmentId: result.enrollmentId,
        campaignId,
        contactId,
        startedAt: result.startedAt,
        scheduledSteps: result.scheduledSteps
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/drip/queue", async (req, res) => {
    try {
      const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 30));
      const rows = await all(
        `SELECT q.id, q.scheduled_at, q.sent_at, q.status, q.error_message,
                s.channel, s.step_order, e.contact_id, e.campaign_id, c.full_name
         FROM drip_send_queue q
         JOIN drip_steps s ON s.id = q.step_id
         JOIN drip_enrollments e ON e.id = q.enrollment_id
         JOIN contacts c ON c.id = e.contact_id
         ORDER BY q.scheduled_at DESC
         LIMIT ?`,
        [limit]
      );
      res.json(rows);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  /** Live dashboard: active drip enrollments and recent automation activity. */
  app.get("/api/drip/automations-dashboard", async (req, res) => {
    try {
      const nowSec = Math.floor(Date.now() / 1000);
      const sevenDaysAgo = nowSec - 7 * 24 * 3600;
      const runningLimit = Math.min(50, Math.max(1, Number(req.query.runningLimit) || 25));
      const pastLimit = Math.min(80, Math.max(1, Number(req.query.pastLimit) || 40));

      const running = await all(
        `SELECT
           e.id AS enrollment_id,
           e.campaign_id,
           dc.name AS campaign_name,
           e.contact_id,
           c.full_name AS contact_name,
           e.started_at,
           (SELECT COUNT(*) FROM drip_send_queue q2 WHERE q2.enrollment_id = e.id AND q2.status = 'pending') AS pending_count,
           (SELECT MIN(q3.scheduled_at) FROM drip_send_queue q3 WHERE q3.enrollment_id = e.id AND q3.status = 'pending') AS next_scheduled_at,
           (SELECT s.channel
              FROM drip_send_queue q4
              JOIN drip_steps s ON s.id = q4.step_id
             WHERE q4.enrollment_id = e.id AND q4.status = 'pending'
             ORDER BY q4.scheduled_at ASC
             LIMIT 1) AS next_channel,
           (SELECT s.step_order
              FROM drip_send_queue q5
              JOIN drip_steps s ON s.id = q5.step_id
             WHERE q5.enrollment_id = e.id AND q5.status = 'pending'
             ORDER BY q5.scheduled_at ASC
             LIMIT 1) AS next_step_order
         FROM drip_enrollments e
         JOIN drip_campaigns dc ON dc.id = e.campaign_id
         JOIN contacts c ON c.id = e.contact_id
         WHERE e.status = 'active'
           AND EXISTS (
             SELECT 1 FROM drip_send_queue q WHERE q.enrollment_id = e.id AND q.status = 'pending'
           )
         ORDER BY next_scheduled_at ASC
         LIMIT ?`,
        [runningLimit]
      );

      const past7d = await all(
        `SELECT q.id AS queue_id, q.scheduled_at, q.sent_at, q.status, q.error_message,
                s.channel, s.step_order,
                e.id AS enrollment_id, e.contact_id, e.campaign_id,
                c.full_name AS contact_name,
                dc.name AS campaign_name
         FROM drip_send_queue q
         JOIN drip_steps s ON s.id = q.step_id
         JOIN drip_enrollments e ON e.id = q.enrollment_id
         JOIN contacts c ON c.id = e.contact_id
         JOIN drip_campaigns dc ON dc.id = e.campaign_id
         WHERE q.status IN ('sent', 'failed', 'skipped')
           AND COALESCE(q.sent_at, q.scheduled_at) >= ?
         ORDER BY COALESCE(q.sent_at, q.scheduled_at) DESC
         LIMIT ?`,
        [sevenDaysAgo, pastLimit]
      );

      const runningCampaignsRow = await get(
        `SELECT COUNT(DISTINCT e.campaign_id) AS n
         FROM drip_enrollments e
         WHERE e.status = 'active'
           AND EXISTS (
             SELECT 1 FROM drip_send_queue q WHERE q.enrollment_id = e.id AND q.status = 'pending'
           )`
      );

      res.json({
        running,
        past7d,
        runningCount: running.length,
        past7dCount: past7d.length,
        runningCampaignCount: Number(runningCampaignsRow?.n || 0),
        since: sevenDaysAgo
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
}

module.exports = { registerDripRoutes };
