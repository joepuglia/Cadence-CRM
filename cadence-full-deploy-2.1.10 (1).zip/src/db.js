const fs = require("fs");
const os = require("os");
const path = require("path");
const { AsyncLocalStorage } = require("async_hooks");
const sqlite3 = require("sqlite3").verbose();

const LEGACY_TENANT_ID = 1;
const tenantContext = new AsyncLocalStorage();
const tenantDbCache = new Map();

function isCloudSyncedPath(filePath) {
  return /onedrive|dropbox|google drive/i.test(String(filePath || ""));
}

function copySqliteSidecars(src, dest) {
  for (const suf of ["-wal", "-shm", "-journal"]) {
    if (fs.existsSync(src + suf)) {
      try {
        fs.copyFileSync(src + suf, dest + suf);
      } catch {
        // ignore sidecar copy errors
      }
    }
  }
}

function resolveDbPath() {
  const explicit = String(process.env.CRM_DB_PATH || "").trim();
  if (explicit) return path.resolve(explicit);

  const repoPath = path.join(__dirname, "..", "crm.sqlite");
  const hosted = String(process.env.NODE_ENV || "").toLowerCase() === "production";
  if (hosted || !isCloudSyncedPath(repoPath)) return repoPath;

  const localDir = path.join(process.env.LOCALAPPDATA || os.homedir(), "CadenceCRM");
  fs.mkdirSync(localDir, { recursive: true });
  const localPath = path.join(localDir, "crm.sqlite");
  if (!fs.existsSync(localPath) && fs.existsSync(repoPath)) {
    fs.copyFileSync(repoPath, localPath);
    copySqliteSidecars(repoPath, localPath);
    console.log(`[db] Copied SQLite off OneDrive to ${localPath}`);
  }
  if (fs.existsSync(localPath)) {
    console.log(`[db] Using local SQLite (OneDrive is slow): ${localPath}`);
    return localPath;
  }
  return repoPath;
}

const dbPath = resolveDbPath();

function applyConnectionPragmas(conn, filePath) {
  // busy_timeout lets reads wait for a lock instead of failing with 0 results.
  conn.run("PRAGMA busy_timeout = 8000");
  conn.run("PRAGMA temp_store = MEMORY");
  conn.run("PRAGMA cache_size = -8000");
  conn.run("PRAGMA foreign_keys = ON");
  const hosted = String(process.env.NODE_ENV || "").toLowerCase() === "production";
  const onCloudFs = isCloudSyncedPath(filePath || dbPath);
  if (!hosted && !onCloudFs) {
    // Local disk: WAL is much faster. Do not use WAL on cPanel/cloud-synced folders.
    conn.run("PRAGMA journal_mode = WAL");
    conn.run("PRAGMA synchronous = NORMAL");
    conn.run("PRAGMA mmap_size = 268435456");
  } else {
    // Classic rollback journal for cPanel / OneDrive compatibility.
    conn.run("PRAGMA journal_mode = DELETE");
    conn.run("PRAGMA synchronous = NORMAL");
  }
}

const db = new sqlite3.Database(dbPath);
applyConnectionPragmas(db, dbPath);

function resolveDb() {
  const ctx = tenantContext.getStore();
  const tenantId = ctx?.tenantId;
  if (tenantId && tenantId !== LEGACY_TENANT_ID) {
    const conn = tenantDbCache.get(tenantId);
    if (!conn) throw new Error(`Tenant database not loaded for tenant ${tenantId}`);
    return conn;
  }
  return db;
}

function runOn(conn, sql, params = []) {
  return new Promise((resolve, reject) => {
    conn.run(sql, params, function onRun(err) {
      if (err) return reject(err);
      return resolve(this);
    });
  });
}

function allOn(conn, sql, params = []) {
  return new Promise((resolve, reject) => {
    conn.all(sql, params, (err, rows) => {
      if (err) return reject(err);
      return resolve(rows);
    });
  });
}

function getOn(conn, sql, params = []) {
  return new Promise((resolve, reject) => {
    conn.get(sql, params, (err, row) => {
      if (err) return reject(err);
      return resolve(row);
    });
  });
}

function run(sql, params = []) {
  return runOn(resolveDb(), sql, params);
}

function all(sql, params = []) {
  return allOn(resolveDb(), sql, params);
}

function get(sql, params = []) {
  return getOn(resolveDb(), sql, params);
}

function platformRun(sql, params = []) {
  return runOn(db, sql, params);
}

function platformAll(sql, params = []) {
  return allOn(db, sql, params);
}

function platformGet(sql, params = []) {
  return getOn(db, sql, params);
}

function withTenantContext(tenantId, fn) {
  return tenantContext.run({ tenantId: Number(tenantId) }, fn);
}

function isTrialTenantContext() {
  const ctx = tenantContext.getStore();
  const tenantId = Number(ctx?.tenantId);
  return Number.isInteger(tenantId) && tenantId > 0 && tenantId !== LEGACY_TENANT_ID;
}

async function ensureContactColumns() {
  const columns = await all(`PRAGMA table_info(contacts)`);
  const existing = new Set(columns.map((c) => c.name));
  const desired = [
    "age",
    "gender",
    "household_size",
    "income",
    "lead_source",
    "communication_type",
    "secondary_phone",
    "last_called",
    "last_emailed",
    "date_of_contact",
    "outcome",
    "date_of_birth",
    "coverages_sold",
    "profession",
    "quote",
    "health_issues",
    "coverage_start_date",
    "policy_renewal",
    "annual_renewal",
    "renewal_interval",
    "bank_routing",
    "bank_account",
    "height",
    "weight",
    "ssn_last4",
    "vcall",
    "insurance_type",
    "upon_approval",
    "commission",
    "home_address",
    "city",
    "state",
    "zip_code",
    "indian",
    "last_sms",
    "last_tagged",
    "follow_up_date",
    "follow_up_time",
    "follow_up_reminder",
    "special_notes",
    "app_id",
    "custom_fields",
    "ai_lead_score",
    "ai_lead_reason",
    "ai_lead_scored_at",
    "do_not_email",
    "outcome_sold_at",
    "household_members",
    "quotes",
    "middle_name",
    "application_submitted_at"
  ];
  for (const column of desired) {
    if (existing.has(column)) continue;
    await run(`ALTER TABLE contacts ADD COLUMN ${column} TEXT`);
  }
  await run(`
    CREATE INDEX IF NOT EXISTS idx_contacts_created_at
    ON contacts (created_at DESC, id DESC)
  `);
  await run(`
    UPDATE contacts
    SET application_submitted_at = updated_at
    WHERE (application_submitted_at IS NULL OR TRIM(COALESCE(application_submitted_at, '')) = '')
      AND datetime(updated_at) >= datetime('2026-10-01')
      AND (
        instr(lower(COALESCE(notes, '')), 'health insurance application') > 0
        OR instr(lower(COALESCE(tags, '')), 'insurance-app') > 0
      )
  `);
  await run(`
    UPDATE contacts
    SET outcome_sold_at = (
      SELECT MAX(ca.created_at)
      FROM contact_activity ca
      WHERE ca.contact_id = contacts.id
        AND LOWER(COALESCE(ca.activity_type, '')) = 'detail_change'
        AND LOWER(TRIM(COALESCE(ca.detail, ''))) LIKE 'outcome:%'
        AND (
          LOWER(TRIM(COALESCE(ca.detail, ''))) LIKE '% -> sold'
          OR LOWER(TRIM(COALESCE(ca.detail, ''))) LIKE '% -> sold %'
          OR LOWER(REPLACE(COALESCE(ca.detail, ''), ' ', '')) LIKE '%->sold'
        )
    )
    WHERE (outcome_sold_at IS NULL OR TRIM(COALESCE(outcome_sold_at, '')) = '')
      AND LOWER(REPLACE(REPLACE(TRIM(COALESCE(outcome, '')), '-', ''), ' ', '')) IN ('sold', 'closedsold')
  `);
  await migratePolicyRenewalFromCustomFields();
}

function slugifyCustomFieldKey(raw) {
  return String(raw || "")
    .toLowerCase()
    .replace(/[\s-]+/g, "_")
    .replace(/[^a-z0-9_]/g, "")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function isPolicyRenewalCustomSlug(raw) {
  const compact = slugifyCustomFieldKey(raw).replace(/_/g, "");
  return /^poli?cyrenewal(date)?$/.test(compact);
}

function normalizePolicyRenewalDateValue(raw) {
  const s = String(raw || "").trim();
  if (!s) return "";
  let m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
  if (m) return `${m[1]}-${m[2]}-${m[3]}`;
  m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(s);
  if (m) {
    return `${m[3]}-${String(Number(m[1])).padStart(2, "0")}-${String(Number(m[2])).padStart(2, "0")}`;
  }
  return s;
}

/** Copy {{policy_renewal}} custom values onto the built-in contact column, then drop the custom field. */
async function migratePolicyRenewalFromCustomFields() {
  const rows = await all(
    `SELECT id, custom_fields, policy_renewal FROM contacts WHERE TRIM(COALESCE(custom_fields, '')) != ''`
  );
  for (const row of rows || []) {
    let parsed;
    try {
      parsed = JSON.parse(String(row.custom_fields || "").trim());
    } catch {
      continue;
    }
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) continue;
    const renewalKeys = Object.keys(parsed).filter((key) => isPolicyRenewalCustomSlug(key));
    if (!renewalKeys.length) continue;
    let nextValue = normalizePolicyRenewalDateValue(row.policy_renewal);
    if (!nextValue) {
      for (const key of renewalKeys) {
        const candidate = normalizePolicyRenewalDateValue(parsed[key]);
        if (candidate) {
          nextValue = candidate;
          break;
        }
      }
    }
    for (const key of renewalKeys) delete parsed[key];
    const nextJson = Object.keys(parsed).length ? JSON.stringify(parsed) : "";
    await run(`UPDATE contacts SET policy_renewal = ?, custom_fields = ? WHERE id = ?`, [
      nextValue,
      nextJson,
      row.id
    ]);
  }
  try {
    const defs = await all(`SELECT id, field_key, label FROM custom_merge_fields`);
    for (const def of defs || []) {
      const key = String(def.field_key || "");
      const label = String(def.label || "");
      if (isPolicyRenewalCustomSlug(key) || /poli?cy\s*renewal/i.test(label) || /poli?cy\s*renewal/i.test(key)) {
        await run(`DELETE FROM custom_merge_fields WHERE id = ?`, [def.id]);
      }
    }
  } catch {
    // custom_merge_fields may not exist on a partial schema; ensureDripSchema creates it first.
  }
}

async function ensureContactActivityColumns() {
  const columns = await all(`PRAGMA table_info(contact_activity)`);
  const existing = new Set(columns.map((c) => c.name));
  if (!existing.has("is_pinned")) {
    await run(`ALTER TABLE contact_activity ADD COLUMN is_pinned INTEGER NOT NULL DEFAULT 0`);
  }
  if (!existing.has("is_starred")) {
    await run(`ALTER TABLE contact_activity ADD COLUMN is_starred INTEGER NOT NULL DEFAULT 0`);
  }
}

async function ensureContactTasksSchema() {
  await run(`
    CREATE TABLE IF NOT EXISTS contact_tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      contact_id INTEGER NOT NULL,
      task_name TEXT NOT NULL,
      action_type TEXT NOT NULL DEFAULT 'Other',
      task_date TEXT NOT NULL DEFAULT '',
      task_time TEXT NOT NULL DEFAULT '',
      condition TEXT NOT NULL DEFAULT 'Yet to Start',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
    )
  `);
  // Reminder dedup: stamped with the YYYY-MM-DD a due-task reminder was sent.
  const taskCols = await all(`PRAGMA table_info(contact_tasks)`);
  if (!(Array.isArray(taskCols) ? taskCols : []).some((c) => c && c.name === "reminder_sent_date")) {
    await run(`ALTER TABLE contact_tasks ADD COLUMN reminder_sent_date TEXT NOT NULL DEFAULT ''`);
  }
}

/** Older DBs had step_id → drip_steps without CASCADE; deletes/replaces steps then violate FK. */
async function migrateDripSendQueueStepCascade() {
  let fkRows;
  try {
    fkRows = await all(`PRAGMA foreign_key_list(drip_send_queue)`);
  } catch {
    return;
  }
  const stepFk = fkRows.find((fk) => fk.from === "step_id");
  if (!stepFk) return;
  const od = String(stepFk.on_delete || "").toUpperCase();
  if (od === "CASCADE") return;

  await run("BEGIN");
  try {
    await run(`
      CREATE TABLE drip_send_queue__migrate (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        enrollment_id INTEGER NOT NULL,
        step_id INTEGER NOT NULL,
        scheduled_at INTEGER NOT NULL,
        sent_at INTEGER,
        status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'sent', 'failed', 'skipped')),
        error_message TEXT,
        FOREIGN KEY (enrollment_id) REFERENCES drip_enrollments(id) ON DELETE CASCADE,
        FOREIGN KEY (step_id) REFERENCES drip_steps(id) ON DELETE CASCADE,
        UNIQUE (enrollment_id, step_id)
      )
    `);
    await run(`
      INSERT INTO drip_send_queue__migrate (id, enrollment_id, step_id, scheduled_at, sent_at, status, error_message)
      SELECT id, enrollment_id, step_id, scheduled_at, sent_at, status, error_message FROM drip_send_queue
    `);
    await run(`DROP TABLE drip_send_queue`);
    await run(`ALTER TABLE drip_send_queue__migrate RENAME TO drip_send_queue`);
    await run("COMMIT");
  } catch (e) {
    try {
      await run("ROLLBACK");
    } catch {
      /* ignore */
    }
    throw e;
  }
}

async function ensureDripSchema() {
  const campaignColumns = await all(`PRAGMA table_info(drip_campaigns)`);
  const campaignExisting = new Set(campaignColumns.map((c) => c.name));
  if (!campaignExisting.has("start_at")) {
    await run(`ALTER TABLE drip_campaigns ADD COLUMN start_at INTEGER`);
  }
  if (!campaignExisting.has("end_at")) {
    await run(`ALTER TABLE drip_campaigns ADD COLUMN end_at INTEGER`);
  }
  if (!campaignExisting.has("tag_config")) {
    await run(`ALTER TABLE drip_campaigns ADD COLUMN tag_config TEXT NOT NULL DEFAULT '[]'`);
  }
  if (!campaignExisting.has("schedule_mode")) {
    await run(`ALTER TABLE drip_campaigns ADD COLUMN schedule_mode TEXT NOT NULL DEFAULT 'scheduled'`);
  }
  if (!campaignExisting.has("twilio_from")) {
    await run(`ALTER TABLE drip_campaigns ADD COLUMN twilio_from TEXT`);
  }
  if (!campaignExisting.has("email_from")) {
    await run(`ALTER TABLE drip_campaigns ADD COLUMN email_from TEXT`);
  }
  if (!campaignExisting.has("category_id")) {
    await run(`ALTER TABLE drip_campaigns ADD COLUMN category_id INTEGER`);
  }
  if (!campaignExisting.has("description")) {
    await run(`ALTER TABLE drip_campaigns ADD COLUMN description TEXT NOT NULL DEFAULT ''`);
  }

  const stepColumns = await all(`PRAGMA table_info(drip_steps)`);
  const stepExisting = new Set(stepColumns.map((c) => c.name));
  if (!stepExisting.has("call_twiml_url")) {
    await run(`ALTER TABLE drip_steps ADD COLUMN call_twiml_url TEXT NOT NULL DEFAULT ''`);
  }
  if (!stepExisting.has("twilio_from")) {
    await run(`ALTER TABLE drip_steps ADD COLUMN twilio_from TEXT NOT NULL DEFAULT ''`);
  }
  if (!stepExisting.has("email_from")) {
    await run(`ALTER TABLE drip_steps ADD COLUMN email_from TEXT NOT NULL DEFAULT ''`);
  }

  await migrateDripSendQueueStepCascade();
  await run(`
    CREATE INDEX IF NOT EXISTS idx_drip_send_queue_status_sent_at
    ON drip_send_queue (status, sent_at DESC)
  `);
}

/** Older API saved missing `function` as explicit "none" in tag_config — fix stored JSON. */
async function migrateMisstoredTagRuleFunctionNone() {
  try {
    await run(`
      UPDATE drip_campaigns SET tag_config =
        REPLACE(REPLACE(tag_config, '"function":"none"', '"function":"enroll'), '"function": "none"', '"function": "enroll')
      WHERE tag_config LIKE '%"function":"none"%' OR tag_config LIKE '%"function": "none"%'
    `);
  } catch (e) {
    console.error("migrateMisstoredTagRuleFunctionNone:", e);
  }
}

/** Legacy DBs default schedule_mode to "scheduled", so tag enroll rules were never run. Promote to on_tag. */
async function migrateTagEnrollCampaignsFromScheduled() {
  const { campaignHasEnrollRule } = require("./dripEnrollment");
  let rows;
  try {
    rows = await all(`SELECT id, tag_config FROM drip_campaigns WHERE schedule_mode = 'scheduled'`);
  } catch {
    return;
  }
  for (const row of rows) {
    if (!campaignHasEnrollRule(row.tag_config)) continue;
    await run(`UPDATE drip_campaigns SET schedule_mode = 'on_tag', start_at = NULL, end_at = NULL WHERE id = ?`, [
      row.id
    ]);
  }
}

async function ensureCampaignCategoriesSchema() {
  await run(`
    CREATE TABLE IF NOT EXISTS campaign_categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS twilio_from_numbers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      phone_number TEXT NOT NULL UNIQUE,
      label TEXT NOT NULL DEFAULT '',
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS twilio_hidden_lines (
      line_key TEXT PRIMARY KEY,
      hidden_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS twilio_line_labels (
      line_key TEXT PRIMARY KEY,
      label TEXT NOT NULL DEFAULT ''
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS twilio_runtime_config (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL DEFAULT ''
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS crm_app_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL DEFAULT ''
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS email_from_addresses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email_address TEXT NOT NULL UNIQUE COLLATE NOCASE,
      label TEXT NOT NULL DEFAULT '',
      smtp_host TEXT NOT NULL DEFAULT '',
      smtp_port INTEGER,
      smtp_secure INTEGER NOT NULL DEFAULT 0,
      smtp_user TEXT NOT NULL DEFAULT '',
      smtp_pass TEXT NOT NULL DEFAULT '',
      reply_to TEXT NOT NULL DEFAULT '',
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);

  /**
   * User-defined merge fields available to emails / drip steps. Stored as a
   * (slug -> value) pair plus an optional human-readable label.
   * Reserved slugs (e.g. first_name, good_through, ...) are filtered out at
   * the API layer so custom fields can never shadow a built-in.
   */
  await run(`
    CREATE TABLE IF NOT EXISTS custom_merge_fields (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      field_key TEXT NOT NULL UNIQUE COLLATE NOCASE,
      field_value TEXT NOT NULL DEFAULT '',
      label TEXT NOT NULL DEFAULT '',
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER)),
      updated_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
  const cmfCols = await all(`PRAGMA table_info(custom_merge_fields)`);
  const cmfExisting = new Set((Array.isArray(cmfCols) ? cmfCols : []).map((c) => c.name));
  if (!cmfExisting.has("field_scope")) {
    await run(`ALTER TABLE custom_merge_fields ADD COLUMN field_scope TEXT NOT NULL DEFAULT 'shared'`);
  }

  const efaCols = await all(`PRAGMA table_info(email_from_addresses)`);
  const efaExisting = new Set(efaCols.map((c) => c.name));
  if (!efaExisting.has("smtp_host")) {
    await run(`ALTER TABLE email_from_addresses ADD COLUMN smtp_host TEXT NOT NULL DEFAULT ''`);
  }
  if (!efaExisting.has("smtp_port")) {
    await run(`ALTER TABLE email_from_addresses ADD COLUMN smtp_port INTEGER`);
  }
  if (!efaExisting.has("smtp_secure")) {
    await run(`ALTER TABLE email_from_addresses ADD COLUMN smtp_secure INTEGER NOT NULL DEFAULT 0`);
  }
  if (!efaExisting.has("smtp_user")) {
    await run(`ALTER TABLE email_from_addresses ADD COLUMN smtp_user TEXT NOT NULL DEFAULT ''`);
  }
  if (!efaExisting.has("smtp_pass")) {
    await run(`ALTER TABLE email_from_addresses ADD COLUMN smtp_pass TEXT NOT NULL DEFAULT ''`);
  }
  if (!efaExisting.has("reply_to")) {
    await run(`ALTER TABLE email_from_addresses ADD COLUMN reply_to TEXT NOT NULL DEFAULT ''`);
  }
}

async function ensureDocumentsSchema() {
  await run(`
    CREATE TABLE IF NOT EXISTS documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      file_name TEXT NOT NULL,
      mime_type TEXT NOT NULL DEFAULT 'application/octet-stream',
      size_bytes INTEGER NOT NULL DEFAULT 0,
      category_name TEXT NOT NULL DEFAULT 'Uncategorized',
      storage_path TEXT NOT NULL,
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
  const cols = await all(`PRAGMA table_info(documents)`);
  const existing = new Set(cols.map((c) => c.name));
  if (!existing.has("category_name")) {
    await run(`ALTER TABLE documents ADD COLUMN category_name TEXT NOT NULL DEFAULT 'Uncategorized'`);
  }
}

async function ensureEmailTemplatesSchema() {
  await run(`
    CREATE TABLE IF NOT EXISTS email_templates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      subject TEXT NOT NULL DEFAULT '',
      body TEXT NOT NULL DEFAULT '',
      category_id INTEGER,
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
  const cols = await all(`PRAGMA table_info(email_templates)`);
  const existing = new Set(cols.map((c) => c.name));
  if (!existing.has("category_id")) {
    await run(`ALTER TABLE email_templates ADD COLUMN category_id INTEGER`);
  }
}

/**
 * One-time seed of the "AI Sales Assistant Follow-Up" marketing template
 * (linked banner image + CTA button). Inserts exactly once on the main DB,
 * guarded by a crm_app_settings flag so it never duplicates and never
 * resurrects if the user later edits or deletes it.
 */
async function ensureAiFollowupTemplateSeed() {
  const flagKey = "seeded_ai_followup_template_v1";
  const flag = await get(`SELECT value FROM crm_app_settings WHERE key = ?`, [flagKey]);
  if (flag) return;
  const subject = "Did this get buried, {{first_name}}?";
  const body = [
    '<div style="font-family:Arial,Helvetica,sans-serif;font-size:16px;line-height:1.6;color:#1f2937;">',
    '<p>Hi {{first_name}},</p>',
    '<p>I sent a note last week about Cadence and wanted to follow up &mdash; I know how fast an inbox fills up during the day.</p>',
    '<p style="text-align:center;margin:24px 0;"><a href="https://crmcadence.com/welcome.html" target="_blank" style="text-decoration:none;"><img src="https://crmcadence.com/cadence-ad-1200x630.png" alt="Cadence CRM - meet your AI sales assistant. Built for health insurance agents. Free for 14 days." width="600" style="display:block;width:100%;max-width:600px;height:auto;border:0;border-radius:12px;margin:0 auto;" /></a></p>',
    '<p>Quick recap: Cadence is the only CRM built <em>exclusively</em> for health insurance agents, designed to do the busywork so you can focus on selling. Your AI assistant writes the emails, texts, and call scripts, coaches you through objections, and your automations keep every client warm while you&rsquo;re on the phone.</p>',
    '<p>The best part &mdash; you can try all of it <strong>free for 14 days. No credit card to start.</strong></p>',
    '<p style="text-align:center;margin:28px 0;"><a href="https://crmcadence.com/welcome.html" target="_blank" style="background:#4f46e5;color:#ffffff;text-decoration:none;font-weight:bold;font-size:16px;padding:14px 28px;border-radius:8px;display:inline-block;">Start free for 14 days &rarr;</a></p>',
    '<p>If getting your system in place has been on your list, now&rsquo;s the ideal time &mdash; well before AEP and open enrollment heat up this fall.</p>',
    '<p>Talk soon,<br />The Cadence CRM Team<br /><a href="https://crmcadence.com/welcome.html" style="color:#4f46e5;">crmcadence.com</a></p>',
    '</div>'
  ].join("");
  await run(
    `INSERT INTO email_templates (name, subject, body) VALUES (?, ?, ?)`,
    ["AI Sales Assistant Follow-Up", subject, body]
  );
  await run(`INSERT OR REPLACE INTO crm_app_settings (key, value) VALUES (?, '1')`, [flagKey]);
}

async function ensureEmailTemplateCategoriesSchema() {
  await run(`
    CREATE TABLE IF NOT EXISTS email_template_categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
}

async function ensureCallRecordingsSchema() {
  await run(`
    CREATE TABLE IF NOT EXISTS call_recordings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      call_sid TEXT NOT NULL UNIQUE,
      recording_sid TEXT NOT NULL DEFAULT '',
      contact_id INTEGER,
      phone TEXT NOT NULL DEFAULT '',
      recording_url TEXT NOT NULL DEFAULT '',
      duration_seconds INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER)),
      updated_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
  await run(`
    CREATE INDEX IF NOT EXISTS idx_call_recordings_contact
    ON call_recordings (contact_id)
  `);
  const columns = await all(`PRAGMA table_info(call_recordings)`);
  const existing = new Set(columns.map((c) => c.name));
  for (const column of ["transcript_text", "transcript_status", "transcript_error", "transcribed_at"]) {
    if (!existing.has(column)) {
      await run(`ALTER TABLE call_recordings ADD COLUMN ${column} TEXT NOT NULL DEFAULT ''`);
    }
  }
}

async function ensureWebinarsSchema() {
  await run(`
    CREATE TABLE IF NOT EXISTS webinars (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      host_name TEXT NOT NULL DEFAULT '',
      starts_at INTEGER NOT NULL DEFAULT 0,
      duration_minutes INTEGER NOT NULL DEFAULT 60,
      zoom_meeting_id TEXT NOT NULL DEFAULT '',
      zoom_passcode TEXT NOT NULL DEFAULT '',
      zoom_join_url TEXT NOT NULL DEFAULT '',
      zoom_start_url TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'scheduled',
      is_published INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER)),
      updated_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
  await run(`
    CREATE TABLE IF NOT EXISTS webinar_registrations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      webinar_id INTEGER NOT NULL,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL DEFAULT '',
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER)),
      FOREIGN KEY (webinar_id) REFERENCES webinars(id) ON DELETE CASCADE
    )
  `);
  await run(`
    CREATE INDEX IF NOT EXISTS idx_webinar_registrations_webinar
    ON webinar_registrations (webinar_id)
  `);
}

async function ensureLandingPagesSchema() {
  await run(`
    CREATE TABLE IF NOT EXISTS landing_pages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      website_url TEXT NOT NULL DEFAULT '',
      landing_page_url TEXT NOT NULL DEFAULT '',
      platform TEXT NOT NULL DEFAULT '',
      notes TEXT NOT NULL DEFAULT '',
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER)),
      updated_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
}

async function ensureVideosSchema() {
  await run(`
    CREATE TABLE IF NOT EXISTS videos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      source_type TEXT NOT NULL CHECK (source_type IN ('url', 'file')),
      video_url TEXT NOT NULL DEFAULT '',
      file_name TEXT NOT NULL DEFAULT '',
      mime_type TEXT NOT NULL DEFAULT '',
      storage_path TEXT NOT NULL DEFAULT '',
      size_bytes INTEGER NOT NULL DEFAULT 0,
      notes TEXT NOT NULL DEFAULT '',
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
}

async function ensureFollowUpReminderSchema() {
  await run(`
    CREATE TABLE IF NOT EXISTS follow_up_reminder_sent (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      contact_id INTEGER NOT NULL,
      channel TEXT NOT NULL,
      reminder_kind TEXT NOT NULL,
      follow_up_date TEXT NOT NULL,
      sent_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER)),
      UNIQUE (contact_id, channel, reminder_kind, follow_up_date),
      FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
    )
  `);
  await run(`
    CREATE TABLE IF NOT EXISTS push_subscriptions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      endpoint TEXT NOT NULL UNIQUE,
      subscription_json TEXT NOT NULL,
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
  await run(`
    CREATE TABLE IF NOT EXISTS sms_usage (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sent_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER)),
      day TEXT NOT NULL,
      month TEXT NOT NULL
    )
  `);
}

async function ensureSavedFormsSchema() {
  await run(`
    CREATE TABLE IF NOT EXISTS saved_forms (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      source_type TEXT NOT NULL CHECK (source_type IN ('url', 'file')),
      form_url TEXT NOT NULL DEFAULT '',
      file_name TEXT NOT NULL DEFAULT '',
      mime_type TEXT NOT NULL DEFAULT '',
      storage_path TEXT NOT NULL DEFAULT '',
      size_bytes INTEGER NOT NULL DEFAULT 0,
      notes TEXT NOT NULL DEFAULT '',
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
}

async function ensureEmailOpenTrackingSchema() {
  await run(`
    CREATE TABLE IF NOT EXISTS email_open_tracking (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      open_token TEXT NOT NULL UNIQUE,
      contact_ids TEXT NOT NULL DEFAULT '',
      to_emails TEXT NOT NULL DEFAULT '',
      subject TEXT NOT NULL DEFAULT '',
      tag TEXT NOT NULL DEFAULT '',
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER)),
      opened_at INTEGER
    )
  `);
  // Migration for existing installs: add the tag column if missing. This gives
  // the bulk "send once per tag" skip a DURABLE, repair-proof per-tag record of
  // who was emailed (the send-queue history can be cleared by a repair).
  await run(`ALTER TABLE email_open_tracking ADD COLUMN tag TEXT NOT NULL DEFAULT ''`).catch(() => {});
  // Contact history scans opens by opened_at (recent-window sync + newest-first
  // annotation); index it so those queries don't full-scan a growing table.
  await run(`CREATE INDEX IF NOT EXISTS idx_email_open_tracking_opened_at ON email_open_tracking (opened_at)`);
  await run(`CREATE INDEX IF NOT EXISTS idx_email_open_tracking_created_at ON email_open_tracking (created_at)`);
  await run(`CREATE INDEX IF NOT EXISTS idx_email_open_tracking_tag ON email_open_tracking (tag)`);
}

async function ensureEmailClickTrackingSchema() {
  await run(`
    CREATE TABLE IF NOT EXISTS email_click_tracking (
      click_token TEXT NOT NULL PRIMARY KEY,
      open_token TEXT NOT NULL DEFAULT '',
      contact_ids TEXT NOT NULL DEFAULT '',
      to_emails TEXT NOT NULL DEFAULT '',
      subject TEXT NOT NULL DEFAULT '',
      link_url TEXT NOT NULL DEFAULT '',
      tag TEXT NOT NULL DEFAULT '',
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
  await run(`
    CREATE TABLE IF NOT EXISTS email_click_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      contact_id INTEGER NOT NULL DEFAULT 0,
      to_email TEXT NOT NULL DEFAULT '',
      subject TEXT NOT NULL DEFAULT '',
      link_url TEXT NOT NULL DEFAULT '',
      open_token TEXT NOT NULL DEFAULT '',
      tag TEXT NOT NULL DEFAULT '',
      clicked_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
  await run(
    `CREATE INDEX IF NOT EXISTS idx_email_click_events_clicked_at ON email_click_events (clicked_at)`
  );
}

/** Throttled "send to tag" campaigns: one row per queued recipient. Subject and
 *  body are stored UNMERGED so {{first_name}} etc. personalize at send time. */
async function ensureEmailBulkQueueSchema() {
  await run(`
    CREATE TABLE IF NOT EXISTS email_bulk_queue (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      batch_id TEXT NOT NULL,
      tag TEXT NOT NULL DEFAULT '',
      contact_id INTEGER NOT NULL DEFAULT 0,
      to_email TEXT NOT NULL,
      from_email TEXT NOT NULL DEFAULT '',
      subject TEXT NOT NULL DEFAULT '',
      body_html TEXT NOT NULL DEFAULT '',
      body_text TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'pending',
      error TEXT NOT NULL DEFAULT '',
      scheduled_at INTEGER NOT NULL,
      sent_at INTEGER,
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
  await run(
    `CREATE INDEX IF NOT EXISTS idx_email_bulk_queue_due ON email_bulk_queue (status, scheduled_at)`
  );
  // The email body/subject/from are stored ONCE here per campaign (keyed by
  // batch_id) instead of being copied into every recipient's queue row — that
  // per-recipient duplication is what ballooned the database to 20+ GB.
  await run(`
    CREATE TABLE IF NOT EXISTS email_bulk_batch (
      batch_id TEXT PRIMARY KEY,
      tag TEXT NOT NULL DEFAULT '',
      from_email TEXT NOT NULL DEFAULT '',
      subject TEXT NOT NULL DEFAULT '',
      body_html TEXT NOT NULL DEFAULT '',
      body_text TEXT NOT NULL DEFAULT '',
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
  // The batch_id index is built in the background after startup (server.js queue
  // maintenance) so a large existing queue can never slow down boot.
}

async function ensureCalendarSchema() {
  await run(`
    CREATE TABLE IF NOT EXISTS calendar_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      event_date TEXT NOT NULL,
      event_time TEXT NOT NULL DEFAULT '',
      end_date TEXT NOT NULL DEFAULT '',
      end_time TEXT NOT NULL DEFAULT '',
      all_day INTEGER NOT NULL DEFAULT 0,
      location TEXT NOT NULL DEFAULT '',
      color TEXT NOT NULL DEFAULT '#2563eb',
      contact_id INTEGER,
      google_event_id TEXT,
      google_calendar_id TEXT,
      google_synced_at INTEGER,
      origin TEXT NOT NULL DEFAULT 'manual',
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER)),
      updated_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER)),
      FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE SET NULL
    )
  `);
  await run(
    `CREATE INDEX IF NOT EXISTS idx_calendar_events_event_date ON calendar_events (event_date)`
  );
  await run(
    `CREATE UNIQUE INDEX IF NOT EXISTS idx_calendar_events_google_event_id
       ON calendar_events (google_event_id)
       WHERE google_event_id IS NOT NULL AND google_event_id != ''`
  );
  let calendarCols;
  try {
    calendarCols = await all(`PRAGMA table_info(calendar_events)`);
  } catch {
    calendarCols = [];
  }
  if (!calendarCols.some((c) => c.name === "recurrence")) {
    await run(`ALTER TABLE calendar_events ADD COLUMN recurrence TEXT NOT NULL DEFAULT ''`);
  }
}

async function ensureSalesInquiriesSchema() {
  await run(`
    CREATE TABLE IF NOT EXISTS sales_inquiries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL DEFAULT '',
      country TEXT NOT NULL DEFAULT '',
      company_name TEXT NOT NULL DEFAULT '',
      company_size TEXT NOT NULL DEFAULT '',
      hear_about TEXT NOT NULL DEFAULT '',
      message TEXT NOT NULL DEFAULT '',
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
  await run(`
    CREATE INDEX IF NOT EXISTS idx_sales_inquiries_email
    ON sales_inquiries (email)
  `);
}

async function ensureSubscriptionSignupsSchema() {
  await run(`
    CREATE TABLE IF NOT EXISTS subscription_signups (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      first_name TEXT NOT NULL,
      last_name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL DEFAULT '',
      agency_name TEXT NOT NULL DEFAULT '',
      resident_state TEXT NOT NULL DEFAULT '',
      licensed_state TEXT NOT NULL DEFAULT '',
      license_number TEXT NOT NULL DEFAULT '',
      plan TEXT NOT NULL DEFAULT 'pro',
      trial_ends_at INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'trial_pending',
      tenant_id INTEGER,
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER)),
      UNIQUE (email)
    )
  `);
  const cols = await all(`PRAGMA table_info(subscription_signups)`);
  const names = new Set((cols || []).map((c) => c.name));
  if (!names.has("tenant_id")) {
    await run(`ALTER TABLE subscription_signups ADD COLUMN tenant_id INTEGER`);
  }
  if (!names.has("resident_state")) {
    await run(`ALTER TABLE subscription_signups ADD COLUMN resident_state TEXT NOT NULL DEFAULT ''`);
  }
  if (!names.has("terms_accepted_at")) {
    await run(`ALTER TABLE subscription_signups ADD COLUMN terms_accepted_at INTEGER`);
  }
  if (!names.has("terms_version")) {
    await run(`ALTER TABLE subscription_signups ADD COLUMN terms_version TEXT NOT NULL DEFAULT ''`);
  }
  await run(`
    CREATE INDEX IF NOT EXISTS idx_subscription_signups_email
    ON subscription_signups (email)
  `);
  await run(`
    CREATE TABLE IF NOT EXISTS trial_onboarding_sent (
      id       INTEGER PRIMARY KEY AUTOINCREMENT,
      email    TEXT    NOT NULL,
      step     TEXT    NOT NULL,
      sent_at  INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER)),
      UNIQUE (email, step)
    )
  `);
  await run(`
    CREATE TABLE IF NOT EXISTS lead_capture_config (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      tenant_id    INTEGER NOT NULL UNIQUE,
      form_key     TEXT    NOT NULL UNIQUE,
      notify_email TEXT    NOT NULL DEFAULT '',
      created_at   INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
}

async function ensureTenantsSchema() {
  await platformRun(`
    CREATE TABLE IF NOT EXISTS tenants (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      slug TEXT NOT NULL UNIQUE,
      agency_name TEXT NOT NULL DEFAULT '',
      owner_email TEXT NOT NULL DEFAULT '',
      owner_first_name TEXT NOT NULL DEFAULT '',
      owner_last_name TEXT NOT NULL DEFAULT '',
      owner_phone TEXT NOT NULL DEFAULT '',
      plan TEXT NOT NULL DEFAULT 'pro',
      status TEXT NOT NULL DEFAULT 'trial',
      trial_ends_at INTEGER NOT NULL DEFAULT 0,
      stripe_customer_id TEXT NOT NULL DEFAULT '',
      stripe_subscription_id TEXT NOT NULL DEFAULT '',
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER)),
      updated_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
  await platformRun(`
    CREATE TABLE IF NOT EXISTS tenant_users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      tenant_id INTEGER NOT NULL,
      email TEXT NOT NULL,
      password_hash TEXT NOT NULL DEFAULT '',
      role TEXT NOT NULL DEFAULT 'owner',
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER)),
      updated_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER)),
      FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
      UNIQUE (email)
    )
  `);
  await platformRun(`
    CREATE INDEX IF NOT EXISTS idx_tenant_users_tenant
    ON tenant_users (tenant_id)
  `);

  const legacy = await platformGet(`SELECT id FROM tenants WHERE id = ?`, [LEGACY_TENANT_ID]);
  if (!legacy) {
    const nowSec = Math.floor(Date.now() / 1000);
    await platformRun(
      `INSERT INTO tenants (
         id, slug, agency_name, owner_email, owner_first_name, owner_last_name,
         plan, status, trial_ends_at, created_at, updated_at
       ) VALUES (?, 'primary', 'Primary workspace', '', '', '', 'pro', 'active', ?, ?, ?)`,
      [LEGACY_TENANT_ID, Date.now() + 100 * 365 * 24 * 60 * 60 * 1000, nowSec, nowSec]
    );
  }
}

async function ensureGoogleOAuthSchema() {
  await run(`
    CREATE TABLE IF NOT EXISTS google_oauth_tokens (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      access_token TEXT NOT NULL DEFAULT '',
      refresh_token TEXT NOT NULL DEFAULT '',
      expiry INTEGER NOT NULL DEFAULT 0,
      token_type TEXT NOT NULL DEFAULT 'Bearer',
      scope TEXT NOT NULL DEFAULT '',
      account_email TEXT NOT NULL DEFAULT '',
      calendar_id TEXT NOT NULL DEFAULT 'primary',
      last_sync_at INTEGER NOT NULL DEFAULT 0,
      updated_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
}

async function ensureSocialWorkspaceSchema() {
  await run(`
    CREATE TABLE IF NOT EXISTS social_media_assets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      file_name TEXT NOT NULL DEFAULT '',
      mime_type TEXT NOT NULL DEFAULT '',
      storage_path TEXT NOT NULL DEFAULT '',
      size_bytes INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
  await run(`
    CREATE TABLE IF NOT EXISTS social_posts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      content TEXT NOT NULL DEFAULT '',
      media_asset_id INTEGER,
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER)),
      FOREIGN KEY (media_asset_id) REFERENCES social_media_assets(id) ON DELETE SET NULL
    )
  `);
  await run(`
    CREATE TABLE IF NOT EXISTS social_post_targets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      post_id INTEGER NOT NULL,
      target TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'sent', 'failed')),
      response_text TEXT NOT NULL DEFAULT '',
      posted_at INTEGER,
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER)),
      FOREIGN KEY (post_id) REFERENCES social_posts(id) ON DELETE CASCADE
    )
  `);
  await run(`
    CREATE INDEX IF NOT EXISTS idx_social_posts_created_at
    ON social_posts (created_at DESC, id DESC)
  `);
  await run(`
    CREATE INDEX IF NOT EXISTS idx_social_post_targets_post
    ON social_post_targets (post_id, target)
  `);
  try {
    await run(`ALTER TABLE social_posts ADD COLUMN scheduled_at INTEGER`);
  } catch {
    /* column may exist */
  }
  try {
    await run(`ALTER TABLE social_posts ADD COLUMN publish_status TEXT NOT NULL DEFAULT 'published'`);
  } catch {
    /* column may exist */
  }
  try {
    await run(`ALTER TABLE social_posts ADD COLUMN targets_json TEXT NOT NULL DEFAULT '[]'`);
  } catch {
    /* column may exist */
  }
  try {
    await run(`ALTER TABLE social_posts ADD COLUMN video_id INTEGER REFERENCES videos(id) ON DELETE SET NULL`);
  } catch {
    /* column may exist */
  }
  try {
    await run(`ALTER TABLE social_media_assets ADD COLUMN category_name TEXT NOT NULL DEFAULT 'Uncategorized'`);
  } catch {
    /* column may exist */
  }
  await run(`
    CREATE INDEX IF NOT EXISTS idx_social_posts_scheduled
    ON social_posts (publish_status, scheduled_at)
  `);
}

async function openTenantDatabase(tenantId) {
  const id = Number(tenantId);
  if (!Number.isInteger(id) || id <= 0) throw new Error("Invalid tenant id");
  if (id === LEGACY_TENANT_ID) return db;
  if (tenantDbCache.has(id)) return tenantDbCache.get(id);

  const dir = path.join(__dirname, "..", "tenant-data", String(id));
  fs.mkdirSync(dir, { recursive: true });
  const tenantDbPath = path.join(dir, "crm.sqlite");
  const conn = new sqlite3.Database(tenantDbPath);
  applyConnectionPragmas(conn, tenantDbPath);
  tenantDbCache.set(id, conn);

  await withTenantContext(id, async () => {
    await initializeCrmDatabase({ seed: false, includePlatformTables: false });
  });
  return conn;
}

async function initializeCrmDatabase({ seed = true, includePlatformTables = true } = {}) {
  await run(`
    CREATE TABLE IF NOT EXISTS contacts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      full_name TEXT NOT NULL,
      email TEXT,
      phone TEXT,
      status TEXT DEFAULT 'NEW',
      tags TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Recycle bin: contacts deleted by mistake are snapshotted here and kept 30 days.
  await run(`
    CREATE TABLE IF NOT EXISTS deleted_contacts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      original_id INTEGER,
      full_name TEXT,
      email TEXT,
      deleted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      payload TEXT
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS drip_campaigns (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      start_at INTEGER,
      end_at INTEGER,
      tag_config TEXT NOT NULL DEFAULT '[]',
      schedule_mode TEXT NOT NULL DEFAULT 'scheduled',
      twilio_from TEXT,
      email_from TEXT,
      created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS drip_steps (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      campaign_id INTEGER NOT NULL,
      step_order INTEGER NOT NULL,
      offset_hours REAL NOT NULL DEFAULT 0,
      channel TEXT NOT NULL CHECK (channel IN ('sms', 'email', 'call')),
      subject TEXT NOT NULL DEFAULT '',
      body TEXT NOT NULL,
      call_twiml_url TEXT NOT NULL DEFAULT '',
      twilio_from TEXT NOT NULL DEFAULT '',
      email_from TEXT NOT NULL DEFAULT '',
      FOREIGN KEY (campaign_id) REFERENCES drip_campaigns(id) ON DELETE CASCADE
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS drip_enrollments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      campaign_id INTEGER NOT NULL,
      contact_id INTEGER NOT NULL,
      started_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER)),
      status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'cancelled')),
      FOREIGN KEY (campaign_id) REFERENCES drip_campaigns(id) ON DELETE CASCADE,
      FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS drip_send_queue (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      enrollment_id INTEGER NOT NULL,
      step_id INTEGER NOT NULL,
      scheduled_at INTEGER NOT NULL,
      sent_at INTEGER,
      status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'sent', 'failed', 'skipped')),
      error_message TEXT,
      FOREIGN KEY (enrollment_id) REFERENCES drip_enrollments(id) ON DELETE CASCADE,
      FOREIGN KEY (step_id) REFERENCES drip_steps(id) ON DELETE CASCADE,
      UNIQUE (enrollment_id, step_id)
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS contact_activity (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      contact_id INTEGER NOT NULL,
      activity_type TEXT NOT NULL,
      detail TEXT DEFAULT '',
      is_pinned INTEGER NOT NULL DEFAULT 0,
      is_starred INTEGER NOT NULL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
    )
  `);

  // Speed up contact history cards query (pinned-first, newest-first).
  await run(`
    CREATE INDEX IF NOT EXISTS idx_contact_activity_history
    ON contact_activity (contact_id, is_pinned DESC, created_at DESC, id DESC)
  `);
  await run(`
    CREATE INDEX IF NOT EXISTS idx_contact_activity_created_at
    ON contact_activity (created_at DESC, id DESC)
  `);
  await run(`
    CREATE INDEX IF NOT EXISTS idx_contact_activity_type_created_at
    ON contact_activity (activity_type, created_at DESC, id DESC)
  `);

  await ensureContactColumns();
  await ensureContactActivityColumns();
  await ensureContactTasksSchema();
  await ensureDripSchema();
  await migratePolicyRenewalFromCustomFields();
  await migrateMisstoredTagRuleFunctionNone();
  await migrateTagEnrollCampaignsFromScheduled();
  await ensureCampaignCategoriesSchema();
  await ensureDocumentsSchema();
  await ensureEmailTemplateCategoriesSchema();
  await ensureEmailTemplatesSchema();
  await ensureLandingPagesSchema();
  await ensureCallRecordingsSchema();
  await ensureWebinarsSchema();
  await ensureVideosSchema();
  await ensureSavedFormsSchema();
  await ensureFollowUpReminderSchema();
  await ensureEmailOpenTrackingSchema();
  await ensureEmailClickTrackingSchema();
  await ensureEmailBulkQueueSchema();
  await ensureSocialWorkspaceSchema();
  await ensureCalendarSchema();
  await ensureGoogleOAuthSchema();
  if (includePlatformTables) {
    await ensureSubscriptionSignupsSchema();
    await ensureSalesInquiriesSchema();
    await ensureAiFollowupTemplateSeed();
  }

  if (!seed) return;

  const existing = await get("SELECT COUNT(*) AS total FROM contacts");
  if (!existing || existing.total === 0) {
    const seed = [
      ["Vinayak Neemkar", "vinayakneemkar@gmail.com", "+15551230001", "NEW", "VN,Lead", "Imported from dashboard"],
      ["Sahith Vardhan Reddy", "sahith.asp104@gmail.com", "+15551230002", "APPROVED", "SV,Customer", ""],
      ["Stephen Lash", "drstephenlash@gmail.com", "+15551230003", "NEW", "SL,QuoteM", ""],
      ["Alexandria Salisbury", "alliethorson14@gmail.com", "+15551230004", "DECLINED", "AS", ""]
    ];

    for (const row of seed) {
      await run(
        `INSERT INTO contacts (full_name, email, phone, status, tags, notes)
         VALUES (?, ?, ?, ?, ?, ?)`,
        row
      );
    }
  }

  const templateCount = await get("SELECT COUNT(*) AS total FROM email_templates");
  if (!templateCount || Number(templateCount.total || 0) === 0) {
    await run(
      `INSERT INTO email_templates (name, subject, body) VALUES (?, ?, ?)`,
      [
        "Welcome Template",
        "Welcome to Cadence",
        "Hi {{first_name}},\n\nWelcome! We are glad to connect with you.\n\nBest regards,\nCadence Team"
      ]
    );
    await run(
      `INSERT INTO email_templates (name, subject, body) VALUES (?, ?, ?)`,
      [
        "Follow Up Template",
        "Quick Follow Up",
        "Hi {{first_name}},\n\nFollowing up on our recent conversation.\n\nThanks,\nCadence Team"
      ]
    );
  }
}

async function initDb() {
  await ensureTenantsSchema();
  await initializeCrmDatabase({ seed: true, includePlatformTables: true });
}

module.exports = {
  db,
  run,
  all,
  get,
  initDb,
  initializeCrmDatabase,
  ensureContactColumns,
  platformRun,
  platformAll,
  platformGet,
  openTenantDatabase,
  withTenantContext,
  isTrialTenantContext,
  LEGACY_TENANT_ID
};
