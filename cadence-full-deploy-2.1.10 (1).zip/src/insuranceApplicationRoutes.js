"use strict";

/**
 * Public health-insurance application form for licensed agents.
 * Applicants fill this out; the agent enters the data into EZAPP.
 *
 * GET  /apply-form  (short live URL)
 * GET  /apply/:formKey
 * POST /api/apply/:formKey
 *
 * Reuses lead_capture_config.form_key for tenant routing + notify email.
 */

const { encryptField } = require("./fieldEncryption");

function escapeHtml(s) {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function str(v, max) {
  return String(v == null ? "" : v).trim().slice(0, max || 200);
}

function digitsOnly(v, max) {
  return String(v == null ? "" : v).replace(/\D/g, "").slice(0, max || 32);
}

function buildInsuranceApplicationHtml(formKey, agencyName) {
  const safeAgency = escapeHtml(agencyName || "Your Insurance Agent");
  const safeKey = String(formKey || "").replace(/[^a-f0-9]/g, "");
  const now = new Date();
  const thisYear = now.getFullYear();
  const months = [
    ["01", "January"],
    ["02", "February"],
    ["03", "March"],
    ["04", "April"],
    ["05", "May"],
    ["06", "June"],
    ["07", "July"],
    ["08", "August"],
    ["09", "September"],
    ["10", "October"],
    ["11", "November"],
    ["12", "December"]
  ];
  const monthOpts = months
    .map(([v, label]) => `<option value="${v}">${label}</option>`)
    .join("");
  const dayOpts = Array.from({ length: 31 }, (_, i) => {
    const d = String(i + 1).padStart(2, "0");
    return `<option value="${d}">${d}</option>`;
  }).join("");
  // DOB: oldest first is hard; newest-first year list is easier to scan for adults.
  const dobYearOpts = Array.from({ length: 100 }, (_, i) => thisYear - i)
    .map((y) => `<option value="${y}">${y}</option>`)
    .join("");
  const startYearOpts = [thisYear, thisYear + 1]
    .map((y) => `<option value="${y}">${y}</option>`)
    .join("");

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Health Insurance Application Form — ${safeAgency}</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Segoe UI',system-ui,sans-serif;background:#f1f5f9;min-height:100vh;padding:28px 16px 48px;color:#0f172a}
  .wrap{width:100%;max-width:720px;margin:0 auto}
  .card{background:#fff;border-radius:16px;box-shadow:0 8px 32px rgba(15,23,42,.10);overflow:hidden}
  .card-header{background:#fff;padding:24px 32px 20px;border-bottom:1px solid #e2e8f0;text-align:center}
  .card-header .logo{display:block;max-width:280px;width:100%;height:auto;margin:0 auto 16px}
  .card-header h1{color:#002677;font-size:1.35rem;font-weight:800;letter-spacing:-.01em;margin-bottom:6px}
  .card-header p{color:#475569;font-size:.9rem;line-height:1.45}
  .card-body{padding:28px 32px 32px}
  .section{margin-bottom:28px;padding-bottom:8px;border-bottom:1px solid #e2e8f0}
  .section:last-of-type{border-bottom:none;margin-bottom:12px}
  .section-title{font-size:1rem;font-weight:800;color:#002677;margin-bottom:4px}
  .section-hint{font-size:.84rem;color:#64748b;margin-bottom:14px;line-height:1.4}
  .field{margin-bottom:14px}
  label{display:block;font-size:.78rem;font-weight:600;color:#475569;margin-bottom:5px;text-transform:uppercase;letter-spacing:.04em}
  .req::after{content:" *";color:#dc2626}
  input,select,textarea{width:100%;border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.95rem;color:#0f172a;background:#fff}
  input:focus,select:focus,textarea:focus{outline:none;border-color:#002677}
  textarea{resize:vertical;min-height:90px}
  .row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  .row-3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px}
  .date-parts{display:grid;grid-template-columns:1.4fr .8fr 1fr;gap:10px}
  .date-parts .sublabel{font-size:.7rem;font-weight:600;color:#94a3b8;margin-bottom:4px;text-transform:uppercase;letter-spacing:.04em}
  .toggle{display:flex;align-items:center;gap:10px;margin-bottom:14px;padding:10px 12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px}
  .toggle input{width:auto;margin:0}
  .toggle label{margin:0;text-transform:none;letter-spacing:0;font-size:.92rem;font-weight:600;color:#334155;cursor:pointer}
  .hidden{display:none !important}
  .check-row{display:flex;flex-wrap:wrap;gap:14px 22px;margin-bottom:8px}
  .check{display:flex;align-items:center;gap:8px}
  .check input{width:auto}
  .check label{margin:0;text-transform:none;letter-spacing:0;font-size:.92rem;font-weight:500;color:#334155;cursor:pointer}
  .price{color:#002677;font-weight:700}
  .btn{display:block;width:100%;padding:14px;background:#002677;color:#fff;font-weight:700;font-size:1rem;border:none;border-radius:999px;cursor:pointer;margin-top:8px}
  .btn:hover{opacity:.92}
  .btn:disabled{opacity:.6;cursor:not-allowed}
  .success{display:none;text-align:center;padding:40px 16px}
  .success-icon{width:56px;height:56px;border-radius:50%;background:#ecfdf5;color:#059669;display:inline-flex;align-items:center;justify-content:center;font-size:1.6rem;font-weight:800;margin-bottom:14px}
  .success h2{color:#002677;font-size:1.2rem;margin-bottom:8px}
  .success p{color:#475569;font-size:.95rem;line-height:1.5}
  .err{color:#dc2626;font-size:.88rem;margin:10px 0;display:none}
  .notice{font-size:.82rem;color:#64748b;line-height:1.45;margin:12px 0 0;padding:12px;background:#f8fafc;border-radius:8px;border:1px solid #e2e8f0}
  .footer{margin-top:18px;text-align:center;font-size:.78rem;color:#94a3b8}
  .footer a{color:#002677;text-decoration:none}
  @media(max-width:640px){.row,.row-3{grid-template-columns:1fr}.date-parts{grid-template-columns:1fr}.card-body{padding:20px}.card-header{padding:20px}.card-header .logo{max-width:220px}}
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="card-header">
      <img class="logo" src="/united-healthcare-logo.png" alt="UnitedHealthcare" width="280" height="56" />
      <h1>Health Insurance Application Form</h1>
      <p>Complete this form for ${safeAgency}. Your licensed agent will use these details to submit your application in EZAPP.</p>
    </div>
    <div class="card-body">
      <form id="ia-form" autocomplete="off">

        <div class="section">
          <div class="section-title">Primary Applicant</div>
          <p class="section-hint">The main person named on the policy.</p>
          <div class="row-3">
            <div class="field"><label class="req" for="first_name">First name</label><input id="first_name" name="first_name" type="text" required autocomplete="off" /></div>
            <div class="field"><label for="middle_name">Middle name</label><input id="middle_name" name="middle_name" type="text" autocomplete="off" /></div>
            <div class="field"><label class="req" for="last_name">Last name</label><input id="last_name" name="last_name" type="text" required autocomplete="off" /></div>
          </div>
          <div class="field"><label class="req" for="gender">Gender</label>
            <select id="gender" name="gender" required>
              <option value="">Select…</option>
              <option>Male</option>
              <option>Female</option>
            </select>
          </div>
          <div class="field">
            <label class="req">Date of birth</label>
            <div class="date-parts">
              <div>
                <div class="sublabel">Month</div>
                <select id="dob_month" required><option value="">Month</option>${monthOpts}</select>
              </div>
              <div>
                <div class="sublabel">Day</div>
                <select id="dob_day" required><option value="">Day</option>${dayOpts}</select>
              </div>
              <div>
                <div class="sublabel">Year</div>
                <select id="dob_year" required><option value="">Year</option>${dobYearOpts}</select>
              </div>
            </div>
          </div>
          <div class="row-3">
            <div class="field"><label class="req" for="height">Height</label><input id="height" name="height" type="text" required placeholder="e.g. 5'10&quot;" /></div>
            <div class="field"><label class="req" for="weight">Weight (lbs)</label><input id="weight" name="weight" type="text" required inputmode="numeric" placeholder="e.g. 180" /></div>
            <div class="field"><label class="req" for="ssn_last4">Last 4 of SSN</label><input id="ssn_last4" name="ssn_last4" type="password" required inputmode="numeric" maxlength="4" pattern="[0-9]{4}" autocomplete="off" /></div>
          </div>
          <div class="field"><label class="req" for="profession">Profession</label><input id="profession" name="profession" type="text" required /></div>
          <div class="field"><label class="req" for="home_address">Street address</label><input id="home_address" name="home_address" type="text" required autocomplete="off" /></div>
          <div class="row-3">
            <div class="field"><label class="req" for="city">City</label><input id="city" name="city" type="text" required autocomplete="off" /></div>
            <div class="field"><label class="req" for="state">State</label><input id="state" name="state" type="text" required autocomplete="off" placeholder="e.g. TX" /></div>
            <div class="field"><label class="req" for="zip_code">ZIP</label><input id="zip_code" name="zip_code" type="text" required autocomplete="off" /></div>
          </div>
          <div class="row">
            <div class="field"><label class="req" for="ia_contact_email">Email</label><input id="ia_contact_email" name="ia_contact_email" type="text" inputmode="email" required autocomplete="new-password" data-lpignore="true" data-1p-ignore="true" data-form-type="other" readonly onfocus="this.removeAttribute('readonly')" value="" /></div>
            <div class="field"><label class="req" for="ia_contact_phone">Phone</label><input id="ia_contact_phone" name="ia_contact_phone" type="text" inputmode="tel" required autocomplete="new-password" data-lpignore="true" data-1p-ignore="true" data-form-type="other" readonly onfocus="this.removeAttribute('readonly')" value="" /></div>
          </div>
        </div>

        <div class="section">
          <div class="section-title">Spouse</div>
          <div class="toggle">
            <input type="checkbox" id="has_spouse" />
            <label for="has_spouse">Include spouse on this application</label>
          </div>
          <div id="spouse-fields" class="hidden">
            <div class="row-3">
              <div class="field"><label class="req" for="spouse_first_name">First name</label><input id="spouse_first_name" name="spouse_first_name" type="text" /></div>
              <div class="field"><label for="spouse_middle_name">Middle name</label><input id="spouse_middle_name" name="spouse_middle_name" type="text" /></div>
              <div class="field"><label class="req" for="spouse_last_name">Last name</label><input id="spouse_last_name" name="spouse_last_name" type="text" /></div>
            </div>
            <div class="row">
              <div class="field"><label class="req" for="spouse_gender">Gender</label>
                <select id="spouse_gender" name="spouse_gender">
                  <option value="">Select…</option>
                  <option>Male</option>
                  <option>Female</option>
                </select>
              </div>
              <div class="field"><label class="req" for="spouse_ssn_last4">Last 4 of SSN</label><input id="spouse_ssn_last4" name="spouse_ssn_last4" type="password" inputmode="numeric" maxlength="4" pattern="[0-9]{4}" autocomplete="off" /></div>
            </div>
            <div class="field">
              <label class="req">Date of birth</label>
              <div class="date-parts">
                <div>
                  <div class="sublabel">Month</div>
                  <select id="spouse_dob_month"><option value="">Month</option>${monthOpts}</select>
                </div>
                <div>
                  <div class="sublabel">Day</div>
                  <select id="spouse_dob_day"><option value="">Day</option>${dayOpts}</select>
                </div>
                <div>
                  <div class="sublabel">Year</div>
                  <select id="spouse_dob_year"><option value="">Year</option>${dobYearOpts}</select>
                </div>
              </div>
            </div>
            <div class="row-3">
              <div class="field"><label class="req" for="spouse_height">Height</label><input id="spouse_height" name="spouse_height" type="text" placeholder="e.g. 5'6&quot;" /></div>
              <div class="field"><label class="req" for="spouse_weight">Weight (lbs)</label><input id="spouse_weight" name="spouse_weight" type="text" inputmode="numeric" /></div>
              <div class="field"><label class="req" for="spouse_profession">Profession</label><input id="spouse_profession" name="spouse_profession" type="text" /></div>
            </div>
          </div>
        </div>

        <div class="section">
          <div class="section-title">Child 1</div>
          <div class="toggle">
            <input type="checkbox" id="has_child1" />
            <label for="has_child1">Include Child 1</label>
          </div>
          <div id="child1-fields" class="hidden">
            <div class="row-3">
              <div class="field"><label class="req" for="child1_first_name">First name</label><input id="child1_first_name" name="child1_first_name" type="text" /></div>
              <div class="field"><label for="child1_middle_name">Middle name</label><input id="child1_middle_name" name="child1_middle_name" type="text" /></div>
              <div class="field"><label class="req" for="child1_last_name">Last name</label><input id="child1_last_name" name="child1_last_name" type="text" /></div>
            </div>
            <div class="field">
              <label class="req">Date of birth</label>
              <div class="date-parts">
                <div>
                  <div class="sublabel">Month</div>
                  <select id="child1_dob_month"><option value="">Month</option>${monthOpts}</select>
                </div>
                <div>
                  <div class="sublabel">Day</div>
                  <select id="child1_dob_day"><option value="">Day</option>${dayOpts}</select>
                </div>
                <div>
                  <div class="sublabel">Year</div>
                  <select id="child1_dob_year"><option value="">Year</option>${dobYearOpts}</select>
                </div>
              </div>
            </div>
            <div class="row-3">
              <div class="field"><label class="req" for="child1_gender">Gender</label>
                <select id="child1_gender" name="child1_gender">
                  <option value="">Select…</option>
                  <option>Male</option>
                  <option>Female</option>
                </select>
              </div>
              <div class="field"><label class="req" for="child1_height">Height</label><input id="child1_height" name="child1_height" type="text" /></div>
              <div class="field"><label class="req" for="child1_weight">Weight (lbs)</label><input id="child1_weight" name="child1_weight" type="text" inputmode="numeric" /></div>
            </div>
          </div>
        </div>

        <div class="section">
          <div class="section-title">Child 2</div>
          <div class="toggle">
            <input type="checkbox" id="has_child2" />
            <label for="has_child2">Include Child 2</label>
          </div>
          <div id="child2-fields" class="hidden">
            <div class="row-3">
              <div class="field"><label class="req" for="child2_first_name">First name</label><input id="child2_first_name" name="child2_first_name" type="text" /></div>
              <div class="field"><label for="child2_middle_name">Middle name</label><input id="child2_middle_name" name="child2_middle_name" type="text" /></div>
              <div class="field"><label class="req" for="child2_last_name">Last name</label><input id="child2_last_name" name="child2_last_name" type="text" /></div>
            </div>
            <div class="field">
              <label class="req">Date of birth</label>
              <div class="date-parts">
                <div>
                  <div class="sublabel">Month</div>
                  <select id="child2_dob_month"><option value="">Month</option>${monthOpts}</select>
                </div>
                <div>
                  <div class="sublabel">Day</div>
                  <select id="child2_dob_day"><option value="">Day</option>${dayOpts}</select>
                </div>
                <div>
                  <div class="sublabel">Year</div>
                  <select id="child2_dob_year"><option value="">Year</option>${dobYearOpts}</select>
                </div>
              </div>
            </div>
            <div class="row-3">
              <div class="field"><label class="req" for="child2_gender">Gender</label>
                <select id="child2_gender" name="child2_gender">
                  <option value="">Select…</option>
                  <option>Male</option>
                  <option>Female</option>
                </select>
              </div>
              <div class="field"><label class="req" for="child2_height">Height</label><input id="child2_height" name="child2_height" type="text" /></div>
              <div class="field"><label class="req" for="child2_weight">Weight (lbs)</label><input id="child2_weight" name="child2_weight" type="text" inputmode="numeric" /></div>
            </div>
          </div>
        </div>

        <div class="section">
          <div class="section-title">Medical conditions &amp; prescriptions</div>
          <p class="section-hint">Optional. List any conditions, medications, dosages, and who they apply to.</p>
          <div class="field"><label for="medical_notes">Details</label><textarea id="medical_notes" name="medical_notes" placeholder="e.g. High blood pressure — Lisinopril 10mg daily (primary)"></textarea></div>
        </div>

        <div class="section">
          <div class="section-title">Dental, vision &amp; life</div>
          <p class="section-hint">Optional add-ons. Dental and vision prices are per insured, monthly.</p>
          <div class="check-row">
            <div class="check"><input type="checkbox" id="want_dental" /><label for="want_dental">Add dental — <span class="price">$42.35</span> per insured monthly</label></div>
            <div class="check"><input type="checkbox" id="want_vision" /><label for="want_vision">Add vision — <span class="price">$12.39</span> per insured monthly</label></div>
            <div class="check"><input type="checkbox" id="want_life" /><label for="want_life">Add Life Insurance — <span class="price">Amount varies</span></label></div>
          </div>
        </div>

        <div class="section">
          <div class="section-title">Coverage start &amp; payment</div>
          <div class="field">
            <label class="req">Preferred start date</label>
            <div class="date-parts">
              <div>
                <div class="sublabel">Month</div>
                <select id="start_month" required><option value="">Month</option>${monthOpts}</select>
              </div>
              <div>
                <div class="sublabel">Day</div>
                <select id="start_day" required><option value="">Day</option>${dayOpts}</select>
              </div>
              <div>
                <div class="sublabel">Year</div>
                <select id="start_year" required><option value="">Year</option>${startYearOpts}</select>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="field"><label class="req" for="ia_ach_rt">Bank routing number</label><input id="ia_ach_rt" name="ia_ach_rt" type="text" required inputmode="numeric" maxlength="9" pattern="[0-9]{9}" autocomplete="new-password" data-lpignore="true" data-1p-ignore="true" data-form-type="other" readonly onfocus="this.removeAttribute('readonly');this.type='password'" value="" /></div>
            <div class="field"><label class="req" for="ia_ach_ac">Bank account number</label><input id="ia_ach_ac" name="ia_ach_ac" type="text" required inputmode="numeric" autocomplete="new-password" data-lpignore="true" data-1p-ignore="true" data-form-type="other" readonly onfocus="this.removeAttribute('readonly');this.type='password'" value="" /></div>
          </div>
          <p class="notice">Sensitive information (SSN last 4 and bank details) is sent securely to your licensed agent for EZAPP entry only. Do not share this link publicly.</p>
        </div>

        <p class="err" id="ia-err"></p>
        <button class="btn" type="submit" id="ia-submit">Submit Application Information</button>
      </form>

      <div class="success" id="ia-success">
        <div class="success-icon">✓</div>
        <h2>Application received</h2>
        <p>Thank you. Your information has been sent to ${safeAgency}. Your agent will enter the application into EZAPP and follow up with you.</p>
      </div>
    </div>
  </div>
  <p class="footer">Powered by <a href="https://crmcadence.com" target="_blank" rel="noopener">Cadence CRM</a></p>
</div>
<script>
(function(){
  function toggle(cbId, fieldsId, requiredIds){
    var cb=document.getElementById(cbId);
    var box=document.getElementById(fieldsId);
    function sync(){
      var on=cb.checked;
      box.classList.toggle('hidden', !on);
      requiredIds.forEach(function(id){
        var el=document.getElementById(id);
        if(el) el.required = on;
      });
    }
    cb.addEventListener('change', sync);
    sync();
  }
  toggle('has_spouse','spouse-fields',['spouse_first_name','spouse_last_name','spouse_gender','spouse_ssn_last4','spouse_dob_month','spouse_dob_day','spouse_dob_year','spouse_height','spouse_weight','spouse_profession']);
  toggle('has_child1','child1-fields',['child1_first_name','child1_last_name','child1_gender','child1_dob_month','child1_dob_day','child1_dob_year','child1_height','child1_weight']);
  toggle('has_child2','child2-fields',['child2_first_name','child2_last_name','child2_gender','child2_dob_month','child2_dob_day','child2_dob_year','child2_height','child2_weight']);

  function dateFromParts(mId, dId, yId){
    var m=document.getElementById(mId).value;
    var d=document.getElementById(dId).value;
    var y=document.getElementById(yId).value;
    if(!m||!d||!y) return '';
    return y+'-'+m+'-'+d;
  }

  // Strip browser autofill (Chrome often ignores autocomplete=off).
  var noFillIds=['ia_contact_email','ia_contact_phone','ia_ach_rt','ia_ach_ac','ssn_last4','spouse_ssn_last4'];
  function clearNoFill(){
    noFillIds.forEach(function(id){
      var el=document.getElementById(id);
      if(!el) return;
      el.value='';
      el.setAttribute('value','');
    });
  }
  clearNoFill();
  setTimeout(clearNoFill, 50);
  setTimeout(clearNoFill, 250);
  setTimeout(clearNoFill, 800);
  window.addEventListener('pageshow', clearNoFill);

  var form=document.getElementById('ia-form');
  var btn=document.getElementById('ia-submit');
  var err=document.getElementById('ia-err');
  var success=document.getElementById('ia-success');

  form.addEventListener('submit', function(e){
    e.preventDefault();
    err.style.display='none';
    var dob=dateFromParts('dob_month','dob_day','dob_year');
    var start=dateFromParts('start_month','start_day','start_year');
    var spouseDob=dateFromParts('spouse_dob_month','spouse_dob_day','spouse_dob_year');
    var child1Dob=dateFromParts('child1_dob_month','child1_dob_day','child1_dob_year');
    var child2Dob=dateFromParts('child2_dob_month','child2_dob_day','child2_dob_year');
    if(!dob){
      err.textContent='Please select a complete date of birth.';
      err.style.display='block';
      return;
    }
    if(!start){
      err.textContent='Please select a complete preferred start date.';
      err.style.display='block';
      return;
    }
    if(document.getElementById('has_spouse').checked && !spouseDob){
      err.textContent='Please select a complete spouse date of birth.';
      err.style.display='block';
      return;
    }
    if(document.getElementById('has_child1').checked && !child1Dob){
      err.textContent='Please select a complete Child 1 date of birth.';
      err.style.display='block';
      return;
    }
    if(document.getElementById('has_child2').checked && !child2Dob){
      err.textContent='Please select a complete Child 2 date of birth.';
      err.style.display='block';
      return;
    }
    btn.disabled=true;
    btn.textContent='Submitting…';
    var g=function(id){ var el=document.getElementById(id); return (el&&el.value||'').trim(); };
    function joinName(first, middle, last){ return [first, middle, last].filter(Boolean).join(' '); }
    var data={
      first_name:g('first_name'),
      middle_name:g('middle_name'),
      last_name:g('last_name'),
      full_name:joinName(g('first_name'), g('middle_name'), g('last_name')),
      gender:g('gender'),
      date_of_birth:dob,
      height:g('height'),
      weight:g('weight'),
      ssn_last4:g('ssn_last4'),
      profession:g('profession'),
      home_address:g('home_address'),
      city:g('city'),
      state:g('state'),
      zip_code:g('zip_code'),
      email:g('ia_contact_email'),
      phone:g('ia_contact_phone'),
      has_spouse:document.getElementById('has_spouse').checked,
      spouse_first_name:g('spouse_first_name'),
      spouse_middle_name:g('spouse_middle_name'),
      spouse_last_name:g('spouse_last_name'),
      spouse_full_name:joinName(g('spouse_first_name'), g('spouse_middle_name'), g('spouse_last_name')),
      spouse_gender:g('spouse_gender'),
      spouse_ssn_last4:g('spouse_ssn_last4'),
      spouse_date_of_birth:spouseDob,
      spouse_height:g('spouse_height'),
      spouse_weight:g('spouse_weight'),
      spouse_profession:g('spouse_profession'),
      has_child1:document.getElementById('has_child1').checked,
      child1_first_name:g('child1_first_name'),
      child1_middle_name:g('child1_middle_name'),
      child1_last_name:g('child1_last_name'),
      child1_full_name:joinName(g('child1_first_name'), g('child1_middle_name'), g('child1_last_name')),
      child1_gender:g('child1_gender'),
      child1_date_of_birth:child1Dob,
      child1_height:g('child1_height'),
      child1_weight:g('child1_weight'),
      has_child2:document.getElementById('has_child2').checked,
      child2_first_name:g('child2_first_name'),
      child2_middle_name:g('child2_middle_name'),
      child2_last_name:g('child2_last_name'),
      child2_full_name:joinName(g('child2_first_name'), g('child2_middle_name'), g('child2_last_name')),
      child2_gender:g('child2_gender'),
      child2_date_of_birth:child2Dob,
      child2_height:g('child2_height'),
      child2_weight:g('child2_weight'),
      medical_notes:g('medical_notes'),
      want_dental:document.getElementById('want_dental').checked,
      want_vision:document.getElementById('want_vision').checked,
      want_life:document.getElementById('want_life').checked,
      coverage_start_date:start,
      bank_routing:g('ia_ach_rt'),
      bank_account:g('ia_ach_ac')
    };
    fetch('/api/apply/${safeKey}',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify(data)
    }).then(function(r){ return r.json().then(function(j){ return {ok:r.ok,j:j}; }); })
    .then(function(res){
      if(res.ok && res.j.ok){
        form.style.display='none';
        success.style.display='block';
      } else {
        err.textContent=(res.j && res.j.error) || 'Something went wrong. Please try again.';
        err.style.display='block';
        btn.disabled=false;
        btn.textContent='Submit Application Information';
      }
    }).catch(function(){
      err.textContent='Network error. Please try again.';
      err.style.display='block';
      btn.disabled=false;
      btn.textContent='Submit Application Information';
    });
  });
})();
</script>
</body>
</html>`;
}

function buildEzappPacket(body) {
  const lines = [
    "=== EZAPP APPLICATION PACKET ===",
    "",
    "PRIMARY APPLICANT",
    `Full name: ${str(body.full_name, 200)}`,
    `Gender: ${str(body.gender, 40)}`,
    `Date of birth: ${str(body.date_of_birth, 40)}`,
    `Height: ${str(body.height, 40)}`,
    `Weight: ${str(body.weight, 40)}`,
    `SSN last 4: ${digitsOnly(body.ssn_last4, 4)}`,
    `Profession: ${str(body.profession, 120)}`,
    `Address: ${str(body.home_address, 200)}, ${str(body.city, 100)}, ${str(body.state, 40)} ${str(body.zip_code, 20)}`,
    `Email: ${str(body.email, 200)}`,
    `Phone: ${str(body.phone, 50)}`,
    ""
  ];

  if (body.has_spouse) {
    lines.push(
      "SPOUSE",
      `Full name: ${str(body.spouse_full_name, 200)}`,
      `Gender: ${str(body.spouse_gender, 40)}`,
      `Date of birth: ${str(body.spouse_date_of_birth, 40)}`,
      `SSN last 4: ${digitsOnly(body.spouse_ssn_last4, 4)}`,
      `Height: ${str(body.spouse_height, 40)}`,
      `Weight: ${str(body.spouse_weight, 40)}`,
      `Profession: ${str(body.spouse_profession, 120)}`,
      ""
    );
  }

  if (body.has_child1) {
    lines.push(
      "CHILD 1",
      `Full name: ${str(body.child1_full_name, 200)}`,
      `Gender: ${str(body.child1_gender, 40)}`,
      `Date of birth: ${str(body.child1_date_of_birth, 40)}`,
      `Height: ${str(body.child1_height, 40)}`,
      `Weight: ${str(body.child1_weight, 40)}`,
      ""
    );
  }

  if (body.has_child2) {
    lines.push(
      "CHILD 2",
      `Full name: ${str(body.child2_full_name, 200)}`,
      `Gender: ${str(body.child2_gender, 40)}`,
      `Date of birth: ${str(body.child2_date_of_birth, 40)}`,
      `Height: ${str(body.child2_height, 40)}`,
      `Weight: ${str(body.child2_weight, 40)}`,
      ""
    );
  }

  const medical = str(body.medical_notes, 4000);
  lines.push("MEDICAL / PRESCRIPTIONS", medical || "(none provided)", "");

  const addOns = [];
  if (body.want_dental) addOns.push("Dental — $42.35 per insured monthly");
  if (body.want_vision) addOns.push("Vision — $12.39 per insured monthly");
  if (body.want_life) addOns.push("Life Insurance — Amount varies");
  lines.push("ADD-ONS", addOns.length ? addOns.join(" + ") : "(none)", "");

  lines.push(
    "COVERAGE & PAYMENT",
    `Preferred start date: ${str(body.coverage_start_date, 40)}`,
    `Bank routing: ${digitsOnly(body.bank_routing, 9)}`,
    `Bank account: ${digitsOnly(body.bank_account, 20)}`,
    "",
    "Submitted via Cadence Health Insurance Application form."
  );

  return lines.join("\n");
}

function validateApplication(body) {
  if (!str(body.full_name, 200)) return "Full name is required.";
  if (!str(body.gender, 40)) return "Gender is required.";
  if (!str(body.date_of_birth, 40)) return "Date of birth is required.";
  if (!str(body.height, 40)) return "Height is required.";
  if (!str(body.weight, 40)) return "Weight is required.";
  if (digitsOnly(body.ssn_last4, 4).length !== 4) return "Last 4 of SSN must be exactly 4 digits.";
  if (!str(body.profession, 120)) return "Profession is required.";
  if (!str(body.home_address, 200)) return "Street address is required.";
  if (!str(body.city, 100)) return "City is required.";
  if (!str(body.state, 40)) return "State is required.";
  if (!str(body.zip_code, 20)) return "ZIP code is required.";
  const email = str(body.email, 200);
  if (!email || !email.includes("@")) return "A valid email address is required.";
  if (!str(body.phone, 50)) return "Phone is required.";
  if (!str(body.coverage_start_date, 40)) return "Preferred start date is required.";
  if (digitsOnly(body.bank_routing, 9).length !== 9) return "Bank routing number must be 9 digits.";
  if (digitsOnly(body.bank_account, 20).length < 4) return "Bank account number is required.";

  if (body.has_spouse) {
    if (!str(body.spouse_full_name, 200)) return "Spouse full name is required.";
    if (!str(body.spouse_gender, 40)) return "Spouse gender is required.";
    if (!str(body.spouse_date_of_birth, 40)) return "Spouse date of birth is required.";
    if (digitsOnly(body.spouse_ssn_last4, 4).length !== 4) return "Spouse SSN last 4 must be exactly 4 digits.";
    if (!str(body.spouse_height, 40)) return "Spouse height is required.";
    if (!str(body.spouse_weight, 40)) return "Spouse weight is required.";
    if (!str(body.spouse_profession, 120)) return "Spouse profession is required.";
  }
  if (body.has_child1) {
    if (!str(body.child1_full_name, 200)) return "Child 1 full name is required.";
    if (!str(body.child1_gender, 40)) return "Child 1 gender is required.";
    if (!str(body.child1_date_of_birth, 40)) return "Child 1 date of birth is required.";
    if (!str(body.child1_height, 40)) return "Child 1 height is required.";
    if (!str(body.child1_weight, 40)) return "Child 1 weight is required.";
  }
  if (body.has_child2) {
    if (!str(body.child2_full_name, 200)) return "Child 2 full name is required.";
    if (!str(body.child2_gender, 40)) return "Child 2 gender is required.";
    if (!str(body.child2_date_of_birth, 40)) return "Child 2 date of birth is required.";
    if (!str(body.child2_height, 40)) return "Child 2 height is required.";
    if (!str(body.child2_weight, 40)) return "Child 2 weight is required.";
  }
  return null;
}

function resolveInsuranceAppMirrorUrl() {
  const full = String(process.env.INSURANCE_APP_MIRROR_APPLY_URL || "").trim().replace(/\/$/, "");
  if (full) return full;
  const base = String(process.env.INSURANCE_APP_MIRROR_BASE || "").trim().replace(/\/$/, "");
  const key = String(process.env.INSURANCE_APP_MIRROR_FORM_KEY || "").replace(/[^a-f0-9]/g, "");
  if (base && key) return `${base}/api/apply/${key}`;
  return "";
}

async function mirrorInsuranceApplication(body, req) {
  // Avoid infinite loops when two Cadence sites mirror each other.
  if (String(req.get("x-cadence-mirror") || "") === "1") return;
  const url = resolveInsuranceAppMirrorUrl();
  if (!url) return;
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 15000);
    const resp = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Cadence-Mirror": "1"
      },
      body: JSON.stringify(body),
      signal: controller.signal
    });
    clearTimeout(timer);
    if (!resp.ok) {
      const text = await resp.text().catch(() => "");
      console.warn(
        `[insurance-app] Mirror to ${url} failed: HTTP ${resp.status} ${String(text).slice(0, 200)}`
      );
    }
  } catch (err) {
    console.warn("[insurance-app] Mirror request failed:", err.message || err);
  }
}

function normalizePersonName(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/[.,']/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function mergeContactTags(existing, extras) {
  const seen = new Set();
  const out = [];
  for (const raw of [...String(existing || "").split(/[,;]/), ...extras]) {
    const tag = String(raw || "").trim();
    if (!tag) continue;
    const key = tag.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(tag);
  }
  return out.join(",");
}

function splitPersonName(fullName) {
  const parts = str(fullName, 200).split(/\s+/).filter(Boolean);
  if (!parts.length) return { first_name: "", last_name: "" };
  if (parts.length === 1) return { first_name: parts[0], last_name: "" };
  return { first_name: parts[0], last_name: parts.slice(1).join(" ") };
}

function householdMemberFromApplication(id, relationship, fullName, dob, gender, middleName) {
  const explicitMiddle = str(middleName, 80);
  const name = splitPersonName(fullName);
  if (!name.first_name && !name.last_name && !explicitMiddle) return null;
  const genderVal = str(gender, 40);
  let first = name.first_name;
  let last = name.last_name;
  if (explicitMiddle) {
    const midParts = explicitMiddle.split(/\s+/).filter(Boolean);
    const rest = String(fullName || "").trim().split(/\s+/).filter(Boolean).slice(1);
    const head = rest.slice(0, midParts.length).join(" ");
    if (head.toLowerCase() === explicitMiddle.toLowerCase()) {
      first = rest.length ? String(fullName).trim().split(/\s+/)[0] : first;
      last = rest.slice(midParts.length).join(" ");
    }
  }
  return {
    id,
    relationship,
    first_name: first,
    middle_name: explicitMiddle,
    last_name: last,
    date_of_birth: str(dob, 40),
    gender: genderVal === "Male" || genderVal === "Female" ? genderVal : "",
    tobacco: ""
  };
}

function buildApplicationHouseholdMembers(body) {
  const members = [];
  if (body.has_spouse) {
    const spouse = householdMemberFromApplication(
      "hm_spouse",
      "Spouse",
      body.spouse_full_name,
      body.spouse_date_of_birth,
      body.spouse_gender,
      body.spouse_middle_name
    );
    if (spouse) members.push(spouse);
  }
  if (body.has_child1) {
    const child = householdMemberFromApplication(
      "hm_child1",
      "Child",
      body.child1_full_name,
      body.child1_date_of_birth,
      body.child1_gender,
      body.child1_middle_name
    );
    if (child) members.push(child);
  }
  if (body.has_child2) {
    const child = householdMemberFromApplication(
      "hm_child2",
      "Child",
      body.child2_full_name,
      body.child2_date_of_birth,
      body.child2_gender,
      body.child2_middle_name
    );
    if (child) members.push(child);
  }
  return members;
}

async function findExistingApplicationContact(get, { email, fullName }) {
  const emailNorm = String(email || "").trim().toLowerCase();
  if (emailNorm) {
    const byEmail = await get(
      `SELECT id FROM contacts
        WHERE lower(trim(COALESCE(email, ''))) = ?
        ORDER BY id ASC
        LIMIT 1`,
      [emailNorm]
    );
    if (byEmail && byEmail.id) return byEmail;
  }
  const nameNorm = normalizePersonName(fullName);
  if (!nameNorm) return null;
  const byName = await get(
    `SELECT id,
            (SELECT COUNT(*) FROM contacts WHERE lower(trim(COALESCE(full_name, ''))) = lower(trim(?))) AS name_count
       FROM contacts
      WHERE lower(trim(COALESCE(full_name, ''))) = lower(trim(?))
      ORDER BY id ASC
      LIMIT 1`,
    [fullName, fullName]
  );
  if (byName && byName.id && Number(byName.name_count) === 1) return byName;
  return null;
}

function registerInsuranceApplicationRoutes(app, deps) {
  const {
    platformGet,
    withTenantContext,
    openTenantDatabase,
    run,
    get,
    LEGACY_TENANT_ID,
    sendNotifyEmail,
    logContactActivity,
    publicFormsLimiter
  } = deps;

  const rateLimit = typeof publicFormsLimiter === "function" ? publicFormsLimiter : (_req, _res, next) => next();

  async function resolveDefaultApplyConfig() {
    let cfg = await platformGet(
      `SELECT form_key, tenant_id, notify_email FROM lead_capture_config WHERE tenant_id = ?`,
      [LEGACY_TENANT_ID]
    );
    if (!cfg) {
      cfg = await platformGet(
        `SELECT form_key, tenant_id, notify_email FROM lead_capture_config ORDER BY id ASC LIMIT 1`
      );
    }
    return cfg || null;
  }

  async function resolveAgencyName(tenantId) {
    let agencyName = "Your Insurance Agent";
    if (Number(tenantId) !== Number(LEGACY_TENANT_ID)) {
      const signup = await platformGet(
        `SELECT agency_name FROM subscription_signups WHERE tenant_id = ?`,
        [tenantId]
      );
      if (signup && signup.agency_name) agencyName = signup.agency_name;
    }
    return agencyName;
  }

  async function serveApplyPage(res, formKey, tenantId) {
    const agencyName = await resolveAgencyName(tenantId);
    res.removeHeader("X-Frame-Options");
    res.setHeader("Content-Security-Policy", "frame-ancestors *");
    res.type("html").send(buildInsuranceApplicationHtml(formKey, agencyName));
  }

  // Friendly short URL — uses this server's form key, so a localhost copy
  // still works after it is rewritten to the live host.
  app.get(["/apply-form", "/applyform"], async (req, res) => {
    try {
      const cfg = await resolveDefaultApplyConfig();
      if (!cfg || !cfg.form_key) {
        return res
          .status(404)
          .send("Application form is not set up yet. Open Lead Capture Form in Cadence to create your link.");
      }
      await serveApplyPage(res, cfg.form_key, cfg.tenant_id);
    } catch (err) {
      console.error("[insurance-app] GET /apply-form error:", err.message || err);
      res.status(500).send("Something went wrong. Please try again.");
    }
  });

  app.get("/apply/:formKey", async (req, res) => {
    try {
      const formKey = String(req.params.formKey || "").replace(/[^a-f0-9]/g, "");
      if (!formKey) return res.status(400).send("Invalid form link.");
      const cfg = await platformGet(
        `SELECT tenant_id FROM lead_capture_config WHERE form_key = ?`,
        [formKey]
      );
      if (!cfg) {
        return res
          .status(404)
          .send(
            "Form not found. The link may have been regenerated — check Lead Capture Form in your CRM for the current link."
          );
      }
      await serveApplyPage(res, formKey, cfg.tenant_id);
    } catch (err) {
      console.error("[insurance-app] GET /apply error:", err.message || err);
      res.status(500).send("Something went wrong. Please try again.");
    }
  });

  app.post("/api/apply/:formKey", rateLimit, async (req, res) => {
    try {
      const formKey = String(req.params.formKey || "").replace(/[^a-f0-9]/g, "");
      if (!formKey) return res.status(400).json({ error: "Invalid form link." });
      const cfg = await platformGet(
        `SELECT tenant_id, notify_email FROM lead_capture_config WHERE form_key = ?`,
        [formKey]
      );
      if (!cfg) return res.status(404).json({ error: "Form not found." });

      const body = req.body || {};
      const validationError = validateApplication(body);
      if (validationError) return res.status(400).json({ error: validationError });

      const fullName = str(body.full_name, 200);
      const middleName = str(body.middle_name, 80);
      const email = str(body.email, 200);
      const phone = str(body.phone, 50);
      const packet = buildEzappPacket(body);
      const healthIssues = str(body.medical_notes, 2000);
      const addOns = [];
      if (body.want_dental) addOns.push("Dental — $42.35 per insured monthly");
      if (body.want_vision) addOns.push("Vision — $12.39 per insured monthly");
      if (body.want_life) addOns.push("Life Insurance — Amount varies");
      const notes = addOns.length
        ? `Health insurance application. Add-ons: ${addOns.join(" + ")}.`
        : "Health insurance application submitted via Cadence form.";

      const household = 1 + (body.has_spouse ? 1 : 0) + (body.has_child1 ? 1 : 0) + (body.has_child2 ? 1 : 0);
      const householdMembers = buildApplicationHouseholdMembers(body);
      const householdJson = JSON.stringify(householdMembers);
      const appTags = ["insurance-app", "ezapp"];
      const gender = str(body.gender, 40);
      const dateOfBirth = str(body.date_of_birth, 40);
      const profession = str(body.profession, 120);
      const coverageStart = str(body.coverage_start_date, 40);
      const height = str(body.height, 40);
      const weight = str(body.weight, 40);
      const ssnLast4 = encryptField(digitsOnly(body.ssn_last4, 4));
      const homeAddress = str(body.home_address, 200);
      const city = str(body.city, 100);
      const state = str(body.state, 40);
      const zipCode = str(body.zip_code, 20);
      const bankRouting = encryptField(digitsOnly(body.bank_routing, 9));
      const bankAccount = encryptField(digitsOnly(body.bank_account, 20));

      let upserted = { created: true, id: null };
      const tenantId = Number(cfg.tenant_id);
      if (
        Number.isInteger(tenantId) &&
        tenantId > 0 &&
        tenantId !== Number(LEGACY_TENANT_ID) &&
        typeof openTenantDatabase === "function"
      ) {
        await openTenantDatabase(tenantId);
      }
      await withTenantContext(cfg.tenant_id, async () => {
        const existing = typeof get === "function" ? await findExistingApplicationContact(get, { email, fullName }) : null;
        if (existing && existing.id) {
          const current = await get(
            `SELECT id, tags, notes, special_notes, lead_source, household_members FROM contacts WHERE id = ?`,
            [existing.id]
          );
          const mergedTags = mergeContactTags(current && current.tags, appTags);
          const prevNotes = String((current && current.notes) || "").trim();
          const mergedNotes = prevNotes ? `${prevNotes}\n\n${notes}` : notes;
          const prevPacket = String((current && current.special_notes) || "").trim();
          const mergedPacket =
            prevPacket && prevPacket !== packet ? `${packet}\n\n--- Previous notes ---\n${prevPacket}` : packet;
          const keepLeadSource = String((current && current.lead_source) || "").trim();
          await run(
            `UPDATE contacts SET
               full_name = ?, middle_name = ?, email = ?, phone = ?,
               tags = ?, notes = ?, special_notes = ?,
               lead_source = COALESCE(NULLIF(?, ''), lead_source),
               gender = ?, date_of_birth = ?, profession = ?, health_issues = ?, coverage_start_date = ?,
               height = ?, weight = ?, ssn_last4 = ?,
               home_address = ?, city = ?, state = ?, zip_code = ?, household_size = ?,
               household_members = CASE WHEN trim(COALESCE(household_members, '')) = '' THEN ? ELSE household_members END,
               bank_routing = ?, bank_account = ?,
               application_submitted_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
             WHERE id = ?`,
            [
              fullName,
              middleName,
              email,
              phone,
              mergedTags,
              mergedNotes,
              mergedPacket,
              keepLeadSource || "Insurance Application",
              gender,
              dateOfBirth,
              profession,
              healthIssues,
              coverageStart,
              height,
              weight,
              ssnLast4,
              homeAddress,
              city,
              state,
              zipCode,
              String(household),
              householdJson,
              bankRouting,
              bankAccount,
              existing.id
            ]
          );
          upserted = { created: false, id: existing.id };
          if (typeof logContactActivity === "function") {
            try {
              await logContactActivity(
                existing.id,
                "detail_change",
                "EZAPP application submitted — existing contact updated."
              );
            } catch (histErr) {
              console.warn("[insurance-app] activity log:", histErr.message || histErr);
            }
          }
          return;
        }

        const result = await run(
          `INSERT INTO contacts (
             full_name, middle_name, email, phone, status, tags, notes, special_notes, lead_source,
             gender, date_of_birth, profession, health_issues, coverage_start_date,
             height, weight, ssn_last4,
             home_address, city, state, zip_code, household_size, household_members,
             bank_routing, bank_account, application_submitted_at, updated_at
           ) VALUES (
             ?, ?, ?, ?, 'New Lead', ?, ?, ?, 'Insurance Application',
             ?, ?, ?, ?, ?,
             ?, ?, ?,
             ?, ?, ?, ?, ?, ?,
             ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
           )`,
          [
            fullName,
            middleName,
            email,
            phone,
            appTags.join(","),
            notes,
            packet,
            gender,
            dateOfBirth,
            profession,
            healthIssues,
            coverageStart,
            height,
            weight,
            ssnLast4,
            homeAddress,
            city,
            state,
            zipCode,
            String(household),
            householdJson,
            bankRouting,
            bankAccount
          ]
        );
        upserted = { created: true, id: result && result.lastID };
      });

      const notifyTo =
        String(cfg.notify_email || "").trim() ||
        String(process.env.TRIAL_SIGNUP_NOTIFY_EMAIL || "").trim() ||
        String(process.env.CONTACT_SALES_NOTIFY_EMAIL || "").trim() ||
        String(process.env.SMTP_FROM || process.env.SMTP_USER || "").trim();

      if (notifyTo && typeof sendNotifyEmail === "function") {
        try {
          await sendNotifyEmail({
            to: notifyTo,
            subject: `${upserted.created ? "New" : "Updated"} insurance application: ${fullName}`,
            text: [
              upserted.created
                ? `A health insurance application was submitted for EZAPP entry.`
                : `A health insurance application was submitted for EZAPP entry. An existing Cadence contact was updated (matched by email or unique name) instead of creating a duplicate.`,
              ``,
              `Primary:  ${fullName}`,
              `Email:    ${email}`,
              `Phone:    ${phone}`,
              `Start:    ${str(body.coverage_start_date, 40)}`,
              `Household size: ${household}`,
              `Add-ons:  ${addOns.length ? addOns.join(" + ") : "(none)"}`,
              ``,
              `Open the contact in Cadence CRM — Special Notes contains the full EZAPP packet.`
            ].join("\n")
          });
          console.log(`[insurance-app] Notification email sent to ${notifyTo}`);
        } catch (notifyErr) {
          console.warn("[insurance-app] Notification email failed:", notifyErr.message || notifyErr);
        }
      } else {
        console.warn(
          "[insurance-app] No notification email configured. Set Lead Capture → Lead Notification Email (or TRIAL_SIGNUP_NOTIFY_EMAIL / SMTP_FROM)."
        );
      }

      // Optional: also create the contact on another Cadence site (e.g. cadencecrm.pro).
      // Does not block the applicant response if the mirror is down.
      void mirrorInsuranceApplication(body, req);

      res.json({ ok: true });
    } catch (err) {
      console.error("[insurance-app] POST /api/apply error:", err.message || err);
      res.status(500).json({ error: "Something went wrong. Please try again." });
    }
  });
}

module.exports = {
  registerInsuranceApplicationRoutes,
  buildInsuranceApplicationHtml,
  buildEzappPacket
};
