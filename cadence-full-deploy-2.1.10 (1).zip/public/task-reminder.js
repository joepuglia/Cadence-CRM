/**
 * Shared “task due today” reminder: opens a modal from one hour before the
 * scheduled local time until the agent clicks Confirm. Used on Live Dashboard,
 * Contacts Workspace, and Calendar.
 */
(function taskReminderIife() {
  const LEGACY_DISMISSED_KEY = "crm_homeTaskReminderDismissedIds";
  const DISMISSED_KEY = "crm_taskReminderDismissedIds";
  const MS_BEFORE = 60 * 60 * 1000;
  const POLL_MS = 30_000;

  const MODAL_HTML = `
<div id="cadenceTaskReminderModal" class="contact-modal hidden" aria-hidden="true">
  <div class="contact-modal-backdrop"></div>
  <div class="contact-modal-card home-task-reminder-card" role="dialog" aria-modal="true" aria-labelledby="cadenceTaskReminderTitle">
    <div class="contact-modal-header">
      <h3 id="cadenceTaskReminderTitle">Task due today</h3>
    </div>
    <p class="home-task-reminder-lead">This task reaches its scheduled time within the next hour.</p>
    <dl class="home-task-reminder-dl">
      <div><dt>Task</dt><dd id="cadenceTaskReminderName">—</dd></div>
      <div><dt>Action</dt><dd id="cadenceTaskReminderAction">—</dd></div>
      <div><dt>Contact</dt><dd id="cadenceTaskReminderContact">—</dd></div>
      <div><dt>Scheduled</dt><dd id="cadenceTaskReminderWhen">—</dd></div>
    </dl>
    <p class="home-task-reminder-hint" id="cadenceTaskReminderHint"></p>
    <div class="contact-modal-actions home-task-reminder-actions">
      <a id="cadenceTaskReminderOpenContact" class="home-task-reminder-open" href="#">Open contact</a>
      <button type="button" id="cadenceTaskReminderConfirmBtn">Confirm</button>
    </div>
  </div>
</div>`;

  let legacyDismissedMerged = false;
  let tasksCache = [];
  let pollId = null;
  let edgeTimer = null;
  let currentTaskId = null;
  let listenersWired = false;

  let modalEl;
  let confirmBtn;
  let nameEl;
  let actionEl;
  let contactEl;
  let whenEl;
  let hintEl;
  let openContactEl;

  function ensureModal() {
    let el = document.getElementById("cadenceTaskReminderModal");
    if (!el) {
      document.body.insertAdjacentHTML("beforeend", MODAL_HTML.trim());
      el = document.getElementById("cadenceTaskReminderModal");
    }
    modalEl = el;
    if (!modalEl) return null;
    confirmBtn = document.getElementById("cadenceTaskReminderConfirmBtn");
    nameEl = document.getElementById("cadenceTaskReminderName");
    actionEl = document.getElementById("cadenceTaskReminderAction");
    contactEl = document.getElementById("cadenceTaskReminderContact");
    whenEl = document.getElementById("cadenceTaskReminderWhen");
    hintEl = document.getElementById("cadenceTaskReminderHint");
    openContactEl = document.getElementById("cadenceTaskReminderOpenContact");
    if (!listenersWired) {
      listenersWired = true;
      if (confirmBtn) {
        confirmBtn.addEventListener("click", () => {
          if (currentTaskId != null) addDismissedTaskId(currentTaskId);
          hideModal();
          maybeShow();
          scheduleEdge();
        });
      }
    }
    return modalEl;
  }

  function mergeLegacyDismissedOnce() {
    if (legacyDismissedMerged) return;
    legacyDismissedMerged = true;
    try {
      const raw = sessionStorage.getItem(LEGACY_DISMISSED_KEY);
      if (!raw) return;
      const arr = JSON.parse(raw);
      if (!Array.isArray(arr)) {
        sessionStorage.removeItem(LEGACY_DISMISSED_KEY);
        return;
      }
      const set = readDismissedSet(DISMISSED_KEY);
      for (const n of arr.map(Number)) {
        if (Number.isInteger(n) && n > 0) set.add(n);
      }
      sessionStorage.setItem(DISMISSED_KEY, JSON.stringify([...set]));
      sessionStorage.removeItem(LEGACY_DISMISSED_KEY);
    } catch {
      try {
        sessionStorage.removeItem(LEGACY_DISMISSED_KEY);
      } catch {
        // no-op
      }
    }
  }

  function readDismissedSet(key) {
    try {
      const raw = sessionStorage.getItem(key);
      const arr = raw ? JSON.parse(raw) : [];
      if (!Array.isArray(arr)) return new Set();
      return new Set(arr.map((n) => Number(n)).filter((n) => Number.isInteger(n) && n > 0));
    } catch {
      return new Set();
    }
  }

  function getDismissedTaskIds() {
    mergeLegacyDismissedOnce();
    return readDismissedSet(DISMISSED_KEY);
  }

  function addDismissedTaskId(taskId) {
    mergeLegacyDismissedOnce();
    const set = readDismissedSet(DISMISSED_KEY);
    set.add(Number(taskId));
    sessionStorage.setItem(DISMISSED_KEY, JSON.stringify([...set]));
  }

  function getLocalYmd(d) {
    const y = d.getFullYear();
    return `${y}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  }

  function parseTaskLocalDueMs(taskDate, taskTime) {
    const d = String(taskDate || "").trim();
    const t = String(taskTime || "").trim();
    const md = /^(\d{4})-(\d{2})-(\d{2})$/.exec(d);
    const mt = /^(\d{2}):(\d{2})$/.exec(t);
    if (!md || !mt) return NaN;
    const dt = new Date(Number(md[1]), Number(md[2]) - 1, Number(md[3]), Number(mt[1]), Number(mt[2]), 0, 0);
    const ms = dt.getTime();
    return Number.isFinite(ms) ? ms : NaN;
  }

  function formatUpcomingDueLabel(taskDateRaw, taskTimeRaw) {
    const dateRaw = String(taskDateRaw || "").trim();
    const timeRaw = String(taskTimeRaw || "").trim();
    if (!dateRaw) return "Due: No schedule";
    const dt = new Date(`${dateRaw}T${timeRaw || "23:59:59"}`);
    if (!Number.isFinite(dt.getTime())) return `Due: ${dateRaw}`;
    const datePart = dt.toLocaleDateString();
    const timePart = timeRaw
      ? dt.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })
      : "No time set";
    return `Due: ${datePart} • ${timePart}`;
  }

  function getNextReminder(nowMs = Date.now()) {
    const dismissed = getDismissedTaskIds();
    const today = getLocalYmd(new Date(nowMs));
    const rows = [];
    for (const task of tasksCache) {
      const id = Number(task?.id);
      if (!Number.isInteger(id) || id < 1) continue;
      const cond = String(task?.condition || "").trim().toLowerCase();
      if (cond === "completed") continue;
      const dateStr = String(task?.task_date || "").trim();
      const timeStr = String(task?.task_time || "").trim();
      if (dateStr !== today) continue;
      if (!/^\d{2}:\d{2}$/.test(timeStr)) continue;
      const dueMs = parseTaskLocalDueMs(dateStr, timeStr);
      if (!Number.isFinite(dueMs)) continue;
      if (nowMs < dueMs - MS_BEFORE) continue;
      if (dismissed.has(id)) continue;
      rows.push({ task, id, dueMs });
    }
    rows.sort((a, b) => a.dueMs - b.dueMs || a.id - b.id);
    return rows[0] || null;
  }

  function hideModal() {
    if (!modalEl) return;
    modalEl.classList.add("hidden");
    modalEl.setAttribute("aria-hidden", "true");
    currentTaskId = null;
  }

  function showModal(entry) {
    if (!modalEl || !entry?.task) return;
    const { task, id, dueMs } = entry;
    currentTaskId = id;
    const nowMs = Date.now();
    if (nameEl) nameEl.textContent = String(task.task_name || "—").trim() || "—";
    if (actionEl) actionEl.textContent = String(task.action_type || "—").trim() || "—";
    const cid = Number(task.contact_id);
    const contactLabel = String(task.contact_name || (Number.isInteger(cid) && cid > 0 ? `Contact #${cid}` : "—")).trim();
    if (contactEl) contactEl.textContent = contactLabel || "—";
    if (whenEl) whenEl.textContent = formatUpcomingDueLabel(task.task_date, task.task_time);
    if (hintEl) {
      const minsLeft = Math.round((dueMs - nowMs) / 60000);
      if (minsLeft > 1) hintEl.textContent = `About ${minsLeft} minutes until the scheduled time.`;
      else if (minsLeft === 1) hintEl.textContent = "About 1 minute until the scheduled time.";
      else hintEl.textContent = "The scheduled time is now or has already passed.";
    }
    if (openContactEl) {
      if (Number.isInteger(cid) && cid > 0) {
        openContactEl.href = `/contact.html?id=${encodeURIComponent(cid)}&full=1&focus=tasks#contactTasksSection`;
        openContactEl.classList.remove("hidden");
      } else {
        openContactEl.setAttribute("href", "#");
        openContactEl.classList.add("hidden");
      }
    }
    modalEl.classList.remove("hidden");
    modalEl.setAttribute("aria-hidden", "false");
    if (confirmBtn && typeof confirmBtn.focus === "function") {
      try {
        confirmBtn.focus();
      } catch {
        // no-op
      }
    }
  }

  function maybeShow() {
    if (!modalEl) return;
    if (!modalEl.classList.contains("hidden")) return;
    const next = getNextReminder();
    if (!next) return;
    showModal(next);
  }

  function stopWatcher() {
    if (pollId != null) {
      clearInterval(pollId);
      pollId = null;
    }
    if (edgeTimer != null) {
      clearTimeout(edgeTimer);
      edgeTimer = null;
    }
  }

  function scheduleEdge() {
    if (edgeTimer != null) {
      clearTimeout(edgeTimer);
      edgeTimer = null;
    }
    if (!modalEl) return;
    const nowMs = Date.now();
    const dismissed = getDismissedTaskIds();
    const today = getLocalYmd(new Date(nowMs));
    let soonest = Infinity;
    for (const task of tasksCache) {
      const id = Number(task?.id);
      if (!Number.isInteger(id) || id < 1 || dismissed.has(id)) continue;
      const cond = String(task?.condition || "").trim().toLowerCase();
      if (cond === "completed") continue;
      const dateStr = String(task?.task_date || "").trim();
      const timeStr = String(task?.task_time || "").trim();
      if (dateStr !== today) continue;
      if (!/^\d{2}:\d{2}$/.test(timeStr)) continue;
      const dueMs = parseTaskLocalDueMs(dateStr, timeStr);
      if (!Number.isFinite(dueMs)) continue;
      const edge = dueMs - MS_BEFORE;
      if (edge > nowMs) soonest = Math.min(soonest, edge);
    }
    if (!Number.isFinite(soonest) || soonest === Infinity) return;
    const delay = Math.min(Math.max(0, soonest - nowMs + 1), 24 * 60 * 60 * 1000);
    edgeTimer = window.setTimeout(() => {
      edgeTimer = null;
      maybeShow();
      scheduleEdge();
    }, delay);
  }

  function start(tasks) {
    ensureModal();
    if (!modalEl) return;
    tasksCache = Array.isArray(tasks) ? tasks : [];
    stopWatcher();
    if (currentTaskId != null) {
      const still = tasksCache.some((t) => Number(t?.id) === currentTaskId);
      if (!still) hideModal();
    }
    maybeShow();
    scheduleEdge();
    pollId = window.setInterval(() => {
      maybeShow();
    }, POLL_MS);
  }

  window.CadenceTaskReminder = { start, stop: stopWatcher };
})();
