(function initRolePlayPage() {
  const statusBadgeEl = document.getElementById("rolePlayStatusBadge");
  const statusTextEl = document.getElementById("rolePlayStatusText");
  const scenarioEl = document.getElementById("rolePlayScenario");
  const difficultyEl = document.getElementById("rolePlayDifficulty");
  const startBtn = document.getElementById("rolePlayStartBtn");
  const hintBtn = document.getElementById("rolePlayHintBtn");
  const endBtn = document.getElementById("rolePlayEndBtn");
  const sendBtn = document.getElementById("rolePlaySendBtn");
  const micBtn = document.getElementById("rolePlayMicBtn");
  const micHint = document.getElementById("rolePlayMicHint");
  const messageEl = document.getElementById("rolePlayMessage");
  const composerEl = document.getElementById("rolePlayComposer");
  const transcriptEl = document.getElementById("rolePlayTranscript");
  const errorEl = document.getElementById("rolePlayError");
  const kickerEl = document.getElementById("rolePlayChatKicker");
  const titleEl = document.getElementById("rolePlayChatTitle");
  const hintCard = document.getElementById("rolePlayHintCard");
  const hintText = document.getElementById("rolePlayHintText");
  const debriefCard = document.getElementById("rolePlayDebriefCard");
  const contactSearch = document.getElementById("rolePlayContactSearch");
  const contactIdEl = document.getElementById("rolePlayContactId");
  const contactResults = document.getElementById("rolePlayContactResults");
  const contactChip = document.getElementById("rolePlayContactChip");
  const contactChipLabel = document.getElementById("rolePlayContactChipLabel");
  const contactClear = document.getElementById("rolePlayContactClear");

  let sessionId = "";
  let busy = false;
  let searchTimer = 0;
  let recognition = null;
  let listening = false;
  let speechBase = "";
  let speechFinal = "";
  let autoSendAfterSpeech = false;

  const SpeechRecognitionCtor =
    typeof window !== "undefined"
      ? window.SpeechRecognition || window.webkitSpeechRecognition || null
      : null;

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function formatFetchError(err) {
    const msg = String(err?.message || err || "").trim();
    if (/failed to fetch|fetch failed|networkerror|load failed/i.test(msg)) {
      return "Could not reach the CRM server. Refresh and try again.";
    }
    return msg || "Request failed.";
  }

  async function fetchApiJson(path, init) {
    let response;
    try {
      response = await fetch(path, {
        credentials: "include",
        ...(init || {})
      });
    } catch (err) {
      throw new Error(formatFetchError(err));
    }
    let data = {};
    try {
      data = await response.json();
    } catch {
      data = {};
    }
    return { response, data };
  }

  function setStatus(state, text) {
    if (statusBadgeEl) statusBadgeEl.dataset.state = state;
    if (statusTextEl) statusTextEl.textContent = text;
  }

  function showError(text) {
    if (!errorEl) return;
    const msg = String(text || "").trim();
    errorEl.textContent = msg;
    errorEl.hidden = !msg;
  }

  function setBusy(next) {
    busy = Boolean(next);
    const onCall = Boolean(sessionId);
    if (startBtn) startBtn.disabled = busy;
    if (hintBtn) hintBtn.disabled = busy || !onCall;
    if (endBtn) endBtn.disabled = busy || !onCall;
    if (sendBtn) sendBtn.disabled = busy || !onCall;
    if (messageEl) messageEl.disabled = busy || !onCall;
    if (micBtn) {
      const speechOk = Boolean(SpeechRecognitionCtor);
      micBtn.disabled = busy || !onCall || !speechOk;
      if (!speechOk) {
        micBtn.title = "Speech-to-text needs Chrome, Edge, or Safari";
      }
    }
    if (startBtn) startBtn.textContent = busy && !onCall ? "Starting..." : onCall ? "New call" : "Start call";
    if (sendBtn) sendBtn.textContent = busy && onCall ? "..." : "Send";
  }

  function setListeningUi(on) {
    listening = Boolean(on);
    if (micBtn) {
      micBtn.classList.toggle("is-listening", listening);
      micBtn.setAttribute("aria-pressed", listening ? "true" : "false");
      const label = micBtn.querySelector(".role-play-mic-label");
      if (label) label.textContent = listening ? "Stop" : "Talk";
      micBtn.title = listening ? "Stop listening" : "Talk instead of typing";
    }
    if (micHint) micHint.hidden = !listening;
  }

  function stopListening(opts) {
    const options = opts || {};
    autoSendAfterSpeech = Boolean(options.autoSend);
    if (recognition && listening) {
      try {
        recognition.stop();
      } catch {
        /* ignore */
      }
    } else {
      setListeningUi(false);
      autoSendAfterSpeech = false;
    }
  }

  function startListening() {
    if (!SpeechRecognitionCtor || !sessionId || busy || listening) return;
    showError("");
    speechBase = String(messageEl?.value || "").trim();
    speechFinal = "";
    autoSendAfterSpeech = false;
    if (!recognition) {
      recognition = new SpeechRecognitionCtor();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = "en-US";
      recognition.maxAlternatives = 1;
      recognition.onresult = (event) => {
        let interim = "";
        let finals = "";
        for (let i = event.resultIndex; i < event.results.length; i += 1) {
          const piece = String(event.results[i][0]?.transcript || "");
          if (event.results[i].isFinal) finals += piece;
          else interim += piece;
        }
        if (finals) speechFinal = (speechFinal + " " + finals).replace(/\s+/g, " ").trim();
        const live = [speechBase, speechFinal, interim].filter(Boolean).join(" ").replace(/\s+/g, " ").trim();
        if (messageEl) messageEl.value = live;
      };
      recognition.onerror = (event) => {
        const code = String(event?.error || "");
        if (code === "aborted" || code === "no-speech") return;
        if (code === "not-allowed" || code === "service-not-allowed") {
          showError("Microphone permission blocked. Allow mic access, then try Talk again.");
        } else if (code === "network") {
          showError("Speech service could not connect. Check your network and try again.");
        } else {
          showError("Could not hear that. Try Talk again or type your line.");
        }
      };
      recognition.onend = () => {
        setListeningUi(false);
        const text = String(messageEl?.value || "").trim();
        if (autoSendAfterSpeech && text && sessionId && !busy) {
          autoSendAfterSpeech = false;
          sendTurn({ preventDefault() {} });
        } else {
          autoSendAfterSpeech = false;
        }
      };
    }
    try {
      recognition.start();
      setListeningUi(true);
    } catch (err) {
      showError(err?.message || "Could not start the microphone.");
      setListeningUi(false);
    }
  }

  function toggleMic() {
    if (!SpeechRecognitionCtor) {
      showError("Speech-to-text needs Chrome, Edge, or Safari on this device.");
      return;
    }
    if (!sessionId || busy) return;
    if (listening) stopListening({ autoSend: true });
    else startListening();
  }

  function appendBubble(role, text) {
    if (!transcriptEl) return;
    const empty = transcriptEl.querySelector(".role-play-empty");
    if (empty) empty.remove();
    const row = document.createElement("div");
    row.className = "role-play-bubble role-play-bubble--" + (role === "agent" ? "agent" : "prospect");
    row.innerHTML =
      '<span class="role-play-bubble-label">' +
      (role === "agent" ? "You" : "Prospect") +
      "</span><p>" +
      escapeHtml(text) +
      "</p>";
    transcriptEl.appendChild(row);
    transcriptEl.scrollTop = transcriptEl.scrollHeight;
  }

  function resetTranscript(placeholder) {
    if (!transcriptEl) return;
    transcriptEl.innerHTML = '<div class="role-play-empty">' + escapeHtml(placeholder) + "</div>";
  }

  function hideResults() {
    if (contactResults) {
      contactResults.innerHTML = "";
      contactResults.hidden = true;
    }
  }

  function renderContactResults(rows, emptyText) {
    if (!contactResults) return;
    const items = Array.isArray(rows) ? rows : [];
    if (!items.length) {
      contactResults.innerHTML =
        '<li class="assistant-contact-empty">' + escapeHtml(emptyText || "No contacts found.") + "</li>";
      contactResults.hidden = false;
      return;
    }
    contactResults.innerHTML = items
      .map(
        (c) =>
          `<li><button type="button" class="assistant-contact-pick" data-id="${escapeHtml(c.id)}" data-name="${escapeHtml(
            c.full_name || ""
          )}">${escapeHtml(c.full_name || "Unnamed")}<span class="assistant-contact-pick__meta">${escapeHtml(
            [c.outcome, c.email].filter(Boolean).join(" - ")
          )}</span></button></li>`
      )
      .join("");
    contactResults.hidden = false;
    contactResults.querySelectorAll(".assistant-contact-pick").forEach((btn) => {
      btn.addEventListener("click", () => {
        selectContact({
          id: btn.getAttribute("data-id"),
          full_name: btn.getAttribute("data-name")
        });
      });
    });
  }

  async function searchContacts(q) {
    const query = String(q || "").trim();
    const dedicated = "/api/role-play/contacts" + (query ? "?q=" + encodeURIComponent(query) : "");
    let { response, data } = await fetchApiJson(dedicated);
    if (response.status === 404) {
      ({ response, data } = await fetchApiJson(
        "/api/contacts?q=" +
          encodeURIComponent(query) +
          "&page=1&limit=12&sortBy=full_name&sortOrder=asc"
      ));
    }
    if (!response.ok) {
      throw new Error(data.error || "Could not load contacts.");
    }
    return Array.isArray(data?.items) ? data.items : Array.isArray(data?.contacts) ? data.contacts : [];
  }

  function scheduleContactSearch(q, emptyText) {
    window.clearTimeout(searchTimer);
    searchTimer = window.setTimeout(async () => {
      try {
        const rows = await searchContacts(q);
        renderContactResults(rows, emptyText);
      } catch (err) {
        renderContactResults([], err.message || "Could not load contacts.");
      }
    }, 180);
  }

  function clearContact() {
    if (contactIdEl) contactIdEl.value = "";
    if (contactSearch) {
      contactSearch.value = "";
      contactSearch.hidden = false;
    }
    if (contactChip) contactChip.hidden = true;
    hideResults();
  }

  function selectContact(contact) {
    if (contactIdEl) contactIdEl.value = String(contact.id || "");
    if (contactChipLabel) contactChipLabel.textContent = contact.full_name || "Contact";
    if (contactChip) contactChip.hidden = false;
    if (contactSearch) {
      contactSearch.value = "";
      contactSearch.hidden = true;
    }
    hideResults();
  }

  async function loadStatus() {
    try {
      const { response, data } = await fetchApiJson("/api/role-play/status");
      if (!response.ok) throw new Error(data.error || "Could not check AI.");
      if (data.configured) setStatus("ready", "Claude ready");
      else setStatus("unconfigured", "Add ANTHROPIC_API_KEY to enable role play");
    } catch (err) {
      setStatus("error", err.message || "AI status unavailable");
    }
  }

  async function loadScenarios() {
    const { response, data } = await fetchApiJson("/api/role-play/scenarios");
    if (!response.ok) throw new Error(data.error || "Could not load scenarios.");
    const rows = Array.isArray(data.scenarios) ? data.scenarios : [];
    if (!scenarioEl) return;
    scenarioEl.innerHTML = rows
      .map(
        (s) =>
          `<option value="${escapeHtml(s.id)}">${escapeHtml(s.label)}${
            s.insurance ? " — " + escapeHtml(s.insurance) : ""
          }</option>`
      )
      .join("");
  }

  async function startCall() {
    showError("");
    if (listening) stopListening({ autoSend: false });
    if (debriefCard) debriefCard.hidden = true;
    if (hintCard) hintCard.hidden = true;
    sessionId = "";
    setBusy(true);
    resetTranscript("Connecting...");
    try {
      const { response, data } = await fetchApiJson("/api/role-play/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          scenarioId: scenarioEl?.value || "",
          difficulty: difficultyEl?.value || "typical",
          contactId: contactIdEl?.value || ""
        })
      });
      if (!response.ok) throw new Error(data.error || "Could not start the call.");
      sessionId = String(data.sessionId || "");
      const label = data.scenario?.label || "Practice call";
      if (kickerEl) kickerEl.textContent = data.contactName ? "Role play as " + data.contactName : "Live role play";
      if (titleEl) titleEl.textContent = label;
      resetTranscript("");
      appendBubble("prospect", data.prospectMessage || "");
      messageEl?.focus();
    } catch (err) {
      resetTranscript("Choose a scenario, then start the call. The prospect speaks first.");
      showError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function sendTurn(event) {
    if (event && typeof event.preventDefault === "function") event.preventDefault();
    if (listening) stopListening({ autoSend: false });
    if (!sessionId || busy) return;
    const text = String(messageEl?.value || "").trim();
    if (!text) return;
    showError("");
    messageEl.value = "";
    speechBase = "";
    speechFinal = "";
    appendBubble("agent", text);
    setBusy(true);
    try {
      const { response, data } = await fetchApiJson("/api/role-play/turn", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId, message: text })
      });
      if (!response.ok) throw new Error(data.error || "Could not send that line.");
      appendBubble("prospect", data.prospectMessage || "");
    } catch (err) {
      showError(err.message);
    } finally {
      setBusy(false);
      messageEl?.focus();
    }
  }

  async function requestHint() {
    if (!sessionId || busy) return;
    showError("");
    setBusy(true);
    try {
      const { response, data } = await fetchApiJson("/api/role-play/hint", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId })
      });
      if (!response.ok) throw new Error(data.error || "Could not load a hint.");
      if (hintText) hintText.textContent = data.hint || "";
      if (hintCard) hintCard.hidden = false;
    } catch (err) {
      showError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function endCall() {
    if (!sessionId || busy) return;
    if (listening) stopListening({ autoSend: false });
    showError("");
    setBusy(true);
    try {
      const { response, data } = await fetchApiJson("/api/role-play/end", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId })
      });
      if (!response.ok) throw new Error(data.error || "Could not score the call.");
      const d = data.debrief || {};
      document.getElementById("rolePlayScoreLine").textContent = "Score: " + (d.score || "—") + " / 10";
      document.getElementById("rolePlayWhatWorked").textContent = d.whatWorked || "—";
      document.getElementById("rolePlayBetterQuestion").textContent = d.betterQuestion || "—";
      document.getElementById("rolePlayLineToUse").textContent = d.lineToUse || "—";
      document.getElementById("rolePlayWatchOut").textContent = d.watchOut || "—";
      if (debriefCard) debriefCard.hidden = false;
      sessionId = "";
      if (kickerEl) kickerEl.textContent = "Call ended";
      if (titleEl) titleEl.textContent = data.scenario?.label || "Scorecard ready";
    } catch (err) {
      showError(err.message);
    } finally {
      setBusy(false);
    }
  }

  contactClear?.addEventListener("click", clearContact);
  contactSearch?.addEventListener("focus", () => {
    if (contactChip && !contactChip.hidden) return;
    scheduleContactSearch(contactSearch.value, "No contacts found.");
  });
  contactSearch?.addEventListener("input", () => {
    const q = String(contactSearch.value || "").trim();
    scheduleContactSearch(q, q ? "No matching contacts." : "No contacts found.");
  });
  document.addEventListener("click", (event) => {
    if (!event.target.closest(".assistant-contact-field")) hideResults();
  });

  startBtn?.addEventListener("click", startCall);
  hintBtn?.addEventListener("click", requestHint);
  endBtn?.addEventListener("click", endCall);
  micBtn?.addEventListener("click", toggleMic);
  composerEl?.addEventListener("submit", sendTurn);
  messageEl?.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      if (listening) stopListening({ autoSend: false });
      composerEl?.requestSubmit();
    }
  });

  if (micBtn && !SpeechRecognitionCtor) {
    micBtn.disabled = true;
    micBtn.title = "Speech-to-text needs Chrome, Edge, or Safari";
  }

  function loadSetupRobot() {
    const host = document.getElementById("rolePlayRobotHost");
    if (!host || host.querySelector("lottie-player")) return;

    function mount() {
      if (!host.isConnected || host.querySelector("lottie-player")) return;
      host.innerHTML =
        '<lottie-player src="/ai-robot.json?v=20260825csmooth5" background="transparent" speed="1" loop autoplay></lottie-player>';
    }

    function ensurePlayer() {
      try {
        if (window.customElements && customElements.get("lottie-player")) {
          mount();
          return;
        }
      } catch {
        /* ignore */
      }
      const existing = document.querySelector('script[src*="lottie-player"]');
      const startWait = () => {
        if (window.customElements && customElements.whenDefined) {
          customElements.whenDefined("lottie-player").then(mount).catch(mount);
        } else {
          window.setTimeout(mount, 50);
        }
      };
      if (existing) {
        startWait();
        return;
      }
      const script = document.createElement("script");
      script.src = "/vendor/lottie-player.js?v=208";
      script.async = true;
      script.onload = startWait;
      script.onerror = function () {};
      document.head.appendChild(script);
    }

    const start = () => {
      if (window.requestIdleCallback) window.requestIdleCallback(ensurePlayer, { timeout: 800 });
      else window.setTimeout(ensurePlayer, 120);
    };
    if (document.readyState === "complete") start();
    else window.addEventListener("load", start, { once: true });
  }

  Promise.all([loadStatus(), loadScenarios()]).catch((err) => {
    setStatus("error", err.message || "Could not load role play.");
  });
  loadSetupRobot();
})();
