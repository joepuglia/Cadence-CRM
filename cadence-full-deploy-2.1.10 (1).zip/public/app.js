﻿function crmIndianFieldLabel() {
  return String(window.__CRM_INDIAN_FIELD_LABEL__ || "").trim() || "Indian";
}

function crmIndianFieldOmitted() {
  return Boolean(window.__CRM_OMIT_INDIAN_WORKSPACE__);
}

// ── Contact segment tabs (All / Leads / Clients) ──────────────────────────────
let activeContactView = "all"; // "all" | "leads" | "clients"

function getClientStatusLabels() {
  if (window.CrmContactWorkspaceOptions && typeof window.CrmContactWorkspaceOptions.getClientStatusLabels === "function") {
    return window.CrmContactWorkspaceOptions.getClientStatusLabels();
  }
  return ["APS", "APPROVED", "SOLD", "CLOSED"];
}

function setActiveContactView(view) {
  activeContactView = view;
  document.querySelectorAll(".contacts-view-tab").forEach((btn) => {
    const isActive = btn.getAttribute("data-view") === view;
    btn.classList.toggle("active", isActive);
    btn.setAttribute("aria-selected", isActive ? "true" : "false");
  });
}

document.querySelectorAll(".contacts-view-tab").forEach((btn) => {
  btn.addEventListener("click", () => {
    const view = btn.getAttribute("data-view");
    setActiveContactView(view);
    // Clear any manual status dropdown selection — tabs define the segment
    if (statusFilter) statusFilter.value = "";
    currentPage = 1;
    loadContacts().catch((e) => showMessage(e.message, true));
  });
});
async function loadContactTabCounts() {
  try {
    const { response, data } = await fetchApiJson("/api/contacts/tab-counts");
    if (!response.ok) return;
    const { all, leads, clients } = data || {};
    document.querySelectorAll(".contacts-view-tab").forEach((btn) => {
      const view = btn.getAttribute("data-view");
      const count = view === "all" ? all : view === "leads" ? leads : view === "clients" ? clients : null;
      if (count == null) return;
      let badge = btn.querySelector(".tab-count-badge");
      if (!badge) {
        badge = document.createElement("span");
        badge.className = "tab-count-badge";
        btn.appendChild(badge);
      }
      badge.textContent = count.toLocaleString("en-US");
    });
  } catch (_) {}
}
loadContactTabCounts();
// ──────────────────────────────────────────────────────────────────────────────

const contactsBody = document.getElementById("contactsBody");
const contactsCardsEl = document.getElementById("contactsCards");
const selectAllContactsMobile = document.getElementById("selectAllContactsMobile");
const contactsListHost = document.querySelector(".contacts-list-host");
const messageEl = document.getElementById("message");
const searchInput = document.getElementById("searchInput");
const clearSearchBtn = document.getElementById("clearSearchBtn");
const statusFilter = document.getElementById("statusFilter");
const outcomeFilter = document.getElementById("outcomeFilter");
const contactsFilterSelect = document.getElementById("contactsFilterSelect");
const contactsTasksBtn = document.getElementById("contactsTasksBtn");
const importCsvBtn = document.getElementById("importCsvBtn");
const scoreLeadsBtn = document.getElementById("scoreLeadsBtn");
const contactCountEl = document.getElementById("contactCount");
const selectedCountEl = document.getElementById("selectedCount");
const selectAllContacts = document.getElementById("selectAllContacts");
document.addEventListener("change", (event) => {
  const t = event.target;
  if (!t || (t.id !== "selectAllContacts" && t.id !== "selectAllContactsMobile")) return;
  // Defined later; only runs after full script parse when user interacts.
  if (typeof handleSelectAllContactsChange === "function") {
    handleSelectAllContactsChange(Boolean(t.checked)).catch((e) => {
      if (typeof showMessage === "function") showMessage(e.message, true);
    });
  }
});
const prevPageBtn = document.getElementById("prevPageBtn");
const nextPageBtn = document.getElementById("nextPageBtn");
const pageInfoEl = document.getElementById("pageInfo");
const sortByLabelEl = document.getElementById("sortByLabel");
const activeFiltersEl = document.getElementById("activeFilters");
const activeFiltersRowEl = document.querySelector(".active-filters-row");
const quickFilterFieldSelect = document.getElementById("quickFilterField");
const quickFilterDropdown = document.getElementById("quickFilterDropdown");
const tagsFilterTermInput = document.getElementById("tagsFilterTerm");
const statusHeaderDropdown = document.getElementById("statusHeaderDropdown");
const createdDateFromInput = document.getElementById("createdDateFrom");
const createdDateToInput = document.getElementById("createdDateTo");
const clearAllFiltersBtn = document.getElementById("clearAllFiltersBtn");
const contactsStateFilter = document.getElementById("contactsStateFilter");
const bulkActionSelect = document.getElementById("bulkActionSelect");
const applyBulkActionBtn = document.getElementById("applyBulkActionBtn");
const bulkTagsModal = document.getElementById("bulkTagsModal");
const bulkTagsModalForm = document.getElementById("bulkTagsModalForm");
const bulkTagsModalTitle = document.getElementById("bulkTagsModalTitle");
const bulkTagsModalInput = document.getElementById("bulkTagsModalInput");
const bulkTagsModalSubmitBtn = document.getElementById("bulkTagsModalSubmitBtn");
const bulkTagsModalCloseBtn = document.getElementById("bulkTagsModalCloseBtn");
const bulkStatusModal = document.getElementById("bulkStatusModal");
const bulkStatusModalForm = document.getElementById("bulkStatusModalForm");
const bulkStatusModalTitle = document.getElementById("bulkStatusModalTitle");
const bulkStatusModalLabel = document.getElementById("bulkStatusModalLabel");
const bulkStatusModalSelect = document.getElementById("bulkStatusModalSelect");
const bulkStatusModalSubmitBtn = document.getElementById("bulkStatusModalSubmitBtn");
const bulkStatusModalCloseBtn = document.getElementById("bulkStatusModalCloseBtn");
const contactDetailModal = document.getElementById("contactDetailModal");
const contactModalForm = document.getElementById("contactModalForm");
const contactModalCloseBtn = document.getElementById("contactModalCloseBtn");
const contactModalSmsBtn = document.getElementById("contactModalSmsBtn");
const contactModalEmailBtn = document.getElementById("contactModalEmailBtn");
const contactModalCallBtn = document.getElementById("contactModalCallBtn");
const contactModalDeleteBtn = document.getElementById("contactModalDeleteBtn");
const addContactModal = document.getElementById("addContactModal");
const addContactPopupForm = document.getElementById("addContactPopupForm");
const addContactModalCloseBtn = document.getElementById("addContactModalCloseBtn");
const addContactContinueBtn = document.getElementById("addContactContinueBtn");
const addContactStatus = document.getElementById("addContactStatus");
const twilioModal = document.getElementById("twilioModal");
const twilioSmsPopupForm = document.getElementById("twilioSmsPopupForm");
const twilioCallPopupForm = document.getElementById("twilioCallPopupForm");
const twilioModalCloseBtn = document.getElementById("twilioModalCloseBtn");
const twilioPopupStatus = document.getElementById("twilioPopupStatus");
const twilioEndCallBtn = document.getElementById("twilioEndCallBtn");
const twilioCallUseHeadset = document.getElementById("twilioCallUseHeadset");
const twilioCallRecord = document.getElementById("twilioCallRecord");
const contactModalCallRecord = document.getElementById("contactModalCallRecord");
const contactModalCallUseHeadset = document.getElementById("contactModalCallUseHeadset");
const morningBriefingModal = document.getElementById("morningBriefingModal");
const morningBriefingContent = document.getElementById("morningBriefingContent");
const morningBriefingCloseBtn = document.getElementById("morningBriefingCloseBtn");
const morningBriefingDismissBtn = document.getElementById("morningBriefingDismissBtn");
let twilioCallStatusPollTimer = null;
let activeTwilioCallSid = "";
let activeTwilioCallMode = "";
/** When set, Twilio SMS popup sends via POST /api/contacts/bulk-send-sms instead of single send. */
let twilioBulkSmsContactIds = null;
const selectedContactIds = new Set();
let currentPage = 1;
/** Bumps on each loadContacts(); stale in-flight requests must not overwrite UI. */
let loadContactsGeneration = 0;
/** When set, the list is ordered by `outcome` (Contact Details field); toggled via the Outcome column header. */
let sortByOutcomeColumn = null;
const pageLimit = 25;
let totalContacts = 0;
let activeContact = null;
let currentPageContactIds = [];
let contactIdsFilter = [];
const CONTACT_IDS_SESSION_KEY = "cadencePendingContactIdsFilter";
const CONTACT_IDS_URL_CHAR_LIMIT = 900;
const CONTACT_IDS_URL_COUNT_LIMIT = 40;
const CONTACTS_LIST_URL_CHAR_LIMIT = 1800;
let pipelineContactIdsAutoCleared = false;
const BULK_ACTION_USAGE_KEY = "crm.bulkActionUsage";
const EMAIL_ATTACHMENT_PREF_KEY = "crm.emailAttachmentDocumentIds";
let lastFilteredContactIds = [];
/** True after Select All loads the full filtered ID set (not just the current page). */
let selectEntireFilteredSet = false;
let selectAllFilterKey = "";
/** Selected US state filter (full name, matches contact form `state` field). */
function getContactsWorkspaceFilterState() {
  return String(contactsStateFilter?.value || "").trim();
}
const contactsTopbarAddContactBtn = document.getElementById("contactsTopbarAddContactBtn");
const contactsTopbarQuickActionsBtn = document.getElementById("contactsTopbarQuickActionsBtn");
const contactsTopbarQuickActionsMenu = document.getElementById("contactsTopbarQuickActionsMenu");
const contactsTopbarQuickActionsWrap = document.getElementById("contactsTopbarQuickActionsWrap");
const contactsEmptyState = document.getElementById("contactsEmptyState");
const contactsFilteredEmptyState = document.getElementById("contactsFilteredEmptyState");
const contactsEmptyAddBtn = document.getElementById("contactsEmptyAddBtn");
const contactsEmptyImportBtn = document.getElementById("contactsEmptyImportBtn");
const contactsFilteredEmptyClearBtn = document.getElementById("contactsFilteredEmptyClearBtn");
const contactsBulkActionsEl = document.querySelector(".bulk-actions");
const contactsTableWrap = document.querySelector(".contacts-table-wrap");
const contactsTopMetaEl = document.querySelector(".contacts-top-meta");
const contactsMobileSelectAllLabel = document.querySelector(".contacts-mobile-select-all");

/**
 * Drip badge: active enrollment with pending sends -> "Enrolled Live"; active enrollment in progress (no badge);
 * no active enrollments and finished drips only -> "Drip Completed" (red).
 */
function enrollmentBadgeHtml(activeCampaignCount, dripPendingCount, dripCompletedCampaignCount) {
  const ac = Number(activeCampaignCount || 0);
  const dp = Number(dripPendingCount || 0);
  const dc = Number(dripCompletedCampaignCount || 0);
  if (ac > 0) {
    if (dp > 0) {
      const suffix = ac > 1 ? ` (${ac})` : "";
      return `<span class="contact-enrolled-badge contact-enrolled-badge--live">Enrolled Live${suffix}</span>`;
    }
    return "";
  }
  if (dc > 0) {
    const suffix = dc > 1 ? ` (${dc})` : "";
    return `<span class="contact-enrolled-badge contact-enrolled-badge--completed">Drip Completed${suffix}</span>`;
  }
  return "";
}

async function ensureContactWorkspaceOptionsReady() {
  if (!window.CrmContactWorkspaceOptions) return;
  try {
    if (typeof window.CrmContactWorkspaceOptions.reloadAndApply === "function") {
      await window.CrmContactWorkspaceOptions.reloadAndApply(document);
    } else {
      await window.CrmContactWorkspaceOptions.load(true);
      window.CrmContactWorkspaceOptions.applyAll(document);
    }
  } catch {
    window.CrmContactWorkspaceOptions.applyAll(document);
  }
}

function workspaceFieldLabel(fieldValue, fallback) {
  if (window.CrmContactWorkspaceOptions?.getQuickFilterFieldLabel) {
    return window.CrmContactWorkspaceOptions.getQuickFilterFieldLabel(fieldValue, fallback);
  }
  return fallback || fieldValue;
}

/** List filters use the same status values as Contact Details (Settings - Contact Workspace labels). */
function getContactDetailStatusValues() {
  if (window.CrmContactWorkspaceOptions && typeof window.CrmContactWorkspaceOptions.getStatusLabels === "function") {
    return window.CrmContactWorkspaceOptions.getStatusLabels();
  }
  const source = document.getElementById("contactStatusSelect");
  if (!source || !source.options.length) {
    return ["NEW", "PENDING", "APPROVED", "DECLINED", "CLOSED", "WORKING", "NOT TAKEN"];
  }
  return [...source.options].map((o) => String(o.value || o.textContent).trim()).filter(Boolean);
}

function sortOutcomeLabels(values) {
  return [...values].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));
}

function getContactDetailOutcomeValues() {
  if (window.CrmContactWorkspaceOptions && typeof window.CrmContactWorkspaceOptions.getOutcomeLabels === "function") {
    return window.CrmContactWorkspaceOptions.getOutcomeLabels();
  }
  const source = document.getElementById("contactOutcomeSelect");
  if (!source || !source.options.length) {
    return sortOutcomeLabels([]);
  }
  return sortOutcomeLabels(
    [...source.options]
      .filter(
        (o) => !(o.hasAttribute("value") && String(o.getAttribute("value") ?? "").trim() === "")
      )
      .map((o) => String(o.value || o.textContent).trim())
      .filter(Boolean)
  );
}

function getContactDetailLeadSourceValues() {
  if (window.CrmContactWorkspaceOptions && typeof window.CrmContactWorkspaceOptions.getLeadSourceLabels === "function") {
    return window.CrmContactWorkspaceOptions.getLeadSourceLabels();
  }
  const source = document.getElementById("lead_source");
  if (!source || !source.options.length) {
    return [];
  }
  return [...source.options]
    .filter((o) => !(o.hasAttribute("value") && String(o.getAttribute("value") ?? "").trim() === ""))
    .map((o) => String(o.value || o.textContent).trim())
    .filter(Boolean);
}

function syncToolbarStatusesFromContactDetails() {
  const statuses = getContactDetailStatusValues();
  const outcomes = getContactDetailOutcomeValues();
  const rebuild = (selectEl, emptyValue, emptyLabel) => {
    if (!selectEl) return;
    const prev = selectEl.value;
    selectEl.replaceChildren();
    const allOpt = document.createElement("option");
    allOpt.value = emptyValue;
    allOpt.textContent = emptyLabel;
    selectEl.appendChild(allOpt);
    for (const s of statuses) {
      const opt = document.createElement("option");
      opt.value = s;
      opt.textContent = s;
      selectEl.appendChild(opt);
    }
    if (prev !== emptyValue && statuses.includes(prev)) selectEl.value = prev;
    else selectEl.value = emptyValue;
  };
  rebuild(statusFilter, "", "Select Status");

  if (outcomeFilter && window.CrmContactWorkspaceOptions?.fillGroupedOutcomeSelect) {
    window.CrmContactWorkspaceOptions.fillGroupedOutcomeSelect(outcomeFilter, outcomes, "", "Select Outcome");
  }
}

function toDateInputValue(raw) {
  const s = String(raw || "").trim();
  if (!s) return "";
  let m = /^(\d{4})-(\d{1,2})-(\d{1,2})/.exec(s);
  if (m) {
    return `${m[1]}-${String(Number(m[2])).padStart(2, "0")}-${String(Number(m[3])).padStart(2, "0")}`;
  }
  m = /^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})$/.exec(s);
  if (m) {
    return `${m[3]}-${String(Number(m[1])).padStart(2, "0")}-${String(Number(m[2])).padStart(2, "0")}`;
  }
  return "";
}

function formatCommissionValue(raw) {
  const value = String(raw == null ? "" : raw).trim();
  if (!value) return "";
  return value.startsWith("$") ? value : `$${value}`;
}

/** Numeric income -> $85,000; labels like Low/Medium/High stay as entered. */
function formatIncomeValue(raw) {
  const value = String(raw == null ? "" : raw).trim();
  if (!value) return "";
  const stripped = value.replace(/[$,\s]/g, "");
  if (/^-?\d+(\.\d+)?$/.test(stripped)) {
    const num = Number(stripped);
    if (Number.isFinite(num)) {
      return new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: "USD",
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
      }).format(num);
    }
  }
  return value;
}

function apiUrl(path) {
  if (!window.CrmApi?.apiUrl) {
    const p = path.startsWith("/") ? path : `/${path}`;
    return p;
  }
  return window.CrmApi.apiUrl(path);
}

function fetchApiJson(pathAndQuery, init) {
  if (!window.CrmApi?.fetchApiJson) {
    throw new Error("CRM API helper failed to load. Hard-refresh this page.");
  }
  return window.CrmApi.fetchApiJson(pathAndQuery, init);
}

function isStaleFetchConfigErrorMessage(text) {
  return /web page instead of JSON/i.test(String(text || ""));
}

const TASK_REMINDER_REFRESH_MS = 90_000;

async function syncTaskReminders() {
  if (typeof window.CadenceTaskReminder?.start !== "function") return;
  try {
    const { response, data } = await fetchApiJson("/api/tasks/upcoming?limit=100");
    if (!response.ok) return;
    const rows = Array.isArray(data) ? data : [];
    window.CadenceTaskReminder.start(rows);
  } catch {
    // ignore (offline / not logged in)
  }
}

function showMessage(text, isError = false) {
  const str = String(text == null ? "" : text);
  if (isError && typeof window.crmHandleAuthErrorMessage === "function" && window.crmHandleAuthErrorMessage(str, isError)) {
    return;
  }
  messageEl.textContent = str;
  messageEl.style.color = isError ? "#c62828" : "#1b5e20";
}

function getInitials(name) {
  const pieces = String(name || "")
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  if (!pieces.length) return "?";
  if (pieces.length === 1) return pieces[0].slice(0, 2).toUpperCase();
  return `${pieces[0][0]}${pieces[1][0]}`.toUpperCase();
}

function getAvatarStyle(name) {
  const s = String(name || "").trim();
  let hash = 0;
  for (let i = 0; i < s.length; i += 1) {
    hash = (hash * 31 + s.charCodeAt(i)) >>> 0;
  }
  const hue = hash % 360;
  return {
    background: `hsl(${hue} 78% 92%)`,
    color: `hsl(${hue} 62% 36%)`
  };
}

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

const MORNING_BRIEFING_SEEN_KEY = "crm.morningBriefingSeenDate";

const MORNING_BRIEFING_QUOTES = [
  { text: "Success is the sum of small efforts, repeated day in and day out.", author: "Robert Collier" },
  { text: "The secret of getting ahead is getting started.", author: "Mark Twain" },
  { text: "Don't watch the clock; do what it does. Keep going.", author: "Sam Levenson" },
  { text: "Every contact is a conversation waiting to happen.", author: "Cadence CRM" },
  { text: "Opportunities don't happen. You create them.", author: "Chris Grosser" },
  { text: "The harder you work for something, the greater you'll feel when you achieve it.", author: "Unknown" },
  { text: "Your pipeline reflects your habits. Show up for it today.", author: "Cadence CRM" },
  { text: "Act as if what you do makes a difference. It does.", author: "William James" },
  { text: "Quality means doing it right when no one is looking.", author: "Henry Ford" },
  { text: "The best way to predict the future is to create it.", author: "Peter Drucker" },
  { text: "Small daily improvements are the key to staggering long-term results.", author: "Unknown" },
  { text: "You don't have to be great to start, but you have to start to be great.", author: "Zig Ziglar" },
  { text: "Focus on progress, not perfection.", author: "Unknown" },
  { text: "A goal without a plan is just a wish.", author: "Antoine de Saint-Exupéry" },
  { text: "Today's follow-up is tomorrow's enrolled client.", author: "Cadence CRM" },
  { text: "Discipline is choosing between what you want now and what you want most.", author: "Abraham Lincoln" },
  { text: "The only place where success comes before work is in the dictionary.", author: "Vidal Sassoon" },
  { text: "Be so good they can't ignore you.", author: "Steve Martin" },
  { text: "Energy and persistence conquer all things.", author: "Benjamin Franklin" },
  { text: "Your attitude determines your direction.", author: "Unknown" },
  { text: "Make today so productive that yesterday gets jealous.", author: "Unknown" },
  { text: "Clients buy trust before they buy a policy.", author: "Cadence CRM" },
  { text: "It always seems impossible until it's done.", author: "Nelson Mandela" },
  { text: "Dream big. Start small. Act now.", author: "Robin Sharma" },
  { text: "The difference between try and triumph is a little umph.", author: "Unknown" },
  { text: "You miss 100% of the shots you don't take.", author: "Wayne Gretzky" },
  { text: "Consistency beats intensity when you're building a book of business.", author: "Cadence CRM" },
  { text: "What you get by achieving your goals is not as important as what you become.", author: "Zig Ziglar" },
  { text: "Start where you are. Use what you have. Do what you can.", author: "Arthur Ashe" },
  { text: "Excellence is not a skill. It's an attitude.", author: "Ralph Marston" },
  { text: "The best time to plant a tree was 20 years ago. The second best time is now.", author: "Chinese proverb" },
  { text: "One call today can change someone's coverage—and your month.", author: "Cadence CRM" },
  { text: "Motivation gets you going. Habit keeps you growing.", author: "Unknown" },
  { text: "Do something today that your future self will thank you for.", author: "Unknown" },
  { text: "Clear pipeline, clear mind.", author: "Cadence CRM" },
  { text: "Fortune favors the prepared agent.", author: "Cadence CRM" },
  { text: "Work hard in silence. Let your results speak.", author: "Frank Ocean" },
  { text: "If you're not willing to risk the usual, you'll have to settle for the ordinary.", author: "Jim Rohn" },
  { text: "The way to get started is to quit talking and begin doing.", author: "Walt Disney" },
  { text: "Success usually comes to those who are too busy to be looking for it.", author: "Henry David Thoreau" },
  { text: "Don't count the days. Make the days count.", author: "Muhammad Ali" },
  { text: "Your next client is already in your CRM—reach out.", author: "Cadence CRM" },
];

function getMorningBriefingQuoteOfDay() {
  const key = todayLocalDateKey();
  let hash = 0;
  for (let i = 0; i < key.length; i += 1) {
    hash = (hash * 31 + key.charCodeAt(i)) >>> 0;
  }
  return MORNING_BRIEFING_QUOTES[hash % MORNING_BRIEFING_QUOTES.length];
}

function morningBriefingQuoteHtml() {
  const quote = getMorningBriefingQuoteOfDay();
  return `
    <blockquote class="morning-briefing-quote" aria-label="Quote of the day">
      <p class="morning-briefing-quote-label">Quote of the day</p>
      <p class="morning-briefing-quote-text">&ldquo;${escapeHtml(quote.text)}&rdquo;</p>
      <cite class="morning-briefing-quote-author">&mdash; ${escapeHtml(quote.author)}</cite>
    </blockquote>`;
}

function todayLocalDateKey() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function getMorningBriefingSeenDate() {
  try {
    return localStorage.getItem(MORNING_BRIEFING_SEEN_KEY) || "";
  } catch {
    return "";
  }
}

function markMorningBriefingSeenToday() {
  try {
    localStorage.setItem(MORNING_BRIEFING_SEEN_KEY, todayLocalDateKey());
  } catch {
    // localStorage may be blocked; the briefing can still be shown.
  }
}

function closeMorningBriefing() {
  if (!morningBriefingModal) return;
  morningBriefingModal.classList.add("hidden");
  morningBriefingModal.setAttribute("aria-hidden", "true");
}

function formatBriefingStatValue(value) {
  if (value == null || value === "") return "0";
  const text = String(value).trim();
  if (!text || text === "N/A" || /[a-zA-Z]/.test(text)) return text;
  const numeric = Number(text.replace(/,/g, ""));
  if (Number.isFinite(numeric)) return numeric.toLocaleString("en-US");
  return text;
}

function morningBriefingStat(label, value) {
  return `<div class="morning-briefing-stat"><span>${escapeHtml(label)}</span><strong>${escapeHtml(formatBriefingStatValue(value))}</strong></div>`;
}

function formatBriefingTask(row) {
  const name = String(row?.full_name || row?.email || "Contact").trim();
  const task = String(row?.task_name || "Task").trim();
  const date = String(row?.task_date || "").trim();
  const time = String(row?.task_time || "").trim();
  const when = [date, time].filter(Boolean).join(" ");
  return `${name} - ${task}${when ? ` (${when})` : ""}`;
}

function formatBriefingOutcomeChange(row) {
  const name = String(row?.full_name || row?.email || "Contact").trim();
  const outcome = String(row?.outcome || "Outcome updated").trim();
  return `${name} - ${outcome}`;
}

function briefingActionItems(snapshot) {
  const items = [];
  if (Number(snapshot?.staleLeads || 0) > 0) {
    const n = Number(snapshot.staleLeads);
    items.push(
      `Call ${n.toLocaleString("en-US")} NEW lead${n === 1 ? "" : "s"} with no activity in 7+ days.`
    );
  }
  if (Number(snapshot?.appointmentsScheduled || 0) > 0) {
    const n = Number(snapshot.appointmentsScheduled);
    items.push(
      `Review ${n.toLocaleString("en-US")} scheduled task${n === 1 ? "" : "s"} coming up in the next 7 days.`
    );
  }
  if (Number(snapshot?.newLeads || 0) > 0) {
    const n = Number(snapshot.newLeads);
    items.push(
      `Follow up with ${n.toLocaleString("en-US")} new lead${n === 1 ? "" : "s"} from the last 7 days.`
    );
  }
  if (Number(snapshot?.leadsQuoted || 0) > 0) {
    items.push(`Check quote follow-ups and move serious buyers to the next step.`);
  }
  if (!items.length) items.push("Review Contacts Workspace and add your first follow-up for today.");
  return items.slice(0, 3);
}

function renderMorningBriefing(snapshot) {
  if (!morningBriefingContent) return;
  const soldInPeriod = Number(snapshot?.closedSoldInPeriod ?? 0);
  const lostInPeriod = Number(snapshot?.closedLostInPeriod ?? 0);
  const closeRate =
    snapshot?.closeRate != null && soldInPeriod + lostInPeriod > 0
      ? `${snapshot.closeRate}% (${soldInPeriod} sold / ${lostInPeriod} lost)`
      : soldInPeriod + lostInPeriod === 0
        ? "N/A (no closed deals yet)"
        : "N/A";
  const upcomingTasks = Array.isArray(snapshot?.upcomingTasks) ? snapshot.upcomingTasks.slice(0, 4) : [];
  const recentChanges = Array.isArray(snapshot?.recentOutcomeChanges) ? snapshot.recentOutcomeChanges.slice(0, 4) : [];
  const actions = briefingActionItems(snapshot);
  const listHtml = (items, formatter, emptyText) => {
    if (!items.length) return `<p class="morning-briefing-empty">${escapeHtml(emptyText)}</p>`;
    return `<ul class="morning-briefing-list">${items.map((item) => `<li>${escapeHtml(formatter(item))}</li>`).join("")}</ul>`;
  };
  morningBriefingContent.innerHTML = `
    ${morningBriefingQuoteHtml()}
    <div class="morning-briefing-grid">
      ${morningBriefingStat("New leads - last 7 days", snapshot?.newLeads ?? 0)}
      ${morningBriefingStat("Scheduled - next 7 days", snapshot?.appointmentsScheduled ?? 0)}
      ${morningBriefingStat("NEW no activity 7+ days", snapshot?.staleLeads ?? 0)}
      ${morningBriefingStat("Win rate of closed deals (7d)", closeRate)}
    </div>
    <div class="morning-briefing-split">
      <section class="morning-briefing-panel">
        <h4>Today&apos;s Top Actions</h4>
        <ul class="morning-briefing-list">${actions.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>
      </section>
      <section class="morning-briefing-panel">
        <h4>Pipeline Snapshot</h4>
        <ul class="morning-briefing-list">
          <li>${escapeHtml(formatBriefingStatValue(snapshot?.leadsQuoted ?? 0))} leads have quotes.</li>
          <li>${escapeHtml(formatBriefingStatValue(snapshot?.closedSold ?? 0))} sold / ${escapeHtml(formatBriefingStatValue(snapshot?.closedLost ?? 0))} lost.</li>
          <li>${escapeHtml(formatBriefingStatValue(snapshot?.activeCampaigns ?? 0))} active drip campaign${Number(snapshot?.activeCampaigns || 0) === 1 ? "" : "s"}.</li>
        </ul>
      </section>
      <section class="morning-briefing-panel">
        <h4>Next 7 Days</h4>
        ${listHtml(upcomingTasks, formatBriefingTask, "No scheduled tasks in the next 7 days.")}
      </section>
      <section class="morning-briefing-panel">
        <h4>Recent Outcome Changes</h4>
        ${listHtml(recentChanges, formatBriefingOutcomeChange, "No outcome changes in the last 7 days.")}
      </section>
    </div>`;
}

async function showMorningBriefingOnce() {
  if (!morningBriefingModal || !morningBriefingContent) return;
  if (getMorningBriefingSeenDate() === todayLocalDateKey()) return;
  try {
    const { response, data } = await fetchApiJson("/api/pipeline/morning-briefing?pastDays=7&futureDays=7");
    if (!response.ok) return;
    if (data?.skipMorningBriefing) {
      markMorningBriefingSeenToday();
      return;
    }
    if (!data?.snapshot) return;
    renderMorningBriefing(data.snapshot);
    morningBriefingModal.classList.remove("hidden");
    morningBriefingModal.setAttribute("aria-hidden", "false");
    markMorningBriefingSeenToday();
    if (morningBriefingCloseBtn) morningBriefingCloseBtn.focus();
  } catch (error) {
    console.warn("Morning briefing unavailable:", error);
  }
}

/** Contacts workspace Status column: neutral pill for Call Back; other values keep slug-colored pills. */
function workspaceContactsStatusPillInnerHtml(statusRaw) {
  const label = String(statusRaw ?? "").trim();
  const slug = String(statusRaw || "unknown").toLowerCase().replace(/\s+/g, "-");
  const slugClass = slug === "call-back" ? "" : ` status-${slug}`;
  return `<span class="status-pill${slugClass}">${escapeHtml(label)}</span>`;
}

/** Contacts workspace Outcome column: highlight key outcomes as pills. */
function workspaceContactsOutcomeCellInnerHtml(outcomeRaw) {
  const trimmed = outcomeRaw != null ? String(outcomeRaw).trim() : "";
  if (!trimmed) return escapeHtml("-");
  // Normalize for matching: lowercase + strip all whitespace, so "Call Back",
  // "call back", "Callback", "CALLBACK", "call-back" all collapse to "callback".
  const matchKey = trimmed.toLowerCase().replace(/[\s-]+/g, "");
  if (matchKey === "sold") {
    return `<span class="outcome-pill outcome-sold">${escapeHtml(trimmed)}</span>`;
  }
  if (matchKey === "callback") {
    return `<span class="outcome-pill outcome-call-back">${escapeHtml(trimmed)}</span>`;
  }
  return `<span class="outcome-pill">${escapeHtml(trimmed)}</span>`;
}

/** Contacts workspace Lead Source column: Referral = pink bar + white text; all others indigo + white. */
function workspaceContactsLeadSourceCellInnerHtml(leadSourceRaw) {
  const trimmed = leadSourceRaw != null ? String(leadSourceRaw).trim() : "";
  if (!trimmed || trimmed === "-") return escapeHtml("-");
  const isReferral = trimmed.toLowerCase() === "referral";
  const mod = isReferral ? " lead-source-pill--referral" : "";
  return `<span class="lead-source-pill${mod}">${escapeHtml(trimmed)}</span>`;
}

function workspaceContactsAiScoreHtml(scoreRaw, reasonRaw) {
  const score = Number(scoreRaw);
  if (!Number.isFinite(score) || score <= 0) return `<span class="ai-score-pill ai-score-pill--empty">Not scored</span>`;
  const level = score >= 8 ? "hot" : score >= 5 ? "warm" : "cool";
  const reason = String(reasonRaw || "").trim();
  return `<span class="ai-score-pill ai-score-pill--${level}" title="${escapeHtml(reason)}">${Math.round(score)}/10</span>`;
}

function getContactRowCheckboxes() {
  if (contactsListHost) return contactsListHost.querySelectorAll(".row-select");
  return contactsBody ? contactsBody.querySelectorAll(".row-select") : [];
}

function syncSelectAllCheckboxes(checked) {
  if (selectAllContacts) selectAllContacts.checked = checked;
  if (selectAllContactsMobile) selectAllContactsMobile.checked = checked;
}

function contactSummaryUrl(contactId) {
  return `/contact.html?id=${encodeURIComponent(contactId)}`;
}

function contactDetailsUrl(contactId) {
  return `/contact.html?id=${encodeURIComponent(contactId)}&full=1`;
}

function attachContactListItemHandlers(rootEl, contactId) {
  const rowSelect = rootEl.querySelector(".row-select");
  if (rowSelect) {
    rowSelect.addEventListener("change", () => {
      if (rowSelect.checked) selectedContactIds.add(contactId);
      else {
        selectedContactIds.delete(contactId);
        selectEntireFilteredSet = false;
        syncSelectAllCheckboxes(false);
      }
      updateSelectedCount();
    });
  }
  const nameHit = rootEl.querySelector(".contact-name-hit");
  if (nameHit) {
    nameHit.addEventListener("click", (event) => {
      event.stopPropagation();
      window.location.href = contactDetailsUrl(contactId);
    });
  }
  const openContactSummary = () => {
    window.location.href = contactSummaryUrl(contactId);
  };
  rootEl.addEventListener("click", (event) => {
    const target = event.target;
    if (target?.closest?.("input, button, a, select, label, .contact-name-hit")) return;
    openContactSummary();
  });
}

function appendContactListItem(c, isChecked) {
  const contactId = Number(c.id);
  const initials = getInitials(c.full_name);
  const avatarStyle = getAvatarStyle(c.full_name);
  const safeName = escapeHtml(c.full_name || "");
  const safeEmail = escapeHtml(c.email || "");
  const safePhone = escapeHtml(c.phone || "");
  const noteText = shortText(c.notes || "-", 34);
  const noteFull = escapeHtml(String(c.notes || ""));
  const leadSource = c.lead_source || "-";
  const quoteValue =
    c.quote != null && String(c.quote).trim() ? escapeHtml(formatCommissionValue(String(c.quote))) : "-";
  const enrolledBadge = enrollmentBadgeHtml(
    c.active_campaign_count,
    c.drip_pending_count,
    c.drip_completed_campaign_count
  );
  const statusHtml = workspaceContactsStatusPillInnerHtml(c.status);
  const outcomeHtml = workspaceContactsOutcomeCellInnerHtml(c.outcome);
  const leadSourceHtml = workspaceContactsLeadSourceCellInnerHtml(leadSource);
  const aiScoreHtml = workspaceContactsAiScoreHtml(c.ai_lead_score, c.ai_lead_reason);
  const tagsHtml = String(c.tags || "")
    .split(",")
    .map((t) => t.trim())
    .filter(Boolean)
    .map((t) => `<span class="tag-chip">${escapeHtml(t)}</span>`)
    .join("");

  if (contactsBody) {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><input type="checkbox" class="row-select" data-contact-id="${contactId}" ${isChecked} /></td>
      <td>
        <div class="basic-info-cell">
          <div class="avatar" style="background:${avatarStyle.background};color:${avatarStyle.color};">${initials}</div>
          <div>
            <div class="contact-name"><span class="contact-name-hit">${safeName}</span> ${enrolledBadge}</div>
            <div class="contact-sub">${safeEmail}</div>
            <div class="contact-sub">${safePhone}</div>
            <div class="contact-sub contact-sub-ai-score">${aiScoreHtml}</div>
          </div>
        </div>
      </td>
      <td class="contacts-col-status">${statusHtml}</td>
      <td class="contacts-col-outcome">${outcomeHtml}</td>
      <td class="contacts-col-lead-source">${leadSourceHtml}</td>
      <td class="contacts-col-notes" title="${noteFull}">${escapeHtml(noteText)}</td>
      <td class="contacts-col-quote"><strong>${quoteValue}</strong></td>
      <td>${tagsHtml}</td>
    `;
    attachContactListItemHandlers(tr, contactId);
    contactsBody.appendChild(tr);
  }

  if (contactsCardsEl) {
    const card = document.createElement("article");
    card.className = "contacts-mobile-card";
    card.dataset.contactId = String(contactId);
    card.innerHTML = `
      <div class="contacts-mobile-card-head">
        <input type="checkbox" class="row-select" data-contact-id="${contactId}" ${isChecked} aria-label="Select contact" />
        <div class="basic-info-cell">
          <div class="avatar" style="background:${avatarStyle.background};color:${avatarStyle.color};">${initials}</div>
          <div>
            <div class="contact-name"><span class="contact-name-hit">${safeName}</span> ${enrolledBadge}</div>
            <div class="contact-sub">${safeEmail}</div>
            <div class="contact-sub">${safePhone}</div>
          </div>
        </div>
      </div>
      <div class="contacts-mobile-pills">
        <div class="contacts-mobile-pill-field">
          <span class="contacts-mobile-pill-label">Status</span>
          ${statusHtml}
        </div>
        <div class="contacts-mobile-pill-field">
          <span class="contacts-mobile-pill-label">Outcome</span>
          ${outcomeHtml}
        </div>
        <div class="contacts-mobile-pill-field">
          <span class="contacts-mobile-pill-label">Lead Source</span>
          ${leadSourceHtml}
        </div>
        <div class="contacts-mobile-pill-field">
          <span class="contacts-mobile-pill-label">AI Score</span>
          ${aiScoreHtml}
        </div>
      </div>
      <div class="contacts-mobile-notes" title="${noteFull}">
        <span class="contacts-mobile-meta-label">Call Back Notes</span>
        <span class="contacts-mobile-notes-text">${escapeHtml(noteText)}</span>
      </div>
      <div class="contacts-mobile-footer">
        <div class="contacts-mobile-quote">
          <span class="contacts-mobile-meta-label">Quote</span>
          <strong>${quoteValue}</strong>
        </div>
        <div class="contacts-mobile-tags-wrap">
          <span class="contacts-mobile-meta-label">Tags</span>
          <div class="contacts-mobile-tags">${tagsHtml || '<span class="contacts-mobile-muted">-</span>'}</div>
        </div>
      </div>
    `;
    attachContactListItemHandlers(card, contactId);
    contactsCardsEl.appendChild(card);
  }
}

function shortText(value, max = 28) {
  const s = String(value == null ? "" : value);
  if (s.length <= max) return s;
  return `${s.slice(0, max - 3)}...`;
}

function titleCaseWords(value) {
  return String(value || "")
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .split(" ")
    .filter(Boolean)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

function ensureContactModalFieldLabels() {
  const grid = contactModalForm ? contactModalForm.querySelector(".contact-modal-grid") : null;
  if (!grid) return;
  const fields = [...grid.querySelectorAll("input, select, textarea")];
  let idx = 0;
  for (const field of fields) {
    if (field.type === "hidden") continue;
    if (field.closest(".contact-status-box")) continue;
    if (field.parentElement && field.parentElement.classList.contains("contact-field-box")) continue;
    idx += 1;
    if (!field.id) {
      const safeName = String(field.name || "field").replace(/[^a-zA-Z0-9_-]/g, "_");
      field.id = `contactField_${safeName}_${idx}`;
    }
    const label = document.createElement("label");
    label.className = "contact-modal-field-label";
    label.setAttribute("for", field.id);
    const placeholderText = String(field.getAttribute("placeholder") || "").trim();
    label.textContent = placeholderText || titleCaseWords(field.name || "Field");

    const wrapper = document.createElement("div");
    wrapper.className = "contact-field-box";
    field.parentNode.insertBefore(wrapper, field);
    wrapper.appendChild(label);
    wrapper.appendChild(field);
  }
}

function updateSelectedCount() {
  selectedCountEl.textContent = `${selectedContactIds.size.toLocaleString("en-US")} selected`;
}

function pruneSelectionToCurrentFilter() {
  if (!Array.isArray(lastFilteredContactIds) || !lastFilteredContactIds.length) return;
  const allowed = new Set(lastFilteredContactIds);
  for (const id of [...selectedContactIds]) {
    if (!allowed.has(id)) selectedContactIds.delete(id);
  }
}

function selectedIdsArray() {
  pruneSelectionToCurrentFilter();
  return [...selectedContactIds]
    .map((id) => Number(id))
    .filter((n) => Number.isInteger(n) && n > 0);
}

function openEmailPage(contactIds = []) {
  const ids = [...new Set((Array.isArray(contactIds) ? contactIds : []).map((n) => Number(n)).filter((n) => Number.isInteger(n) && n > 0))];
  const idsStr = ids.join(",");
  // Large selections overflow the URL and the server rejects it (HTTP 414 Request-URI Too Large).
  // Hand the IDs off via sessionStorage with a short one-shot flag; small lists stay in the URL
  // so single-contact "Send Email" links remain shareable.
  if (idsStr.length > 1500) {
    try {
      sessionStorage.setItem("cadencePendingEmailContactIds", idsStr);
    } catch {
      /* storage unavailable — fall through to the URL path below */
    }
    window.location.href = "/email.html?contactBatch=1";
    return;
  }
  try {
    sessionStorage.removeItem("cadencePendingEmailContactIds");
  } catch {
    /* ignore */
  }
  const params = new URLSearchParams();
  if (ids.length) params.set("contactIds", idsStr);
  window.location.href = `/email.html${params.toString() ? `?${params.toString()}` : ""}`;
}

function requireSelection() {
  const ids = selectedIdsArray();
  if (!ids.length) {
    showMessage("Select at least one contact first.", true);
    return null;
  }
  return ids;
}

function promptBulkTagsViaModal(mode) {
  if (!bulkTagsModal || !bulkTagsModalForm || !bulkTagsModalInput || !bulkTagsModalTitle || !bulkTagsModalSubmitBtn) {
    const fallbackLabel = mode === "remove" ? "Tags to remove (comma separated):" : "Tags to add (comma separated):";
    return Promise.resolve(window.prompt(fallbackLabel, ""));
  }
  const isRemove = mode === "remove";
  bulkTagsModalTitle.textContent = isRemove ? "Remove Tags" : "Add Tags";
  bulkTagsModalSubmitBtn.textContent = isRemove ? "Remove Tags" : "Add Tags";
  bulkTagsModalInput.value = "";
  bulkTagsModal.classList.remove("hidden");
  bulkTagsModal.setAttribute("aria-hidden", "false");
  requestAnimationFrame(() => bulkTagsModalInput.focus());

  return new Promise((resolve) => {
    const cleanup = () => {
      bulkTagsModalForm.removeEventListener("submit", onSubmit);
      if (bulkTagsModalCloseBtn) bulkTagsModalCloseBtn.removeEventListener("click", onCancel);
      bulkTagsModal.removeEventListener("click", onBackdrop);
    };
    const close = (value) => {
      cleanup();
      bulkTagsModal.classList.add("hidden");
      bulkTagsModal.setAttribute("aria-hidden", "true");
      resolve(value);
    };
    const onSubmit = (event) => {
      event.preventDefault();
      close(String(bulkTagsModalInput.value || "").trim());
    };
    const onCancel = () => close(null);
    const onBackdrop = (event) => {
      const target = event.target;
      if (target && target.getAttribute && target.getAttribute("data-close-bulk-tags-modal") === "1") onCancel();
    };
    bulkTagsModalForm.addEventListener("submit", onSubmit);
    if (bulkTagsModalCloseBtn) bulkTagsModalCloseBtn.addEventListener("click", onCancel);
    bulkTagsModal.addEventListener("click", onBackdrop);
  });
}

function populateBulkFieldSelect(values, { allowEmpty = false, emptyLabel = "—" } = {}) {
  if (!bulkStatusModalSelect) return;
  const prev = bulkStatusModalSelect.value;
  bulkStatusModalSelect.replaceChildren();
  if (allowEmpty) {
    const emptyOpt = document.createElement("option");
    emptyOpt.value = "";
    emptyOpt.textContent = emptyLabel;
    bulkStatusModalSelect.appendChild(emptyOpt);
  }
  for (const value of values) {
    const opt = document.createElement("option");
    opt.value = value;
    opt.textContent = value;
    bulkStatusModalSelect.appendChild(opt);
  }
  if (prev && [...bulkStatusModalSelect.options].some((o) => o.value === prev)) {
    bulkStatusModalSelect.value = prev;
  }
}

function promptBulkFieldViaModal({ title, label, values, allowEmpty = false, emptyLabel = "—", promptFallback }) {
  if (bulkStatusModalTitle) bulkStatusModalTitle.textContent = title;
  if (bulkStatusModalLabel) bulkStatusModalLabel.textContent = label;
  populateBulkFieldSelect(values, { allowEmpty, emptyLabel });
  if (!bulkStatusModal || !bulkStatusModalForm || !bulkStatusModalSelect) {
    const fallback = window.prompt(promptFallback || `${label}:`, values[0] || "");
    return Promise.resolve(fallback == null ? null : String(fallback).trim());
  }
  bulkStatusModal.classList.remove("hidden");
  bulkStatusModal.setAttribute("aria-hidden", "false");
  requestAnimationFrame(() => bulkStatusModalSelect.focus());

  return new Promise((resolve) => {
    const cleanup = () => {
      bulkStatusModalForm.removeEventListener("submit", onSubmit);
      if (bulkStatusModalCloseBtn) bulkStatusModalCloseBtn.removeEventListener("click", onCancel);
      bulkStatusModal.removeEventListener("click", onBackdrop);
    };
    const close = (value) => {
      cleanup();
      bulkStatusModal.classList.add("hidden");
      bulkStatusModal.setAttribute("aria-hidden", "true");
      resolve(value);
    };
    const onSubmit = (event) => {
      event.preventDefault();
      const value = String(bulkStatusModalSelect.value || "").trim();
      if (!allowEmpty && !value) return;
      close(value);
    };
    const onCancel = () => close(null);
    const onBackdrop = (event) => {
      const target = event.target;
      if (target && target.getAttribute && target.getAttribute("data-close-bulk-status-modal") === "1") onCancel();
    };
    bulkStatusModalForm.addEventListener("submit", onSubmit);
    if (bulkStatusModalCloseBtn) bulkStatusModalCloseBtn.addEventListener("click", onCancel);
    bulkStatusModal.addEventListener("click", onBackdrop);
  });
}

async function promptBulkStatusViaModal() {
  await ensureContactWorkspaceOptionsReady();
  const statusLabel = workspaceFieldLabel("status", "Status");
  return promptBulkFieldViaModal({
    title: `Change ${statusLabel}`,
    label: `New ${statusLabel.toLowerCase()}`,
    values: getContactDetailStatusValues(),
    promptFallback: `New ${statusLabel.toLowerCase()} for selected contacts:`
  });
}

async function promptBulkOutcomeViaModal() {
  await ensureContactWorkspaceOptionsReady();
  const outcomeLabel = workspaceFieldLabel("outcome", "Outcome");
  return promptBulkFieldViaModal({
    title: `Change ${outcomeLabel}`,
    label: `New ${outcomeLabel.toLowerCase()}`,
    values: getContactDetailOutcomeValues(),
    promptFallback: `New ${outcomeLabel.toLowerCase()} for selected contacts:`
  });
}

async function promptBulkLeadSourceViaModal() {
  await ensureContactWorkspaceOptionsReady();
  const leadSourceLabel = workspaceFieldLabel("lead_source", "Lead Source");
  const leadSourceLower = leadSourceLabel.toLowerCase();
  return promptBulkFieldViaModal({
    title: `Change ${leadSourceLabel}`,
    label: `New ${leadSourceLower}`,
    values: getContactDetailLeadSourceValues(),
    allowEmpty: true,
    emptyLabel: `Clear ${leadSourceLower}`,
    promptFallback: `New ${leadSourceLower} for selected contacts:`
  });
}

function parseBulkActionUsage() {
  try {
    const raw = window.localStorage.getItem(BULK_ACTION_USAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

function getPreferredEmailAttachmentIds() {
  try {
    const raw = window.localStorage.getItem(EMAIL_ATTACHMENT_PREF_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(parsed)) return [];
    return [...new Set(parsed.map((v) => Number(v)).filter((n) => Number.isInteger(n) && n > 0))];
  } catch {
    return [];
  }
}

function rememberBulkActionUsage(action) {
  if (!action) return;
  const usage = parseBulkActionUsage();
  usage[action] = Number(usage[action] || 0) + 1;
  try {
    window.localStorage.setItem(BULK_ACTION_USAGE_KEY, JSON.stringify(usage));
  } catch {
    //
  }
}

/** Maps Sort By header dropdown (slug) to API sortBy + sortOrder. */
function getHeaderSortOverride() {
  const v = String(statusHeaderDropdown?.value || "").trim();
  if (!v) return null;
  if (window.CrmContactWorkspaceOptions?.getSortOrderForDropdownValue) {
    return window.CrmContactWorkspaceOptions.getSortOrderForDropdownValue(v);
  }
  const sorts = {
    newest: ["created_at", "desc"],
    details_changed: ["updated_at", "desc"],
    last_emailed: ["last_emailed", "desc"],
    last_sms: ["last_sms", "desc"],
    last_called: ["last_called", "desc"],
    last_tagged: ["last_tagged", "desc"],
    state: ["state", "asc"],
    lead_source: ["lead_source", "asc"],
    ai_lead_score: ["ai_lead_score", "desc"],
    gender: ["gender", "asc"],
    indian: ["indian", "asc"],
    profession: ["profession", "asc"],
    income: ["income", "desc"],
    date_of_contact: ["date_of_contact", "desc"],
    household_size: ["household_size", "desc"]
  };
  const pair = sorts[v];
  if (!pair) return null;
  return { sortBy: pair[0], sortOrder: pair[1] };
}

/** Merge header sort + optional Outcome column sort (API already supports sortBy=outcome). */
function getContactListSort() {
  if (sortByOutcomeColumn) {
    return { sortBy: "outcome", sortOrder: sortByOutcomeColumn };
  }
  const header = getHeaderSortOverride();
  if (header) {
    return { sortBy: header.sortBy, sortOrder: header.sortOrder };
  }
  return { sortBy: "updated_at", sortOrder: "desc" };
}

function quickFilterFieldLabel(field) {
  const value = String(field || "").trim();
  if (window.CrmContactWorkspaceOptions?.getQuickFilterFieldLabel) {
    return window.CrmContactWorkspaceOptions.getQuickFilterFieldLabel(value, value);
  }
  if (value === "indian") return crmIndianFieldLabel();
  if (value === "status") return "Status";
  if (value === "outcome") return "Outcome";
  if (value === "lead_source") return "Lead Source";
  if (value === "tags") return "Tags";
  return value;
}

function buildQuickFilterQuery() {
  const field = String(quickFilterFieldSelect?.value || "tags").trim();
  const mode = String(quickFilterDropdown?.value || "all").trim();
  const term = String(tagsFilterTermInput?.value || "").trim();
  if (mode === "all") return "";
  if (field === "tags") {
    if (mode === "not-defined") return "&tagFilter=not-defined";
    if (mode === "is" && term) return `&tagFilter=is&tagTerm=${encodeURIComponent(term)}`;
    if (mode === "is-not" && term) return `&tagFilter=is-not&tagTerm=${encodeURIComponent(term)}`;
    return "";
  }
  if (field === "status") {
    if (mode === "not-defined") return "&statusLabelMode=not-defined";
    if (mode === "is" && term) {
      return `&statusLabelMode=is&statusLabelTerm=${encodeURIComponent(term)}`;
    }
    if (mode === "is-not" && term) {
      return `&statusLabelMode=is-not&statusLabelTerm=${encodeURIComponent(term)}`;
    }
    return "";
  }
  if (field === "outcome") {
    if (mode === "not-defined") return "&outcomeLabelMode=not-defined";
    if (mode === "is" && term) {
      return `&outcomeLabelMode=is&outcomeLabelTerm=${encodeURIComponent(term)}`;
    }
    if (mode === "is-not" && term) {
      return `&outcomeLabelMode=is-not&outcomeLabelTerm=${encodeURIComponent(term)}`;
    }
    return "";
  }
  if (field === "lead_source") {
    if (mode === "not-defined") return "&leadSourceMode=not-defined";
    if (mode === "is" && term) {
      return `&leadSourceMode=is&leadSourceTerm=${encodeURIComponent(term)}`;
    }
    if (mode === "is-not" && term) {
      return `&leadSourceMode=is-not&leadSourceTerm=${encodeURIComponent(term)}`;
    }
    return "";
  }
  if (field === "indian") {
    if (mode === "not-defined") return "&indianMode=not-defined";
    if (mode === "is" && term) {
      return `&indianMode=is&indianTerm=${encodeURIComponent(term)}`;
    }
    if (mode === "is-not" && term) {
      return `&indianMode=is-not&indianTerm=${encodeURIComponent(term)}`;
    }
    return "";
  }
  if (mode === "not-defined") return `&qfField=${encodeURIComponent(field)}&qfMode=not-defined`;
  if (mode === "is" && term) {
    return `&qfField=${encodeURIComponent(field)}&qfMode=is&qfTerm=${encodeURIComponent(term)}`;
  }
  if (mode === "is-not" && term) {
    return `&qfField=${encodeURIComponent(field)}&qfMode=is-not&qfTerm=${encodeURIComponent(term)}`;
  }
  return "";
}

function buildLeadSourceFilterQuery() {
  const val = String(contactsFilterSelect?.value || "").trim();
  if (!val) return "";
  return `&leadSourceMode=is&leadSourceTerm=${encodeURIComponent(val)}`;
}

function buildCreatedDateRangeQuery() {
  const from = String(createdDateFromInput?.value || "").trim();
  const to = String(createdDateToInput?.value || "").trim();
  const fromParam = from ? `&createdFrom=${encodeURIComponent(from)}` : "";
  const toParam = to ? `&createdTo=${encodeURIComponent(to)}` : "";
  return `${fromParam}${toParam}`;
}

function updateTagsFilterControls() {
  const field = String(quickFilterFieldSelect?.value || "tags").trim();
  const mode = String(quickFilterDropdown?.value || "");
  if (tagsFilterTermInput) {
    tagsFilterTermInput.disabled = mode === "all" || mode === "not-defined";
    const fieldLabel = quickFilterFieldLabel(field);
    tagsFilterTermInput.placeholder =
      mode === "all" ? "Value" : mode === "not-defined" ? "-" : field === "indian" ? `${fieldLabel} (Yes/No)` : fieldLabel;
  }
}

function renderActiveFilters() {
  const chips = [];
  const q = String(searchInput.value || "").trim();
  if (q) chips.push(`Search: ${q}`);
  if (statusFilter.value) chips.push(`Status: ${statusFilter.value}`);
  if (outcomeFilter?.value) chips.push(`Outcome: ${outcomeFilter.value}`);
  if (contactsFilterSelect?.value) chips.push(`Lead Source: ${contactsFilterSelect.value}`);
  const tfMode = String(quickFilterDropdown?.value || "all").trim();
  const tfTerm = String(tagsFilterTermInput?.value || "").trim();
  const tfField = String(quickFilterFieldSelect?.value || "tags").trim();
  const tfFieldLabel = quickFilterFieldLabel(tfField);
  if (tfMode !== "all") {
    if (tfMode === "not-defined") chips.push(`${tfFieldLabel}: IS NOT DEFINED`);
    else if (tfMode === "is" && tfTerm) chips.push(`${tfFieldLabel}: IS "${tfTerm}"`);
    else if (tfMode === "is-not" && tfTerm) chips.push(`${tfFieldLabel}: IS NOT "${tfTerm}"`);
  }
  const createdFrom = String(createdDateFromInput?.value || "").trim();
  const createdTo = String(createdDateToInput?.value || "").trim();
  if (createdFrom || createdTo) {
    const fromLabel = createdFrom || "Any";
    const toLabel = createdTo || "Any";
    chips.push(`Created: ${fromLabel} to ${toLabel}`);
  }
  if (contactIdsFilter.length) chips.push(`Pipeline selection: ${contactIdsFilter.length} contacts`);
  const filterState = getContactsWorkspaceFilterState();
  if (filterState) {
    chips.push(`State: ${filterState}`);
  }

  activeFiltersEl.innerHTML = chips.map((chip) => `<span class="filter-chip">${chip}</span>`).join("");
  if (activeFiltersRowEl) {
    activeFiltersRowEl.style.display = chips.length ? "flex" : "none";
  }
}

function hasActiveContactsListFilters() {
  const q = String(searchInput?.value || "").trim();
  if (q) return true;
  if (statusFilter?.value) return true;
  if (outcomeFilter?.value) return true;
  if (contactsFilterSelect?.value) return true;
  const tfMode = String(quickFilterDropdown?.value || "all").trim();
  const tfTerm = String(tagsFilterTermInput?.value || "").trim();
  if (tfMode !== "all") {
    if (tfMode === "not-defined") return true;
    if ((tfMode === "is" || tfMode === "is-not") && tfTerm) return true;
  }
  const createdFrom = String(createdDateFromInput?.value || "").trim();
  const createdTo = String(createdDateToInput?.value || "").trim();
  if (createdFrom || createdTo) return true;
  if (contactIdsFilter.length) return true;
  if (getContactsWorkspaceFilterState()) return true;
  return false;
}

function updateContactsEmptyState() {
  const filtersActive = hasActiveContactsListFilters();
  const isWorkspaceEmpty = totalContacts === 0 && !filtersActive;
  const isFilteredEmpty = totalContacts === 0 && filtersActive;
  const hideList = isWorkspaceEmpty || isFilteredEmpty;

  if (contactsEmptyState) contactsEmptyState.classList.toggle("hidden", !isWorkspaceEmpty);
  if (contactsFilteredEmptyState) contactsFilteredEmptyState.classList.toggle("hidden", !isFilteredEmpty);
  if (contactsTableWrap) contactsTableWrap.classList.toggle("hidden", hideList);
  if (contactsCardsEl) contactsCardsEl.classList.toggle("hidden", hideList);
  if (contactsBulkActionsEl) contactsBulkActionsEl.classList.toggle("hidden", hideList);
  if (contactsMobileSelectAllLabel) contactsMobileSelectAllLabel.classList.toggle("hidden", hideList);
  if (contactsTopMetaEl) contactsTopMetaEl.classList.toggle("hidden", totalContacts === 0);
}

/** US state names - must match contact form `state` options (full names). */
const CONTACT_WORKSPACE_US_STATES = [
  "Alabama",
  "Alaska",
  "Arizona",
  "Arkansas",
  "California",
  "Colorado",
  "Connecticut",
  "Delaware",
  "Florida",
  "Georgia",
  "Hawaii",
  "Idaho",
  "Illinois",
  "Indiana",
  "Iowa",
  "Kansas",
  "Kentucky",
  "Louisiana",
  "Maine",
  "Maryland",
  "Massachusetts",
  "Michigan",
  "Minnesota",
  "Mississippi",
  "Missouri",
  "Montana",
  "Nebraska",
  "Nevada",
  "New Hampshire",
  "New Jersey",
  "New Mexico",
  "New York",
  "North Carolina",
  "North Dakota",
  "Ohio",
  "Oklahoma",
  "Oregon",
  "Pennsylvania",
  "Rhode Island",
  "South Carolina",
  "South Dakota",
  "Tennessee",
  "Texas",
  "Utah",
  "Vermont",
  "Virginia",
  "Washington",
  "West Virginia",
  "Wisconsin",
  "Wyoming"
];

function initContactsWorkspaceStateFilter() {
  if (!contactsStateFilter) return;
  for (const st of CONTACT_WORKSPACE_US_STATES) {
    const opt = document.createElement("option");
    opt.value = st;
    opt.textContent = st;
    contactsStateFilter.appendChild(opt);
  }
  contactsStateFilter.addEventListener("change", () => {
    document.querySelectorAll(".quick-filter-btn").forEach((b) => b.classList.remove("active"));
    currentPage = 1;
    loadContacts().catch((err) => showMessage(err.message, true));
  });
}

function parseContactIdsList(raw) {
  return [
    ...new Set(
      String(raw || "")
        .split(",")
        .map((value) => Number(String(value || "").trim()))
        .filter((value) => Number.isInteger(value) && value > 0)
    )
  ];
}

function contactIdsUrlTooLarge(ids) {
  const list = Array.isArray(ids) ? ids : [];
  if (list.length > CONTACT_IDS_URL_COUNT_LIMIT) return true;
  return list.join(",").length > CONTACT_IDS_URL_CHAR_LIMIT;
}

function storeContactIdsFilter(ids) {
  try {
    sessionStorage.setItem(CONTACT_IDS_SESSION_KEY, (Array.isArray(ids) ? ids : []).join(","));
  } catch {
    /* ignore */
  }
}

function clearStoredContactIdsFilter() {
  try {
    sessionStorage.removeItem(CONTACT_IDS_SESSION_KEY);
  } catch {
    /* ignore */
  }
}

function readStoredContactIdsFilter() {
  try {
    return parseContactIdsList(sessionStorage.getItem(CONTACT_IDS_SESSION_KEY) || "");
  } catch {
    return [];
  }
}

function clearPipelineContactIdsFromUrl() {
  const url = new URL(window.location.href);
  url.searchParams.delete("contactIdBatch");
  url.searchParams.delete("contactIds");
  const next = `${url.pathname}${url.search}${url.hash}`;
  if (next !== `${window.location.pathname}${window.location.search}${window.location.hash}`) {
    window.history.replaceState({}, "", next);
  }
}

function clearPipelineContactIdsFilter(options = {}) {
  const had = contactIdsFilter.length > 0;
  contactIdsFilter = [];
  clearStoredContactIdsFilter();
  clearPipelineContactIdsFromUrl();
  if (options.resetApiCache) window.CrmApi?.resetApiBaseCache?.();
  return had;
}

function contactsListUsesPost() {
  if (contactIdsUrlTooLarge(contactIdsFilter)) return true;
  return buildContactsListPath().length > CONTACTS_LIST_URL_CHAR_LIMIT;
}

function buildContactsListPath({ omitContactIds = false } = {}) {
  const rawQuery = String(searchInput.value || "");
  const q = encodeURIComponent(rawQuery);
  const status = encodeURIComponent(statusFilter.value || "");
  const outcome = encodeURIComponent(outcomeFilter?.value || "");
  const tagQuery = buildQuickFilterQuery();
  const createdRangeQuery = buildCreatedDateRangeQuery();
  const { sortBy, sortOrder } = getContactListSort();
  const indianFieldActive =
    String(quickFilterFieldSelect?.value || "").trim() === "indian" ? "&indianSortFirst=1" : "";
  const filterState = getContactsWorkspaceFilterState();
  const stateFilter =
    filterState !== "" ? `&contactState=${encodeURIComponent(filterState)}` : "";
  const leadSourceQuery = buildLeadSourceFilterQuery();
  const idsFilter =
    !omitContactIds && contactIdsFilter.length && !contactIdsUrlTooLarge(contactIdsFilter)
      ? `&contactIds=${encodeURIComponent(contactIdsFilter.join(","))}`
      : "";
  // Segment view: Clients = SOLD (status or tag), Leads = NOT SOLD
  let viewQuery = "";
  if (activeContactView === "clients" || activeContactView === "leads") {
    viewQuery = `&contactViewSegment=${encodeURIComponent(activeContactView)}`;
  }
  return `/api/contacts?q=${q}&status=${status}&outcome=${outcome}&sortBy=${encodeURIComponent(sortBy)}&sortOrder=${encodeURIComponent(sortOrder || "desc")}${tagQuery}${indianFieldActive}${stateFilter}${leadSourceQuery}${createdRangeQuery}${idsFilter}${viewQuery}`;
}

function buildContactsListFilterPayload() {
  const path = buildContactsListPath({ omitContactIds: true });
  const queryStart = path.indexOf("?");
  const params = new URLSearchParams(queryStart >= 0 ? path.slice(queryStart + 1) : "");
  const payload = {};
  for (const [key, value] of params.entries()) payload[key] = value;
  if (contactIdsFilter.length) payload.contactIds = contactIdsFilter.join(",");
  return payload;
}

async function fetchContactsListPage(page, limit, { allowPipelineRetry = true, attempt = 0, idsOnly = false, allIds = false } = {}) {
  try {
    if (contactsListUsesPost()) {
      const payload = buildContactsListFilterPayload();
      payload.page = page;
      payload.limit = limit;
      if (idsOnly) payload.idsOnly = "1";
      if (allIds) payload.allIds = "1";
      let listUrl = "/api/contacts/list";
      if (idsOnly) listUrl = allIds ? "/api/contacts/list?idsOnly=1&allIds=1" : "/api/contacts/list?idsOnly=1";
      return await fetchApiJson(listUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        timeoutMs: idsOnly ? 120000 : 30000
      });
    }
    const listPath = buildContactsListPath();
    const idsQs = idsOnly ? `&idsOnly=1${allIds ? "&allIds=1" : ""}` : "";
    return await fetchApiJson(`${listPath}&page=${page}&limit=${limit}${idsQs}`, {
      timeoutMs: idsOnly ? 120000 : 30000
    });
  } catch (error) {
    const msg = String(error?.message || "");
    const recoverable =
      allowPipelineRetry &&
      contactIdsFilter.length > 0 &&
      /web page instead of json|too large|414|invalid json from api|api request failed/i.test(msg);
    if (recoverable) {
      clearPipelineContactIdsFilter({ resetApiCache: true });
      pipelineContactIdsAutoCleared = true;
      return fetchContactsListPage(page, limit, { allowPipelineRetry: false, attempt, idsOnly, allIds });
    }
    if (attempt < 1 && /timed out|failed to fetch|networkerror|load failed|api request failed/i.test(msg)) {
      await new Promise((r) => setTimeout(r, 600));
      return fetchContactsListPage(page, limit, { allowPipelineRetry, attempt: attempt + 1, idsOnly, allIds });
    }
    throw error;
  }
}

async function fetchApiResponse(pathAndQuery, init) {
  if (window.CrmApi?.fetchApi) return window.CrmApi.fetchApi(pathAndQuery, init);
  return fetch(apiUrl(pathAndQuery), { credentials: "include", ...(init || {}) });
}

function updateContactsPaginationUi(page, maxPage) {
  const safeMax = Math.max(1, Number(maxPage) || 1);
  const safePage = Math.min(Math.max(1, Number(page) || 1), safeMax);
  if (pageInfoEl) pageInfoEl.textContent = `Page ${safePage} of ${safeMax}`;
  if (prevPageBtn) prevPageBtn.disabled = safePage <= 1;
  if (nextPageBtn) nextPageBtn.disabled = safePage >= safeMax;
}

async function loadContacts() {
  const loadGen = ++loadContactsGeneration;
  const isStale = () => loadGen !== loadContactsGeneration;
  const { sortBy, sortOrder } = getContactListSort();
  if (sortByOutcomeColumn) {
    sortByLabelEl.textContent = `Outcome (${sortByOutcomeColumn === "asc" ? "A-Z" : "Z-A"})`;
  } else if (statusHeaderDropdown?.value) {
    const opt = statusHeaderDropdown.options[statusHeaderDropdown.selectedIndex];
    sortByLabelEl.textContent = opt ? String(opt.textContent || "").trim() || "Sort" : "Sort";
  } else {
    sortByLabelEl.textContent = "Details Changed";
  }
  const contactsSummary = document.querySelector(".contacts-summary");
  if (contactsSummary) {
    contactsSummary.textContent = `Filter: ${sortByLabelEl.textContent}`;
  }
  const outcomeSortBtn = document.getElementById("contactsSortOutcomeBtn");
  const outcomeArrow = outcomeSortBtn?.querySelector(".contacts-sort-arrow");
  if (outcomeArrow) {
    if (sortByOutcomeColumn === "asc") outcomeArrow.textContent = "\u2191";
    else if (sortByOutcomeColumn === "desc") outcomeArrow.textContent = "\u2193";
    else outcomeArrow.textContent = "";
  }
  if (outcomeSortBtn) {
    outcomeSortBtn.classList.toggle("is-active", Boolean(sortByOutcomeColumn));
    outcomeSortBtn.setAttribute(
      "aria-sort",
      sortByOutcomeColumn === "asc" ? "ascending" : sortByOutcomeColumn === "desc" ? "descending" : "none"
    );
  }
  renderActiveFilters();
  const listPath = buildContactsListPath();
  if (selectEntireFilteredSet && selectAllFilterKey && selectAllFilterKey !== listPath) {
    selectEntireFilteredSet = false;
    selectAllFilterKey = "";
    selectedContactIds.clear();
  }
  const { response, data } = await fetchContactsListPage(currentPage, pageLimit);
  if (isStale()) return;
  if (!response.ok) throw new Error(data.error || "Failed to load contacts");
  const contacts = Array.isArray(data?.items) ? data.items : Array.isArray(data) ? data : [];
  currentPageContactIds = contacts.map((c) => Number(c.id)).filter((n) => Number.isInteger(n) && n > 0);
  totalContacts = Number(data?.total || contacts.length || 0);
  contactCountEl.textContent = `${totalContacts.toLocaleString("en-US")} Total`;

  const maxPage = Math.max(1, Math.ceil(totalContacts / pageLimit));
  if (currentPage > maxPage) {
    currentPage = maxPage;
    updateContactsPaginationUi(currentPage, maxPage);
    if (!isStale()) return loadContacts();
    return;
  }
  updateContactsPaginationUi(currentPage, maxPage);

  if (contactsBody) contactsBody.innerHTML = "";
  if (contactsCardsEl) {
    contactsCardsEl.innerHTML = contacts.length
      ? ""
      : '<div class="contacts-mobile-empty">No contacts match your filters.</div>';
  }
  for (const c of contacts) {
    const isChecked = selectedContactIds.has(Number(c.id)) ? "checked" : "";
    appendContactListItem(c, isChecked);
  }
  if (isStale()) return;
  updateContactsEmptyState();
  // Full filtered ID sets load only on Select All (prefetching 31k full rows times out).
  if (!(selectEntireFilteredSet && Array.isArray(lastFilteredContactIds) && lastFilteredContactIds.length)) {
    lastFilteredContactIds = currentPageContactIds.slice();
  }
  if (isStale()) return;
  if (!selectEntireFilteredSet) pruneSelectionToCurrentFilter();
  const allFilteredSelected = selectEntireFilteredSet
    ? selectedContactIds.size > 0 && totalContacts > 0 && selectedContactIds.size >= totalContacts
    : lastFilteredContactIds.length > 0 && lastFilteredContactIds.every((id) => selectedContactIds.has(id));
  syncSelectAllCheckboxes(allFilteredSelected);
  updateContactsPaginationUi(currentPage, maxPage);
  updateSelectedCount();
  if (messageEl && isStaleFetchConfigErrorMessage(messageEl.textContent)) {
    showMessage("");
  }
  if (pipelineContactIdsAutoCleared) {
    pipelineContactIdsAutoCleared = false;
    showMessage(
      "Cleared a large pipeline contact selection that was breaking the list. Your search and filters still apply.",
      false
    );
  }
  syncTaskReminders().catch(() => {});
}

function collectContactIdsFromRows(rows, ids, seen) {
  for (const c of rows || []) {
    const id = Number(c && c.id);
    if (!Number.isInteger(id) || id < 1 || seen.has(id)) continue;
    seen.add(id);
    ids.push(id);
  }
}

async function fetchAllFilteredContactIds(_listPathBase, expectedTotal = 0) {
  const ids = [];
  const seen = new Set();
  const target = Number(expectedTotal) > 0 ? Number(expectedTotal) : 0;

  const { response, data } = await fetchContactsListPage(1, Math.max(target || 5000, 5000), {
    idsOnly: true,
    allIds: true
  });
  if (!response.ok) {
    throw new Error((data && data.error) || "Failed to load contact ids for Select All.");
  }
  const rows = Array.isArray(data && data.items) ? data.items : Array.isArray(data) ? data : [];
  collectContactIdsFromRows(rows, ids, seen);
  const reportedTotal = Number((data && data.total) || 0);
  if (ids.length && (target <= 0 || ids.length >= target || (reportedTotal > 0 && ids.length >= reportedTotal))) {
    return ids;
  }

  const perPage = 10000;
  const maxPages = Math.max(3, Math.ceil((target || ids.length || 1) / perPage) + 2);
  for (let page = 1; page <= maxPages; page += 1) {
    if (target > 0 && ids.length >= target) break;
    const pageResult = await fetchContactsListPage(page, perPage, { idsOnly: true });
    if (!pageResult.response.ok) {
      throw new Error((pageResult.data && pageResult.data.error) || "Failed to load contact ids for Select All.");
    }
    const pageRows = Array.isArray(pageResult.data && pageResult.data.items)
      ? pageResult.data.items
      : Array.isArray(pageResult.data)
        ? pageResult.data
        : [];
    if (!pageRows.length) break;
    const before = ids.length;
    collectContactIdsFromRows(pageRows, ids, seen);
    if (ids.length === before || pageRows.length < perPage) break;
  }
  return ids;
}

function openContactModal(contact) {
  if (typeof window.crmConfigureContactFormAutofill === "function") {
    window.crmConfigureContactFormAutofill(contactModalForm || document);
  }
  activeContact = contact;
  const fullName = String(contact.full_name || "").trim();
  const middleName = String(contact.middle_name || "").trim();
  const nameParts = fullName.split(/\s+/).filter(Boolean);
  const firstName = nameParts.length ? nameParts[0] : "";
  let restParts = nameParts.slice(1);
  if (middleName) {
    const midParts = middleName.split(/\s+/).filter(Boolean);
    const head = restParts.slice(0, midParts.length).join(" ");
    if (head.toLowerCase() === middleName.toLowerCase()) restParts = restParts.slice(midParts.length);
  }
  const lastName = restParts.join(" ");
  contactModalForm.elements.id.value = String(contact.id || "");
  contactModalForm.elements.full_name.value = fullName;
  contactModalForm.elements.first_name.value = firstName;
  if (contactModalForm.elements.middle_name) contactModalForm.elements.middle_name.value = middleName;
  contactModalForm.elements.last_name.value = lastName;
  contactModalForm.elements.email.value = contact.email || "";
  contactModalForm.elements.primary_phone.value = contact.phone || "";
  contactModalForm.elements.secondary_phone.value = contact.secondary_phone || "";
  contactModalForm.elements.age.value = contact.age || "";
  contactModalForm.elements.gender.value = contact.gender || "";
  if (contactModalForm.elements.indian) contactModalForm.elements.indian.value = contact.indian || "";
  contactModalForm.elements.household_size.value = contact.household_size || "";
  contactModalForm.elements.income.value = formatIncomeValue(contact.income || "");
  contactModalForm.elements.lead_source.value = contact.lead_source || "";
  contactModalForm.elements.communication_type.value = contact.communication_type || "";
  contactModalForm.elements.date_of_contact.value = toDateInputValue(contact.date_of_contact || "");
  contactModalForm.elements.outcome.value = contact.outcome || "";
  contactModalForm.elements.status.value = contact.status || "NEW";
  contactModalForm.elements.date_of_birth.value = toDateInputValue(contact.date_of_birth || "");
  contactModalForm.elements.coverages_sold.value = contact.coverages_sold || "";
  contactModalForm.elements.profession.value = contact.profession || "";
  contactModalForm.elements.quote.value = formatCommissionValue(contact.quote || "");
  contactModalForm.elements.health_issues.value = contact.health_issues || "";
  contactModalForm.elements.coverage_start_date.value = toDateInputValue(contact.coverage_start_date || "");
  contactModalForm.elements.bank_routing.value = contact.bank_routing || "";
  contactModalForm.elements.bank_account.value = contact.bank_account || "";
  if (typeof window.crmHidePasswordInput === "function") {
    window.crmHidePasswordInput(contactModalForm.elements.bank_routing);
    window.crmHidePasswordInput(contactModalForm.elements.bank_account);
  }
  contactModalForm.elements.vcall.value = contact.vcall || "";
  contactModalForm.elements.commission.value = formatCommissionValue(contact.commission || "");
  contactModalForm.elements.home_address.value = contact.home_address || "";
  contactModalForm.elements.city.value = contact.city || "";
  contactModalForm.elements.state.value = contact.state || "";
  contactModalForm.elements.zip_code.value = contact.zip_code || "";
  contactModalForm.elements.tags.value = contact.tags || "";
  if (contactModalForm.elements.follow_up_date) {
    contactModalForm.elements.follow_up_date.value = contact.follow_up_date || "";
  }
  if (contactModalForm.elements.follow_up_time) {
    contactModalForm.elements.follow_up_time.value = contact.follow_up_time || "";
  }
  contactModalForm.elements.notes.value = contact.notes || "";
  if (contactModalForm.elements.special_notes) {
    contactModalForm.elements.special_notes.value = contact.special_notes || "";
  }
  if (contactModalForm.elements.app_id) {
    contactModalForm.elements.app_id.value = contact.app_id || "";
  }
  contactDetailModal.classList.remove("hidden");
  contactDetailModal.setAttribute("aria-hidden", "false");
}

function closeContactModal() {
  activeContact = null;
  contactDetailModal.classList.add("hidden");
  contactDetailModal.setAttribute("aria-hidden", "true");
}

function openAddContactModal() {
  if (!addContactModal) return;
  addContactModal.classList.remove("hidden");
  addContactModal.setAttribute("aria-hidden", "false");
  if (addContactContinueBtn) {
    addContactContinueBtn.classList.add("is-hidden");
    addContactContinueBtn.setAttribute("data-contact-id", "");
  }
  setAddContactStatus("");
}

function closeAddContactModal() {
  if (!addContactModal) return;
  addContactModal.classList.add("hidden");
  addContactModal.setAttribute("aria-hidden", "true");
}

function resetTwilioSmsBulkUi() {
  twilioBulkSmsContactIds = null;
  const banner = document.getElementById("twilioSmsBulkBanner");
  const wrap = document.getElementById("twilioSmsPhoneWrap");
  const phoneInput = twilioSmsPopupForm && twilioSmsPopupForm.elements && twilioSmsPopupForm.elements.phone;
  if (banner) {
    banner.classList.add("is-hidden");
    banner.textContent = "";
  }
  if (wrap) wrap.classList.remove("is-hidden");
  if (phoneInput) phoneInput.required = true;
}

function resetTwilioCallBulkUi() {
  const banner = document.getElementById("twilioCallBulkBanner");
  const wrap = document.getElementById("twilioCallPhoneHeadsetWrap");
  const phoneInput = twilioCallPopupForm && twilioCallPopupForm.elements && twilioCallPopupForm.elements.phone;
  if (banner) {
    banner.classList.add("is-hidden");
    banner.textContent = "";
  }
  if (wrap) wrap.classList.remove("is-hidden");
  if (phoneInput) phoneInput.required = true;
}

function openTwilioModalForBulkSms(contactIds) {
  const ids = Array.isArray(contactIds)
    ? contactIds.filter((id) => Number.isInteger(id) && id >= 1)
    : [];
  if (!ids.length) {
    showMessage("No contacts selected.", true);
    return;
  }
  resetTwilioSmsBulkUi();
  resetTwilioCallBulkUi();
  twilioBulkSmsContactIds = ids;
  const banner = document.getElementById("twilioSmsBulkBanner");
  const wrap = document.getElementById("twilioSmsPhoneWrap");
  const phoneInput = twilioSmsPopupForm && twilioSmsPopupForm.elements && twilioSmsPopupForm.elements.phone;
  if (banner) {
    banner.textContent = `Sending to ${ids.length} selected contact(s). Only contacts with a primary phone number receive the message.`;
    banner.classList.remove("is-hidden");
  }
  if (wrap) wrap.classList.add("is-hidden");
  if (phoneInput) phoneInput.removeAttribute("required");
  openTwilioModal("sms");
  const bodyEl = twilioSmsPopupForm && twilioSmsPopupForm.elements && twilioSmsPopupForm.elements.body;
  if (bodyEl) requestAnimationFrame(() => bodyEl.focus());
}

function setTwilioModalDisplayMode(mode) {
  if (!twilioModal) return;
  twilioModal.classList.remove("twilio-modal-mode--sms", "twilio-modal-mode--call");
  if (mode === "sms") twilioModal.classList.add("twilio-modal-mode--sms");
  else if (mode === "call") twilioModal.classList.add("twilio-modal-mode--call");
}

function updateTwilioModalHeaderTitle(mode) {
  const h3 = twilioModal && twilioModal.querySelector(".contact-modal-header h3");
  if (!h3) return;
  if (mode === "sms") h3.textContent = "Send SMS";
  else if (mode === "call") h3.textContent = "Start Call";
  else h3.textContent = "Twilio";
}

function resetTwilioModalChrome() {
  if (!twilioModal) return;
  twilioModal.classList.remove("twilio-modal-mode--sms", "twilio-modal-mode--call");
  const h3 = twilioModal.querySelector(".contact-modal-header h3");
  if (h3) h3.textContent = "Twilio";
}

function openTwilioModal(mode = "both") {
  if (!twilioModal) return;
  const callInProgress = !!(String(activeTwilioCallSid || "").trim() || activeTwilioCallMode);
  const displayMode = callInProgress ? "call" : mode === "sms" || mode === "call" ? mode : "both";
  if (displayMode === "both") {
    twilioModal.classList.remove("twilio-modal-mode--sms", "twilio-modal-mode--call");
    updateTwilioModalHeaderTitle("both");
  } else {
    setTwilioModalDisplayMode(displayMode);
    updateTwilioModalHeaderTitle(displayMode);
  }
  twilioModal.classList.remove("hidden");
  twilioModal.setAttribute("aria-hidden", "false");
  // Do not clear an in-progress call when reopening the modal (e.g. top Twilio button);
  // that used to wipe activeTwilioCallSid and broke End Call.
  if (!callInProgress) {
    stopTwilioCallStatusPolling();
    if (twilioEndCallBtn) delete twilioEndCallBtn.dataset.restCallSid;
    setTwilioPopupStatus("");
  } else {
    setTwilioPopupStatus("On Call");
  }
  const sms = document.getElementById("twilioSmsFrom");
  const call = document.getElementById("twilioCallFrom");
  if (sms && call && window.mirrorTwilioFromSelect) {
    window.mirrorTwilioFromSelect(sms, call);
  }
}

function closeTwilioModal() {
  if (!twilioModal) return;
  if (activeTwilioCallMode || String(activeTwilioCallSid || "").trim()) {
    setTwilioPopupStatus("On Call");
    showMessage("Call is active. End or disconnect the call before closing.", true);
    return;
  }
  resetTwilioModalChrome();
  twilioModal.classList.add("hidden");
  twilioModal.setAttribute("aria-hidden", "true");
  if (twilioEndCallBtn) delete twilioEndCallBtn.dataset.restCallSid;
  stopTwilioCallStatusPolling();
  resetTwilioSmsBulkUi();
  resetTwilioCallBulkUi();
}

function describeTwilioRestCallStatus(data) {
  const status = String(data?.status || "").trim().toLowerCase();
  const duration = Number(data?.duration) || 0;
  const errorDetail = String(data?.errorMessage || "").trim();
  if (status === "queued") return { label: "Dialing...", terminal: false, isError: false };
  if (status === "ringing") return { label: "Ringing...", terminal: false, isError: false };
  if (status === "in-progress") return { label: "On Call", terminal: false, isError: false };
  if (status === "busy") return { label: "Line busy.", terminal: true, isError: true };
  if (status === "no-answer") return { label: "No answer.", terminal: true, isError: false };
  if (status === "failed") {
    const base = "Call failed.";
    const hint = errorDetail
      ? errorDetail.slice(0, 180)
      : "Check the phone number and your Twilio account (trial accounts can only call verified numbers).";
    return { label: `${base} ${hint}`.trim(), terminal: true, isError: true };
  }
  if (status === "canceled" || status === "cancelled") {
    return { label: "Call canceled.", terminal: true, isError: false };
  }
  if (status === "completed" || status === "complete") {
    return {
      label: "Call ended.",
      terminal: true,
      isError: false
    };
  }
  return { label: "", terminal: false, isError: false };
}

function isActiveTwilioCallStatusLabel(normalized) {
  return (
    normalized === "on call" ||
    normalized.startsWith("on call ·") ||
    normalized === "dialing..." ||
    normalized === "ringing..." ||
    normalized === "connecting..." ||
    normalized === "starting call..."
  );
}

function setAddContactStatus(text, isError = false) {
  if (!addContactStatus) return;
  const str = String(text || "");
  addContactStatus.textContent = str;
  addContactStatus.classList.toggle("is-error", !!isError);
  addContactStatus.classList.toggle("is-hidden", str === "");
}

function setTwilioPopupStatus(text, isError = false) {
  if (!twilioPopupStatus) return;
  const statusText = String(text || "");
  const normalized = statusText.trim().toLowerCase();
  twilioPopupStatus.textContent = statusText;
  twilioPopupStatus.classList.toggle("is-error", !!isError);
  twilioPopupStatus.classList.toggle("is-success", !isError && isActiveTwilioCallStatusLabel(normalized));
  const isMessageSent = statusText.trim().toLowerCase() === "message sent";
  twilioPopupStatus.classList.toggle("align-left", isMessageSent);
  twilioPopupStatus.classList.toggle("align-right", !isMessageSent);
}

function clearTwilioCallPhoneInput() {
  const phoneInput = twilioCallPopupForm && twilioCallPopupForm.elements && twilioCallPopupForm.elements.phone;
  if (phoneInput) phoneInput.value = "";
}

function stopTwilioCallStatusPolling() {
  if (twilioCallStatusPollTimer) {
    clearInterval(twilioCallStatusPollTimer);
    twilioCallStatusPollTimer = null;
  }
  activeTwilioCallSid = "";
  activeTwilioCallMode = "";
}

function finalizeTwilioCallUi(message = "") {
  stopTwilioCallStatusPolling();
  setTwilioPopupStatus(message, false);
}

function startTwilioCallStatusPolling(callSid) {
  stopTwilioCallStatusPolling();
  activeTwilioCallSid = String(callSid || "").trim();
  if (!activeTwilioCallSid) return;
  activeTwilioCallMode = "rest";
  if (twilioEndCallBtn) {
    twilioEndCallBtn.dataset.restCallSid = activeTwilioCallSid;
  }
  setTwilioPopupStatus("Dialing...");
  const pollOnce = async () => {
    if (!activeTwilioCallSid) return;
    try {
      const { response, data } = await fetchApiJson(
        `/api/twilio/call-status/${encodeURIComponent(activeTwilioCallSid)}`
      );
      if (!response.ok) return;
      const info = describeTwilioRestCallStatus(data);
      if (info.label) setTwilioPopupStatus(info.label, info.isError);
      if (info.terminal) {
        if (info.isError) showMessage(info.label, true);
        if (twilioEndCallBtn) delete twilioEndCallBtn.dataset.restCallSid;
        stopTwilioCallStatusPolling();
        if (!info.isError) clearTwilioCallPhoneInput();
      }
    } catch {
      // Keep polling quietly; transient errors should not block the UI.
    }
  };
  pollOnce();
  twilioCallStatusPollTimer = setInterval(pollOnce, 2000);
}

async function refreshContactsWorkspace() {
  document.querySelectorAll("details[open]").forEach((el) => {
    el.open = false;
  });
  if (document.activeElement && typeof document.activeElement.blur === "function") {
    document.activeElement.blur();
  }
  if (createdDateFromInput) createdDateFromInput.value = "";
  if (createdDateToInput) createdDateToInput.value = "";
  selectedContactIds.clear();
  selectEntireFilteredSet = false;
  selectAllFilterKey = "";
  syncSelectAllCheckboxes(false);
  getContactRowCheckboxes().forEach((cb) => {
    cb.checked = false;
  });
  updateSelectedCount();
  currentPage = 1;
  await loadContacts();
  showMessage(`Updated ${new Date().toLocaleTimeString()}`);
}

function setContactsTopbarQuickActionsOpen(isOpen) {
  if (!contactsTopbarQuickActionsMenu || !contactsTopbarQuickActionsBtn) return;
  contactsTopbarQuickActionsMenu.classList.toggle("hidden", !isOpen);
  contactsTopbarQuickActionsMenu.setAttribute("aria-hidden", isOpen ? "false" : "true");
  contactsTopbarQuickActionsBtn.setAttribute("aria-expanded", isOpen ? "true" : "false");
}

async function handleContactsQuickAction(action) {
  if (action === "call") {
    await openTwilioCallStandaloneFromAddMenu();
    return;
  }
  if (action === "sms") {
    openTwilioSmsStandaloneFromAddMenu();
    return;
  }
  if (action === "email") {
    openEmailPage();
    return;
  }
  if (action === "task") {
    const ids = selectedIdsArray();
    const q = ids.length ? `?newTask=1&contactId=${encodeURIComponent(String(ids[0]))}` : "?newTask=1";
    window.location.href = `/calendar.html${q}`;
  }
}

function setContactsTopbarAddMenuOpen(isOpen) {
  setContactsTopbarQuickActionsOpen(isOpen);
}

async function openTwilioCallStandaloneFromAddMenu() {
  resetTwilioSmsBulkUi();
  resetTwilioCallBulkUi();
  openTwilioModal("call");
  const phoneInput = twilioCallPopupForm && twilioCallPopupForm.elements && twilioCallPopupForm.elements.phone;
  if (!phoneInput) return;
  phoneInput.value = "";
  const ids = selectedIdsArray();
  if (ids.length) {
    const firstId = ids[0];
    try {
      const { response, data } = await fetchApiJson(`/api/contacts/${encodeURIComponent(firstId)}`);
      if (response.ok && data && data.phone != null) {
        phoneInput.value = String(data.phone).trim();
      }
    } catch {
      //
    }
  }
  requestAnimationFrame(() => phoneInput.focus());
}

function openTwilioSmsStandaloneFromAddMenu() {
  resetTwilioSmsBulkUi();
  resetTwilioCallBulkUi();
  openTwilioModal("sms");
  const bodyEl = twilioSmsPopupForm && twilioSmsPopupForm.elements && twilioSmsPopupForm.elements.body;
  if (bodyEl) requestAnimationFrame(() => bodyEl.focus());
  else {
    const phoneInput = twilioSmsPopupForm && twilioSmsPopupForm.elements && twilioSmsPopupForm.elements.phone;
    if (phoneInput) requestAnimationFrame(() => phoneInput.focus());
  }
}

if (contactsTopbarAddContactBtn) {
  contactsTopbarAddContactBtn.addEventListener("click", () => {
    openAddContactModal();
  });
}

if (contactsTopbarQuickActionsBtn && contactsTopbarQuickActionsMenu && contactsTopbarQuickActionsWrap) {
  contactsTopbarQuickActionsBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    const open = contactsTopbarQuickActionsMenu.classList.contains("hidden");
    setContactsTopbarQuickActionsOpen(open);
  });
  contactsTopbarQuickActionsMenu.addEventListener("click", async (e) => {
    const item = e.target && e.target.closest ? e.target.closest("[data-quick-action]") : null;
    if (!item || !contactsTopbarQuickActionsMenu.contains(item)) return;
    const action = String(item.getAttribute("data-quick-action") || "").trim();
    setContactsTopbarQuickActionsOpen(false);
    await handleContactsQuickAction(action);
  });
  document.addEventListener("mousedown", (e) => {
    if (!contactsTopbarQuickActionsMenu || contactsTopbarQuickActionsMenu.classList.contains("hidden")) return;
    const t = e.target;
    if (contactsTopbarQuickActionsWrap.contains(t)) return;
    setContactsTopbarQuickActionsOpen(false);
  });
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    if (!contactsTopbarQuickActionsMenu || contactsTopbarQuickActionsMenu.classList.contains("hidden")) return;
    setContactsTopbarQuickActionsOpen(false);
    contactsTopbarQuickActionsBtn.focus();
  });
}

if (contactsEmptyAddBtn) {
  contactsEmptyAddBtn.addEventListener("click", () => openAddContactModal());
}

if (contactsEmptyImportBtn) {
  contactsEmptyImportBtn.addEventListener("click", () => {
    window.location.href = "/contact-import.html";
  });
}

if (contactsFilteredEmptyClearBtn && clearAllFiltersBtn) {
  contactsFilteredEmptyClearBtn.addEventListener("click", () => clearAllFiltersBtn.click());
}

document.getElementById("applyFiltersBtn").addEventListener("click", () => {
  clearPipelineContactIdsFilter({ resetApiCache: true });
  currentPage = 1;
  loadContacts().catch((e) => showMessage(e.message, true));
});

if (clearSearchBtn) {
  clearSearchBtn.addEventListener("click", () => {
    searchInput.value = "";
    clearPipelineContactIdsFilter({ resetApiCache: true });
    currentPage = 1;
    loadContacts().catch((e) => showMessage(e.message, true));
  });
}

const contactsSortOutcomeBtn = document.getElementById("contactsSortOutcomeBtn");
if (contactsSortOutcomeBtn) {
  contactsSortOutcomeBtn.addEventListener("click", () => {
    if (sortByOutcomeColumn === "asc") sortByOutcomeColumn = "desc";
    else if (sortByOutcomeColumn === "desc") sortByOutcomeColumn = "asc";
    else sortByOutcomeColumn = "asc";
    currentPage = 1;
    loadContacts().catch((e) => showMessage(e.message, true));
  });
}

if (statusHeaderDropdown) {
  statusHeaderDropdown.addEventListener("change", () => {
    document.querySelectorAll(".quick-filter-btn").forEach((b) => b.classList.remove("active"));
    currentPage = 1;
    loadContacts().catch((e) => showMessage(e.message, true));
  });
}

if (createdDateFromInput) {
  createdDateFromInput.addEventListener("change", () => {
    currentPage = 1;
    loadContacts().catch((e) => showMessage(e.message, true));
  });
}

if (createdDateToInput) {
  createdDateToInput.addEventListener("change", () => {
    currentPage = 1;
    loadContacts().catch((e) => showMessage(e.message, true));
  });
}

if (statusFilter) {
  statusFilter.addEventListener("change", () => {
    document.querySelectorAll(".quick-filter-btn").forEach((b) => b.classList.remove("active"));
    // If user picks a specific status manually, reset segment tab to All
    setActiveContactView("all");
    currentPage = 1;
    loadContacts().catch((e) => showMessage(e.message, true));
  });
}

if (outcomeFilter) {
  outcomeFilter.addEventListener("change", () => {
    document.querySelectorAll(".quick-filter-btn").forEach((b) => b.classList.remove("active"));
    currentPage = 1;
    loadContacts().catch((e) => showMessage(e.message, true));
  });
}

if (contactsFilterSelect) {
  contactsFilterSelect.addEventListener("change", () => {
    document.querySelectorAll(".quick-filter-btn").forEach((b) => b.classList.remove("active"));
    currentPage = 1;
    loadContacts().catch((e) => showMessage(e.message, true));
  });
}

if (contactsTasksBtn) {
  contactsTasksBtn.addEventListener("click", () => {
    window.location.href = "/tasks.html";
  });
}

document.querySelectorAll(".quick-filter-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".quick-filter-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    const status = btn.getAttribute("data-status");
    const tag = btn.getAttribute("data-tag");
    if (status !== null) {
      statusFilter.value = status;
    } else if (tag && tagsFilterTermInput && quickFilterDropdown) {
      if (quickFilterFieldSelect) quickFilterFieldSelect.value = "tags";
      quickFilterDropdown.value = "is";
      tagsFilterTermInput.value = tag;
      updateTagsFilterControls();
    }
    currentPage = 1;
    loadContacts().catch((e) => showMessage(e.message, true));
  });
});

if (quickFilterFieldSelect) {
  quickFilterFieldSelect.addEventListener("change", () => {
    if (tagsFilterTermInput) tagsFilterTermInput.value = "";
    updateTagsFilterControls();
    currentPage = 1;
    loadContacts().catch((e) => showMessage(e.message, true));
  });
}

if (quickFilterDropdown) {
  quickFilterDropdown.addEventListener("change", () => {
    updateTagsFilterControls();
    currentPage = 1;
    loadContacts().catch((e) => showMessage(e.message, true));
  });
}

let tagsFilterTermDebounce = null;
if (tagsFilterTermInput) {
  tagsFilterTermInput.addEventListener("input", () => {
    if (String(quickFilterDropdown?.value || "").trim() === "all") return;
    clearTimeout(tagsFilterTermDebounce);
    tagsFilterTermDebounce = setTimeout(() => {
      currentPage = 1;
      loadContacts().catch((e) => showMessage(e.message, true));
    }, 350);
  });
  tagsFilterTermInput.addEventListener("keydown", (event) => {
    if (event.key !== "Enter") return;
    event.preventDefault();
    runTagsFilterSearch();
  });
}

function runTagsFilterSearch() {
  clearTimeout(tagsFilterTermDebounce);
  currentPage = 1;
  loadContacts().catch((e) => showMessage(e.message, true));
}

if (clearAllFiltersBtn) {
  clearAllFiltersBtn.addEventListener("click", () => {
  searchInput.value = "";
  statusFilter.value = "";
  if (outcomeFilter) outcomeFilter.value = "";
  if (contactsFilterSelect) contactsFilterSelect.value = "";
  if (statusHeaderDropdown) statusHeaderDropdown.value = "newest";
  sortByOutcomeColumn = null;
  if (quickFilterFieldSelect) quickFilterFieldSelect.value = "tags";
  if (quickFilterDropdown) quickFilterDropdown.value = "all";
  if (tagsFilterTermInput) tagsFilterTermInput.value = "";
  if (createdDateFromInput) createdDateFromInput.value = "";
  if (createdDateToInput) createdDateToInput.value = "";
  clearPipelineContactIdsFilter({ resetApiCache: true });
  if (contactsStateFilter) contactsStateFilter.value = "";
  updateTagsFilterControls();
  selectEntireFilteredSet = false;
  selectAllFilterKey = "";
  selectedContactIds.clear();
  syncSelectAllCheckboxes(false);
  currentPage = 1;
  document.querySelectorAll(".quick-filter-btn").forEach((b) => b.classList.remove("active"));
  if (window.location.search) {
    const url = new URL(window.location.href);
    url.search = "";
    window.history.replaceState({}, "", `${url.pathname}${url.hash}`);
  }
  loadContacts().catch((e) => showMessage(e.message, true));
  });
}

prevPageBtn.addEventListener("click", () => {
  if (currentPage <= 1) return;
  currentPage -= 1;
  loadContacts().catch((e) => showMessage(e.message, true));
});

nextPageBtn.addEventListener("click", () => {
  currentPage += 1;
  loadContacts().catch((e) => showMessage(e.message, true));
});

async function handleSelectAllContactsChange(checked) {
  if (!checked) {
    selectEntireFilteredSet = false;
    selectAllFilterKey = "";
    selectedContactIds.clear();
    for (const cb of getContactRowCheckboxes()) cb.checked = false;
    syncSelectAllCheckboxes(false);
    updateSelectedCount();
    showMessage("");
    return;
  }

  const pageIds =
    currentPageContactIds.length > 0
      ? currentPageContactIds.slice()
      : [...getContactRowCheckboxes()]
          .map((cb) => Number(cb.getAttribute("data-contact-id") || cb.value || 0))
          .filter((id, idx, arr) => Number.isInteger(id) && id > 0 && arr.indexOf(id) === idx);

  for (const id of pageIds) selectedContactIds.add(id);
  for (const cb of getContactRowCheckboxes()) cb.checked = true;
  syncSelectAllCheckboxes(true);
  updateSelectedCount();

  if (!(totalContacts > 0)) return;

  const loadingMsg =
    totalContacts > pageIds.length
      ? `Selecting all ${totalContacts.toLocaleString("en-US")} matching contacts...`
      : "";
  try {
    if (loadingMsg) showMessage(loadingMsg);
    const ids = await fetchAllFilteredContactIds(buildContactsListPath(), totalContacts);
    if (!ids.length) throw new Error("No contacts matched the current filters.");
    lastFilteredContactIds = ids;
    selectEntireFilteredSet = true;
    selectAllFilterKey = buildContactsListPath();
    selectedContactIds.clear();
    for (const id of ids) selectedContactIds.add(id);
    for (const cb of getContactRowCheckboxes()) cb.checked = true;
    syncSelectAllCheckboxes(true);
    updateSelectedCount();
    showMessage(`Selected ${ids.length.toLocaleString("en-US")} contacts`);
  } catch (error) {
    selectEntireFilteredSet = false;
    showMessage(error.message || "Failed to select all contacts.", true);
    lastFilteredContactIds = pageIds.slice();
    syncSelectAllCheckboxes(pageIds.length > 0 && pageIds.every((id) => selectedContactIds.has(id)));
    updateSelectedCount();
  }
}

function wireSelectAllCheckbox(el) {
  // Select All is handled by the document-level change listener above.
  // Keep this helper so older call sites remain harmless.
  if (el) el.dataset.selectAllWired = "1";
}

wireSelectAllCheckbox(selectAllContacts);
wireSelectAllCheckbox(selectAllContactsMobile);

if (importCsvBtn) {
  importCsvBtn.addEventListener("click", () => {
    window.location.href = "/contact-import.html";
  });
}

if (scoreLeadsBtn) {
  scoreLeadsBtn.addEventListener("click", async () => {
    const contactIds = currentPageContactIds.slice(0, pageLimit);
    if (!contactIds.length) {
      showMessage("No contacts are visible to score.", true);
      return;
    }
    scoreLeadsBtn.disabled = true;
    const original = scoreLeadsBtn.textContent;
    const controller = typeof AbortController !== "undefined" ? new AbortController() : null;
    const timeoutId = setTimeout(() => controller?.abort(), 300_000);
    scoreLeadsBtn.textContent = "Scoring...";
    showMessage(`Scoring the first ${contactIds.length} visible contact${contactIds.length === 1 ? "" : "s"} with AI...`);
    try {
      const { response, data } = await fetchApiJson("/api/ai/contacts/score-batch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller?.signal,
        body: JSON.stringify({ contactIds, limit: pageLimit })
      });
      if (!response.ok) throw new Error(data.error || "Could not score leads.");
      const scored = Number(data.scored || 0);
      const failed = Number(data.failed || 0);
      const baseMessage = `AI scored ${scored} of ${contactIds.length} visible contact${contactIds.length === 1 ? "" : "s"}.`;
      showMessage(failed > 0 ? `${baseMessage} ${failed} could not be scored right now.` : baseMessage);
      await loadContacts();
    } catch (error) {
      const message =
        error?.name === "AbortError"
          ? "AI scoring is taking too long. Try again, or check the Claude API settings."
          : error.message || "Could not score leads.";
      showMessage(message, true);
    } finally {
      clearTimeout(timeoutId);
      scoreLeadsBtn.disabled = false;
      scoreLeadsBtn.textContent = original || "AI Score Leads";
    }
  });
}

async function runBulkAction(action) {
  if (!action) {
    showMessage("Choose an action first.", true);
    return;
  }
  if (action === "export-csv") {
    try {
      const payload = buildContactsListFilterPayload();
      const selectedIds = selectedIdsArray();
      if (selectedIds.length) payload.contactIds = selectedIds.join(",");
      const exportPath = "/api/contacts/export-csv";
      const usePost =
        contactsListUsesPost() ||
        (payload.contactIds && String(payload.contactIds).length > CONTACT_IDS_URL_CHAR_LIMIT);
      const response = usePost
        ? await fetchApiResponse(exportPath, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
          })
        : await fetchApiResponse(
            `${exportPath}?${new URLSearchParams(
              Object.entries(payload).filter(([, value]) => value != null && String(value) !== "")
            ).toString()}`
          );
      const contentType = response.headers.get("content-type") || "";
      if (!response.ok) {
        let message = `Export failed (${response.status}).`;
        if (contentType.includes("application/json")) {
          const data = await response.json().catch(() => null);
          if (data?.error) message = data.error;
        } else {
          const text = await response.text().catch(() => "");
          if (text.trim()) message = text.trim().slice(0, 180);
        }
        throw new Error(message);
      }
      const blob = await response.blob();
      const disposition = response.headers.get("content-disposition") || "";
      const fileNameMatch = disposition.match(/filename="?([^"]+)"?/i);
      const fileName = fileNameMatch?.[1] || "contacts-export.csv";
      const downloadUrl = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = downloadUrl;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(downloadUrl);
      showMessage("Exported contacts CSV.");
    } catch (error) {
      showMessage(error.message || "Failed to export contacts.", true);
    }
    return;
  }
  if (action === "start-call") {
    const ids = requireSelection();
    if (!ids) return;
    resetTwilioSmsBulkUi();
    resetTwilioCallBulkUi();
    openTwilioModal("call");
    const contactIdInput =
      twilioCallPopupForm && twilioCallPopupForm.elements && twilioCallPopupForm.elements.contactId;
    if (contactIdInput) contactIdInput.value = String(ids[0] || "");
    const phoneInput = twilioCallPopupForm && twilioCallPopupForm.elements && twilioCallPopupForm.elements.phone;
    if (phoneInput) {
      phoneInput.value = "";
      const firstId = ids[0];
      try {
        const { response, data } = await fetchApiJson(`/api/contacts/${encodeURIComponent(firstId)}`);
        if (response.ok && data && data.phone != null) {
          phoneInput.value = String(data.phone).trim();
        }
      } catch {
        //
      }
      requestAnimationFrame(() => phoneInput.focus());
    }
    return;
  }
  const ids = requireSelection();
  if (!ids) return;
  try {
    if (action === "add-tags") {
      const tags = await promptBulkTagsViaModal("add");
      if (tags == null) return;
      const { response, data } = await fetchApiJson("/api/contacts/bulk-update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contactIds: ids, addTags: tags })
      });
      if (!response.ok) throw new Error(data.error || "Failed to add tags");
      showMessage(`Updated ${data.updated} contact(s).`);
      await loadContacts();
      return;
    }
    if (action === "remove-tags") {
      const tags = await promptBulkTagsViaModal("remove");
      if (tags == null) return;
      const { response, data } = await fetchApiJson("/api/contacts/bulk-update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contactIds: ids, removeTags: tags })
      });
      if (!response.ok) throw new Error(data.error || "Failed to remove tags");
      showMessage(`Updated ${data.updated} contact(s).`);
      await loadContacts();
      return;
    }
    if (action === "change-status") {
      const status = await promptBulkStatusViaModal();
      if (status == null) return;
      const { response, data } = await fetchApiJson("/api/contacts/bulk-update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contactIds: ids, status })
      });
      if (!response.ok) throw new Error(data.error || "Failed to change status");
      showMessage(`Updated status for ${data.updated} contact(s).`);
      await loadContacts();
      return;
    }
    if (action === "change-outcome") {
      const outcome = await promptBulkOutcomeViaModal();
      if (outcome == null) return;
      const { response, data } = await fetchApiJson("/api/contacts/bulk-update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contactIds: ids, outcome })
      });
      if (!response.ok) throw new Error(data.error || "Failed to change outcome");
      showMessage(`Updated outcome for ${data.updated} contact(s).`);
      await loadContacts();
      return;
    }
    if (action === "change-lead-source") {
      const lead_source = await promptBulkLeadSourceViaModal();
      if (lead_source == null) return;
      const { response, data } = await fetchApiJson("/api/contacts/bulk-update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contactIds: ids, lead_source })
      });
      if (!response.ok) throw new Error(data.error || "Failed to change lead source");
      showMessage(`Updated lead source for ${data.updated} contact(s).`);
      await loadContacts();
      return;
    }
    if (action === "delete-selected") {
      const deleteCount = ids.length;
      const deleteLabel = hasActiveContactsListFilters()
        ? `Delete ${deleteCount.toLocaleString("en-US")} contact${deleteCount === 1 ? "" : "s"} in your current filtered view? This cannot be undone.`
        : `Delete ${deleteCount.toLocaleString("en-US")} selected contact${deleteCount === 1 ? "" : "s"}? This cannot be undone.`;
      if (!window.confirm(deleteLabel)) return;
      const { response, data } = await fetchApiJson("/api/contacts/bulk-delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contactIds: ids })
      });
      if (!response.ok) throw new Error(data?.error || "Failed to delete contacts");
      const deleted = Number(data?.deleted ?? 0);
      if (deleted <= 0) {
        throw new Error("No contacts were deleted. Refresh the list and try again.");
      }
      selectedContactIds.clear();
      syncSelectAllCheckboxes(false);
      showMessage(`Deleted ${deleted} contact(s).`);
      await loadContacts();
      return;
    }
    if (action === "send-sms") {
      openTwilioModalForBulkSms(ids);
      return;
    }
    if (action === "send-email") {
      openEmailPage(ids);
      return;
    }
  } catch (error) {
    showMessage(error.message, true);
  }
}

if (applyBulkActionBtn) {
  applyBulkActionBtn.addEventListener("click", async () => {
    const action = bulkActionSelect ? bulkActionSelect.value : "";
    await runBulkAction(action);
    rememberBulkActionUsage(action);
  });
}

ensureContactModalFieldLabels();

if (contactModalForm) {
contactModalForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const formData = new FormData(event.target);
  const payload = Object.fromEntries(formData.entries());
  /* Defensive: always pull long-text values straight from the textarea so Notes and
     Special Notes persist even if FormData ever fails to capture them (observed when
     the textarea has been resized by the user). */
  const notesEl = contactModalForm.elements.notes;
  const specialNotesEl = contactModalForm.elements.special_notes;
  if (notesEl && typeof notesEl.value === "string") payload.notes = notesEl.value;
  if (specialNotesEl && typeof specialNotesEl.value === "string") {
    payload.special_notes = specialNotesEl.value;
  }
  const firstName = String(payload.first_name || "").trim();
  const middleName = String(payload.middle_name || "").trim();
  const lastName = String(payload.last_name || "").trim();
  payload.middle_name = middleName;
  payload.full_name = [firstName, middleName, lastName].filter(Boolean).join(" ");
  payload.phone = String(payload.primary_phone || "").trim();
  payload.secondary_phone = String(payload.secondary_phone || "").trim();
  payload.commission = formatCommissionValue(payload.commission);
  payload.quote = formatCommissionValue(payload.quote);
  payload.income = formatIncomeValue(payload.income);
  const contactId = Number(payload.id);
  if (!Number.isInteger(contactId) || contactId < 1) {
    showMessage("Invalid contact id.", true);
    return;
  }
  delete payload.id;
  delete payload.first_name;
  delete payload.last_name;
  delete payload.primary_phone;
  if (!String(payload.full_name || "").trim()) {
    showMessage("Full name is required.", true);
    return;
  }
  try {
    const { response, data: body } = await fetchApiJson(`/api/contacts/${contactId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (!response.ok) throw new Error(body.error || "Failed to update contact");
    showMessage(`Updated contact #${body.id}`);
    closeContactModal();
    await loadContacts();
  } catch (error) {
    showMessage(error.message, true);
  }
});
}

if (contactModalForm && contactModalForm.elements.commission) {
  contactModalForm.elements.commission.addEventListener("blur", () => {
    contactModalForm.elements.commission.value = formatCommissionValue(contactModalForm.elements.commission.value);
  });
}
if (contactModalForm && contactModalForm.elements.quote) {
  contactModalForm.elements.quote.addEventListener("blur", () => {
    contactModalForm.elements.quote.value = formatCommissionValue(contactModalForm.elements.quote.value);
  });
}
if (contactModalForm && contactModalForm.elements.income) {
  contactModalForm.elements.income.addEventListener("blur", () => {
    contactModalForm.elements.income.value = formatIncomeValue(contactModalForm.elements.income.value);
  });
}

if (contactModalSmsBtn) {
  contactModalSmsBtn.addEventListener("click", () => {
    if (!activeContact) return;
    resetTwilioSmsBulkUi();
    resetTwilioCallBulkUi();
    openTwilioModal("sms");
    const phoneInput = twilioSmsPopupForm && twilioSmsPopupForm.elements && twilioSmsPopupForm.elements.phone;
    const bodyEl = twilioSmsPopupForm && twilioSmsPopupForm.elements && twilioSmsPopupForm.elements.body;
    if (phoneInput) phoneInput.value = String(activeContact.phone || "").trim();
    if (bodyEl) requestAnimationFrame(() => bodyEl.focus());
  });
}

if (contactModalEmailBtn) {
  contactModalEmailBtn.addEventListener("click", async () => {
    if (!activeContact) return;
    openEmailPage([activeContact.id]);
  });
}

if (contactModalCallBtn) {
  contactModalCallBtn.addEventListener("click", () => {
    if (!activeContact) return;
    resetTwilioSmsBulkUi();
    resetTwilioCallBulkUi();
    openTwilioModal("call");
    const contactIdInput =
      twilioCallPopupForm && twilioCallPopupForm.elements && twilioCallPopupForm.elements.contactId;
    if (contactIdInput) contactIdInput.value = String(activeContact.id || "");
    const phoneInput = twilioCallPopupForm && twilioCallPopupForm.elements && twilioCallPopupForm.elements.phone;
    if (phoneInput) {
      phoneInput.value = String(activeContact.phone || "").trim();
      requestAnimationFrame(() => phoneInput.focus());
    }
    if (!String(activeContact.phone || "").trim()) {
      setTwilioPopupStatus("Add a phone number, then click Start Call.", true);
    }
  });
}

if (contactModalDeleteBtn) {
  contactModalDeleteBtn.addEventListener("click", async () => {
    if (!activeContact || !activeContact.id) return;
    const label = activeContact.full_name || `contact #${activeContact.id}`;
    if (!window.confirm(`Delete ${label}? This cannot be undone.`)) return;
    try {
      const { response, data } = await fetchApiJson("/api/contacts/bulk-delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contactIds: [activeContact.id] })
      });
      if (!response.ok) throw new Error(data.error || "Failed to delete contact");
      selectedContactIds.delete(activeContact.id);
      syncSelectAllCheckboxes(false);
      showMessage(`Deleted contact.`);
      closeContactModal();
      await loadContacts();
    } catch (error) {
      showMessage(error.message, true);
    }
  });
}

contactModalCloseBtn.addEventListener("click", closeContactModal);
contactDetailModal.addEventListener("click", (event) => {
  const target = event.target;
  if (target && target.getAttribute && target.getAttribute("data-close-modal") === "1") {
    closeContactModal();
  }
});

if (addContactModalCloseBtn) {
  addContactModalCloseBtn.addEventListener("click", closeAddContactModal);
}

if (addContactModal) {
  addContactModal.addEventListener("click", (event) => {
    const target = event.target;
    if (target && target.getAttribute && target.getAttribute("data-close-add-contact-modal") === "1") {
      closeAddContactModal();
    }
  });
}

if (addContactPopupForm) {
  addContactPopupForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const payload = Object.fromEntries(new FormData(event.target).entries());
    if (!String(payload.full_name || "").trim()) {
      showMessage("Full name is required.", true);
      return;
    }
    try {
      const { response, data } = await fetchApiJson("/api/contacts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!response.ok) throw new Error(data.error || "Failed to create contact");
      const createdName = String(payload.full_name || "").trim() || `contact #${data.id}`;
      showMessage(`Created contact #${data.id}`);
      if (addContactContinueBtn && data.id) {
        addContactContinueBtn.classList.remove("is-hidden");
        addContactContinueBtn.setAttribute("data-contact-id", String(data.id));
      }
      event.target.reset();
      setAddContactStatus(
        `Saved ${createdName}. The form is cleared so you can add another contact. Use the "Continue Editing" button to open the contact you just saved.`
      );
      const nameField = event.target.elements && event.target.elements.full_name;
      if (nameField && typeof nameField.focus === "function") nameField.focus();
      await loadContacts();
    } catch (error) {
      showMessage(error.message, true);
    }
  });
}

if (addContactContinueBtn) {
  addContactContinueBtn.addEventListener("click", () => {
    const id = Number(addContactContinueBtn.getAttribute("data-contact-id"));
    if (!Number.isInteger(id) || id < 1) return;
    window.location.href = `/contact.html?id=${encodeURIComponent(id)}&full=1`;
  });
}

if (twilioModalCloseBtn) {
  twilioModalCloseBtn.addEventListener("click", closeTwilioModal);
}

if (twilioModal) {
  twilioModal.addEventListener("click", (event) => {
    const target = event.target;
    if (target && target.getAttribute && target.getAttribute("data-close-twilio-modal") === "1") {
      closeTwilioModal();
    }
  });
}

if (twilioSmsPopupForm) {
  twilioSmsPopupForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const payload = Object.fromEntries(new FormData(event.target).entries());
    payload.phone = String(payload.phone || "").trim();
    if (!payload.twilioFrom) {
      const smsFromEl = document.getElementById("twilioSmsFrom");
      payload.twilioFrom =
        (smsFromEl && smsFromEl.value) ||
        (window.pickDefaultTwilioFromSelect && window.pickDefaultTwilioFromSelect(smsFromEl)) ||
        "primary";
    }
    const bulkIds = twilioBulkSmsContactIds;
    if (bulkIds && bulkIds.length) {
      const body = String(payload.body || "").trim();
      if (!body) {
        showMessage("SMS body is required.", true);
        setTwilioPopupStatus("SMS body is required.", true);
        return;
      }
      try {
        const { response, data } = await fetchApiJson("/api/contacts/bulk-send-sms", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contactIds: bulkIds,
            body,
            twilioFrom: payload.twilioFrom
          })
        });
        if (!response.ok) throw new Error(data.error || "Failed to send SMS");
        const parts = [`Sent ${data.sent} SMS.`];
        if (data.skipped) parts.push(`Skipped ${data.skipped} (no phone).`);
        if (data.failed) parts.push(`${data.failed} failed.`);
        if (data.error) parts.push(data.error);
        showMessage(parts.join(" "));
        setTwilioPopupStatus(
          data.failed ? `Sent ${data.sent}; ${data.failed} failed.` : `Sent ${data.sent} SMS.`
        );
        event.target.reset();
        await loadContacts();
        closeTwilioModal();
      } catch (error) {
        showMessage(error.message, true);
        setTwilioPopupStatus(error.message, true);
      }
      return;
    }
    if (!payload.phone || !String(payload.body || "").trim()) {
      showMessage("Phone and SMS body are required.", true);
      setTwilioPopupStatus("Phone and SMS body are required.", true);
      return;
    }
    try {
      const { response, data } = await fetchApiJson("/api/twilio/send-sms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!response.ok) throw new Error(data.error || "Failed to send SMS");
      showMessage(`SMS sent. SID: ${data.sid}`);
      setTwilioPopupStatus("Message Sent");
      event.target.reset();
    } catch (error) {
      showMessage(error.message, true);
      setTwilioPopupStatus(error.message, true);
    }
  });
}

async function startTwilioRestDialOut(callPayload) {
  const { response, data } = await fetchApiJson("/api/twilio/start-call", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(callPayload)
  });
  if (!response.ok) throw new Error(data.error || "Failed to start call");
  const callSid = String((data && (data.sid != null ? data.sid : data.callSid)) || "").trim();
  if (!callSid) throw new Error("Server did not return a call SID.");
  showMessage(`Call started. SID: ${callSid}`);
  startTwilioCallStatusPolling(callSid);
  return callSid;
}

if (twilioCallPopupForm) {
  // Play standard DTMF tones from the dial pad. Lazily create an AudioContext
  // on first user click (required by browser autoplay policies). Each tone is
  // a short blend of two sine waves with a tiny gain ramp to avoid clicks.
  const DTMF_FREQUENCIES = {
    "1": [697, 1209], "2": [697, 1336], "3": [697, 1477],
    "4": [770, 1209], "5": [770, 1336], "6": [770, 1477],
    "7": [852, 1209], "8": [852, 1336], "9": [852, 1477],
    "*": [941, 1209], "0": [941, 1336], "#": [941, 1477]
  };
  let dialpadAudioCtx = null;
  function playDialpadTone(key, durationMs = 140) {
    const freqs = DTMF_FREQUENCIES[key];
    if (!freqs) return;
    try {
      if (!dialpadAudioCtx) {
        const Ctx = window.AudioContext || window.webkitAudioContext;
        if (!Ctx) return;
        dialpadAudioCtx = new Ctx();
      }
      if (dialpadAudioCtx.state === "suspended" && typeof dialpadAudioCtx.resume === "function") {
        dialpadAudioCtx.resume().catch(() => {});
      }
      const ctx = dialpadAudioCtx;
      const now = ctx.currentTime;
      const dur = Math.max(0.05, durationMs / 1000);
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.18, now + 0.012);
      gain.gain.setValueAtTime(0.18, now + dur - 0.025);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);
      gain.connect(ctx.destination);
      freqs.forEach((freq) => {
        const osc = ctx.createOscillator();
        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, now);
        osc.connect(gain);
        osc.start(now);
        osc.stop(now + dur + 0.02);
      });
    } catch (e) {
      // ignore; audio is a non-essential nicety
    }
  }

  twilioCallPopupForm.addEventListener("click", (event) => {
    const btn = event.target && event.target.closest ? event.target.closest("[data-dial-key]") : null;
    if (!btn) return;
    const phoneInput = twilioCallPopupForm.elements && twilioCallPopupForm.elements.phone;
    if (!phoneInput) return;
    const key = String(btn.getAttribute("data-dial-key") || "").trim();
    if (!key) return;
    const isDtmfKey = /^[0-9*#]$/.test(key);
    if (isDtmfKey) playDialpadTone(key);
    if (
      isDtmfKey &&
      activeTwilioCallMode === "browser" &&
      window.CrmTwilioVoice &&
      typeof CrmTwilioVoice.sendDigits === "function" &&
      CrmTwilioVoice.sendDigits(key)
    ) {
      setTwilioPopupStatus(`Sent tone: ${key}`);
      return;
    }
    if (key === "clear") {
      phoneInput.value = "";
    } else if (key === "backspace") {
      phoneInput.value = String(phoneInput.value || "").slice(0, -1);
    } else {
      phoneInput.value = `${String(phoneInput.value || "")}${key}`;
    }
    phoneInput.dispatchEvent(new Event("input", { bubbles: true }));
    phoneInput.focus();
  });

  twilioCallPopupForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    setTwilioPopupStatus("Starting call...");
    const payload = Object.fromEntries(new FormData(event.target).entries());
    const selectedTwilioFrom = String(payload.twilioFrom || "").trim();
    payload.phone = String(payload.phone || "").trim();
    if (!payload.twilioFrom) {
      const callFromEl = document.getElementById("twilioCallFrom");
      payload.twilioFrom =
        (callFromEl && callFromEl.value) ||
        (window.pickDefaultTwilioFromSelect && window.pickDefaultTwilioFromSelect(callFromEl)) ||
        "primary";
    }
    if (!payload.phone) {
      showMessage("Phone number is required.", true);
      setTwilioPopupStatus("Phone number is required.", true);
      return;
    }
    const providerEl = document.getElementById("twilioCallProvider");
    if (providerEl && !providerEl.disabled) {
      payload.voiceProvider = String(providerEl.value || "").trim();
    }
    const useHeadset = twilioCallUseHeadset && twilioCallUseHeadset.checked && window.CrmTwilioVoice;
    const savedPhone = String(payload.phone || "").trim();
    try {
      if (useHeadset) {
        // Unlock browser audio playback inside the click gesture so autoplay
        // policy does not silently mute the remote call audio.
        if (typeof CrmTwilioVoice.unlockAudioPlayback === "function") {
          CrmTwilioVoice.unlockAudioPlayback();
        }
        const toNorm = CrmTwilioVoice.normalizePhoneForTwilio(payload.phone);
        if (!toNorm.startsWith("+")) {
          showMessage("Enter a 10-digit U.S. number or a full number with country code.", true);
          setTwilioPopupStatus("Enter a valid phone number.", true);
          return;
        }
        payload.phone = toNorm;
        const voiceCfg = await fetchTwilioVoiceConfig();
        try {
          let recordCall = twilioCallRecord && twilioCallRecord.checked;
          if (recordCall && !voiceCfg.recordingReady) {
            showMessage(
              "Recording needs HTTPS CRM Public URL in Settings → Runtime. Starting call without recording.",
              true
            );
            recordCall = false;
          }
          const call = await CrmTwilioVoice.connectCall({
            to: toNorm,
            twilioFrom: payload.twilioFrom,
            recordCall,
            contactId: payload.contactId
          });
          const browserCallSid =
            typeof CrmTwilioVoice.getBrowserCallSid === "function" ? CrmTwilioVoice.getBrowserCallSid() : "";
          await fetchApiJson("/api/twilio/notify-browser-call", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              phone: toNorm,
              contactId: payload.contactId,
              callSid: browserCallSid,
              recordCall
            })
          });
          showMessage("Call started (this computer). Allow the mic if prompted.");
          setTwilioPopupStatus("Connecting...");
          activeTwilioCallMode = "browser";
          let browserCallConnected = false;
          let browserCallRinging = false;
          let restFallbackStarted = false;
          const fallbackToPhoneLine = async () => {
            if (restFallbackStarted || browserCallConnected || browserCallRinging) return;
            restFallbackStarted = true;
            activeTwilioCallMode = "";
            if (window.CrmTwilioVoice && typeof CrmTwilioVoice.disconnectActive === "function") {
              CrmTwilioVoice.disconnectActive();
            }
            if (window.CrmTwilioVoice && typeof CrmTwilioVoice.releaseCallMedia === "function") {
              CrmTwilioVoice.releaseCallMedia();
            }
            showMessage("Computer audio failed. Calling through the phone line so it still rings.");
            setTwilioPopupStatus("Calling through the phone line...");
            payload.recordCall = twilioCallRecord && twilioCallRecord.checked;
            try {
              await startTwilioRestDialOut(payload);
            } catch (restErr) {
              showMessage(restErr.message || "Could not start the phone-line call.", true);
              setTwilioPopupStatus(restErr.message || "Could not start the phone-line call.", true);
            }
          };
          const formatBrowserCallError =
            typeof CrmTwilioVoice.formatCallError === "function"
              ? (err) => CrmTwilioVoice.formatCallError(err)
              : (err) => String((err && err.message) || "Browser audio failed.");
          call.on("ringing", () => {
            browserCallRinging = true;
            setTwilioPopupStatus("Ringing...");
          });
          call.on("accept", () => {
            browserCallConnected = true;
            setTwilioPopupStatus("On Call");
          });
          call.on("error", (err) => {
            if (!browserCallConnected && !browserCallRinging) {
              fallbackToPhoneLine();
              return;
            }
            activeTwilioCallMode = "";
            const msg = formatBrowserCallError(err);
            setTwilioPopupStatus(msg, true);
            showMessage(msg, true);
          });
          call.on("disconnect", async () => {
            const wasConnected = browserCallConnected;
            const wasRinging = browserCallRinging;
            browserCallConnected = false;
            browserCallRinging = false;
            if (window.CrmTwilioVoice && typeof CrmTwilioVoice.releaseCallMedia === "function") {
              CrmTwilioVoice.releaseCallMedia();
            }
            if (wasConnected || wasRinging) {
              finalizeTwilioCallUi("Call ended.");
            } else {
              await fallbackToPhoneLine();
              return;
            }
            if (wasConnected || wasRinging) clearTwilioCallPhoneInput();
            const cid = Number(payload.contactId);
            if (Number.isInteger(cid) && cid > 0) {
              try {
                await fetchApiJson("/api/twilio/sync-call-recordings", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    contactId: cid,
                    callSid: browserCallSid,
                    phone: toNorm
                  })
                });
              } catch (err) {
                console.warn("Recording sync:", err);
              }
            }
          });
          const fromSelect = twilioCallPopupForm.elements && twilioCallPopupForm.elements.twilioFrom;
          if (fromSelect && selectedTwilioFrom) fromSelect.value = selectedTwilioFrom;
          return;
        } catch (headsetError) {
          if (window.CrmTwilioVoice && typeof CrmTwilioVoice.releaseCallMedia === "function") {
            CrmTwilioVoice.releaseCallMedia();
          }
          activeTwilioCallMode = "";
          showMessage("Computer audio failed. Calling through the phone line so it still rings.");
          setTwilioPopupStatus("Calling through the phone line...");
        }
      }
      payload.recordCall = twilioCallRecord && twilioCallRecord.checked;
      await startTwilioRestDialOut(payload);
      const fromSelect = twilioCallPopupForm.elements && twilioCallPopupForm.elements.twilioFrom;
      if (fromSelect && selectedTwilioFrom) fromSelect.value = selectedTwilioFrom;
    } catch (error) {
      // Restore phone so user can retry without re-entering it
      const phoneEl = twilioCallPopupForm.elements && twilioCallPopupForm.elements.phone;
      if (phoneEl && savedPhone) phoneEl.value = savedPhone;
      showMessage(error.message, true);
      setTwilioPopupStatus(error.message, true);
    }
  });
}

if (twilioEndCallBtn) {
  twilioEndCallBtn.addEventListener(
    "click",
    async (event) => {
      event.preventDefault();
      event.stopPropagation();
      // Read Voice SDK CallSid before disconnect clears the reference; browser hang-up
      // sometimes no-ops in the SDK, so we always try REST end-call when we have a CA... sid.
      const preSdkSid =
        window.CrmTwilioVoice && typeof CrmTwilioVoice.getBrowserCallSid === "function"
          ? CrmTwilioVoice.getBrowserCallSid()
          : "";
      if (window.CrmTwilioVoice && typeof CrmTwilioVoice.disconnectActive === "function") {
        CrmTwilioVoice.disconnectActive();
      }
      const hangupSid = String(
        preSdkSid ||
          activeTwilioCallSid ||
          (twilioEndCallBtn.dataset && twilioEndCallBtn.dataset.restCallSid) ||
          ""
      ).trim();
      if (!hangupSid) {
        const bulkBanner = document.getElementById("twilioCallBulkBanner");
        if (bulkBanner && !bulkBanner.classList.contains("is-hidden")) {
          showMessage("Bulk dialing cannot be hung up from this button. Close the modal when finished.", true);
        } else {
          finalizeTwilioCallUi("Call ended.");
        }
        return;
      }
      try {
        const { response, data } = await fetchApiJson("/api/twilio/end-call", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ sid: hangupSid })
        });
        if (!response.ok) throw new Error(data.error || "Failed to end call");
        showMessage("Call ended.");
        finalizeTwilioCallUi("");
        if (twilioEndCallBtn) delete twilioEndCallBtn.dataset.restCallSid;
        clearTwilioCallPhoneInput();
      } catch (error) {
        showMessage(error.message, true);
        setTwilioPopupStatus(error.message, true);
      }
    },
    true
  );
}

async function fetchTwilioVoiceConfig() {
  if (window.CrmTwilioVoice && typeof CrmTwilioVoice.fetchVoiceConfig === "function") {
    return CrmTwilioVoice.fetchVoiceConfig();
  }
  const r = await fetch("/api/twilio/voice-config");
  return r.ok ? r.json() : {};
}

function applyCallRecordingUi(cfg) {
  const recordingReady = !!cfg.recordingReady;
  const recordHint = recordingReady
    ? "When checked, Twilio saves a recording after the call. Playback appears in contact history."
    : "Recording needs your public site URL in Settings - Runtime (HTTPS, e.g. https://crmcadence.com). You can still check this box; the server will confirm before dialing.";
  [twilioCallRecord, contactModalCallRecord].forEach((el) => {
    if (!el) return;
    el.disabled = false;
    el.removeAttribute("aria-disabled");
    el.title = recordHint;
    const label = el.closest("label");
    if (label) {
      label.classList.toggle("twilio-record-opt--warn", !recordingReady);
      label.title = recordHint;
    }
    if (cfg.callRecordingDefault !== false) el.checked = true;
    else el.checked = false;
  });
}

(function initTwilioHeadsetOptions() {
  fetchTwilioVoiceConfig()
    .then((cfg) => {
      const ready = !!(cfg.browserCallReady || cfg.voiceApiCredentialsValid);
      const missing = Array.isArray(cfg.missingEnv) ? cfg.missingEnv.join(", ") : "";
      const webhookNote =
        ready && cfg.voiceWebhookUrl
          ? cfg.voiceWebhookSynced
            ? ""
            : ` TwiML app voice URL should be ${cfg.voiceWebhookUrl}.`
          : "";
      const webhookHint =
        !ready && cfg.voiceWebhookTestHint
          ? ` ${cfg.voiceWebhookTestHint}`
          : "";
      const hint = ready
        ? `You hear and speak through this computer (mic, speakers, or headset). Allow the mic if prompted.${webhookNote}`
        : `Set ${missing || "Twilio voice settings"} in Settings → Twilio to talk on calls from your computer.${webhookHint} ${cfg.hint || ""}`.trim();
      if (window.CrmTwilioVoice && typeof CrmTwilioVoice.applyHeadsetUi === "function") {
        CrmTwilioVoice.applyHeadsetUi({
          cfg,
          checkboxes: [twilioCallUseHeadset, contactModalCallUseHeadset].filter(Boolean)
        });
      } else {
        [twilioCallUseHeadset, contactModalCallUseHeadset].forEach((el) => {
          if (!el) return;
          el.disabled = false;
          el.checked = true;
          el.title = ready
            ? `${hint} Leave checked to talk on the call.`
            : hint;
        });
      }
      applyCallRecordingUi(cfg);
      if (window.CrmTwilioVoice && typeof CrmTwilioVoice.applyRestProviderUi === "function") {
        CrmTwilioVoice.applyRestProviderUi({
          cfg,
          selects: [document.getElementById("twilioCallProvider")].filter(Boolean),
          boxes: [document.getElementById("twilioCallProviderBox")].filter(Boolean)
        });
      }
    })
    .catch(() => {
      [twilioCallUseHeadset, contactModalCallUseHeadset].forEach((el) => {
        if (!el) return;
        el.disabled = false;
        el.checked = true;
        el.title = "Use this computer for call audio (mic / speakers / headset).";
      });
      [twilioCallRecord, contactModalCallRecord].forEach((el) => {
        if (el) {
          el.disabled = false;
          el.checked = true;
        }
      });
    });
})();

(function wireTwilioModalFromPair() {
  const sms = document.getElementById("twilioSmsFrom");
  const call = document.getElementById("twilioCallFrom");
  if (!sms || !call || !window.mirrorTwilioFromSelect) return;
  sms.addEventListener("change", () => window.mirrorTwilioFromSelect(sms, call));
  call.addEventListener("change", () => window.mirrorTwilioFromSelect(call, sms));
})();

window.__crmSyncTwilioFromPairs = function syncTwilioModalFromPair() {
  const sms = document.getElementById("twilioSmsFrom");
  const call = document.getElementById("twilioCallFrom");
  if (!sms || !call || !window.mirrorTwilioFromSelect) return;
  window.mirrorTwilioFromSelect(sms, call);
};

if (morningBriefingModal) {
  morningBriefingModal.addEventListener("click", (event) => {
    if (event.target && event.target.closest("[data-close-morning-briefing]")) closeMorningBriefing();
  });
}
if (morningBriefingCloseBtn) morningBriefingCloseBtn.addEventListener("click", closeMorningBriefing);
if (morningBriefingDismissBtn) morningBriefingDismissBtn.addEventListener("click", closeMorningBriefing);
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && morningBriefingModal && !morningBriefingModal.classList.contains("hidden")) {
    closeMorningBriefing();
  }
});

initContactsWorkspaceStateFilter();
updateTagsFilterControls();

async function initContactWorkspaceOptionsUi() {
  if (window.__CRM_WORKSPACE_UI_READY__) {
    try {
      await window.__CRM_WORKSPACE_UI_READY__;
    } catch {
      /* continue */
    }
  }
  if (window.CrmContactWorkspaceOptions) {
    try {
      await window.CrmContactWorkspaceOptions.reloadAndApply(document);
    } catch {
      window.CrmContactWorkspaceOptions.applyAll(document);
    }
    window.CrmContactWorkspaceOptions.applyWorkspaceUiLabels?.(document);
  }
  syncToolbarStatusesFromContactDetails();
}

document.addEventListener("visibilitychange", () => {
  if (document.visibilityState !== "visible" || !window.CrmContactWorkspaceOptions?.reloadAndApply) return;
  window.CrmContactWorkspaceOptions.reloadAndApply(document)
    .then(() => {
      syncToolbarStatusesFromContactDetails();
    })
    .catch(() => {});
});

window.addEventListener("crm-workspace-options-applied", () => {
  syncToolbarStatusesFromContactDetails();
});

function applyContactsListFiltersFromUrl() {
  const params = new URLSearchParams(window.location.search);
  let changed = false;
  const outcome = params.get("outcome");
  if (outcome && outcomeFilter) {
    outcomeFilter.value = outcome;
    changed = true;
  }
  const status = params.get("status");
  if (status && statusFilter) {
    const opt = [...statusFilter.options].find((o) => o.value.toLowerCase() === String(status).toLowerCase());
    if (opt) {
      statusFilter.value = opt.value;
      changed = true;
    }
  }
  const leadSource = params.get("lead_source");
  if (leadSource && contactsFilterSelect) {
    const opt = [...contactsFilterSelect.options].find((o) => o.value.toLowerCase() === String(leadSource).toLowerCase());
    if (opt) {
      contactsFilterSelect.value = opt.value;
      changed = true;
    }
  }
  const createdFrom = params.get("createdFrom");
  const createdTo = params.get("createdTo");
  if (createdFrom && createdDateFromInput) {
    createdDateFromInput.value = createdFrom;
    changed = true;
  }
  if (createdTo && createdDateToInput) {
    createdDateToInput.value = createdTo;
    changed = true;
  }
  const sortBy = params.get("sortBy");
  if (sortBy && statusHeaderDropdown) {
    const hasOption = [...statusHeaderDropdown.options].some((o) => o.value === sortBy);
    if (hasOption) {
      statusHeaderDropdown.value = sortBy;
      changed = true;
    }
  }
  const tagsFilter = params.get("tagsFilter");
  if (tagsFilter && tagsFilterTermInput && quickFilterDropdown && quickFilterFieldSelect) {
    quickFilterFieldSelect.value = "tags";
    quickFilterDropdown.value = "is";
    tagsFilterTermInput.value = tagsFilter;
    changed = true;
  }
  const contactIds = params.get("contactIds");
  if (params.get("contactIdBatch") === "1") {
    contactIdsFilter = readStoredContactIdsFilter();
    if (!contactIdsFilter.length) {
      const url = new URL(window.location.href);
      url.searchParams.delete("contactIdBatch");
      window.history.replaceState({}, "", `${url.pathname}${url.search}${url.hash}`);
    }
    changed = contactIdsFilter.length > 0 || changed;
  } else if (contactIds) {
    contactIdsFilter = parseContactIdsList(contactIds);
    if (contactIdsUrlTooLarge(contactIdsFilter)) {
      storeContactIdsFilter(contactIdsFilter);
      const url = new URL(window.location.href);
      url.searchParams.delete("contactIds");
      url.searchParams.set("contactIdBatch", "1");
      window.history.replaceState({}, "", `${url.pathname}${url.search}${url.hash}`);
    }
    changed = contactIdsFilter.length > 0 || changed;
  }
  return changed;
}

initContactWorkspaceOptionsUi().then(() => {
  applyContactsListFiltersFromUrl();
  if (
    contactIdsFilter.length &&
    !new URLSearchParams(window.location.search).get("contactIdBatch") &&
    !new URLSearchParams(window.location.search).get("contactIds")
  ) {
    clearPipelineContactIdsFilter({ resetApiCache: true });
  }
  loadContacts().catch((e) => showMessage(e.message, true));
  showMorningBriefingOnce();
});
setInterval(() => {
  syncTaskReminders().catch(() => {});
}, TASK_REMINDER_REFRESH_MS);

// Call forwarding prompt replaced by firstLoginWizard.js
