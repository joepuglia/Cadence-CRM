/**
 * Shared HTML branding for Cadence email templates (logo, product screenshots, footer).
 * Loaded before email-templates.js; exposes window.CadenceEmailBranding.
 */
(function (global) {
  "use strict";

  const ORIGIN =
    typeof location !== "undefined" && location.origin && !/^file:/i.test(location.origin)
      ? location.origin
      : "https://crmcadence.com";

  const ASSETS = `${ORIGIN}/email-assets`;

  const LOGO_ICON = `${ORIGIN}/favicon.svg`;
  const HERO_CONTACTS = `${ASSETS}/cadence-email-hero-contacts.png`;
  const HERO_PIPELINE = `${ASSETS}/cadence-email-hero-pipeline.png`;

  const HERO_BY_KEY = {
    contacts: HERO_CONTACTS,
    pipeline: HERO_PIPELINE
  };

  /** CRM product screenshots — Paradigmai / agent outreach only. */
  const TEMPLATE_VISUALS = {
    "paradigmai-solo-trial": { hero: "contacts" },
    "paradigmai-large-agency": { hero: "pipeline" },
    "paradigmai-has-crm": { hero: "pipeline" },
    "product-launch": { hero: "pipeline" }
  };

  const BRANDS = {
    crm: {
      logoAlt: "Cadence",
      headerName: "Cadence CRM",
      headerTagline: "Built for health insurance agents",
      footerName: "Cadence CRM",
      footerTagline: "Built for health insurance agents",
      footerSub: "Contacts · Pipeline · Email · SMS · Automations · AI",
      footerLink: "https://crmcadence.com",
      accent: "#4f46e5"
    },
    advisor: {
      logoAlt: "Cadence",
      headerName: "Cadence Health Advisors",
      headerTagline: "Your partner for health coverage",
      footerName: "Cadence Health Advisors",
      footerTagline: "Your partner for health coverage",
      footerSub: "Individual & family plans · Medicare · ACA · Private options",
      footerLink: null,
      accent: "#0c4a6e"
    }
  };

  function escapeHtml(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  /** Health-insurance client emails vs Paradigmai / CRM outreach. */
  function brandForTemplate(templateId, category) {
    const id = String(templateId || "");
    const cat = String(category || "");
    if (id.startsWith("paradigmai-") || cat === "Agent Outreach") return "crm";
    if (cat === "Health Insurance" || id.startsWith("hi-")) return "advisor";
    if (id === "product-launch") return "crm";
    return "crm";
  }

  function logoHeader(linkUrl, brandKey) {
    const brand = BRANDS[brandKey] || BRANDS.crm;
    const href =
      linkUrl != null ? linkUrl : brandKey === "advisor" ? null : brand.footerLink || "https://crmcadence.com";
    const iconImg = `<img src="${LOGO_ICON}" alt="${escapeHtml(brand.logoAlt)}" width="56" height="56" style="display:block;width:56px;height:56px;max-width:56px;max-height:56px;border:0;outline:none;border-radius:12px;object-fit:contain;" />`;
    const textBlock = `<div style="font-family:Arial,Helvetica,sans-serif;text-align:left;">
      <div style="font-size:21px;font-weight:800;color:#0f172a;line-height:1.2;letter-spacing:-0.02em;">${escapeHtml(brand.headerName)}</div>
      <div style="font-size:13px;color:#64748b;margin-top:4px;line-height:1.35;">${escapeHtml(brand.headerTagline)}</div>
    </div>`;
    const rowInner = `<table cellpadding="0" cellspacing="0" border="0" role="presentation" style="margin:0 auto;">
  <tr>
    <td valign="middle" style="padding:0 14px 0 0;vertical-align:middle;">${iconImg}</td>
    <td valign="middle" style="vertical-align:middle;">${textBlock}</td>
  </tr>
</table>`;
    const headerInner =
      href && href !== "#"
        ? `<a href="${href}" style="text-decoration:none;color:inherit;display:inline-block;" target="_blank" rel="noopener">${rowInner}</a>`
        : rowInner;

    return `<table cellpadding="0" cellspacing="0" border="0" width="100%" role="presentation" style="font-family:Arial,Helvetica,sans-serif;">
  <tr>
    <td align="center" style="padding:20px 20px 16px;background:linear-gradient(180deg,#f8fafc 0%,#ffffff 100%);border-bottom:1px solid #e2e8f0;">
      ${headerInner}
    </td>
  </tr>
</table>`;
  }

  function heroImage(heroKey, alt) {
    const src = HERO_BY_KEY[heroKey] || heroKey;
    if (!src) return "";
    const safeAlt = escapeHtml(alt || "Cadence CRM for health insurance agents");
    return `<table cellpadding="0" cellspacing="0" border="0" width="100%" role="presentation" style="font-family:Arial,Helvetica,sans-serif;">
  <tr>
    <td style="padding:0;line-height:0;font-size:0;background:#0f172a;">
      <img src="${src}" alt="${safeAlt}" width="600" style="display:block;width:100%;max-width:600px;height:auto;border:0;outline:none;" />
    </td>
  </tr>
</table>`;
  }

  function footerBlock(brandKey) {
    const brand = BRANDS[brandKey] || BRANDS.crm;
    const nameHtml = brand.footerLink
      ? `<a href="${brand.footerLink}" style="color:${brand.accent};text-decoration:none;font-weight:700;">${escapeHtml(brand.footerName)}</a>`
      : `<span style="color:${brand.accent};font-weight:700;">${escapeHtml(brand.footerName)}</span>`;

    return `<table cellpadding="0" cellspacing="0" border="0" width="100%" role="presentation" style="font-family:Arial,Helvetica,sans-serif;">
  <tr>
    <td align="center" style="padding:18px 20px;background:#f8fafc;border-top:1px solid #e2e8f0;font-size:12px;line-height:1.5;color:#64748b;">
      ${nameHtml}
      <span style="color:#cbd5e1;"> · </span>
      ${escapeHtml(brand.footerTagline)}
      <br />
      <span style="font-size:11px;color:#94a3b8;">${escapeHtml(brand.footerSub)}</span>
    </td>
  </tr>
</table>`;
  }

  /**
   * @param {string} bodyHtml
   * @param {{ hero?: string, heroAlt?: string, logoLink?: string, showFooter?: boolean, maxWidth?: number, brand?: string }} [opts]
   */
  function wrap(bodyHtml, opts) {
    const options = opts || {};
    const brandKey = options.brand === "advisor" ? "advisor" : "crm";
    const maxWidth = options.maxWidth || 600;
    const heroKey = options.hero;
    const heroBlock = heroKey ? heroImage(heroKey, options.heroAlt) : "";
    const footer = options.showFooter !== false ? footerBlock(brandKey) : "";
    const header = logoHeader(options.logoLink, brandKey);

    return `<div data-cadence-branded="1" style="background:#e2e8f0;font-family:Arial,Helvetica,sans-serif;margin:0;padding:20px 12px;">
  <div style="max-width:${maxWidth}px;width:100%;margin:0 auto;background:#ffffff;border-radius:14px;overflow:hidden;box-shadow:0 8px 32px rgba(15,23,42,0.12);">
    <div contenteditable="false" data-cadence-email-header="1" style="-webkit-user-modify:read-only;user-select:none;">${header}${heroBlock}</div>
    <div data-cadence-email-body="1" style="padding:26px 24px 8px;color:#0f172a;font-size:16px;line-height:1.6;">
      ${bodyHtml}
    </div>
    <div contenteditable="false" data-cadence-email-footer="1" style="-webkit-user-modify:read-only;user-select:none;">${footer}</div>
  </div>
</div>`;
  }

  function applyBrandingToTemplate(templateId, rawHtml, category) {
    const id = String(templateId || "");
    if (id.startsWith("paradigmai-")) {
      const hero = (TEMPLATE_VISUALS[id] && TEMPLATE_VISUALS[id].hero) || "contacts";
      return paradigmaiBody(rawHtml, hero);
    }
    return brandedSample(templateId, rawHtml, category);
  }

  function brandedSample(templateId, html, category) {
    const brand = brandForTemplate(templateId, category);
    const visuals = TEMPLATE_VISUALS[templateId];
    return wrap(html, {
      brand,
      hero: visuals ? visuals.hero : null,
      heroAlt: visuals && visuals.heroAlt
    });
  }

  function paradigmaiBody(innerHtml, heroKey) {
    return wrap(innerHtml, {
      brand: "crm",
      hero: heroKey,
      heroAlt: "Cadence CRM — built for health insurance agents",
      logoLink: "https://crmcadence.com/signup.html?utm_source=paradigmai&utm_medium=email"
    });
  }

  function ctaButton(href, label, color) {
    const bg = color || "#4f46e5";
    return `<p style="text-align:center;margin:22px 0 18px;">
  <a href="${href}" data-cadence-cta="1" style="display:inline-block;background:${bg};color:#ffffff;text-decoration:none;padding:14px 32px;border-radius:10px;font-weight:700;font-size:16px;font-family:Arial,Helvetica,sans-serif;" target="_blank" rel="noopener">${escapeHtml(label)}</a>
</p>`;
  }

  global.CadenceEmailBranding = {
    ORIGIN,
    ASSETS,
    LOGO_ICON,
    HERO_CONTACTS,
    HERO_PIPELINE,
    HERO_BY_KEY,
    TEMPLATE_VISUALS,
    BRANDS,
    brandForTemplate,
    wrap,
    brandedSample,
    applyBrandingToTemplate,
    paradigmaiBody,
    logoHeader,
    heroImage,
    footerBlock,
    ctaButton,
    escapeHtml
  };
})(typeof window !== "undefined" ? window : globalThis);

(function () {
  "use strict";

  const editor = document.getElementById("templateBodyEditor");
  const subjectField = document.getElementById("saveTemplateSubject");
  const nameField = document.getElementById("saveTemplateName");
  if (!editor) return;
  let savedEditorRange = null;

  // Built-in samples aren't DB rows — "delete" hides them for this browser/workspace.
  const HIDDEN_SAMPLES_KEY = "cadence.hiddenSampleTemplateIds";

  function getHiddenSampleIds() {
    try {
      const raw = localStorage.getItem(HIDDEN_SAMPLES_KEY);
      const parsed = raw ? JSON.parse(raw) : [];
      return new Set(Array.isArray(parsed) ? parsed.map(String) : []);
    } catch {
      return new Set();
    }
  }

  function setHiddenSampleIds(ids) {
    try {
      localStorage.setItem(HIDDEN_SAMPLES_KEY, JSON.stringify([...ids]));
    } catch {
      /* ignore quota / private mode */
    }
  }

  function hideBuiltInSample(sampleId, sampleName) {
    const id = String(sampleId || "").trim();
    if (!id || id.startsWith("saved-")) return false;
    const label = String(sampleName || id).trim() || id;
    if (!window.confirm(`Remove built-in template "${label}" from your gallery?\n\nYou can hard-refresh later after clearing site data if you want samples back.`)) {
      return false;
    }
    const hidden = getHiddenSampleIds();
    hidden.add(id);
    setHiddenSampleIds(hidden);
    if (window.__CRM_CURRENT_SAMPLE_TEMPLATE_ID__ === id) {
      window.__CRM_CURRENT_SAMPLE_TEMPLATE_ID__ = "";
    }
    document.dispatchEvent(
      new CustomEvent("crm:sample-template-hidden", { detail: { id } })
    );
    return true;
  }

  window.CadenceEmailSampleActions = {
    hideBuiltInSample,
    getHiddenSampleIds,
    isHidden: (id) => getHiddenSampleIds().has(String(id || ""))
  };

  const PARADIGMAI_TRIAL_URL =
    "https://crmcadence.com/signup.html?utm_source=paradigmai&utm_medium=email";

  function paradigmaiCta() {
    const B = window.CadenceEmailBranding;
    if (B) return B.ctaButton(PARADIGMAI_TRIAL_URL, "Start 14-day free trial", "#4f46e5");
    return `<p style="text-align:center;margin:22px 0;"><a href="${PARADIGMAI_TRIAL_URL}" data-cadence-cta="1" style="display:inline-block;background:#4f46e5;color:#ffffff;text-decoration:none;padding:14px 32px;border-radius:10px;font-weight:700;">Start 14-day free trial</a></p>`;
  }

  function paradigmaiSoloTrialHtml() {
    const body = `<p style="margin:0 0 14px;">Hi {{first_name}},</p>
  <p style="margin:0 0 14px;">I noticed you work as a health insurance agent. Most solo agents we talk to are still juggling spreadsheets, Gmail, and sticky notes between enrollments.</p>
  <p style="margin:0 0 14px;"><strong>Cadence CRM</strong> was built only for health insurance agents — contacts, pipeline, email, SMS, drip campaigns, and Claude AI in one place (not a generic CRM).</p>
  <p style="margin:0 0 8px;">Try the full Pro version free for <strong>14 days</strong> — no credit card:</p>
  ${paradigmaiCta()}
  <p style="margin:0 0 14px;font-size:14px;color:#64748b;text-align:center;">Or copy this link: <a href="${PARADIGMAI_TRIAL_URL}" style="color:#4f46e5;">${PARADIGMAI_TRIAL_URL}</a></p>
  <p style="margin:0 0 14px;">If it's not a fit, no worries. Reply with one question and I'll answer directly.</p>
  <p style="margin:18px 0 0;">Best,<br/><strong>[Your name]</strong><br/>Cadence CRM</p>`;
    return body;
  }

  function paradigmaiLargeAgencyHtml() {
    const body = `<p style="margin:0 0 14px;">Hi {{first_name}},</p>
  <p style="margin:0 0 14px;">Running enrollments across a team usually means leads slip between inboxes, spreadsheets, and different tools.</p>
  <p style="margin:0 0 14px;"><strong>Cadence CRM</strong> gives health insurance agencies one workspace: shared contacts, pipeline, email, SMS, automations, and AI drafting — built for agent workflows, not generic sales teams.</p>
  <p style="margin:0 0 8px;"><strong>14-day full trial, no credit card:</strong></p>
  ${paradigmaiCta()}
  <p style="margin:0 0 14px;">Worth a 10-minute look before your next busy season? Happy to point you at the pieces that matter for larger teams.</p>
  <p style="margin:18px 0 0;">Best,<br/><strong>[Your name]</strong><br/>Cadence CRM</p>`;
    return body;
  }

  function paradigmaiHasCrmHtml() {
    const body = `<p style="margin:0 0 14px;">Hi {{first_name}},</p>
  <p style="margin:0 0 14px;">Many agents we speak with already use a CRM — but it's often built for general sales, not health insurance (renewals, OEP, Medicare vs ACA, enrollment follow-up).</p>
  <p style="margin:0 0 14px;"><strong>Cadence</strong> is built for health insurance agents: pipeline, email, SMS, drip campaigns, and Claude AI together — at <strong>$79/month</strong> after a 14-day full trial (no credit card to start).</p>
  ${paradigmaiCta()}
  <p style="margin:0 0 14px;">If you're open to a side-by-side look, reply <strong>compare</strong> and I'll send the short list of what agents switch for.</p>
  <p style="margin:18px 0 0;">Best,<br/><strong>[Your name]</strong><br/>Cadence CRM</p>`;
    return body;
  }

  const SAMPLE_TEMPLATES = [
    {
      id: "welcome-warm",
      name: "Warm Welcome",
      category: "Welcome",
      subject: "Welcome aboard, {{first_name}}!",
      thumbColor: "linear-gradient(135deg, #6366f1, #ec4899)",
      icon: "👋",
      html: warmWelcomeHtml()
    },
    {
      id: "newsletter-roundup",
      name: "Monthly Newsletter",
      category: "Newsletter",
      subject: "Here's what you might have missed",
      thumbColor: "linear-gradient(135deg, #0ea5e9, #14b8a6)",
      icon: "📰",
      html: newsletterHtml()
    },
    {
      id: "promo-sale",
      name: "Big Sale Promo",
      category: "Promotion",
      subject: "{{first_name}}, exclusive savings inside",
      thumbColor: "linear-gradient(135deg, #f97316, #ef4444)",
      icon: "🎉",
      html: promoHtml()
    },
    {
      id: "event-invite",
      name: "Event Invitation",
      category: "Events",
      subject: "You're invited! Save the date",
      thumbColor: "linear-gradient(135deg, #7c3aed, #2563eb)",
      icon: "🎟️",
      html: eventInviteHtml()
    },
    {
      id: "product-launch",
      name: "Product Announcement",
      category: "Announcements",
      subject: "Introducing something we think you'll love",
      thumbColor: "linear-gradient(135deg, #1e293b, #475569)",
      icon: "🚀",
      html: productLaunchHtml()
    },
    {
      id: "followup-soft",
      name: "Friendly Follow-Up",
      category: "Follow-ups",
      subject: "Quick check-in, {{first_name}}",
      thumbColor: "linear-gradient(135deg, #10b981, #059669)",
      icon: "💬",
      html: followUpHtml()
    },
    {
      id: "thank-you",
      name: "Thank You Note",
      category: "Engagement",
      subject: "Thank you, {{first_name}}",
      thumbColor: "linear-gradient(135deg, #f59e0b, #d97706)",
      icon: "🙏",
      html: thankYouHtml()
    },
    {
      id: "reengage",
      name: "Re-engagement Nudge",
      category: "Engagement",
      subject: "We've missed you, {{first_name}}",
      thumbColor: "linear-gradient(135deg, #db2777, #9333ea)",
      icon: "✨",
      html: reengageHtml()
    },
    {
      id: "hi-open-enrollment",
      name: "Open Enrollment Reminder",
      category: "Health Insurance",
      subject: "Open enrollment ends soon — let's review your options, {{first_name}}",
      thumbColor: "linear-gradient(135deg, #0c4a6e, #0ea5e9)",
      icon: "🗓️",
      html: hiOpenEnrollmentHtml()
    },
    {
      id: "hi-quote-followup",
      name: "Health Insurance Quote Follow-Up",
      category: "Health Insurance",
      subject: "Following up on your health insurance quote",
      thumbColor: "linear-gradient(135deg, #0e7490, #14b8a6)",
      icon: "💼",
      html: hiQuoteFollowUpHtml()
    },
    {
      id: "hi-plan-compare",
      name: "Plan Options Side-by-Side",
      category: "Health Insurance",
      subject: "Three plans tailored to you, {{first_name}}",
      thumbColor: "linear-gradient(135deg, #1e40af, #6366f1)",
      icon: "📋",
      html: hiPlanCompareHtml()
    },
    {
      id: "hi-life-event",
      name: "New Life Event Coverage",
      category: "Health Insurance",
      subject: "Big life change? Let's make sure you're covered",
      thumbColor: "linear-gradient(135deg, #15803d, #84cc16)",
      icon: "👶",
      html: hiLifeEventHtml()
    },
    {
      id: "hi-welcome-policy",
      name: "Welcome New Policyholder",
      category: "Health Insurance",
      subject: "Your coverage is active — welcome aboard, {{first_name}}",
      thumbColor: "linear-gradient(135deg, #0f766e, #22d3ee)",
      icon: "✅",
      html: hiWelcomePolicyHtml()
    },
    {
      id: "hi-annual-review",
      name: "Annual Coverage Review",
      category: "Health Insurance",
      subject: "Time for your annual coverage review, {{first_name}}",
      thumbColor: "linear-gradient(135deg, #1e3a8a, #3b82f6)",
      icon: "🔍",
      html: hiAnnualReviewHtml()
    },
    {
      id: "hi-self-employed",
      name: "Self-Employed Coverage Pitch",
      category: "Health Insurance",
      subject: "Health insurance built for self-employed pros",
      thumbColor: "linear-gradient(135deg, #7c2d12, #ea580c)",
      icon: "💪",
      html: hiSelfEmployedHtml()
    },
    {
      id: "hi-supplemental",
      name: "Supplemental & Critical Illness",
      category: "Health Insurance",
      subject: "Extra protection for the bills your plan won't cover",
      thumbColor: "linear-gradient(135deg, #9d174d, #f43f5e)",
      icon: "❤️‍🩹",
      html: hiSupplementalHtml()
    },
    {
      id: "hi-healthy-savings",
      name: "Healthy Lifestyle Discount",
      category: "Health Insurance",
      subject: "Healthy habits = lower premiums, {{first_name}}",
      thumbColor: "linear-gradient(135deg, #14532d, #22c55e)",
      icon: "🥗",
      html: hiHealthySavingsHtml()
    },
    {
      id: "hi-young-healthy",
      name: "Young & Healthy Catastrophic",
      category: "Health Insurance",
      subject: "Low-premium coverage built for young & healthy",
      thumbColor: "linear-gradient(135deg, #0369a1, #38bdf8)",
      icon: "⚡",
      html: hiYoungHealthyHtml()
    },
    {
      id: "hi-private-underwritten",
      name: "Private Underwritten Plan Pitch",
      category: "Health Insurance",
      subject: "Healthy? You may qualify for better coverage at a lower price",
      thumbColor: "linear-gradient(135deg, #064e3b, #14b8a6)",
      icon: "✨",
      html: hiPrivateUnderwrittenHtml()
    },
    {
      id: "hi-here-is-quote",
      name: "Here Is Your Quote",
      category: "Health Insurance",
      subject: "Here's your personalized health insurance quote, {{first_name}}",
      thumbColor: "linear-gradient(135deg, #1d4ed8, #06b6d4)",
      icon: "📄",
      html: hiHereIsQuoteHtml()
    },
    {
      id: "hi-prospect-welcome",
      name: "Welcome — New Lead",
      category: "Health Insurance",
      subject: "Thanks for reaching out, {{first_name}}",
      thumbColor: "linear-gradient(135deg, #4f46e5, #7c3aed)",
      icon: "👋",
      html: hiProspectWelcomeHtml()
    },
    {
      id: "hi-referral-ask",
      name: "Referral Ask",
      category: "Health Insurance",
      subject: "Know someone who needs help with health insurance?",
      thumbColor: "linear-gradient(135deg, #b45309, #f59e0b)",
      icon: "🤝",
      html: hiReferralAskHtml()
    },
    {
      id: "hi-post-enrollment-thanks",
      name: "Post-Enrollment Thank You",
      category: "Health Insurance",
      subject: "Thank you for trusting me with your coverage, {{first_name}}",
      thumbColor: "linear-gradient(135deg, #047857, #34d399)",
      icon: "💚",
      html: hiPostEnrollmentThanksHtml()
    },
    {
      id: "paradigmai-solo-trial",
      name: "Paradigmai — Solo Agent Trial",
      category: "Agent Outreach",
      subject: "CRM built for solo agents — {{first_name}}",
      thumbColor: "linear-gradient(135deg, #4f46e5, #7c3aed)",
      icon: "🎯",
      html: paradigmaiSoloTrialHtml()
    },
    {
      id: "paradigmai-large-agency",
      name: "Paradigmai — Large Agency Trial",
      category: "Agent Outreach",
      subject: "Keep your team on one pipeline — {{first_name}}",
      thumbColor: "linear-gradient(135deg, #0c4a6e, #6366f1)",
      icon: "🏢",
      html: paradigmaiLargeAgencyHtml()
    },
    {
      id: "paradigmai-has-crm",
      name: "Paradigmai — Already Has CRM",
      category: "Agent Outreach",
      subject: "Agent-specific CRM vs generic — quick compare",
      thumbColor: "linear-gradient(135deg, #b45309, #ea580c)",
      icon: "⚖️",
      html: paradigmaiHasCrmHtml()
    }
  ];

  function resolveSampleHtml(tpl) {
    const raw = tpl._rawHtml != null ? tpl._rawHtml : tpl.html;
    // Saved (user-created) templates already contain their final HTML — don't
    // run sample-only branding on them (that keys off built-in sample ids).
    if (tpl && tpl.__saved) return raw;
    const B = window.CadenceEmailBranding;
    if (!B) return raw;
    return B.applyBrandingToTemplate(tpl.id, raw, tpl.category);
  }

  function applyBrandingToAllSamples() {
    const B = window.CadenceEmailBranding;
    if (!B) {
      console.warn("[email-templates] CadenceEmailBranding not loaded — headers/footers missing");
      return;
    }
    for (const tpl of SAMPLE_TEMPLATES) {
      if (tpl._rawHtml == null) tpl._rawHtml = tpl.html;
      const visuals = B.TEMPLATE_VISUALS[tpl.id];
      if (visuals && visuals.hero && B.HERO_BY_KEY[visuals.hero]) {
        tpl.thumbImage = B.HERO_BY_KEY[visuals.hero];
      }
      tpl.html = B.applyBrandingToTemplate(tpl.id, tpl._rawHtml, tpl.category);
    }
  }

  function initBrandedSamples() {
    if (window.CadenceEmailBranding) applyBrandingToAllSamples();
  }

  /** Curated starters shown prominently for health insurance agents. */
  const STARTER_TEMPLATE_IDS = [
    "hi-prospect-welcome",
    "hi-quote-followup",
    "hi-open-enrollment",
    "hi-referral-ask",
    "hi-post-enrollment-thanks",
    "hi-here-is-quote",
    "followup-soft",
    "hi-welcome-policy",
    "paradigmai-solo-trial",
    "paradigmai-large-agency",
    "paradigmai-has-crm"
  ];

  /** Display order in the template gallery (then sorted by name within each category). */
  const GALLERY_CATEGORY_ORDER = [
    "Agent Outreach",
    "Health Insurance",
    "Welcome",
    "Follow-ups",
    "Engagement",
    "Newsletter",
    "Events",
    "Promotion",
    "Announcements"
  ];

  const THEMES = [
    { id: "indigo", name: "Indigo Pro", primary: "#4f46e5", accent: "#a78bfa", surface: "#f5f3ff", text: "#1e1b4b" },
    { id: "ocean", name: "Ocean", primary: "#0284c7", accent: "#22d3ee", surface: "#ecfeff", text: "#0c4a6e" },
    { id: "forest", name: "Forest", primary: "#16a34a", accent: "#84cc16", surface: "#f0fdf4", text: "#14532d" },
    { id: "sunset", name: "Sunset", primary: "#ea580c", accent: "#f59e0b", surface: "#fff7ed", text: "#7c2d12" },
    { id: "berry", name: "Berry", primary: "#be185d", accent: "#f472b6", surface: "#fdf2f8", text: "#831843" },
    { id: "slate", name: "Minimal Slate", primary: "#1e293b", accent: "#64748b", surface: "#f8fafc", text: "#0f172a" }
  ];

  injectStyles();
  buildBlockToolbar();
  buildBlockPopover();
  wireEditorSelectionTracking();
  wireClearBodyButton();
  wireSubjectLineHelper();

  initBrandedSamples();
  buildGallery();

  function isRangeInsideEditor(range) {
    if (!range) return false;
    const node = range.commonAncestorContainer;
    return node === editor || editor.contains(node);
  }

  function captureEditorRange() {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return;
    const range = sel.getRangeAt(0);
    if (!isRangeInsideEditor(range)) return;
    savedEditorRange = range.cloneRange();
  }

  function getRangeFromPoint(x, y) {
    if (document.caretRangeFromPoint) return document.caretRangeFromPoint(x, y);
    if (document.caretPositionFromPoint) {
      const pos = document.caretPositionFromPoint(x, y);
      if (!pos) return null;
      const range = document.createRange();
      range.setStart(pos.offsetNode, pos.offset);
      range.collapse(true);
      return range;
    }
    return null;
  }

  function saveEditorRangeFromPoint(event) {
    if (!event) return;
    const range = getRangeFromPoint(event.clientX, event.clientY);
    if (range && isRangeInsideEditor(range)) {
      savedEditorRange = range.cloneRange();
      return;
    }
    if (event.target === editor) {
      const fallback = document.createRange();
      fallback.selectNodeContents(editor);
      fallback.collapse(false);
      savedEditorRange = fallback;
    }
  }

  function restoreEditorRange() {
    editor.focus();
    if (!savedEditorRange || !isRangeInsideEditor(savedEditorRange)) return false;
    const sel = window.getSelection();
    if (!sel) return false;
    try {
      sel.removeAllRanges();
      sel.addRange(savedEditorRange);
      return true;
    } catch {
      return false;
    }
  }

  function wireEditorSelectionTracking() {
    editor.addEventListener("pointerup", saveEditorRangeFromPoint);
    editor.addEventListener("click", saveEditorRangeFromPoint);
    ["mouseup", "keyup", "focus", "input"].forEach((eventName) => {
      editor.addEventListener(eventName, captureEditorRange);
    });
    document.addEventListener("selectionchange", () => {
      const sel = window.getSelection();
      if (!sel || sel.rangeCount === 0) return;
      const range = sel.getRangeAt(0);
      if (isRangeInsideEditor(range)) savedEditorRange = range.cloneRange();
    });
  }

  function wireClearBodyButton() {
    const clearBtn = document.getElementById("templateClearBodyBtn");
    if (!clearBtn || !editor) return;
    clearBtn.addEventListener("click", () => {
      const hasContent = (editor.innerHTML || "").replace(/<br\s*\/?\s*>/gi, "").trim().length > 0;
      if (hasContent && !window.confirm("Clear the entire template body? This can be undone with the Undo Last Edit button.")) {
        return;
      }
      editor.innerHTML = "";
      editor.dispatchEvent(new Event("input", { bubbles: true }));
      editor.focus();
      const feedback = document.getElementById("templateSaveFeedback");
      if (feedback) {
        feedback.textContent = "Template body cleared.";
        window.setTimeout(() => {
          if (feedback.textContent === "Template body cleared.") feedback.textContent = "";
        }, 2500);
      }
    });
  }

  function injectStyles() {
    if (document.getElementById("email-templates-aug-styles")) return;
    const style = document.createElement("style");
    style.id = "email-templates-aug-styles";
    style.textContent = `
      .et-gallery-section { margin-bottom: 14px; }
      .et-gallery-starters-title { margin: 0 0 4px; font-size: 1.05rem; color: #0f172a; }
      .et-gallery-starters-lead { margin: 0 0 12px; color: #475569; font-size: 0.92rem; line-height: 1.5; }
      .et-gallery-mine-block { margin: 0 0 22px; padding: 0 0 18px; border-bottom: 1px solid #e2e8f0; }
      .et-gallery-samples-block { margin-top: 4px; }
      .et-gallery-subsection-label { margin: 4px 0 10px; font-size: 0.78rem; font-weight: 800; letter-spacing: 0.06em; text-transform: uppercase; color: #64748b; }
      .et-gallery-starter-grid { margin-bottom: 14px; }
      .et-gallery-more-details { border: 1px solid #dbe4f6; border-radius: 10px; padding: 0 12px; background: #f8fafc; }
      .et-gallery-more-details > summary {
        cursor: pointer;
        font-weight: 700;
        color: #334155;
        padding: 12px 0;
        list-style: none;
      }
      .et-gallery-more-details > summary::-webkit-details-marker { display: none; }
      .et-gallery-more-body { padding: 0 0 12px; }
      .et-gallery-header { display: flex; justify-content: flex-start; align-items: center; gap: 12px; flex-wrap: wrap; margin-bottom: 10px; }
      .et-gallery-search { padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 8px; min-width: 220px; max-width: 360px; width: 100%; background: #fff; }
      .et-gallery-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 12px; align-items: start; }
      .et-gallery-grid > button { width: auto; height: auto; max-height: 40px; align-self: start; margin: 0; }
      .et-card { display: flex; flex-direction: column; border-radius: 12px; overflow: hidden; border: 1px solid #d8dee8; background: #ffffff; box-shadow: 0 1px 2px rgba(15,23,42,0.05); transition: transform 0.12s ease, box-shadow 0.12s ease, border-color 0.12s ease; }
      .et-card:hover { transform: translateY(-2px); box-shadow: 0 8px 16px rgba(37,99,235,0.15); border-color: #93b6f5; }
      .et-card-thumb { height: 120px; display: flex; align-items: center; justify-content: center; font-size: 2.6rem; color: #ffffff; text-shadow: 0 2px 4px rgba(0,0,0,0.15); overflow: hidden; position: relative; background: #e2e8f0; }
      .et-card-thumb--html { background: #f1f5f9; }
      .et-card-thumb-frame {
        position: absolute;
        top: 0; left: 0;
        width: 600px; height: 800px;
        border: 0;
        transform: scale(0.2);
        transform-origin: top left;
        pointer-events: none;
        background: #ffffff;
      }
      .et-card-body { padding: 10px 12px 12px; display: flex; flex-direction: column; gap: 4px; flex: 1; }
      .et-card-name { font-weight: 700; color: #0f172a; font-size: 0.95rem; }
      .et-card-cat { font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.06em; color: #64748b; font-weight: 600; }
      .et-card-actions { display: flex; gap: 6px; margin-top: auto; padding-top: 8px; align-items: center; }
      .et-card-actions button { flex: 1 1 auto; width: auto; height: auto; font-size: 0.78rem; padding: 6px 8px; border-radius: 6px; cursor: pointer; }
      .et-preview-backdrop { position: fixed; inset: 0; background: rgba(15,23,42,0.55); display: none; align-items: center; justify-content: center; z-index: 240; padding: 18px; }
      .et-preview-backdrop.is-open { display: flex; }
      .et-preview-modal { background: #ffffff; border-radius: 14px; width: min(820px, 96vw); max-height: min(92vh, 980px); display: flex; flex-direction: column; box-shadow: 0 18px 40px rgba(15,23,42,0.35); overflow: hidden; }
      .et-preview-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; padding: 14px 16px; border-bottom: 1px solid #e2e8f0; }
      .et-preview-head > div { flex: 1 1 auto; min-width: 0; }
      .et-preview-head h3 { margin: 0 0 4px; font-size: 1.05rem; color: #0f172a; }
      .et-preview-subject { margin: 0; color: #64748b; font-size: 0.85rem; }
      .et-preview-head button,
      .et-preview-head .et-preview-close-x,
      .et-preview-actions button {
        width: auto !important;
        min-width: 0 !important;
        max-width: none !important;
        flex: 0 0 auto !important;
        margin: 0 !important;
        padding: 8px 14px;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
      }
      .et-preview-head .et-preview-close-x {
        width: 36px !important;
        height: 36px !important;
        padding: 0 !important;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        line-height: 1;
        background: #f1f5f9;
        color: #1e293b;
        border: 1px solid #cbd5e1;
      }
      .et-preview-frame-wrap { flex: 1 1 auto; min-height: 280px; overflow: auto; background: #f1f5f9; padding: 16px; }
      .et-preview-frame { width: 100%; min-height: 420px; height: 56vh; border: 0; background: #ffffff; border-radius: 8px; box-shadow: 0 1px 3px rgba(15,23,42,0.12); }
      .et-preview-actions { display: flex; flex-wrap: nowrap; gap: 8px; justify-content: flex-end; align-items: center; padding: 12px 16px; border-top: 1px solid #e2e8f0; background: #f8fafc; }
      .et-preview-actions button {
        flex: 0 0 auto !important;
        width: auto !important;
        min-width: 0 !important;
        max-width: none !important;
      }
      .et-preview-actions .et-preview-close-btn {
        flex: 0 0 auto !important;
        width: auto !important;
        min-width: 72px !important;
        max-width: 96px !important;
        padding: 8px 14px !important;
        background: #f1f5f9;
        color: #1e293b;
        border: 1px solid #cbd5e1;
      }
      .et-preview-actions .et-cancel { background: #f1f5f9; color: #1e293b; border: 1px solid #cbd5e1; }
      .et-preview-actions .et-confirm { background: #2563eb; color: #ffffff; border: 1px solid #1d4ed8; }
      .et-preview-actions .et-delete { background: #e5e7eb; color: #111827; border: 1px solid #9ca3af; }
      .et-preview-actions .et-delete:hover:not(:disabled) { background: #d1d5db; }
      .et-preview-actions .et-delete:disabled { opacity: 0.55; cursor: not-allowed; }
      .et-block-toolbar { display: flex; flex-wrap: wrap; gap: 6px; padding: 8px 10px; margin-top: 8px; background: linear-gradient(180deg, #f8fafc, #eef2f7); border: 1px solid #d8dee8; border-radius: 10px; align-items: center; }
      .et-block-toolbar-label { font-size: 0.74rem; text-transform: uppercase; letter-spacing: 0.07em; font-weight: 700; color: #475569; margin-right: 4px; }
      .et-block-btn { width: auto; margin: 0; padding: 4px 9px; border-radius: 6px; border: 1px solid #cbd5e1; background: #ffffff; color: #1e293b; cursor: pointer; font-size: 0.78rem; font-weight: 600; line-height: 1.2; white-space: nowrap; }
      .et-block-btn:hover { background: #eef2ff; border-color: #93b6f5; }
      .et-block-bg-cluster { display: inline-flex; gap: 5px; align-items: center; padding-left: 4px; border-left: 1px solid #cbd5e1; }
      .et-block-bg-cluster input[type="color"] { width: 30px; height: 26px; padding: 1px; border: 1px solid #cbd5e1; border-radius: 6px; background: #ffffff; cursor: pointer; }
      .et-theme-cluster { display: inline-flex; gap: 6px; align-items: center; margin-left: auto; }
      .et-theme-swatch { width: 28px; height: 28px; border-radius: 50%; border: 2px solid #ffffff; box-shadow: 0 0 0 1px rgba(15,23,42,0.18); cursor: pointer; }
      .et-theme-swatch:hover { transform: scale(1.1); }
      .et-emoji-tray { display: none; position: absolute; z-index: 100; background: #ffffff; border: 1px solid #d8dee8; border-radius: 8px; padding: 6px; box-shadow: 0 8px 18px rgba(15,23,42,0.18); max-width: 280px; }
      .et-emoji-tray.is-open { display: block; }
      .et-emoji-tray button { width: auto; margin: 0; font-size: 1.2rem; padding: 4px 6px; background: transparent; border: 0; cursor: pointer; }
      .et-emoji-tray button:hover { background: #eef2ff; border-radius: 4px; }
      .et-popover-backdrop { position: fixed; inset: 0; background: rgba(15,23,42,0.55); display: none; align-items: center; justify-content: center; z-index: 200; }
      .et-popover-backdrop.is-open { display: flex; }
      .et-popover { background: #ffffff; border-radius: 12px; padding: 18px 22px; max-width: 460px; width: 90vw; box-shadow: 0 14px 30px rgba(15,23,42,0.32); }
      .et-popover h3 { margin: 0 0 12px; }
      .et-popover .field { margin-bottom: 10px; }
      .et-popover label { display: block; font-size: 0.78rem; color: #475569; font-weight: 600; margin-bottom: 4px; }
      .et-popover input[type="text"], .et-popover input[type="url"], .et-popover textarea { width: 100%; padding: 6px 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-family: inherit; font-size: 0.92rem; }
      .et-popover textarea { min-height: 60px; resize: vertical; }
      .et-popover .row { display: flex; gap: 8px; }
      .et-popover .row > .field { flex: 1; }
      .et-popover-actions { display: flex; gap: 8px; justify-content: flex-end; margin-top: 12px; }
      .et-popover-actions button { padding: 7px 14px; border-radius: 6px; cursor: pointer; font-weight: 600; }
      .et-cancel { background: #f1f5f9; color: #1e293b; border: 1px solid #cbd5e1; }
      .et-confirm { background: linear-gradient(135deg, #2563eb, #1d4ed8); color: #ffffff; border: 1px solid #1d4ed8; }
      #templateBodyEditor [data-et-hero] { position: relative; outline: 1px dashed transparent; transition: outline-color 0.15s ease; }
      #templateBodyEditor [data-et-hero]:hover { outline-color: rgba(37,99,235,0.55); }
      #templateBodyEditor [data-et-hero]::after { content: "↘ drag to resize"; position: absolute; right: 8px; bottom: 4px; font-size: 0.7rem; font-weight: 600; letter-spacing: 0.04em; padding: 2px 6px; border-radius: 4px; background: rgba(15,23,42,0.55); color: #ffffff; pointer-events: none; opacity: 0; transition: opacity 0.15s ease; font-family: system-ui, sans-serif; }
      #templateBodyEditor [data-et-hero]:hover::after { opacity: 1; }
      #templateBodyEditor [data-et-callout] { position: relative; outline: 1px dashed transparent; transition: outline-color 0.15s ease; resize: both; overflow: auto; min-width: 120px; min-height: 56px; box-sizing: border-box; }
      #templateBodyEditor [data-et-callout]:hover { outline-color: rgba(37,99,235,0.55); }
      #templateBodyEditor [data-et-callout]::after { content: "↘ drag to resize"; position: absolute; right: 8px; bottom: 4px; font-size: 0.7rem; font-weight: 600; letter-spacing: 0.04em; padding: 2px 6px; border-radius: 4px; background: rgba(15,23,42,0.55); color: #ffffff; pointer-events: none; opacity: 0; transition: opacity 0.15s ease; font-family: system-ui, sans-serif; }
      #templateBodyEditor [data-et-callout]:hover::after { opacity: 1; }
      #templateBodyEditor [data-et-callout] hr { border: none; border-top: 1px solid #d8dee8; margin: 10px 0; }
    `;
    document.head.appendChild(style);
  }

  function buildGallery() {
    const section =
      document.getElementById("starterTemplatesSection") ||
      document.querySelector(".et-gallery-section");
    if (!section) return;

    const starterGrid = section.querySelector('[data-et-grid="starters"]');
    const moreGrid = section.querySelector('[data-et-grid="more"]');
    const mineSearch = section.querySelector('[data-et-search="mine"]');
    const samplesSearch = section.querySelector('[data-et-search="samples"]');
    const moreSummary = section.querySelector(".et-gallery-more-details summary");
    const mineBlock = section.querySelector("[data-et-mine-block]");
    const mineGrid = section.querySelector('[data-et-grid="mine"]');
    let mineCards = [];

    const MINE_THUMB_COLORS = [
      "linear-gradient(135deg, #6366f1, #ec4899)",
      "linear-gradient(135deg, #0ea5e9, #14b8a6)",
      "linear-gradient(135deg, #f97316, #ef4444)",
      "linear-gradient(135deg, #7c3aed, #2563eb)",
      "linear-gradient(135deg, #10b981, #059669)",
      "linear-gradient(135deg, #f59e0b, #d97706)",
      "linear-gradient(135deg, #db2777, #9333ea)",
      "linear-gradient(135deg, #0c4a6e, #0ea5e9)"
    ];

    function savedRowToCard(row) {
      const id = Number(row && row.id) || 0;
      const category = String((row && row.category_name) || "").trim() || "Uncategorized";
      const body = String((row && row.body) || "");
      return {
        id: "saved-" + id,
        __saved: true,
        savedId: id,
        name: String((row && row.name) || "Untitled template"),
        category,
        subject: String((row && row.subject) || ""),
        icon: "📧",
        thumbColor: MINE_THUMB_COLORS[id % MINE_THUMB_COLORS.length],
        html: body,
        _rawHtml: body,
        thumbHtml: body
      };
    }

    function activeMineCategory() {
      const raw = String(window.__CRM_TEMPLATE_CATEGORY_FILTER__ || "ALL").trim();
      return raw || "ALL";
    }

    function renderMine() {
      if (!mineGrid || !mineBlock) return;
      // Keep this block visible so category chips / Create Category stay at the top.
      mineBlock.hidden = false;
      if (!mineCards.length) {
        mineGrid.innerHTML =
          '<p class="hint">No saved templates yet. Use a sample below, edit, then Save Template.</p>';
        return;
      }
      const q = String(mineSearch?.value || "").toLowerCase().trim();
      const cat = activeMineCategory();
      const byCategory =
        cat === "ALL"
          ? mineCards
          : mineCards.filter((card) => String(card.category || "Uncategorized") === cat);
      renderCards(mineGrid, byCategory, q);
    }

    async function loadMineTemplates() {
      if (!mineGrid) return;
      try {
        const res = await fetch("/api/email/templates", { credentials: "include" });
        if (!res.ok) throw new Error("load failed");
        const data = await res.json().catch(() => []);
        const rows = Array.isArray(data) ? data : [];
        window.__CRM_EMAIL_TEMPLATE_ROWS__ = rows;
        mineCards = rows
          .map(savedRowToCard)
          .sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base", numeric: true }));
      } catch (err) {
        mineCards = [];
      }
      renderMine();
    }
    const starterSet = new Set(STARTER_TEMPLATE_IDS);
    const PARADIGMAI_TEMPLATE_IDS = new Set([
      "paradigmai-solo-trial",
      "paradigmai-large-agency",
      "paradigmai-has-crm"
    ]);

    function visibleTemplates(list) {
      const hidden = getHiddenSampleIds();
      let out = list.filter((tpl) => !hidden.has(String(tpl.id)));
      if (window.__CRM_WORKSPACE_TYPE__ === "trial") {
        out = out.filter((tpl) => !PARADIGMAI_TEMPLATE_IDS.has(tpl.id));
      }
      return out;
    }

    function updateMoreSummaryCount() {
      if (!moreSummary) return;
      const moreCount = visibleTemplates(
        SAMPLE_TEMPLATES.filter((tpl) => !starterSet.has(tpl.id))
      ).length;
      moreSummary.textContent = `Browse more sample templates (${moreCount})`;
    }

    function applySampleFilter() {
      const q = String(samplesSearch?.value || "").toLowerCase().trim();
      updateMoreSummaryCount();
      renderCards(
        starterGrid,
        visibleTemplates(SAMPLE_TEMPLATES.filter((tpl) => starterSet.has(tpl.id))),
        q
      );
      renderCards(
        moreGrid,
        visibleTemplates(SAMPLE_TEMPLATES.filter((tpl) => !starterSet.has(tpl.id))),
        q
      );
    }

    const runGalleryFilter = () => {
      renderMine();
      applySampleFilter();
      document.querySelectorAll("[data-owner-only]").forEach((el) => {
        const hide = window.__CRM_WORKSPACE_TYPE__ === "trial";
        el.hidden = hide;
        if (hide) el.setAttribute("aria-hidden", "true");
        else el.removeAttribute("aria-hidden");
      });
    };

    document.addEventListener("crm:sample-template-hidden", applySampleFilter);

    if (window.__CRM_WORKSPACE_UI_READY__) {
      window.__CRM_WORKSPACE_UI_READY__.then(runGalleryFilter);
    } else {
      window.addEventListener("crm-workspace-ui-ready", runGalleryFilter, { once: true });
    }
    runGalleryFilter();
    if (mineSearch) mineSearch.addEventListener("input", renderMine);
    if (samplesSearch) samplesSearch.addEventListener("input", applySampleFilter);

    loadMineTemplates();
    document.addEventListener("crm:email-template-saved", loadMineTemplates);
    document.addEventListener("crm:reload-email-templates", loadMineTemplates);
    document.addEventListener("crm:template-category-changed", renderMine);
  }

  function wireSubjectLineHelper() {
    if (!subjectField) return;
    const counter = document.getElementById("templateSubjectCharCount");
    const hint = document.getElementById("templateSubjectHint");
    const update = () => {
      const len = String(subjectField.value || "").length;
      if (counter) {
        counter.textContent = len ? `${len} character${len === 1 ? "" : "s"}` : "";
        counter.classList.toggle("is-over-ideal", len > 50);
        counter.classList.toggle("is-long", len > 70);
      }
      if (hint) hint.classList.toggle("is-muted", len > 0 && len <= 50);
    };
    subjectField.addEventListener("input", update);
    subjectField.addEventListener("change", update);
    update();
  }

  function galleryCategoryRank(category) {
    const cat = String(category || "").trim();
    const i = GALLERY_CATEGORY_ORDER.indexOf(cat);
    return i === -1 ? 999 : i;
  }

  function renderCards(grid, templates, filter) {
    if (!grid) return;
    const q = String(filter || "").toLowerCase().trim();
    grid.innerHTML = "";
    const source = Array.isArray(templates) ? templates : SAMPLE_TEMPLATES;
    const matches = source.filter((tpl) => {
      if (!q) return true;
      return `${tpl.name} ${tpl.category} ${tpl.subject}`.toLowerCase().includes(q);
    });
    matches.sort((a, b) => {
      const byCat = galleryCategoryRank(a.category) - galleryCategoryRank(b.category);
      if (byCat !== 0) return byCat;
      return String(a.name || "").localeCompare(String(b.name || ""), undefined, { sensitivity: "base", numeric: true });
    });
    for (const tpl of matches) {
      const card = document.createElement("div");
      card.className = "et-card";
      const htmlThumb = tpl.__saved && String(tpl.thumbHtml || tpl._rawHtml || tpl.html || "").trim();
      let thumbHtml;
      if (htmlThumb) {
        thumbHtml = `<div class="et-card-thumb et-card-thumb--html"><iframe class="et-card-thumb-frame" sandbox="" tabindex="-1" aria-hidden="true" title=""></iframe></div>`;
      } else {
        const thumbStyle = tpl.thumbImage
          ? `background:#0f172a url(${tpl.thumbImage}) center top / cover no-repeat;`
          : `background:${tpl.thumbColor};`;
        const thumbInner = tpl.thumbImage
          ? `<span style="display:block;width:100%;height:100%;background:linear-gradient(180deg,transparent 40%,rgba(15,23,42,0.75));"></span>`
          : tpl.icon;
        thumbHtml = `<div class="et-card-thumb" style="${thumbStyle}">${thumbInner}</div>`;
      }
      card.innerHTML = `
        ${thumbHtml}
        <div class="et-card-body">
          <span class="et-card-cat">${escapeHtml(tpl.category)}</span>
          <span class="et-card-name">${escapeHtml(tpl.name)}</span>
          <div class="et-card-actions">
            <button type="button" data-act="preview">Preview</button>
            <button type="button" data-act="use">Use this</button>
          </div>
        </div>
      `;
      if (htmlThumb) {
        const frame = card.querySelector(".et-card-thumb-frame");
        if (frame) {
          const doc =
            `<!doctype html><html><head><meta charset="utf-8"><style>` +
            `html,body{margin:0;padding:0;background:#fff;overflow:hidden;}` +
            `body{transform-origin:top left;}` +
            `</style></head><body>${htmlThumb}</body></html>`;
          try {
            frame.srcdoc = doc;
          } catch {
            /* ignore */
          }
        }
      }
      card.querySelector('[data-act="use"]').addEventListener("click", () => useSample(tpl));
      card.querySelector('[data-act="preview"]').addEventListener("click", () => previewSample(tpl));
      grid.appendChild(card);
    }
    if (!grid.children.length) {
      grid.innerHTML = `<p class="hint">No templates match your search.</p>`;
    }
  }

  function findSavedRowByName(name) {
    const needle = String(name || "")
      .trim()
      .toLowerCase();
    if (!needle) return null;
    const rows = Array.isArray(window.__CRM_EMAIL_TEMPLATE_ROWS__)
      ? window.__CRM_EMAIL_TEMPLATE_ROWS__
      : [];
    return rows.find((row) => String(row?.name || "").trim().toLowerCase() === needle) || null;
  }

  function useSample(tpl) {
    const actions = window.CadenceEmailTemplateActions || {};

    // Saved thumbnail cards: always load into edit mode with a real template id.
    if (tpl && tpl.__saved && Number(tpl.savedId) > 0) {
      window.__CRM_CURRENT_SAMPLE_TEMPLATE_ID__ = "";
      window.__CRM_CURRENT_SAMPLE_TEMPLATE_NAME__ = "";
      let ok = false;
      if (typeof actions.loadTemplateFromGalleryCard === "function") {
        ok = actions.loadTemplateFromGalleryCard(tpl);
      } else if (typeof actions.loadTemplateIntoEditForm === "function") {
        ok = actions.loadTemplateIntoEditForm(tpl.savedId, {
          id: tpl.savedId,
          name: tpl.name,
          subject: tpl.subject,
          body: tpl._rawHtml || tpl.html || "",
          category_name: tpl.category
        });
      }
      if (!ok) {
        // Last-resort direct write so Delete still has an id.
        const form = document.getElementById("saveTemplateForm");
        const idField = form && form.querySelector('[name="template_id"]');
        const editSelect = document.getElementById("templateEditSelect");
        if (form) form.dataset.editingTemplateId = String(tpl.savedId);
        if (idField) idField.value = String(tpl.savedId);
        if (editSelect) editSelect.value = String(tpl.savedId);
        window.__CRM_CURRENT_TEMPLATE_EDIT_ID__ = Number(tpl.savedId);
        if (nameField) nameField.value = tpl.name || "";
        if (subjectField) subjectField.value = tpl.subject || "";
        editor.innerHTML = resolveSampleHtml(tpl);
      }
      editor.focus();
      editor.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }

    // Sample card that matches an already-saved template (e.g. seeded Paradigmai):
    // load the saved row so Delete Template works.
    const savedMatch = findSavedRowByName(tpl && tpl.name);
    if (savedMatch && Number(savedMatch.id) > 0) {
      if (editor.innerHTML.trim() && !window.confirm("Replace the current editor content with this template?")) {
        return;
      }
      if (typeof actions.loadTemplateFromGalleryCard === "function") {
        actions.loadTemplateFromGalleryCard({
          __saved: true,
          savedId: savedMatch.id,
          name: savedMatch.name,
          subject: savedMatch.subject,
          category: savedMatch.category_name || "",
          html: savedMatch.body || "",
          _rawHtml: savedMatch.body || ""
        });
      } else if (typeof actions.loadTemplateIntoEditForm === "function") {
        actions.loadTemplateIntoEditForm(savedMatch.id, savedMatch);
      }
      editor.focus();
      editor.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }

    if (editor.innerHTML.trim() && !window.confirm("Replace the current editor content with this sample template?")) return;
    editor.innerHTML = resolveSampleHtml(tpl);
    if (subjectField) subjectField.value = tpl.subject || subjectField.value;
    if (nameField) nameField.value = tpl.name || nameField.value;
    // Clear edit-mode id so sample "Use this" doesn't look like an existing save.
    const form = document.getElementById("saveTemplateForm");
    const idField = form && form.querySelector('[name="template_id"]');
    if (form) delete form.dataset.editingTemplateId;
    if (idField) idField.value = "";
    const editSelect = document.getElementById("templateEditSelect");
    if (editSelect) editSelect.value = "";
    window.__CRM_CURRENT_TEMPLATE_EDIT_ID__ = 0;
    window.__CRM_CURRENT_SAMPLE_TEMPLATE_ID__ = String(tpl.id || "");
    window.__CRM_CURRENT_SAMPLE_TEMPLATE_NAME__ = String(tpl.name || "");
    if (typeof actions.setEditingTemplateId === "function") actions.setEditingTemplateId(0);
    editor.focus();
    editor.scrollIntoView({ behavior: "smooth", block: "center" });
  }

  function ensurePreviewModal() {
    let backdrop = document.getElementById("etPreviewBackdrop");
    if (backdrop) {
      // Refresh markup if an older modal (full-width Close / no Delete) is still in the DOM.
      if (
        !backdrop.querySelector(".et-preview-close-x") ||
        !backdrop.querySelector(".et-preview-close-btn") ||
        !backdrop.querySelector("#etPreviewDeleteBtn")
      ) {
        backdrop.remove();
        backdrop = null;
      }
    }
    if (backdrop) return backdrop;
    backdrop = document.createElement("div");
    backdrop.id = "etPreviewBackdrop";
    backdrop.className = "et-preview-backdrop";
    backdrop.innerHTML = `
      <div class="et-preview-modal" role="dialog" aria-modal="true" aria-labelledby="etPreviewTitle">
        <div class="et-preview-head">
          <div>
            <h3 id="etPreviewTitle">Template preview</h3>
            <p class="et-preview-subject" id="etPreviewSubject"></p>
          </div>
          <button type="button" class="et-preview-close-x" data-et-preview-close aria-label="Close preview">×</button>
        </div>
        <div class="et-preview-frame-wrap">
          <iframe class="et-preview-frame" id="etPreviewFrame" title="Template preview" sandbox=""></iframe>
        </div>
        <div class="et-preview-actions">
          <button type="button" class="et-delete" id="etPreviewDeleteBtn">Delete</button>
          <button type="button" class="et-preview-close-btn" data-et-preview-close>Close</button>
          <button type="button" class="et-confirm" id="etPreviewUseBtn">Use this</button>
        </div>
      </div>
    `;
    document.body.appendChild(backdrop);
    backdrop.addEventListener("click", (e) => {
      if (e.target === backdrop || e.target.closest("[data-et-preview-close]")) {
        closePreviewModal();
      }
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && backdrop.classList.contains("is-open")) closePreviewModal();
    });
    return backdrop;
  }

  function closePreviewModal() {
    const backdrop = document.getElementById("etPreviewBackdrop");
    if (!backdrop) return;
    backdrop.classList.remove("is-open");
    const frame = document.getElementById("etPreviewFrame");
    if (frame) {
      try {
        frame.srcdoc = "";
      } catch {
        /* ignore */
      }
    }
    backdrop._etPreviewTpl = null;
  }

  function previewSample(tpl) {
    const backdrop = ensurePreviewModal();
    backdrop._etPreviewTpl = tpl;
    const title = document.getElementById("etPreviewTitle");
    const subject = document.getElementById("etPreviewSubject");
    const frame = document.getElementById("etPreviewFrame");
    const deleteBtn = document.getElementById("etPreviewDeleteBtn");
    const useBtn = document.getElementById("etPreviewUseBtn");
    if (title) title.textContent = tpl.name || "Template preview";
    if (subject) {
      subject.textContent = tpl.subject ? `Subject: ${tpl.subject}` : "";
    }
    const html = resolveSampleHtml(tpl);
    if (frame) {
      frame.srcdoc =
        `<!doctype html><html><head><meta charset="utf-8"><style>` +
        `body{margin:0;font-family:Arial,sans-serif;background:#f1f5f9;padding:20px;}` +
        `</style></head><body>${html}</body></html>`;
    }
    if (deleteBtn) {
      const isSaved = Boolean(tpl.__saved && Number(tpl.savedId) > 0);
      deleteBtn.hidden = false;
      deleteBtn.disabled = false;
      deleteBtn.title = isSaved
        ? "Delete this saved template"
        : "Remove this built-in sample from your gallery";
      deleteBtn.onclick = async () => {
        // Built-in sample: hide from gallery (no DB row).
        if (!isSaved) {
          if (hideBuiltInSample(tpl.id, tpl.name)) closePreviewModal();
          return;
        }
        const actions = window.CadenceEmailTemplateActions;
        try {
          if (actions && typeof actions.deleteEmailTemplateById === "function") {
            const deleted = await actions.deleteEmailTemplateById(tpl.savedId);
            if (deleted) closePreviewModal();
            return;
          }
          if (!window.confirm(`Delete template "${tpl.name}"? This cannot be undone.`)) return;
          const res = await fetch(`/api/email/templates/${tpl.savedId}`, {
            method: "DELETE",
            credentials: "include"
          });
          const data = await res.json().catch(() => ({}));
          if (!res.ok) throw new Error(data.error || "Failed to delete template");
          document.dispatchEvent(new CustomEvent("crm:email-template-saved"));
          document.dispatchEvent(new CustomEvent("crm:reload-email-templates"));
          closePreviewModal();
        } catch (err) {
          window.alert(err.message || "Could not delete template.");
        }
      };
    }
    if (useBtn) {
      useBtn.onclick = () => {
        closePreviewModal();
        useSample(tpl);
      };
    }
    backdrop.classList.add("is-open");
  }

  function buildBlockToolbar() {
    const editorBox = editor.parentElement;
    if (!editorBox) return;
    const toolbar = document.createElement("div");
    toolbar.className = "et-block-toolbar";
    toolbar.innerHTML = `
      <span class="et-block-toolbar-label">Insert Block</span>
      <button type="button" class="et-block-btn" data-block="button">Button</button>
      <button type="button" class="et-block-btn" data-block="hero">Banner</button>
      <button type="button" class="et-block-btn" data-block="divider">Divider</button>
      <button type="button" class="et-block-btn" data-block="spacer">Spacer</button>
      <button type="button" class="et-block-btn" data-block="quote">Comment</button>
      <button type="button" class="et-block-btn" data-block="signature">Signature Card</button>
      <button type="button" class="et-block-btn" data-block="callout">Callout Box</button>
      <button type="button" class="et-block-btn" data-block="emoji" id="etEmojiBtn">Emoji! ☺</button>
      <span class="et-block-bg-cluster" aria-label="Change selected block background">
        <span class="et-block-toolbar-label" style="margin-right: 0">Block BG</span>
        <input type="color" id="etBlockBgColor" value="#ffffff" title="Banner or Callout background color" />
        <button type="button" class="et-block-btn" id="etApplyBlockBgBtn">Apply</button>
      </span>
      <span class="et-theme-cluster" aria-label="Color themes">
        <span class="et-block-toolbar-label" style="margin-right: 0">Theme</span>
        ${THEMES.map((t) => `<span class="et-theme-swatch" data-theme="${t.id}" title="${escapeHtml(t.name)}" style="background: linear-gradient(135deg, ${t.primary}, ${t.accent});"></span>`).join("")}
      </span>
    `;
    editorBox.appendChild(toolbar);

    toolbar.addEventListener("mousedown", (e) => {
      if (
        e.target.closest(".et-block-btn") ||
        e.target.closest(".et-theme-swatch") ||
        e.target.closest(".et-block-bg-cluster") ||
        e.target.closest(".et-block-toolbar-label")
      ) {
        captureEditorRange();
        if (!e.target.closest("#etBlockBgColor")) e.preventDefault();
      }
    });

    const blockBgColor = toolbar.querySelector("#etBlockBgColor");
    const applyBlockBgBtn = toolbar.querySelector("#etApplyBlockBgBtn");
    const applyBlockBgFromControl = () => applySelectedBlockBackground(blockBgColor.value);
    if (blockBgColor) {
      blockBgColor.addEventListener("input", applyBlockBgFromControl);
      blockBgColor.addEventListener("change", applyBlockBgFromControl);
    }
    if (applyBlockBgBtn) {
      applyBlockBgBtn.addEventListener("mousedown", (e) => {
        captureEditorRange();
        e.preventDefault();
      });
    }

    toolbar.addEventListener("click", (e) => {
      const themeEl = e.target.closest(".et-theme-swatch");
      if (themeEl) {
        const theme = THEMES.find((t) => t.id === themeEl.dataset.theme);
        if (theme) applyTheme(theme);
        return;
      }
      if (e.target.closest("#etApplyBlockBgBtn")) {
        applyBlockBgFromControl();
        return;
      }
      const btn = e.target.closest(".et-block-btn");
      if (!btn) return;
      const block = btn.dataset.block;
      if (block === "emoji") return toggleEmojiTray(btn);
      handleBlockInsert(block);
    });

    buildEmojiTray(toolbar);
  }

  function elementHasInlineBackground(el) {
    if (!el || el.nodeType !== 1) return false;
    const inline = String(el.getAttribute && el.getAttribute("style") || "");
    if (!inline) return false;
    return /(?:^|;)\s*(?:background(?:-color)?)\s*:/i.test(inline);
  }

  function findBlockAncestorWithBackground(el) {
    let cur = el && el.nodeType === 1 ? el : el?.parentElement;
    while (cur && cur !== editor && editor.contains(cur)) {
      if (cur.dataset && (cur.dataset.etHero || cur.dataset.etCallout)) return cur;
      if (elementHasInlineBackground(cur)) return cur;
      cur = cur.parentElement;
    }
    return null;
  }

  function findCalloutAncestor(el) {
    let cur = el && el.nodeType === 1 ? el : el?.parentElement;
    while (cur && cur !== editor && editor.contains(cur)) {
      if (cur.dataset && cur.dataset.etCallout) return cur;
      cur = cur.parentElement;
    }
    return null;
  }

  function getSelectedEditableBlock() {
    restoreEditorRange();
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return null;
    const range = sel.getRangeAt(0);
    if (!isRangeInsideEditor(range)) return null;
    const startEl =
      range.startContainer && range.startContainer.nodeType === 1
        ? range.startContainer
        : range.startContainer?.parentElement;
    const direct = findBlockAncestorWithBackground(startEl);
    if (direct) return direct;
    for (const block of editor.querySelectorAll("[data-et-hero], [data-et-callout]")) {
      try {
        if (range.intersectsNode(block)) return block;
      } catch {
        /* ignore detached selection nodes */
      }
    }
    return null;
  }

  function flashBlockBackgroundFeedback(block) {
    if (!block) return;
    const prevOutline = block.style.outline || "";
    const prevOffset = block.style.outlineOffset || "";
    const prevTransition = block.style.transition || "";
    block.style.transition = "outline-color 0.6s ease";
    block.style.outline = "2px solid rgba(37, 99, 235, 0.85)";
    block.style.outlineOffset = "2px";
    setTimeout(() => {
      block.style.outline = prevOutline;
      block.style.outlineOffset = prevOffset;
      block.style.transition = prevTransition;
    }, 700);
  }

  function applySelectedBlockBackground(color) {
    const nextColor = String(color || "").trim();
    if (!/^#[0-9a-f]{6}$/i.test(nextColor)) return;
    const block = getSelectedEditableBlock();
    if (!block) {
      alert("Click inside the Banner or Callout Box first, then choose a Block BG color.");
      return;
    }
    const inline = String(block.getAttribute("style") || "");
    const cleaned = inline
      .replace(/(?:^|;)\s*background\s*:[^;]*/gi, "")
      .replace(/(?:^|;)\s*background-color\s*:[^;]*/gi, "")
      .replace(/^;+/, "")
      .trim();
    const next = `${cleaned ? `${cleaned};` : ""}background:${nextColor};background-color:${nextColor};`;
    block.setAttribute("style", next);
    flashBlockBackgroundFeedback(block);
    editor.dispatchEvent(new Event("input", { bubbles: true }));
    captureEditorRange();
  }

  function buildEmojiTray(parent) {
    const tray = document.createElement("div");
    tray.className = "et-emoji-tray";
    tray.id = "etEmojiTray";
    const emojis = ["👋", "🎉", "🚀", "✨", "🙏", "💡", "📅", "📍", "📞", "✅", "❤️", "🔥", "🌟", "👍", "🎁", "💬", "📧", "📈", "🤝", "💼", "🏆", "🎯", "📰", "🎟️", "🌈", "💎", "👏", "🙌", "❗"];
    tray.innerHTML = emojis.map((e) => `<button type="button">${e}</button>`).join("");
    parent.appendChild(tray);
    tray.addEventListener("mousedown", (e) => {
      if (e.target.closest("button")) {
        captureEditorRange();
        e.preventDefault();
      }
    });
    tray.addEventListener("click", (e) => {
      const b = e.target.closest("button");
      if (!b) return;
      restoreEditorRange();
      insertHtmlAtCaret(b.textContent);
      tray.classList.remove("is-open");
    });
    document.addEventListener("click", (e) => {
      if (!tray.contains(e.target) && !e.target.closest("#etEmojiBtn")) {
        tray.classList.remove("is-open");
      }
    });
  }

  function toggleEmojiTray(btn) {
    captureEditorRange();
    const tray = document.getElementById("etEmojiTray");
    if (!tray) return;
    const willOpen = !tray.classList.contains("is-open");
    if (!willOpen) {
      tray.classList.remove("is-open");
      return;
    }
    tray.style.position = "fixed";
    tray.style.visibility = "hidden";
    tray.classList.add("is-open");
    const margin = 8;
    const btnRect = btn.getBoundingClientRect();
    const trayRect = tray.getBoundingClientRect();
    const viewportW = window.innerWidth || document.documentElement.clientWidth;
    const viewportH = window.innerHeight || document.documentElement.clientHeight;
    const spaceBelow = viewportH - btnRect.bottom;
    const spaceAbove = btnRect.top;
    let top = btnRect.bottom + 6;
    if (trayRect.height + margin > spaceBelow && spaceAbove > spaceBelow) {
      top = btnRect.top - trayRect.height - 6;
    }
    top = Math.max(margin, Math.min(top, viewportH - trayRect.height - margin));
    let left = btnRect.left;
    left = Math.max(margin, Math.min(left, viewportW - trayRect.width - margin));
    tray.style.top = `${top}px`;
    tray.style.left = `${left}px`;
    tray.style.visibility = "";
  }

  function buildBlockPopover() {
    const back = document.createElement("div");
    back.className = "et-popover-backdrop";
    back.id = "etPopoverBackdrop";
    back.innerHTML = `<div class="et-popover" id="etPopover"><div id="etPopoverContent"></div></div>`;
    document.body.appendChild(back);
    back.addEventListener("click", (e) => {
      if (e.target === back) closePopover();
    });
  }

  function captureBoundaryFromCurrentSelection() {
    const sel = window.getSelection();
    if (sel && sel.rangeCount > 0) {
      const r = sel.getRangeAt(0);
      if (isRangeInsideEditor(r)) {
        return {
          startContainer: r.startContainer,
          startOffset: r.startOffset,
          endContainer: r.endContainer,
          endOffset: r.endOffset
        };
      }
    }
    if (savedEditorRange && isRangeInsideEditor(savedEditorRange)) {
      return {
        startContainer: savedEditorRange.startContainer,
        startOffset: savedEditorRange.startOffset,
        endContainer: savedEditorRange.endContainer,
        endOffset: savedEditorRange.endOffset
      };
    }
    return null;
  }

  function applyBoundaryToEditorSelection(boundary) {
    if (!boundary) return false;
    const { startContainer, startOffset, endContainer, endOffset } = boundary;
    if (!editor.contains(startContainer) || !editor.contains(endContainer)) return false;
    editor.focus();
    const sel = window.getSelection();
    if (!sel) return false;
    try {
      const range = document.createRange();
      range.setStart(startContainer, startOffset);
      range.setEnd(endContainer, endOffset);
      sel.removeAllRanges();
      sel.addRange(range);
      savedEditorRange = range.cloneRange();
      return true;
    } catch {
      return false;
    }
  }

  function openPopover(title, fieldsHtml, onConfirm) {
    const insertionBoundary = captureBoundaryFromCurrentSelection();
    const back = document.getElementById("etPopoverBackdrop");
    const content = document.getElementById("etPopoverContent");
    content.innerHTML = `
      <h3>${escapeHtml(title)}</h3>
      ${fieldsHtml}
      <div class="et-popover-actions">
        <button type="button" class="et-cancel" data-act="cancel">Cancel</button>
        <button type="button" class="et-confirm" data-act="confirm">Insert</button>
      </div>
    `;
    back.classList.add("is-open");
    const cancelBtn = content.querySelector('[data-act="cancel"]');
    const confirmBtn = content.querySelector('[data-act="confirm"]');
    cancelBtn.addEventListener("mousedown", (e) => e.preventDefault());
    confirmBtn.addEventListener("mousedown", (e) => e.preventDefault());
    cancelBtn.addEventListener("click", closePopover);
    confirmBtn.addEventListener("click", () => {
      try {
        applyBoundaryToEditorSelection(insertionBoundary);
        onConfirm(content);
        closePopover();
      } catch (err) {
        alert(err.message || "Could not insert block.");
      }
    });
    const firstInput = content.querySelector("input, textarea");
    if (firstInput) firstInput.focus();
  }

  function closePopover() {
    document.getElementById("etPopoverBackdrop").classList.remove("is-open");
  }

  function handleBlockInsert(kind) {
    if (kind === "divider") {
      insertHtmlAtCaret(`<hr style="border:none;border-top:1px solid #d8dee8;margin:18px 0;" />`);
      return;
    }
    if (kind === "spacer") {
      insertHtmlAtCaret(`<div style="height:24px;line-height:24px;font-size:1px;">&nbsp;</div>`);
      return;
    }
    if (kind === "button") {
      openPopover("Insert Button", `
        <div class="field"><label>Button text</label><input type="text" id="bp-text" value="Click here" /></div>
        <div class="field"><label>Link URL</label><input type="url" id="bp-url" placeholder="https://..." /></div>
        <div class="row">
          <div class="field"><label>Background</label><input type="color" id="bp-bg" value="#2563eb" /></div>
          <div class="field"><label>Text color</label><input type="color" id="bp-fg" value="#ffffff" /></div>
        </div>
      `, (c) => {
        const text = c.querySelector("#bp-text").value.trim() || "Click here";
        const url = c.querySelector("#bp-url").value.trim() || "#";
        const bg = c.querySelector("#bp-bg").value;
        const fg = c.querySelector("#bp-fg").value;
        const html = `<p style="text-align:center;margin:18px 0;"><a href="${encodeAttr(url)}" data-cadence-cta="1" style="display:inline-block;background:${bg};color:${fg};text-decoration:none;padding:12px 28px;border-radius:8px;font-weight:700;font-family:Arial,sans-serif;">${escapeHtml(text)}</a></p>`;
        insertHtmlAtCaret(html);
      });
      return;
    }
    if (kind === "hero") {
      openPopover("Insert Banner", `
        <div class="field"><label>Headline</label><input type="text" id="hb-h" value="Welcome to Cadence" /></div>
        <div class="field"><label>Subtext</label><input type="text" id="hb-s" value="A quick note before we dive in." /></div>
        <div class="row">
          <div class="field"><label>Start color</label><input type="color" id="hb-c1" value="#2563eb" /></div>
          <div class="field"><label>End color</label><input type="color" id="hb-c2" value="#1e40af" /></div>
          <div class="field"><label>Text color</label><input type="color" id="hb-tc" value="#ffffff" /></div>
        </div>
        <div class="row">
          <div class="field"><label>Width</label><input type="text" id="hb-w" value="100%" placeholder="e.g. 100% or 600px" /></div>
          <div class="field"><label>Height (optional)</label><input type="text" id="hb-mh" value="" placeholder="auto, or e.g. 160px" /></div>
        </div>
        <p style="margin:6px 0 0;font-size:0.78rem;color:#64748b;">Tip: after inserting, drag the bottom-right corner to resize. Leave height blank to auto-fit the text.</p>
      `, (c) => {
        const h = c.querySelector("#hb-h").value || "Welcome";
        const s = c.querySelector("#hb-s").value || "";
        const c1 = c.querySelector("#hb-c1").value;
        const c2 = c.querySelector("#hb-c2").value;
        const tc = c.querySelector("#hb-tc").value;
        const w = String(c.querySelector("#hb-w").value || "100%").trim() || "100%";
        const heightInput = String(c.querySelector("#hb-mh").value || "").trim();
        const heightStyle = heightInput ? `height:${heightInput};` : "";
        const html = `<div data-et-hero="1" style="background:linear-gradient(135deg,${c1},${c2});color:${tc};padding:24px 22px;border-radius:14px;text-align:center;margin:0 0 18px;font-family:Arial,sans-serif;width:${w};max-width:100%;${heightStyle}min-width:80px;min-height:48px;box-sizing:border-box;resize:both;overflow:hidden;word-break:break-word;"><h1 style="margin:0 0 6px;font-size:1.6rem;line-height:1.2;">${escapeHtml(h)}</h1><p style="margin:0;opacity:0.92;font-size:1rem;line-height:1.35;">${escapeHtml(s)}</p></div>`;
        insertHtmlAtCaret(html);
      });
      return;
    }
    if (kind === "quote") {
      openPopover("Insert Comment Box", `
        <div class="field"><label>Comment text</label><textarea id="q-t" rows="3">A great experience all around.</textarea></div>
        <div class="field"><label>Attribution</label><input type="text" id="q-a" value="— Happy customer" /></div>
      `, (c) => {
        const t = c.querySelector("#q-t").value || "";
        const a = c.querySelector("#q-a").value || "";
        const html = `<blockquote style="margin:18px 0;padding:14px 18px;border-left:4px solid #2563eb;background:#f8fafc;font-style:italic;font-family:Georgia,serif;border-radius:0 8px 8px 0;">${escapeHtml(t)}<footer style="margin-top:6px;font-style:normal;font-size:0.88rem;color:#64748b;font-family:Arial,sans-serif;">${escapeHtml(a)}</footer></blockquote>`;
        insertHtmlAtCaret(html);
      });
      return;
    }
    if (kind === "signature") {
      openPopover("Insert Signature Card", `
        <div class="field"><label>Name</label><input type="text" id="sg-n" value="Your Name" /></div>
        <div class="field"><label>Title</label><input type="text" id="sg-t" value="Your Title, Cadence" /></div>
        <div class="row">
          <div class="field"><label>Email</label><input type="text" id="sg-e" value="you@cadence.com" /></div>
          <div class="field"><label>Phone</label><input type="text" id="sg-p" placeholder="(555) 123-4567" /></div>
        </div>
        <div class="field"><label>Accent color</label><input type="color" id="sg-c" value="#2563eb" /></div>
      `, (c) => {
        const n = c.querySelector("#sg-n").value || "";
        const t = c.querySelector("#sg-t").value || "";
        const e = c.querySelector("#sg-e").value || "";
        const p = c.querySelector("#sg-p").value || "";
        const cl = c.querySelector("#sg-c").value;
        const phoneRow = p ? `<div style="font-size:0.88rem;color:#475569;">📞 ${escapeHtml(p)}</div>` : "";
        const html = `<table cellpadding="0" cellspacing="0" border="0" style="margin:18px 0;font-family:Arial,sans-serif;"><tr><td style="border-left:4px solid ${cl};padding:10px 16px;"><div style="font-weight:800;color:#0f172a;font-size:1.05rem;">${escapeHtml(n)}</div><div style="color:#64748b;font-size:0.9rem;margin:2px 0 6px;">${escapeHtml(t)}</div><div style="font-size:0.88rem;color:${cl};"><a href="mailto:${encodeAttr(e)}" style="color:${cl};text-decoration:none;">✉ ${escapeHtml(e)}</a></div>${phoneRow}</td></tr></table>`;
        insertHtmlAtCaret(html);
      });
      return;
    }
    if (kind === "callout") {
      openPopover("Insert Callout Box", `
        <div class="field"><label>Headline</label><input type="text" id="co-h" value="Heads up!" /></div>
        <div class="field"><label>Body text</label><textarea id="co-b" rows="3">Important information your reader should not miss.</textarea></div>
        <div class="row">
          <div class="field"><label>Background</label><input type="color" id="co-bg" value="#ffffff" /></div>
          <div class="field"><label>Border</label><input type="color" id="co-bd" value="#000000" /></div>
          <div class="field"><label>Text color</label><input type="color" id="co-tc" value="#000000" /></div>
        </div>
        <p style="margin:6px 0 0;font-size:0.78rem;color:#64748b;">Tip: after inserting, drag the bottom-right corner to resize the callout.</p>
      `, (c) => {
        const h = c.querySelector("#co-h").value || "";
        const b = c.querySelector("#co-b").value || "";
        const bg = c.querySelector("#co-bg").value;
        const bd = c.querySelector("#co-bd").value;
        const tc = c.querySelector("#co-tc").value;
        const html = `<div data-et-callout="1" style="background:${bg};border:1px solid ${bd};border-radius:10px;padding:14px 18px;margin:18px 0;color:${tc};font-family:Arial,sans-serif;width:100%;max-width:100%;min-width:120px;min-height:56px;box-sizing:border-box;resize:both;overflow:auto;word-break:break-word;"><div style="font-weight:800;margin-bottom:4px;">${escapeHtml(h)}</div><div style="font-size:0.95rem;line-height:1.5;">${escapeHtml(b)}</div></div>`;
        insertHtmlAtCaret(html);
      });
      return;
    }
  }

  function applyTheme(theme) {
    const html = `<div data-theme="${theme.id}" style="background:${theme.surface};color:${theme.text};border-radius:14px;padding:24px;font-family:Arial,sans-serif;">
  <div style="background:linear-gradient(135deg,${theme.primary},${theme.accent});color:#ffffff;border-radius:10px;padding:22px;text-align:center;margin-bottom:18px;">
    <h1 style="margin:0 0 6px;font-size:1.7rem;">Hi {{first_name}}</h1>
    <p style="margin:0;opacity:0.92;">A fresh ${escapeHtml(theme.name)} look for your next email.</p>
  </div>
  <p style="margin:0 0 14px;line-height:1.55;">Replace this paragraph with your own message. Use the toolbar above to add buttons, dividers, signatures, and more.</p>
  <p style="margin:0 0 18px;line-height:1.55;">Need a call to action? Try the <strong>Button</strong> block. Want a personal sign-off? Insert a <strong>Signature Card</strong>.</p>
  <p style="text-align:center;margin:0 0 0;"><a href="#" data-cadence-cta="1" style="display:inline-block;background:${theme.primary};color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:8px;font-weight:700;">Take action</a></p>
</div>`;
    if (editor.innerHTML.trim() && !window.confirm(`Replace the current editor content with the ${theme.name} theme?`)) return;
    editor.innerHTML = html;
    editor.focus();
  }

  const BLOCK_LEVEL_TAGS = new Set([
    "DIV", "P", "BLOCKQUOTE", "HR", "TABLE", "UL", "OL", "PRE", "SECTION",
    "ARTICLE", "ASIDE", "FIGURE", "FIGCAPTION", "H1", "H2", "H3", "H4", "H5", "H6"
  ]);

  function isBlockLevelNode(node) {
    return Boolean(node && node.nodeType === 1 && BLOCK_LEVEL_TAGS.has(node.tagName));
  }

  function isEffectivelyEmptyElement(node) {
    if (!node || node.nodeType !== 1) return false;
    if (node.querySelector("img, table, hr, blockquote, ul, ol")) return false;
    const html = String(node.innerHTML || "")
      .replace(/<br\s*\/?>/gi, "")
      .replace(/&nbsp;/gi, "")
      .trim();
    return !html && !String(node.textContent || "").trim();
  }

  function getTopLevelEditorChild(node) {
    let cur = node && node.nodeType === 1 ? node : node?.parentElement;
    while (cur && cur.parentElement && cur.parentElement !== editor) {
      cur = cur.parentElement;
    }
    return cur && cur.parentElement === editor ? cur : null;
  }

  function normalizeBlockInsertionRange(range, insertsBlock) {
    if (!insertsBlock || !range) return range;
    if (findCalloutAncestor(range.commonAncestorContainer)) return range;
    const topLevel = getTopLevelEditorChild(range.commonAncestorContainer);
    if (!topLevel) return range;
    const normalized = document.createRange();
    if (isEffectivelyEmptyElement(topLevel)) {
      normalized.setStartBefore(topLevel);
      normalized.setEndAfter(topLevel);
    } else {
      normalized.setStartAfter(topLevel);
      normalized.collapse(true);
    }
    return normalized;
  }

  function placeCaretInTrailingParagraph(afterNode) {
    if (!afterNode || !afterNode.parentNode) return;
    const trailer = document.createElement("p");
    trailer.innerHTML = "<br>";
    afterNode.parentNode.insertBefore(trailer, afterNode.nextSibling);
    const sel = window.getSelection();
    if (!sel) return;
    const r = document.createRange();
    r.setStart(trailer, 0);
    r.collapse(true);
    sel.removeAllRanges();
    sel.addRange(r);
    savedEditorRange = r.cloneRange();
  }

  function insertHtmlAtCaret(html) {
    let sel = window.getSelection();
    const liveRangeInsideEditor = sel && sel.rangeCount > 0 && editor.contains(sel.anchorNode);
    if (!liveRangeInsideEditor) {
      restoreEditorRange();
      sel = window.getSelection();
    }
    let lastInsertedNode = null;
    const tmp = document.createElement("div");
    tmp.innerHTML = html;
    const insertsBlock = Array.from(tmp.childNodes).some(isBlockLevelNode);
    if (sel && sel.rangeCount > 0 && editor.contains(sel.anchorNode)) {
      const range = normalizeBlockInsertionRange(sel.getRangeAt(0), insertsBlock);
      range.deleteContents();
      const frag = document.createDocumentFragment();
      let node;
      while ((node = tmp.firstChild)) {
        lastInsertedNode = frag.appendChild(node);
      }
      range.insertNode(frag);
      if (lastInsertedNode) {
        const newRange = document.createRange();
        newRange.setStartAfter(lastInsertedNode);
        newRange.collapse(true);
        sel.removeAllRanges();
        sel.addRange(newRange);
        savedEditorRange = newRange.cloneRange();
      }
    } else {
      while (tmp.firstChild) {
        lastInsertedNode = editor.appendChild(tmp.firstChild);
      }
      captureEditorRange();
    }
    if (isBlockLevelNode(lastInsertedNode)) {
      placeCaretInTrailingParagraph(lastInsertedNode);
    }
    editor.dispatchEvent(new Event("input", { bubbles: true }));
    editor.focus();
  }

  function escapeHtml(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function encodeAttr(s) {
    return String(s == null ? "" : s).replace(/"/g, "&quot;");
  }

  // ===== Sample template HTML builders =====

  function warmWelcomeHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:600px;">
  <div style="background:linear-gradient(135deg,#6366f1,#ec4899);color:#ffffff;border-radius:14px;padding:34px 28px;text-align:center;">
    <div style="font-size:2.6rem;line-height:1;margin-bottom:6px;">👋</div>
    <h1 style="margin:0 0 6px;font-size:1.8rem;">Welcome aboard, {{first_name}}!</h1>
    <p style="margin:0;opacity:0.92;">We're so glad you're here.</p>
  </div>
  <p style="margin:18px 0;line-height:1.6;">Hi {{first_name}}, thanks for joining us. Here are a few things you can do right away to make the most of your account:</p>
  <ul style="margin:0 0 18px 20px;line-height:1.7;">
    <li>Explore your dashboard.</li>
    <li>Personalize your profile.</li>
    <li>Reply to this email if you need anything — a real human reads every message.</li>
  </ul>
  <p style="text-align:center;margin:24px 0;"><a href="#" style="display:inline-block;background:#4f46e5;color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:8px;font-weight:700;">Open my dashboard</a></p>
  <p style="margin:18px 0 0;line-height:1.55;">Cheers,<br/><strong>The Cadence Team</strong></p>
</div>`;
  }

  function newsletterHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:620px;">
  <div style="background:#0ea5e9;color:#ffffff;padding:18px 24px;border-radius:12px 12px 0 0;display:flex;justify-content:space-between;align-items:center;">
    <strong style="font-size:1.1rem;">Cadence Monthly</strong>
    <span style="opacity:0.85;font-size:0.85rem;">{{date_of_contact}}</span>
  </div>
  <div style="background:#ffffff;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 12px 12px;padding:24px;">
    <h2 style="margin:0 0 12px;color:#0c4a6e;">Highlights you might've missed</h2>
    <p style="margin:0 0 18px;line-height:1.6;">Hi {{first_name}}, here's a quick roundup of what's new this month — three reads under five minutes each.</p>
    <div style="display:block;margin-bottom:16px;border-bottom:1px solid #e2e8f0;padding-bottom:14px;">
      <strong style="font-size:1.05rem;color:#0c4a6e;">📈 The metric that matters most</strong>
      <p style="margin:4px 0 0;line-height:1.55;color:#334155;">Why north-star metrics outperform vanity dashboards every quarter.</p>
    </div>
    <div style="display:block;margin-bottom:16px;border-bottom:1px solid #e2e8f0;padding-bottom:14px;">
      <strong style="font-size:1.05rem;color:#0c4a6e;">🛠️ Three tools we love</strong>
      <p style="margin:4px 0 0;line-height:1.55;color:#334155;">A short list of underrated tools that punch way above their weight.</p>
    </div>
    <div style="display:block;margin-bottom:18px;">
      <strong style="font-size:1.05rem;color:#0c4a6e;">🎯 Customer story: Acme</strong>
      <p style="margin:4px 0 0;line-height:1.55;color:#334155;">How Acme cut their onboarding time by 60% in 30 days.</p>
    </div>
    <p style="text-align:center;margin:18px 0 0;"><a href="#" style="display:inline-block;background:#0284c7;color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:8px;font-weight:700;">Read the full issue</a></p>
  </div>
</div>`;
  }

  function promoHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:600px;">
  <div style="background:linear-gradient(135deg,#f97316,#ef4444);color:#ffffff;padding:36px 24px;text-align:center;border-radius:14px;">
    <div style="font-size:0.9rem;opacity:0.92;letter-spacing:0.18em;text-transform:uppercase;">Limited Time</div>
    <h1 style="margin:8px 0 4px;font-size:2.4rem;">Save 30% Today</h1>
    <p style="margin:0;font-size:1.05rem;opacity:0.95;">Code <strong>CADENCE30</strong> · Ends Friday</p>
  </div>
  <p style="margin:22px 0;line-height:1.6;font-size:1rem;">Hi {{first_name}}, just a quick heads-up: our biggest sale of the season is live for the next 72 hours. No catch, no fine print — just 30% off everything.</p>
  <p style="text-align:center;margin:18px 0;"><a href="#" style="display:inline-block;background:#ef4444;color:#ffffff;text-decoration:none;padding:14px 36px;border-radius:999px;font-weight:800;font-size:1.05rem;">Shop the sale →</a></p>
  <p style="margin:18px 0 0;font-size:0.85rem;color:#64748b;text-align:center;">Offer ends 11:59 PM Friday. Cannot be combined with other promotions.</p>
</div>`;
  }

  function eventInviteHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:600px;">
  <div style="background:linear-gradient(135deg,#7c3aed,#2563eb);color:#ffffff;border-radius:14px;padding:34px 28px;text-align:center;">
    <div style="font-size:0.85rem;letter-spacing:0.2em;text-transform:uppercase;opacity:0.85;">You're Invited</div>
    <h1 style="margin:6px 0 2px;font-size:2rem;">Cadence Connect 2026</h1>
    <p style="margin:0;opacity:0.92;">An evening of ideas, conversations, and craft cocktails.</p>
  </div>
  <table cellpadding="0" cellspacing="0" border="0" style="width:100%;margin:24px 0;font-family:Arial,sans-serif;">
    <tr>
      <td style="padding:0 8px 0 0;width:50%;vertical-align:top;background:#f1f5f9;border-radius:10px;text-align:center;padding:18px 12px;">
        <div style="font-size:0.78rem;color:#64748b;letter-spacing:0.1em;text-transform:uppercase;font-weight:700;">When</div>
        <div style="font-size:1.05rem;color:#0f172a;font-weight:700;margin-top:4px;">Friday, June 12</div>
        <div style="font-size:0.92rem;color:#475569;">6:00 – 9:00 PM</div>
      </td>
      <td style="width:8px;"></td>
      <td style="width:50%;vertical-align:top;background:#f1f5f9;border-radius:10px;text-align:center;padding:18px 12px;">
        <div style="font-size:0.78rem;color:#64748b;letter-spacing:0.1em;text-transform:uppercase;font-weight:700;">Where</div>
        <div style="font-size:1.05rem;color:#0f172a;font-weight:700;margin-top:4px;">The Innovation Loft</div>
        <div style="font-size:0.92rem;color:#475569;">123 Main Street</div>
      </td>
    </tr>
  </table>
  <p style="margin:0 0 14px;line-height:1.6;">Hi {{first_name}}, we'd love to have you. Drinks, demos, and a few surprises — RSVP below so we can save you a spot.</p>
  <p style="text-align:center;margin:22px 0 8px;"><a href="#" style="display:inline-block;background:#7c3aed;color:#ffffff;text-decoration:none;padding:12px 32px;border-radius:8px;font-weight:700;">RSVP now</a></p>
</div>`;
  }

  function productLaunchHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:620px;">
  <div style="background:#0f172a;color:#ffffff;padding:40px 28px;text-align:center;border-radius:14px;">
    <div style="font-size:0.85rem;letter-spacing:0.2em;text-transform:uppercase;opacity:0.7;">New from Cadence</div>
    <h1 style="margin:8px 0 6px;font-size:2.2rem;">Meet Cadence Pulse</h1>
    <p style="margin:0;opacity:0.85;">The fastest way to stay in rhythm with your customers.</p>
  </div>
  <p style="margin:22px 0 18px;line-height:1.6;font-size:1rem;">Hi {{first_name}}, today we're shipping something we've been working on for months. Three reasons you'll love it:</p>
  <table cellpadding="0" cellspacing="0" border="0" style="width:100%;margin:0 0 22px;">
    <tr>
      <td style="vertical-align:top;padding:0 6px 12px 0;">
        <div style="font-size:1.5rem;">⚡</div>
        <strong style="display:block;margin:4px 0;">Lightning fast</strong>
        <span style="color:#475569;font-size:0.9rem;line-height:1.45;display:block;">Send 10x faster with smart drafts.</span>
      </td>
      <td style="vertical-align:top;padding:0 6px 12px 6px;">
        <div style="font-size:1.5rem;">🎯</div>
        <strong style="display:block;margin:4px 0;">Right people</strong>
        <span style="color:#475569;font-size:0.9rem;line-height:1.45;display:block;">Auto-segments built in.</span>
      </td>
      <td style="vertical-align:top;padding:0 0 12px 6px;">
        <div style="font-size:1.5rem;">📊</div>
        <strong style="display:block;margin:4px 0;">Real signals</strong>
        <span style="color:#475569;font-size:0.9rem;line-height:1.45;display:block;">Open rates that actually mean something.</span>
      </td>
    </tr>
  </table>
  <p style="text-align:center;margin:0 0 12px;"><a href="#" style="display:inline-block;background:#0f172a;color:#ffffff;text-decoration:none;padding:12px 32px;border-radius:8px;font-weight:700;">Try it free for 14 days</a></p>
  <p style="margin:0;text-align:center;font-size:0.85rem;color:#64748b;">No credit card required.</p>
</div>`;
  }

  function followUpHtml() {
    return `<div style="font-family:Georgia,serif;color:#1e293b;max-width:560px;line-height:1.65;font-size:1rem;">
  <p>Hi {{first_name}},</p>
  <p>Just circling back on my last note — I know inboxes are busy, so no pressure at all.</p>
  <p>If now's a good time, here are three options that fit most schedules:</p>
  <ul style="margin:8px 0 16px 20px;">
    <li>Tuesday afternoon (your timezone)</li>
    <li>Wednesday before noon</li>
    <li>Thursday — anytime works</li>
  </ul>
  <p>Reply with whichever is easiest, or suggest a time that works better. If now isn't the right moment, just say so — I'll happily check back in a couple of weeks.</p>
  <p>Talk soon,<br/><strong>{{full_name}}</strong></p>
</div>`;
  }

  function thankYouHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:560px;text-align:center;">
  <div style="background:linear-gradient(135deg,#f59e0b,#d97706);color:#ffffff;border-radius:14px;padding:44px 28px;">
    <div style="font-size:3rem;line-height:1;">🙏</div>
    <h1 style="margin:10px 0 4px;font-size:1.8rem;">Thank you, {{first_name}}</h1>
    <p style="margin:0;opacity:0.95;font-size:1.05rem;">From all of us at Cadence.</p>
  </div>
  <p style="margin:22px 0;line-height:1.6;text-align:left;">It's customers like you who make our work feel meaningful. We just wanted to take a moment to say it plainly: we appreciate you.</p>
  <p style="margin:14px 0 0;line-height:1.55;text-align:left;">If there's anything we can do to make your experience even better, just reply to this email — we read every one.</p>
  <p style="margin:24px 0 0;text-align:left;">Warmly,<br/><strong>The Cadence Team</strong></p>
</div>`;
  }

  function reengageHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:560px;">
  <div style="background:linear-gradient(135deg,#db2777,#9333ea);color:#ffffff;border-radius:14px;padding:34px 24px;text-align:center;">
    <div style="font-size:2.4rem;line-height:1;">✨</div>
    <h1 style="margin:8px 0 4px;font-size:1.7rem;">We've missed you, {{first_name}}</h1>
    <p style="margin:0;opacity:0.92;">Here's a little something to bring you back.</p>
  </div>
  <p style="margin:22px 0 14px;line-height:1.6;">It's been a while, and a lot has changed since you last popped in. We're shipping faster, and your feedback would mean the world to us.</p>
  <div style="background:#fdf2f8;border:1px dashed #db2777;border-radius:10px;padding:16px;text-align:center;margin:0 0 22px;">
    <div style="font-size:0.78rem;letter-spacing:0.18em;text-transform:uppercase;color:#9d174d;font-weight:800;">Welcome back gift</div>
    <div style="font-size:1.4rem;color:#831843;font-weight:800;margin:4px 0;">25% off your next month</div>
    <div style="font-size:0.85rem;color:#9d174d;">Code <strong>BACKWITHCADENCE</strong></div>
  </div>
  <p style="text-align:center;margin:0 0 14px;"><a href="#" style="display:inline-block;background:#db2777;color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:8px;font-weight:700;">Pick up where you left off</a></p>
  <p style="margin:18px 0 0;font-size:0.85rem;color:#64748b;text-align:center;">If life took you elsewhere, no hard feelings — <a href="{{unsubscribe_url}}" style="color:#64748b;">unsubscribe here</a>.</p>
</div>`;
  }

  function hiOpenEnrollmentHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:600px;">
  <div style="background:linear-gradient(135deg,#0c4a6e,#0ea5e9);color:#ffffff;border-radius:14px;padding:30px 26px;text-align:center;">
    <div style="font-size:0.78rem;letter-spacing:0.2em;text-transform:uppercase;opacity:0.85;">Open Enrollment</div>
    <h1 style="margin:6px 0 4px;font-size:1.8rem;">Don't get caught uncovered</h1>
    <p style="margin:0;opacity:0.92;">Open enrollment ends soon — let's lock in the right plan together.</p>
  </div>
  <p style="margin:22px 0 14px;line-height:1.65;">Hi {{first_name}}, the open enrollment window for individual and family health plans is closing in a few weeks. Once it ends, you generally can't change coverage until next year unless you have a qualifying life event.</p>
  <div style="background:#f0f9ff;border-left:4px solid #0284c7;border-radius:0 10px 10px 0;padding:14px 18px;margin:0 0 22px;">
    <div style="font-weight:800;color:#0c4a6e;margin-bottom:4px;">What we'll review on a quick 15-minute call:</div>
    <ul style="margin:6px 0 0 18px;padding:0;line-height:1.6;color:#1e293b;">
      <li>Your current coverage and any changes for next year</li>
      <li>Premiums, deductibles, and out-of-pocket maximums</li>
      <li>Whether you qualify for a subsidy or premium tax credit</li>
      <li>Network and prescription coverage for the plans you're considering</li>
    </ul>
  </div>
  <p style="text-align:center;margin:0 0 14px;"><a href="#" style="display:inline-block;background:#0284c7;color:#ffffff;text-decoration:none;padding:13px 30px;border-radius:8px;font-weight:700;">Book my 15-minute review</a></p>
  <p style="margin:18px 0 0;line-height:1.55;">Prefer to talk directly? Just reply to this email or call <strong>{{phone}}</strong> — no obligation, ever.</p>
  <p style="margin:18px 0 0;line-height:1.55;">Looking out for you,<br/><strong>{{full_name}}</strong><br/><span style="color:#64748b;font-size:0.9rem;">Licensed Health Insurance Agent</span></p>
</div>`;
  }

  function hiQuoteFollowUpHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:560px;">
  <p style="margin:0 0 14px;line-height:1.65;">Hi {{first_name}},</p>
  <p style="margin:0 0 14px;line-height:1.65;">Thanks again for letting me put together a quote for you. I wanted to circle back to see if you had a chance to look it over and answer any questions that came up.</p>
  <div style="background:#ecfeff;border:1px solid #a5f3fc;border-radius:12px;padding:18px 20px;margin:0 0 18px;">
    <div style="font-size:0.78rem;letter-spacing:0.16em;text-transform:uppercase;color:#0e7490;font-weight:800;">Your quote at a glance</div>
    <div style="font-size:1.4rem;color:#0c4a6e;font-weight:800;margin:6px 0 4px;">{{quote}}</div>
    <div style="color:#0e7490;font-size:0.92rem;">Coverage start: <strong>{{coverage_start_date}}</strong></div>
  </div>
  <p style="margin:0 0 14px;line-height:1.65;">A few things people commonly want to dig into:</p>
  <ul style="margin:0 0 18px 22px;line-height:1.7;color:#1e293b;">
    <li>Whether your preferred doctors and hospitals are in-network</li>
    <li>How prescriptions you take regularly are covered</li>
    <li>What a typical year of out-of-pocket costs would look like</li>
    <li>Adding a spouse, child, or HSA-compatible plan</li>
  </ul>
  <p style="text-align:center;margin:0 0 16px;"><a href="#" style="display:inline-block;background:#0e7490;color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:8px;font-weight:700;">Schedule a 10-min call</a></p>
  <p style="margin:0;line-height:1.65;">If now isn't a great moment, just reply with a couple of times that work and I'll send a calendar hold. No pressure — I just want to make sure you have what you need to decide with confidence.</p>
  <p style="margin:18px 0 0;line-height:1.55;">Talk soon,<br/><strong>{{full_name}}</strong><br/><span style="color:#64748b;font-size:0.9rem;">Your licensed health insurance agent</span></p>
</div>`;
  }

  function hiPlanCompareHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:640px;">
  <div style="background:linear-gradient(135deg,#1e40af,#6366f1);color:#ffffff;border-radius:14px;padding:28px 24px;text-align:center;">
    <h1 style="margin:0 0 6px;font-size:1.7rem;">Three plans tailored to you</h1>
    <p style="margin:0;opacity:0.92;">Side-by-side, no jargon. Pick the one that fits.</p>
  </div>
  <p style="margin:22px 0 16px;line-height:1.65;">Hi {{first_name}}, based on what we talked through, here are the three options I'd recommend you consider:</p>
  <table cellpadding="0" cellspacing="0" border="0" style="width:100%;font-family:Arial,sans-serif;border-collapse:separate;border-spacing:8px 0;">
    <tr>
      <td style="vertical-align:top;background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:16px;width:33%;">
        <div style="font-size:0.74rem;letter-spacing:0.14em;text-transform:uppercase;color:#64748b;font-weight:800;">Bronze</div>
        <div style="font-weight:800;color:#0f172a;font-size:1.2rem;margin:4px 0 2px;">Lowest monthly cost</div>
        <div style="color:#475569;font-size:0.9rem;line-height:1.5;">Lower premium, higher deductible. Great if you're healthy and want catastrophic protection.</div>
        <div style="margin-top:10px;font-size:1.4rem;font-weight:800;color:#1e40af;">$XXX<span style="font-size:0.78rem;color:#64748b;font-weight:600;">/mo</span></div>
      </td>
      <td style="vertical-align:top;background:#eef2ff;border:2px solid #6366f1;border-radius:12px;padding:16px;width:33%;position:relative;">
        <div style="position:absolute;top:-10px;right:12px;background:#6366f1;color:#ffffff;font-size:0.66rem;letter-spacing:0.14em;font-weight:800;padding:3px 8px;border-radius:999px;">RECOMMENDED</div>
        <div style="font-size:0.74rem;letter-spacing:0.14em;text-transform:uppercase;color:#4338ca;font-weight:800;">Silver</div>
        <div style="font-weight:800;color:#0f172a;font-size:1.2rem;margin:4px 0 2px;">Best balance</div>
        <div style="color:#475569;font-size:0.9rem;line-height:1.5;">Moderate premium with predictable copays. Most clients pick this tier.</div>
        <div style="margin-top:10px;font-size:1.4rem;font-weight:800;color:#4338ca;">$XXX<span style="font-size:0.78rem;color:#64748b;font-weight:600;">/mo</span></div>
      </td>
      <td style="vertical-align:top;background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:16px;width:33%;">
        <div style="font-size:0.74rem;letter-spacing:0.14em;text-transform:uppercase;color:#64748b;font-weight:800;">Gold</div>
        <div style="font-weight:800;color:#0f172a;font-size:1.2rem;margin:4px 0 2px;">Lowest out-of-pocket</div>
        <div style="color:#475569;font-size:0.9rem;line-height:1.5;">Higher premium, but very low deductible and copays. Ideal if you visit doctors often.</div>
        <div style="margin-top:10px;font-size:1.4rem;font-weight:800;color:#1e40af;">$XXX<span style="font-size:0.78rem;color:#64748b;font-weight:600;">/mo</span></div>
      </td>
    </tr>
  </table>
  <p style="margin:22px 0 14px;line-height:1.65;">Want me to walk through these on a quick call so you can ask questions and pick with confidence?</p>
  <p style="text-align:center;margin:0 0 14px;"><a href="#" style="display:inline-block;background:#4338ca;color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:8px;font-weight:700;">Book a comparison call</a></p>
  <p style="margin:18px 0 0;line-height:1.55;">Here for you,<br/><strong>{{full_name}}</strong></p>
</div>`;
  }

  function hiLifeEventHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:560px;">
  <div style="background:linear-gradient(135deg,#15803d,#84cc16);color:#ffffff;border-radius:14px;padding:30px 26px;text-align:center;">
    <div style="font-size:2.2rem;line-height:1;">🎉</div>
    <h1 style="margin:8px 0 4px;font-size:1.65rem;">Big life change? Congratulations.</h1>
    <p style="margin:0;opacity:0.92;">Let's make sure your coverage keeps up.</p>
  </div>
  <p style="margin:22px 0 14px;line-height:1.65;">Hi {{first_name}}, marriage, a new baby, a move, a new job — they all open a Special Enrollment Period of <strong>up to 60 days</strong> to update your health insurance outside of open enrollment.</p>
  <p style="margin:0 0 14px;line-height:1.65;">Here's what we'd typically check together:</p>
  <ul style="margin:0 0 18px 22px;line-height:1.7;color:#1e293b;">
    <li>Adding a spouse or newborn to your plan</li>
    <li>Switching to a family-tier plan with better network or pediatric coverage</li>
    <li>Whether your subsidy amount needs to be re-calculated</li>
    <li>HSA-eligible plans if your situation now favors them</li>
    <li>COBRA vs. marketplace coverage if you've changed jobs</li>
  </ul>
  <p style="text-align:center;margin:0 0 16px;"><a href="#" style="display:inline-block;background:#15803d;color:#ffffff;text-decoration:none;padding:12px 30px;border-radius:8px;font-weight:700;">Book a coverage review</a></p>
  <p style="margin:0;line-height:1.65;">If your event happened more than 60 days ago, it's worth still reaching out — there are sometimes other options that work.</p>
  <p style="margin:18px 0 0;line-height:1.55;">Cheering you on,<br/><strong>{{full_name}}</strong></p>
</div>`;
  }

  function hiWelcomePolicyHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:600px;">
  <div style="background:linear-gradient(135deg,#0f766e,#22d3ee);color:#ffffff;border-radius:14px;padding:32px 26px;text-align:center;">
    <div style="font-size:2.4rem;line-height:1;">✅</div>
    <h1 style="margin:8px 0 4px;font-size:1.75rem;">You're covered, {{first_name}}!</h1>
    <p style="margin:0;opacity:0.92;">Coverage is active starting <strong>{{coverage_start_date}}</strong>.</p>
  </div>
  <p style="margin:22px 0 14px;line-height:1.65;">Welcome to your new health plan. Below are the next steps and what to do if you ever have a question — including <em>after</em> you become a client. I'm here as long as you need me.</p>
  <table cellpadding="0" cellspacing="0" border="0" style="width:100%;margin:0 0 22px;font-family:Arial,sans-serif;">
    <tr>
      <td style="vertical-align:top;width:33%;padding:0 6px 0 0;">
        <div style="background:#ecfeff;border-radius:10px;padding:14px;text-align:center;">
          <div style="font-size:1.4rem;">📬</div>
          <strong style="display:block;margin:4px 0;">Watch your mail</strong>
          <span style="color:#475569;font-size:0.88rem;line-height:1.45;display:block;">Member ID cards arrive within 7–10 business days.</span>
        </div>
      </td>
      <td style="vertical-align:top;width:33%;padding:0 6px;">
        <div style="background:#ecfeff;border-radius:10px;padding:14px;text-align:center;">
          <div style="font-size:1.4rem;">🔐</div>
          <strong style="display:block;margin:4px 0;">Set up your portal</strong>
          <span style="color:#475569;font-size:0.88rem;line-height:1.45;display:block;">Access claims, ID cards, and benefits online.</span>
        </div>
      </td>
      <td style="vertical-align:top;width:33%;padding:0 0 0 6px;">
        <div style="background:#ecfeff;border-radius:10px;padding:14px;text-align:center;">
          <div style="font-size:1.4rem;">💊</div>
          <strong style="display:block;margin:4px 0;">Update prescriptions</strong>
          <span style="color:#475569;font-size:0.88rem;line-height:1.45;display:block;">Give pharmacies your new plan info.</span>
        </div>
      </td>
    </tr>
  </table>
  <div style="background:#f1f5f9;border-radius:10px;padding:14px 18px;margin:0 0 18px;">
    <strong>Save my contact info:</strong>
    <div style="margin-top:4px;color:#475569;line-height:1.55;">Questions about a claim, a doctor, or your card? Email or call me before calling the carrier — I'm faster.</div>
  </div>
  <p style="margin:18px 0 0;line-height:1.55;">Welcome to the family,<br/><strong>{{full_name}}</strong><br/><span style="color:#64748b;font-size:0.9rem;">Your dedicated agent · {{phone}}</span></p>
</div>`;
  }

  function hiAnnualReviewHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:600px;">
  <div style="background:linear-gradient(135deg,#1e3a8a,#3b82f6);color:#ffffff;border-radius:14px;padding:30px 26px;text-align:center;">
    <div style="font-size:2.2rem;line-height:1;">🔍</div>
    <h1 style="margin:8px 0 4px;font-size:1.75rem;">Time for your annual coverage review</h1>
    <p style="margin:0;opacity:0.92;">A 15-minute check to make sure your plan still fits.</p>
  </div>
  <p style="margin:22px 0 14px;line-height:1.65;">Hi {{first_name}}, every year your premiums, deductibles, and provider networks shift — sometimes a little, sometimes a lot. A short review now can mean real savings (or smarter coverage) for the year ahead.</p>
  <div style="background:#eff6ff;border-left:4px solid #3b82f6;border-radius:0 10px 10px 0;padding:14px 18px;margin:0 0 22px;">
    <div style="font-weight:800;color:#1e3a8a;margin-bottom:4px;">In our review we'll look at:</div>
    <ul style="margin:6px 0 0 20px;padding:0;line-height:1.6;color:#1e293b;">
      <li>Has your plan's premium or deductible changed for next year?</li>
      <li>Are your doctors and prescriptions still in-network and on the formulary?</li>
      <li>Have your subsidy or income estimates shifted?</li>
      <li>Any qualifying life events in the past 12 months?</li>
      <li>Plans we didn't see last year that may now fit better</li>
    </ul>
  </div>
  <p style="text-align:center;margin:0 0 14px;"><a href="#" style="display:inline-block;background:#1e40af;color:#ffffff;text-decoration:none;padding:12px 30px;border-radius:8px;font-weight:700;">Book my annual review</a></p>
  <p style="margin:18px 0 0;line-height:1.65;">If everything's still perfect, we'll wrap up early — but most folks find at least one tweak worth making. There's never a fee for the review or for switching plans through me.</p>
  <p style="margin:18px 0 0;line-height:1.55;">Looking out for you,<br/><strong>{{full_name}}</strong></p>
</div>`;
  }

  function hiSelfEmployedHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:600px;">
  <div style="background:linear-gradient(135deg,#7c2d12,#ea580c);color:#ffffff;border-radius:14px;padding:30px 26px;text-align:center;">
    <div style="font-size:2.2rem;line-height:1;">💪</div>
    <h1 style="margin:8px 0 4px;font-size:1.7rem;">Health coverage built for self-employed pros</h1>
    <p style="margin:0;opacity:0.92;">Without paying corporate-employee prices.</p>
  </div>
  <p style="margin:22px 0 14px;line-height:1.65;">Hi {{first_name}}, running your own business is hard enough — figuring out health insurance shouldn't add to it. The good news: as a 1099, freelancer, or business owner, you have <strong>more options than most W-2 employees</strong>, including:</p>
  <ul style="margin:0 0 18px 22px;line-height:1.7;color:#1e293b;">
    <li><strong>Marketplace plans</strong> with subsidies that can cut premiums dramatically</li>
    <li><strong>HSA-eligible high-deductible plans</strong> — lower premiums, tax-free savings, triple tax advantage</li>
    <li><strong>Self-employed health insurance deduction</strong> on your taxes (often overlooked)</li>
    <li><strong>Health-share programs</strong> if marketplace pricing doesn't pencil out</li>
    <li><strong>Spouse-employer "family" plans</strong> compared apples-to-apples vs. your own coverage</li>
  </ul>
  <div style="background:#fff7ed;border:1px solid #fed7aa;border-radius:10px;padding:14px 18px;margin:0 0 22px;">
    <strong style="color:#9a3412;">Quick math you might not realize:</strong>
    <div style="margin-top:4px;color:#1f2937;line-height:1.55;">For a typical self-employed person earning $80k, marketplace subsidies can drop a $600/mo premium to under $300/mo. That's worth a 15-minute conversation.</div>
  </div>
  <p style="text-align:center;margin:0 0 14px;"><a href="#" style="display:inline-block;background:#ea580c;color:#ffffff;text-decoration:none;padding:12px 30px;border-radius:8px;font-weight:700;">Get my free quote</a></p>
  <p style="margin:18px 0 0;line-height:1.65;">No fee, no obligation, no spam — just options. Reply with a few times that work, or use the link above to grab a slot directly.</p>
  <p style="margin:18px 0 0;line-height:1.55;">In your corner,<br/><strong>{{full_name}}</strong></p>
</div>`;
  }

  function hiSupplementalHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:600px;">
  <div style="background:linear-gradient(135deg,#9d174d,#f43f5e);color:#ffffff;border-radius:14px;padding:30px 26px;text-align:center;">
    <div style="font-size:2.2rem;line-height:1;">❤️‍🩹</div>
    <h1 style="margin:8px 0 4px;font-size:1.7rem;">Extra protection for the bills your plan won't cover.</h1>
    <p style="margin:0;opacity:0.92;">Critical illness, cancer, accident & hospital indemnity coverage.</p>
  </div>
  <p style="margin:22px 0 14px;line-height:1.65;">Hi {{first_name}}, even a "good" health plan still leaves you on the hook for thousands in deductibles, coinsurance, and non-medical costs (lost income, travel, copays, childcare) when something serious happens. That's where supplemental coverage steps in.</p>
  <div style="display:block;margin:0 0 22px;">
    <div style="background:#fff1f2;border:1px solid #fecdd3;border-radius:10px;padding:14px 18px;margin-bottom:10px;">
      <strong style="color:#9f1239;">Critical Illness</strong>
      <div style="margin-top:4px;color:#1f2937;line-height:1.55;">Lump-sum cash payout — often $10k–$50k — on diagnosis of cancer, heart attack, stroke, kidney failure, and more. Use it however you need.</div>
    </div>
    <div style="background:#fff1f2;border:1px solid #fecdd3;border-radius:10px;padding:14px 18px;margin-bottom:10px;">
      <strong style="color:#9f1239;">Hospital Indemnity</strong>
      <div style="margin-top:4px;color:#1f2937;line-height:1.55;">Pays a flat daily benefit for every day you're admitted — directly to you, regardless of what your major medical plan pays. Helps wipe out the deductible.</div>
    </div>
    <div style="background:#fff1f2;border:1px solid #fecdd3;border-radius:10px;padding:14px 18px;margin-bottom:10px;">
      <strong style="color:#9f1239;">Accident Insurance</strong>
      <div style="margin-top:4px;color:#1f2937;line-height:1.55;">Cash benefits for ER visits, fractures, stitches, and follow-up care. Especially useful for active families and high-deductible plans.</div>
    </div>
    <div style="background:#fff1f2;border:1px solid #fecdd3;border-radius:10px;padding:14px 18px;">
      <strong style="color:#9f1239;">Cancer-Specific Plans</strong>
      <div style="margin-top:4px;color:#1f2937;line-height:1.55;">Targeted benefits for diagnosis, treatment, transportation, and recovery — often available with limited or no medical underwriting.</div>
    </div>
  </div>
  <p style="margin:0 0 14px;line-height:1.65;">Premiums for these are usually surprisingly low — often $10–$40/mo — because they're designed to <em>complement</em> your major medical plan, not replace it.</p>
  <p style="text-align:center;margin:0 0 14px;"><a href="#" style="display:inline-block;background:#be123c;color:#ffffff;text-decoration:none;padding:12px 30px;border-radius:8px;font-weight:700;">See supplemental options</a></p>
  <p style="margin:18px 0 0;line-height:1.65;">Want a quick rundown for your situation? Reply with your age and household and I'll send back a sample quote.</p>
  <p style="margin:18px 0 0;line-height:1.55;">Take care,<br/><strong>{{full_name}}</strong></p>
</div>`;
  }

  function hiHealthySavingsHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:600px;">
  <div style="background:linear-gradient(135deg,#14532d,#22c55e);color:#ffffff;border-radius:14px;padding:30px 26px;text-align:center;">
    <div style="font-size:2.2rem;line-height:1;">🥗</div>
    <h1 style="margin:8px 0 4px;font-size:1.7rem;">Healthy habits = lower premiums.</h1>
    <p style="margin:0;opacity:0.92;">If you're tobacco-free and rarely use the doctor, your rate should reflect that.</p>
  </div>
  <p style="margin:22px 0 14px;line-height:1.65;">Hi {{first_name}}, here's something most people don't realize: insurers reward healthy clients. If you're a non-smoker, hit a healthy BMI range, and don't have ongoing medical claims, you can typically lock in:</p>
  <ul style="margin:0 0 18px 22px;line-height:1.7;color:#1e293b;">
    <li><strong>Non-tobacco rates</strong> — often 15–50% cheaper than tobacco-user rates</li>
    <li><strong>Preferred-tier pricing</strong> on medically underwritten plans</li>
    <li><strong>Lower-premium HSA-eligible plans</strong> that pay you back at tax time</li>
    <li><strong>Wellness credits & gym reimbursements</strong> from many carriers</li>
    <li><strong>Multi-year rate locks</strong> on certain private plans</li>
  </ul>
  <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:14px 18px;margin:0 0 22px;">
    <strong style="color:#14532d;">Real example:</strong>
    <div style="margin-top:4px;color:#1f2937;line-height:1.55;">A healthy 38-year-old non-smoker we recently quoted dropped from $612/mo on a default ACA plan to $341/mo on a private underwritten plan — same network, similar deductible. That's ~$3,250 a year back in their pocket.</div>
  </div>
  <p style="text-align:center;margin:0 0 14px;"><a href="#" style="display:inline-block;background:#16a34a;color:#ffffff;text-decoration:none;padding:12px 30px;border-radius:8px;font-weight:700;">See what I'd save</a></p>
  <p style="margin:18px 0 0;line-height:1.65;">If you're already taking care of yourself, your insurance bill should reward that — not punish it. Reply or grab a slot above and I'll run the numbers for you.</p>
  <p style="margin:18px 0 0;line-height:1.55;">Cheers to good health,<br/><strong>{{full_name}}</strong></p>
</div>`;
  }

  function hiYoungHealthyHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:600px;">
  <div style="background:linear-gradient(135deg,#0369a1,#38bdf8);color:#ffffff;border-radius:14px;padding:30px 26px;text-align:center;">
    <div style="font-size:2.2rem;line-height:1;">⚡</div>
    <h1 style="margin:8px 0 4px;font-size:1.7rem;">Young, healthy, and don't want to overpay?</h1>
    <p style="margin:0;opacity:0.92;">Low-premium coverage built around how you actually use insurance.</p>
  </div>
  <p style="margin:22px 0 14px;line-height:1.65;">Hi {{first_name}}, if you're young and healthy, the truth is you don't need a fancy plan with a low deductible — you need a <strong>safety net</strong> for the rare big-ticket event. That keeps your premium low and your wallet happy.</p>
  <div style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:10px;padding:16px 18px;margin:0 0 22px;">
    <strong style="color:#0c4a6e;">Best fits for healthy young adults:</strong>
    <ul style="margin:8px 0 0 22px;padding:0;line-height:1.7;color:#1f2937;">
      <li><strong>Catastrophic plans</strong> (under 30 or with hardship exemption) — lowest premium with full ACA protections after the deductible</li>
      <li><strong>Bronze ACA plans</strong> with HSA option — premium subsidies still apply if eligible</li>
      <li><strong>Short-term medical plans</strong> for gap coverage between jobs or post-college</li>
      <li><strong>Accident & hospital indemnity riders</strong> — pennies on the dollar to cover the deductible</li>
    </ul>
  </div>
  <p style="margin:0 0 14px;line-height:1.65;">A typical healthy 26-year-old we work with pays <strong>$120–$180/month</strong> with a real safety net behind them. No bloat, no paying for benefits they'll never use.</p>
  <p style="text-align:center;margin:0 0 14px;"><a href="#" style="display:inline-block;background:#0284c7;color:#ffffff;text-decoration:none;padding:12px 30px;border-radius:8px;font-weight:700;">Quote my low-premium plan</a></p>
  <p style="margin:18px 0 0;line-height:1.65;">Takes about 2 minutes to get a real quote. Reply with your zip & age or click above.</p>
  <p style="margin:18px 0 0;line-height:1.55;">Have a great one,<br/><strong>{{full_name}}</strong></p>
</div>`;
  }

  function hiHereIsQuoteHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:600px;">
  <div style="background:linear-gradient(135deg,#1d4ed8,#06b6d4);color:#ffffff;border-radius:14px;padding:30px 26px;text-align:center;">
    <div style="font-size:2.2rem;line-height:1;">📄</div>
    <h1 style="margin:8px 0 4px;font-size:1.7rem;">Here's your personalized quote.</h1>
    <p style="margin:0;opacity:0.92;">Prepared just for you, {{first_name}}.</p>
  </div>
  <p style="margin:22px 0 14px;line-height:1.65;">Hi {{first_name}}, thanks for the info you sent over. Based on your household, zip code, and preferences, here are the plan options I think fit you best. I've included the highlights so you can compare at a glance — full benefit summaries are linked at the bottom.</p>
  <div style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:12px;padding:16px 18px;margin:0 0 22px;">
    <strong style="color:#0c4a6e;font-size:1rem;">Quote summary</strong>
    <table style="width:100%;border-collapse:collapse;margin-top:8px;font-size:0.95rem;">
      <tr>
        <td style="padding:6px 0;color:#475569;width:50%;">Effective date</td>
        <td style="padding:6px 0;color:#0f172a;text-align:right;font-weight:600;">[Effective Date]</td>
      </tr>
      <tr>
        <td style="padding:6px 0;color:#475569;border-top:1px solid #e0f2fe;">Household covered</td>
        <td style="padding:6px 0;color:#0f172a;text-align:right;font-weight:600;border-top:1px solid #e0f2fe;">[# Adults / # Kids]</td>
      </tr>
      <tr>
        <td style="padding:6px 0;color:#475569;border-top:1px solid #e0f2fe;">Network preference</td>
        <td style="padding:6px 0;color:#0f172a;text-align:right;font-weight:600;border-top:1px solid #e0f2fe;">[PPO / HMO / EPO]</td>
      </tr>
      <tr>
        <td style="padding:6px 0;color:#475569;border-top:1px solid #e0f2fe;">Subsidy applied</td>
        <td style="padding:6px 0;color:#0f172a;text-align:right;font-weight:600;border-top:1px solid #e0f2fe;">[$ / mo]</td>
      </tr>
    </table>
  </div>
  <h2 style="margin:0 0 12px;font-size:1.1rem;color:#0f172a;">Recommended option</h2>
  <div style="border:2px solid #1d4ed8;border-radius:12px;padding:18px;margin:0 0 16px;background:#ffffff;">
    <div style="display:block;margin:0 0 8px;">
      <span style="display:inline-block;background:#1d4ed8;color:#ffffff;font-size:0.72rem;font-weight:700;letter-spacing:0.05em;text-transform:uppercase;padding:3px 9px;border-radius:999px;">Best fit</span>
    </div>
    <div style="font-size:1.1rem;font-weight:700;color:#0f172a;">[Carrier — Plan Name]</div>
    <div style="color:#64748b;font-size:0.9rem;margin-top:2px;">[Metal Tier] · [PPO/HMO/EPO] · [Network Name]</div>
    <table style="width:100%;border-collapse:collapse;margin-top:14px;font-size:0.95rem;">
      <tr>
        <td style="padding:6px 0;color:#475569;width:55%;">Monthly premium</td>
        <td style="padding:6px 0;color:#1d4ed8;text-align:right;font-weight:800;font-size:1.1rem;">$[XXX]/mo</td>
      </tr>
      <tr>
        <td style="padding:6px 0;color:#475569;border-top:1px solid #e2e8f0;">Annual deductible</td>
        <td style="padding:6px 0;color:#0f172a;text-align:right;font-weight:600;border-top:1px solid #e2e8f0;">$[XXXX]</td>
      </tr>
      <tr>
        <td style="padding:6px 0;color:#475569;border-top:1px solid #e2e8f0;">Out-of-pocket max</td>
        <td style="padding:6px 0;color:#0f172a;text-align:right;font-weight:600;border-top:1px solid #e2e8f0;">$[XXXX]</td>
      </tr>
      <tr>
        <td style="padding:6px 0;color:#475569;border-top:1px solid #e2e8f0;">Primary care visit</td>
        <td style="padding:6px 0;color:#0f172a;text-align:right;font-weight:600;border-top:1px solid #e2e8f0;">$[XX] copay</td>
      </tr>
      <tr>
        <td style="padding:6px 0;color:#475569;border-top:1px solid #e2e8f0;">Specialist visit</td>
        <td style="padding:6px 0;color:#0f172a;text-align:right;font-weight:600;border-top:1px solid #e2e8f0;">$[XX] copay</td>
      </tr>
      <tr>
        <td style="padding:6px 0;color:#475569;border-top:1px solid #e2e8f0;">Generic Rx</td>
        <td style="padding:6px 0;color:#0f172a;text-align:right;font-weight:600;border-top:1px solid #e2e8f0;">$[XX]</td>
      </tr>
      <tr>
        <td style="padding:6px 0;color:#475569;border-top:1px solid #e2e8f0;">HSA-eligible</td>
        <td style="padding:6px 0;color:#0f172a;text-align:right;font-weight:600;border-top:1px solid #e2e8f0;">[Yes / No]</td>
      </tr>
    </table>
    <div style="margin-top:14px;padding-top:12px;border-top:1px dashed #cbd5e1;color:#475569;font-size:0.9rem;line-height:1.55;">
      <strong style="color:#0f172a;">Why I picked this:</strong> [1–2 sentences explaining the fit — network, doctors, prescriptions, monthly cost, etc.]
    </div>
  </div>
  <h2 style="margin:18px 0 12px;font-size:1.1rem;color:#0f172a;">Alternate options</h2>
  <div style="border:1px solid #e2e8f0;border-radius:12px;padding:16px 18px;margin:0 0 12px;background:#ffffff;">
    <div style="font-weight:700;color:#0f172a;">[Carrier — Plan Name]</div>
    <div style="color:#64748b;font-size:0.88rem;margin-top:2px;">[Metal Tier] · Premium <strong style="color:#0f172a;">$[XXX]/mo</strong> · Deductible $[XXXX] · OOP max $[XXXX]</div>
    <div style="color:#475569;font-size:0.88rem;margin-top:6px;line-height:1.5;">Good if you want [lower premium / lower deductible / wider network / HSA].</div>
  </div>
  <div style="border:1px solid #e2e8f0;border-radius:12px;padding:16px 18px;margin:0 0 22px;background:#ffffff;">
    <div style="font-weight:700;color:#0f172a;">[Carrier — Plan Name]</div>
    <div style="color:#64748b;font-size:0.88rem;margin-top:2px;">[Metal Tier] · Premium <strong style="color:#0f172a;">$[XXX]/mo</strong> · Deductible $[XXXX] · OOP max $[XXXX]</div>
    <div style="color:#475569;font-size:0.88rem;margin-top:6px;line-height:1.5;">Good if you want [lower premium / lower deductible / wider network / HSA].</div>
  </div>
  <div style="background:#fef3c7;border:1px solid #fde68a;border-radius:10px;padding:12px 16px;margin:0 0 22px;color:#78350f;line-height:1.55;">
    <strong>Quote good through [Date].</strong> Premiums and availability can change at the end of the month or when carriers re-file rates, so let's lock something in before then.
  </div>
  <p style="text-align:center;margin:0 0 14px;">
    <a href="#" style="display:inline-block;background:#1d4ed8;color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:8px;font-weight:700;margin:0 4px 8px;">Accept &amp; enroll</a>
    <a href="#" style="display:inline-block;background:#ffffff;color:#1d4ed8;text-decoration:none;padding:11px 26px;border-radius:8px;font-weight:700;border:2px solid #1d4ed8;margin:0 4px 8px;">Schedule a call</a>
  </p>
  <p style="margin:0 0 14px;line-height:1.65;">Want to compare doctors, prescriptions, or run different deductible scenarios? Just reply with what you'd like to see and I'll re-quote — usually within the same day.</p>
  <p style="margin:18px 0 0;line-height:1.55;">Talk soon,<br/><strong>{{full_name}}</strong><br/><span style="color:#64748b;font-size:0.9rem;">Licensed Insurance Agent</span></p>
  <p style="margin:14px 0 0;font-size:0.78rem;color:#94a3b8;line-height:1.5;">This is a quote summary, not a contract. Final premiums and benefits are determined by the issuing carrier upon application. Plan documents and Summary of Benefits available on request.</p>
</div>`;
  }

  function hiProspectWelcomeHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:560px;">
  <p style="margin:0 0 14px;line-height:1.65;">Hi {{first_name}},</p>
  <p style="margin:0 0 14px;line-height:1.65;">Thanks for reaching out about health insurance. I'm {{full_name}}, a licensed agent in {{state}}, and I help individuals and families find coverage that fits their budget and their doctors.</p>
  <p style="margin:0 0 14px;line-height:1.65;">Here's what happens next:</p>
  <ul style="margin:0 0 18px 22px;line-height:1.7;color:#1e293b;">
    <li>I'll review your situation (household, doctors, prescriptions, budget)</li>
    <li>I'll send a clear side-by-side comparison — no jargon</li>
    <li>We'll pick a plan together and I'll walk you through enrollment if you decide to move forward</li>
  </ul>
  <p style="margin:0 0 14px;line-height:1.65;">Reply with a good time to talk, or call me at <strong>{{phone}}</strong>. There's no cost and no obligation for a consultation.</p>
  <p style="margin:18px 0 0;line-height:1.55;">Talk soon,<br/><strong>{{full_name}}</strong><br/><span style="color:#64748b;font-size:0.9rem;">Licensed Health Insurance Agent</span></p>
</div>`;
  }

  function hiReferralAskHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:560px;">
  <p style="margin:0 0 14px;line-height:1.65;">Hi {{first_name}},</p>
  <p style="margin:0 0 14px;line-height:1.65;">I'm glad we've been able to help with your coverage. The highest compliment I receive is when a client introduces me to someone they care about who needs help navigating health insurance.</p>
  <p style="margin:0 0 14px;line-height:1.65;">Do you know a friend, family member, or coworker who is:</p>
  <ul style="margin:0 0 18px 22px;line-height:1.7;color:#1e293b;">
    <li>Shopping for coverage during open enrollment</li>
    <li>Between jobs or losing employer coverage</li>
    <li>Turning 26 and aging off a parent's plan</li>
    <li>Simply unhappy with their current plan or costs</li>
  </ul>
  <p style="margin:0 0 14px;line-height:1.65;">If someone comes to mind, you can forward this email or reply with their name and number — I'll treat them with the same care I give you. I'll never pressure anyone; I just explain options clearly.</p>
  <p style="margin:18px 0 0;line-height:1.55;">Thank you again,<br/><strong>{{full_name}}</strong><br/><span style="color:#64748b;font-size:0.9rem;">{{phone}}</span></p>
</div>`;
  }

  function hiPostEnrollmentThanksHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:560px;">
  <p style="margin:0 0 14px;line-height:1.65;">Hi {{first_name}},</p>
  <p style="margin:0 0 14px;line-height:1.65;">Thank you for trusting me with your health insurance. It means a lot — I know this is an important decision for you and your family.</p>
  <p style="margin:0 0 14px;line-height:1.65;">Your coverage is set for <strong>{{coverage_start_date}}</strong>. I'll stay your agent going forward, so if you have questions about ID cards, claims, doctors, or prescriptions, reach out to me first — I'm often faster than calling the carrier directly.</p>
  <p style="margin:0 0 14px;line-height:1.65;">If anything changes (new job, move, marriage, baby), let me know right away so we can keep your coverage correct.</p>
  <p style="margin:18px 0 0;line-height:1.55;">Gratefully,<br/><strong>{{full_name}}</strong><br/><span style="color:#64748b;font-size:0.9rem;">Your agent · {{phone}}</span></p>
</div>`;
  }

  function hiPrivateUnderwrittenHtml() {
    return `<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:600px;">
  <div style="background:linear-gradient(135deg,#064e3b,#14b8a6);color:#ffffff;border-radius:14px;padding:30px 26px;text-align:center;">
    <div style="font-size:2.2rem;line-height:1;">✨</div>
    <h1 style="margin:8px 0 4px;font-size:1.7rem;">Healthy? You can usually do better than the marketplace.</h1>
    <p style="margin:0;opacity:0.92;">Privately underwritten plans reward you for being a low-risk client.</p>
  </div>
  <p style="margin:22px 0 14px;line-height:1.65;">Hi {{first_name}}, ACA marketplace plans charge everyone in your age bracket the same — whether they ran a marathon last weekend or haven't seen a doctor in a decade. Privately underwritten plans don't work that way. <strong>If you're healthy, you pay less.</strong></p>
  <div style="background:#ecfdf5;border:1px solid #a7f3d0;border-radius:10px;padding:16px 18px;margin:0 0 22px;">
    <strong style="color:#064e3b;">What healthy clients typically unlock:</strong>
    <ul style="margin:8px 0 0 22px;padding:0;line-height:1.7;color:#1f2937;">
      <li><strong>15–40% lower premiums</strong> versus comparable marketplace plans</li>
      <li><strong>Broader PPO networks</strong> — see specialists without referrals or narrow tiers</li>
      <li><strong>Lower deductibles</strong> at the same monthly cost</li>
      <li><strong>Real prescription coverage</strong> instead of capped tiers</li>
      <li><strong>Multi-year rate locks</strong> on some carriers</li>
    </ul>
  </div>
  <div style="background:#f8fafc;border-radius:10px;padding:14px 18px;margin:0 0 22px;border:1px dashed #cbd5e1;">
    <strong style="color:#0f172a;">Real-world swap:</strong>
    <div style="margin-top:4px;color:#1f2937;line-height:1.55;">Healthy 42-year-old, no claims, non-smoker — moved from a $704/mo Silver ACA plan to a $429/mo PPO with a lower deductible and a bigger network. <strong>Net savings: ~$3,300/year.</strong></div>
  </div>
  <p style="text-align:center;margin:0 0 14px;"><a href="#" style="display:inline-block;background:#0d9488;color:#ffffff;text-decoration:none;padding:12px 30px;border-radius:8px;font-weight:700;">Run my private quote</a></p>
  <p style="margin:18px 0 0;line-height:1.65;">A short health questionnaire and we'll know in minutes what you qualify for. No application fee, no obligation, totally confidential.</p>
  <p style="margin:18px 0 0;line-height:1.55;">Best,<br/><strong>{{full_name}}</strong></p>
</div>`;
  }
})();
