(function () {
  function getApiBase() {
    let injected =
      typeof window.__CRM_API_ORIGIN__ === "string" ? window.__CRM_API_ORIGIN__.trim().replace(/\/$/, "") : "";
    if (!injected && typeof window.location !== "undefined") {
      const proto = window.location.protocol;
      if (proto === "http:" || proto === "https:") {
        injected = window.location.origin.replace(/\/$/, "");
      }
    }
    if (injected) return injected;
    const fromMeta = document.querySelector('meta[name="crm-api-base"]');
    return fromMeta ? String(fromMeta.getAttribute("content") || "").trim().replace(/\/$/, "") : "";
  }

  function apiUrl(path) {
    const p = path.startsWith("/") ? path : `/${path}`;
    const base = getApiBase();
    return base ? `${base}${p}` : p;
  }

  function urlBase64ToUint8Array(base64String) {
    const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; ++i) outputArray[i] = rawData.charCodeAt(i);
    return outputArray;
  }

  async function fetchJson(path, init) {
    const response = await fetch(apiUrl(path), init);
    const text = await response.text();
    let data = {};
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      data = {};
    }
    return { response, data };
  }

  async function loadStatusIntoDom() {
    const emailEl = document.getElementById("reminderEmailStatus");
    const pushEl = document.getElementById("reminderPushStatus");
    const subsEl = document.getElementById("reminderPushSubsCount");
    if (!emailEl || !pushEl) return;
    const { response, data } = await fetchJson("/api/reminders/status");
    if (!response.ok) {
      emailEl.textContent = "Could not load";
      pushEl.textContent = "Could not load";
      return;
    }
    emailEl.textContent = data.emailReminderReady ? "On" : "Off";
    pushEl.textContent = data.pushReminderReady ? "On" : "Off";
    if (subsEl) subsEl.textContent = String(Number(data.pushSubscriptionCount || 0));
  }

  async function enablePush() {
    const msg = document.getElementById("reminderPushMessage");
    const setMsg = (t, isErr) => {
      if (!msg) return;
      msg.textContent = t;
      msg.style.color = isErr ? "#c62828" : "#1b5e20";
    };

    if (!("serviceWorker" in navigator) || !("PushManager" in window)) {
      setMsg("This browser does not support push notifications.", true);
      return;
    }

    setMsg("Checking server…");
    const { response: stResp, data: status } = await fetchJson("/api/reminders/status");
    if (!stResp.ok) {
      setMsg("Could not turn on browser notifications. Refresh this page and try again.", true);
      return;
    }
    if (!status.vapidPublicKey || !String(status.vapidPublicKey).trim()) {
      setMsg("Browser notifications are not available right now.", true);
      return;
    }

    const permission = await Notification.requestPermission();
    if (permission !== "granted") {
      setMsg("Notification permission was not granted.", true);
      return;
    }

    const reg = await navigator.serviceWorker.register("/sw.js");
    await reg.update();

    const sub = await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(status.vapidPublicKey)
    });

    const json = sub.toJSON();
    const { response: postResp, data: postBody } = await fetchJson("/api/reminders/push-subscribe", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ subscription: json })
    });

    if (!postResp.ok) {
      setMsg(postBody.error || "Failed to save subscription.", true);
      return;
    }

    setMsg("Browser notifications enabled for follow-up reminders.");
    await loadStatusIntoDom();
  }

  async function disablePush() {
    const msg = document.getElementById("reminderPushMessage");
    const setMsg = (t, isErr) => {
      if (!msg) return;
      msg.textContent = t;
      msg.style.color = isErr ? "#c62828" : "#1b5e20";
    };

    const reg = await navigator.serviceWorker.getRegistration("/sw.js");
    const sub = reg && reg.pushManager ? await reg.pushManager.getSubscription() : null;
    if (!sub) {
      setMsg("Browser notifications are already off on this device.", true);
      await loadStatusIntoDom();
      return;
    }

    const json = sub.toJSON();
    await fetchJson("/api/reminders/push-unsubscribe", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ endpoint: json.endpoint })
    });

    await sub.unsubscribe().catch(() => {});
    setMsg("Browser notifications disabled for this device.");
    await loadStatusIntoDom();
  }

  document.addEventListener("DOMContentLoaded", () => {
    const enableBtn = document.getElementById("enablePushRemindersBtn");
    const disableBtn = document.getElementById("disablePushRemindersBtn");
    if (!enableBtn && !disableBtn) return;

    loadStatusIntoDom().catch(() => {});
    if (enableBtn) enableBtn.addEventListener("click", () => enablePush().catch(() => {}));
    if (disableBtn) disableBtn.addEventListener("click", () => disablePush().catch(() => {}));
  });
})();
