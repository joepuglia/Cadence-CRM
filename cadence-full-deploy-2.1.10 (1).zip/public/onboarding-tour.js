/**
 * First-time user footnotes with clear arrows (Contacts workspace).
 * Dismissal stored in localStorage - use ?onboarding=1 to replay.
 */
(function () {
  const STORAGE_KEY = "crm.onboarding.contacts.v1";

  const CONTACTS_STEPS = [
    {
      id: "welcome",
      title: "Welcome to Cadence",
      body: "A short setup tour: where your contacts live, how to add one, and where to connect email so you can send. You can skip anytime.",
      placement: "center",
      showArrow: false
    },
    {
      id: "dashboard",
      selector: '.agile-nav-inner a[href="/home.html"]',
      title: "Live Dashboard",
      body: "See new contacts, sold, emails sent and opened, clicks, and upcoming tasks at a glance.",
      placement: "flow",
      showArrow: true
    },
    {
      id: "contacts",
      selector: ".agile-nav-inner .active",
      title: "Contacts Workspace",
      body: "This is your main workspace for leads and clients. Search, filter, call, text, email, and open full contact records from here.",
      placement: "flow",
      showArrow: true
    },
    {
      id: "campaign-builder",
      selector: '.agile-nav-inner a[href="/campaigns.html"]',
      title: "AI Campaign Builder",
      body: "Describe a goal and AI writes a drip sequence — emails, SMS, and timing you can save and send.",
      placement: "flow",
      showArrow: true
    },
    {
      id: "automations",
      selector: '.agile-nav-inner a[href="/automations.html"]',
      title: "Automations",
      body: "Build drag-and-drop journeys that follow up automatically when contacts enter a campaign.",
      placement: "flow",
      showArrow: true
    },
    {
      id: "pipeline",
      selector: '.agile-nav-inner a[href="/pipeline.html"]',
      title: "Pipeline Summary",
      body: "See where leads sit from new to sold, and your overall close rate.",
      placement: "flow",
      showArrow: true
    },
    {
      id: "renewals",
      selector: '.agile-nav-inner a[href="/renewals.html"]',
      title: "Renewals",
      body: "Track plans coming due from Coverage Start Date. Set 3, 6, or 12 month terms on the contact Coverage section.",
      placement: "flow",
      showArrow: true
    },
    {
      id: "reports",
      selector: '.agile-nav-inner a[href="/reports.html"]',
      title: "Reports",
      body: "Close rate by lead source, plus email open rate and click-to-open.",
      placement: "flow",
      showArrow: true
    },
    {
      id: "ai-assistant",
      selector: '.agile-nav-inner a[href="/assistant.html"]',
      title: "AI Assistant",
      body: "Use Cadence AI to draft emails and texts, coach objections, summarize your pipeline, and generate call scripts.",
      placement: "flow",
      showArrow: true
    },
    {
      id: "ai-role-play",
      selector: '.agile-nav-inner a[href="/role-play.html"]',
      title: "AI Role Play",
      body: "Practice sales conversations with an AI prospect. Pick a scenario, talk or type, get coaching hints, and a debrief when you finish.",
      placement: "flow",
      showArrow: true
    },
    {
      id: "ai-content",
      selector: '.agile-nav-inner a[href="/ai-content.html"]',
      title: "AI Content",
      body: "Draft SEO blog posts for your website, score them, and publish.",
      placement: "flow",
      showArrow: true
    },
    {
      id: "webinars",
      selector: '.agile-nav-inner a[href="/webinar-admin.html"]',
      optional: true,
      title: "Webinars",
      body: "Schedule client-facing Zoom presentations, share a registration page, and track who signed up.",
      placement: "flow",
      showArrow: false
    },
    {
      id: "add-contact",
      selector: "#contactsTopbarAddContactBtn",
      title: "Add your first contact",
      body: "Use + Add Contact in the top bar. Quick Actions covers calls, SMS, email, and tasks.",
      placement: "flow",
      showArrow: true
    },
    {
      id: "search",
      selector: "#searchInput",
      title: "Find anyone fast",
      body: "Search by name, email, or phone. Use status and outcome filters below to narrow the list.",
      placement: "flow",
      showArrow: true
    }
  ];

  const prefs = window.CrmClientPrefs || {};

  function isCompleted() {
    if (typeof prefs.readAccountFlag === "function") return prefs.readAccountFlag(STORAGE_KEY);
    if (typeof prefs.readFlag === "function") return prefs.readFlag(STORAGE_KEY);
    try {
      return localStorage.getItem(STORAGE_KEY) === "1";
    } catch {
      return false;
    }
  }

  function markCompleted() {
    if (typeof prefs.writeAccountFlag === "function") {
      prefs.writeAccountFlag(STORAGE_KEY);
      return;
    }
    if (typeof prefs.writeFlag === "function") {
      prefs.writeFlag(STORAGE_KEY);
      return;
    }
    try {
      localStorage.setItem(STORAGE_KEY, "1");
    } catch {
      /* ignore */
    }
  }

  function isMobileLayout() {
    return typeof prefs.isMobileLayout === "function" && prefs.isMobileLayout();
  }

  let startAfterSetup = false;

  function consumeStartAfterSetup() {
    try {
      if (sessionStorage.getItem("crm.onboarding.startAfterSetup") === "1") {
        sessionStorage.removeItem("crm.onboarding.startAfterSetup");
        startAfterSetup = true;
      }
    } catch {
      /* ignore */
    }
    return startAfterSetup;
  }

  function shouldRun() {
    const params = new URLSearchParams(window.location.search);
    if (params.get("onboarding") === "1") return true;
    if (consumeStartAfterSetup()) return true;
    if (isMobileLayout()) return false;
    return !isCompleted();
  }

  function isContactsPage() {
    const p = (window.location.pathname || "/").replace(/\/$/, "") || "/";
    return p === "" || p === "/" || p.endsWith("/index.html");
  }

  class OnboardingTour {
    constructor(steps) {
      this.steps = steps;
      this.index = 0;
      this.root = null;
      this.popover = null;
      this.highlight = null;
      this.onKeydown = this.onKeydown.bind(this);
      this.onReposition = this.onReposition.bind(this);
    }

    start() {
      if (!this.steps.length) return;
      document.body.classList.add("crm-onboarding-active");
      this.buildUi();
      this.showStep(0);
      document.addEventListener("keydown", this.onKeydown);
      window.addEventListener("resize", this.onReposition);
      window.addEventListener("scroll", this.onReposition, true);
    }

    destroy() {
      document.body.classList.remove("crm-onboarding-active");
      document.removeEventListener("keydown", this.onKeydown);
      window.removeEventListener("resize", this.onReposition);
      window.removeEventListener("scroll", this.onReposition, true);
      if (this.root?.parentNode) this.root.parentNode.removeChild(this.root);
      this.root = null;
      document.querySelectorAll(".crm-onboarding-highlight").forEach((el) => {
        el.classList.remove("crm-onboarding-highlight");
      });
    }

    buildUi() {
      const root = document.createElement("div");
      root.className = "crm-onboarding";
      root.setAttribute("role", "dialog");
      root.setAttribute("aria-modal", "true");
      root.setAttribute("aria-label", "Getting started guide");
      root.innerHTML = `
        <div class="crm-onboarding-backdrop" data-action="skip"></div>
        <div class="crm-onboarding-highlight-ring" hidden></div>
        <div class="crm-onboarding-popover" hidden>
          <div class="crm-onboarding-arrow" aria-hidden="true"></div>
          <div class="crm-onboarding-header">
            <span class="crm-onboarding-step-clock" aria-hidden="true">1</span>
            <p class="crm-onboarding-title"></p>
          </div>
          <p class="crm-onboarding-body"></p>
          <div class="crm-onboarding-footer">
            <span class="crm-onboarding-progress"></span>
            <div class="crm-onboarding-actions">
              <button type="button" class="crm-onboarding-btn crm-onboarding-btn--ghost" data-action="back" hidden>Back</button>
              <button type="button" class="crm-onboarding-btn crm-onboarding-btn--ghost" data-action="skip">Skip tour</button>
              <button type="button" class="crm-onboarding-btn crm-onboarding-btn--primary" data-action="next">Next</button>
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(root);
      this.root = root;
      this.popover = root.querySelector(".crm-onboarding-popover");
      this.highlight = root.querySelector(".crm-onboarding-highlight-ring");
      this.titleEl = root.querySelector(".crm-onboarding-title");
      this.bodyEl = root.querySelector(".crm-onboarding-body");
      this.progressEl = root.querySelector(".crm-onboarding-progress");
      this.clockEl = root.querySelector(".crm-onboarding-step-clock");
      this.arrowEl = root.querySelector(".crm-onboarding-arrow");
      this.backBtn = root.querySelector('[data-action="back"]');
      this.nextBtn = root.querySelector('[data-action="next"]');
      this.backdrop = root.querySelector(".crm-onboarding-backdrop");

      root.addEventListener("click", (e) => {
        const btn = e.target.closest("[data-action]");
        if (!btn) return;
        const action = btn.getAttribute("data-action");
        if (action === "next") this.next();
        else if (action === "back") this.back();
        else if (action === "skip") this.finish();
      });
    }

    onKeydown(e) {
      if (e.key === "Escape") this.finish();
      if (e.key === "ArrowRight") this.next();
      if (e.key === "ArrowLeft") this.back();
    }

    onReposition() {
      this.positionCurrent();
    }

    currentStep() {
      return this.steps[this.index];
    }

    targetEl(step) {
      if (!step?.selector) return null;
      return document.querySelector(step.selector);
    }

    showStep(i) {
      this.index = i;
      const step = this.currentStep();
      if (!step) return this.finish();

      document.querySelectorAll(".crm-onboarding-highlight").forEach((el) => {
        el.classList.remove("crm-onboarding-highlight");
      });

      if (step.titleHtml) {
        this.titleEl.innerHTML = step.titleHtml;
      } else {
        this.titleEl.textContent = step.title || "";
      }
      this.bodyEl.textContent = step.body || "";
      this.progressEl.textContent = `Step ${i + 1} of ${this.steps.length}`;
      if (this.clockEl) {
        this.clockEl.textContent = String(i + 1);
        this.clockEl.className = `crm-onboarding-step-clock crm-onboarding-step-clock--${(i % 6) + 1}`;
      }
      this.backBtn.hidden = i === 0;
      this.nextBtn.textContent = i === this.steps.length - 1 ? "Got it" : "Next";

      const placement = step.placement || "bottom";
      this.popover.classList.toggle("crm-onboarding-popover--center", placement === "center");
      this.popover.classList.toggle("crm-onboarding-popover--no-arrow", step.showArrow === false);
      this.arrowEl.className = "crm-onboarding-arrow";
      if (step.showArrow !== false && placement !== "center" && placement !== "flow") {
        this.arrowEl.classList.add(`crm-onboarding-arrow--${placement}`);
      } else if (step.showArrow !== false && placement === "flow") {
        this.arrowEl.classList.add("crm-onboarding-arrow--right");
      }

      const target = this.targetEl(step);
      if (target) {
        target.classList.add("crm-onboarding-highlight");
        try {
          target.scrollIntoView({ block: "nearest", behavior: "smooth" });
        } catch {
          target.scrollIntoView();
        }
      }

      const isCenter = placement === "center" || (!target && placement !== "flow");
      if (this.backdrop) this.backdrop.hidden = false;
      this.popover.hidden = false;
      this.highlight.hidden = isCenter || !target;
      requestAnimationFrame(() => this.positionCurrent());
    }

    positionCurrent() {
      const step = this.currentStep();
      if (!step || !this.popover) return;

      const pad = 12;
      const gap = 14;
      const arrowSize = 10;
      const popRect = this.popover.getBoundingClientRect();
      const vw = window.innerWidth;
      const vh = window.innerHeight;

      if (step.placement === "center" || (!step.selector && step.placement !== "flow")) {
        const left = Math.max(pad, (vw - popRect.width) / 2);
        const top = Math.max(pad, (vh - popRect.height) / 2);
        this.popover.style.left = `${left}px`;
        this.popover.style.top = `${top}px`;
        this.highlight.hidden = true;
        return;
      }

      const target = this.targetEl(step);
      if (step.placement === "flow" && !target) {
        const left = Math.min(Math.max(pad, 220), vw - popRect.width - pad);
        const top = Math.min(Math.max(pad, 520), vh - popRect.height - pad);
        this.popover.style.left = `${left}px`;
        this.popover.style.top = `${top}px`;
        this.highlight.hidden = true;
        return;
      }
      if (!target) {
        this.popover.style.left = `${pad}px`;
        this.popover.style.top = `${pad}px`;
        this.highlight.hidden = true;
        return;
      }

      const tr = target.getBoundingClientRect();
      this.highlight.hidden = false;
      this.highlight.style.left = `${tr.left - 4}px`;
      this.highlight.style.top = `${tr.top - 4}px`;
      this.highlight.style.width = `${tr.width + 8}px`;
      this.highlight.style.height = `${tr.height + 8}px`;

      const placement = step.placement || "bottom";
      let left = tr.left;
      let top = tr.bottom + gap + arrowSize;

      if (placement === "flow") {
        const sidebarWidth = Math.max(0, tr.right + gap + arrowSize);
        left = Math.min(Math.max(pad, sidebarWidth), vw - popRect.width - pad);
        top = tr.top + tr.height / 2 - popRect.height / 2;
      } else if (placement === "top") {
        top = tr.top - popRect.height - gap - arrowSize;
        left = tr.left + tr.width / 2 - popRect.width / 2;
      } else if (placement === "bottom") {
        top = tr.bottom + gap + arrowSize;
        left = tr.left + tr.width / 2 - popRect.width / 2;
      } else if (placement === "left") {
        left = tr.left - popRect.width - gap - arrowSize;
        top = tr.top + tr.height / 2 - popRect.height / 2;
      } else if (placement === "right") {
        left = tr.right + gap + arrowSize;
        top = tr.top + tr.height / 2 - popRect.height / 2;
      }

      left = Math.min(Math.max(pad, left), vw - popRect.width - pad);
      top = Math.min(Math.max(pad, top), vh - popRect.height - pad);
      this.popover.style.left = `${left}px`;
      this.popover.style.top = `${top}px`;

      if (step.showArrow !== false) {
        const arrow = this.arrowEl;
        arrow.style.right = "";
        arrow.style.bottom = "";
        if (placement === "flow") {
          const ay = tr.top + tr.height / 2 - top;
          arrow.style.left = "";
          arrow.style.top = `${Math.min(Math.max(arrowSize + 8, ay), popRect.height - arrowSize - 8)}px`;
        } else if (placement === "bottom") {
          const ax = tr.left + tr.width / 2 - left;
          arrow.style.left = `${Math.min(Math.max(arrowSize + 8, ax), popRect.width - arrowSize - 8)}px`;
          arrow.style.top = "";
        } else if (placement === "top") {
          const ax = tr.left + tr.width / 2 - left;
          arrow.style.left = `${Math.min(Math.max(arrowSize + 8, ax), popRect.width - arrowSize - 8)}px`;
          arrow.style.top = "";
        } else if (placement === "right") {
          const ay = tr.top + tr.height / 2 - top;
          arrow.style.left = "";
          arrow.style.top = `${Math.min(Math.max(arrowSize + 8, ay), popRect.height - arrowSize - 8)}px`;
        } else if (placement === "left") {
          const ay = tr.top + tr.height / 2 - top;
          arrow.style.left = "";
          arrow.style.top = `${Math.min(Math.max(arrowSize + 8, ay), popRect.height - arrowSize - 8)}px`;
        }
      }
    }

    next() {
      if (this.index >= this.steps.length - 1) return this.finish();
      this.showStep(this.index + 1);
    }

    back() {
      if (this.index <= 0) return;
      this.showStep(this.index - 1);
    }

    finish() {
      markCompleted();
      this.destroy();
    }
  }

  let contactsTourStartAttempts = 0;

  function maybeStartContactsTour() {
    if (!isContactsPage() || !shouldRun()) return;
    const required = CONTACTS_STEPS.filter((s) => s.selector && !s.optional);
    const missing = required.filter((s) => !document.querySelector(s.selector));
    if (missing.length && contactsTourStartAttempts < 12) {
      contactsTourStartAttempts += 1;
      setTimeout(maybeStartContactsTour, 400);
      return;
    }
    if (missing.length) return;
    const steps = CONTACTS_STEPS.filter((s) => !s.optional || document.querySelector(s.selector));
    const tour = new OnboardingTour(steps);
    tour.start();
  }

  window.CrmOnboardingTour = {
    STORAGE_KEY,
    maybeStartContactsTour,
    resetContactsTour() {
      try {
        localStorage.removeItem(STORAGE_KEY);
      } catch {
        /* ignore */
      }
    }
  };

  let tourBooted = false;

  function startTourAfterWizard() {
    if (tourBooted) return;
    const forceTour = new URLSearchParams(window.location.search).get("onboarding") === "1";
    if (!forceTour && document.getElementById("firstLoginWizard")) return;
    tourBooted = true;
    maybeStartContactsTour();
  }

  async function init() {
    if (!isContactsPage()) return;
    if (typeof prefs.resolveOnboardingAccount === "function") {
      await prefs.resolveOnboardingAccount();
    }
    const forceTour = new URLSearchParams(window.location.search).get("onboarding") === "1";
    if (forceTour) {
      startTourAfterWizard();
      return;
    }
    window.addEventListener("crm-first-login-wizard-done", startTourAfterWizard, { once: true });
    if (!document.getElementById("firstLoginWizard")) {
      setTimeout(startTourAfterWizard, 7000);
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      void init();
    });
  } else {
    void init();
  }
})();
