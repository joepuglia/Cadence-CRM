"use strict";

const crypto = require("crypto");

const UNSUBSCRIBE_KEYWORDS =
  /\b(unsubscribe|opt[\s-]?out|remove me|stop emailing|stop emails|do not email|don't email|take me off)\b/i;

function getUnsubscribeSigningSecret() {
  const envKey = String(process.env.CRM_SECRET_KEY || "").trim();
  if (/^[0-9a-fA-F]{64}$/.test(envKey)) return Buffer.from(envKey, "hex");
  if (envKey) return crypto.createHash("sha256").update(`crm-unsub-v1:${envKey}`).digest();
  return crypto.createHash("sha256").update("crm-unsub-local-dev").digest();
}

function issueUnsubscribeToken({ tenantId, contactId, email }) {
  const em = String(email || "").trim().toLowerCase();
  if (!em || !em.includes("@")) return "";
  const payload = JSON.stringify({
    t: String(tenantId || "legacy").trim() || "legacy",
    e: em,
    c: Number.isInteger(Number(contactId)) && Number(contactId) > 0 ? Number(contactId) : null
  });
  const sig = crypto.createHmac("sha256", getUnsubscribeSigningSecret()).update(payload).digest("base64url");
  return Buffer.from(`${payload}.${sig}`).toString("base64url");
}

function verifyUnsubscribeToken(token) {
  const raw = String(token || "").trim();
  if (!raw) return null;
  try {
    const decoded = Buffer.from(raw, "base64url").toString("utf8");
    const dot = decoded.lastIndexOf(".");
    if (dot < 1) return null;
    const payload = decoded.slice(0, dot);
    const sig = decoded.slice(dot + 1);
    const expected = crypto.createHmac("sha256", getUnsubscribeSigningSecret()).update(payload).digest("base64url");
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
    const data = JSON.parse(payload);
    const email = String(data?.e || "").trim().toLowerCase();
    if (!email || !email.includes("@")) return null;
    return {
      tenantId: String(data?.t || "legacy").trim() || "legacy",
      email,
      contactId: Number.isInteger(Number(data?.c)) && Number(data?.c) > 0 ? Number(data.c) : null
    };
  } catch {
    return null;
  }
}

function buildUnsubscribePageUrl(publicOrigin, token) {
  const base = String(publicOrigin || "").trim().replace(/\/$/, "");
  if (!base) return "";
  if (token) return `${base}/email-unsubscribe.html?token=${encodeURIComponent(token)}`;
  return `${base}/email-unsubscribe.html`;
}

function buildListUnsubscribeHeaders() {
  // Gmail files mail into Promotions when these bulk-mail headers are present.
  return { headers: {} };
}

function htmlAlreadyHasUnsubscribe(html, text, unsubscribeUrl) {
  const u = String(unsubscribeUrl || "").trim();
  const h = String(html || "");
  const t = String(text || "");
  if (u && (h.includes(u) || t.includes(u))) return true;
  return /\bunsubscribe\b/i.test(h) || /\bunsubscribe\b/i.test(t);
}

const PLAIN_REPLY_LINE = "Reply to this email if you would rather not hear from me.";

function appendUnsubscribeFooter({ html, text }) {
  const h = String(html || "");
  const t = String(text || "");
  if (htmlAlreadyHasUnsubscribe(h, t, "") || /rather not hear from me/i.test(`${h}\n${t}`)) {
    return { html: h, text: t };
  }
  const htmlFooter = `<p style="margin:16px 0 0;font-family:Arial,Helvetica,sans-serif;font-size:13px;line-height:1.4;color:#444;text-align:left;">${PLAIN_REPLY_LINE}</p>`;
  const textFooter = `\n\n${PLAIN_REPLY_LINE}`;
  return {
    html: `${h.trim()}${htmlFooter}`,
    text: `${t.trim()}${textFooter}`.trim()
  };
}

function prepareOutboundEmailWithUnsubscribe({
  subject,
  text,
  html,
  contact,
  tenantId,
  publicOrigin,
  mergeFields,
  customFields,
  applyMergeFields
}) {
  const email = String(contact?.email || mergeFields?.email || "").trim().toLowerCase();
  const contactId = contact?.id ? Number(contact.id) : null;
  const token = email ? issueUnsubscribeToken({ tenantId, contactId, email }) : "";
  const unsubscribeUrl = buildUnsubscribePageUrl(publicOrigin, token);
  const merge = {
    ...(mergeFields && typeof mergeFields === "object" ? mergeFields : {}),
    unsubscribe_url: unsubscribeUrl
  };
  let outSubject = applyMergeFields(String(subject || ""), merge, { customFields, keepHtmlNbsp: false });
  let outText = applyMergeFields(String(text || ""), merge, { customFields, keepHtmlNbsp: false });
  let outHtml = applyMergeFields(String(html || ""), merge, { customFields, keepHtmlNbsp: true });
  const footered = appendUnsubscribeFooter({ html: outHtml, text: outText });
  return {
    subject: outSubject,
    text: footered.text,
    html: footered.html,
    unsubscribeUrl,
    listUnsubscribeHeaders: buildListUnsubscribeHeaders()
  };
}

function isUnsubscribeReplyContent(subject, text) {
  const combined = `${String(subject || "").trim()}\n${String(text || "").trim()}`.trim();
  return UNSUBSCRIBE_KEYWORDS.test(combined);
}

function extractReplyEmailAddress(from) {
  const raw = String(from || "").trim();
  if (!raw) return "";
  const angled = raw.match(/<([^>]+@[^>]+)>/);
  if (angled) return String(angled[1] || "").trim().toLowerCase();
  const found = raw.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
  return found ? String(found[0] || "").trim().toLowerCase() : raw.toLowerCase();
}

async function markEmailUnsubscribed(deps, { email, tenantId, source, contactId }) {
  const { run, all, get, logContactActivity } = deps;
  const em = String(email || "").trim().toLowerCase();
  if (!em || !em.includes("@")) {
    return { ok: false, error: "Valid email is required.", updated: 0 };
  }
  let ids = [];
  if (Number.isInteger(Number(contactId)) && Number(contactId) > 0) {
    const row = await get(`SELECT id, do_not_email FROM contacts WHERE id = ?`, [Number(contactId)]);
    if (row) ids = [Number(row.id)];
  }
  if (!ids.length) {
    const rows = await all(`SELECT id FROM contacts WHERE lower(trim(email)) = ?`, [em]);
    ids = (Array.isArray(rows) ? rows : []).map((r) => Number(r.id)).filter((n) => Number.isInteger(n) && n > 0);
  }
  if (!ids.length) {
    return { ok: true, updated: 0, message: "No matching contact found — nothing to update.", email: em, tenantId };
  }
  const placeholders = ids.map(() => "?").join(",");
  await run(`UPDATE contacts SET do_not_email = '1', updated_at = CURRENT_TIMESTAMP WHERE id IN (${placeholders})`, ids);
  const detail = `Email unsubscribe (${String(source || "link").trim()})\nAddress: ${em}`;
  for (const id of ids) {
    await logContactActivity(id, "detail_change", detail);
  }
  return { ok: true, updated: ids.length, email: em, tenantId, contactIds: ids };
}

module.exports = {
  UNSUBSCRIBE_KEYWORDS,
  issueUnsubscribeToken,
  verifyUnsubscribeToken,
  buildUnsubscribePageUrl,
  buildListUnsubscribeHeaders,
  appendUnsubscribeFooter,
  prepareOutboundEmailWithUnsubscribe,
  isUnsubscribeReplyContent,
  extractReplyEmailAddress,
  markEmailUnsubscribed
};
