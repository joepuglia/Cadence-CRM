"use strict";

const crypto = require("crypto");
const { run, get, all } = require("./db");

const GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth";
const GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token";
const GOOGLE_USERINFO_URL = "https://www.googleapis.com/oauth2/v2/userinfo";
const GOOGLE_CALENDAR_API = "https://www.googleapis.com/calendar/v3";

const SCOPES = [
  "https://www.googleapis.com/auth/calendar",
  "https://www.googleapis.com/auth/userinfo.email"
].join(" ");

const oauthStateCache = new Map();
const STATE_TTL_MS = 10 * 60 * 1000;

function getClientId() {
  return String(process.env.GOOGLE_CLIENT_ID || "").trim();
}

function getClientSecret() {
  return String(process.env.GOOGLE_CLIENT_SECRET || "").trim();
}

function getRedirectUri(req) {
  const fromEnv = String(process.env.GOOGLE_REDIRECT_URI || "").trim();
  if (fromEnv) return fromEnv;
  if (req && req.protocol && req.get) {
    return `${req.protocol}://${req.get("host")}/api/google/calendar/callback`;
  }
  return "http://localhost:3000/api/google/calendar/callback";
}

function isConfigured() {
  return Boolean(getClientId() && getClientSecret());
}

function normalizeReturnTo(returnTo) {
  const raw = String(returnTo || "").trim();
  if (raw.startsWith("/") && !raw.startsWith("//")) return raw;
  return "/calendar.html";
}

async function persistOAuthState(state, returnTo) {
  const meta = { createdAt: Date.now(), returnTo: normalizeReturnTo(returnTo) };
  const key = `${STATE_KEY_PREFIX}${state}`;
  await run(`INSERT OR REPLACE INTO crm_app_settings (key, value) VALUES (?, ?)`, [
    key,
    JSON.stringify(meta)
  ]);
  oauthStateCache.set(state, meta);
}

async function pruneExpiredStates() {
  const cutoff = Date.now() - STATE_TTL_MS;
  const rows = await all(`SELECT key, value FROM crm_app_settings WHERE key LIKE ?`, [
    `${STATE_KEY_PREFIX}%`
  ]);
  for (const row of rows) {
    let createdAt = 0;
    try {
      createdAt = Number(JSON.parse(String(row.value || "{}")).createdAt) || 0;
    } catch {
      createdAt = 0;
    }
    if (!createdAt || createdAt < cutoff) {
      await run(`DELETE FROM crm_app_settings WHERE key = ?`, [row.key]);
    }
  }
  for (const [key, value] of oauthStateCache) {
    if (!value || value.createdAt < cutoff) oauthStateCache.delete(key);
  }
}

async function buildAuthUrl(req, returnTo) {
  if (!isConfigured()) {
    throw new Error("Google OAuth not configured. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in .env.");
  }
  const state = crypto.randomBytes(18).toString("hex");
  await persistOAuthState(state, returnTo);
  await pruneExpiredStates();
  const params = new URLSearchParams({
    client_id: getClientId(),
    redirect_uri: getRedirectUri(req),
    response_type: "code",
    scope: SCOPES,
    access_type: "offline",
    include_granted_scopes: "true",
    prompt: "consent",
    state
  });
  return `${GOOGLE_AUTH_URL}?${params.toString()}`;
}

async function consumeState(state) {
  if (!state) return null;
  const key = `${STATE_KEY_PREFIX}${state}`;
  const row = await get(`SELECT value FROM crm_app_settings WHERE key = ?`, [key]);
  if (row) {
    await run(`DELETE FROM crm_app_settings WHERE key = ?`, [key]);
    oauthStateCache.delete(state);
    try {
      const meta = JSON.parse(String(row.value || "{}"));
      const createdAt = Number(meta.createdAt) || 0;
      if (createdAt && Date.now() - createdAt <= STATE_TTL_MS) {
        return { createdAt, returnTo: normalizeReturnTo(meta.returnTo) };
      }
    } catch {
      return null;
    }
  }
  const value = oauthStateCache.get(state) || null;
  if (value) oauthStateCache.delete(state);
  if (!value) return null;
  if (Date.now() - value.createdAt > STATE_TTL_MS) return null;
  return value;
}

async function exchangeCodeForTokens(code, redirectUri) {
  const body = new URLSearchParams({
    code,
    client_id: getClientId(),
    client_secret: getClientSecret(),
    redirect_uri: redirectUri,
    grant_type: "authorization_code"
  });
  const response = await fetch(GOOGLE_TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: body.toString()
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error_description || data.error || `Google token exchange failed (HTTP ${response.status})`);
  }
  return data;
}

async function refreshAccessToken(refreshToken) {
  const body = new URLSearchParams({
    refresh_token: refreshToken,
    client_id: getClientId(),
    client_secret: getClientSecret(),
    grant_type: "refresh_token"
  });
  const response = await fetch(GOOGLE_TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: body.toString()
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error_description || data.error || `Google token refresh failed (HTTP ${response.status})`);
  }
  return data;
}

async function fetchUserEmail(accessToken) {
  try {
    const response = await fetch(GOOGLE_USERINFO_URL, {
      headers: { Authorization: `Bearer ${accessToken}` }
    });
    if (!response.ok) return "";
    const data = await response.json().catch(() => ({}));
    return String(data.email || "").trim();
  } catch (_e) {
    return "";
  }
}

async function saveTokens(tokenData, accountEmail) {
  const expiryEpoch = tokenData.expires_in
    ? Math.floor(Date.now() / 1000) + Number(tokenData.expires_in)
    : 0;
  const existing = await get(`SELECT id, refresh_token, calendar_id FROM google_oauth_tokens WHERE id = 1`);
  const refresh = tokenData.refresh_token || (existing && existing.refresh_token) || "";
  const calendarId = (existing && existing.calendar_id) || "primary";
  const accessToken = tokenData.access_token || "";
  const tokenType = tokenData.token_type || "Bearer";
  const scope = tokenData.scope || "";
  const updatedAt = Math.floor(Date.now() / 1000);
  if (existing) {
    await run(
      `UPDATE google_oauth_tokens
       SET access_token = ?, refresh_token = ?, expiry = ?, token_type = ?, scope = ?,
           account_email = ?, calendar_id = ?, updated_at = ?
       WHERE id = 1`,
      [accessToken, refresh, expiryEpoch, tokenType, scope, accountEmail || "", calendarId, updatedAt]
    );
  } else {
    await run(
      `INSERT INTO google_oauth_tokens
       (id, access_token, refresh_token, expiry, token_type, scope, account_email, calendar_id, updated_at)
       VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [accessToken, refresh, expiryEpoch, tokenType, scope, accountEmail || "", calendarId, updatedAt]
    );
  }
}

async function loadTokens() {
  return get(
    `SELECT access_token, refresh_token, expiry, token_type, scope, account_email, calendar_id, last_sync_at, updated_at
     FROM google_oauth_tokens WHERE id = 1`
  );
}

async function disconnect() {
  await run(`DELETE FROM google_oauth_tokens WHERE id = 1`);
}

async function getValidAccessToken() {
  const row = await loadTokens();
  if (!row) return null;
  const nowSec = Math.floor(Date.now() / 1000);
  if (row.access_token && row.expiry && nowSec < Number(row.expiry) - 60) {
    return row.access_token;
  }
  if (!row.refresh_token) return null;
  const refreshed = await refreshAccessToken(row.refresh_token);
  await saveTokens(refreshed, row.account_email);
  return refreshed.access_token;
}

async function getStatus() {
  const row = await loadTokens();
  if (!row || (!row.access_token && !row.refresh_token)) {
    return {
      connected: false,
      configured: isConfigured(),
      accountEmail: "",
      calendarId: "primary",
      lastSyncAt: 0
    };
  }
  return {
    connected: true,
    configured: isConfigured(),
    accountEmail: String(row.account_email || ""),
    calendarId: String(row.calendar_id || "primary"),
    lastSyncAt: Number(row.last_sync_at || 0)
  };
}

function toGoogleEvent(localEvent) {
  const allDay = Number(localEvent.all_day) === 1;
  const out = {
    summary: String(localEvent.title || "Untitled"),
    description: String(localEvent.description || ""),
    location: String(localEvent.location || "")
  };
  const startDate = String(localEvent.event_date || "");
  const endDate = String(localEvent.end_date || localEvent.event_date || "");
  if (allDay || !localEvent.event_time) {
    const endPlusOne = addDaysIso(endDate || startDate, 1);
    out.start = { date: startDate };
    out.end = { date: endPlusOne };
  } else {
    const startTime = String(localEvent.event_time || "00:00");
    const endTime = String(localEvent.end_time || incrementTime(startTime, 60));
    const startIso = `${startDate}T${ensureSeconds(startTime)}`;
    const endIso = `${endDate || startDate}T${ensureSeconds(endTime)}`;
    out.start = { dateTime: startIso };
    out.end = { dateTime: endIso };
  }
  const recurrence = String(localEvent.recurrence || "").trim().toLowerCase();
  const rruleMap = {
    daily: "RRULE:FREQ=DAILY",
    weekly: "RRULE:FREQ=WEEKLY",
    monthly: "RRULE:FREQ=MONTHLY",
    yearly: "RRULE:FREQ=YEARLY"
  };
  if (rruleMap[recurrence]) {
    out.recurrence = [rruleMap[recurrence]];
  }
  return out;
}

function ensureSeconds(time) {
  const t = String(time || "00:00").trim();
  if (/^\d{2}:\d{2}:\d{2}$/.test(t)) return t;
  if (/^\d{2}:\d{2}$/.test(t)) return `${t}:00`;
  if (/^\d{1,2}:\d{2}$/.test(t)) return `${t.padStart(5, "0")}:00`;
  return "00:00:00";
}

function incrementTime(hhmm, minutes) {
  const m = String(hhmm || "00:00").match(/^(\d{1,2}):(\d{2})/);
  if (!m) return "01:00";
  let total = Number(m[1]) * 60 + Number(m[2]) + Number(minutes || 0);
  total = ((total % 1440) + 1440) % 1440;
  const hh = String(Math.floor(total / 60)).padStart(2, "0");
  const mm = String(total % 60).padStart(2, "0");
  return `${hh}:${mm}`;
}

function addDaysIso(yyyyMmDd, days) {
  const m = String(yyyyMmDd || "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return yyyyMmDd;
  const dt = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  dt.setDate(dt.getDate() + Number(days || 0));
  const y = dt.getFullYear();
  const mo = String(dt.getMonth() + 1).padStart(2, "0");
  const d = String(dt.getDate()).padStart(2, "0");
  return `${y}-${mo}-${d}`;
}

async function googleApiCall(method, path, body) {
  const accessToken = await getValidAccessToken();
  if (!accessToken) throw new Error("Google Calendar is not connected.");
  const headers = { Authorization: `Bearer ${accessToken}` };
  const init = { method, headers };
  if (body !== undefined) {
    headers["Content-Type"] = "application/json";
    init.body = JSON.stringify(body);
  }
  const url = path.startsWith("http") ? path : `${GOOGLE_CALENDAR_API}${path}`;
  const response = await fetch(url, init);
  if (response.status === 204) return null;
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const msg = (data && data.error && data.error.message) || `Google Calendar HTTP ${response.status}`;
    const err = new Error(msg);
    err.status = response.status;
    throw err;
  }
  return data;
}

async function listGoogleEventsInRange(timeMinIso, timeMaxIso) {
  const row = await loadTokens();
  const calendarId = (row && row.calendar_id) || "primary";
  const items = [];
  let pageToken = "";
  do {
    const params = new URLSearchParams({
      timeMin: timeMinIso,
      timeMax: timeMaxIso,
      singleEvents: "true",
      orderBy: "startTime",
      maxResults: "250"
    });
    if (pageToken) params.set("pageToken", pageToken);
    const data = await googleApiCall(
      "GET",
      `/calendars/${encodeURIComponent(calendarId)}/events?${params.toString()}`
    );
    if (Array.isArray(data && data.items)) items.push(...data.items);
    pageToken = (data && data.nextPageToken) || "";
  } while (pageToken);
  return items;
}

function googleEventToLocalRow(googleEvent) {
  if (!googleEvent || !googleEvent.id) return null;
  const start = googleEvent.start || {};
  const end = googleEvent.end || {};
  const isAllDay = Boolean(start.date && !start.dateTime);
  let eventDate = "";
  let eventTime = "";
  let endDate = "";
  let endTime = "";
  if (isAllDay) {
    eventDate = String(start.date || "");
    endDate = end.date ? addDaysIso(String(end.date), -1) : eventDate;
  } else if (start.dateTime) {
    const dt = new Date(start.dateTime);
    eventDate = formatLocalDate(dt);
    eventTime = formatLocalTime(dt);
    if (end.dateTime) {
      const endDt = new Date(end.dateTime);
      endDate = formatLocalDate(endDt);
      endTime = formatLocalTime(endDt);
    }
  }
  return {
    title: String(googleEvent.summary || "(no title)"),
    description: String(googleEvent.description || ""),
    location: String(googleEvent.location || ""),
    event_date: eventDate,
    event_time: eventTime,
    end_date: endDate,
    end_time: endTime,
    all_day: isAllDay ? 1 : 0,
    google_event_id: String(googleEvent.id),
    google_calendar_id: "primary",
    color: "#16a34a",
    origin: "google"
  };
}

function formatLocalDate(dt) {
  const y = dt.getFullYear();
  const m = String(dt.getMonth() + 1).padStart(2, "0");
  const d = String(dt.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function formatLocalTime(dt) {
  const h = String(dt.getHours()).padStart(2, "0");
  const m = String(dt.getMinutes()).padStart(2, "0");
  return `${h}:${m}`;
}

async function pushEventToGoogle(localEvent) {
  const row = await loadTokens();
  const calendarId = (row && row.calendar_id) || "primary";
  const body = toGoogleEvent(localEvent);
  if (localEvent.google_event_id) {
    return googleApiCall(
      "PATCH",
      `/calendars/${encodeURIComponent(calendarId)}/events/${encodeURIComponent(localEvent.google_event_id)}`,
      body
    );
  }
  return googleApiCall("POST", `/calendars/${encodeURIComponent(calendarId)}/events`, body);
}

async function deleteGoogleEvent(googleEventId) {
  if (!googleEventId) return;
  const row = await loadTokens();
  const calendarId = (row && row.calendar_id) || "primary";
  try {
    await googleApiCall(
      "DELETE",
      `/calendars/${encodeURIComponent(calendarId)}/events/${encodeURIComponent(googleEventId)}`
    );
  } catch (err) {
    if (err && err.status === 404) return;
    if (err && err.status === 410) return;
    throw err;
  }
}

async function setLastSyncAt(epochSeconds) {
  const updatedAt = Math.floor(Date.now() / 1000);
  await run(
    `UPDATE google_oauth_tokens SET last_sync_at = ?, updated_at = ? WHERE id = 1`,
    [Math.max(0, Number(epochSeconds || 0)), updatedAt]
  );
}

module.exports = {
  isConfigured,
  buildAuthUrl,
  consumeState,
  exchangeCodeForTokens,
  refreshAccessToken,
  fetchUserEmail,
  saveTokens,
  loadTokens,
  disconnect,
  getValidAccessToken,
  getStatus,
  listGoogleEventsInRange,
  googleEventToLocalRow,
  pushEventToGoogle,
  deleteGoogleEvent,
  toGoogleEvent,
  setLastSyncAt,
  getRedirectUri
};
