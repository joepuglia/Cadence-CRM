"use strict";

const { buildRenewalItems } = require("./renewals");
const { sqlExcludeInitialImportTags } = require("./initialImportOmit");

const KIND_LABELS = {
  task_overdue: "Overdue task",
  task_today: "Task due today",
  follow_up_overdue: "Overdue follow-up",
  follow_up_today: "Follow-up today",
  renewal_overdue: "Overdue renewal",
  renewal_soon: "Renewal soon",
  stale_lead: "Not contacted 7+ days",
  hot_lead: "Hot lead"
};

const PRIORITY = {
  hot_lead: 110,
  task_overdue: 100,
  follow_up_overdue: 95,
  task_today: 80,
  follow_up_today: 75,
  renewal_overdue: 70,
  stale_lead: 55,
  renewal_soon: 45
};

function kindLabel(kind) {
  return KIND_LABELS[kind] || String(kind || "Attention");
}

function contactHref(contactId, focus) {
  const id = Number(contactId) || 0;
  if (!id) return "#";
  const base = `/contact.html?id=${encodeURIComponent(id)}`;
  if (focus === "tasks") return `${base}&full=1&focus=tasks#contactTasksSection`;
  if (focus === "follow_up") return `${base}&full=1&focus=follow_up#contactFollowUpSection`;
  return base;
}

function dueAt(dateYmd, timeHhmm) {
  const d = String(dateYmd || "").trim().slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) return null;
  const t = String(timeHhmm || "").trim();
  if (/^\d{2}:\d{2}$/.test(t)) return `${d}T${t}`;
  return d;
}

function pushItem(items, partial) {
  const kind = String(partial.kind || "");
  const contactId = Number(partial.contact_id) || 0;
  if (!kind || !contactId) return;
  items.push({
    kind,
    kind_label: kindLabel(kind),
    priority: Number(PRIORITY[kind]) || 0,
    contact_id: contactId,
    contact_name: String(partial.contact_name || "").trim() || "Unnamed contact",
    title: String(partial.title || kindLabel(kind)).trim(),
    due_at: partial.due_at || null,
    href: partial.href || contactHref(contactId),
    meta: partial.meta && typeof partial.meta === "object" ? partial.meta : {}
  });
}

async function loadTaskItems(all, omitTagsC) {
  const rows = await all(
    `SELECT
       t.id,
       t.contact_id,
       t.task_name,
       t.action_type,
       t.task_date,
       t.task_time,
       COALESCE(c.full_name, '') AS contact_name
     FROM contact_tasks t
     INNER JOIN contacts c ON c.id = t.contact_id
     WHERE lower(trim(COALESCE(t.condition, ''))) != 'completed'
       AND trim(COALESCE(t.task_date, '')) != ''
       AND date(t.task_date) <= date('now')
       AND ${omitTagsC}
     ORDER BY date(t.task_date) ASC, trim(COALESCE(t.task_time, '')) ASC, t.id ASC
     LIMIT 200`
  );
  return Array.isArray(rows) ? rows : [];
}

async function loadFollowUpItems(all, omitTagsC) {
  const rows = await all(
    `SELECT
       c.id AS contact_id,
       COALESCE(c.full_name, '') AS contact_name,
       c.follow_up_date,
       c.follow_up_time
     FROM contacts c
     WHERE trim(COALESCE(c.follow_up_date, '')) != ''
       AND date(c.follow_up_date) <= date('now')
       AND lower(trim(COALESCE(c.outcome, ''))) != 'sold'
       AND ${omitTagsC}
       AND NOT EXISTS (
         SELECT 1
         FROM contact_tasks t
         WHERE t.contact_id = c.id
           AND lower(trim(COALESCE(t.condition, ''))) = 'completed'
           AND trim(COALESCE(t.task_date, '')) != ''
           AND date(t.task_date) = date(c.follow_up_date)
       )
     ORDER BY date(c.follow_up_date) ASC, trim(COALESCE(c.follow_up_time, '')) ASC
     LIMIT 200`
  );
  return Array.isArray(rows) ? rows : [];
}

async function loadStaleLeadItems(all, omitTagsC) {
  // Exclude initial-import book dump. "Contacted" = outreach only (call/sms/email).
  const rows = await all(
    `SELECT
       c.id AS contact_id,
       COALESCE(c.full_name, '') AS contact_name,
       c.status,
       c.outcome,
       c.created_at,
       act.last_outreach,
       COALESCE(
         act.last_outreach,
         NULLIF(trim(COALESCE(c.last_called, '')), ''),
         NULLIF(trim(COALESCE(c.last_sms, '')), ''),
         NULLIF(trim(COALESCE(c.last_emailed, '')), ''),
         c.created_at
       ) AS last_touch_at
     FROM contacts c
     LEFT JOIN (
       SELECT contact_id, MAX(datetime(created_at)) AS last_outreach
       FROM contact_activity
       WHERE lower(trim(COALESCE(activity_type, ''))) IN ('call', 'sms', 'email', 'email_sent')
       GROUP BY contact_id
     ) act ON act.contact_id = c.id
     WHERE lower(trim(COALESCE(c.outcome, ''))) NOT IN (
         'sold', 'do not call', 'dnc', 'not interested', 'already covered', 'wrong number'
       )
       AND lower(trim(COALESCE(c.status, ''))) NOT IN ('sold', 'approved', 'client', 'closed')
       AND datetime(COALESCE(
         act.last_outreach,
         NULLIF(trim(COALESCE(c.last_called, '')), ''),
         NULLIF(trim(COALESCE(c.last_sms, '')), ''),
         NULLIF(trim(COALESCE(c.last_emailed, '')), ''),
         c.created_at
       )) < datetime('now', '-7 days')
       AND ${omitTagsC}
     ORDER BY datetime(COALESCE(
       act.last_outreach,
       NULLIF(trim(COALESCE(c.last_called, '')), ''),
       NULLIF(trim(COALESCE(c.last_sms, '')), ''),
       NULLIF(trim(COALESCE(c.last_emailed, '')), ''),
       c.created_at
     )) ASC
     LIMIT 500`
  );
  return Array.isArray(rows) ? rows : [];
}

async function loadHotLeadItems(all, omitTagsC) {
  const rows = await all(
    `SELECT
       c.id AS contact_id,
       COALESCE(c.full_name, '') AS contact_name,
       c.ai_lead_score,
       c.ai_lead_reason,
       c.outcome,
       c.status
     FROM contacts c
     WHERE CAST(COALESCE(c.ai_lead_score, 0) AS REAL) >= 7
       AND lower(trim(COALESCE(c.outcome, ''))) NOT IN ('sold', 'do not call', 'dnc', 'not interested')
       AND lower(COALESCE(c.ai_lead_reason, '')) NOT LIKE '%marked sold%'
       AND ${omitTagsC}
     ORDER BY CAST(COALESCE(c.ai_lead_score, 0) AS REAL) DESC, c.id DESC
     LIMIT 50`
  );
  return Array.isArray(rows) ? rows : [];
}

async function loadRenewalRows(all, omitTags) {
  const rows = await all(
    `SELECT id, full_name, email, phone, coverage_start_date, quote, coverages_sold,
            status, outcome, lead_source, annual_renewal, renewal_interval
     FROM contacts
     WHERE trim(COALESCE(coverage_start_date, '')) != ''
       AND (
         COALESCE(renewal_interval, '') IN ('3', '6', '12')
         OR (COALESCE(renewal_interval, '') = '' AND COALESCE(annual_renewal, '') = '1')
       )
       AND ${omitTags}`
  );
  return Array.isArray(rows) ? rows : [];
}

function isTodayYmd(ymd) {
  const d = String(ymd || "").trim().slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) return false;
  const now = new Date();
  const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
  return d === today;
}

function isPastYmd(ymd) {
  const d = String(ymd || "").trim().slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) return false;
  const now = new Date();
  const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
  return d < today;
}

/**
 * Build a prioritized attention queue from existing CRM signals.
 * @param {{ all: Function }} db
 */
async function buildAttentionQueue(db) {
  const { all } = db;
  const omitTags = sqlExcludeInitialImportTags();
  const omitTagsC = sqlExcludeInitialImportTags("c");

  const [taskRows, followUpRows, staleRows, hotRows, renewalSourceRows] = await Promise.all([
    loadTaskItems(all, omitTagsC),
    loadFollowUpItems(all, omitTagsC),
    loadStaleLeadItems(all, omitTagsC),
    loadHotLeadItems(all, omitTagsC),
    loadRenewalRows(all, omitTags)
  ]);

  const items = [];
  const seen = new Set();

  function dedupeKey(kind, contactId, extra) {
    return `${kind}:${contactId}:${extra || ""}`;
  }

  for (const row of taskRows) {
    const date = String(row.task_date || "").trim().slice(0, 10);
    const kind = isPastYmd(date) ? "task_overdue" : isTodayYmd(date) ? "task_today" : null;
    if (!kind) continue;
    const key = dedupeKey(kind, row.contact_id, row.id);
    if (seen.has(key)) continue;
    seen.add(key);
    pushItem(items, {
      kind,
      contact_id: row.contact_id,
      contact_name: row.contact_name,
      title: String(row.task_name || "").trim() || kindLabel(kind),
      due_at: dueAt(row.task_date, row.task_time),
      href: contactHref(row.contact_id, "tasks"),
      meta: { task_id: Number(row.id) || 0, action_type: String(row.action_type || "") }
    });
  }

  for (const row of followUpRows) {
    const date = String(row.follow_up_date || "").trim().slice(0, 10);
    const kind = isPastYmd(date) ? "follow_up_overdue" : isTodayYmd(date) ? "follow_up_today" : null;
    if (!kind) continue;
    const key = dedupeKey(kind, row.contact_id, date);
    if (seen.has(key)) continue;
    seen.add(key);
    pushItem(items, {
      kind,
      contact_id: row.contact_id,
      contact_name: row.contact_name,
      title: kindLabel(kind),
      due_at: dueAt(row.follow_up_date, row.follow_up_time),
      href: contactHref(row.contact_id, "follow_up"),
      meta: {}
    });
  }

  const renewalPayload = buildRenewalItems(renewalSourceRows);
  for (const row of renewalPayload.items || []) {
    const days = Number(row.days_until);
    if (!Number.isFinite(days)) continue;
    let kind = null;
    if (days < 0) kind = "renewal_overdue";
    else if (days <= 14) kind = "renewal_soon";
    if (!kind) continue;
    const key = dedupeKey(kind, row.id, row.next_renewal);
    if (seen.has(key)) continue;
    seen.add(key);
    pushItem(items, {
      kind,
      contact_id: row.id,
      contact_name: row.full_name,
      title:
        kind === "renewal_overdue"
          ? `Renewal overdue (${Math.abs(days)}d)`
          : days === 0
            ? "Renewal today"
            : `Renewal in ${days} day${days === 1 ? "" : "s"}`,
      due_at: row.next_renewal || null,
      href: contactHref(row.id),
      meta: { days_until: days, next_renewal: row.next_renewal }
    });
  }

  for (const row of staleRows) {
    const key = dedupeKey("stale_lead", row.contact_id);
    if (seen.has(key)) continue;
    seen.add(key);
    const status = String(row.status || "").trim() || "Lead";
    pushItem(items, {
      kind: "stale_lead",
      contact_id: row.contact_id,
      contact_name: row.contact_name,
      title: `No call, text, or email in 7+ days`,
      due_at: null,
      href: contactHref(row.contact_id),
      meta: {
        last_at: row.last_touch_at || row.last_outreach || row.created_at || null,
        status,
        outcome: String(row.outcome || "").trim()
      }
    });
  }

  for (const row of hotRows) {
    const key = dedupeKey("hot_lead", row.contact_id);
    if (seen.has(key)) continue;
    // Skip if already represented by a higher-urgency item for this contact
    const alreadyUrgent = items.some(
      (it) =>
        it.contact_id === Number(row.contact_id) &&
        ["task_overdue", "follow_up_overdue", "task_today", "follow_up_today"].includes(it.kind)
    );
    if (alreadyUrgent) continue;
    seen.add(key);
    const score = Number(row.ai_lead_score) || 0;
    const outcome = String(row.outcome || "").trim();
    const reason = String(row.ai_lead_reason || "").trim();
    const titleParts = [`AI score ${score}/10`];
    if (outcome) titleParts.push(outcome);
    pushItem(items, {
      kind: "hot_lead",
      contact_id: row.contact_id,
      contact_name: row.contact_name,
      title: titleParts.join(" · "),
      due_at: null,
      href: contactHref(row.contact_id),
      meta: {
        ai_lead_score: score,
        ai_lead_reason: reason,
        outcome
      }
    });
  }

  items.sort((a, b) => {
    if (b.priority !== a.priority) return b.priority - a.priority;
    const aScore = Number(a.meta && a.meta.ai_lead_score) || 0;
    const bScore = Number(b.meta && b.meta.ai_lead_score) || 0;
    if (a.kind === "hot_lead" && b.kind === "hot_lead" && bScore !== aScore) {
      return bScore - aScore;
    }
    const ad = String(a.due_at || "");
    const bd = String(b.due_at || "");
    if (ad && bd && ad !== bd) return ad.localeCompare(bd);
    if (ad && !bd) return -1;
    if (!ad && bd) return 1;
    return String(a.contact_name).localeCompare(String(b.contact_name));
  });

  const counts = {
    overdue: items.filter((it) =>
      ["task_overdue", "follow_up_overdue", "renewal_overdue"].includes(it.kind)
    ).length,
    today: items.filter((it) => ["task_today", "follow_up_today"].includes(it.kind)).length,
    upcoming: items.filter((it) => ["renewal_soon", "stale_lead", "hot_lead"].includes(it.kind)).length,
    total: items.length
  };

  const byKind = {};
  for (const it of items) {
    byKind[it.kind] = (byKind[it.kind] || 0) + 1;
  }

  const now = new Date();
  const asOf = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;

  return { asOf, items, counts, byKind };
}

module.exports = {
  buildAttentionQueue,
  KIND_LABELS
};
