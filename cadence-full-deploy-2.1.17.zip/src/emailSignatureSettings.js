/**
 * Server-persisted email signature (per-tenant crm_app_settings).
 * Shape matches browser localStorage: top-level default block + optional byFrom map.
 */
const SETTING_KEY = "email_signature_settings_v1";

function normalizeBlock(obj) {
  if (!obj || typeof obj !== "object") return {};
  return {
    text: String(obj.text || "").trim(),
    html: String(obj.html || "").trim(),
    fontSize: String(obj.fontSize != null && obj.fontSize !== "" ? obj.fontSize : "16"),
    color: String(obj.color != null && obj.color !== "" ? obj.color : "#1f2937").trim(),
    linkText: String(obj.linkText || "").trim(),
    linkUrl: String(obj.linkUrl || "").trim(),
    imageUrl: String(obj.imageUrl || "").trim()
  };
}

function stripByFrom(raw) {
  if (!raw || typeof raw !== "object") return {};
  const o = { ...raw };
  delete o.byFrom;
  delete o.include;
  return o;
}

function hasBlockContent(block) {
  const b = normalizeBlock(block);
  if (b.text || b.html) return true;
  if (b.linkText && b.linkUrl) return true;
  if (b.imageUrl) return true;
  if (b.html && /<img[\s>]/i.test(b.html)) return true;
  return false;
}

function normalizeStoredPayload(raw) {
  const src = raw && typeof raw === "object" ? raw : {};
  const byFromRaw = src.byFrom && typeof src.byFrom === "object" ? src.byFrom : {};
  const byFrom = {};
  for (const [addr, block] of Object.entries(byFromRaw)) {
    const key = String(addr || "").trim().toLowerCase();
    if (!key) continue;
    byFrom[key] = normalizeBlock(block);
  }
  const defaultBlock = normalizeBlock(stripByFrom(src));
  const include = src.include === false ? false : true;
  return {
    settings: { ...defaultBlock, byFrom },
    include
  };
}

function parseStoredJson(raw) {
  const s = String(raw || "").trim();
  if (!s) return normalizeStoredPayload({});
  try {
    return normalizeStoredPayload(JSON.parse(s));
  } catch {
    return normalizeStoredPayload({});
  }
}

async function readSetting(get, key) {
  const row = await get(`SELECT value FROM crm_app_settings WHERE key = ?`, [key]);
  return row ? String(row.value || "") : "";
}

async function writeSetting(run, key, value) {
  await run(`INSERT OR REPLACE INTO crm_app_settings (key, value) VALUES (?, ?)`, [key, String(value || "")]);
}

async function getEmailSignatureSettings(get) {
  const raw = await readSetting(get, SETTING_KEY);
  return parseStoredJson(raw);
}

async function saveEmailSignatureSettings(run, body) {
  const incoming = body && typeof body === "object" ? body : {};
  const settingsIn = incoming.settings && typeof incoming.settings === "object" ? incoming.settings : incoming;
  const saved = normalizeStoredPayload({
    ...stripByFrom(settingsIn),
    byFrom: settingsIn.byFrom,
    include: Object.prototype.hasOwnProperty.call(incoming, "include") ? incoming.include : settingsIn.include
  });
  const stored = {
    ...saved.settings,
    include: saved.include !== false
  };
  await writeSetting(run, SETTING_KEY, JSON.stringify(stored));
  return saved;
}

function registerEmailSignatureSettingsRoutes(app, { run, get }) {
  app.get("/api/email/signature-settings", async (req, res) => {
    try {
      const data = await getEmailSignatureSettings(get);
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: error.message || "Failed to load email signature settings" });
    }
  });

  app.put("/api/email/signature-settings", async (req, res) => {
    try {
      const saved = await saveEmailSignatureSettings(run, req.body || {});
      res.json(saved);
    } catch (error) {
      res.status(500).json({ error: error.message || "Failed to save email signature settings" });
    }
  });
}

module.exports = {
  SETTING_KEY,
  normalizeBlock,
  hasBlockContent,
  getEmailSignatureSettings,
  saveEmailSignatureSettings,
  registerEmailSignatureSettingsRoutes
};
