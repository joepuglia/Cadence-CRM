const { callClaudeJson, getClaudeConfig } = require("./claudeClient");
const {
  parseCsv,
  CADENCE_CONTACT_FIELDS,
  getSampleValuesForHeaders,
  buildStaticColumnMappings,
  mergeColumnMappings,
  mappingHasNameColumn,
  previewContactsCsv,
  columnMappingObject
} = require("./csvImport");
const { importParadigmaiBundle, PARADIGMAI_CSV_NAME } = require("./paradigmaiImport");

const MAX_CSV_BYTES = 10 * 1024 * 1024;

const IMPORT_MAPPING_SYSTEM = `You map CSV column headers to Cadence CRM contact import fields for health insurance agents.

Rules:
- Return JSON: { "mappings": [ { "header": "exact CSV header", "field": "field_key or empty string", "confidence": "auto" or "review" } ] }
- Use only these field keys: ${CADENCE_CONTACT_FIELDS.map((f) => f.key).join(", ")}
- Map name variants intelligently: "First", "fname", "Contact Name" → first_name or full_name as appropriate
- Use confidence "auto" when the mapping is obvious; "review" when uncertain
- Use empty field with confidence skipped only if the column is junk (Row #, internal ID with no meaning, blank header)
- Never map two different headers to the same field unless they are true duplicates
- Prefer full_name for a single combined name column; use first_name + last_name when split columns exist`;

function assertCsvSize(csv) {
  if (Buffer.byteLength(csv, "utf8") > MAX_CSV_BYTES) {
    const err = new Error("CSV file is too large (max 10 MB).");
    err.statusCode = 413;
    throw err;
  }
}

async function suggestMappingsWithAi(headers, rows) {
  const staticOnly = buildStaticColumnMappings(headers);
  const unmapped = staticOnly.filter((m) => !m.field);
  if (!unmapped.length) {
    return { mappings: staticOnly, aiUsed: false };
  }

  const { configured } = getClaudeConfig();
  if (!configured) {
    return { mappings: staticOnly, aiUsed: false, aiUnavailable: true };
  }

  const unmappedHeaders = new Set(unmapped.map((m) => String(m.header || "").trim().toLowerCase()));
  const columns = getSampleValuesForHeaders(headers, rows, 3).filter((col) =>
    unmappedHeaders.has(String(col.header || "").trim().toLowerCase())
  );

  try {
    const payload = await callClaudeJson({
      system: IMPORT_MAPPING_SYSTEM,
      user: `Map these CSV columns to Cadence fields:\n${JSON.stringify(columns, null, 2)}`,
      maxTokens: Math.min(4096, 320 + columns.length * 90)
    });

    const mappings = mergeColumnMappings(headers, payload?.mappings);
    return { mappings, aiUsed: true };
  } catch (error) {
    console.warn("[import] AI column mapping failed, using static aliases:", error.message || error);
    return {
      mappings: staticOnly,
      aiUsed: false,
      aiUnavailable: true,
      aiError: String(error.message || "AI mapping failed")
    };
  }
}

function registerImportRoutes(
  app,
  { createRateLimiter, run, get, scheduleAutoLeadScore, dbDeps, isOwnerWorkspaceSession } = {}
) {
  const limiter = createRateLimiter
    ? createRateLimiter({ windowMs: 60_000, max: 15, label: "import-csv-ai" })
    : (_req, _res, next) => next();

  app.get("/api/contacts/import-csv/fields", (_req, res) => {
    return res.json({ fields: CADENCE_CONTACT_FIELDS });
  });

  app.post("/api/contacts/import-csv/suggest-mapping", limiter, async (req, res) => {
    try {
      const csv = String(req.body?.csv || "");
      if (!csv.trim()) return res.status(400).json({ error: "csv string is required." });
      assertCsvSize(csv);

      const { headers, rows } = parseCsv(csv);
      if (!headers.length) return res.status(400).json({ error: "CSV has no header row." });

      const { mappings, aiUsed, aiUnavailable, aiError } = await suggestMappingsWithAi(headers, rows);
      const columns = getSampleValuesForHeaders(headers, rows, 3);
      const samplesByHeader = new Map(columns.map((c) => [c.header.toLowerCase(), c.samples]));
      const enriched = mappings.map((m) => ({
        ...m,
        samples: samplesByHeader.get(String(m.header || "").toLowerCase()) || []
      }));
      return res.json({
        mappings: enriched,
        fields: CADENCE_CONTACT_FIELDS,
        totalRows: rows.length,
        aiUsed,
        aiUnavailable: Boolean(aiUnavailable),
        aiError: aiError || null,
        hasNameColumn: mappingHasNameColumn(mappings)
      });
    } catch (error) {
      const status = Number(error.statusCode) || 500;
      return res.status(status).json({ error: error.message || "Could not suggest column mapping." });
    }
  });

  app.post("/api/contacts/import-paradigmai-bundle", async (req, res) => {
    try {
      if (typeof isOwnerWorkspaceSession === "function" && !isOwnerWorkspaceSession(req)) {
        return res.status(403).json({ error: "Paradigmai import is only available on the main operator workspace." });
      }
      if (!run || !get) {
        return res.status(500).json({ error: "Import not configured on server." });
      }
      const result = await importParadigmaiBundle({
        run,
        get,
        scheduleAutoLeadScore,
        dbDeps,
        skipDuplicates: req.body?.skipDuplicates !== false
      });
      return res.status(201).json({
        ok: true,
        source: PARADIGMAI_CSV_NAME,
        ...result,
        message: `Imported ${result.imported} Paradigmai contact(s).${
          result.skipped ? ` Skipped ${result.skipped} duplicate(s) already in your workspace.` : ""
        }`
      });
    } catch (error) {
      return res.status(500).json({ error: error.message || "Paradigmai import failed." });
    }
  });

  app.post("/api/contacts/import-csv/preview", async (req, res) => {
    try {
      const csv = String(req.body?.csv || "");
      const mappings = Array.isArray(req.body?.mappings) ? req.body.mappings : [];
      if (!csv.trim()) return res.status(400).json({ error: "csv string is required." });
      assertCsvSize(csv);

      const columnMapping = columnMappingObject(mappings);
      const result = previewContactsCsv(csv, columnMapping, 3);
      return res.json({
        ...result,
        hasNameColumn: mappingHasNameColumn(mappings)
      });
    } catch (error) {
      return res.status(500).json({ error: error.message || "Could not preview import." });
    }
  });
}

module.exports = { registerImportRoutes, MAX_CSV_BYTES };
