"use strict";

const crypto = require("crypto");

/** Stored format: hexSalt:hexScryptDigest (64-byte digest). */
function hashLoginPassword(plain) {
  const pw = String(plain || "");
  const salt = crypto.randomBytes(16);
  const derived = crypto.scryptSync(pw, salt, 64);
  return `${salt.toString("hex")}:${derived.toString("hex")}`;
}

function verifyLoginPassword(plain, stored) {
  const raw = String(stored || "").trim();
  const idx = raw.indexOf(":");
  if (idx <= 0) return false;
  const saltHex = raw.slice(0, idx);
  const wantHex = raw.slice(idx + 1);
  let salt;
  let want;
  try {
    salt = Buffer.from(saltHex, "hex");
    want = Buffer.from(wantHex, "hex");
  } catch {
    return false;
  }
  if (!salt.length || !want.length) return false;
  let derived;
  try {
    derived = crypto.scryptSync(String(plain || ""), salt, want.length);
  } catch {
    return false;
  }
  if (derived.length !== want.length) return false;
  return crypto.timingSafeEqual(derived, want);
}

function generateTempPassword() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
  let out = "";
  const bytes = crypto.randomBytes(12);
  for (let i = 0; i < 12; i++) out += chars[bytes[i] % chars.length];
  return out;
}

module.exports = { hashLoginPassword, verifyLoginPassword, generateTempPassword };
