"use strict";

const crypto = require("crypto");

const ANCHOR_HREF_RE = /<a\b[^>]*?\shref\s*=\s*(["'])([^"']*)\1/gi;

function shouldWrapClickLink(href, publicOrigin) {
  const url = String(href || "").trim();
  if (!url) return false;
  if (/^mailto:/i.test(url)) return false;
  if (/^tel:/i.test(url)) return false;
  if (/^#/.test(url)) return false;
  if (!/^https?:\/\//i.test(url)) return false;
  if (/\/api\/email\/(open|click)\//i.test(url)) return false;
  if (/\/api\/email\/unsubscribe/i.test(url)) return false;
  if (/\/email-unsubscribe\.html/i.test(url)) return false;
  const origin = String(publicOrigin || "").trim().replace(/\/$/, "");
  if (origin && url.toLowerCase().startsWith(`${origin.toLowerCase()}/api/email/`)) return false;
  return true;
}

function buildClickTrackUrl(publicOrigin, token) {
  const base = String(publicOrigin || "").trim().replace(/\/$/, "");
  if (!base) return "";
  return `${base}/api/email/click/${encodeURIComponent(String(token || "").trim())}`;
}

async function wrapEmailLinksForClickTracking(options = {}) {
  const {
    html,
    publicOrigin,
    run,
    contactIds = "",
    toEmails = "",
    subject = "",
    openToken = "",
    tag = ""
  } = options;
  const body = String(html || "");
  const origin = String(publicOrigin || "").trim().replace(/\/$/, "");
  if (!body || !origin || typeof run !== "function") return body;

  const matches = [];
  let match;
  const re = new RegExp(ANCHOR_HREF_RE.source, "gi");
  while ((match = re.exec(body)) !== null) {
    const href = match[2];
    if (!shouldWrapClickLink(href, origin)) continue;
    matches.push({
      index: match.index,
      full: match[0],
      quote: match[1],
      href
    });
  }
  if (!matches.length) return body;

  const replacements = [];
  for (const item of matches) {
    const clickToken = crypto.randomBytes(24).toString("hex");
    const trackUrl = buildClickTrackUrl(origin, clickToken);
    if (!trackUrl) continue;
    await run(
      `INSERT INTO email_click_tracking (click_token, open_token, contact_ids, to_emails, subject, link_url, tag)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        clickToken,
        String(openToken || ""),
        String(contactIds || ""),
        String(toEmails || ""),
        String(subject || ""),
        item.href,
        String(tag || "")
      ]
    );
    const updated = item.full.replace(
      `href=${item.quote}${item.href}${item.quote}`,
      `href=${item.quote}${trackUrl}${item.quote}`
    );
    replacements.push({ index: item.index, length: item.full.length, updated });
  }
  if (!replacements.length) return body;

  let out = body;
  for (const r of replacements.sort((a, b) => b.index - a.index)) {
    out = `${out.slice(0, r.index)}${r.updated}${out.slice(r.index + r.length)}`;
  }
  return out;
}

async function resolveEmailClickTrackingToken(deps, token) {
  const { get, platformAll, openTenantDatabase, withTenantContext, LEGACY_TENANT_ID } = deps;
  const cleanToken = String(token || "").trim();
  if (!cleanToken) return null;
  const tenantIds = [LEGACY_TENANT_ID];
  try {
    const tenantRows = await platformAll(`SELECT id FROM tenants WHERE id != ? ORDER BY id ASC`, [LEGACY_TENANT_ID]);
    for (const row of Array.isArray(tenantRows) ? tenantRows : []) {
      const tenantId = Number(row?.id);
      if (Number.isInteger(tenantId) && tenantId > 0 && tenantId !== LEGACY_TENANT_ID) {
        tenantIds.push(tenantId);
      }
    }
  } catch {
    // ignore tenant lookup errors
  }
  for (const tenantId of tenantIds) {
    try {
      if (tenantId !== LEGACY_TENANT_ID) await openTenantDatabase(tenantId);
      const row = await withTenantContext(tenantId, () =>
        get(`SELECT * FROM email_click_tracking WHERE click_token = ?`, [cleanToken])
      );
      if (row) return { tenantId, row };
    } catch {
      // keep searching
    }
  }
  return null;
}

async function recordEmailClickAndGetDestination(deps, token) {
  const { run, logContactActivity } = deps;
  const resolved = await resolveEmailClickTrackingToken(deps, token);
  if (!resolved) return null;
  const { tenantId, row } = resolved;
  return deps.withTenantContext(tenantId, async () => {
    const nowUnix = Math.floor(Date.now() / 1000);
    const firstContactId = Number(String(row.contact_ids || "").split(",")[0]) || 0;
    const toEmail = String(row.to_emails || "")
      .split(",")
      .map((v) => v.trim())
      .filter(Boolean)[0] || "";
    await run(
      `INSERT INTO email_click_events (contact_id, to_email, subject, link_url, open_token, tag, clicked_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        firstContactId,
        toEmail,
        String(row.subject || ""),
        String(row.link_url || ""),
        String(row.open_token || ""),
        String(row.tag || ""),
        nowUnix
      ]
    );
    const subjectLabel = String(row.subject || "(no subject)").trim() || "(no subject)";
    const linkLabel = String(row.link_url || "").trim() || "(link)";
    const clickedAtLabel = new Date(nowUnix * 1000).toLocaleString();
    const contactIds = [
      ...new Set(
        String(row.contact_ids || "")
          .split(",")
          .map((v) => Number(String(v || "").trim()))
          .filter((n) => Number.isInteger(n) && n > 0)
      )
    ];
    if (typeof logContactActivity === "function") {
      for (const contactId of contactIds) {
        await logContactActivity(
          contactId,
          "email",
          `Email Clicked\nSubject: ${subjectLabel}\nLink: ${linkLabel}\nClicked At: ${clickedAtLabel}`
        );
      }
    }
    return String(row.link_url || "").trim() || null;
  });
}

module.exports = {
  wrapEmailLinksForClickTracking,
  recordEmailClickAndGetDestination,
  resolveEmailClickTrackingToken
};
