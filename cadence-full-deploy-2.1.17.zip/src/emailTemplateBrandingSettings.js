"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { toRelativeUploadPath, uploadsRootDir } = require("./uploadPaths");

const SETTING_KEY = "email_template_branding_v1";
const BRANDING_SUBDIR = "branding";
const MAX_PHOTO_BYTES = 5 * 1024 * 1024;

function randomToken() {
  return crypto.randomBytes(24).toString("hex");
}

function normalizeSettings(raw) {
  const src = raw && typeof raw === "object" ? raw : {};
  return {
    enabled: src.enabled === true,
    companyName: String(src.companyName || "").trim(),
    photoPath: String(src.photoPath || "").trim(),
    photoMimeType: String(src.photoMimeType || "image/jpeg").trim() || "image/jpeg",
    photoToken: String(src.photoToken || "").trim()
  };
}

async function readSetting(get, key) {
  const row = await get(`SELECT value FROM crm_app_settings WHERE key = ?`, [key]);
  return row ? String(row.value || "") : "";
}

async function writeSetting(run, key, value) {
  await run(`INSERT OR REPLACE INTO crm_app_settings (key, value) VALUES (?, ?)`, [key, String(value || "")]);
}

async function ensureBrandingTokenTable(platformRun) {
  await platformRun(`
    CREATE TABLE IF NOT EXISTS email_agent_branding_tokens (
      token TEXT PRIMARY KEY,
      tenant_id INTEGER NOT NULL,
      updated_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
    )
  `);
  await platformRun(`
    CREATE INDEX IF NOT EXISTS idx_email_agent_branding_tokens_tenant
    ON email_agent_branding_tokens (tenant_id)
  `);
}

function brandingDirForTenant(tenantId) {
  return path.join(uploadsRootDir, BRANDING_SUBDIR, String(tenantId));
}

function resolveBrandingPhotoDisk(photoPath) {
  const rel = String(photoPath || "")
    .trim()
    .replace(/\\/g, "/")
    .replace(/^uploads\/?/i, "");
  if (!rel) return "";
  const disk = path.join(uploadsRootDir, rel);
  return fs.existsSync(disk) ? disk : "";
}

function publicPhotoUrl(req, photoToken) {
  const token = String(photoToken || "").trim();
  if (!token) return "";
  const proto = String(req.get("x-forwarded-proto") || req.protocol || "https")
    .split(",")[0]
    .trim();
  const host = String(req.get("x-forwarded-host") || req.get("host") || "").split(",")[0].trim();
  if (!host) return `/api/public/agent-branding-photo/${encodeURIComponent(token)}`;
  return `${proto}://${host}/api/public/agent-branding-photo/${encodeURIComponent(token)}`;
}

async function getEmailTemplateBrandingSettings(get) {
  const raw = await readSetting(get, SETTING_KEY);
  if (!raw) return normalizeSettings({});
  try {
    return normalizeSettings(JSON.parse(raw));
  } catch {
    return normalizeSettings({});
  }
}

async function saveEmailTemplateBrandingSettings(run, get, incoming) {
  const existing = await getEmailTemplateBrandingSettings(get);
  const body = incoming && typeof incoming === "object" ? incoming : {};
  const next = normalizeSettings({
    ...existing,
    enabled: Object.prototype.hasOwnProperty.call(body, "enabled") ? body.enabled === true : existing.enabled,
    companyName: Object.prototype.hasOwnProperty.call(body, "companyName")
      ? body.companyName
      : existing.companyName
  });
  if ((next.companyName || next.photoPath) && !Object.prototype.hasOwnProperty.call(body, "enabled")) {
    next.enabled = true;
  }
  await writeSetting(run, SETTING_KEY, JSON.stringify(next));
  return next;
}

async function upsertPhotoToken(platformRun, tenantId, token) {
  const t = String(token || "").trim();
  if (!t) return;
  await platformRun(
    `INSERT INTO email_agent_branding_tokens (token, tenant_id, updated_at)
     VALUES (?, ?, CAST(strftime('%s','now') AS INTEGER))
     ON CONFLICT(token) DO UPDATE SET tenant_id = excluded.tenant_id, updated_at = excluded.updated_at`,
    [t, Number(tenantId)]
  );
}

async function saveAgentPhoto(run, get, platformRun, tenantId, { contentBase64, mimeType, fileName }) {
  const b64 = String(contentBase64 || "").trim();
  if (!b64) throw new Error("Photo data is required.");
  const buffer = Buffer.from(b64, "base64");
  if (!buffer.length) throw new Error("Photo file is empty.");
  if (buffer.length > MAX_PHOTO_BYTES) throw new Error("Photo too large (max 5MB).");

  const extFromMime = {
    "image/jpeg": ".jpg",
    "image/jpg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
    "image/gif": ".gif"
  };
  const mime = String(mimeType || "image/jpeg").trim().toLowerCase();
  const ext = extFromMime[mime] || path.extname(String(fileName || "")) || ".jpg";

  const dir = brandingDirForTenant(tenantId);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  const storedName = `agent-photo${ext}`;
  const diskPath = path.join(dir, storedName);
  fs.writeFileSync(diskPath, buffer);

  const existing = await getEmailTemplateBrandingSettings(get);
  let photoToken = existing.photoToken;
  if (!photoToken) photoToken = randomToken();

  const photoPath = toRelativeUploadPath(`${BRANDING_SUBDIR}/${tenantId}`, storedName);
  const next = normalizeSettings({
    ...existing,
    enabled: existing.enabled || true,
    photoPath,
    photoMimeType: mime,
    photoToken
  });
  await writeSetting(run, SETTING_KEY, JSON.stringify(next));
  await upsertPhotoToken(platformRun, tenantId, photoToken);
  return next;
}

async function removeAgentPhoto(run, get, platformRun, tenantId) {
  const existing = await getEmailTemplateBrandingSettings(get);
  const disk = resolveBrandingPhotoDisk(existing.photoPath);
  if (disk && fs.existsSync(disk)) {
    try {
      fs.unlinkSync(disk);
    } catch {
      /* ignore */
    }
  }
  if (existing.photoToken) {
    await platformRun(`DELETE FROM email_agent_branding_tokens WHERE token = ?`, [existing.photoToken]);
  }
  const next = normalizeSettings({
    ...existing,
    photoPath: "",
    photoMimeType: "image/jpeg",
    photoToken: ""
  });
  await writeSetting(run, SETTING_KEY, JSON.stringify(next));
  return next;
}

function settingsForClient(req, settings) {
  const s = normalizeSettings(settings);
  const hasPhoto = Boolean(s.photoPath && s.photoToken);
  const photoUrl = hasPhoto ? publicPhotoUrl(req, s.photoToken) : "";
  return {
    enabled: s.enabled,
    companyName: s.companyName,
    photoUrl,
    hasPhoto
  };
}

function registerEmailTemplateBrandingRoutes(app, {
  run,
  get,
  platformRun,
  platformGet,
  openTenantDatabase,
  withTenantContext,
  getAuthSession
}) {
  ensureBrandingTokenTable(platformRun).catch((err) => {
    console.warn("[email-template-branding] token table init:", err.message || err);
  });

  app.get("/api/public/agent-branding-photo/:token", async (req, res) => {
    try {
      const token = String(req.params.token || "").trim();
      if (!token || token.length < 16) return res.status(404).end();

      const row = await platformGet(
        `SELECT tenant_id AS tenantId FROM email_agent_branding_tokens WHERE token = ?`,
        [token]
      );
      if (!row?.tenantId) return res.status(404).end();

      await openTenantDatabase(row.tenantId);
      await withTenantContext(row.tenantId, async () => {
        const settings = await getEmailTemplateBrandingSettings(get);
        if (!settings.photoPath) return res.status(404).end();
        const disk = resolveBrandingPhotoDisk(settings.photoPath);
        if (!disk || !fs.existsSync(disk)) return res.status(404).end();
        res.setHeader("Content-Type", settings.photoMimeType || "image/jpeg");
        res.setHeader("Cache-Control", "public, max-age=86400");
        return res.sendFile(disk);
      });
    } catch (err) {
      console.error("[email-template-branding] public photo:", err.message || err);
      return res.status(500).end();
    }
  });

  app.get("/api/email/template-branding", async (req, res) => {
    try {
      const session = getAuthSession(req);
      if (!session?.tenantId) return res.status(401).json({ error: "Not authenticated." });
      let settings = await getEmailTemplateBrandingSettings(get);
      if ((settings.photoPath || settings.companyName) && !settings.enabled) {
        settings = normalizeSettings({ ...settings, enabled: true });
        await writeSetting(run, SETTING_KEY, JSON.stringify(settings));
        if (settings.photoPath && settings.photoToken) {
          await upsertPhotoToken(platformRun, session.tenantId, settings.photoToken);
        }
      }
      res.json(settingsForClient(req, settings));
    } catch (error) {
      res.status(500).json({ error: error.message || "Failed to load template branding settings" });
    }
  });

  app.put("/api/email/template-branding", async (req, res) => {
    try {
      const session = getAuthSession(req);
      if (!session?.tenantId) return res.status(401).json({ error: "Not authenticated." });
      const saved = await saveEmailTemplateBrandingSettings(run, get, req.body || {});
      if (saved.enabled && saved.photoPath && saved.photoToken) {
        await upsertPhotoToken(platformRun, session.tenantId, saved.photoToken);
      }
      res.json(settingsForClient(req, saved));
    } catch (error) {
      res.status(500).json({ error: error.message || "Failed to save template branding settings" });
    }
  });

  app.post("/api/email/template-branding/photo", async (req, res) => {
    try {
      const session = getAuthSession(req);
      if (!session?.tenantId) return res.status(401).json({ error: "Not authenticated." });
      const saved = await saveAgentPhoto(run, get, platformRun, session.tenantId, req.body || {});
      res.json(settingsForClient(req, saved));
    } catch (error) {
      res.status(400).json({ error: error.message || "Failed to upload photo" });
    }
  });

  app.delete("/api/email/template-branding/photo", async (req, res) => {
    try {
      const session = getAuthSession(req);
      if (!session?.tenantId) return res.status(401).json({ error: "Not authenticated." });
      const saved = await removeAgentPhoto(run, get, platformRun, session.tenantId);
      res.json(settingsForClient(req, saved));
    } catch (error) {
      res.status(500).json({ error: error.message || "Failed to remove photo" });
    }
  });
}

module.exports = {
  SETTING_KEY,
  getEmailTemplateBrandingSettings,
  saveEmailTemplateBrandingSettings,
  registerEmailTemplateBrandingRoutes,
  publicPhotoUrl,
  settingsForClient
};
