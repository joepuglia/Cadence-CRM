"use strict";

const crypto = require("crypto");

const ALGO = "aes-256-gcm";
const PREFIX = "enc:v1:";

function getKey() {
  const raw = String(process.env.BANK_FIELD_ENCRYPTION_KEY || "").trim();
  if (!raw) return null;
  if (/^[0-9a-f]{64}$/i.test(raw)) return Buffer.from(raw, "hex");
  const buf = Buffer.from(raw, "base64");
  return buf.length === 32 ? buf : null;
}

function encryptField(plaintext) {
  if (plaintext == null || plaintext === "") return plaintext;
  const key = getKey();
  if (!key) return plaintext;
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGO, key, iv);
  const enc = Buffer.concat([cipher.update(String(plaintext), "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${PREFIX}${iv.toString("hex")}:${tag.toString("hex")}:${enc.toString("hex")}`;
}

function decryptField(value) {
  if (!value || !String(value).startsWith(PREFIX)) return value;
  const key = getKey();
  if (!key) return "[encrypted — set BANK_FIELD_ENCRYPTION_KEY to view]";
  try {
    const parts = String(value).slice(PREFIX.length).split(":");
    if (parts.length !== 3) return "[encrypted — invalid format]";
    const iv = Buffer.from(parts[0], "hex");
    const tag = Buffer.from(parts[1], "hex");
    const data = Buffer.from(parts[2], "hex");
    const decipher = crypto.createDecipheriv(ALGO, key, iv);
    decipher.setAuthTag(tag);
    return decipher.update(data) + decipher.final("utf8");
  } catch {
    return "[encrypted — decryption failed]";
  }
}

function decryptContactBankFields(contact) {
  if (!contact) return contact;
  return {
    ...contact,
    bank_routing: decryptField(contact.bank_routing),
    bank_account: decryptField(contact.bank_account)
  };
}

module.exports = { encryptField, decryptField, decryptContactBankFields };
