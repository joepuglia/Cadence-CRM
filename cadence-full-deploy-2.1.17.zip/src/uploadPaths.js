"use strict";

const fs = require("fs");
const path = require("path");

const uploadsRootDir = path.join(__dirname, "..", "uploads");

/** Portable key stored in SQLite, e.g. `social/1234_photo.jpg` */
function toRelativeUploadPath(subdir, fileOrName) {
  const sub = String(subdir || "")
    .trim()
    .replace(/^\/+|\/+$/g, "");
  const name =
    typeof fileOrName === "string"
      ? path.basename(fileOrName.replace(/\\/g, "/"))
      : path.basename(String(fileOrName?.filename || fileOrName?.path || "").replace(/\\/g, "/"));
  if (!sub || !name) return "";
  return `${sub}/${name}`;
}

/**
 * Resolve a row's storage_path to an absolute file on this server.
 * Handles legacy Windows/Linux absolute paths saved before portable keys.
 */
function findUploadByHint(subdir, hintFileName) {
  const sub = String(subdir || "")
    .trim()
    .replace(/^\/+|\/+$/g, "");
  const hint = path.basename(String(hintFileName || "").replace(/\\/g, "/"));
  if (!sub || !hint) return "";

  const dir = path.join(uploadsRootDir, sub);
  if (!fs.existsSync(dir)) return "";

  let entries;
  try {
    entries = fs.readdirSync(dir);
  } catch {
    return "";
  }

  const exact = entries.find((name) => name === hint);
  if (exact) return path.join(dir, exact);

  const suffix = entries.find((name) => name.endsWith(`_${hint}`));
  if (suffix) return path.join(dir, suffix);

  const contains = entries.find((name) => name.includes(hint));
  if (contains) return path.join(dir, contains);

  return "";
}

function resolveStoredUploadPath(storagePath, subdir, hintFileName) {
  const raw = String(storagePath || "").trim();
  if (!raw) {
    return findUploadByHint(subdir, hintFileName);
  }

  if (fs.existsSync(raw)) {
    return path.resolve(raw);
  }

  const norm = raw.replace(/\\/g, "/");
  const fileName = path.basename(norm);
  const sub = String(subdir || "")
    .trim()
    .replace(/^\/+|\/+$/g, "");
  const candidates = [];

  if (norm.includes("/") && !path.isAbsolute(raw)) {
    candidates.push(path.join(uploadsRootDir, norm));
    candidates.push(path.join(uploadsRootDir, norm.replace(/^uploads\/?/i, "")));
    candidates.push(path.join(__dirname, "..", norm));
  }

  if (sub && fileName) {
    candidates.push(path.join(uploadsRootDir, sub, fileName));
    candidates.push(path.join(uploadsRootDir, fileName));
  }

  if (/^[a-zA-Z]:[/\\]/.test(raw) || raw.startsWith("\\\\")) {
    if (sub && fileName) candidates.push(path.join(uploadsRootDir, sub, fileName));
  }

  const seen = new Set();
  for (const candidate of candidates) {
    const abs = path.resolve(candidate);
    if (seen.has(abs)) continue;
    seen.add(abs);
    if (fs.existsSync(abs)) return abs;
  }

  const hinted = findUploadByHint(subdir, hintFileName || fileName);
  if (hinted) return hinted;

  return findUploadAnywhere(hintFileName || fileName);
}

function findUploadAnywhere(hintFileName) {
  const hint = path.basename(String(hintFileName || "").replace(/\\/g, "/"));
  if (!hint || !fs.existsSync(uploadsRootDir)) return "";

  function walk(dir) {
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return "";
    }
    for (const ent of entries) {
      const full = path.join(dir, ent.name);
      if (ent.isFile()) {
        if (ent.name === hint || ent.name.endsWith(`_${hint}`) || ent.name.includes(hint)) {
          return full;
        }
      } else if (ent.isDirectory()) {
        const nested = walk(full);
        if (nested) return nested;
      }
    }
    return "";
  }

  return walk(uploadsRootDir);
}

function portableStorageKey(subdir, absolutePath) {
  const sub = String(subdir || "")
    .trim()
    .replace(/^\/+|\/+$/g, "");
  const fileName = path.basename(String(absolutePath || "").replace(/\\/g, "/"));
  if (!sub || !fileName) return "";
  return `${sub}/${fileName}`;
}

module.exports = {
  uploadsRootDir,
  toRelativeUploadPath,
  resolveStoredUploadPath,
  findUploadByHint,
  findUploadAnywhere,
  portableStorageKey
};
