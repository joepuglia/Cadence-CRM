/** Digits-only key for sorting E.164 / phone strings numerically. */
function twilioPhoneDigits(e164) {
  return String(e164 || "").replace(/\D/g, "") || "0";
}

function compareTwilioPhoneNumbers(a, b) {
  const da = twilioPhoneDigits(a);
  const db = twilioPhoneDigits(b);
  if (da.length !== db.length) return da.length - db.length;
  if (da < db) return -1;
  if (da > db) return 1;
  return 0;
}

/** @param {{ number?: string, line?: string }[]} entries */
function sortTwilioFromEntries(entries) {
  const lineOrder = { primary: 0, secondary: 1, third: 2, custom: 3 };
  return [...entries].sort((a, b) => {
    const cmp = compareTwilioPhoneNumbers(a.number, b.number);
    if (cmp !== 0) return cmp;
    return (lineOrder[a.line] ?? 9) - (lineOrder[b.line] ?? 9);
  });
}

function sortCustomTwilioRows(rows) {
  return [...rows].sort((a, b) =>
    compareTwilioPhoneNumbers(a.number || a.phone_number, b.number || b.phone_number)
  );
}

module.exports = {
  twilioPhoneDigits,
  compareTwilioPhoneNumbers,
  sortTwilioFromEntries,
  sortCustomTwilioRows
};
