const {
  EMAIL_SYSTEM,
  SMS_SYSTEM,
  AUTOMATION_SYSTEM,
  PIPELINE_SYSTEM,
  OBJECTION_COACH_SYSTEM,
  CALL_SCRIPT_SYSTEM,
  FOLLOW_UP_SEQUENCE_SYSTEM,
  PLAN_COMPARISON_SYSTEM,
  VOICEMAIL_SYSTEM,
  TONE_LABELS
} = require("./assistantPrompts");
const {
  callClaudeText,
  getClaudeConfig,
  isClaudeUsageLimitError,
  CLAUDE_USAGE_LIMIT_MESSAGE
} = require("./claudeClient");
const { sqlExcludeInitialImportTags } = require("./initialImportOmit");

const CLOSED_LOST_OUTCOMES = [
  "bad email",
  "bad number",
  "cannot afford",
  "cannot insure",
  "declined",
  "dnc",
  "employer plan",
  "fake lead",
  "has coverage",
  "no contact",
  "not interested",
  "rude",
  "stop",
  "stopped responding",
  "too many calls",
  "wrong number"
];

function formatClaudeError(data, response) {
  const raw = String(data?.error?.message || (typeof data?.error === "string" ? data.error : "") || "").trim();
  const code = String(data?.error?.type || "").trim().toLowerCase();
  if (isClaudeUsageLimitError(raw, code, response?.status)) {
    return CLAUDE_USAGE_LIMIT_MESSAGE;
  }
  if (response?.status === 401 || /authentication|invalid.*api.*key/i.test(raw)) {
    return "Invalid Claude API key on this server. Ask your CRM administrator to update it.";
  }
  return raw || (response?.status === 401 ? "Invalid Claude API key." : "Claude request failed.");
}

function stripJsonFences(text) {
  const trimmed = String(text || "").trim();
  const fenced = trimmed.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
  return fenced ? String(fenced[1] || "").trim() : trimmed;
}

function escapeHtmlText(text) {
  return String(text || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function textToSimpleHtml(text) {
  return String(text || "")
    .split(/\n\s*\n/)
    .map((part) => part.trim())
    .filter(Boolean)
    .map((part) => `<p>${escapeHtmlText(part.replace(/\n/g, " "))}</p>`)
    .join("");
}

function decodeBasicEntities(text) {
  return String(text || "")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'");
}

function stripHtmlForPrompt(text) {
  return decodeBasicEntities(text)
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ");
}

function compactText(text, max = 500) {
  const out = stripHtmlForPrompt(text)
    .replace(/\{[\s\S]{1200,}\}/g, " ")
    .replace(/\[[\s\S]{1200,}\]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (out.length <= max) return out;
  return `${out.slice(0, max).trim()}...`;
}

function cleanGeneratedEmailBody(text, max = 1800) {
  let out = stripHtmlForPrompt(text)
    .replace(/^Body:\s*/i, "")
    .replace(/\r\n/g, "\n")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
  if (out.length > max) out = `${out.slice(0, max).trim()}...`;
  return out;
}

function safeJsonParse(raw) {
  try {
    return JSON.parse(String(raw || ""));
  } catch {
    return null;
  }
}

function pickFirstString(obj, keys) {
  if (!obj || typeof obj !== "object") return "";
  for (const key of keys) {
    const value = obj[key];
    if (typeof value === "string" && value.trim()) return value;
  }
  return "";
}

function summarizeActivityDetail(typeRaw, detailRaw) {
  const type = String(typeRaw || "activity").trim().toLowerCase();
  const parsed = safeJsonParse(detailRaw);
  if (parsed && typeof parsed === "object") {
    if (type === "email") {
      const subject = compactText(pickFirstString(parsed, ["subject", "emailSubject", "title"]), 90);
      const body = compactText(pickFirstString(parsed, ["body", "text", "message", "html", "detail"]), 180);
      return [subject && `subject: ${subject}`, body && `body: ${body}`].filter(Boolean).join("; ");
    }
    if (type === "sms") {
      return compactText(pickFirstString(parsed, ["body", "message", "text", "detail"]), 180);
    }
    if (type === "call" || type === "ai_call_summary") {
      return compactText(pickFirstString(parsed, ["summary", "notes", "transcript", "detail"]), 220);
    }
    return compactText(Object.entries(parsed).slice(0, 4).map(([key, value]) => `${key}: ${String(value)}`).join("; "), 220);
  }
  return compactText(detailRaw, 220);
}

function parseEmailDraft(raw) {
  const text = stripJsonFences(raw);
  const subjectMatch = text.match(/^Subject:\s*(.+)$/im);
  const subject = subjectMatch ? String(subjectMatch[1] || "").trim() : "";
  const body = subjectMatch
    ? text.slice(subjectMatch.index + subjectMatch[0].length).trim()
    : text;
  const cleanedBody = cleanGeneratedEmailBody(body);
  return {
    subject,
    text: cleanedBody,
    html: textToSimpleHtml(cleanedBody)
  };
}

function stripSmsCharSuffix(text) {
  return String(text || "")
    .replace(/\[\s*\d+\s*characters?\s*]\s*$/i, "")
    .trim();
}

function smsCharCountFromBlock(text) {
  const match = String(text || "").match(/\[\s*(\d+)\s*characters?\s*]\s*$/i);
  if (match) return Number(match[1]);
  return stripSmsCharSuffix(text).length;
}

function parseSmsDraft(raw) {
  const text = stripJsonFences(raw);
  const message1Match = text.match(/Message\s*1:\s*([\s\S]*?)(?=Message\s*2:|$)/i);
  const message2Match = text.match(/Message\s*2:\s*([\s\S]*?)$/i);
  let message = "";
  let message2 = "";
  if (message1Match) {
    message = stripSmsCharSuffix(message1Match[1]);
    if (message2Match) message2 = stripSmsCharSuffix(message2Match[1]);
  } else {
    message = stripSmsCharSuffix(text);
  }
  const characterCount = message1Match ? smsCharCountFromBlock(message1Match[1]) : smsCharCountFromBlock(text);
  const characterCount2 = message2 ? (message2Match ? smsCharCountFromBlock(message2Match[1]) : message2.length) : 0;
  return {
    message,
    message2,
    characterCount,
    characterCount2,
    isTwoPart: Boolean(message2)
  };
}

function extractAutomationField(block, label) {
  const re = new RegExp(
    `${label}:\\s*([\\s\\S]*?)(?=\\n(?:TRIGGER|ACTION|PURPOSE|HOW TO SET IT UP|SETUP):|$)`,
    "i"
  );
  const match = String(block || "").match(re);
  return match ? String(match[1] || "").trim() : "";
}

function parseAutomationIdeas(raw) {
  const text = stripJsonFences(raw);
  const blocks = text
    .split(/\n(?=\s*(?:\d+\.\s*)?TRIGGER:\s)/i)
    .map((part) => part.trim())
    .filter(Boolean);
  const ideas = blocks
    .map((block, index) => {
      const trigger = extractAutomationField(block, "TRIGGER");
      const action = extractAutomationField(block, "ACTION");
      const purpose = extractAutomationField(block, "PURPOSE");
      const setup =
        extractAutomationField(block, "HOW TO SET IT UP") || extractAutomationField(block, "SETUP");
      if (!trigger && !action && !purpose && !setup) return null;
      return {
        name: trigger ? trigger.slice(0, 72) : `Automation idea ${index + 1}`,
        trigger,
        action,
        purpose,
        setup
      };
    })
    .filter(Boolean)
    .slice(0, 5);
  return ideas;
}

function toneLabel(tone) {
  const key = String(tone || "professional")
    .trim()
    .toLowerCase();
  return TONE_LABELS[key] || TONE_LABELS.professional;
}

async function callClaudeChat({ system, user, maxTokens = 1400 }) {
  return callClaudeText({ system, user, maxTokens, temperature: 0.65 });
}

async function collectPipelineSnapshot(all, { pastDays = 7, futureDays = 14 } = {}) {
  const past = Number.isFinite(Number(pastDays)) && Number(pastDays) > 0 ? Math.floor(Number(pastDays)) : 7;
  const future = Number.isFinite(Number(futureDays)) && Number(futureDays) > 0 ? Math.floor(Number(futureDays)) : 14;
  const omitTags = sqlExcludeInitialImportTags();
  const omitTagsC = sqlExcludeInitialImportTags("c");

  const totalRow = await all(`SELECT COUNT(*) AS n FROM contacts`);
  const totalContacts = Number(totalRow?.[0]?.n || 0);

  const newLeadsRows = await all(
    `SELECT COUNT(*) AS n FROM contacts
     WHERE datetime(created_at) >= datetime('now', ?)
       AND ${omitTags}`,
    [`-${past} days`]
  );
  const newLeads = Number(newLeadsRows?.[0]?.n || 0);

  const soldRows = await all(
    `SELECT COUNT(*) AS n FROM contacts WHERE lower(trim(COALESCE(outcome, ''))) = 'sold'`
  );
  const closedSold = Number(soldRows?.[0]?.n || 0);

  const lostPlaceholders = CLOSED_LOST_OUTCOMES.map(() => "?").join(", ");
  const lostRows = await all(
    `SELECT COUNT(*) AS n FROM contacts
     WHERE lower(trim(COALESCE(outcome, ''))) IN (${lostPlaceholders})`,
    CLOSED_LOST_OUTCOMES
  );
  const closedLost = Number(lostRows?.[0]?.n || 0);

  const markedInPeriodSql = (outcomePredicate, extraParams = []) => {
    const params = [...extraParams, `-${past} days`, `-${past} days`];
    return all(
      `SELECT COUNT(*) AS n
       FROM contacts c
       WHERE ${outcomePredicate}
         AND (
           datetime(c.created_at) >= datetime('now', ?)
           OR EXISTS (
             SELECT 1 FROM contact_activity ca
             WHERE ca.contact_id = c.id
               AND lower(trim(COALESCE(ca.activity_type, ''))) = 'detail_change'
               AND datetime(ca.created_at) >= datetime('now', ?)
               AND lower(trim(COALESCE(ca.detail, ''))) LIKE 'outcome:%-> ' || lower(trim(COALESCE(c.outcome, '')))
           )
         )`,
      params
    );
  };

  const soldInPeriodRows = await markedInPeriodSql(`lower(trim(COALESCE(c.outcome, ''))) = 'sold'`);
  const closedSoldInPeriod = Number(soldInPeriodRows?.[0]?.n || 0);

  const lostInPeriodRows = await markedInPeriodSql(
    `lower(trim(COALESCE(c.outcome, ''))) IN (${lostPlaceholders})`,
    CLOSED_LOST_OUTCOMES
  );
  const closedLostInPeriod = Number(lostInPeriodRows?.[0]?.n || 0);

  const interestedRows = await all(
    `SELECT COUNT(*) AS n FROM contacts
     WHERE lower(replace(replace(trim(COALESCE(outcome, '')), '-', ''), ' ', '')) IN ('callback', 'veryinterested')`
  );
  const interested = Number(interestedRows?.[0]?.n || 0);

  const statusChanges = await all(
    `SELECT ca.contact_id, c.full_name, c.outcome, MAX(datetime(ca.created_at)) AS changed_at
     FROM contact_activity ca
     INNER JOIN contacts c ON c.id = ca.contact_id
     WHERE LOWER(COALESCE(ca.activity_type, '')) = 'detail_change'
       AND LOWER(COALESCE(ca.detail, '')) LIKE 'outcome:%'
       AND datetime(ca.created_at) >= datetime('now', ?)
     GROUP BY ca.contact_id, c.full_name, c.email, c.outcome
     ORDER BY datetime(changed_at) DESC
     LIMIT 12`,
    [`-${past} days`]
  );

  const scheduledTasks = await all(
    `SELECT c.full_name, c.outcome, t.task_name, t.task_date, t.task_time
     FROM contact_tasks t
     INNER JOIN contacts c ON c.id = t.contact_id
     WHERE lower(trim(COALESCE(t.condition, ''))) != 'completed'
       AND trim(COALESCE(t.task_date, '')) != ''
       AND date(t.task_date) >= date('now')
       AND date(t.task_date) <= date('now', ?)
     ORDER BY date(t.task_date) ASC, trim(COALESCE(t.task_time, '')) ASC
     LIMIT 12`,
    [`+${future} days`]
  );

  const closeRate =
    closedSoldInPeriod + closedLostInPeriod > 0
      ? Math.round((closedSoldInPeriod / (closedSoldInPeriod + closedLostInPeriod)) * 100)
      : null;

  const staleRows = await all(
    `SELECT COUNT(*) AS n
     FROM contacts c
     LEFT JOIN (
       SELECT contact_id, MAX(datetime(created_at)) AS last_at
       FROM contact_activity
       GROUP BY contact_id
     ) act ON act.contact_id = c.id
     WHERE lower(trim(COALESCE(c.status, ''))) = 'new'
       AND datetime(COALESCE(act.last_at, c.created_at)) < datetime('now', '-7 days')
       AND ${omitTagsC}`
  );
  const staleLeads = Number(staleRows?.[0]?.n || 0);

  const quotedRows = await all(
    `SELECT COUNT(*) AS n FROM contacts
     WHERE trim(COALESCE(quote, '')) != '' AND trim(COALESCE(quote, '')) != '0'`
  );
  const leadsQuoted = Number(quotedRows?.[0]?.n || 0);

  const activeCampaignRows = await all(
    `SELECT COUNT(DISTINCT campaign_id) AS n FROM drip_enrollments
     WHERE lower(trim(COALESCE(status, ''))) = 'active'`
  );
  const activeCampaigns = Number(activeCampaignRows?.[0]?.n || 0);

  const appointmentsScheduled = Array.isArray(scheduledTasks) ? scheduledTasks.length : 0;

  return {
    pastDays: past,
    futureDays: future,
    totalContacts,
    newLeads,
    closedSold,
    closedLost,
    closedSoldInPeriod,
    closedLostInPeriod,
    closeRate,
    interested,
    staleLeads,
    leadsQuoted,
    appointmentsScheduled,
    activeCampaigns,
    recentOutcomeChanges: Array.isArray(statusChanges) ? statusChanges : [],
    upcomingTasks: Array.isArray(scheduledTasks) ? scheduledTasks : []
  };
}

async function loadContactContextForAssistant(get, all, contactId) {
  const id = Number(contactId);
  if (!Number.isInteger(id) || id < 1) return null;
  const contact = await get(
    `SELECT id, full_name, email, phone, status, outcome, lead_source, state, notes, special_notes, tags, created_at
     FROM contacts WHERE id = ?`,
    [id]
  );
  if (!contact) return null;
  const history = await all(
    `SELECT activity_type, detail, created_at
     FROM contact_activity
     WHERE contact_id = ?
     ORDER BY datetime(created_at) DESC
     LIMIT 5`,
    [id]
  );
  const historyLines = (Array.isArray(history) ? history : []).map((row) => {
    const when = String(row.created_at || "").trim();
    const type = String(row.activity_type || "activity").trim();
    const detail = summarizeActivityDetail(type, row.detail);
    return `- ${when ? `${when}: ` : ""}${type}${detail ? ` — ${detail}` : ""}`;
  }).slice(0, 3);
  return {
    id: contact.id,
    fullName: String(contact.full_name || "").trim(),
    email: String(contact.email || "").trim(),
    phone: String(contact.phone || "").trim(),
    status: String(contact.status || "").trim(),
    outcome: String(contact.outcome || "").trim(),
    leadSource: String(contact.lead_source || "").trim(),
    state: String(contact.state || "").trim(),
    tags: String(contact.tags || "").trim(),
    notes: compactText(contact.notes, 350),
    specialNotes: compactText(contact.special_notes, 350),
    createdAt: String(contact.created_at || "").trim(),
    recentActivity: historyLines
  };
}

function contactStatusLabel(ctx) {
  if (!ctx) return "";
  const parts = [ctx.status, ctx.outcome].map((v) => String(v || "").trim()).filter(Boolean);
  return parts.join(" · ");
}

function buildEmailPrompt(body, contactCtx) {
  const contactName = String(contactCtx?.fullName || body?.contactName || "").trim();
  const contactStatus = contactStatusLabel(contactCtx);
  const leadSource = String(body?.leadSource || contactCtx?.leadSource || "").trim();
  const quoteAmount = String(body?.quoteAmount || "").trim();
  const purpose = String(body?.purpose || "").trim();
  const tone = toneLabel(body?.tone);
  const context = compactText(body?.context || body?.contactContext || "", 600);
  const extra = [];
  if (contactCtx?.notes) extra.push(`Notes: ${contactCtx.notes}`);
  if (contactCtx?.specialNotes) extra.push(`Special notes: ${contactCtx.specialNotes}`);
  if (contactCtx?.recentActivity?.length) extra.push(`Recent activity:\n${contactCtx.recentActivity.join("\n")}`);
  const mergedContext = [context, ...extra].filter(Boolean).join("\n");

  return [
    "Write an email draft for the following:",
    `Contact name: ${contactName || ""}`,
    `Contact status: ${contactStatus || ""}`,
    `Lead source: ${leadSource || ""}`,
    `Quote amount: ${quoteAmount || ""}`,
    `Purpose: ${purpose}`,
    `Tone: ${tone}`,
    `Additional context: ${compactText(mergedContext, 1200) || ""}`
  ].join("\n");
}

function buildSmsPrompt(body, contactCtx) {
  const contactName = String(contactCtx?.fullName || body?.contactName || "").trim();
  const contactStatus = contactStatusLabel(contactCtx);
  const purpose = String(body?.purpose || "").trim();
  const tone = toneLabel(body?.tone || "warm");
  const context = String(body?.context || "").trim();

  return [
    "Write an SMS draft for the following:",
    `Contact name: ${contactName || ""}`,
    `Contact status: ${contactStatus || ""}`,
    `Purpose: ${purpose}`,
    `Tone: ${tone}`,
    `Additional context: ${context || ""}`
  ].join("\n");
}

async function collectAutomationContext(all, body) {
  const snapshot = await collectPipelineSnapshot(all, { pastDays: 30, futureDays: 14 });
  const leadSourceRows = await all(
    `SELECT trim(COALESCE(lead_source, '')) AS lead_source, COUNT(*) AS n
     FROM contacts
     WHERE trim(COALESCE(lead_source, '')) != ''
     GROUP BY trim(COALESCE(lead_source, ''))
     ORDER BY n DESC
     LIMIT 5`
  );
  const campaignRows = await all(
    `SELECT DISTINCT trim(COALESCE(c.name, '')) AS name
     FROM drip_campaigns c
     INNER JOIN drip_enrollments e ON e.campaign_id = c.id
     WHERE lower(trim(COALESCE(e.status, ''))) = 'active'
       AND trim(COALESCE(c.name, '')) != ''
     LIMIT 10`
  );
  const leadSources = (Array.isArray(leadSourceRows) ? leadSourceRows : [])
    .map((row) => `${row.lead_source} (${row.n})`)
    .join(", ");
  const activeCampaigns = (Array.isArray(campaignRows) ? campaignRows : [])
    .map((row) => row.name)
    .filter(Boolean)
    .join(", ");
  const pipelineSummary = [
    `${snapshot.newLeads} new leads (30d)`,
    `${snapshot.leadsQuoted} with quotes`,
    `${snapshot.closedSold} sold / ${snapshot.closedLost} lost`,
    snapshot.closeRate != null
      ? `${snapshot.closeRate}% close rate (last ${snapshot.pastDays || 7}d)`
      : `no closes in last ${snapshot.pastDays || 7} days`,
    `${snapshot.staleLeads} new leads with no activity (7d+)`
  ]
    .filter(Boolean)
    .join("; ");

  return { pipelineSummary, leadSources, activeCampaigns, snapshot };
}

function buildAutomationPrompt(body, automationCtx) {
  const context = String(body?.context || "").trim();
  const goals = String(body?.goals || "").trim();
  const audience = String(body?.audience || "").trim();
  const niche = String(body?.niche || "Medicare / health insurance").trim();
  const mergedContext = [context, goals && `Goals: ${goals}`, audience && `Audience: ${audience}`, niche && `Niche: ${niche}`]
    .filter(Boolean)
    .join("\n");

  return [
    "Suggest 5 automation ideas for a health insurance agent with the following context:",
    `Current pipeline summary: ${automationCtx?.pipelineSummary || ""}`,
    `Most common lead sources: ${automationCtx?.leadSources || ""}`,
    `Current active campaigns: ${automationCtx?.activeCampaigns || ""}`,
    `Additional context: ${mergedContext || ""}`
  ].join("\n");
}

function buildPipelinePrompt(snapshot, body) {
  const context = String(body?.context || "").trim();
  const dateRange = `Last ${snapshot.pastDays || 30} days (upcoming tasks: next ${snapshot.futureDays || 14} days)`;
  return [
    "Generate a pipeline summary for the following agent data:",
    `Date range: ${dateRange}`,
    `New leads: ${snapshot.newLeads ?? ""}`,
    `Leads quoted: ${snapshot.leadsQuoted ?? ""}`,
    `Appointments scheduled: ${snapshot.appointmentsScheduled ?? ""}`,
    `Closed sold: ${snapshot.closedSold ?? ""}`,
    `Closed lost: ${snapshot.closedLost ?? ""}`,
    `NEW status leads with no activity in 7+ days: ${snapshot.staleLeads ?? ""}`,
    `Conversion rate (last ${snapshot.pastDays || 30}d): ${snapshot.closeRate != null ? `${snapshot.closeRate}%` : "N/A"}`,
    `Closed in period: ${snapshot.closedSoldInPeriod ?? 0} sold, ${snapshot.closedLostInPeriod ?? 0} lost`,
    `Upcoming enrollment deadline: ${String(body?.enrollmentDeadline || "").trim()}`,
    `Active drip campaigns: ${snapshot.activeCampaigns ?? ""}`,
    `Additional context: ${context || ""}`
  ].join("\n");
}

function contactContextLines(contactCtx) {
  if (!contactCtx) return ["Contact context: none selected"];
  return [
    `Contact name: ${contactCtx.fullName || ""}`,
    `Status: ${contactCtx.status || ""}`,
    `Outcome: ${contactCtx.outcome || ""}`,
    `Lead source: ${contactCtx.leadSource || ""}`,
    `State: ${contactCtx.state || ""}`,
    `Tags: ${contactCtx.tags || ""}`,
    `Notes: ${contactCtx.notes || ""}`,
    `Special notes: ${contactCtx.specialNotes || ""}`,
    contactCtx.recentActivity?.length ? `Recent activity:\n${contactCtx.recentActivity.join("\n")}` : ""
  ].filter(Boolean);
}

function buildObjectionPrompt(body, contactCtx) {
  return [
    "Coach the agent on this objection.",
    `Insurance type: ${String(body?.insuranceType || "Private health insurance").trim()}`,
    `Objection heard: ${String(body?.objection || "").trim()}`,
    `Agent context: ${String(body?.context || "").trim()}`,
    ...contactContextLines(contactCtx)
  ].join("\n");
}

function buildCallScriptPrompt(body, contactCtx) {
  return [
    "Create a call script for this upcoming call.",
    `Call type: ${String(body?.callType || "").trim()}`,
    `Goal: ${String(body?.goal || "").trim()}`,
    `Insurance type: ${String(body?.insuranceType || "Private health insurance").trim()}`,
    `Extra context: ${String(body?.context || "").trim()}`,
    ...contactContextLines(contactCtx)
  ].join("\n");
}

function buildFollowUpSequencePrompt(body, contactCtx) {
  return [
    "Create a multi-step follow-up sequence.",
    `Situation: ${String(body?.situation || "").trim()}`,
    `Insurance type: ${String(body?.insuranceType || "Private health insurance").trim()}`,
    `Preferred channels: ${String(body?.channels || "SMS and email").trim()}`,
    `Extra context: ${String(body?.context || "").trim()}`,
    ...contactContextLines(contactCtx)
  ].join("\n");
}

function buildPlanComparisonPrompt(body) {
  return [
    "Compare these two plans in plain English.",
    `Client priorities: ${String(body?.priorities || "").trim()}`,
    `Plan A details:\n${String(body?.planA || "").trim()}`,
    `Plan B details:\n${String(body?.planB || "").trim()}`
  ].join("\n");
}

function buildVoicemailPrompt(body, contactCtx) {
  return [
    "Write a voicemail script.",
    `Purpose: ${String(body?.purpose || "").trim()}`,
    `Insurance type: ${String(body?.insuranceType || "Private health insurance").trim()}`,
    `Extra context: ${String(body?.context || "").trim()}`,
    ...contactContextLines(contactCtx)
  ].join("\n");
}

const REENGAGE_SYSTEM = `You are an expert health insurance agent CRM assistant. Write a short, warm re-engagement message for a contact who hasn't been contacted in a while. Be personal, not salesy. Reference their name naturally.`;

function buildReengagePrompt(contact, channel) {
  const name = contact.full_name || contact.first_name || "there";
  const status = contact.status || "";
  const notes = String(contact.notes || "").slice(0, 200);
  const daysSince = contact.days_since_contact ? `${contact.days_since_contact} days since last contact` : "inactive for a while";
  if (channel === "sms") {
    return `Write a friendly SMS re-engagement message (under 155 characters) for ${name}. Status: ${status || "unknown"}. ${daysSince}. ${notes ? `Notes: ${notes}` : ""} Use {{first_name}} for their name. Return only the SMS text, nothing else.`;
  }
  return `Write a short re-engagement email (subject + 2-3 paragraph body) for ${name}. Status: ${status || "unknown"}. ${daysSince}. ${notes ? `Notes: ${notes}` : ""} Use {{first_name}} and {{agent_name}} naturally. Format: first line is subject (no "Subject:" prefix), blank line, then body. Return only the email, nothing else.`;
}

function registerReengageRoute(app, { all, getAuthSession, createRateLimiter }) {
  const limiter = createRateLimiter({ windowMs: 60_000, max: 8 });

  app.post("/api/assistant/reengage", limiter, async (req, res) => {
    try {
      const session = getAuthSession(req);
      if (!session) return res.status(401).json({ error: "Unauthorized" });
      const { noApiKey, noApiKeyMessage } = getClaudeConfig();
      if (noApiKey) return res.status(402).json({ error: noApiKeyMessage });

      const days   = Math.max(7, Math.min(365, Number(req.body?.days)  || 60));
      const limit  = Math.max(1, Math.min(20,  Number(req.body?.limit) || 10));
      const channel = String(req.body?.channel || "email");

      // Find contacts with no activity in the last N days
      const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
      const contacts = await all(`
        SELECT c.id, c.full_name, c.email, c.phone, c.status, c.notes,
               MAX(ca.created_at) AS last_activity,
               CAST(julianday('now') - julianday(COALESCE(MAX(ca.created_at), c.created_at)) AS INTEGER) AS days_since_contact
        FROM contacts c
        LEFT JOIN contact_activity ca ON ca.contact_id = c.id
        GROUP BY c.id
        HAVING last_activity IS NULL OR last_activity < ?
        ORDER BY last_activity ASC NULLS LAST
        LIMIT ?
      `, [cutoff, limit]);

      if (!contacts.length) {
        return res.json({ contacts: [], message: `No contacts inactive for ${days}+ days found.` });
      }

      // Generate re-engagement drafts for each contact
      const results = await Promise.all(contacts.map(async (contact) => {
        try {
          const raw = await callClaudeText({
            system: REENGAGE_SYSTEM,
            user: buildReengagePrompt(contact, channel),
            maxTokens: channel === "sms" ? 200 : 600,
            temperature: 0.7
          });
          let subject = "", body = raw.trim();
          if (channel === "email") {
            const lines = raw.trim().split("\n");
            subject = lines[0].replace(/^subject:\s*/i, "").trim();
            body = lines.slice(2).join("\n").trim() || lines.slice(1).join("\n").trim();
          }
          return { contact, subject, body, error: null };
        } catch (e) {
          return { contact, subject: "", body: "", error: e.message };
        }
      }));

      return res.json({ contacts: results, days, channel });
    } catch (e) {
      return res.status(500).json({ error: e.message || "Re-engagement scan failed." });
    }
  });
}

function registerAssistantRoutes(app, { all, get, createRateLimiter }) {
  const assistantLimiter = createRateLimiter
    ? createRateLimiter({ windowMs: 60_000, max: 20, label: "assistant-generate" })
    : (_req, _res, next) => next();

  app.get("/api/assistant/status", (_req, res) => {
    const { configured, model, keyLooksValid, keyLength } = getClaudeConfig();
    return res.json({
      configured,
      model,
      provider: "claude",
      keyLooksValid,
      keyLength: configured ? keyLength : 0
    });
  });

  app.get("/api/assistant/contact/:id", async (req, res) => {
    try {
      if (!get) return res.status(500).json({ error: "Contact lookup unavailable." });
      const ctx = await loadContactContextForAssistant(get, all, req.params.id);
      if (!ctx) return res.status(404).json({ error: "Contact not found." });
      return res.json(ctx);
    } catch (error) {
      return res.status(500).json({ error: error.message || "Could not load contact." });
    }
  });

  app.post("/api/assistant/generate", assistantLimiter, async (req, res) => {
    try {
      const mode = String(req.body?.mode || "")
        .trim()
        .toLowerCase();
      if (!mode) return res.status(400).json({ error: "Choose an AI Assistant mode." });

      const contactCtx =
        get && req.body?.contactId
          ? await loadContactContextForAssistant(get, all, req.body.contactId)
          : null;

      if (mode === "email") {
        const purpose = String(req.body?.purpose || "").trim();
        if (!purpose) return res.status(400).json({ error: "Describe the email purpose." });
        const raw = await callClaudeChat({
          system: EMAIL_SYSTEM,
          user: buildEmailPrompt(req.body, contactCtx),
          maxTokens: 1000
        });
        const parsed = parseEmailDraft(raw);
        return res.json({
          mode,
          subject: parsed.subject,
          text: parsed.text,
          html: parsed.html || textToSimpleHtml(parsed.text)
        });
      }

      if (mode === "sms") {
        const purpose = String(req.body?.purpose || "").trim();
        if (!purpose) return res.status(400).json({ error: "Describe the SMS purpose." });
        const raw = await callClaudeChat({
          system: SMS_SYSTEM,
          user: buildSmsPrompt(req.body, contactCtx),
          maxTokens: 400
        });
        const parsed = parseSmsDraft(raw);
        return res.json({
          mode,
          message: parsed.message,
          message2: parsed.message2,
          characterCount: parsed.characterCount,
          characterCount2: parsed.characterCount2,
          isTwoPart: parsed.isTwoPart
        });
      }

      if (mode === "automation") {
        const automationCtx = await collectAutomationContext(all, req.body);
        const raw = await callClaudeChat({
          system: AUTOMATION_SYSTEM,
          user: buildAutomationPrompt(req.body, automationCtx),
          maxTokens: 1800
        });
        const ideas = parseAutomationIdeas(raw);
        return res.json({ mode, ideas, raw: ideas.length ? undefined : raw });
      }

      if (mode === "pipeline") {
        const snapshot = await collectPipelineSnapshot(all, {
          pastDays: req.body?.pastDays,
          futureDays: req.body?.futureDays
        });
        const raw = await callClaudeChat({
          system: PIPELINE_SYSTEM,
          user: buildPipelinePrompt(snapshot, req.body),
          maxTokens: 1000
        });
        return res.json({ mode, snapshot, summary: raw });
      }

      if (mode === "objection") {
        const objection = String(req.body?.objection || "").trim();
        if (!objection) return res.status(400).json({ error: "Enter the client objection." });
        const raw = await callClaudeChat({
          system: OBJECTION_COACH_SYSTEM,
          user: buildObjectionPrompt(req.body, contactCtx),
          maxTokens: 900
        });
        return res.json({ mode, text: raw });
      }

      if (mode === "call-script") {
        const callType = String(req.body?.callType || "").trim();
        if (!callType) return res.status(400).json({ error: "Choose a call type." });
        const raw = await callClaudeChat({
          system: CALL_SCRIPT_SYSTEM,
          user: buildCallScriptPrompt(req.body, contactCtx),
          maxTokens: 1400
        });
        return res.json({ mode, text: raw });
      }

      if (mode === "follow-up-sequence") {
        const situation = String(req.body?.situation || req.body?.context || "").trim();
        if (!situation && !contactCtx) return res.status(400).json({ error: "Describe the contact situation." });
        const raw = await callClaudeChat({
          system: FOLLOW_UP_SEQUENCE_SYSTEM,
          user: buildFollowUpSequencePrompt(req.body, contactCtx),
          maxTokens: 1600
        });
        return res.json({ mode, text: raw });
      }

      if (mode === "plan-comparison") {
        if (!String(req.body?.planA || "").trim() || !String(req.body?.planB || "").trim()) {
          return res.status(400).json({ error: "Paste details for both plans." });
        }
        const raw = await callClaudeChat({
          system: PLAN_COMPARISON_SYSTEM,
          user: buildPlanComparisonPrompt(req.body),
          maxTokens: 1300
        });
        return res.json({ mode, text: raw });
      }

      if (mode === "voicemail") {
        const purpose = String(req.body?.purpose || "").trim();
        if (!purpose) return res.status(400).json({ error: "Describe the voicemail purpose." });
        const raw = await callClaudeChat({
          system: VOICEMAIL_SYSTEM,
          user: buildVoicemailPrompt(req.body, contactCtx),
          maxTokens: 600
        });
        return res.json({ mode, text: raw });
      }

      return res.status(400).json({ error: "Unknown AI Assistant mode." });
    } catch (error) {
      const status = Number(error.statusCode) || 500;
      return res.status(status).json({ error: error.message || "AI request failed." });
    }
  });
}

// ── AI Campaign Generator ──────────────────────────────────────────────────────
const AI_CAMPAIGN_SYSTEM = `You are an expert health insurance agent CRM assistant. Generate a drip campaign as a JSON object.

Rules:
- Return ONLY valid JSON, no markdown, no explanation.
- The JSON must have: name (string), description (string), steps (array).
- Each step must have: step_order (integer starting at 1), offset_hours (number, hours after previous step or enrollment), channel ("email" or "sms"), subject (string, empty "" for sms), body (string).
- For email steps: write a proper subject line and 3-5 paragraph body. Use {{first_name}}, {{agent_name}} merge fields where natural.
- For SMS steps: body must be under 160 characters. No subject.
- Make offset_hours realistic: step 1 at 0, then 48, 120, 240, 336 hours etc.
- Generate exactly as many steps as requested (default 5 if not specified).
- Campaign name should be concise and descriptive.`;

function registerAiCampaignRoute(app, { createRateLimiter }) {
  const limiter = createRateLimiter({ windowMs: 60_000, max: 10 });

  app.post("/api/assistant/generate-campaign", limiter, async (req, res) => {
    try {
      const session = getAuthSession(req);
      if (!session) return res.status(401).json({ error: "Unauthorized" });
      const { noApiKey, noApiKeyMessage } = getClaudeConfig();
      if (noApiKey) return res.status(402).json({ error: noApiKeyMessage });

      const goal = String(req.body?.goal || "").trim();
      if (!goal) return res.status(400).json({ error: "Describe your campaign goal." });

      const raw = await callClaudeText({
        system: AI_CAMPAIGN_SYSTEM,
        user: `Generate a drip campaign for this goal: ${goal}`,
        maxTokens: 3000,
        temperature: 0.7
      });

      // Extract JSON from response
      const jsonMatch = raw.match(/\{[\s\S]*\}/);
      if (!jsonMatch) return res.status(500).json({ error: "AI returned an unexpected format. Try again." });
      const campaign = JSON.parse(jsonMatch[0]);

      // Validate
      if (!campaign.name || !Array.isArray(campaign.steps) || !campaign.steps.length) {
        return res.status(500).json({ error: "AI returned an incomplete campaign. Try again." });
      }
      return res.json({ campaign });
    } catch (e) {
      if (e instanceof SyntaxError) return res.status(500).json({ error: "AI returned invalid JSON. Try again." });
      const message = String(e.message || "");
      return res.status(e.statusCode || 500).json({
        error: isClaudeUsageLimitError(message) ? CLAUDE_USAGE_LIMIT_MESSAGE : message || "AI campaign generation failed."
      });
    }
  });
}

module.exports = {
  registerAssistantRoutes,
  registerAiCampaignRoute,
  registerReengageRoute,
  collectPipelineSnapshot,
  loadContactContextForAssistant
};
