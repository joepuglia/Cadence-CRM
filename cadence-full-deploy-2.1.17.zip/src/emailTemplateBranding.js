"use strict";

const EMAIL_ASSET_ORIGIN = "https://crmcadence.com";
const LOGO_ICON = `${EMAIL_ASSET_ORIGIN}/favicon.svg`;
const HERO_CONTACTS = `${EMAIL_ASSET_ORIGIN}/email-assets/cadence-email-hero-contacts.png`;
const HERO_PIPELINE = `${EMAIL_ASSET_ORIGIN}/email-assets/cadence-email-hero-pipeline.png`;

function escapeHtml(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function logoHeaderHtml({ headerName, headerTagline, logoLink }) {
  const href = logoLink || "https://crmcadence.com";
  const textBlock = `<div style="font-family:Arial,sans-serif;text-align:left;">
<div style="font-size:21px;font-weight:800;color:#0f172a;line-height:1.2;">${escapeHtml(headerName)}</div>
<div style="font-size:13px;color:#64748b;margin-top:4px;">${escapeHtml(headerTagline)}</div>
</div>`;
  return `<table cellpadding="0" cellspacing="0" border="0" width="100%" role="presentation"><tr><td align="center" style="padding:20px 20px 16px;background:#f8fafc;border-bottom:1px solid #e2e8f0;">
<a href="${href}" style="text-decoration:none;color:inherit;"><table cellpadding="0" cellspacing="0" border="0" role="presentation" style="margin:0 auto;"><tr>
<td valign="middle" style="padding:0 14px 0 0;"><img src="${LOGO_ICON}" alt="Cadence" width="56" height="56" style="display:block;width:56px;height:56px;border:0;border-radius:12px;" /></td>
<td valign="middle">${textBlock}</td>
</tr></table></a></td></tr></table>`;
}

function wrapEmailHtml(bodyHtml, { hero, logoLink, maxWidth = 600 } = {}) {
  const heroSrc = hero === "pipeline" ? HERO_PIPELINE : hero === "contacts" ? HERO_CONTACTS : "";
  const heroBlock = heroSrc
    ? `<table cellpadding="0" cellspacing="0" border="0" width="100%" role="presentation"><tr><td style="padding:0;line-height:0;font-size:0;background:#0f172a;"><img src="${heroSrc}" alt="Cadence CRM" width="600" style="display:block;width:100%;max-width:600px;height:auto;border:0;" /></td></tr></table>`
    : "";
  const header = logoHeaderHtml({
    headerName: "Cadence CRM",
    headerTagline: "Built for health insurance agents",
    logoLink
  });
  const footer = `<table cellpadding="0" cellspacing="0" border="0" width="100%" role="presentation"><tr><td align="center" style="padding:18px 20px;background:#f8fafc;border-top:1px solid #e2e8f0;font-size:12px;color:#64748b;font-family:Arial,sans-serif;"><a href="https://crmcadence.com" style="color:#4f46e5;font-weight:700;text-decoration:none;">Cadence CRM</a> · Built for health insurance agents</td></tr></table>`;

  return `<table cellpadding="0" cellspacing="0" border="0" width="100%" role="presentation" style="background:#e2e8f0;font-family:Arial,sans-serif;">
<tr><td align="center" style="padding:24px 12px;">
<table cellpadding="0" cellspacing="0" border="0" width="${maxWidth}" style="max-width:${maxWidth}px;width:100%;background:#ffffff;border-radius:14px;overflow:hidden;">
<tr><td>
${header}
${heroBlock}
<div style="padding:26px 24px 8px;color:#0f172a;font-size:16px;line-height:1.6;">${bodyHtml}</div>
${footer}
</td></tr></table>
</td></tr></table>`;
}

function ctaButton(href, label, color = "#4f46e5") {
  return `<p style="text-align:center;margin:22px 0 18px;"><a href="${href}" style="display:inline-block;background:${color};color:#ffffff;text-decoration:none;padding:14px 32px;border-radius:10px;font-weight:700;">${escapeHtml(label)}</a></p>`;
}

function paradigmaiHtmlBody(innerHtml, hero) {
  return wrapEmailHtml(innerHtml, {
    hero,
    logoLink: "https://crmcadence.com/signup.html?utm_source=paradigmai&utm_medium=email"
  });
}

module.exports = {
  EMAIL_ASSET_ORIGIN,
  LOGO_ICON,
  HERO_CONTACTS,
  HERO_PIPELINE,
  wrapEmailHtml,
  ctaButton,
  paradigmaiHtmlBody
};
