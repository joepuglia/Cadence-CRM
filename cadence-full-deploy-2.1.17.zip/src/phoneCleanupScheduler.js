"use strict";

/**
 * phoneCleanupScheduler.js
 * Sends a release notification email to support@crmcadence.com when a number is released.
 *
 * Runs once daily. Finds tenants whose trial has expired (or status = cancelled)
 * for more than GRACE_DAYS and releases their provisioned Twilio phone number
 * back to the master account.
 *
 * Grace period: 7 days — gives expired agents time to convert before losing their number.
 */

const { releaseNumber, isMasterConfigured } = require("./twilioProvisioning");
const { sendEmail, isEmailConfigured } = require("./emailService");

const OWNER_EMAIL = "support@crmcadence.com";

const GRACE_DAYS   = 7;
const GRACE_SEC    = GRACE_DAYS * 24 * 60 * 60;
const TICK_MS      = 24 * 60 * 60 * 1000; // run once per day

let running = false;

async function processPhoneCleanup({ platformAll, withTenantContext, run, get }) {
  if (running) return;
  running = true;
  try {
    if (!isMasterConfigured()) return;

    const nowSec   = Math.floor(Date.now() / 1000);
    const cutoffSec = nowSec - GRACE_SEC;

    // Find tenants that are expired/cancelled and past the grace period
    const tenants = await platformAll(`
      SELECT id, owner_email, slug
      FROM tenants
      WHERE status IN ('expired', 'cancelled')
        AND trial_ends_at < ?
    `, [cutoffSec]);

    if (!tenants || !tenants.length) return;

    for (const tenant of tenants) {
      try {
        let phoneNumber = null;
        let alreadyReleased = false;

        await withTenantContext(tenant.id, async () => {
          const phoneRow    = await get(`SELECT value FROM twilio_runtime_config WHERE key = 'phoneNumber'`);
          const releasedRow = await get(`SELECT value FROM twilio_runtime_config WHERE key = 'phoneReleased'`);
          phoneNumber     = phoneRow?.value   || null;
          alreadyReleased = releasedRow?.value === "1";
        });

        if (!phoneNumber || alreadyReleased) continue;

        console.log(`[phone-cleanup] Releasing ${phoneNumber} for tenant ${tenant.id} (${tenant.owner_email})`);
        await releaseNumber(phoneNumber);

        // Mark as released so we don't attempt again
        await withTenantContext(tenant.id, async () => {
          await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('phoneReleased', '1')`);
          await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('phoneReleasedAt', ?)`,
            [String(nowSec)]
          );
        });

        console.log(`[phone-cleanup] Released ${phoneNumber} for tenant ${tenant.id}`);

        // Notify owner
        if (isEmailConfigured()) {
          sendEmail({
            to: OWNER_EMAIL,
            subject: "Cadence CRM — Phone number released",
            text: `Phone number ${phoneNumber} was released from tenant ${tenant.id} (${tenant.owner_email} / ${tenant.slug}) after ${GRACE_DAYS}-day grace period post-expiry.`
          }).catch(() => {});
        }
      } catch (err) {
        console.error(`[phone-cleanup] Failed to release number for tenant ${tenant.id}:`, err.message || err);
      }
    }
  } catch (err) {
    console.error("[phone-cleanup] Scheduler error:", err.message || err);
  } finally {
    running = false;
  }
}

function startPhoneCleanupScheduler(deps) {
  // Run once at startup (after a short delay), then daily
  setTimeout(() => {
    processPhoneCleanup(deps).catch((err) =>
      console.error("[phone-cleanup] Startup run error:", err)
    );
  }, 60 * 1000); // wait 60s after boot before first run

  setInterval(() => {
    processPhoneCleanup(deps).catch((err) =>
      console.error("[phone-cleanup] Interval error:", err)
    );
  }, TICK_MS);

  console.log(`[phone-cleanup] Scheduler started — checks daily, ${GRACE_DAYS}-day grace period after expiry`);
}

module.exports = { startPhoneCleanupScheduler };
