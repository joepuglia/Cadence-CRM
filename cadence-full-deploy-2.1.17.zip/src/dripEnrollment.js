"use strict";

function normalizeTagToken(t) {
  return String(t || "")
    .trim()
    .toLowerCase();
}

function tagTokens(tagsStr) {
  return String(tagsStr || "")
    .split(/[,;\n\r]+/)
    .map((t) => t.trim())
    .filter(Boolean)
    .map(normalizeTagToken);
}

/** Tag tokens newly present on the contact (case-insensitive). */
function addedTagTokens(prevStr, nextStr) {
  const prev = new Set(tagTokens(prevStr));
  const seen = new Set();
  const out = [];
  for (const t of tagTokens(nextStr)) {
    if (!prev.has(t) && !seen.has(t)) {
      seen.add(t);
      out.push(t);
    }
  }
  return out;
}

/** Tag tokens no longer present on the contact (case-insensitive). */
function removedTagTokens(prevStr, nextStr) {
  const next = new Set(tagTokens(nextStr));
  const seen = new Set();
  const out = [];
  for (const t of tagTokens(prevStr)) {
    if (!next.has(t) && !seen.has(t)) {
      seen.add(t);
      out.push(t);
    }
  }
  return out;
}

function parseTagRulesJson(tagConfig) {
  try {
    let raw = tagConfig;
    if (typeof raw === "string") raw = JSON.parse(raw || "[]");
    /** Some stores double-stringify tag rules; unwrap once. */
    if (typeof raw === "string") raw = JSON.parse(raw);
    return Array.isArray(raw) ? raw : [];
  } catch {
    return [];
  }
}

function enrollRuleTags(tagConfig) {
  const rules = parseTagRulesJson(tagConfig);
  const out = [];
  for (const rule of rules) {
    const tag = normalizeTagToken(rule && rule.tag);
    if (!tag) continue;
    let fn = Object.prototype.hasOwnProperty.call(rule, "function")
      ? String(rule.function == null ? "" : rule.function).trim().toLowerCase()
      : "enroll";
    if (fn === "none") continue;
    if (fn !== "enroll") continue;
    out.push(tag);
  }
  return [...new Set(out)];
}

/** True if campaign tag rules include at least one tag-trigger enrollment row. */
function campaignHasEnrollRule(tagConfig) {
  const rules = parseTagRulesJson(tagConfig);
  return rules.some((r) => {
    const tag = String(r.tag || "").trim();
    if (!tag) return false;
    let fn = Object.prototype.hasOwnProperty.call(r, "function")
      ? String(r.function == null ? "" : r.function).trim().toLowerCase()
      : "enroll";
    if (fn === "none") return false;
    return fn === "enroll";
  });
}

async function enrollContactInCampaign(deps, campaignId, contactId, startedAtUnix) {
  const { run, get, all } = deps;
  const startedAt = Number.isFinite(startedAtUnix) ? Math.floor(startedAtUnix) : Math.floor(Date.now() / 1000);

  const existing = await get(
    `SELECT id FROM drip_enrollments WHERE campaign_id = ? AND contact_id = ? AND status = 'active'`,
    [campaignId, contactId]
  );
  if (existing) {
    const pendingRow = await get(
      `SELECT COUNT(1) AS pending_count
       FROM drip_send_queue
       WHERE enrollment_id = ? AND status = 'pending'`,
      [existing.id]
    );
    const pendingCount = Number(pendingRow && pendingRow.pending_count);
    if (pendingCount > 0) {
      return { ok: false, reason: "already_active" };
    }
    await run(`UPDATE drip_enrollments SET status = 'cancelled' WHERE id = ? AND status = 'active'`, [existing.id]);
  }

  const campaign = await get(`SELECT * FROM drip_campaigns WHERE id = ?`, [campaignId]);
  if (!campaign) return { ok: false, reason: "no_campaign" };

  const steps = await all(`SELECT * FROM drip_steps WHERE campaign_id = ? ORDER BY step_order ASC`, [campaignId]);
  if (!steps.length) return { ok: false, reason: "no_steps" };

  await run("BEGIN");
  try {
    const en = await run(
      `INSERT INTO drip_enrollments (campaign_id, contact_id, started_at, status) VALUES (?, ?, ?, 'active')`,
      [campaignId, contactId, startedAt]
    );
    const enrollmentId = en.lastID;
    for (const step of steps) {
      const scheduledAt = startedAt + Math.round(Number(step.offset_hours) * 3600);
      await run(
        `INSERT INTO drip_send_queue (enrollment_id, step_id, scheduled_at, status) VALUES (?, ?, ?, 'pending')`,
        [enrollmentId, step.id, scheduledAt]
      );
    }
    await run("COMMIT");
    return { ok: true, enrollmentId, scheduledSteps: steps.length, startedAt };
  } catch (e) {
    await run("ROLLBACK");
    throw e;
  }
}

/**
 * @param {{ explicitAddedTokens?: string[] }} [options]
 *        Bulk tag UI passes tokens the user typed so enrollment still runs if prev/next diff misses (spacing, etc.).
 */
async function maybeEnrollFromContactTags(deps, contactId, previousTagsStr, nextTagsStr, options = {}) {
  const { all, run } = deps;
  let added = addedTagTokens(previousTagsStr, nextTagsStr);
  const removed = removedTagTokens(previousTagsStr, nextTagsStr);
  const explicit = options.explicitAddedTokens;
  if (Array.isArray(explicit) && explicit.length > 0) {
    const nextSet = new Set(tagTokens(nextTagsStr));
    const fromExplicit = explicit.map(normalizeTagToken).filter((t) => t && nextSet.has(t));
    added = [...new Set([...added, ...fromExplicit])];
  }
  if (!added.length && !removed.length) return;

  const previousSet = new Set(tagTokens(previousTagsStr));
  const nextSet = new Set(tagTokens(nextTagsStr));
  const campaigns = await all(`SELECT * FROM drip_campaigns`);

  // First, stop active enrollments when a qualifying tag was removed and no matching tag remains.
  for (const c of campaigns) {
    const ruleTags = enrollRuleTags(c.tag_config);
    if (!ruleTags.length) continue;
    const hadMatchBefore = ruleTags.some((t) => previousSet.has(t));
    const hasMatchNow = ruleTags.some((t) => nextSet.has(t));
    const removedTriggerTag = removed.some((t) => ruleTags.includes(t));
    if (!(hadMatchBefore && !hasMatchNow && removedTriggerTag)) continue;

    const activeRows = await all(
      `SELECT id
       FROM drip_enrollments
       WHERE campaign_id = ? AND contact_id = ? AND status = 'active'`,
      [c.id, contactId]
    );
    if (!Array.isArray(activeRows) || !activeRows.length) continue;

    const stopAt = Math.floor(Date.now() / 1000);
    for (const row of activeRows) {
      const enrollmentId = Number(row && row.id);
      if (!Number.isInteger(enrollmentId) || enrollmentId < 1) continue;
      await run(
        `UPDATE drip_send_queue
         SET status = 'skipped',
             sent_at = ?,
             error_message = COALESCE(NULLIF(error_message, ''), 'Stopped: matching tag removed')
         WHERE enrollment_id = ?
           AND status = 'pending'`,
        [stopAt, enrollmentId]
      );
      await run(`UPDATE drip_enrollments SET status = 'cancelled' WHERE id = ? AND status = 'active'`, [enrollmentId]);
    }
  }

  if (!added.length) return;
  for (const c of campaigns) {
    if (!campaignHasEnrollRule(c.tag_config)) continue;
    const ruleTags = enrollRuleTags(c.tag_config);
    for (const tag of ruleTags) {
      if (!added.includes(tag)) continue;
      try {
        const mode = String(c.schedule_mode || "")
          .trim()
          .toLowerCase();
        if (mode === "scheduled" && typeof run === "function") {
          await run(
            `UPDATE drip_campaigns SET schedule_mode = 'on_tag', start_at = NULL, end_at = NULL WHERE id = ?`,
            [c.id]
          );
        }
        const result = await enrollContactInCampaign(deps, c.id, contactId);
        if (result && result.ok === false && result.reason && result.reason !== "already_active") {
          console.warn(`Tag enroll campaign ${c.id} contact ${contactId}: ${result.reason}`);
        }
      } catch (e) {
        console.error(`Tag enroll campaign ${c.id} contact ${contactId}:`, e && e.message ? e.message : e);
      }
    }
  }
}

module.exports = {
  enrollContactInCampaign,
  maybeEnrollFromContactTags,
  addedTagTokens,
  removedTagTokens,
  tagTokens,
  campaignHasEnrollRule,
  normalizeTagToken
};
