"use strict";

const crypto = require("crypto");

/** Tag match that tolerates "tag1, tag2" spacing and case. */
const TAG_MATCH_SQL = `(',' || REPLACE(LOWER(COALESCE(tags, '')), ' ', '') || ',') LIKE '%,' || REPLACE(LOWER(?), ' ', '') || ',%'`;

const PER_HOUR_MIN = 10;
const PER_HOUR_MAX = 60;
const PER_HOUR_DEFAULT = 40;

function nowUnix() {
  return Math.floor(Date.now() / 1000);
}

function clampPerHour(raw) {
  const n = Number(raw);
  if (!Number.isFinite(n) || n <= 0) return PER_HOUR_DEFAULT;
  return Math.max(PER_HOUR_MIN, Math.min(PER_HOUR_MAX, Math.floor(n)));
}

function isValidEmail(raw) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(raw || "").trim());
}

/** Lowercased set of emails already emailed for this campaign: sends recorded
 *  for this TAG in the queue, PLUS everyone actually sent this SUBJECT (from
 *  email_open_tracking, which logs every sent email and SURVIVES a queue
 *  rebuild/repair — so it recovers recipients even after the queue was cleared).
 *  Subject matching is exact, so it works for fixed subjects (merge-field
 *  subjects render per-recipient and won't match). */
async function alreadySentEmailsForTag(all, tag, subject) {
  const set = new Set();
  const addRows = (rows) => {
    for (const r of Array.isArray(rows) ? rows : []) {
      const e = String(r.email || "").trim().toLowerCase();
      if (e) set.add(e);
    }
  };
  const cleanTag = String(tag || "").trim();
  if (cleanTag) {
    // Per-tag sends recorded in the queue (works for new campaigns)…
    addRows(
      await all(
        `SELECT DISTINCT LOWER(TRIM(to_email)) AS email
           FROM email_bulk_queue
          WHERE LOWER(TRIM(tag)) = LOWER(TRIM(?)) AND status = 'sent'`,
        [cleanTag]
      ).catch(() => [])
    );
    // …and the DURABLE per-tag record in open-tracking, which survives a queue
    // rebuild/repair — so "send once per tag" keeps working for every campaign,
    // including cancel-then-resend-later to the same tag.
    addRows(
      await all(
        `SELECT DISTINCT LOWER(TRIM(to_emails)) AS email
           FROM email_open_tracking
          WHERE LOWER(TRIM(tag)) = LOWER(TRIM(?))`,
        [cleanTag]
      ).catch(() => [])
    );
  }
  const cleanSubject = String(subject || "").trim();
  if (cleanSubject) {
    addRows(
      await all(
        `SELECT DISTINCT LOWER(TRIM(to_emails)) AS email
           FROM email_open_tracking
          WHERE TRIM(subject) = TRIM(?)`,
        [cleanSubject]
      ).catch(() => [])
    );
  }
  return set;
}

/** Recipients for a tag with exclusion counts (no rows written). When
 *  skipAlreadySent is set, contacts already emailed in a prior campaign for
 *  this tag are excluded from sendable and reported as alreadyEmailed. */
async function previewEmailBulkCampaign({ all }, tag, { skipAlreadySent = false, subject = "" } = {}) {
  const cleanTag = String(tag || "").trim();
  if (!cleanTag) {
    return { tag: "", total: 0, sendable: 0, skippedNoEmail: 0, skippedDoNotEmail: 0, duplicateEmails: 0, alreadyEmailed: 0 };
  }
  const rows = await all(
    `SELECT id, email, do_not_email FROM contacts WHERE ${TAG_MATCH_SQL}`,
    [cleanTag]
  );
  const alreadySent = skipAlreadySent ? await alreadySentEmailsForTag(all, cleanTag, subject) : new Set();
  let sendable = 0;
  let skippedNoEmail = 0;
  let skippedDoNotEmail = 0;
  let duplicateEmails = 0;
  let alreadyEmailed = 0;
  const seen = new Set();
  for (const row of Array.isArray(rows) ? rows : []) {
    const email = String(row.email || "").trim().toLowerCase();
    if (!isValidEmail(email)) {
      skippedNoEmail += 1;
      continue;
    }
    if (String(row.do_not_email || "") === "1") {
      skippedDoNotEmail += 1;
      continue;
    }
    if (seen.has(email)) {
      duplicateEmails += 1;
      continue;
    }
    seen.add(email);
    if (alreadySent.has(email)) {
      alreadyEmailed += 1;
      continue;
    }
    sendable += 1;
  }
  return {
    tag: cleanTag,
    total: Array.isArray(rows) ? rows.length : 0,
    sendable,
    skippedNoEmail,
    skippedDoNotEmail,
    duplicateEmails,
    alreadyEmailed
  };
}

/** Queue one row per sendable contact, spaced to the requested per-hour rate. */
async function queueEmailBulkCampaign({ run, all }, { tag, subject, html, text, from, perHour, skipAlreadySent = false }) {
  const cleanTag = String(tag || "").trim();
  if (!cleanTag) throw new Error("tag is required");
  const cleanSubject = String(subject || "").trim();
  if (!cleanSubject) throw new Error("subject is required");
  const cleanHtml = String(html || "").trim();
  const cleanText = String(text || "").trim();
  if (!cleanHtml && !cleanText) throw new Error("Email body is required");

  const rows = await all(
    `SELECT id, email, do_not_email FROM contacts WHERE ${TAG_MATCH_SQL} ORDER BY id ASC`,
    [cleanTag]
  );
  const alreadySent = skipAlreadySent ? await alreadySentEmailsForTag(all, cleanTag, cleanSubject) : new Set();
  const rate = clampPerHour(perHour);
  const intervalSeconds = Math.max(30, Math.round(3600 / rate));
  const batchId = `blk-${Date.now().toString(36)}-${crypto.randomBytes(3).toString("hex")}`;
  const start = nowUnix();

  // Store the body/subject/from ONCE per campaign — recipient rows just reference
  // it by batch_id. (Copying the full body into every recipient row is what
  // previously bloated the database by gigabytes per large campaign.)
  await run(
    `INSERT INTO email_bulk_batch (batch_id, tag, from_email, subject, body_html, body_text, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [batchId, cleanTag, String(from || "").trim(), cleanSubject, cleanHtml, cleanText, start]
  );

  let queued = 0;
  let skippedNoEmail = 0;
  let skippedDoNotEmail = 0;
  let skippedAlreadySent = 0;
  const seen = new Set();
  for (const row of Array.isArray(rows) ? rows : []) {
    const email = String(row.email || "").trim().toLowerCase();
    if (!isValidEmail(email)) {
      skippedNoEmail += 1;
      continue;
    }
    if (String(row.do_not_email || "") === "1") {
      skippedDoNotEmail += 1;
      continue;
    }
    if (seen.has(email)) continue;
    seen.add(email);
    if (alreadySent.has(email)) {
      skippedAlreadySent += 1;
      continue;
    }
    const scheduledAt = start + queued * intervalSeconds;
    // Lean row: no body/subject/from here — those live once in email_bulk_batch.
    await run(
      `INSERT INTO email_bulk_queue
         (batch_id, tag, contact_id, to_email, status, scheduled_at)
       VALUES (?, ?, ?, ?, 'pending', ?)`,
      [batchId, cleanTag, Number(row.id) || 0, email, scheduledAt]
    );
    queued += 1;
  }
  const estFinishAt = queued ? start + (queued - 1) * intervalSeconds : start;
  return {
    batchId,
    tag: cleanTag,
    queued,
    skippedNoEmail,
    skippedDoNotEmail,
    skippedAlreadySent,
    perHour: rate,
    intervalSeconds,
    estFinishAt
  };
}

/** Aggregate status for one batch (or the most recent batch when omitted). */
async function emailBulkCampaignStatus({ get, all }, batchId) {
  let id = String(batchId || "").trim();
  if (!id) {
    const latest = await get(`SELECT batch_id FROM email_bulk_queue ORDER BY id DESC LIMIT 1`);
    id = String(latest?.batch_id || "").trim();
  }
  if (!id) return { batchId: "", exists: false };
  const rows = await all(
    `SELECT status, COUNT(*) AS n FROM email_bulk_queue WHERE batch_id = ? GROUP BY status`,
    [id]
  );
  const counts = { pending: 0, sent: 0, failed: 0, skipped: 0, canceled: 0, paused: 0 };
  for (const row of Array.isArray(rows) ? rows : []) {
    const key = String(row.status || "").trim();
    if (key in counts) counts[key] = Number(row.n) || 0;
  }
  const meta = await get(
    `SELECT tag, MIN(scheduled_at) AS first_at, MAX(scheduled_at) AS last_at FROM email_bulk_queue WHERE batch_id = ?`,
    [id]
  );
  const nextRow = await get(
    `SELECT MIN(scheduled_at) AS next_at FROM email_bulk_queue WHERE batch_id = ? AND status = 'pending'`,
    [id]
  );
  const lastError = await get(
    `SELECT error FROM email_bulk_queue WHERE batch_id = ? AND status = 'failed' AND error != '' ORDER BY id DESC LIMIT 1`,
    [id]
  );
  const total = counts.pending + counts.sent + counts.failed + counts.skipped + counts.canceled + counts.paused;
  // Recover the configured send rate from the original scheduled spacing.
  const spacing = total > 1 ? Math.round((Number(meta?.last_at) - Number(meta?.first_at)) / (total - 1)) : 0;
  const perHour = spacing > 0 ? Math.round(3600 / spacing) : null;
  return {
    batchId: id,
    exists: total > 0,
    tag: String(meta?.tag || ""),
    total,
    perHour,
    ...counts,
    nextScheduledAt: Number(nextRow?.next_at) || null,
    estFinishAt: counts.pending ? Number(meta?.last_at) || null : null,
    lastError: String(lastError?.error || "")
  };
}

async function cancelEmailBulkCampaign({ run }, batchId) {
  const id = String(batchId || "").trim();
  if (!id) throw new Error("batchId is required");
  const result = await run(
    `UPDATE email_bulk_queue SET status = 'canceled' WHERE batch_id = ? AND status IN ('pending', 'paused')`,
    [id]
  );
  return { batchId: id, canceled: Number(result?.changes) || 0 };
}

/** Pause holds all unsent rows as 'paused'; the scheduler only sends 'pending',
 *  so they wait. Resume flips them back — the rate guard keeps the original pace,
 *  and already-sent rows stay sent (no resend). Content is the original snapshot. */
async function pauseEmailBulkCampaign({ run }, batchId) {
  const id = String(batchId || "").trim();
  if (!id) throw new Error("batchId is required");
  const result = await run(
    `UPDATE email_bulk_queue SET status = 'paused' WHERE batch_id = ? AND status = 'pending'`,
    [id]
  );
  return { batchId: id, paused: Number(result?.changes) || 0 };
}

async function resumeEmailBulkCampaign({ run }, batchId) {
  const id = String(batchId || "").trim();
  if (!id) throw new Error("batchId is required");
  const result = await run(
    `UPDATE email_bulk_queue SET status = 'pending' WHERE batch_id = ? AND status = 'paused'`,
    [id]
  );
  return { batchId: id, resumed: Number(result?.changes) || 0 };
}

/** Housekeeping for the bulk-email tables, in small batches so the write lock is
 *  only ever held briefly (reads keep flowing):
 *   - delete 'canceled'/'skipped'/'failed' rows (disposable),
 *   - keep 'sent' rows (lean now — they're the "already emailed" history),
 *   - drop each campaign's stored body once it has no rows left to send. */
async function pruneEmailBulkQueue({ run }, { batchSize = 1000, maxBatches = 20000 } = {}) {
  if (typeof run !== "function") return { deleted: 0 };
  let deleted = 0;
  for (let i = 0; i < maxBatches; i++) {
    const res = await run(
      `DELETE FROM email_bulk_queue
        WHERE id IN (
          SELECT id FROM email_bulk_queue
          WHERE status IN ('canceled', 'skipped', 'failed')
          LIMIT ?
        )`,
      [batchSize]
    );
    const n = Number(res?.changes) || 0;
    deleted += n;
    if (n < batchSize) break;
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  // Drop each campaign's stored body once it has no more rows to send (finished
  // or canceled). The lean queue rows stay as history; only the large body goes.
  await run(
    `DELETE FROM email_bulk_batch
      WHERE batch_id NOT IN (
        SELECT DISTINCT batch_id FROM email_bulk_queue WHERE status IN ('pending', 'paused')
      )`
  ).catch(() => {});
  return { deleted };
}

/** Status for every batch that still has pending emails — i.e. every campaign
 *  currently sending. Lets the UI list and manage more than one at a time.
 *  One grouped query (not N+1 status lookups) so Send Email stays fast on a
 *  large production queue. */
async function emailBulkCampaignActiveList({ get, all }) {
  const rows = await all(
    `SELECT batch_id,
            MAX(tag) AS tag,
            MIN(scheduled_at) AS first_at,
            MAX(scheduled_at) AS last_at,
            MIN(CASE WHEN status = 'pending' THEN scheduled_at END) AS next_at,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending,
            SUM(CASE WHEN status = 'paused' THEN 1 ELSE 0 END) AS paused,
            SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) AS sent,
            SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) AS failed,
            SUM(CASE WHEN status = 'skipped' THEN 1 ELSE 0 END) AS skipped,
            SUM(CASE WHEN status = 'canceled' THEN 1 ELSE 0 END) AS canceled
       FROM email_bulk_queue
      WHERE batch_id IN (
        SELECT DISTINCT batch_id FROM email_bulk_queue WHERE status IN ('pending', 'paused')
      )
      GROUP BY batch_id
      ORDER BY next_at ASC`
  );
  const campaigns = [];
  for (const row of Array.isArray(rows) ? rows : []) {
    const id = String(row.batch_id || "").trim();
    if (!id) continue;
    const pending = Number(row.pending) || 0;
    const paused = Number(row.paused) || 0;
    const sent = Number(row.sent) || 0;
    const failed = Number(row.failed) || 0;
    const skipped = Number(row.skipped) || 0;
    const canceled = Number(row.canceled) || 0;
    const total = pending + paused + sent + failed + skipped + canceled;
    const firstAt = Number(row.first_at) || 0;
    const lastAt = Number(row.last_at) || 0;
    const spacing = total > 1 ? Math.round((lastAt - firstAt) / (total - 1)) : 0;
    campaigns.push({
      batchId: id,
      exists: total > 0,
      tag: String(row.tag || ""),
      total,
      perHour: spacing > 0 ? Math.round(3600 / spacing) : null,
      pending,
      sent,
      failed,
      skipped,
      canceled,
      paused,
      nextScheduledAt: Number(row.next_at) || null,
      estFinishAt: pending ? lastAt || null : null,
      lastError: ""
    });
  }
  return { campaigns };
}

let processing = false;

/** Send due queue rows. `sendOne` (injected from server.js) merges fields,
 *  adds the tracking pixel, sends, and logs history for a single recipient. */
async function processDueBulkEmails({ get, all, run, sendOne, maxPerTick = 5 }) {
  if (processing) return;
  processing = true;
  try {
    /* Fair scheduling so multiple campaigns send in parallel: pick every batch
       that has a due row and send ONE row from each (subject to its own rate),
       rather than taking the globally-earliest rows. This stops an older batch
       with a large overdue backlog from monopolising every cycle and starving
       newer batches. A single campaign still sends exactly one row per interval. */
    const dueBatches = await all(
      `SELECT batch_id, MIN(scheduled_at) AS next_at
         FROM email_bulk_queue
        WHERE status = 'pending' AND scheduled_at <= ?
        GROUP BY batch_id
        ORDER BY next_at ASC`,
      [nowUnix()]
    );
    /* Rate guard: even when many rows are overdue (e.g. the app slept and a
       backlog built up), never send faster than the batch's configured rate.
       The interval is derived from the original scheduled spacing, and a batch
       only sends again once that long has passed since its last send. */
    const batchInterval = async (batchId) => {
      const meta = await get(
        `SELECT COUNT(*) AS n, MIN(scheduled_at) AS first_at, MAX(scheduled_at) AS last_at
         FROM email_bulk_queue WHERE batch_id = ?`,
        [batchId]
      );
      const n = Number(meta?.n) || 0;
      return n > 1 ? Math.max(0, Math.round((Number(meta.last_at) - Number(meta.first_at)) / (n - 1))) : 0;
    };

    let sentThisTick = 0;
    for (const b of Array.isArray(dueBatches) ? dueBatches : []) {
      if (sentThisTick >= maxPerTick) break;
      const batchId = String(b.batch_id || "");
      if (!batchId) continue;
      let row = null;
      try {
        // Keep each campaign at its own pace — skip it if it sent within its interval.
        const interval = await batchInterval(batchId);
        if (interval > 0) {
          const lastSent = await get(
            `SELECT MAX(sent_at) AS t FROM email_bulk_queue WHERE batch_id = ? AND sent_at IS NOT NULL`,
            [batchId]
          );
          if (lastSent?.t && nowUnix() - Number(lastSent.t) < interval) {
            continue; // this batch sent recently — its turn comes next cycle
          }
        }
        // Take this batch's earliest due row.
        row = await get(
          `SELECT * FROM email_bulk_queue
            WHERE batch_id = ? AND status = 'pending' AND scheduled_at <= ?
            ORDER BY scheduled_at ASC, id ASC LIMIT 1`,
          [batchId, nowUnix()]
        );
        if (!row) continue;
        // Re-check the opt-out flag at send time — it may have been set after queueing.
        const contact = row.contact_id
          ? await get(`SELECT * FROM contacts WHERE id = ?`, [row.contact_id])
          : null;
        if (contact && String(contact.do_not_email || "") === "1") {
          await run(`UPDATE email_bulk_queue SET status = 'skipped', error = 'Do Not Email set' WHERE id = ?`, [row.id]);
          continue;
        }
        // Body/subject/from live once per batch (not per recipient) so the queue
        // stays tiny; merge them in here. Fall back to any row-level copy (old rows).
        const batch = await get(
          `SELECT subject, from_email, body_html, body_text FROM email_bulk_batch WHERE batch_id = ?`,
          [batchId]
        );
        const sendRow = batch
          ? {
              ...row,
              subject: row.subject || batch.subject || "",
              from_email: row.from_email || batch.from_email || "",
              body_html: row.body_html || batch.body_html || "",
              body_text: row.body_text || batch.body_text || ""
            }
          : row;
        await sendOne({ row: sendRow, contact });
        await run(`UPDATE email_bulk_queue SET status = 'sent', sent_at = ?, error = '' WHERE id = ?`, [nowUnix(), row.id]);
        sentThisTick += 1;
      } catch (err) {
        const message = String((err && err.message) || err || "send failed").slice(0, 480);
        if (row && row.id) {
          await run(`UPDATE email_bulk_queue SET status = 'failed', error = ? WHERE id = ?`, [message, row.id]);
        }
        console.error(`[email-bulk] send failed for batch ${batchId}:`, message);
      }
    }
  } finally {
    processing = false;
  }
}

function startEmailBulkScheduler(deps) {
  // Keep this interval "ref'd" so the Node process is less likely to idle-exit
  // between HTTP requests. On cPanel Passenger the process can still sleep when
  // there is zero traffic — pair this with /api/health or /api/cron/email-queue
  // (external cron every 1–5 minutes) so campaigns send while nobody is logged in.
  const hosted = String(process.env.NODE_ENV || "").toLowerCase() === "production";
  const tickMs = Number(process.env.EMAIL_BULK_TICK_MS || (hosted ? 45_000 : 120_000));
  const tick = () => {
    processDueBulkEmails(deps).catch((err) => console.error("[email-bulk] scheduler error:", err));
  };
  const id = setInterval(tick, tickMs);
  setTimeout(tick, hosted ? 5000 : 25000);
  return () => clearInterval(id);
}

module.exports = {
  previewEmailBulkCampaign,
  queueEmailBulkCampaign,
  emailBulkCampaignStatus,
  emailBulkCampaignActiveList,
  cancelEmailBulkCampaign,
  pauseEmailBulkCampaign,
  resumeEmailBulkCampaign,
  pruneEmailBulkQueue,
  processDueBulkEmails,
  startEmailBulkScheduler,
  clampPerHour
};
