"use strict";

const { EMAIL_ASSET_ORIGIN, ctaButton } = require("./emailTemplateBranding");

/** PNG letterhead (Gmail strips SVG images, so never use favicon.svg in email). */
const LETTERHEAD_LOGO = `${EMAIL_ASSET_ORIGIN}/email-assets/cadence-letterhead.png`;
const TRIAL_URL = "https://crmcadence.com";
/** Marketing landing page — sells the trial first, then links to the signup form.
 *  The intro letter's CTA points here (not straight at the signup form). */
const WELCOME_URL = "https://crmcadence.com/welcome.html";

const CATEGORY_NAME = "Cadence Outreach";

/** Branded letter shell: PNG letterhead on top, white card, compliance footer.
 *  "[Your name]" style placeholders are meant to be edited once in the template UI. */
function letterheadHtml(innerHtml) {
  const header = `<table cellpadding="0" cellspacing="0" border="0" width="100%" role="presentation"><tr><td align="center" style="padding:26px 20px 18px;background:#ffffff;border-bottom:1px solid #e2e8f0;">
<a href="${TRIAL_URL}" style="text-decoration:none;"><img src="${LETTERHEAD_LOGO}" alt="Cadence CRM — Built for Health Insurance Agents" width="320" style="display:block;width:320px;max-width:90%;height:auto;border:0;" /></a>
</td></tr></table>`;
  const footer = `<table cellpadding="0" cellspacing="0" border="0" width="100%" role="presentation"><tr><td align="center" style="padding:18px 20px;background:#f8fafc;border-top:1px solid #e2e8f0;font-size:12px;color:#64748b;font-family:Arial,sans-serif;line-height:1.6;">
<a href="${TRIAL_URL}" style="color:#4f46e5;font-weight:700;text-decoration:none;">Cadence CRM</a> · Built for health insurance agents<br/>
[Your agency name] · [Your mailing address]<br/>
Don&#8217;t want these emails? <a href="{{unsubscribe_url}}" style="color:#64748b;">Unsubscribe here</a> or reply &#8220;unsubscribe&#8221;.
</td></tr></table>`;
  return `<table cellpadding="0" cellspacing="0" border="0" width="100%" role="presentation" style="background:#e2e8f0;font-family:Arial,sans-serif;">
<tr><td align="center" style="padding:24px 12px;">
<table cellpadding="0" cellspacing="0" border="0" width="600" style="max-width:600px;width:100%;background:#ffffff;border-radius:14px;overflow:hidden;">
<tr><td>
${header}
<div style="padding:26px 24px 8px;color:#0f172a;font-size:16px;line-height:1.6;">${innerHtml}</div>
${footer}
</td></tr></table>
</td></tr></table>`;
}

const pTag = (html) => `<p style="margin:0 0 14px;">${html}</p>`;
const signoff = (line) => `<p style="margin:18px 0 0;">${line},<br/><strong>[Your name]</strong><br/>Cadence CRM</p>`;

const CADENCE_OUTREACH_TEMPLATES = [
  // ── Generic intro letter ────────────────────────────────────────────────
  {
    name: "Cadence — Intro Letter (The future of CRM is here)",
    category_name: CATEGORY_NAME,
    subject: "The future of CRM is here — meet Cadence",
    body: letterheadHtml(
      pTag("Hi {{first_name}},") +
      pTag("What if your CRM actually understood health insurance?") +
      pTag("Meet <strong>Cadence</strong> — the only CRM built exclusively for health insurance agents. Not a generic CRM with insurance features bolted on. One industry, built from the ground up: ours.") +
      pTag("Here&#8217;s what that looks like:") +
      `<ul style="margin:0 0 14px;padding-left:22px;">
<li style="margin:0 0 10px;"><strong>Your personal AI assistant</strong> — drafts letters, call scripts, voicemails, and fresh campaign ideas for you in seconds.</li>
<li style="margin:0 0 10px;"><strong>An AI coach in your corner</strong> — helps you handle any objection and tells you exactly when and how to follow up.</li>
<li style="margin:0 0 10px;"><strong>Automations that work while you sell</strong> — emails and texts go out automatically, on the schedule you choose.</li>
<li style="margin:0 0 10px;"><strong>Everything in one place</strong> — call, text, and email your entire book of business without ever leaving the app.</li>
</ul>` +
      pTag("<strong>The future of CRM is here.</strong>") +
      pTag("See it with your own clients — free for 14 days, no credit card, then $79/month.") +
      ctaButton(WELCOME_URL, "Start your free 14-day trial") +
      signoff("Best")
    )
  },

  // ── Private Health drip ─────────────────────────────────────────────────
  {
    name: "Cadence — Private Health 1 of 3 (Intro)",
    category_name: CATEGORY_NAME,
    subject: "{{first_name}}, still tracking follow-ups on sticky notes?",
    body: letterheadHtml(
      pTag("Hi {{first_name}},") +
      pTag("Private health is a relationship business — dozens or hundreds of individual clients, off-exchange and supplemental plans, and follow-ups that can&#8217;t be allowed to slip. Most CRMs aren&#8217;t built for that.") +
      pTag("<strong>Cadence</strong> is. Your whole book in one place: call + text from the browser, follow-up reminders so no client falls through the cracks, and AI that summarizes your calls and flags cross-sell openings (dental, vision, supplemental, life).") +
      pTag("See it with your own clients — free 14-day trial, no card:") +
      ctaButton(TRIAL_URL, "Start your free trial") +
      signoff("Best")
    )
  },
  {
    name: "Cadence — Private Health 2 of 3 (Follow-ups & cross-sells)",
    category_name: CATEGORY_NAME,
    subject: "never miss a follow-up (or a cross-sell) again",
    body: letterheadHtml(
      pTag("Hi {{first_name}},") +
      pTag("The private health agents who switch to Cadence had the same problem — follow-ups slipping through the cracks, and cross-sell openings (dental, vision, supplemental, life) getting forgotten.") +
      pTag("Cadence reminds you exactly who to call and when, keeps each client&#8217;s plan + notes in one view, and its AI nudges you on who&#8217;s ready for a cross-sell. Set up automated email and text campaigns on the schedule you choose, and your whole book stays warm — even while you&#8217;re selling.") +
      ctaButton(TRIAL_URL, "Start your free trial") +
      signoff("Best")
    )
  },
  {
    name: "Cadence — Private Health 3 of 3 (Soft breakup)",
    category_name: CATEGORY_NAME,
    subject: "should I close your file, {{first_name}}?",
    body: letterheadHtml(
      pTag("Hi {{first_name}},") +
      pTag("Last note — I won&#8217;t clutter your inbox. If an all-in-one CRM for private health agents (follow-ups, cross-sells, calls/texts, AI — $79/mo) isn&#8217;t a fit right now, no worries.") +
      pTag("If you&#8217;re curious, the free 14-day trial is the easiest way to see it with your own book:") +
      ctaButton(TRIAL_URL, "Start your free trial") +
      signoff("Wishing you a strong year")
    )
  },

  // ── ACA drip ────────────────────────────────────────────────────────────
  {
    name: "Cadence — ACA 1 of 3 (OEP intro)",
    category_name: CATEGORY_NAME,
    subject: "{{first_name}}, surviving OEP on a spreadsheet?",
    body: letterheadHtml(
      pTag("Hi {{first_name}},") +
      pTag("ACA is a volume + deadline business — the OEP crush, SEPs all year, subsidy clients, and re-enrollments every season. Generic CRMs buckle under it.") +
      pTag("<strong>Cadence</strong> is built for it: bulk call + text from the browser, a pipeline made for enrollments, automatic re-enrollment reminders, and AI that scores leads and writes your call summaries so you keep up during the rush.") +
      pTag("See it with your own book — free 14-day trial, no card:") +
      ctaButton(TRIAL_URL, "Start your free trial") +
      signoff("Best")
    )
  },
  {
    name: "Cadence — ACA 2 of 3 (OEP surge)",
    category_name: CATEGORY_NAME,
    subject: "handle the OEP surge without dropping clients",
    body: letterheadHtml(
      pTag("Hi {{first_name}},") +
      pTag("The ACA agents who move to Cadence were all fighting the same thing — too many leads during OEP, no fast way to call/text at volume, and re-enrollments slipping away.") +
      pTag("Cadence gives you click-to-call and texting at scale, an enrollment pipeline so nobody falls through, and reminders that bring every client back at re-enrollment time. AI handles your call notes and ranks who to call first.") +
      ctaButton(TRIAL_URL, "Start your free trial") +
      signoff("Best")
    )
  },
  {
    name: "Cadence — ACA 3 of 3 (Soft breakup)",
    category_name: CATEGORY_NAME,
    subject: "should I close your file, {{first_name}}?",
    body: letterheadHtml(
      pTag("Hi {{first_name}},") +
      pTag("Last note, keeping it short. If a CRM built for ACA agents (bulk calls/texts, enrollment pipeline, re-enrollment reminders, AI — $79/mo) isn&#8217;t a fit right now, all good.") +
      pTag("If you&#8217;re curious, the free trial is the easiest way to see it before the next enrollment window:") +
      ctaButton(TRIAL_URL, "Start your free trial") +
      signoff("Wishing you a strong season")
    )
  }
];

/** Idempotent: skips any template whose name already exists, so edits made in
 *  the UI are never overwritten by a later restart. */
async function seedCadenceOutreachTemplates({ run, get }) {
  const created = [];
  const skipped = [];
  for (const tpl of CADENCE_OUTREACH_TEMPLATES) {
    const existing = await get(`SELECT id FROM email_templates WHERE name = ?`, [tpl.name]);
    if (existing) {
      skipped.push(tpl.name);
      continue;
    }
    let categoryId = null;
    if (tpl.category_name) {
      const cat = await get(
        `SELECT id FROM email_template_categories WHERE LOWER(name) = LOWER(?)`,
        [tpl.category_name]
      );
      if (cat) {
        categoryId = Number(cat.id);
      } else {
        const ins = await run(`INSERT INTO email_template_categories (name) VALUES (?)`, [tpl.category_name]);
        categoryId = Number(ins.lastID);
      }
    }
    const result = await run(
      `INSERT INTO email_templates (name, subject, body, category_id) VALUES (?, ?, ?, ?)`,
      [tpl.name, tpl.subject, tpl.body, categoryId]
    );
    created.push({ id: result.lastID, name: tpl.name });
  }
  /* Repoint the intro letter's CTA button from the bare root to the welcome
     landing page, in case the template was seeded before this change. Targets
     ONLY the button href (its unique inline style), so the logo/footer links
     and any UI edits are untouched. Idempotent — a no-op once already fixed. */
  const oldCta = `href="${TRIAL_URL}" style="display:inline-block`;
  const newCta = `href="${WELCOME_URL}" style="display:inline-block`;
  await run(
    `UPDATE email_templates SET body = REPLACE(body, ?, ?)
     WHERE name = ? AND body LIKE '%' || ? || '%'`,
    [oldCta, newCta, "Cadence — Intro Letter (The future of CRM is here)", oldCta]
  );
  return { created, skipped, total: CADENCE_OUTREACH_TEMPLATES.length };
}

module.exports = {
  CADENCE_OUTREACH_TEMPLATES,
  seedCadenceOutreachTemplates
};
