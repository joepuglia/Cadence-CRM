"use strict";

module.exports = require("../public/signup-validation.js");
