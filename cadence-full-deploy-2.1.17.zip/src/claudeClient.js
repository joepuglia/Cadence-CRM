function sanitizeAnthropicApiKey(raw) {
  let key = String(raw || "").trim();
  if (
    (key.startsWith('"') && key.endsWith('"')) ||
    (key.startsWith("'") && key.endsWith("'"))
  ) {
    key = key.slice(1, -1).trim();
  }
  return key.replace(/[\u200B-\u200D\uFEFF]/g, "");
}

const CLAUDE_USAGE_LIMIT_MESSAGE =
  "Claude API usage or credit limit reached. This is the Anthropic key on the CRM server (console.anthropic.com), not Cursor credits. Add billing or wait for the limit to reset, then try again.";

function isClaudeUsageLimitError(raw, code, status) {
  const msg = String(raw || "");
  const c = String(code || "").trim().toLowerCase();
  return (
    /credit|balance|billing|quota|payment|purchase credits|insufficient|limit reached|\berror:\s*limit\b|\blimit\b|rate.?limit|usage limit|spend limit|getAI|getAllVoices/i.test(
      msg
    ) ||
    c === "insufficient_quota" ||
    c === "rate_limit_error" ||
    Number(status) === 429
  );
}

function getClaudeConfig() {
  const apiKey = sanitizeAnthropicApiKey(process.env.ANTHROPIC_API_KEY);
  const model = String(process.env.CLAUDE_MODEL || "claude-sonnet-4-6").trim();
  const keyLooksValid = /^sk-ant-/.test(apiKey) && apiKey.length >= 80;
  const configured = Boolean(apiKey);
  return {
    apiKey,
    model,
    configured,
    keyLooksValid,
    keyLength: apiKey.length,
    noApiKey: !configured,
    noApiKeyMessage:
      "AI is included with Cadence, and it is not turned on for this site yet."
  };
}

function formatClaudeError(data, response) {
  const raw = String(data?.error?.message || (typeof data?.error === "string" ? data.error : "") || "").trim();
  const code = String(data?.error?.type || "").trim().toLowerCase();
  if (isClaudeUsageLimitError(raw, code, response?.status)) {
    return CLAUDE_USAGE_LIMIT_MESSAGE;
  }
  if (response?.status === 401 || /authentication|invalid.*api.*key/i.test(raw)) {
    return "AI is included with Cadence, but the site key was rejected. The site owner needs to save a new Claude key.";
  }
  return raw || "Claude request failed.";
}

function formatClaudeNetworkError(error) {
  const msg = String(error?.message || error || "").trim();
  if (error?.name === "AbortError" || /abort|timeout/i.test(msg)) {
    return "Claude request timed out. Try again with less context or a shorter request.";
  }
  if (/fetch failed|network|ENOTFOUND|ECONNREFUSED|ETIMEDOUT|certificate/i.test(msg)) {
    return (
      "Could not reach Claude from this server. Try again in a moment."
    );
  }
  return msg || "Claude request failed.";
}

function stripJsonFences(text) {
  const trimmed = String(text || "").trim();
  const fenced = trimmed.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
  return fenced ? String(fenced[1] || "").trim() : trimmed;
}

function repairJsonText(text) {
  return String(text || "")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/,\s*([}\]])/g, "$1");
}

function extractBalancedJsonObject(text, startIdx = 0) {
  const source = String(text || "");
  const start = source.indexOf("{", startIdx);
  if (start < 0) return null;
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let i = start; i < source.length; i += 1) {
    const ch = source[i];
    if (escaped) {
      escaped = false;
      continue;
    }
    if (ch === "\\") {
      escaped = true;
      continue;
    }
    if (ch === '"') {
      inString = !inString;
      continue;
    }
    if (inString) continue;
    if (ch === "{") depth += 1;
    if (ch === "}") {
      depth -= 1;
      if (depth === 0) return source.slice(start, i + 1);
    }
  }
  return null;
}

function parseClaudeJsonContent(content) {
  const raw = String(content || "").trim();
  if (!raw) return null;

  const attempts = [];
  attempts.push(stripJsonFences(raw));

  const inlineFence = raw.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  if (inlineFence) attempts.push(String(inlineFence[1] || "").trim());

  const balanced = extractBalancedJsonObject(raw);
  if (balanced) attempts.push(balanced);

  const preamble = raw.replace(/^[\s\S]*?(?=\{)/, "").trim();
  if (preamble && preamble !== raw) attempts.push(preamble);

  for (const candidate of attempts) {
    if (!candidate) continue;
    for (const variant of [candidate, repairJsonText(candidate)]) {
      try {
        return JSON.parse(variant);
      } catch {
        /* try next */
      }
    }
  }
  return null;
}

function getClaudeTimeoutMs(value) {
  const n = Number(value);
  if (Number.isFinite(n) && n > 0) return Math.max(5_000, Math.min(n, 120_000));
  return 45_000;
}

async function callClaudeJson({ system, user, maxTokens = 1200, timeoutMs } = {}) {
  const { apiKey, model } = getClaudeConfig();
  if (!apiKey) {
    const err = new Error("AI is not configured on this server.");
    err.statusCode = 503;
    throw err;
  }

  const controller = typeof AbortController !== "undefined" ? new AbortController() : null;
  const resolvedTimeoutMs = getClaudeTimeoutMs(timeoutMs || process.env.CLAUDE_TIMEOUT_MS);
  const timeout = controller
    ? setTimeout(() => {
        controller.abort();
      }, resolvedTimeoutMs)
    : null;
  if (timeout && typeof timeout.unref === "function") timeout.unref();

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      signal: controller?.signal,
      headers: {
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model,
        max_tokens: maxTokens,
        system: `${system}\n\nRespond with valid JSON only. No markdown fences or commentary.`,
        messages: [{ role: "user", content: user }],
        temperature: 0.2
      })
    });

    let data = {};
    try {
      data = await response.json();
    } catch {
      data = {};
    }

    if (!response.ok) {
      const err = new Error(formatClaudeError(data, response));
      err.statusCode = response.status >= 400 && response.status < 600 ? response.status : 502;
      throw err;
    }

    const blocks = Array.isArray(data?.content) ? data.content : [];
    const content = blocks
      .filter((block) => block && block.type === "text")
      .map((block) => String(block.text || ""))
      .join("\n")
      .trim();

    if (!content) {
      const err = new Error("AI returned an empty response.");
      err.statusCode = 502;
      throw err;
    }

    const parsed = parseClaudeJsonContent(content);
    if (parsed != null) return parsed;

    const err = new Error("AI returned invalid JSON. Try again.");
    err.statusCode = 502;
    throw err;
  } catch (error) {
    if (error?.statusCode) throw error;
    const err = new Error(formatClaudeNetworkError(error));
    err.statusCode = error?.name === "AbortError" ? 504 : 502;
    throw err;
  } finally {
    if (timeout) clearTimeout(timeout);
  }
}

function normalizeClaudeMessages(messages, user) {
  const list = Array.isArray(messages)
    ? messages
        .map((m) => ({
          role: String(m?.role || "").trim() === "assistant" ? "assistant" : "user",
          content: String(m?.content || "").trim()
        }))
        .filter((m) => m.content)
    : [];
  if (list.length) return list;
  return [{ role: "user", content: String(user || "") }];
}

async function callClaudeText({ system, user, messages, maxTokens = 1400, temperature = 0.65, timeoutMs } = {}) {
  const { apiKey, model } = getClaudeConfig();
  if (!apiKey) {
    const err = new Error("AI is included with Cadence, and it is not turned on for this site yet.");
    err.statusCode = 503;
    throw err;
  }

  const controller = typeof AbortController !== "undefined" ? new AbortController() : null;
  const resolvedTimeoutMs = getClaudeTimeoutMs(timeoutMs || process.env.CLAUDE_TIMEOUT_MS);
  const timeout = controller
    ? setTimeout(() => {
        controller.abort();
      }, resolvedTimeoutMs)
    : null;
  if (timeout && typeof timeout.unref === "function") timeout.unref();

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      signal: controller?.signal,
      headers: {
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model,
        max_tokens: maxTokens,
        system: String(system || ""),
        messages: normalizeClaudeMessages(messages, user),
        temperature
      })
    });

    let data = {};
    try {
      data = await response.json();
    } catch {
      data = {};
    }

    if (!response.ok) {
      const err = new Error(formatClaudeError(data, response));
      err.statusCode = response.status >= 400 && response.status < 600 ? response.status : 502;
      throw err;
    }

    const blocks = Array.isArray(data?.content) ? data.content : [];
    const content = blocks
      .filter((block) => block && block.type === "text")
      .map((block) => String(block.text || ""))
      .join("\n")
      .trim();

    if (!content) {
      const err = new Error("AI returned an empty response. Try again.");
      err.statusCode = 502;
      throw err;
    }
    return content;
  } catch (error) {
    if (error?.statusCode) throw error;
    const err = new Error(formatClaudeNetworkError(error));
    err.statusCode = error?.name === "AbortError" ? 504 : 502;
    throw err;
  } finally {
    if (timeout) clearTimeout(timeout);
  }
}


function maskAnthropicApiKey(token) {
  const s = sanitizeAnthropicApiKey(token);
  if (!s) return "";
  if (s.length <= 12) return "••••";
  return `${s.slice(0, 7)}…${s.slice(-4)}`;
}

async function verifyAnthropicApiKey(raw) {
  const apiKey = sanitizeAnthropicApiKey(raw);
  if (!apiKey) return { ok: false, error: "API key is missing." };
  if (!/^sk-ant-/.test(apiKey) || apiKey.length < 80) {
    return {
      ok: false,
      error: "This does not look like a full Claude API key. Copy the whole key from console.anthropic.com."
    };
  }
  let response;
  try {
    response = await fetch("https://api.anthropic.com/v1/models", {
      method: "GET",
      headers: {
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01"
      }
    });
  } catch (err) {
    return { ok: false, error: err.message || "Could not reach Anthropic." };
  }
  if (response.ok) return { ok: true };
  if (response.status === 401 || response.status === 403) {
    return { ok: false, error: "Anthropic rejected this API key." };
  }
  return { ok: false, error: `Anthropic returned status ${response.status}.` };
}

module.exports = {
  getClaudeConfig,
  sanitizeAnthropicApiKey,
  maskAnthropicApiKey,
  verifyAnthropicApiKey,
  parseClaudeJsonContent,
  callClaudeJson,
  callClaudeText,
  formatClaudeError,
  isClaudeUsageLimitError,
  CLAUDE_USAGE_LIMIT_MESSAGE
};
