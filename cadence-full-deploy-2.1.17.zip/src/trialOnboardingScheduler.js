/**
 * Trial onboarding email scheduler.
 *
 * Sends a timed sequence of emails to new trial users:
 *   step "day1"   — 24 h after signup   (getting started: 3 first steps)
 *   step "day5"   — 120 h after signup  (drip campaign builder spotlight)
 *   step "day8"   — 192 h after signup  (personal check-in from Joseph)
 *   step "day12"  — 288 h after signup  (trial ending soon — combo nudge)
 *
 * Each step runs once per signup. Duplicates are prevented by the
 * (email, step) UNIQUE constraint on trial_onboarding_sent.
 */

const { sendTrialWelcomeEmail } = require("./emailService");

const PRO_MONTHLY_USD = Number(process.env.STRIPE_MONTHLY_USD || 79);

function getLoginBase() {
  return String(process.env.TRIAL_WELCOME_LOGIN_URL || process.env.CRM_PUBLIC_URL || "https://crmcadence.com")
    .trim()
    .replace(/\/$/, "");
}

function sharedHeader() {
  return `
        <tr>
          <td style="background:linear-gradient(135deg,#312e81 0%,#4f46e5 60%,#7c3aed 100%);padding:32px 40px 28px;text-align:center;">
            <p style="margin:0 0 4px;font-size:1.5rem;font-weight:800;color:#ffffff;letter-spacing:-0.01em;">Cadence CRM</p>
            <p style="margin:0;font-size:0.88rem;color:rgba(255,255,255,0.80);font-weight:500;">Built for Health Insurance Agents</p>
          </td>
        </tr>`;
}

function sharedFooter() {
  return `
        <tr>
          <td style="background:#f8fafc;border-top:1px solid #e2e8f0;padding:20px 40px;text-align:center;">
            <p style="margin:0;font-size:0.8rem;color:#94a3b8;">
              © Cadence CRM &nbsp;·&nbsp; <a href="https://crmcadence.com" style="color:#4f46e5;text-decoration:none;">crmcadence.com</a> &nbsp;·&nbsp; <a href="mailto:support@crmcadence.com" style="color:#4f46e5;text-decoration:none;">support@crmcadence.com</a>
            </p>
          </td>
        </tr>`;
}

function wrapHtml(innerRows) {
  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:'Segoe UI',system-ui,sans-serif;color:#0f172a;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:40px 16px;">
    <tr><td align="center">
      <table width="100%" style="max-width:580px;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 8px 32px rgba(15,23,42,0.10);" cellpadding="0" cellspacing="0">
        ${sharedHeader()}
        ${innerRows}
        ${sharedFooter()}
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}

function signOff(short = false) {
  if (short) {
    return `
            <p style="margin:0 0 4px;font-size:0.97rem;color:#334155;font-weight:600;">Best regards,</p>
            <p style="margin:0 0 2px;font-size:0.97rem;color:#1e1b4b;font-weight:700;">Joseph R. Pugliares</p>
            <p style="margin:0;font-size:0.88rem;color:#64748b;">Founder, Cadence CRM</p>`;
  }
  return `
            <p style="margin:0 0 4px;font-size:0.97rem;color:#334155;font-weight:600;">Best regards,</p>
            <p style="margin:0 0 2px;font-size:0.97rem;color:#1e1b4b;font-weight:700;">Joseph R. Pugliares</p>
            <p style="margin:0;font-size:0.88rem;color:#64748b;">Founder, Cadence CRM &amp; Cadence Healthcare, LLC</p>`;
}

/* ─────────────────────────────────────────────
   DAY 1 — Getting started: 3 first steps
───────────────────────────────────────────── */
function buildDay1Email(signup) {
  const firstName = String(signup.first_name || "there").trim();
  const base = getLoginBase();
  const subject = `Getting started with Cadence, ${firstName}`;

  const text = [
    `Hi ${firstName},`,
    "",
    "It's Joseph — you signed up for Cadence CRM yesterday and I wanted to make sure you are set up for success.",
    "",
    "Here are the three most important things to do in your first few days:",
    "",
    "1. Add your first contacts",
    "   Head to the Contacts Workspace and start adding your leads. You can upload a CSV file or add them one by one. The AI assistant will even clean up a messy spreadsheet for you.",
    "",
    "2. Set up your pipeline",
    "   Go to Pipeline Summary and create stages that match your sales process — New Lead, Contacted, Quote Sent, Enrolled, and so on.",
    "",
    "3. Build your first drip campaign",
    "   Go to AI Campaign Builder, under AI Tools, and create a simple follow-up sequence for new leads. Even a basic 3-step drip will save you hours every week during open enrollment.",
    "",
    `Log in here: ${base}/login.html`,
    "",
    "If you run into anything or have a question, just reply to this email. I read every one.",
    "",
    "Best regards,",
    "Joseph R. Pugliares",
    "Founder, Cadence CRM & Cadence Healthcare, LLC"
  ].join("\n");

  const html = wrapHtml(`
        <tr>
          <td style="padding:36px 40px 32px;">
            <p style="margin:0 0 20px;font-size:1.05rem;color:#0f172a;">Hi ${firstName},</p>
            <p style="margin:0 0 24px;font-size:0.97rem;line-height:1.65;color:#334155;">
              It's Joseph — you signed up for Cadence CRM yesterday and I wanted to make sure you are set up for success.
              Here are the three most important things to do in your first few days:
            </p>

            <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:16px;">
              <tr>
                <td width="40" valign="top" style="padding-top:2px;">
                  <div style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;font-weight:800;font-size:0.88rem;text-align:center;line-height:28px;">1</div>
                </td>
                <td style="padding-left:12px;">
                  <p style="margin:0 0 4px;font-size:1rem;font-weight:700;color:#1e1b4b;">Add your first contacts</p>
                  <p style="margin:0;font-size:0.92rem;line-height:1.6;color:#475569;">Head to the Contacts Workspace and start adding your leads. You can upload a CSV file or add them one by one. The AI assistant will even clean up a messy spreadsheet for you.</p>
                </td>
              </tr>
            </table>

            <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:16px;">
              <tr>
                <td width="40" valign="top" style="padding-top:2px;">
                  <div style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;font-weight:800;font-size:0.88rem;text-align:center;line-height:28px;">2</div>
                </td>
                <td style="padding-left:12px;">
                  <p style="margin:0 0 4px;font-size:1rem;font-weight:700;color:#1e1b4b;">Set up your pipeline</p>
                  <p style="margin:0;font-size:0.92rem;line-height:1.6;color:#475569;">Go to Pipeline Summary and create stages that match your sales process — New Lead, Contacted, Quote Sent, Enrolled, and so on. A clear pipeline shows you exactly where every deal stands.</p>
                </td>
              </tr>
            </table>

            <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:32px;">
              <tr>
                <td width="40" valign="top" style="padding-top:2px;">
                  <div style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;font-weight:800;font-size:0.88rem;text-align:center;line-height:28px;">3</div>
                </td>
                <td style="padding-left:12px;">
                  <p style="margin:0 0 4px;font-size:1rem;font-weight:700;color:#1e1b4b;">Build your first drip campaign</p>
                  <p style="margin:0;font-size:0.92rem;line-height:1.6;color:#475569;">Go to AI Campaign Builder, under AI Tools, and create a simple follow-up sequence for new leads. Even a basic 3-step drip will save you hours every week — especially during open enrollment.</p>
                </td>
              </tr>
            </table>

            <div style="text-align:center;margin-bottom:32px;">
              <a href="${base}/login.html" style="display:inline-block;padding:14px 32px;background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;font-weight:700;font-size:1rem;text-decoration:none;border-radius:999px;">Log In to Cadence →</a>
            </div>

            <p style="margin:0 0 24px;font-size:0.97rem;line-height:1.65;color:#334155;">
              If you run into anything or have a question, just reply to this email. I read every one.
            </p>
            ${signOff()}
          </td>
        </tr>`);

  return { subject, text, html };
}

/* ─────────────────────────────────────────────
   DAY 5 — Drip campaign builder spotlight
───────────────────────────────────────────── */
function buildDay5Email(signup) {
  const firstName = String(signup.first_name || "there").trim();
  const base = getLoginBase();
  const subject = `The feature that saves agents the most time, ${firstName}`;

  const text = [
    `Hi ${firstName},`,
    "",
    "Of everything inside Cadence, the drip campaign builder is the feature agents tell me saves them the most time.",
    "",
    "Here is why: most health insurance leads do not respond to the first outreach. Or the second. Studies consistently show it takes five to eight touches before a prospect engages — but most agents give up after two.",
    "",
    "A drip campaign runs those follow-ups for you automatically, so every lead gets the full sequence whether you are on a call, at lunch, or done for the day.",
    "",
    "How to build your first campaign in Cadence:",
    "",
    "1. Go to AI Campaign Builder under AI Tools in the left navigation",
    "2. Click New Campaign and name it (e.g. \"New Lead Follow-Up\")",
    "3. Add steps: Day 0 email, Day 2 SMS, Day 5 email, Day 10 re-engagement",
    "4. Write each message — or ask the AI Assistant to draft them for you",
    "5. Save and enroll your first contacts",
    "",
    "Once it is running, every new lead you add to the campaign gets the full sequence without any manual effort.",
    "",
    `Log in and build yours now: ${base}/login.html`,
    "",
    "Best regards,",
    "Joseph R. Pugliares",
    "Founder, Cadence CRM & Cadence Healthcare, LLC"
  ].join("\n");

  const html = wrapHtml(`
        <tr>
          <td style="padding:36px 40px 32px;">
            <p style="margin:0 0 20px;font-size:1.05rem;color:#0f172a;">Hi ${firstName},</p>

            <p style="margin:0 0 16px;font-size:0.97rem;line-height:1.65;color:#334155;">
              Of everything inside Cadence, the <strong>drip campaign builder</strong> is the feature agents tell me saves them the most time.
            </p>
            <p style="margin:0 0 24px;font-size:0.97rem;line-height:1.65;color:#334155;">
              Here is why: most health insurance leads do not respond to the first outreach — or the second. Studies show it takes five to eight touches before a prospect engages, but most agents give up after two. A drip campaign runs those follow-ups automatically, so every lead gets the full sequence whether you are on a call, at lunch, or done for the day.
            </p>

            <!-- Steps box -->
            <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;margin-bottom:28px;">
              <tr><td style="padding:24px 28px;">
                <p style="margin:0 0 16px;font-size:0.82rem;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:#4f46e5;">Build your first campaign in 5 steps</p>
                <table cellpadding="0" cellspacing="0" width="100%">
                  <tr><td style="padding:5px 0;font-size:0.92rem;color:#334155;line-height:1.5;"><span style="font-weight:700;color:#4f46e5;">1.</span> &nbsp;Go to <strong>AI Campaign Builder</strong> under AI Tools in the left nav</td></tr>
                  <tr><td style="padding:5px 0;font-size:0.92rem;color:#334155;line-height:1.5;"><span style="font-weight:700;color:#4f46e5;">2.</span> &nbsp;Click <strong>New Campaign</strong> and give it a name</td></tr>
                  <tr><td style="padding:5px 0;font-size:0.92rem;color:#334155;line-height:1.5;"><span style="font-weight:700;color:#4f46e5;">3.</span> &nbsp;Add steps — Day 0 email, Day 2 SMS, Day 5 email, Day 10 re-engagement</td></tr>
                  <tr><td style="padding:5px 0;font-size:0.92rem;color:#334155;line-height:1.5;"><span style="font-weight:700;color:#4f46e5;">4.</span> &nbsp;Write each message — or let the <strong>AI Assistant</strong> draft them</td></tr>
                  <tr><td style="padding:5px 0;font-size:0.92rem;color:#334155;line-height:1.5;"><span style="font-weight:700;color:#4f46e5;">5.</span> &nbsp;Save and enroll your first contacts</td></tr>
                </table>
              </td></tr>
            </table>

            <p style="margin:0 0 28px;font-size:0.97rem;line-height:1.65;color:#334155;">
              Once it is running, every new lead you add gets the full sequence automatically — no manual effort required.
            </p>

            <div style="text-align:center;margin-bottom:32px;">
              <a href="${base}/login.html" style="display:inline-block;padding:14px 32px;background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;font-weight:700;font-size:1rem;text-decoration:none;border-radius:999px;">Build My First Campaign →</a>
            </div>

            ${signOff()}
          </td>
        </tr>`);

  return { subject, text, html };
}

/* ─────────────────────────────────────────────
   DAY 8 — Personal check-in from Joseph
───────────────────────────────────────────── */
function buildDay8Email(signup) {
  const firstName = String(signup.first_name || "there").trim();
  const base = getLoginBase();
  const subject = `How is Cadence working for you, ${firstName}?`;

  const text = [
    `Hi ${firstName},`,
    "",
    "It's Joseph. You are about halfway through your trial and I wanted to check in personally.",
    "",
    "How is Cadence working for you so far? Have you had a chance to add your contacts and set up your pipeline?",
    "",
    "If there is anything you are stuck on, anything that does not make sense, or any feature you wish worked differently — I want to hear it. Just hit reply. I read every email and respond personally.",
    "",
    "No automated response. No ticket system. Just me.",
    "",
    `If you have not logged in yet, now is a great time: ${base}/login.html`,
    "",
    "Either way, I appreciate you giving Cadence a shot.",
    "",
    "Best regards,",
    "Joseph R. Pugliares",
    "Founder, Cadence CRM & Cadence Healthcare, LLC"
  ].join("\n");

  const html = wrapHtml(`
        <tr>
          <td style="padding:36px 40px 40px;">
            <p style="margin:0 0 20px;font-size:1.05rem;color:#0f172a;">Hi ${firstName},</p>

            <p style="margin:0 0 16px;font-size:0.97rem;line-height:1.65;color:#334155;">
              It's Joseph. You are about halfway through your trial and I wanted to check in personally.
            </p>
            <p style="margin:0 0 16px;font-size:0.97rem;line-height:1.65;color:#334155;">
              How is Cadence working for you so far? Have you had a chance to add your contacts and set up your pipeline?
            </p>
            <p style="margin:0 0 28px;font-size:0.97rem;line-height:1.65;color:#334155;">
              If there is anything you are stuck on, anything that does not make sense, or any feature you wish worked differently — I want to hear it. <strong>Just hit reply.</strong> I read every email and respond personally. No automated response. No ticket system. Just me.
            </p>

            <div style="text-align:center;margin-bottom:32px;">
              <a href="${base}/login.html" style="display:inline-block;padding:14px 32px;background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;font-weight:700;font-size:1rem;text-decoration:none;border-radius:999px;">Log In to Cadence →</a>
            </div>

            <p style="margin:0 0 24px;font-size:0.97rem;line-height:1.65;color:#334155;">
              Either way, I appreciate you giving Cadence a shot.
            </p>

            ${signOff()}
          </td>
        </tr>`);

  return { subject, text, html };
}

/* ─────────────────────────────────────────────
   DAY 12 — Trial ending soon (combo nudge)
───────────────────────────────────────────── */
function buildDay12Email(signup) {
  const firstName = String(signup.first_name || "there").trim();
  const base = getLoginBase();
  const subject = `Your Cadence trial ends in 2 days, ${firstName}`;

  const text = [
    `Hi ${firstName},`,
    "",
    "Your 14-day Cadence CRM trial ends in 2 days.",
    "",
    "If Cadence has been useful — if it has helped you stay organized, follow up faster, or run even one campaign — I hope you will stick around. Continuing is $" + PRO_MONTHLY_USD + "/month and takes about 60 seconds to set up.",
    "",
    "What you keep when you subscribe:",
    "  - All your contacts, notes, and pipeline stages",
    "  - All drip campaigns and email templates you have built",
    "  - Full access to email, SMS, AI, documents, and reports",
    "  - Everything — nothing gets locked or deleted",
    "",
    "If you are not ready yet, no pressure. Your data will stay safe for 30 days after the trial ends.",
    "",
    "But if you are ready to keep going, here is the link:",
    `  ${base}/billing.html`,
    "",
    "And if you have any questions before deciding, just reply. I will answer personally.",
    "",
    "Best regards,",
    "Joseph R. Pugliares",
    "Founder, Cadence CRM & Cadence Healthcare, LLC"
  ].join("\n");

  const html = wrapHtml(`
        <tr>
          <td style="padding:36px 40px 32px;">
            <p style="margin:0 0 20px;font-size:1.05rem;color:#0f172a;">Hi ${firstName},</p>

            <!-- Urgency banner -->
            <table width="100%" cellpadding="0" cellspacing="0" style="background:linear-gradient(135deg,#312e81,#4f46e5);border-radius:12px;margin-bottom:28px;">
              <tr><td style="padding:20px 24px;text-align:center;">
                <p style="margin:0 0 4px;font-size:1.1rem;font-weight:800;color:#ffffff;">Your trial ends in 2 days</p>
                <p style="margin:0;font-size:0.88rem;color:rgba(255,255,255,0.85);">Continue for $${PRO_MONTHLY_USD}/month — cancel anytime</p>
              </td></tr>
            </table>

            <p style="margin:0 0 16px;font-size:0.97rem;line-height:1.65;color:#334155;">
              If Cadence has been useful — if it has helped you stay organized, follow up faster, or run even one campaign — I hope you will stick around.
            </p>

            <!-- What you keep -->
            <table width="100%" cellpadding="0" cellspacing="0" style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;margin-bottom:28px;">
              <tr><td style="padding:20px 24px;">
                <p style="margin:0 0 12px;font-size:0.88rem;font-weight:700;letter-spacing:0.06em;text-transform:uppercase;color:#16a34a;">What you keep when you subscribe</p>
                <table cellpadding="0" cellspacing="0">
                  <tr><td style="padding:4px 0;font-size:0.92rem;color:#334155;line-height:1.5;">✓ &nbsp;All your contacts, notes, and pipeline stages</td></tr>
                  <tr><td style="padding:4px 0;font-size:0.92rem;color:#334155;line-height:1.5;">✓ &nbsp;All drip campaigns and email templates you have built</td></tr>
                  <tr><td style="padding:4px 0;font-size:0.92rem;color:#334155;line-height:1.5;">✓ &nbsp;Full access to email, SMS, AI, documents, and reports</td></tr>
                  <tr><td style="padding:4px 0;font-size:0.92rem;color:#334155;line-height:1.5;">✓ &nbsp;Everything — nothing gets locked or deleted</td></tr>
                </table>
              </td></tr>
            </table>

            <div style="text-align:center;margin-bottom:24px;">
              <a href="${base}/billing.html" style="display:inline-block;padding:14px 32px;background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;font-weight:700;font-size:1rem;text-decoration:none;border-radius:999px;">Keep My Access — $${PRO_MONTHLY_USD}/mo →</a>
            </div>

            <p style="margin:0 0 24px;font-size:0.9rem;line-height:1.65;color:#64748b;text-align:center;">
              Not ready yet? No pressure — your data stays safe for 30 days after the trial ends.<br>
              Questions? Just reply and I will answer personally.
            </p>

            ${signOff(true)}
          </td>
        </tr>`);

  return { subject, text, html };
}

/* ─────────────────────────────────────────────
   STEPS registry
───────────────────────────────────────────── */
const STEPS = [
  { step: "day1",  delayHours: 24,  buildEmail: buildDay1Email  },
  { step: "day5",  delayHours: 120, buildEmail: buildDay5Email  },
  { step: "day8",  delayHours: 192, buildEmail: buildDay8Email  },
  { step: "day12", delayHours: 288, buildEmail: buildDay12Email }
];

/* ─────────────────────────────────────────────
   Scheduler
───────────────────────────────────────────── */
let processing = false;

async function processTrialOnboarding(deps) {
  const { all, run } = deps;
  if (processing) return;
  processing = true;
  try {
    const nowSec = Math.floor(Date.now() / 1000);

    for (const step of STEPS) {
      const minAgeSec = step.delayHours * 3600;
      // Max window = delayHours + 48 h to avoid mailing very stale/inactive signups
      const maxAgeSec = minAgeSec + 48 * 3600;

      const signups = await all(`
        SELECT s.id, s.first_name, s.last_name, s.email, s.agency_name, s.created_at
        FROM subscription_signups s
        WHERE s.status = 'trial_active'
          AND (? - s.created_at) >= ?
          AND (? - s.created_at) <  ?
          AND NOT EXISTS (
            SELECT 1 FROM trial_onboarding_sent t
            WHERE t.email = s.email AND t.step = ?
          )
      `, [nowSec, minAgeSec, nowSec, maxAgeSec, step.step]);

      for (const signup of signups) {
        try {
          const { subject, text, html } = step.buildEmail(signup);
          const result = await sendTrialWelcomeEmail({ to: signup.email, subject, text, html });
          await run(
            `INSERT OR IGNORE INTO trial_onboarding_sent (email, step) VALUES (?, ?)`,
            [signup.email, step.step]
          );
          console.log(`[onboarding] Sent ${step.step} to ${signup.email} — via ${result.via || "unknown"}`);
        } catch (err) {
          console.error(`[onboarding] Failed ${step.step} for ${signup.email}:`, err.message || err);
        }
      }
    }
  } catch (err) {
    console.error("[onboarding] Scheduler error:", err.message || err);
  } finally {
    processing = false;
  }
}

function startTrialOnboardingScheduler(deps) {
  const tickMs = Number(process.env.TRIAL_ONBOARDING_TICK_MS || 10 * 60 * 1000); // default: every 10 min
  const tick = () => {
    processTrialOnboarding(deps).catch((err) =>
      console.error("[onboarding] Unhandled error:", err)
    );
  };
  const id = setInterval(tick, tickMs);
  setTimeout(tick, 15000); // first run 15 s after boot
  return () => clearInterval(id);
}

module.exports = { startTrialOnboardingScheduler, processTrialOnboarding };
