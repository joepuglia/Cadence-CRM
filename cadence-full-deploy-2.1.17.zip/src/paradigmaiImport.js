"use strict";

const fs = require("fs");
const path = require("path");
const { parseContactsCsv, resolveImportCreatedAtSql } = require("./csvImport");

const PARADIGMAI_CSV_NAME = "paradigmai-cadence-import.csv";

function getParadigmaiCsvPath() {
  return path.join(__dirname, "..", "public", PARADIGMAI_CSV_NAME);
}

function loadParadigmaiCsvText() {
  const csvPath = getParadigmaiCsvPath();
  if (!fs.existsSync(csvPath)) {
    throw new Error(`Paradigmai import file missing on server (${PARADIGMAI_CSV_NAME}). Re-deploy public/.`);
  }
  return fs.readFileSync(csvPath, "utf8");
}

async function importContactRows(contacts, { run, scheduleAutoLeadScore, dbDeps, preserveCsvCreatedDates = true, createdAtMapped = true } = {}) {
  let imported = 0;
  const importedContactIds = [];
  for (const row of contacts) {
    const { fragment: createdAtSql, params: createdAtParam } = resolveImportCreatedAtSql(row, {
      preserveCsvCreatedDates,
      createdAtMapped
    });
    const result = await run(
      `INSERT INTO contacts (
          full_name, email, phone, secondary_phone, status, tags, notes, special_notes,
          app_id,
          age, gender, household_size, income, lead_source, communication_type,
          date_of_contact, outcome, date_of_birth, coverages_sold, profession, quote,
          health_issues, coverage_start_date, bank_routing, bank_account, vcall, commission,
          home_address, city, state, zip_code, indian, last_called, last_emailed,
          created_at, updated_at
        )
         VALUES (
          ?, ?, ?, ?, ?, ?, ?, ?,
          ?,
          ?, ?, ?, ?, ?, ?,
          ?, ?, ?, ?, ?, ?,
          ?, ?, ?, ?, ?, ?,
          ?, ?, ?, ?, ?, ?, ?,
          ${createdAtSql}, CURRENT_TIMESTAMP
         )`,
      [
        row.full_name,
        row.email,
        row.phone,
        row.secondary_phone,
        row.status,
        row.tags,
        row.notes,
        row.special_notes,
        row.app_id,
        row.age,
        row.gender,
        row.household_size,
        row.income,
        row.lead_source,
        row.communication_type,
        row.date_of_contact,
        row.outcome,
        row.date_of_birth,
        row.coverages_sold,
        row.profession,
        row.quote,
        row.health_issues,
        row.coverage_start_date,
        row.bank_routing,
        row.bank_account,
        row.vcall,
        row.commission,
        row.home_address,
        row.city,
        row.state,
        row.zip_code,
        row.indian,
        row.last_called,
        row.last_emailed,
        ...createdAtParam
      ]
    );
    if (result?.lastID) importedContactIds.push(result.lastID);
    imported += 1;
  }
  if (scheduleAutoLeadScore && dbDeps) {
    importedContactIds.forEach((contactId) => {
      scheduleAutoLeadScore(dbDeps(), contactId, "csv_import");
    });
  }
  return { imported, importedContactIds };
}

async function importParadigmaiBundle({ run, get, scheduleAutoLeadScore, dbDeps, skipDuplicates = true } = {}) {
  const csv = loadParadigmaiCsvText();
  const { contacts, parseErrors } = parseContactsCsv(csv);
  if (!contacts.length) {
    throw new Error(parseErrors.length ? "No valid Paradigmai rows to import." : "Paradigmai CSV is empty.");
  }

  let skipped = 0;
  const toImport = [];
  for (const row of contacts) {
    if (skipDuplicates && get) {
      const email = String(row.email || "").trim().toLowerCase();
      const name = String(row.full_name || "").trim();
      let existing = null;
      if (email) {
        existing = await get(`SELECT id FROM contacts WHERE LOWER(TRIM(email)) = ? LIMIT 1`, [email]);
      }
      if (!existing && name) {
        existing = await get(`SELECT id FROM contacts WHERE TRIM(full_name) = ? LIMIT 1`, [name]);
      }
      if (existing) {
        skipped += 1;
        continue;
      }
    }
    toImport.push(row);
  }

  const { imported } = await importContactRows(toImport, { run, scheduleAutoLeadScore, dbDeps });
  return {
    imported,
    skipped,
    totalInFile: contacts.length,
    parseErrors: parseErrors.length
  };
}

module.exports = {
  PARADIGMAI_CSV_NAME,
  getParadigmaiCsvPath,
  loadParadigmaiCsvText,
  importParadigmaiBundle
};
