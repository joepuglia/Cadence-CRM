#!/usr/bin/env node
/**
 * One-time repair for a bloated CRM database — run from cPanel:
 *   Setup Node.js App  ->  Run JS Script  ->  db:repair
 * (Best with the Node app STOPPED first so this has the database to itself, and
 *  don't open the site while it runs.)
 *
 * SAFE: it only clears the email send-queue (junk — a full per-recipient copy of
 * every campaign email). It never touches contacts, templates, users, settings,
 * activities, or anything else. Steps:
 *   1. Merge the WAL file back into the database (so no recent data is lost).
 *   2. Switch off WAL (back to the classic journal).
 *   3. Drop the bloated email_bulk_queue table (the app recreates it empty on start).
 *   4. VACUUM to compact the file and reclaim disk space.
 *
 * It is idempotent and resilient: steps 1-3 commit before the (longer) VACUUM, so
 * even if VACUUM is interrupted the database is already healthy — just re-run to
 * finish compacting.
 */
const path = require("path");
const fs = require("fs");
const sqlite3 = require("sqlite3").verbose();

const dbPath = process.env.CRM_DB_PATH || path.join(__dirname, "..", "crm.sqlite");

function run(db, sql) {
  return new Promise((resolve, reject) => {
    db.run(sql, function (err) {
      if (err) reject(err);
      else resolve(this);
    });
  });
}
function get(db, sql) {
  return new Promise((resolve, reject) => {
    db.get(sql, (err, row) => (err ? reject(err) : resolve(row)));
  });
}
function sizeOf(p) {
  try {
    return (fs.statSync(p).size / 1e9).toFixed(2) + " GB";
  } catch (e) {
    return "(none)";
  }
}
function log(msg) {
  console.log(`[db-repair] ${msg}`);
}

(async () => {
  log(`database: ${dbPath}`);
  log(`size before:  crm.sqlite=${sizeOf(dbPath)}   wal=${sizeOf(dbPath + "-wal")}`);

  const db = new sqlite3.Database(dbPath);
  try {
    await run(db, "PRAGMA busy_timeout = 120000"); // wait up to 2 min for any lock

    const before = await get(db, "SELECT COUNT(*) AS n FROM email_bulk_queue").catch(() => ({ n: "?" }));
    log(`email_bulk_queue rows to clear: ${before.n}`);
    const contactsBefore = await get(db, "SELECT COUNT(*) AS n FROM contacts").catch(() => ({ n: "?" }));
    log(`contacts present (will be kept): ${contactsBefore.n}`);

    // 1) Merge the WAL into the main database so nothing recent is lost.
    log("merging the 5 GB change-log (WAL) back into the database…");
    const cp = await get(db, "PRAGMA wal_checkpoint(TRUNCATE)").catch((e) => {
      log("checkpoint note: " + e.message);
      return null;
    });
    if (cp) log(`checkpoint result: ${JSON.stringify(cp)}`);

    // 2) Switch off WAL.
    log("switching to the classic journal mode…");
    const jm = await get(db, "PRAGMA journal_mode = DELETE").catch((e) => {
      log("journal note: " + e.message);
      return null;
    });
    if (jm) log(`journal_mode now: ${JSON.stringify(jm)}`);

    // 3) Drop the bloated queue table (the app recreates it empty on next start).
    log("dropping the bloated email_bulk_queue table…");
    await run(db, "DROP TABLE IF EXISTS email_bulk_queue");

    // 4) Compact the file to reclaim the freed space.
    log("VACUUM — compacting the database; this can take several minutes…");
    await run(db, "VACUUM");

    const contactsAfter = await get(db, "SELECT COUNT(*) AS n FROM contacts").catch(() => ({ n: "?" }));
    log(`contacts after repair (should be unchanged): ${contactsAfter.n}`);
    log(`size after:   crm.sqlite=${sizeOf(dbPath)}   wal=${sizeOf(dbPath + "-wal")}`);
    log("DONE. Now START the Node app again.");
  } catch (e) {
    console.error("[db-repair] FAILED: " + (e && e.message ? e.message : e));
    db.close();
    process.exit(1);
  }
  db.close();
})();
