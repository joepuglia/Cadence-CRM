"use strict";

const crypto = require("crypto");

const BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

function base32Encode(buf) {
  let bits = 0;
  let value = 0;
  let output = "";
  for (let i = 0; i < buf.length; i++) {
    value = (value << 8) | buf[i];
    bits += 8;
    while (bits >= 5) {
      output += BASE32_ALPHABET[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) {
    output += BASE32_ALPHABET[(value << (5 - bits)) & 31];
  }
  return output;
}

function base32Decode(str) {
  const cleaned = String(str || "")
    .toUpperCase()
    .replace(/[^A-Z2-7]/g, "");
  let bits = 0;
  let value = 0;
  const out = [];
  for (let i = 0; i < cleaned.length; i++) {
    const idx = BASE32_ALPHABET.indexOf(cleaned[i]);
    if (idx < 0) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}

function hotp(secretBuf, counter) {
  const counterBuf = Buffer.alloc(8);
  counterBuf.writeBigUInt64BE(BigInt(counter));
  const hmac = crypto.createHmac("sha1", secretBuf).update(counterBuf).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code =
    ((hmac[offset] & 0x7f) << 24) |
    ((hmac[offset + 1] & 0xff) << 16) |
    ((hmac[offset + 2] & 0xff) << 8) |
    (hmac[offset + 3] & 0xff);
  return String(code % 1_000_000).padStart(6, "0");
}

function generateSecretBase32() {
  return base32Encode(crypto.randomBytes(20));
}

function verifyTotpCode(secretBase32, code, { window = 1, stepSec = 30 } = {}) {
  const digits = String(code || "").replace(/\D/g, "");
  if (digits.length !== 6) return false;
  let secretBuf;
  try {
    secretBuf = base32Decode(secretBase32);
  } catch {
    return false;
  }
  if (!secretBuf.length) return false;
  const counter = Math.floor(Date.now() / 1000 / stepSec);
  for (let w = -window; w <= window; w++) {
    if (hotp(secretBuf, counter + w) === digits) return true;
  }
  return false;
}

function buildOtpauthUrl({ secretBase32, accountName, issuer = "Cadence CRM" }) {
  const label = encodeURIComponent(`${issuer}:${accountName}`);
  const params = new URLSearchParams({
    secret: secretBase32,
    issuer,
    algorithm: "SHA1",
    digits: "6",
    period: "30"
  });
  return `otpauth://totp/${label}?${params.toString()}`;
}

function generateBackupCodes(count = 8) {
  const codes = [];
  for (let i = 0; i < count; i++) {
    const a = crypto.randomBytes(2).toString("hex").toUpperCase();
    const b = crypto.randomBytes(2).toString("hex").toUpperCase();
    codes.push(`${a}-${b}`);
  }
  return codes;
}

function hashBackupCode(plain) {
  const norm = String(plain || "")
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "");
  return crypto.createHash("sha256").update(`crm-2fa-backup-v1:${norm}`).digest("hex");
}

function normalizeBackupCodeInput(code) {
  return String(code || "")
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9-]/g, "");
}

module.exports = {
  generateSecretBase32,
  verifyTotpCode,
  buildOtpauthUrl,
  generateBackupCodes,
  hashBackupCode,
  normalizeBackupCodeInput
};
