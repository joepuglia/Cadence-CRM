const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const jpeg = require("./vendor/jpeg-js");
const { PNG } = require("./vendor/pngjs");

const SMS_PHOTO_MAX_BYTES = 5 * 1024 * 1024;
const SMS_PHOTO_TTL_MS = 24 * 60 * 60 * 1000;
const SMS_PHOTO_KEEP_MS = 48 * 60 * 60 * 1000;
/** Carriers drop many picture texts above about 600 KB, and the words go with them. */
const SMS_PHOTO_CARRIER_BYTES = 450 * 1024;
const SMS_PHOTO_CARRIER_EDGE = 1280;

function detectImage(buffer) {
  if (!buffer || buffer.length < 12) return null;
  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return { mime: "image/jpeg", ext: ".jpg" };
  }
  if (buffer[0] === 0x89 && buffer[1] === 0x50 && buffer[2] === 0x4e && buffer[3] === 0x47) {
    return { mime: "image/png", ext: ".png" };
  }
  if (buffer.slice(0, 3).toString("ascii") === "GIF") {
    return { mime: "image/gif", ext: ".gif" };
  }
  if (buffer.slice(0, 4).toString("ascii") === "RIFF" && buffer.slice(8, 12).toString("ascii") === "WEBP") {
    return { mime: "image/webp", ext: ".webp" };
  }
  return null;
}

function signSmsMediaToken(secret, id, exp) {
  return crypto.createHmac("sha256", String(secret || "")).update(`sms-media:${id}:${Number(exp)}`).digest("base64url");
}

function verifySmsMediaToken(secret, id, exp, sig) {
  if (!/^[a-f0-9]{32}$/.test(String(id || ""))) return false;
  const e = Number(exp);
  if (!Number.isFinite(e) || Date.now() > e) return false;
  const expected = signSmsMediaToken(secret, id, e);
  const got = Buffer.from(String(sig || ""));
  const want = Buffer.from(expected);
  if (got.length !== want.length) return false;
  return crypto.timingSafeEqual(got, want);
}

function sweepSmsMedia(dir) {
  if (!dir || !fs.existsSync(dir)) return;
  const cutoff = Date.now() - SMS_PHOTO_KEEP_MS;
  for (const name of fs.readdirSync(dir)) {
    if (!/^[a-f0-9]{32}\.(jpg|png|gif|webp)$/.test(name)) continue;
    const full = path.join(dir, name);
    try {
      const st = fs.statSync(full);
      if (st.mtimeMs < cutoff) fs.unlinkSync(full);
    } catch {
      // A file that disappears mid-sweep can be ignored.
    }
  }
}

function photoError(message) {
  const err = new Error(message);
  err.status = 400;
  return err;
}

function fittedSize(width, height, maxEdge) {
  const edge = Math.max(width, height);
  if (!edge || edge <= maxEdge) return { width: Math.max(1, width), height: Math.max(1, height) };
  const scale = maxEdge / edge;
  return {
    width: Math.max(1, Math.round(width * scale)),
    height: Math.max(1, Math.round(height * scale))
  };
}

function resizeRgba(src, sw, sh, dw, dh) {
  const dst = Buffer.alloc(dw * dh * 4);
  for (let y = 0; y < dh; y += 1) {
    const y0 = Math.floor((y * sh) / dh);
    const y1 = Math.max(y0 + 1, Math.floor(((y + 1) * sh) / dh));
    for (let x = 0; x < dw; x += 1) {
      const x0 = Math.floor((x * sw) / dw);
      const x1 = Math.max(x0 + 1, Math.floor(((x + 1) * sw) / dw));
      let r = 0;
      let g = 0;
      let b = 0;
      let a = 0;
      let n = 0;
      for (let yy = y0; yy < y1; yy += 1) {
        for (let xx = x0; xx < x1; xx += 1) {
          const i = (yy * sw + xx) * 4;
          const alpha = src[i + 3] / 255;
          r += src[i] * alpha + 255 * (1 - alpha);
          g += src[i + 1] * alpha + 255 * (1 - alpha);
          b += src[i + 2] * alpha + 255 * (1 - alpha);
          a += 255;
          n += 1;
        }
      }
      const o = (y * dw + x) * 4;
      dst[o] = Math.round(r / n);
      dst[o + 1] = Math.round(g / n);
      dst[o + 2] = Math.round(b / n);
      dst[o + 3] = Math.round(a / n);
    }
  }
  return dst;
}

function encodeCarrierJpeg(src, width, height, maxEdge) {
  let pixels = src;
  let w = width;
  let h = height;
  let edge = Math.max(SMS_PHOTO_CARRIER_EDGE, Number(maxEdge) || 0);
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const fit = fittedSize(w, h, edge);
    if (fit.width !== w || fit.height !== h) {
      pixels = resizeRgba(pixels, w, h, fit.width, fit.height);
      w = fit.width;
      h = fit.height;
    }
    let quality = 78;
    let encoded = jpeg.encode({ data: pixels, width: w, height: h }, quality);
    while (encoded.data.length > SMS_PHOTO_CARRIER_BYTES && quality > 42) {
      quality -= 12;
      encoded = jpeg.encode({ data: pixels, width: w, height: h }, quality);
    }
    if (encoded.data.length <= SMS_PHOTO_CARRIER_BYTES) {
      return Buffer.from(encoded.data);
    }
    edge = Math.round(edge * 0.7);
  }
  throw photoError("That photo is too large for a text. Use a smaller JPG or PNG.");
}

function decodeRgba(buffer, kind) {
  if (kind.mime === "image/jpeg") {
    const decoded = jpeg.decode(buffer, {
      useTArray: true,
      formatAsRGBA: true,
      maxMemoryUsageInMB: 512,
      maxResolutionInMP: 80
    });
    if (!decoded || !decoded.width || !decoded.height || !decoded.data) return null;
    return { width: decoded.width, height: decoded.height, data: decoded.data };
  }
  if (kind.mime === "image/png") {
    const decoded = PNG.sync.read(buffer);
    if (!decoded || !decoded.width || !decoded.height || !decoded.data) return null;
    return { width: decoded.width, height: decoded.height, data: decoded.data };
  }
  return null;
}

function originalPhoto(buffer, kind) {
  return { buffer, mime: kind.mime, ext: kind.ext };
}

function isCarrierReadyPhoto(buffer, kind) {
  if (!kind) return false;
  if (kind.mime !== "image/jpeg" && kind.mime !== "image/gif" && kind.mime !== "image/webp") return false;
  return buffer.length > 0 && buffer.length <= SMS_PHOTO_CARRIER_BYTES;
}

/**
 * Phone companies accept a modest JPG much more reliably than a full-size
 * camera photo. .jpg and .jpeg are the same format and are always allowed.
 * A photo that is already small enough is returned untouched. Rebuilding it
 * while the phone company downloads it makes the whole text fail.
 * Width and height stay in proportion. A wide banner is not pulled wider.
 * If a JPG cannot be resized, the original file is kept.
 */
function prepareCarrierSmsPhoto(buffer) {
  const kind = detectImage(buffer);
  if (!kind) throw photoError("Use a JPG, PNG, GIF, or WebP photo.");
  if (buffer.length > SMS_PHOTO_MAX_BYTES) {
    throw photoError("That photo is too large for a text. Use a picture under 5 MB.");
  }
  if (isCarrierReadyPhoto(buffer, kind)) {
    return originalPhoto(buffer, kind);
  }
  try {
    const rgba = decodeRgba(buffer, kind);
    if (rgba) {
      let pixels = rgba.data;
      let w = rgba.width;
      let h = rgba.height;
      const fit = fittedSize(w, h, SMS_PHOTO_CARRIER_EDGE);
      if (fit.width !== w || fit.height !== h) {
        pixels = resizeRgba(pixels, w, h, fit.width, fit.height);
        w = fit.width;
        h = fit.height;
      }
      const jpegBuffer = encodeCarrierJpeg(pixels, w, h, Math.max(w, h));
      return { buffer: jpegBuffer, mime: "image/jpeg", ext: ".jpg" };
    }
  } catch {
    // A camera JPG jpeg-js cannot rewrite is still a valid photo.
  }
  return originalPhoto(buffer, kind);
}

function ensureCarrierSmsPhoto(dir, id) {
  const photo = resolveSmsPhoto(dir, id);
  if (!photo) return null;
  const buffer = fs.readFileSync(photo.full);
  const prepared = prepareCarrierSmsPhoto(buffer);
  const nextPath = path.join(dir, `${String(id).toLowerCase()}${prepared.ext}`);
  if (prepared.buffer !== buffer || path.resolve(photo.full) !== path.resolve(nextPath)) {
    fs.writeFileSync(nextPath, prepared.buffer);
    if (path.resolve(photo.full) !== path.resolve(nextPath)) {
      try {
        fs.unlinkSync(photo.full);
      } catch {
        // The new JPEG is already in place.
      }
    }
  }
  return { ...prepared, full: nextPath };
}

function httpsPublicOrigin(raw) {
  let s = String(raw || "").trim();
  if (!s) return "";
  if (!/^https?:\/\//i.test(s)) s = `https://${s}`;
  try {
    const url = new URL(s);
    const host = url.hostname.toLowerCase();
    if (!host || host === "localhost" || host.endsWith(".local") || host.endsWith(".localhost")) return "";
    if (/^(127\.|10\.|192\.168\.|0\.0\.0\.0|172\.(1[6-9]|2\d|3[0-1])\.)/.test(host)) return "";
    if (/wisehealthagency/i.test(host)) return "";
    return `https://${url.host}`;
  } catch {
    return "";
  }
}

function smsPhotoOriginCandidates(stored) {
  const out = [];
  const push = (raw) => {
    const origin = httpsPublicOrigin(raw);
    if (origin && !out.includes(origin)) out.push(origin);
  };
  push(stored);
  push(process.env.CRM_PUBLIC_URL);
  push("https://cadencecrm.pro");
  push("https://crmcadence.com");
  return out;
}

async function chooseSmsPhotoPublicUrl(secret, id, storedOrigin, options) {
  const prefer = httpsPublicOrigin(options && options.prefer);
  const origins = smsPhotoOriginCandidates(storedOrigin);
  if (prefer) {
    const rest = origins.filter((item) => item !== prefer);
    origins.splice(0, origins.length, prefer, ...rest);
  }
  let fallback = "";
  const preferUrl = prefer ? buildSmsMediaPublicUrl(prefer, secret, id) : "";
  for (const origin of origins) {
    const url = buildSmsMediaPublicUrl(origin, secret, id);
    if (!url) continue;
    if (!fallback) fallback = url;
    try {
      const res = await fetch(url, { redirect: "follow", signal: AbortSignal.timeout(4000) });
      const type = String(res.headers.get("content-type") || "").toLowerCase();
      await res.arrayBuffer().catch(() => {});
      if (res.ok && type.startsWith("image/")) return url;
    } catch {
      // This machine often cannot call its own public name. Twilio still can.
    }
  }
  // Hairpin checks fail on this host. Do not hand Twilio an unverified Settings address
  // ahead of the site where a single picture text already works.
  return preferUrl || fallback;
}

function writeSmsPhoto(dir, buffer, sweep) {
  const prepared = prepareCarrierSmsPhoto(buffer);
  fs.mkdirSync(dir, { recursive: true });
  if (sweep) sweepSmsMedia(dir);
  const id = crypto.randomBytes(16).toString("hex");
  fs.writeFileSync(path.join(dir, `${id}${prepared.ext}`), prepared.buffer);
  return { id, mime: prepared.mime };
}

function saveSmsPhoto(dir, buffer) {
  return writeSmsPhoto(dir, buffer, true);
}

/** Campaign photos stay until the step no longer uses them. */
function savePersistentSmsPhoto(dir, buffer) {
  return writeSmsPhoto(dir, buffer, false);
}

function smsPhotoOriginPath(dir, id) {
  return path.join(dir, `${String(id || "").trim().toLowerCase()}.origin`);
}

/** Remember the website that received the upload. A single text uses that same host. */
function rememberSmsPhotoOrigin(dir, id, rawOrigin) {
  const mediaId = String(id || "").trim().toLowerCase();
  const origin = httpsPublicOrigin(rawOrigin);
  if (!/^[a-f0-9]{32}$/.test(mediaId) || !origin) return "";
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(smsPhotoOriginPath(dir, mediaId), `${origin}\n`, "utf8");
  return origin;
}

function readSmsPhotoOrigin(dir, id) {
  const mediaId = String(id || "").trim().toLowerCase();
  if (!/^[a-f0-9]{32}$/.test(mediaId)) return "";
  try {
    return httpsPublicOrigin(fs.readFileSync(smsPhotoOriginPath(dir, mediaId), "utf8"));
  } catch {
    return "";
  }
}

function deleteSmsPhoto(dir, id) {
  const photo = resolveSmsPhoto(dir, id);
  if (photo) {
    try {
      fs.unlinkSync(photo.full);
    } catch {
      // Already gone.
    }
  }
  try {
    fs.unlinkSync(smsPhotoOriginPath(dir, id));
  } catch {
    // No saved website address for this photo.
  }
}

function buildSmsMediaPublicUrl(origin, secret, id) {
  const base = String(origin || "").trim().replace(/\/$/, "");
  const mediaId = String(id || "").trim().toLowerCase();
  if (!base || !/^https:\/\//i.test(base) || !/^[a-f0-9]{32}$/.test(mediaId)) return "";
  const exp = Date.now() + SMS_PHOTO_TTL_MS;
  const sig = signSmsMediaToken(secret, mediaId, exp);
  return `${base}/api/sms/media/${mediaId}?${new URLSearchParams({ e: String(exp), s: sig }).toString()}`;
}

function resolveSmsPhoto(dir, id) {
  if (!/^[a-f0-9]{32}$/.test(String(id || ""))) return null;
  const types = [
    [".jpg", "image/jpeg"],
    [".png", "image/png"],
    [".gif", "image/gif"],
    [".webp", "image/webp"]
  ];
  for (const [ext, mime] of types) {
    const full = path.join(dir, `${id}${ext}`);
    if (fs.existsSync(full)) return { full, mime };
  }
  return null;
}

module.exports = {
  SMS_PHOTO_MAX_BYTES,
  SMS_PHOTO_TTL_MS,
  detectImage,
  signSmsMediaToken,
  verifySmsMediaToken,
  saveSmsPhoto,
  savePersistentSmsPhoto,
  deleteSmsPhoto,
  prepareCarrierSmsPhoto,
  ensureCarrierSmsPhoto,
  chooseSmsPhotoPublicUrl,
  rememberSmsPhotoOrigin,
  readSmsPhotoOrigin,
  buildSmsMediaPublicUrl,
  resolveSmsPhoto
};
