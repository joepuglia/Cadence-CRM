"use strict";

/**
 * emailVerifier.js — proactive email-address verification.
 *
 * Verifies contact email addresses against a verification provider BEFORE you
 * send, so invalid mailboxes are caught up front instead of bouncing. Addresses
 * the provider judges definitely bad are flagged `do_not_email = '1'` — the same
 * flag the bounce processor sets — which the drip + bulk send paths already
 * honor. So nothing in the send code changes; invalids are simply skipped.
 *
 * Results are cached in `email_verifications` (keyed by lowercased email) so each
 * address is billed at most once. Re-running only checks not-yet-verified emails.
 *
 * Environment variables:
 *   EMAIL_VERIFIER_API_KEY      provider API key (required to enable)
 *   EMAIL_VERIFIER_PROVIDER     "zerobounce" (default) | "millionverifier"
 *   EMAIL_VERIFIER_BATCH        addresses checked per /run call (default 100)
 *   EMAIL_VERIFIER_CONCURRENCY  parallel checks per run (default 5)
 *
 * Decisions:
 *   keep     -> valid; safe to email
 *   suppress -> invalid / spamtrap / abuse / disposable / do-not-mail; flagged do_not_email
 *   review   -> catch-all / risky; left as-is (you decide)
 *   unknown  -> provider couldn't determine; left as-is, re-checked on next run
 */

function verifierConfig() {
  const provider = String(process.env.EMAIL_VERIFIER_PROVIDER || "zerobounce")
    .trim()
    .toLowerCase();
  const apiKey = String(process.env.EMAIL_VERIFIER_API_KEY || "").trim();
  const batch = Math.max(1, Math.min(1000, Number(process.env.EMAIL_VERIFIER_BATCH || 100) || 100));
  const concurrency = Math.max(
    1,
    Math.min(20, Number(process.env.EMAIL_VERIFIER_CONCURRENCY || 5) || 5)
  );
  return { provider, apiKey, batch, concurrency, configured: Boolean(apiKey) };
}

async function ensureEmailVerificationSchema(run) {
  await run(
    `CREATE TABLE IF NOT EXISTS email_verifications (
      email TEXT PRIMARY KEY,
      status TEXT,
      decision TEXT,
      raw_status TEXT,
      provider TEXT,
      checked_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`
  );
}

// Normalize provider responses to { status, decision, raw }.
//   status:   valid | risky | unknown | invalid
//   decision: keep  | review | unknown | suppress
function normalizeZeroBounce(data) {
  const s = String((data && data.status) || "").toLowerCase();
  if (s === "valid") return { status: "valid", decision: "keep", raw: s };
  if (s === "catch-all") return { status: "risky", decision: "review", raw: s };
  if (s === "invalid" || s === "spamtrap" || s === "abuse" || s === "do_not_mail") {
    return { status: "invalid", decision: "suppress", raw: s };
  }
  return { status: "unknown", decision: "unknown", raw: s || "unknown" };
}

function normalizeMillionVerifier(data) {
  const r = String((data && data.result) || "").toLowerCase();
  if (r === "ok") return { status: "valid", decision: "keep", raw: r };
  if (r === "catch_all") return { status: "risky", decision: "review", raw: r };
  if (r === "invalid" || r === "disposable") {
    return { status: "invalid", decision: "suppress", raw: r };
  }
  return { status: "unknown", decision: "unknown", raw: r || "unknown" };
}

async function verifyOne(email, cfg) {
  const enc = encodeURIComponent(email);
  const key = encodeURIComponent(cfg.apiKey);
  const url =
    cfg.provider === "millionverifier"
      ? `https://api.millionverifier.com/api/v3/?api=${key}&email=${enc}&timeout=15`
      : `https://api.zerobounce.net/v2/validate?api_key=${key}&email=${enc}`;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20000);
  try {
    const resp = await fetch(url, { signal: controller.signal });
    if (!resp.ok) return { status: "unknown", decision: "unknown", raw: `http_${resp.status}` };
    const data = await resp.json().catch(() => ({}));
    if (data && data.error) {
      // e.g. "Invalid API Key or your account ran out of credits"
      return { status: "unknown", decision: "unknown", raw: ("err: " + String(data.error)).slice(0, 80) };
    }
    return cfg.provider === "millionverifier"
      ? normalizeMillionVerifier(data)
      : normalizeZeroBounce(data);
  } catch (e) {
    return { status: "unknown", decision: "unknown", raw: "request_error" };
  } finally {
    clearTimeout(timer);
  }
}

// Run an async fn over items with a fixed concurrency ceiling.
async function mapLimit(items, limit, fn) {
  let i = 0;
  const workers = new Array(Math.min(limit, items.length || 0)).fill(0).map(async () => {
    while (i < items.length) {
      const idx = i++;
      await fn(items[idx]);
    }
  });
  await Promise.all(workers);
}

/** Build the WHERE fragment limiting verification to a set of contact ids.
 *  When no ids are given, the scope is the whole contacts table (legacy behavior). */
function scopeClause(contactIds) {
  const ids = Array.isArray(contactIds)
    ? contactIds.map((n) => Number(n)).filter((n) => Number.isInteger(n) && n > 0)
    : [];
  if (!ids.length) return { sql: "", params: [] };
  return {
    sql: ` AND id IN (${ids.map(() => "?").join(",")})`,
    params: ids
  };
}

async function countRemaining(get, contactIds) {
  const scope = scopeClause(contactIds);
  const row = await get(
    `SELECT COUNT(*) AS c FROM (
       SELECT DISTINCT lower(trim(email)) AS email
         FROM contacts
        WHERE email IS NOT NULL AND trim(email) <> ''
          AND lower(trim(email)) NOT IN (SELECT email FROM email_verifications)
          ${scope.sql}
     )`,
    scope.params
  );
  return row ? row.c : 0;
}

async function runEmailVerification({ run, all, get, contactIds }) {
  const cfg = verifierConfig();
  await ensureEmailVerificationSchema(run);
  if (!cfg.configured) {
    return {
      configured: false,
      provider: cfg.provider,
      checked: 0,
      valid: 0,
      risky: 0,
      invalid: 0,
      unknown: 0,
      suppressed: 0,
      remaining: await countRemaining(get, contactIds)
    };
  }

  const scope = scopeClause(contactIds);
  const rows = await all(
    `SELECT DISTINCT lower(trim(email)) AS email
       FROM contacts
      WHERE email IS NOT NULL AND trim(email) <> ''
        AND lower(trim(email)) NOT IN (SELECT email FROM email_verifications)
        ${scope.sql}
      LIMIT ?`,
    [...scope.params, cfg.batch]
  );
  const emails = (rows || []).map((r) => r.email).filter(Boolean);

  let valid = 0;
  let risky = 0;
  let invalid = 0;
  let unknown = 0;
  let suppressed = 0;

  await mapLimit(emails, cfg.concurrency, async (email) => {
    const v = await verifyOne(email, cfg);
    await run(
      `INSERT OR REPLACE INTO email_verifications (email, status, decision, raw_status, provider, checked_at)
       VALUES (?, ?, ?, ?, ?, datetime('now'))`,
      [email, v.status, v.decision, v.raw, cfg.provider]
    );
    if (v.status === "valid") valid++;
    else if (v.status === "risky") risky++;
    else if (v.status === "invalid") invalid++;
    else unknown++;

    if (v.decision === "suppress") {
      await run(
        `UPDATE contacts SET do_not_email = '1', updated_at = CURRENT_TIMESTAMP
          WHERE lower(trim(email)) = ? AND COALESCE(do_not_email, '') <> '1'`,
        [email]
      );
      suppressed++;
    }
  });

  return {
    configured: true,
    provider: cfg.provider,
    checked: emails.length,
    valid,
    risky,
    invalid,
    unknown,
    suppressed,
    remaining: await countRemaining(get, contactIds)
  };
}

async function getEmailVerificationStatus({ run, all, get, contactIds }) {
  const cfg = verifierConfig();
  await ensureEmailVerificationSchema(run);

  const scope = scopeClause(contactIds);
  const scoped = scope.sql !== "";

  const totalRow = await get(
    `SELECT COUNT(DISTINCT lower(trim(email))) AS c
       FROM contacts WHERE email IS NOT NULL AND trim(email) <> ''${scope.sql}`,
    scope.params
  );

  // When scoped to a selection, count verifications/status only for those emails.
  const verRow = scoped
    ? await get(
        `SELECT COUNT(*) AS c FROM email_verifications
          WHERE email IN (
            SELECT DISTINCT lower(trim(email)) FROM contacts
             WHERE email IS NOT NULL AND trim(email) <> ''${scope.sql}
          )`,
        scope.params
      )
    : await get(`SELECT COUNT(*) AS c FROM email_verifications`);

  const byStatus = scoped
    ? await all(
        `SELECT status, COUNT(*) AS c FROM email_verifications
          WHERE email IN (
            SELECT DISTINCT lower(trim(email)) FROM contacts
             WHERE email IS NOT NULL AND trim(email) <> ''${scope.sql}
          )
          GROUP BY status`,
        scope.params
      )
    : await all(`SELECT status, COUNT(*) AS c FROM email_verifications GROUP BY status`);

  const counts = { valid: 0, risky: 0, invalid: 0, unknown: 0 };
  for (const r of byStatus || []) {
    if (r && r.status && counts[r.status] !== undefined) counts[r.status] = r.c;
  }
  const total = totalRow ? totalRow.c : 0;
  const verified = verRow ? verRow.c : 0;

  return {
    configured: cfg.configured,
    provider: cfg.provider,
    totalEmails: total,
    verified,
    remaining: Math.max(0, total - verified),
    valid: counts.valid,
    risky: counts.risky,
    invalid: counts.invalid,
    unknown: counts.unknown
  };
}

function registerEmailVerificationRoutes(app, deps) {
  const { run, all, get, isOwnerWorkspaceSession, getAuthSession } = deps;

  const ownerOnly = (req, res) => {
    if (!isOwnerWorkspaceSession(req)) {
      res.status(403).json({ error: "Owner only." });
      return false;
    }
    return true;
  };

  app.get("/api/email-verification/status", async (req, res) => {
    if (!ownerOnly(req, res)) return;
    try {
      // Optional ?contactIds=1,2,3 scopes the totals to the user's selection.
      const raw = String((req.query && req.query.contactIds) || "").trim();
      const contactIds = raw
        ? raw
            .split(",")
            .map((n) => Number(n.trim()))
            .filter((n) => Number.isInteger(n) && n > 0)
        : [];
      res.json(await getEmailVerificationStatus({ run, all, get, contactIds }));
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  // CSV export of verification results, optionally filtered by status
  // (?status=invalid | risky | valid | unknown). No status = all.
  app.get("/api/email-verification/export", async (req, res) => {
    if (!ownerOnly(req, res)) return;
    try {
      await ensureEmailVerificationSchema(run);
      const status = String((req.query && req.query.status) || "").toLowerCase();
      const allowed = ["invalid", "risky", "valid", "unknown"];
      let rows;
      if (allowed.indexOf(status) !== -1) {
        rows = await all(
          `SELECT email, status, decision, raw_status, provider, checked_at
             FROM email_verifications WHERE status = ? ORDER BY email`,
          [status]
        );
      } else {
        rows = await all(
          `SELECT email, status, decision, raw_status, provider, checked_at
             FROM email_verifications ORDER BY status, email`
        );
      }
      const esc = (v) => {
        const s = String(v == null ? "" : v);
        return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
      };
      const header = "email,status,decision,raw_status,provider,checked_at\n";
      const body = (rows || [])
        .map((r) =>
          [r.email, r.status, r.decision, r.raw_status, r.provider, r.checked_at].map(esc).join(",")
        )
        .join("\n");
      res.setHeader("Content-Type", "text/csv; charset=utf-8");
      res.setHeader(
        "Content-Disposition",
        `attachment; filename="email-verification-${status || "all"}.csv"`
      );
      res.send(header + body + (body ? "\n" : ""));
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  // Per-contact lookup: verification status for a single email. Available to any
  // authenticated user (so agents see the badge, not just the owner).
  app.get("/api/email-verification/for", async (req, res) => {
    if (typeof getAuthSession === "function" && !getAuthSession(req)) {
      return res.status(401).json({ error: "Not authenticated." });
    }
    try {
      await ensureEmailVerificationSchema(run);
      const email = String((req.query && req.query.email) || "")
        .trim()
        .toLowerCase();
      if (!email) return res.json({ email: "", status: "unverified" });
      const row = await get(
        `SELECT email, status, decision, raw_status, checked_at
           FROM email_verifications WHERE email = ?`,
        [email]
      );
      res.json(row || { email: email, status: "unverified" });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  const handleRun = async (req, res) => {
    if (!ownerOnly(req, res)) return;
    try {
      // Optional scope: verify only these contacts (the user's selection/filter).
      // Omitted or empty => whole database (legacy behavior, e.g. the GET trigger).
      const contactIds = Array.isArray(req.body?.contactIds) ? req.body.contactIds : [];
      const result = await runEmailVerification({ run, all, get, contactIds });
      if (!result.configured) {
        return res.status(400).json({
          ...result,
          error:
            "Email verifier not configured. Set EMAIL_VERIFIER_API_KEY (and optionally EMAIL_VERIFIER_PROVIDER) in your environment, then restart."
        });
      }
      res.json(result);
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  };

  // POST for a future in-app button; GET (with ?confirm=1) lets the owner trigger
  // a batch straight from the browser address bar, like the bounce tooling.
  app.post("/api/email-verification/run", handleRun);
  app.get("/api/email-verification/run", async (req, res) => {
    if (String((req.query && req.query.confirm) || "") !== "1") {
      return res.status(400).json({
        error: "Add ?confirm=1 to run a verification batch, e.g. /api/email-verification/run?confirm=1"
      });
    }
    return handleRun(req, res);
  });

  // Clears cached "unknown" results so a fresh run re-checks them (e.g. after
  // topping up verifier credits). Genuine valid/invalid/risky verdicts are kept.
  const handleRecheckUnknown = async (req, res) => {
    if (!ownerOnly(req, res)) return;
    try {
      await ensureEmailVerificationSchema(run);
      await run(`DELETE FROM email_verifications WHERE status = 'unknown'`);
      res.json(await getEmailVerificationStatus({ run, all, get }));
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  };
  app.post("/api/email-verification/recheck-unknown", handleRecheckUnknown);
}

/**
 * Seed Apollo-verified emails into email_verifications so the in-app verifier
 * SKIPS them (it only checks emails NOT already in this table) and the per-contact
 * badge shows "Verified" without spending a verifier credit.
 *
 * Only Apollo's explicit "Verified" status is trusted -> status 'valid' / decision 'keep'.
 * Everything else (Unverified, Likely to engage, Unavailable, blank) is left untouched
 * so your own verifier still checks it. Uses INSERT OR IGNORE so it never overwrites a
 * result your own verifier already produced. No-op when the CSV has no "Email Status"
 * column (i.e. non-Apollo files), so it is safe to call on every import.
 */
async function recordApolloVerifiedFromCsv({ run, csv }) {
  if (!run || typeof csv !== "string" || !csv.trim()) {
    return { applicable: false, seeded: 0 };
  }
  // csvImport has no dependency on this module, so this require is not circular.
  const { parseCsv } = require("./csvImport");
  const { headers, rows } = parseCsv(csv);
  if (!headers || !headers.length) return { applicable: false, seeded: 0 };

  const norm = (h) =>
    String(h || "")
      .replace(/^\uFEFF/, "")
      .trim()
      .toLowerCase()
      .replace(/-/g, " ")
      .replace(/\s+/g, " ");

  const statusIdx = headers.findIndex((h) => norm(h) === "email status");
  const emailIdx = headers.findIndex((h) => norm(h) === "email");
  if (statusIdx === -1 || emailIdx === -1) {
    return { applicable: false, seeded: 0 };
  }

  const verified = new Set();
  for (const cells of rows) {
    const email = String(cells[emailIdx] || "").trim().toLowerCase();
    const status = String(cells[statusIdx] || "").trim().toLowerCase();
    // Exact match: "unverified" must NOT count as verified.
    if (email && status === "verified") verified.add(email);
  }
  if (!verified.size) return { applicable: true, seeded: 0 };

  await ensureEmailVerificationSchema(run);
  for (const email of verified) {
    await run(
      `INSERT OR IGNORE INTO email_verifications (email, status, decision, raw_status, provider, checked_at)
       VALUES (?, 'valid', 'keep', 'apollo: verified', 'apollo', datetime('now'))`,
      [email]
    );
  }
  return { applicable: true, seeded: verified.size };
}

module.exports = {
  registerEmailVerificationRoutes,
  recordApolloVerifiedFromCsv,
  runEmailVerification,
  getEmailVerificationStatus,
  ensureEmailVerificationSchema,
  verifierConfig
};
