"use strict";

const { activateTenantSubscription, getTenantById, PRO_MONTHLY_USD } = require("./tenantPlatform");

function isStripeConfigured() {
  return Boolean(
    String(process.env.STRIPE_SECRET_KEY || "").trim() &&
      String(process.env.STRIPE_PRICE_ID || "").trim()
  );
}

function isStripeWebhookConfigured() {
  return Boolean(
    isStripeConfigured() && String(process.env.STRIPE_WEBHOOK_SECRET || "").trim()
  );
}

function getStripe() {
  if (!String(process.env.STRIPE_SECRET_KEY || "").trim()) return null;
  // eslint-disable-next-line global-require
  const Stripe = require("stripe");
  return new Stripe(String(process.env.STRIPE_SECRET_KEY || "").trim());
}

function getStripePriceId() {
  return String(process.env.STRIPE_PRICE_ID || "").trim();
}

function getPublicBaseUrl(req) {
  const trialLogin = String(process.env.TRIAL_WELCOME_LOGIN_URL || "").trim().replace(/\/$/, "");
  if (trialLogin) return trialLogin;
  const env = String(process.env.CRM_PUBLIC_URL || "").trim().replace(/\/$/, "");
  if (env) return env;
  const host = req.get("host");
  const proto = isHttpsRequest(req) ? "https" : "http";
  return host ? `${proto}://${host}` : "https://crmcadence.com";
}

function isHttpsRequest(req) {
  if (!req) return false;
  if (req.secure) return true;
  const proto = String((req.get && req.get("x-forwarded-proto")) || "").toLowerCase();
  return proto.split(",")[0].trim() === "https";
}

async function findTenantIdFromStripeObject(obj) {
  const fromMeta = Number(obj?.metadata?.tenant_id || 0);
  if (Number.isInteger(fromMeta) && fromMeta > 0) return fromMeta;
  const customerId = String(obj?.customer || "").trim();
  if (!customerId.startsWith("cus_")) return 0;
  const { platformGet } = require("./db");
  const row = await platformGet(`SELECT id FROM tenants WHERE stripe_customer_id = ?`, [customerId]);
  return row ? Number(row.id) : 0;
}

async function markTenantBillingInactive(tenantId, status = "expired") {
  const { platformRun } = require("./db");
  const next = status === "cancelled" ? "cancelled" : "expired";
  await platformRun(`UPDATE tenants SET status = ?, updated_at = ? WHERE id = ?`, [
    next,
    Math.floor(Date.now() / 1000),
    tenantId
  ]);
}

async function createCheckoutSession(req, { tenantId, email }) {
  const stripe = getStripe();
  const priceId = getStripePriceId();
  if (!stripe || !priceId) {
    return {
      error:
        "Stripe billing is not configured on this server yet. Add STRIPE_SECRET_KEY and STRIPE_PRICE_ID to .env."
    };
  }

  const tenant = await getTenantById(tenantId);
  if (!tenant) return { error: "Workspace not found." };

  const base = getPublicBaseUrl(req);
  let customerId = String(tenant.stripe_customer_id || "").trim();
  if (!customerId) {
    const customer = await stripe.customers.create({
      email: String(email || tenant.owner_email || "").trim(),
      name: String(tenant.agency_name || "").trim() || undefined,
      metadata: { tenant_id: String(tenantId) }
    });
    customerId = customer.id;
    const { platformRun } = require("./db");
    await platformRun(`UPDATE tenants SET stripe_customer_id = ?, updated_at = ? WHERE id = ?`, [
      customerId,
      Math.floor(Date.now() / 1000),
      tenantId
    ]);
  }

  const session = await stripe.checkout.sessions.create({
    mode: "subscription",
    customer: customerId,
    line_items: [{ price: priceId, quantity: 1 }],
    success_url: `${base}/billing.html?status=success&session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${base}/billing.html?status=cancelled`,
    client_reference_id: String(tenantId),
    metadata: { tenant_id: String(tenantId) },
    subscription_data: {
      metadata: { tenant_id: String(tenantId) }
    },
    allow_promotion_codes: true,
    billing_address_collection: "auto"
  });

  return { url: session.url, sessionId: session.id };
}

async function createBillingPortalSession(req, { tenantId }) {
  const stripe = getStripe();
  if (!stripe) {
    return { error: "Stripe billing is not configured on this server yet." };
  }
  const tenant = await getTenantById(tenantId);
  if (!tenant) return { error: "Workspace not found." };
  const customerId = String(tenant.stripe_customer_id || "").trim();
  if (!customerId) {
    return { error: "No billing profile yet. Subscribe first, then you can manage your subscription here." };
  }
  const base = getPublicBaseUrl(req);
  const session = await stripe.billingPortal.sessions.create({
    customer: customerId,
    return_url: `${base}/billing.html`
  });
  return { url: session.url };
}

async function syncCheckoutSessionCompleted(session) {
  const stripe = getStripe();
  if (!stripe) return;
  const tenantId = Number(session.metadata?.tenant_id || session.client_reference_id || 0);
  if (!tenantId) return;
  let subscriptionId = String(session.subscription || "").trim();
  if (!subscriptionId && session.id) {
    try {
      const full = await stripe.checkout.sessions.retrieve(session.id, { expand: ["subscription"] });
      subscriptionId =
        typeof full.subscription === "string"
          ? full.subscription
          : String(full.subscription?.id || "").trim();
    } catch (err) {
      console.error("Stripe checkout retrieve:", err.message || err);
    }
  }
  await activateTenantSubscription(tenantId, {
    stripeCustomerId: session.customer || "",
    stripeSubscriptionId: subscriptionId
  });
}

async function handleStripeWebhook(rawBody, signatureHeader) {
  const stripe = getStripe();
  const secret = String(process.env.STRIPE_WEBHOOK_SECRET || "").trim();
  if (!stripe || !secret) return { ok: false, status: 503, error: "Stripe webhook not configured" };

  let event;
  try {
    event = stripe.webhooks.constructEvent(rawBody, signatureHeader, secret);
  } catch (err) {
    return { ok: false, status: 400, error: err.message || "Invalid signature" };
  }

  if (event.type === "checkout.session.completed") {
    await syncCheckoutSessionCompleted(event.data.object);
  }

  if (event.type === "customer.subscription.created" || event.type === "customer.subscription.updated") {
    const sub = event.data.object;
    const tenantId = await findTenantIdFromStripeObject(sub);
    const status = String(sub.status || "").toLowerCase();
    if (tenantId > 0) {
      if (["active", "trialing"].includes(status)) {
        await activateTenantSubscription(tenantId, {
          stripeCustomerId: sub.customer || "",
          stripeSubscriptionId: sub.id || ""
        });
      } else if (["canceled", "unpaid", "past_due", "incomplete_expired"].includes(status)) {
        await markTenantBillingInactive(tenantId, status === "canceled" ? "cancelled" : "expired");
      }
    }
  }

  if (event.type === "customer.subscription.deleted") {
    const sub = event.data.object;
    const tenantId = await findTenantIdFromStripeObject(sub);
    if (tenantId > 0) await markTenantBillingInactive(tenantId, "cancelled");
  }

  if (event.type === "invoice.payment_failed") {
    const invoice = event.data.object;
    const tenantId = await findTenantIdFromStripeObject(invoice);
    if (tenantId > 0) await markTenantBillingInactive(tenantId, "expired");
  }

  return { ok: true };
}

function getStripeConfigSummary() {
  return {
    secretKeySet: Boolean(String(process.env.STRIPE_SECRET_KEY || "").trim()),
    priceIdSet: Boolean(getStripePriceId()),
    webhookSecretSet: Boolean(String(process.env.STRIPE_WEBHOOK_SECRET || "").trim()),
    priceId: getStripePriceId(),
    monthlyUsd: PRO_MONTHLY_USD,
    ready: isStripeConfigured() && isStripeWebhookConfigured()
  };
}

module.exports = {
  PRO_MONTHLY_USD,
  isStripeConfigured,
  isStripeWebhookConfigured,
  getStripePriceId,
  createCheckoutSession,
  createBillingPortalSession,
  handleStripeWebhook,
  getPublicBaseUrl,
  getStripeConfigSummary
};
