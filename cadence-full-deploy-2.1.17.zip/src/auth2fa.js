"use strict";

const crypto = require("crypto");
const {
  generateSecretBase32,
  verifyTotpCode,
  buildOtpauthUrl,
  generateBackupCodes,
  hashBackupCode,
  normalizeBackupCodeInput
} = require("./totpAuth");

const AUTH_2FA_CHALLENGE_MAX_AGE_MS = 5 * 60 * 1000;
const RUNTIME_KEYS = {
  enabled: "login2faEnabled",
  secret: "login2faSecret",
  backup: "login2faBackupHashes",
  pending: "login2faPendingSecret"
};

function registerAuth2faRoutes(app, deps) {
  const {
    all,
    run,
    encryptSecret,
    decryptSecret,
    getConfiguredLoginEmail,
    getConfiguredLoginPasswordHash,
    verifyLoginPassword,
    issueSignedAuthToken,
    setAuthCookie,
    isRequestAuthenticated,
    getAuthSigningSecret,
    authLoginLimiter,
    createRateLimiter,
    reloadRuntimeConfig
  } = deps;

  const verify2faLimiter = createRateLimiter({ windowMs: 60_000, max: 12, label: "auth-2fa-verify" });

  function isLogin2faEnabled() {
    return String(process.env.CRM_LOGIN_2FA_ENABLED || "").trim() === "1";
  }

  async function getRuntimeMap() {
    const rows = await all(`SELECT key, value FROM twilio_runtime_config`);
    return new Map((Array.isArray(rows) ? rows : []).map((r) => [String(r.key || ""), String(r.value || "")]));
  }

  async function setRuntimeKey(key, value) {
    await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, [key, value]);
    if (typeof reloadRuntimeConfig === "function") await reloadRuntimeConfig();
  }

  async function deleteRuntimeKey(key) {
    await run(`DELETE FROM twilio_runtime_config WHERE key = ?`, [key]);
    if (typeof reloadRuntimeConfig === "function") await reloadRuntimeConfig();
  }

  async function getDecryptedSecret(key) {
    const map = await getRuntimeMap();
    const raw = map.get(key) || "";
    return String(decryptSecret(raw) || "").trim();
  }

  async function getBackupHashes() {
    const raw = await getDecryptedSecret(RUNTIME_KEYS.backup);
    if (!raw) return [];
    try {
      const arr = JSON.parse(raw);
      return Array.isArray(arr) ? arr.map((h) => String(h)) : [];
    } catch {
      return [];
    }
  }

  async function saveBackupHashes(hashes) {
    const enc = encryptSecret(JSON.stringify(hashes));
    await setRuntimeKey(RUNTIME_KEYS.backup, enc);
  }

  function issue2faChallengeToken(email) {
    const exp = Date.now() + AUTH_2FA_CHALLENGE_MAX_AGE_MS;
    const payload = Buffer.from(JSON.stringify({ t: "2fa", email: String(email).toLowerCase(), exp }), "utf8").toString(
      "base64url"
    );
    const sig = crypto.createHmac("sha256", getAuthSigningSecret()).update(payload).digest("base64url");
    return `${payload}.${sig}`;
  }

  function verify2faChallengeToken(token) {
    const raw = String(token || "").trim();
    const dot = raw.lastIndexOf(".");
    if (dot <= 0) return null;
    const payload = raw.slice(0, dot);
    const sig = raw.slice(dot + 1);
    const expected = crypto.createHmac("sha256", getAuthSigningSecret()).update(payload).digest("base64url");
    try {
      const a = Buffer.from(sig);
      const b = Buffer.from(expected);
      if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
    } catch {
      return null;
    }
    try {
      const data = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
      if (!data || data.t !== "2fa" || typeof data.email !== "string" || typeof data.exp !== "number") return null;
      if (data.exp < Date.now()) return null;
      const configured = getConfiguredLoginEmail();
      if (configured && data.email !== configured) return null;
      return { email: data.email };
    } catch {
      return null;
    }
  }

  async function verify2faCode(code) {
    const secret = await getDecryptedSecret(RUNTIME_KEYS.secret);
    if (!secret) return false;
    if (verifyTotpCode(secret, code)) return true;
    const norm = normalizeBackupCodeInput(code);
    if (!norm) return false;
    const want = hashBackupCode(norm);
    const hashes = await getBackupHashes();
    const idx = hashes.indexOf(want);
    if (idx < 0) return false;
    hashes.splice(idx, 1);
    await saveBackupHashes(hashes);
    return true;
  }

  async function completeLoginOrChallenge(req, res, email) {
    if (!isLogin2faEnabled()) {
      const token = issueSignedAuthToken(email);
      setAuthCookie(res, token, req);
      return res.json({ ok: true });
    }
    const challengeToken = issue2faChallengeToken(email);
    return res.json({ ok: true, requires2fa: true, challengeToken });
  }

  app.post("/api/auth/verify-2fa", verify2faLimiter, async (req, res) => {
    try {
      if (!isLogin2faEnabled()) {
        return res.status(400).json({ error: "Two-factor authentication is not enabled." });
      }
      const challenge = verify2faChallengeToken(req.body?.challengeToken);
      if (!challenge) {
        return res.status(401).json({ error: "Verification session expired. Sign in again." });
      }
      const code = String(req.body?.code || "").trim();
      if (!code) return res.status(400).json({ error: "Enter the 6-digit code from your authenticator app." });
      const ok = await verify2faCode(code);
      if (!ok) return res.status(401).json({ error: "Invalid verification code." });
      const token = issueSignedAuthToken(challenge.email);
      setAuthCookie(res, token, req);
      return res.json({ ok: true });
    } catch (err) {
      return res.status(500).json({ error: err.message || "Verification failed." });
    }
  });

  app.get("/api/auth/2fa/status", async (req, res) => {
    if (!isRequestAuthenticated(req)) {
      return res.status(401).json({ error: "Please log in to continue." });
    }
    try {
      const map = await getRuntimeMap();
      const pending = Boolean(String(map.get(RUNTIME_KEYS.pending) || "").trim());
      return res.json({
        enabled: isLogin2faEnabled(),
        pendingSetup: pending,
        hasBackupCodes: (await getBackupHashes()).length > 0
      });
    } catch (err) {
      return res.status(500).json({ error: err.message || "Failed to load 2FA status." });
    }
  });

  app.post("/api/auth/2fa/setup/begin", async (req, res) => {
    if (!isRequestAuthenticated(req)) {
      return res.status(401).json({ error: "Please log in to continue." });
    }
    if (!getConfiguredLoginPasswordHash()) {
      return res.status(400).json({ error: "Set a login password before enabling two-factor authentication." });
    }
    try {
      const secret = generateSecretBase32();
      await setRuntimeKey(RUNTIME_KEYS.pending, encryptSecret(secret));
      const email = getConfiguredLoginEmail() || "agent";
      const otpauthUrl = buildOtpauthUrl({ secretBase32: secret, accountName: email });
      const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(otpauthUrl)}`;
      return res.json({
        ok: true,
        secretBase32: secret,
        otpauthUrl,
        qrUrl
      });
    } catch (err) {
      return res.status(500).json({ error: err.message || "Could not start 2FA setup." });
    }
  });

  app.post("/api/auth/2fa/setup/confirm", async (req, res) => {
    if (!isRequestAuthenticated(req)) {
      return res.status(401).json({ error: "Please log in to continue." });
    }
    try {
      const pending = await getDecryptedSecret(RUNTIME_KEYS.pending);
      if (!pending) {
        return res.status(400).json({ error: "Start setup first (Generate QR code)." });
      }
      const code = String(req.body?.code || "").trim();
      if (!verifyTotpCode(pending, code)) {
        return res.status(401).json({ error: "Invalid code. Check your authenticator app and try again." });
      }
      const backupPlain = generateBackupCodes(8);
      const backupHashes = backupPlain.map((c) => hashBackupCode(c));
      await setRuntimeKey(RUNTIME_KEYS.secret, encryptSecret(pending));
      await saveBackupHashes(backupHashes);
      await setRuntimeKey(RUNTIME_KEYS.enabled, "1");
      await deleteRuntimeKey(RUNTIME_KEYS.pending);
      process.env.CRM_LOGIN_2FA_ENABLED = "1";
      return res.json({ ok: true, enabled: true, backupCodes: backupPlain });
    } catch (err) {
      return res.status(500).json({ error: err.message || "Could not enable 2FA." });
    }
  });

  app.post("/api/auth/2fa/setup/cancel", async (req, res) => {
    if (!isRequestAuthenticated(req)) {
      return res.status(401).json({ error: "Please log in to continue." });
    }
    try {
      await deleteRuntimeKey(RUNTIME_KEYS.pending);
      return res.json({ ok: true });
    } catch (err) {
      return res.status(500).json({ error: err.message || "Could not cancel setup." });
    }
  });

  app.post("/api/auth/2fa/disable", async (req, res) => {
    if (!isRequestAuthenticated(req)) {
      return res.status(401).json({ error: "Please log in to continue." });
    }
    try {
      const storedHash = getConfiguredLoginPasswordHash();
      const password = String(req.body?.password ?? "");
      if (!storedHash || !verifyLoginPassword(password, storedHash)) {
        return res.status(401).json({ error: "Invalid password." });
      }
      const code = String(req.body?.code || "").trim();
      if (isLogin2faEnabled()) {
        const ok = await verify2faCode(code);
        if (!ok) return res.status(401).json({ error: "Invalid authenticator or backup code." });
      }
      await deleteRuntimeKey(RUNTIME_KEYS.enabled);
      await deleteRuntimeKey(RUNTIME_KEYS.secret);
      await deleteRuntimeKey(RUNTIME_KEYS.backup);
      await deleteRuntimeKey(RUNTIME_KEYS.pending);
      process.env.CRM_LOGIN_2FA_ENABLED = "";
      return res.json({ ok: true, enabled: false });
    } catch (err) {
      return res.status(500).json({ error: err.message || "Could not disable 2FA." });
    }
  });

  return { completeLoginOrChallenge, isLogin2faEnabled };
}

module.exports = { registerAuth2faRoutes };
