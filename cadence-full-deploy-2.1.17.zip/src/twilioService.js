const twilio = require("twilio");
const TwilioRequestClient = require("twilio/lib/base/RequestClient");

function getClient() {
  const sid = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  if (!sid || !token) {
    throw new Error("TWILIO_ACCOUNT_SID or TWILIO_AUTH_TOKEN is missing.");
  }
  return twilio(sid, token);
}

function envTrim(name) {
  return String(process.env[name] || "").trim();
}

/** Env mode: twilio | signalwire | both. Empty means both if SignalWire creds exist. */
function getVoiceProviderMode() {
  const v = String(process.env.VOICE_PROVIDER || process.env.CADENCE_VOICE_PROVIDER || "")
    .trim()
    .toLowerCase();
  if (v === "twilio") return "twilio";
  if (v === "signalwire" || v === "sw") return "signalwire";
  if (v === "both") return "both";
  return "";
}

function isSignalWireConfigured() {
  return getSignalWireMissing().length === 0;
}

function isSignalWireVoiceReady() {
  if (getVoiceProviderMode() === "twilio") return false;
  return isSignalWireConfigured();
}

function getDefaultRestVoiceProvider() {
  return "twilio";
}

/** Default REST backend for Start Call (headset always stays on Twilio when configured). */
function getVoiceProvider() {
  return getDefaultRestVoiceProvider();
}

function isSignalWireVoiceProvider() {
  return getDefaultRestVoiceProvider() === "signalwire";
}

function normalizeVoiceProvider() {
  return "twilio";
}

function inferVoiceProviderFromCallSid(callSid) {
  const sid = String(callSid || "").trim();
  if (/^CA[0-9a-f]{32}$/i.test(sid)) return "twilio";
  if (isSignalWireConfigured()) return "signalwire";
  return "twilio";
}

function normalizeSignalWireHost(raw) {
  let s = String(raw || "")
    .trim()
    .replace(/^https?:\/\//i, "")
    .replace(/\/+$/, "");
  if (!s) return "";
  if (!/\./.test(s)) s = `${s}.signalwire.com`;
  return s;
}

function getSignalWireConfig() {
  return {
    host: normalizeSignalWireHost(process.env.SIGNALWIRE_SPACE_URL || process.env.SIGNALWIRE_SPACE),
    projectId: envTrim("SIGNALWIRE_PROJECT_ID"),
    apiToken: envTrim("SIGNALWIRE_API_TOKEN") || envTrim("SIGNALWIRE_TOKEN")
  };
}

function getSignalWireMissing() {
  const { host, projectId, apiToken } = getSignalWireConfig();
  const missing = [];
  if (!host) missing.push("SIGNALWIRE_SPACE_URL");
  if (!projectId) missing.push("SIGNALWIRE_PROJECT_ID");
  if (!apiToken) missing.push("SIGNALWIRE_API_TOKEN");
  return missing;
}

function createSignalWireRequestClient() {
  const { host } = getSignalWireConfig();
  const inner = new TwilioRequestClient();
  return {
    request(opts) {
      const next = Object.assign({}, opts);
      next.uri = String(opts.uri || "").replace(
        /^https:\/\/api\.twilio\.com/i,
        `https://${host}/api/laml`
      );
      return inner.request(next);
    }
  };
}

function createSignalWireVoiceClient() {
  const missing = getSignalWireMissing();
  if (missing.length) {
    throw new Error(
      `SignalWire is selected for Start Call but incomplete. Set ${missing.join(
        ", "
      )} in .env (SignalWire Dashboard → API).`
    );
  }
  const { projectId, apiToken } = getSignalWireConfig();
  return twilio(projectId, apiToken, {
    accountSid: projectId,
    httpClient: createSignalWireRequestClient()
  });
}

function getVoiceClientFor(provider) {
  if (String(provider || "").toLowerCase() === "signalwire") {
    return createSignalWireVoiceClient();
  }
  return getClient();
}

function getVoiceClient() {
  return getVoiceClientFor(getDefaultRestVoiceProvider());
}

function getVoiceClientForCallSid(callSid) {
  return getVoiceClientFor(inferVoiceProviderFromCallSid(callSid));
}

/** Prefer API Key + Secret for TwiML App reads/writes (same credentials as headset tokens). */
function getVoiceApiClient() {
  const sid = String(process.env.TWILIO_ACCOUNT_SID || "").trim();
  const key = String(process.env.TWILIO_API_KEY || "").trim();
  const secret = String(process.env.TWILIO_API_SECRET || "").trim();
  if (sid && /^SK[0-9a-f]{32}$/i.test(key) && secret) {
    return twilio(key, secret, { accountSid: sid });
  }
  return getClient();
}

const TWILIO_LINES = new Set(["primary", "secondary", "third"]);
const E164_RE = /^\+[1-9]\d{6,14}$/;

function normalizeTwilioFromLine(input) {
  const raw = String(input || "primary").trim();
  const withPlus = raw && !raw.startsWith("+") ? `+${raw}` : raw;
  if (E164_RE.test(withPlus)) return withPlus;
  const v = raw.toLowerCase();
  return TWILIO_LINES.has(v) ? v : "primary";
}

function resolveFromNumber(twilioFrom) {
  const line = normalizeTwilioFromLine(twilioFrom);
  if (E164_RE.test(line)) return line;
  const primary = (process.env.TWILIO_PHONE_NUMBER || "").trim();
  const secondary = (process.env.TWILIO_PHONE_NUMBER_SECOND || "").trim();
  const third = (process.env.TWILIO_PHONE_NUMBER_THIRD || "").trim();
  if (line === "secondary") {
    if (!secondary) {
      throw new Error("TWILIO_PHONE_NUMBER_SECOND is not configured.");
    }
    return secondary;
  }
  if (line === "third") {
    if (!third) {
      throw new Error("TWILIO_PHONE_NUMBER_THIRD is not configured.");
    }
    return third;
  }
  if (!primary) {
    throw new Error("TWILIO_PHONE_NUMBER is missing.");
  }
  return primary;
}

/** From number for REST Start Call. SignalWire DIDs override Twilio env lines when using SignalWire. */
function resolveVoiceFromNumber(twilioFrom, voiceProvider) {
  const provider = normalizeVoiceProvider(voiceProvider);
  if (provider !== "signalwire") {
    return resolveFromNumber(twilioFrom);
  }
  const line = normalizeTwilioFromLine(twilioFrom);
  if (E164_RE.test(line)) return line;
  const swPrimary = envTrim("SIGNALWIRE_PHONE_NUMBER");
  const swSecond = envTrim("SIGNALWIRE_PHONE_NUMBER_SECOND");
  const swThird = envTrim("SIGNALWIRE_PHONE_NUMBER_THIRD");
  if (line === "secondary" && swSecond) return swSecond;
  if (line === "third" && swThird) return swThird;
  if (line === "primary" && swPrimary) return swPrimary;
  if (swPrimary && line !== "secondary" && line !== "third") return swPrimary;
  if (line === "secondary" && swPrimary) return swPrimary;
  if (line === "third" && swPrimary) return swPrimary;
  throw new Error(
    "SignalWire needs its own caller ID. Set SIGNALWIRE_PHONE_NUMBER to a number you bought in SignalWire, or choose Twilio (rings your phone) to use your Twilio line."
  );
}

function getTwilioSmsMissing() {
  const missing = [];
  if (!process.env.TWILIO_ACCOUNT_SID) missing.push("TWILIO_ACCOUNT_SID");
  if (!process.env.TWILIO_AUTH_TOKEN) missing.push("TWILIO_AUTH_TOKEN");
  if (!process.env.TWILIO_PHONE_NUMBER && !process.env.TWILIO_PHONE_NUMBER_SECOND && !process.env.TWILIO_PHONE_NUMBER_THIRD) {
    missing.push("TWILIO_PHONE_NUMBER");
  }
  return missing;
}

function isTwilioSmsReady() {
  return getTwilioSmsMissing().length === 0;
}

/** Text-capable numbers on the connected Twilio account, in Twilio's order. */
async function listAccountSmsNumbers() {
  if (!isTwilioSmsReady()) return [];
  const client = getClient();
  const rows = await client.incomingPhoneNumbers.list({ limit: 20 });
  const numbers = [];
  for (const row of Array.isArray(rows) ? rows : []) {
    const num = String(row && row.phoneNumber || "").trim();
    const smsOk = !row || !row.capabilities || row.capabilities.sms !== false;
    if (num && smsOk && !numbers.includes(num)) numbers.push(num);
  }
  return numbers;
}

/** Normalize outbound recipients to E.164. U.S. 10-digit numbers become +1... */
function normalizePhoneRecipient(raw) {
  let t = String(raw || "")
    .trim()
    .replace(/[^\d+]/g, "");
  if (!t) return "";
  if (t.startsWith("++")) return "";
  if (!t.startsWith("+") && t.length === 10) t = `+1${t}`;
  if (!t.startsWith("+") && t.length === 11 && t.startsWith("1")) t = `+${t}`;
  if (!t.startsWith("+")) t = `+${t}`;
  return E164_RE.test(t) ? t : "";
}

function normalizeSmsRecipient(raw) {
  return normalizePhoneRecipient(raw);
}

function resolveFromNumberWithFallback(twilioFrom) {
  const preferred = normalizeTwilioFromLine(twilioFrom);
  const candidates = [preferred, "primary", "secondary", "third"];
  const seen = new Set();
  for (const line of candidates) {
    if (seen.has(line)) continue;
    seen.add(line);
    try {
      return resolveFromNumber(line);
    } catch {
      // Line not configured; try next.
    }
  }
  throw new Error("No Twilio phone number is configured for SMS.");
}

function listConfiguredSmsFromNumbers(twilioFrom) {
  const preferred = normalizeTwilioFromLine(twilioFrom);
  const order = [preferred, "primary", "secondary", "third"];
  const seen = new Set();
  const numbers = [];
  for (const line of order) {
    if (seen.has(line)) continue;
    seen.add(line);
    try {
      const num = resolveFromNumber(line);
      if (num && !numbers.includes(num)) numbers.push(num);
    } catch {
      // Line is not configured.
    }
  }
  return numbers;
}

const SMS_BODY_MAX = 1600;
const DEFAULT_SMS_ENDING = "Reply STOP to opt out.";

function messageAlreadyOptsOut(text) {
  return /\b(reply|text)\s+stop\b/i.test(text)
    || /\bstop\s+to\s+(opt[\s-]?out|unsubscribe|cancel|end)\b/i.test(text);
}

/** Saved line under each text. Unset uses the default. A blank string sends only the message. */
function resolveSmsEnding(explicit) {
  if (explicit !== undefined && explicit !== null) {
    return String(explicit).replace(/[ \t\u00A0]+$/g, "").trim().slice(0, 300);
  }
  if (process.env.CRM_SMS_ENDING === undefined) return DEFAULT_SMS_ENDING;
  return String(process.env.CRM_SMS_ENDING).replace(/[ \t\u00A0]+$/g, "").trim().slice(0, 300);
}

function endingAlreadyInMessage(text, ending) {
  const line = String(ending || "").trim();
  if (!line) return true;
  if (String(text || "").toLowerCase().includes(line.toLowerCase())) return true;
  if (/\bstop\b/i.test(line) && messageAlreadyOptsOut(text)) return true;
  return false;
}

/**
 * The message is sent exactly as written. Phone numbers are not reformatted
 * and lines are not pulled together. The saved ending, if any, goes on its own line.
 */
function composeOutboundSms(body, smsEnding) {
  const text = String(body || "").replace(/[ \t\u00A0\r\n]+$/g, "");
  const ending = resolveSmsEnding(smsEnding);
  if (!ending || endingAlreadyInMessage(text, ending)) return text.slice(0, SMS_BODY_MAX);
  const glue = "\n\n";
  const room = SMS_BODY_MAX - ending.length - glue.length;
  const head = text.length > room ? text.slice(0, Math.max(0, room)).replace(/[ \t\u00A0\r\n]+$/g, "") : text;
  if (!head) return ending.slice(0, SMS_BODY_MAX);
  return `${head}${glue}${ending}`;
}

function appendSmsOptOut(body) {
  return composeOutboundSms(body, undefined);
}

function keepPhoneNumberFullyLinked(body) {
  return String(body || "");
}

async function sendSms({ to, body, twilioFrom, mediaUrl, smsEnding, useMessagingService }) {
  const client = getClient();
  const normalizedTo = normalizeSmsRecipient(to);
  if (!normalizedTo) {
    throw new Error("Invalid or missing phone number. Use E.164 format (e.g. +15551234567).");
  }
  const fromNumbers = listConfiguredSmsFromNumbers(twilioFrom).filter((from) => {
    const toDigits = String(normalizedTo || "").replace(/\D/g, "");
    const fromDigits = String(from || "").replace(/\D/g, "");
    const toKey = toDigits.length === 11 && toDigits.startsWith("1") ? toDigits.slice(1) : toDigits;
    const fromKey = fromDigits.length === 11 && fromDigits.startsWith("1") ? fromDigits.slice(1) : fromDigits;
    return !toKey || !fromKey || toKey !== fromKey;
  });
  const media = String(mediaUrl || "").trim();
  const text = composeOutboundSms(String(body || "").trim(), smsEnding);
  if (!text && !media) {
    throw new Error("Message or photo is required.");
  }
  const serviceSid = String(process.env.TWILIO_MESSAGING_SERVICE_SID || "").trim();
  if (useMessagingService && serviceSid && !media) {
    try {
      const message = await client.messages.create({ messagingServiceSid: serviceSid, to: normalizedTo, body: text });
      return { sid: message.sid, status: message.status, to: message.to, from: message.from || "" };
    } catch (serviceErr) {
      if (!fromNumbers.length) throw serviceErr;
    }
  }
  if (!fromNumbers.length) {
    throw new Error(
      "That destination is a Cadence business number. Enter your personal cell under Settings → Your phone number."
    );
  }
  let lastError = null;
  for (let i = 0; i < fromNumbers.length; i += 1) {
    const from = fromNumbers[i];
    const payload = { from, to: normalizedTo };
    if (text) payload.body = text;
    if (media) payload.mediaUrl = [media];
    try {
      const message = await client.messages.create(payload);
      return {
        sid: message.sid,
        status: message.status,
        to: message.to
      };
    } catch (error) {
      lastError = error;
      const moreNumbers = i < fromNumbers.length - 1;
      const code = Number(error && error.code);
      const recipientProblem = [20003, 21211, 21602, 21608, 21610, 21614, 21617].includes(code);
      if (moreNumbers && !recipientProblem) continue;
      break;
    }
  }
  const error = lastError || new Error("Could not send that text.");
  if (media && text) {
    try {
      const message = await client.messages.create({ from: fromNumbers[0], to: normalizedTo, body: text });
      return {
        sid: message.sid,
        status: message.status,
        to: message.to,
        photoDropped: true
      };
    } catch {
      // The picture message and the words alone both failed. Report the picture error.
    }
  }
  const code = error && error.code;
  if (code === 21621) {
    throw new Error("This sending number cannot deliver picture texts. In Twilio, turn on MMS for that number.");
  }
  if (code === 21620 || code === 12300 || code === 53603) {
    throw new Error("Twilio could not load that photo. Use a JPG or PNG under 5 MB.");
  }
  if (code === 30019 || code === 11751) {
    throw new Error("That photo is too large for a text. Use a smaller JPG or PNG.");
  }
  throw error;
}

/** TwiML for a direct outbound leg when nobody is being bridged in (drip calls). */
function buildRestOutboundCalleeTwiml() {
  const parts = [];
  for (let i = 0; i < 6; i += 1) {
    parts.push("<Pause length=\"600\"/>");
  }
  return `<?xml version="1.0" encoding="UTF-8"?><Response>${parts.join("")}</Response>`;
}

function isUnusableCallTwimlUrl(url) {
  const u = String(url || "").trim();
  if (!u) return true;
  if (/twimlets\.com\/message/i.test(u)) return true;
  return false;
}

function formatTwilioClientError(error) {
  const code = error && error.code;
  const msg = String((error && (error.message || error.moreInfo)) || error || "Twilio error").trim();
  if (/TWILIO_ACCOUNT_SID or TWILIO_AUTH_TOKEN is missing/i.test(msg)) {
    return "Twilio Account SID or Auth Token is missing. Open Settings → Twilio, paste Account SID (starts with AC) and Auth Token from Twilio Console, then save. Leave blank fields empty only if they are already stored.";
  }
  if (code === 20003 || /authenticate/i.test(msg)) {
    return "Twilio could not authenticate. Account SID and Auth Token must be from the same Twilio account. Paste both from Twilio Console → Account, then save.";
  }
  if (code === 21216 || /account not allowed to call/i.test(msg)) {
    return (
      "Twilio blocked this outbound call (error 21216). That usually means the destination is a toll-free/800 number or a high-risk range, or Voice Geographic Permissions / Trust Hub is not enabled for +1. In Twilio Console enable Voice → Geographic Permissions for United States (and toll-free if you call 800/888/877 numbers), then try a regular 10-digit mobile or landline first."
    );
  }
  if (code === 20404 || /was not found/i.test(msg)) {
    return "The TwiML Application SID is missing or does not match this Twilio account. In Twilio Console go to Voice → TwiML → TwiML Apps, copy the AP… SID, paste it in Settings → Twilio, and save.";
  }
  if (code === 21212 || /from phone number/i.test(msg)) {
    return `Twilio rejected the From number. ${msg}`;
  }
  if (code === 21211 || /to.*is not a valid/i.test(msg)) {
    return "That phone number is not valid. Use a 10-digit U.S. number.";
  }
  if (code === 21608 || /unverified/i.test(msg)) {
    return "Twilio trial accounts can only call verified numbers. Verify this number in Twilio Console, or upgrade the account.";
  }
  return code ? `Twilio error ${code}: ${msg}` : msg;
}

function formatVoiceClientError(error, voiceProvider) {
  const provider = String(voiceProvider || getDefaultRestVoiceProvider()).toLowerCase();
  if (provider !== "signalwire") return formatTwilioClientError(error);
  const code = error && error.code;
  const msg = String((error && (error.message || error.moreInfo)) || error || "SignalWire error").trim();
  if (/SignalWire is selected for Start Call/i.test(msg) || /SIGNALWIRE_/i.test(msg)) return msg;
  if (code === 20003 || /authenticate/i.test(msg)) {
    return "SignalWire could not authenticate. Check SIGNALWIRE_PROJECT_ID and SIGNALWIRE_API_TOKEN for this space.";
  }
  if (code === 21212 || /from phone number/i.test(msg)) {
    return `SignalWire rejected the From number. Use a number you own in SignalWire (SIGNALWIRE_PHONE_NUMBER). ${msg}`;
  }
  if (code === 21211 || /to.*is not a valid/i.test(msg)) {
    return "That phone number is not valid. Use a 10-digit U.S. number.";
  }
  return code ? `SignalWire error ${code}: ${msg}` : msg;
}

function voiceRecordingMediaBase(voiceProvider) {
  if (String(voiceProvider || "").toLowerCase() === "signalwire") {
    const { host, projectId } = getSignalWireConfig();
    return `https://${host}/api/laml/2010-04-01/Accounts/${encodeURIComponent(projectId)}/Recordings`;
  }
  const accountSid = String(process.env.TWILIO_ACCOUNT_SID || "").trim();
  return `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Recordings`;
}

async function startCall({ to, twimlUrl, twilioFrom, record, recordingStatusCallback, voiceProvider }) {
  const provider = normalizeVoiceProvider(voiceProvider);
  const client = getVoiceClientFor(provider);
  const from = resolveVoiceFromNumber(twilioFrom, provider);
  const normalizedTo = normalizePhoneRecipient(to);
  if (!normalizedTo) {
    throw new Error("Invalid or missing phone number. Use a 10-digit U.S. number or E.164 format (e.g. +15551234567).");
  }
  const explicitUrl = String(twimlUrl || "").trim();
  const envUrl = String(process.env.TWILIO_CALL_TWIML_URL || "").trim();
  const chosenUrl = explicitUrl || envUrl;
  const callbackUrl = String(recordingStatusCallback || "").trim();

  // Always dial the contact. Do not ring the agent's cell first.
  const payload = { from, to: normalizedTo };
  if (!isUnusableCallTwimlUrl(chosenUrl)) {
    payload.url = chosenUrl;
  } else {
    payload.twiml = buildRestOutboundCalleeTwiml();
  }
  if (record && callbackUrl) {
    payload.record = true;
    payload.recordingStatusCallback = callbackUrl;
    payload.recordingStatusCallbackMethod = "POST";
    payload.recordingStatusCallbackEvent = ["completed"];
  }

  try {
    const call = await client.calls.create(payload);
    return {
      sid: call.sid,
      status: call.status,
      to: call.to,
      voiceProvider: provider
    };
  } catch (err) {
    throw new Error(formatVoiceClientError(err, provider));
  }
}

async function getCallStatus(callSid) {
  const client = getVoiceClientForCallSid(callSid);
  const sid = String(callSid || "").trim();
  if (!sid) {
    throw new Error("callSid is required");
  }
  const call = await client.calls(sid).fetch();
  const status = String(call.status || "").trim();
  let errorMessage = "";
  if (status.toLowerCase() === "failed") {
    try {
      const notes = await client.calls(sid).notifications.list({ limit: 1 });
      const note = notes && notes[0];
      if (note) {
        errorMessage = String(note.messageText || note.message_text || "").trim();
      }
    } catch {
      // Optional diagnostics; status alone is enough for the UI.
    }
  }
  let bridgeStatus = "";
  if (status.toLowerCase() === "in-progress") {
    try {
      const children = await client.calls.list({ parentCallSid: sid, limit: 5 });
      const child = (children || [])[0];
      const childStatus = String((child && child.status) || "").toLowerCase();
      if (childStatus === "queued" || childStatus === "ringing") bridgeStatus = "ringing-contact";
      else if (childStatus === "in-progress") bridgeStatus = "talking";
    } catch {
      // Parent status is enough if the child list is unavailable.
    }
  }
  return {
    sid: call.sid,
    status: call.status,
    to: call.to,
    duration: Number(call.duration) || 0,
    errorMessage,
    bridgeStatus
  };
}

async function startCallRecording({ callSid, recordingStatusCallback }) {
  const client = getVoiceClientForCallSid(callSid);
  const sid = String(callSid || "").trim();
  const callbackUrl = String(recordingStatusCallback || "").trim();
  if (!sid) {
    throw new Error("callSid is required");
  }
  const payload = { recordingChannels: "dual", playBeep: false };
  if (callbackUrl) {
    payload.recordingStatusCallback = callbackUrl;
    payload.recordingStatusCallbackMethod = "POST";
    payload.recordingStatusCallbackEvent = ["completed"];
  }
  const recording = await client.calls(sid).recordings.create(payload);
  return {
    sid: recording.sid,
    status: recording.status,
    callSid: recording.callSid
  };
}

async function endCall(callSid) {
  const client = getVoiceClientForCallSid(callSid);
  const sid = String(callSid || "").trim();
  if (!sid) {
    throw new Error("callSid is required");
  }
  const current = await client.calls(sid).fetch();
  const st = String(current.status || "").toLowerCase();
  const alreadyDone = new Set(["completed", "canceled", "cancelled", "failed", "busy", "no-answer"]);
  if (alreadyDone.has(st)) {
    return {
      sid: current.sid,
      status: current.status,
      to: current.to
    };
  }
  // Queued / ringing legs must be canceled; in-progress is completed.
  const preferred = st === "queued" || st === "ringing" ? "canceled" : "completed";
  try {
    const call = await client.calls(sid).update({ status: preferred });
    return { sid: call.sid, status: call.status, to: call.to };
  } catch (firstErr) {
    const alt = preferred === "canceled" ? "completed" : "canceled";
    try {
      const call = await client.calls(sid).update({ status: alt });
      return { sid: call.sid, status: call.status, to: call.to };
    } catch {
      throw firstErr;
    }
  }
}

/** List completed recordings for a call SID, including child legs of browser Dial calls. */
async function fetchCompletedRecordingsForCallSid(callSid) {
  const provider = inferVoiceProviderFromCallSid(callSid);
  const client = getVoiceClientFor(provider);
  const accountSid =
    provider === "signalwire"
      ? getSignalWireConfig().projectId
      : String(process.env.TWILIO_ACCOUNT_SID || "").trim();
  const primary = String(callSid || "").trim();
  if (!primary || !accountSid) return [];

  const callSids = new Set([primary]);
  try {
    const children = await client.calls.list({ parentCallSid: primary, limit: 20 });
    for (const child of children || []) {
      const sid = String(child.sid || "").trim();
      if (sid) callSids.add(sid);
    }
  } catch (_) {
    /* parent may not exist yet */
  }

  const out = [];
  const seen = new Set();
  for (const sid of callSids) {
    let recs = [];
    try {
      recs = await client.recordings.list({ callSid: sid, limit: 20 });
    } catch (_) {
      continue;
    }
    for (const rec of recs || []) {
      const recordingSid = String(rec.sid || "").trim();
      if (!recordingSid || seen.has(recordingSid)) continue;
      if (String(rec.status || "").toLowerCase() !== "completed") continue;
      seen.add(recordingSid);
      out.push({
        callSid: sid,
        recordingSid,
        recordingUrl: `${voiceRecordingMediaBase(provider)}/${recordingSid}`,
        durationSeconds: Math.max(0, Math.floor(Number(rec.duration || 0)))
      });
    }
  }
  return out;
}

function normalizePhoneForRecordingLookup(raw) {
  let s = String(raw || "")
    .trim()
    .replace(/\s+/g, "");
  if (!s) return "";
  if (!s.startsWith("+")) {
    const digits = s.replace(/\D/g, "");
    if (digits.length === 10) s = `+1${digits}`;
    else if (digits.length >= 8 && digits.length <= 15) s = `+${digits}`;
  }
  return /^\+[1-9]\d{6,14}$/.test(s) ? s : "";
}

/** Find completed recordings for recent calls to/from this E.164 number. */
async function fetchCompletedRecordingsForPhone(phone) {
  const e164 = normalizePhoneForRecordingLookup(phone);
  if (!e164) return [];
  const providers = ["twilio"];
  if (isSignalWireConfigured()) providers.push("signalwire");
  const callSids = new Set();
  for (const provider of providers) {
    let client;
    try {
      client = getVoiceClientFor(provider);
    } catch {
      continue;
    }
    for (const opts of [{ to: e164 }, { from: e164 }]) {
      try {
        const calls = await client.calls.list({ ...opts, limit: 30 });
        for (const call of calls || []) {
          const sid = String(call.sid || "").trim();
          if (sid) callSids.add(sid);
        }
      } catch (_) {
        /* ignore */
      }
    }
  }
  const out = [];
  const seen = new Set();
  for (const sid of callSids) {
    const recs = await fetchCompletedRecordingsForCallSid(sid);
    for (const rec of recs) {
      if (seen.has(rec.recordingSid)) continue;
      seen.add(rec.recordingSid);
      out.push(rec);
    }
  }
  return out;
}

function isLikelyTwilioApiKey(value) {
  return /^SK[0-9a-f]{32}$/i.test(String(value || "").trim());
}

function isLikelyTwilioAuthToken(value) {
  const s = String(value || "").trim();
  if (!s) return false;
  if (s.includes("@") || /\s/.test(s)) return false;
  if (s.startsWith("$2") || s.startsWith("scrypt:")) return false;
  return /^[0-9a-f]{32}$/i.test(s);
}

function isLikelyTwilioApiSecret(value) {
  const s = String(value || "").trim();
  if (!s || s.length < 16) return false;
  if (isLikelyTwilioAuthToken(s)) return false;
  if (s.includes("@") || /\s/.test(s)) return false;
  return true;
}

async function verifyTwilioVoiceApiCredentials({
  accountSid,
  apiKey,
  apiSecret,
  voiceTwimlAppSid
} = {}) {
  const sid = String(accountSid || process.env.TWILIO_ACCOUNT_SID || "").trim();
  const key = String(apiKey || process.env.TWILIO_API_KEY || "").trim();
  const secret = String(apiSecret || process.env.TWILIO_API_SECRET || "").trim();
  const appSid = String(voiceTwimlAppSid || process.env.TWILIO_VOICE_TWIML_APP_SID || "").trim();
  if (!sid || !key || !secret || !appSid) {
    return { ok: false, error: "Missing Account SID, API Key, API Secret, or Voice TwiML App SID." };
  }
  if (!/^AC[0-9a-f]{32}$/i.test(sid)) {
    return { ok: false, error: "Account SID must start with AC (from Twilio Console → Account)." };
  }
  if (!isLikelyTwilioApiKey(key)) {
    return {
      ok: false,
      error:
        "API Key must be an API Key SID (starts with SK). In Twilio Console go to Account → API keys & tokens → Create API key."
    };
  }
  if (!isLikelyTwilioApiSecret(secret)) {
    return {
      ok: false,
      error:
        "API Secret is not the Auth Token. Use the secret shown once when you create the API key (longer string, not 32 hex characters)."
    };
  }
  if (!appSid.startsWith("AP")) {
    return { ok: false, error: "Voice TwiML App SID must start with AP." };
  }
  try {
    const client = twilio(key, secret, { accountSid: sid });
    const app = await client.applications(appSid).fetch();
    return {
      ok: true,
      twimlAppVoiceUrl: String(app.voiceUrl || "").trim()
    };
  } catch (err) {
    const code = err && err.code;
    const msg = err && err.message ? err.message : String(err);
    let extra = "";
    if (code === 20404 || /was not found/i.test(msg)) {
      return {
        ok: false,
        error:
          "The TwiML Application SID in Settings is missing or does not match this Twilio account. In Twilio Console go to Voice → TwiML → TwiML Apps, open (or create) an app, set Voice Request URL to your live CRM /webhooks/twilio/voice (POST), copy the AP… SID, paste it in Settings → Twilio, and save."
      };
    }
    if (code === 20003) {
      extra =
        " This usually means the API Secret does not match the SK key, the Account SID is from a different Twilio account, or the server is using a stale TWILIO_API_SECRET from .env.";
    }
    return {
      ok: false,
      error: code
        ? `Twilio rejected API Key/Secret (${code}): ${msg}.${extra} Create a new API key, paste both SID and secret, and save.`
        : `Twilio rejected API Key/Secret: ${msg}${extra}`
    };
  }
}

async function provisionVoiceApiKey({ accountSid, authToken, friendlyName } = {}) {
  const sid = String(accountSid || process.env.TWILIO_ACCOUNT_SID || "").trim();
  const token = String(authToken || process.env.TWILIO_AUTH_TOKEN || "").trim();
  if (!sid || !token) {
    throw new Error("Account SID and Auth Token are required to create a Voice API key.");
  }
  const client = twilio(sid, token);
  const key = await client.newKeys.create({
    friendlyName: String(friendlyName || `Cadence CRM Voice ${new Date().toISOString().slice(0, 10)}`).trim()
  });
  const apiKey = String(key.sid || "").trim();
  const apiSecret = String(key.secret || "").trim();
  if (!apiKey || !apiSecret) {
    throw new Error("Twilio created an API key but did not return the secret.");
  }
  return { apiKey, apiSecret };
}

async function createVoiceTwimlApp({ voiceWebhookUrl, friendlyName } = {}) {
  const client = getClient();
  const url = String(voiceWebhookUrl || "").trim();
  const app = await client.applications.create({
    friendlyName: String(friendlyName || "Cadence CRM Voice").trim(),
    ...(url ? { voiceUrl: url, voiceMethod: "POST" } : {})
  });
  return {
    sid: String(app.sid || "").trim(),
    voiceUrl: String(app.voiceUrl || "").trim()
  };
}

async function fetchVoiceTwimlApp(appSid) {
  const client = getVoiceApiClient();
  const sid = String(appSid || process.env.TWILIO_VOICE_TWIML_APP_SID || "").trim();
  if (!sid) throw new Error("Voice TwiML App SID is not configured.");
  const app = await client.applications(sid).fetch();
  return {
    sid: app.sid,
    voiceUrl: String(app.voiceUrl || "").trim(),
    voiceMethod: String(app.voiceMethod || "POST").trim() || "POST"
  };
}

async function syncVoiceTwimlAppUrl({ appSid, voiceWebhookUrl } = {}) {
  const client = getVoiceApiClient();
  const sid = String(appSid || process.env.TWILIO_VOICE_TWIML_APP_SID || "").trim();
  const url = String(voiceWebhookUrl || "").trim();
  if (!sid) throw new Error("Voice TwiML App SID is not configured.");
  if (!url) throw new Error("Voice webhook URL is required.");
  if (!sid.startsWith("AP")) {
    throw new Error("Voice TwiML App SID must start with AP.");
  }
  const app = await client.applications(sid).update({
    voiceUrl: url,
    voiceMethod: "POST"
  });
  return {
    sid: app.sid,
    voiceUrl: String(app.voiceUrl || "").trim(),
    voiceMethod: String(app.voiceMethod || "POST").trim() || "POST"
  };
}

module.exports = {
  sendSms,
  composeOutboundSms,
  resolveSmsEnding,
  DEFAULT_SMS_ENDING,
  keepPhoneNumberFullyLinked,
  appendSmsOptOut,
  normalizePhoneRecipient,
  normalizeSmsRecipient,
  resolveFromNumberWithFallback,
  startCall,
  startCallRecording,
  getCallStatus,
  endCall,
  fetchCompletedRecordingsForCallSid,
  fetchCompletedRecordingsForPhone,
  isTwilioSmsReady,
  listAccountSmsNumbers,
  getTwilioSmsMissing,
  normalizeTwilioFromLine,
  resolveFromNumber,
  fetchVoiceTwimlApp,
  syncVoiceTwimlAppUrl,
  isLikelyTwilioApiKey,
  isLikelyTwilioApiSecret,
  verifyTwilioVoiceApiCredentials,
  provisionVoiceApiKey,
  createVoiceTwimlApp,
  getVoiceProvider,
  getVoiceProviderMode,
  isSignalWireVoiceProvider,
  isSignalWireVoiceReady,
  isSignalWireConfigured,
  getSignalWireMissing
};
