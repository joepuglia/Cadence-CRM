"use strict";

const crypto = require("crypto");
const fs = require("fs");
const https = require("https");
const { URL } = require("url");

const DEFAULT_API_VERSION = "v21.0";

function envTrim(name) {
  return String(process.env[name] || "").trim();
}

function normalizeProvider(raw) {
  const p = String(raw || "")
    .trim()
    .toLowerCase();
  if (p === "meta" || p === "cloud" || p === "facebook" || p === "graph") return "meta";
  return "twilio";
}

function getResolvedWhatsAppProvider() {
  return normalizeProvider(envTrim("WHATSAPP_PROVIDER"));
}

function getMetaWhatsAppMissing() {
  const missing = [];
  if (!envTrim("META_WHATSAPP_PHONE_NUMBER_ID")) missing.push("META_WHATSAPP_PHONE_NUMBER_ID");
  if (!envTrim("META_WHATSAPP_ACCESS_TOKEN")) missing.push("META_WHATSAPP_ACCESS_TOKEN");
  return missing;
}

function isMetaWhatsAppReady() {
  return getMetaWhatsAppMissing().length === 0;
}

function graphApiVersion() {
  const v = envTrim("META_WHATSAPP_API_VERSION");
  return v || DEFAULT_API_VERSION;
}

/** When false, HTTPS to Graph accepts any server cert (dev / broken corporate proxy only). */
function metaGraphTlsRejectUnauthorized() {
  const v = String(process.env.META_WHATSAPP_TLS_REJECT_UNAUTHORIZED || "").trim().toLowerCase();
  if (v === "0" || v === "false" || v === "off" || v === "no") return false;
  return true;
}

/** Optional PEM file (extra root/intermediate) appended for Graph TLS verification. */
function readMetaGraphExtraCaPem() {
  const p = String(process.env.META_WHATSAPP_TLS_CA_FILE || process.env.META_WHATSAPP_EXTRA_CA_CERTS || "").trim();
  if (!p) return null;
  try {
    return fs.readFileSync(p, "utf8");
  } catch (err) {
    console.warn(`Meta WhatsApp: could not read TLS CA file (${p}):`, err && err.message ? err.message : err);
    return null;
  }
}

/**
 * POST JSON to graph.facebook.com with explicit TLS options (avoids undici/fetch
 * ignoring some corporate CA setups; supports relax-verify for dev only).
 */
function httpsPostJson(urlStr, headers, jsonBody) {
  const bodyUtf8 = typeof jsonBody === "string" ? jsonBody : JSON.stringify(jsonBody);
  const u = new URL(urlStr);
  const extraCa = readMetaGraphExtraCaPem();
  return new Promise((resolve, reject) => {
    const opts = {
      hostname: u.hostname,
      port: u.port || 443,
      path: `${u.pathname}${u.search}`,
      method: "POST",
      headers: {
        ...headers,
        "Content-Length": Buffer.byteLength(bodyUtf8, "utf8")
      },
      rejectUnauthorized: metaGraphTlsRejectUnauthorized(),
      servername: u.hostname
    };
    if (extraCa) {
      opts.ca = extraCa;
    }
    const req = https.request(opts, (res) => {
      const chunks = [];
      res.on("data", (d) => chunks.push(d));
      res.on("end", () => {
        resolve({
          statusCode: res.statusCode || 0,
          text: Buffer.concat(chunks).toString("utf8")
        });
      });
    });
    req.on("error", reject);
    req.write(bodyUtf8, "utf8");
    req.end();
  });
}

/** Meta Cloud API expects recipient as digits only (no +). */
function toMetaRecipientDigits(toE164) {
  let s = String(toE164 || "").trim().replace(/^whatsapp:/i, "");
  if (!s) throw new Error("Recipient phone number is required.");
  const withPlus = s.startsWith("+") ? s : `+${s}`;
  const digits = withPlus.replace(/\D/g, "");
  if (digits.length < 8 || digits.length > 15) {
    throw new Error("Recipient must be a valid international phone number (E.164).");
  }
  return digits;
}

function waIdToE164Digits(waId) {
  const d = String(waId || "").replace(/\D/g, "");
  return d;
}

function waIdToPlusE164(waId) {
  const d = waIdToE164Digits(waId);
  if (!d) return "";
  return `+${d}`;
}

async function graphPostMessages(payload) {
  const phoneId = envTrim("META_WHATSAPP_PHONE_NUMBER_ID");
  const token = envTrim("META_WHATSAPP_ACCESS_TOKEN");
  const version = graphApiVersion();
  const url = `https://graph.facebook.com/${encodeURIComponent(version)}/${encodeURIComponent(phoneId)}/messages`;
  let res;
  try {
    res = await httpsPostJson(
      url,
      {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      payload
    );
  } catch (err) {
    const msg = err && err.message ? String(err.message) : "Graph API request failed";
    const e = new Error(
      /unable to verify the first certificate|UNABLE_TO_VERIFY_LEAF_SIGNATURE|self-signed certificate in certificate chain|certificate has expired/i.test(
        msg
      )
        ? `${msg} — Try NODE_OPTIONS=--use-system-ca (Node 22+) so Node uses your OS certificate store, or set META_WHATSAPP_TLS_CA_FILE / NODE_EXTRA_CA_CERTS to a PEM bundle. For local dev only (insecure): META_WHATSAPP_TLS_REJECT_UNAUTHORIZED=0.`
        : msg
    );
    e.cause = err;
    throw e;
  }
  const text = res.text;
  let json;
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    json = { raw: text };
  }
  const ok = res.statusCode >= 200 && res.statusCode < 300;
  if (!ok) {
    const msg =
      (json && json.error && (json.error.error_user_msg || json.error.message)) ||
      (typeof text === "string" && text.slice(0, 400)) ||
      `Graph API HTTP ${res.statusCode}`;
    const err = new Error(msg);
    err.status = res.statusCode;
    err.graph = json;
    throw err;
  }
  return json;
}

/**
 * Send a free-form text message (within the customer care window).
 * @returns {{ sid: string, status: string, to: string, from: string, sandbox: boolean, template: boolean }}
 */
async function sendMetaWhatsAppText({ toE164, body }) {
  const text = String(body || "").trim();
  if (!text) throw new Error("Message body is required.");
  const digits = toMetaRecipientDigits(toE164);
  const json = await graphPostMessages({
    messaging_product: "whatsapp",
    to: digits,
    type: "text",
    text: { preview_url: false, body: text }
  });
  const sid = String((json.messages && json.messages[0] && json.messages[0].id) || "").trim();
  const phoneId = envTrim("META_WHATSAPP_PHONE_NUMBER_ID");
  return {
    sid: sid || "unknown",
    status: "accepted",
    to: waIdToPlusE164(digits),
    from: phoneId ? `meta:${phoneId}` : "meta",
    sandbox: false,
    template: false
  };
}

/**
 * Send an approved template via Cloud API.
 * @param {{ toE164: string, templateName: string, languageCode: string, variableMap: Record<string,string> }} args
 */
async function sendMetaWhatsAppTemplate({ toE164, templateName, languageCode, variableMap }) {
  const name = String(templateName || "").trim();
  if (!name) throw new Error("Meta template name is required.");
  const lang = String(languageCode || "en_US").trim().replace("-", "_");
  const digits = toMetaRecipientDigits(toE164);
  const keys = Object.keys(variableMap || {})
    .filter((k) => /^\d+$/.test(k))
    .map((k) => Number(k))
    .filter((n) => Number.isInteger(n) && n > 0)
    .sort((a, b) => a - b);
  const parameters = keys.map((k) => ({
    type: "text",
    text: String(variableMap[String(k)] == null ? "" : variableMap[String(k)])
  }));
  const template = {
    name,
    language: { code: lang }
  };
  if (parameters.length) {
    template.components = [{ type: "body", parameters }];
  }
  const json = await graphPostMessages({
    messaging_product: "whatsapp",
    to: digits,
    type: "template",
    template
  });
  const sid = String((json.messages && json.messages[0] && json.messages[0].id) || "").trim();
  const phoneId = envTrim("META_WHATSAPP_PHONE_NUMBER_ID");
  return {
    sid: sid || "unknown",
    status: "accepted",
    to: waIdToPlusE164(digits),
    from: phoneId ? `meta:${phoneId}` : "meta",
    sandbox: false,
    template: true
  };
}

function verifyMetaWebhookSignature(rawBodyBuf, signatureHeader, appSecret) {
  const secret = String(appSecret || "").trim();
  if (!secret) return true;
  const sig = String(signatureHeader || "").trim();
  const expectedPrefix = "sha256=";
  if (!sig.startsWith(expectedPrefix)) return false;
  const theirs = sig.slice(expectedPrefix.length);
  const hmac = crypto.createHmac("sha256", secret);
  hmac.update(rawBodyBuf);
  const ours = hmac.digest("hex");
  try {
    return crypto.timingSafeEqual(Buffer.from(theirs, "hex"), Buffer.from(ours, "hex"));
  } catch {
    return false;
  }
}

/**
 * Extract inbound text messages + delivery statuses from a Cloud API webhook body.
 * @returns {{ inbound: Array<{ fromWaId: string, toPhoneNumberId: string, body: string, messageId: string }>, statuses: Array<{ id: string, status: string, errors?: string }> }}
 */
function parseMetaWhatsAppWebhook(body) {
  const inbound = [];
  const statuses = [];
  const entries = Array.isArray(body && body.entry) ? body.entry : [];
  for (const ent of entries) {
    const changes = Array.isArray(ent.changes) ? ent.changes : [];
    for (const ch of changes) {
      const value = ch && ch.value;
      if (!value || String(ch.field || "") !== "messages") continue;
      const phoneNumberId = String((value.metadata && value.metadata.phone_number_id) || "").trim();
      const messages = Array.isArray(value.messages) ? value.messages : [];
      for (const m of messages) {
        const fromWaId = String(m.from || "").trim();
        const messageId = String(m.id || "").trim();
        const type = String(m.type || "").trim().toLowerCase();
        let textBody = "";
        if (type === "text" && m.text && m.text.body != null) {
          textBody = String(m.text.body);
        } else if (type) {
          textBody = `[${type}]`;
        }
        if (fromWaId && messageId) {
          inbound.push({ fromWaId, toPhoneNumberId: phoneNumberId, body: textBody, messageId });
        }
      }
      const stList = Array.isArray(value.statuses) ? value.statuses : [];
      for (const st of stList) {
        const id = String(st.id || "").trim();
        const status = String(st.status || "").trim();
        if (!id || !status) continue;
        const errs = Array.isArray(st.errors)
          ? st.errors
              .map((e) => String((e && (e.title || e.message || e.code)) || "").trim())
              .filter(Boolean)
              .join("; ")
          : "";
        statuses.push({ id, status, errors: errs });
      }
    }
  }
  return { inbound, statuses };
}

module.exports = {
  getResolvedWhatsAppProvider,
  getMetaWhatsAppMissing,
  isMetaWhatsAppReady,
  graphApiVersion,
  toMetaRecipientDigits,
  waIdToPlusE164,
  sendMetaWhatsAppText,
  sendMetaWhatsAppTemplate,
  verifyMetaWebhookSignature,
  parseMetaWhatsAppWebhook
};
