"use strict";

const { encryptField } = require("./fieldEncryption");

/**
 * Parse one CSV line (RFC 4180-style quoted fields). Does not support newlines inside quotes.
 * Kept for backward-compat callers / tests; the full parser below handles multi-line cells.
 */
function parseCsvLine(line) {
  const result = [];
  let current = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i += 1) {
    const c = line[i];
    if (inQuotes) {
      if (c === '"') {
        if (line[i + 1] === '"') {
          current += '"';
          i += 1;
        } else {
          inQuotes = false;
        }
      } else {
        current += c;
      }
    } else if (c === '"') {
      inQuotes = true;
    } else if (c === ",") {
      result.push(current.trim());
      current = "";
    } else {
      current += c;
    }
  }
  result.push(current.trim());
  return result;
}

/**
 * Full RFC 4180 CSV parser that walks the entire text as a character stream so that
 * line breaks inside quoted fields (e.g. long notes pasted from Word/Excel) stay
 * attached to that single cell instead of bleeding into the next row's First/Last Name.
 *
 * Returns { headers, rows } where each row is an array of trimmed cell strings.
 * Empty rows (lines that contain only whitespace) are skipped.
 */
function parseCsvFull(text) {
  const raw = typeof text === "string" ? text.replace(/^\uFEFF/, "") : "";
  const allRows = [];
  let row = [];
  let cell = "";
  let inQuotes = false;
  let cellHasContent = false; // tracks whether the current row has anything (so we can skip blank lines)

  const pushCell = () => {
    row.push(cell.trim());
    cell = "";
  };
  const pushRow = () => {
    pushCell();
    // Treat a row as "empty" if every cell is the empty string. Excel sometimes
    // writes a trailing CRLF that would otherwise produce a row of [""].
    const isBlank = row.length === 1 && row[0] === "";
    if (cellHasContent || !isBlank) allRows.push(row);
    row = [];
    cellHasContent = false;
  };

  for (let i = 0; i < raw.length; i += 1) {
    const c = raw[i];
    if (inQuotes) {
      if (c === '"') {
        if (raw[i + 1] === '"') {
          cell += '"';
          i += 1;
        } else {
          inQuotes = false;
        }
      } else {
        // Inside quotes, newlines (and everything else) are literal cell content.
        cell += c;
      }
    } else if (c === '"') {
      inQuotes = true;
      cellHasContent = true;
    } else if (c === ",") {
      pushCell();
    } else if (c === "\r") {
      // Eat CR; the row is closed by the LF that should follow (or by EOF).
      if (raw[i + 1] === "\n") i += 1;
      pushRow();
    } else if (c === "\n") {
      pushRow();
    } else {
      cell += c;
      if (c !== " " && c !== "\t") cellHasContent = true;
    }
  }
  // Flush the last row if the file does not end with a newline.
  if (inQuotes || cell.length > 0 || row.length > 0 || cellHasContent) {
    pushRow();
  }

  return allRows;
}

function mapHeaderToField(header) {
  if (!header || typeof header !== "string") return null;
  const key = header
    .replace(/^\uFEFF/, "")
    .trim()
    .toLowerCase()
    .replace(/-/g, " ")
    .replace(/\s+/g, " ");
  const aliases = {
    "full name": "full_name",
    full_name: "full_name",
    name: "full_name",
    "contact name": "full_name",
    "primary applicant full name": "full_name",
    "primary applicant name": "full_name",
    "applicant full name": "full_name",
    "applicant name": "full_name",
    "insured name": "full_name",
    "member name": "full_name",
    "client name": "full_name",
    "lead name": "full_name",
    "first name": "first_name",
    "last name": "last_name",
    first_name: "first_name",
    last_name: "last_name",
    fname: "first_name",
    lname: "last_name",
    email: "email",
    "e mail": "email",
    phone: "phone",
    "primary phone": "phone",
    "primary phone number": "phone",
    mobile: "phone",
    telephone: "phone",
    "secondary phone": "secondary_phone",
    "secondary phone number": "secondary_phone",
    status: "status",
    outcome: "outcome",
    tags: "tags",
    notes: "notes",
    "call back notes": "notes",
    "callback notes": "notes",
    "call-back notes": "notes",
    "special notes": "special_notes",
    special_notes: "special_notes",
    age: "age",
    gender: "gender",
    "household size": "household_size",
    income: "income",
    "lead source": "lead_source",
    "communication type": "communication_type",
    "date of contact": "date_of_contact",
    date_of_contact: "date_of_contact",
    "date of birth": "date_of_birth",
    date_of_birth: "date_of_birth",
    "coverages sold": "coverages_sold",
    coverages_sold: "coverages_sold",
    profession: "profession",
    quote: "quote",
    "health issues": "health_issues",
    health_issues: "health_issues",
    "coverage start date": "coverage_start_date",
    coverage_start_date: "coverage_start_date",
    "policy renewal date": "policy_renewal",
    "policy renewal": "policy_renewal",
    policy_renewal: "policy_renewal",
    policy_renewal_date: "policy_renewal",
    "bank routing": "bank_routing",
    bank_routing: "bank_routing",
    "bank account": "bank_account",
    bank_account: "bank_account",
    vcall: "vcall",
    "insurance type": "insurance_type",
    insurance_type: "insurance_type",
    commission: "commission",
    "estimated commission": "commission",
    "home address": "home_address",
    home_address: "home_address",
    household_size: "household_size",
    lead_source: "lead_source",
    communication_type: "communication_type",
    secondary_phone: "secondary_phone",
    city: "city",
    state: "state",
    zip_code: "zip_code",
    "zip code": "zip_code",
    zip: "zip_code",
    indian: "indian",
    "indian category": "indian",
    "lead flag (yes/no)": "indian",
    "lead flag": "indian",
    "indian (yes or no)": "indian",
    "last called": "last_called",
    last_called: "last_called",
    "last emailed": "last_emailed",
    "last email": "last_emailed",
    last_emailed: "last_emailed",
    "created at": "created_at",
    created_at: "created_at",
    "created date": "created_at",
    "date created": "created_at",
    "creation date": "created_at",
    "app id": "app_id",
    app_id: "app_id",
    appid: "app_id",
    "application id": "app_id",
    "application number": "app_id",
    "policy number": "app_id",
    "policy no": "app_id",
    policynumber: "app_id",
    title: "profession",
    agency: "notes",
    "agency name": "notes",
    company: "notes",
    "company agency": "notes",
    location: "city",
    "linkedin url": "notes",
    linkedin: "notes",
    "team size": "tags",
    "years of experience": "notes",
    "currently using a crm": "tags",
    "using crm": "tags",
    "crm status": "tags",
    outreach: "notes",
    "outreach status": "notes"
  };
  return aliases[key] || null;
}

function parseCsv(text) {
  const allRows = parseCsvFull(text);
  if (allRows.length === 0) return { headers: [], rows: [] };
  const [headers, ...rows] = allRows;
  return { headers, rows };
}

/**
 * Normalize a CSV "Created Date" / "created_at" cell to a SQLite-friendly datetime string.
 * Accepts ISO ("2026-05-11T15:00:00Z"), SQLite ("2026-05-11 15:00:00"), or plain dates
 * ("2026-05-11", "5/11/2026"). Returns "" when the value is missing or unparseable so the
 * server can fall back to CURRENT_TIMESTAMP.
 */
function normalizeCreatedAtImport(raw) {
  const s = String(raw == null ? "" : raw).trim();
  if (!s) return "";
  // Already in SQLite "YYYY-MM-DD HH:MM:SS" or "YYYY-MM-DD" form — pass through unchanged.
  if (/^\d{4}-\d{2}-\d{2}( \d{2}:\d{2}(:\d{2})?)?$/.test(s)) return s;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return "";
  const pad = (n) => String(n).padStart(2, "0");
  const y = d.getUTCFullYear();
  const mo = pad(d.getUTCMonth() + 1);
  const da = pad(d.getUTCDate());
  const h = pad(d.getUTCHours());
  const mi = pad(d.getUTCMinutes());
  const se = pad(d.getUTCSeconds());
  return `${y}-${mo}-${da} ${h}:${mi}:${se}`;
}

/** Normalize to Yes / No for the contact "Indian" field; accepts common CSV variants. */
function normalizeIndianCategoryImport(raw) {
  const s = String(raw == null ? "" : raw).trim();
  if (!s) return "";
  const l = s.toLowerCase();
  if (l === "yes" || l === "y" || l === "1" || l === "true") return "Yes";
  if (l === "no" || l === "n" || l === "0" || l === "false") return "No";
  if (s === "Yes" || s === "No") return s;
  return s;
}

/**
 * When two header columns map to the same field (e.g. "indian" and "Indian Category" → indian),
 * use a single value: first non-empty in left-to-right column order, so no duplicate overwrites.
 */
function rowObjects(headers, rows, columnMapping) {
  const fieldToColIndices = new Map();
  headers.forEach((h, colIdx) => {
    const headerKey = String(h || "").trim();
    let f = null;
    if (columnMapping && typeof columnMapping === "object") {
      f =
        columnMapping[headerKey] ??
        columnMapping[headerKey.toLowerCase()] ??
        null;
      if (f === "" || f === "__skip__") f = null;
    }
    if (!f) f = mapHeaderToField(h);
    if (!f) return;
    if (!fieldToColIndices.has(f)) fieldToColIndices.set(f, []);
    fieldToColIndices.get(f).push(colIdx);
  });
  return rows.map((cells) => {
    const obj = {};
    for (const [field, colIndices] of fieldToColIndices) {
      let value = "";
      for (const idx of colIndices) {
        if (idx < cells.length) {
          const t = cells[idx] == null ? "" : String(cells[idx]).trim();
          if (t) {
            value = t;
            break;
          }
        }
      }
      obj[field] = value;
    }
    return obj;
  });
}

function objectsToContacts(objects, startRowNum = 2) {
  const contacts = [];
  const parseErrors = [];
  objects.forEach((obj, idx) => {
    const rowNum = startRowNum + idx;
    const first = (obj.first_name || "").trim();
    const last = (obj.last_name || "").trim();
    let full_name = (obj.full_name || "").trim();
    if (!full_name) {
      full_name = [first, last].filter(Boolean).join(" ").trim();
    }
    if (!full_name) {
      parseErrors.push({ row: rowNum, message: "Missing name" });
      return;
    }
    contacts.push({
      full_name,
      email: (obj.email || "").trim(),
      phone: (obj.phone || "").trim(),
      secondary_phone: (obj.secondary_phone || "").trim(),
      status: (obj.status || "NEW").trim() || "NEW",
      outcome: (obj.outcome || "").trim(),
      tags: (obj.tags || "").trim(),
      notes: (obj.notes || "").trim(),
      special_notes: (obj.special_notes || "").trim(),
      age: (obj.age || "").trim(),
      gender: (obj.gender || "").trim(),
      household_size: (obj.household_size || "").trim(),
      income: (obj.income || "").trim(),
      lead_source: (obj.lead_source || "").trim(),
      communication_type: (obj.communication_type || "").trim(),
      date_of_contact: (obj.date_of_contact || "").trim(),
      date_of_birth: (obj.date_of_birth || "").trim(),
      coverages_sold: (obj.coverages_sold || "").trim(),
      profession: (obj.profession || "").trim(),
      quote: (obj.quote || "").trim(),
      health_issues: (obj.health_issues || "").trim(),
      coverage_start_date: (obj.coverage_start_date || "").trim(),
      policy_renewal: (obj.policy_renewal || "").trim(),
      bank_routing: encryptField((obj.bank_routing || "").trim()),
      bank_account: encryptField((obj.bank_account || "").trim()),
      vcall: (obj.vcall || "").trim(),
      insurance_type: (obj.insurance_type || "").trim(),
      commission: (obj.commission || "").trim(),
      home_address: (obj.home_address || "").trim(),
      city: (obj.city || "").trim(),
      state: (obj.state || "").trim(),
      zip_code: (obj.zip_code || "").trim(),
      indian: normalizeIndianCategoryImport(obj.indian),
      last_called: (obj.last_called || "").trim(),
      last_emailed: (obj.last_emailed || "").trim(),
      created_at: normalizeCreatedAtImport(obj.created_at),
      app_id: (obj.app_id || "").trim()
    });
  });
  return { contacts, parseErrors };
}

function createdAtMappedInColumnMapping(columnMapping) {
  if (!columnMapping || typeof columnMapping !== "object") return false;
  return Object.values(columnMapping).some((field) => String(field || "").trim() === "created_at");
}

/** Default import uses today's timestamp unless user opts in to keep CSV Created dates. */
function resolveImportCreatedAtSql(row, { preserveCsvCreatedDates = false, createdAtMapped = false } = {}) {
  if (preserveCsvCreatedDates && createdAtMapped) {
    const createdAtCsv = typeof row.created_at === "string" ? row.created_at.trim() : "";
    if (createdAtCsv) return { fragment: "?", params: [createdAtCsv] };
  }
  return { fragment: "CURRENT_TIMESTAMP", params: [] };
}

const CADENCE_CONTACT_FIELDS = [
  { key: "full_name", label: "Full name" },
  { key: "first_name", label: "First name (combined into full name)" },
  { key: "last_name", label: "Last name (combined into full name)" },
  { key: "email", label: "Email" },
  { key: "phone", label: "Phone" },
  { key: "secondary_phone", label: "Secondary phone" },
  { key: "status", label: "Status" },
  { key: "outcome", label: "Outcome" },
  { key: "tags", label: "Tags" },
  { key: "notes", label: "Notes" },
  { key: "special_notes", label: "Special notes" },
  { key: "lead_source", label: "Lead source" },
  { key: "age", label: "Age" },
  { key: "gender", label: "Gender" },
  { key: "household_size", label: "Household size" },
  { key: "income", label: "Income" },
  { key: "communication_type", label: "Communication type" },
  { key: "date_of_contact", label: "Date of contact" },
  { key: "date_of_birth", label: "Date of birth" },
  { key: "coverages_sold", label: "Coverages sold" },
  { key: "profession", label: "Profession" },
  { key: "quote", label: "Quote / premium" },
  { key: "health_issues", label: "Health issues" },
  { key: "coverage_start_date", label: "Coverage start date" },
  { key: "policy_renewal", label: "Policy renewal date" },
  { key: "bank_routing", label: "Bank routing" },
  { key: "bank_account", label: "Bank account" },
  { key: "vcall", label: "VCall" },
  { key: "insurance_type", label: "Insurance type" },
  { key: "commission", label: "Commission" },
  { key: "home_address", label: "Home address" },
  { key: "city", label: "City" },
  { key: "state", label: "State" },
  { key: "zip_code", label: "Zip code" },
  { key: "indian", label: "Lead flag (Yes/No)" },
  { key: "last_called", label: "Last called" },
  { key: "last_emailed", label: "Last emailed" },
  { key: "created_at", label: "Created date" },
  { key: "app_id", label: "Policy Number" }
];

const VALID_FIELD_KEYS = new Set(CADENCE_CONTACT_FIELDS.map((f) => f.key));

function getSampleValuesForHeaders(headers, rows, maxSamples = 3) {
  return headers.map((header, colIdx) => {
    const samples = [];
    for (const row of rows) {
      if (samples.length >= maxSamples) break;
      const val = row[colIdx] == null ? "" : String(row[colIdx]).trim();
      if (val) samples.push(val.slice(0, 120));
    }
    return { header: String(header || "").trim(), samples };
  });
}

function buildStaticColumnMappings(headers) {
  return headers.map((header) => {
    const field = mapHeaderToField(header);
    return {
      header: String(header || "").trim(),
      field: field || "",
      confidence: field ? "auto" : "skipped",
      source: field ? "static" : "none"
    };
  });
}

function mergeColumnMappings(headers, aiMappings) {
  const aiByHeader = new Map();
  if (Array.isArray(aiMappings)) {
    for (const item of aiMappings) {
      const header = String(item?.header || "").trim();
      if (!header) continue;
      aiByHeader.set(header.toLowerCase(), item);
    }
  }

  return headers.map((header) => {
    const headerKey = String(header || "").trim();
    const staticField = mapHeaderToField(headerKey);
    if (staticField) {
      return { header: headerKey, field: staticField, confidence: "auto", source: "static" };
    }
    const ai = aiByHeader.get(headerKey.toLowerCase());
    if (ai) {
      const field = VALID_FIELD_KEYS.has(String(ai.field || "").trim()) ? String(ai.field).trim() : "";
      const confidence = field
        ? String(ai.confidence || "review").toLowerCase() === "auto"
          ? "auto"
          : "review"
        : "skipped";
      return { header: headerKey, field, confidence, source: "ai" };
    }
    return { header: headerKey, field: "", confidence: "skipped", source: "none" };
  });
}

function columnMappingObject(mappings) {
  const out = {};
  for (const item of mappings || []) {
    const header = String(item?.header || "").trim();
    const field = String(item?.field || "").trim();
    if (header && field && VALID_FIELD_KEYS.has(field)) out[header] = field;
  }
  return out;
}

function mappingHasNameColumn(mappings) {
  const nameFields = new Set(["full_name", "first_name", "last_name"]);
  return (mappings || []).some((m) => nameFields.has(String(m.field || "").trim()));
}

function parseContactsCsvWithMapping(csvText, columnMapping) {
  const { headers, rows } = parseCsv(csvText);
  if (!headers.length) {
    return { contacts: [], parseErrors: [{ row: 0, message: "CSV has no header row" }] };
  }
  const mappingObj =
    columnMapping && typeof columnMapping === "object" ? columnMapping : columnMappingObject([]);
  const hasName =
    Object.values(mappingObj).some((f) => f === "full_name" || f === "first_name" || f === "last_name") ||
    headers.some((h) => {
      const f = mappingObj[String(h).trim()] || mapHeaderToField(h);
      return f === "full_name" || f === "first_name" || f === "last_name";
    });
  if (!hasName) {
    return {
      contacts: [],
      parseErrors: [
        {
          row: 0,
          message: 'Map at least one name column: Full name, First name, and/or Last name'
        }
      ]
    };
  }
  const objects = rowObjects(headers, rows, mappingObj);
  return objectsToContacts(objects);
}

function previewContactsCsv(csvText, columnMapping, limit = 3) {
  const { headers, rows } = parseCsv(csvText);
  const mappingObj = columnMapping && typeof columnMapping === "object" ? columnMapping : {};
  const objects = rowObjects(headers, rows.slice(0, limit), mappingObj);
  const { contacts, parseErrors } = objectsToContacts(objects, 2);
  return {
    headers,
    totalRows: rows.length,
    preview: contacts,
    parseErrors
  };
}

function parseContactsCsv(csvText, columnMapping) {
  if (columnMapping && Object.keys(columnMapping).length) {
    return parseContactsCsvWithMapping(csvText, columnMapping);
  }
  const { headers, rows } = parseCsv(csvText);
  if (!headers.length) {
    return { contacts: [], parseErrors: [{ row: 0, message: "CSV has no header row" }] };
  }

  const hasNameColumn = headers.some((h) => {
    const f = mapHeaderToField(h);
    return f === "full_name" || f === "first_name" || f === "last_name";
  });
  if (!hasNameColumn) {
    return {
      contacts: [],
      parseErrors: [
        {
          row: 0,
          message:
            'CSV must include a name column: "Full Name" / "name", or "First Name" and/or "Last Name"'
        }
      ]
    };
  }

  const objects = rowObjects(headers, rows);
  return objectsToContacts(objects);
}

module.exports = {
  parseContactsCsv,
  parseContactsCsvWithMapping,
  previewContactsCsv,
  parseCsv,
  CADENCE_CONTACT_FIELDS,
  VALID_FIELD_KEYS,
  getSampleValuesForHeaders,
  buildStaticColumnMappings,
  mergeColumnMappings,
  columnMappingObject,
  mappingHasNameColumn,
  mapHeaderToField,
  createdAtMappedInColumnMapping,
  resolveImportCreatedAtSql
};
