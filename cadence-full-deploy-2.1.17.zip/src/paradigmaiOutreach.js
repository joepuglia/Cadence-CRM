"use strict";

const { ctaButton, paradigmaiHtmlBody } = require("./emailTemplateBranding");

const TRIAL_SIGNUP_URL = "https://crmcadence.com/signup.html?utm_source=paradigmai&utm_medium=email";

const PARADIGMAI_OUTREACH_TEMPLATES = [
  {
    name: "Paradigmai — Solo Agent Trial",
    category_name: "Agent Outreach",
    subject: "CRM built for solo agents — {{first_name}}",
    body: paradigmaiHtmlBody(
      `<p style="margin:0 0 14px;">Hi {{first_name}},</p>
<p style="margin:0 0 14px;">I noticed you work as a health insurance agent. Most solo agents we talk to are still juggling spreadsheets, Gmail, and sticky notes between enrollments.</p>
<p style="margin:0 0 14px;"><strong>Cadence CRM</strong> was built only for health insurance agents — contacts, pipeline, email, SMS, drip campaigns, and Claude AI in one place (not a generic CRM).</p>
<p style="margin:0 0 8px;">Try the full Pro version free for <strong>14 days</strong> — no credit card:</p>
${ctaButton(TRIAL_SIGNUP_URL, "Start 14-day free trial")}
<p style="margin:0 0 14px;font-size:14px;color:#64748b;text-align:center;">Or copy this link: <a href="${TRIAL_SIGNUP_URL}" style="color:#4f46e5;">${TRIAL_SIGNUP_URL}</a></p>
<p style="margin:0 0 14px;">If it's not a fit, no worries. Reply with one question and I'll answer directly.</p>
<p style="margin:18px 0 0;">Best,<br/><strong>[Your name]</strong><br/>Cadence CRM</p>`,
      "contacts"
    )
  },
  {
    name: "Paradigmai — Large Agency Trial",
    category_name: "Agent Outreach",
    subject: "Keep your team on one pipeline — {{first_name}}",
    body: paradigmaiHtmlBody(
      `<p style="margin:0 0 14px;">Hi {{first_name}},</p>
<p style="margin:0 0 14px;">Running enrollments across a team usually means leads slip between inboxes, spreadsheets, and different tools.</p>
<p style="margin:0 0 14px;"><strong>Cadence CRM</strong> gives health insurance agencies one workspace: shared contacts, pipeline, email, SMS, automations, and AI drafting — built for agent workflows, not generic sales teams.</p>
<p style="margin:0 0 8px;"><strong>14-day full trial, no credit card:</strong></p>
${ctaButton(TRIAL_SIGNUP_URL, "Start 14-day free trial")}
<p style="margin:0 0 14px;">Worth a 10-minute look before your next busy season? Happy to point you at the pieces that matter for larger teams.</p>
<p style="margin:18px 0 0;">Best,<br/><strong>[Your name]</strong><br/>Cadence CRM</p>`,
      "pipeline"
    )
  },
  {
    name: "Paradigmai — Already Has CRM",
    category_name: "Agent Outreach",
    subject: "Agent-specific CRM vs generic — quick compare",
    body: paradigmaiHtmlBody(
      `<p style="margin:0 0 14px;">Hi {{first_name}},</p>
<p style="margin:0 0 14px;">Many agents we speak with already use a CRM — but it's often built for general sales, not health insurance (renewals, OEP, Medicare vs ACA, enrollment follow-up).</p>
<p style="margin:0 0 14px;"><strong>Cadence</strong> is built for health insurance agents: pipeline, email, SMS, drip campaigns, and Claude AI together — at <strong>$79/month</strong> after a 14-day full trial (no credit card to start).</p>
${ctaButton(TRIAL_SIGNUP_URL, "Start 14-day free trial")}
<p style="margin:0 0 14px;">If you're open to a side-by-side look, reply <strong>compare</strong> and I'll send the short list of what agents switch for.</p>
<p style="margin:18px 0 0;">Best,<br/><strong>[Your name]</strong><br/>Cadence CRM</p>`,
      "pipeline"
    )
  }
];

async function seedParadigmaiOutreachTemplates({ run, get }) {
  const created = [];
  const skipped = [];
  for (const tpl of PARADIGMAI_OUTREACH_TEMPLATES) {
    const existing = await get(`SELECT id FROM email_templates WHERE name = ?`, [tpl.name]);
    if (existing) {
      skipped.push(tpl.name);
      continue;
    }
    let categoryId = null;
    if (tpl.category_name) {
      const cat = await get(
        `SELECT id FROM email_template_categories WHERE LOWER(name) = LOWER(?)`,
        [tpl.category_name]
      );
      if (cat) {
        categoryId = Number(cat.id);
      } else {
        const ins = await run(`INSERT INTO email_template_categories (name) VALUES (?)`, [tpl.category_name]);
        categoryId = Number(ins.lastID);
      }
    }
    const result = await run(
      `INSERT INTO email_templates (name, subject, body, category_id) VALUES (?, ?, ?, ?)`,
      [tpl.name, tpl.subject, tpl.body, categoryId]
    );
    created.push({ id: result.lastID, name: tpl.name });
  }
  return { created, skipped, total: PARADIGMAI_OUTREACH_TEMPLATES.length };
}

module.exports = {
  TRIAL_SIGNUP_URL,
  PARADIGMAI_OUTREACH_TEMPLATES,
  seedParadigmaiOutreachTemplates
};
