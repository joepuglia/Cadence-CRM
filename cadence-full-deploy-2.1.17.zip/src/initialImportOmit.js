"use strict";

const INITIAL_IMPORT_TAG = "initial-import";
const SETTINGS_KEY = "initial_csv_import_omit";
const OMIT_GRACE_MS = 24 * 60 * 60 * 1000;
const LEGACY_BOOK_DUMP_MIN_NEW = 500;

/** SQL fragment — pass table alias when joining contacts (e.g. "c"). */
function sqlExcludeInitialImportTags(alias = "") {
  const col = alias ? `${alias}.tags` : "tags";
  return `LOWER(COALESCE(${col}, '')) NOT LIKE '%${INITIAL_IMPORT_TAG}%'`;
}

function hasInitialImportTag(tagsRaw) {
  return String(tagsRaw || "")
    .split(",")
    .map((t) => t.trim().toLowerCase())
    .filter(Boolean)
    .some((tag) => tag === INITIAL_IMPORT_TAG || tag.includes(INITIAL_IMPORT_TAG));
}

function mergeInitialImportTag(existingTags) {
  if (hasInitialImportTag(existingTags)) {
    return String(existingTags || "")
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean)
      .join(", ");
  }
  const parts = String(existingTags || "")
    .split(",")
    .map((t) => t.trim())
    .filter(Boolean);
  parts.push(INITIAL_IMPORT_TAG);
  return parts.join(", ");
}

function stripInitialImportTag(tagsRaw) {
  return String(tagsRaw || "")
    .split(",")
    .map((t) => t.trim())
    .filter((t) => {
      if (!t) return false;
      const lower = t.toLowerCase();
      return lower !== INITIAL_IMPORT_TAG && !lower.includes(INITIAL_IMPORT_TAG);
    })
    .join(", ");
}

async function getInitialImportOmitState(get) {
  const row = await get(`SELECT value FROM crm_app_settings WHERE key = ?`, [SETTINGS_KEY]);
  if (!row?.value) return null;
  try {
    return JSON.parse(String(row.value));
  } catch {
    return null;
  }
}

async function setInitialImportOmitState(run, state) {
  await run(`INSERT OR REPLACE INTO crm_app_settings (key, value) VALUES (?, ?)`, [
    SETTINGS_KEY,
    JSON.stringify(state || {})
  ]);
}

async function countTaggedInitialImport(get) {
  const row = await get(`SELECT COUNT(*) AS n FROM contacts WHERE LOWER(COALESCE(tags, '')) LIKE ?`, [
    `%${INITIAL_IMPORT_TAG}%`
  ]);
  return Number(row?.n || 0);
}

async function countUntaggedNewContacts(get) {
  const row = await get(
    `SELECT COUNT(*) AS n FROM contacts
     WHERE lower(trim(COALESCE(status, ''))) = 'new'
       AND LOWER(COALESCE(tags, '')) NOT LIKE ?`,
    [`%${INITIAL_IMPORT_TAG}%`]
  );
  return Number(row?.n || 0);
}

async function activateInitialImportOmit(run, importedCount) {
  await setInitialImportOmitState(run, {
    active: true,
    permanent: true,
    importedAt: new Date().toISOString(),
    importedCount: Number(importedCount) || 0,
    morningBriefingSkippedAt: null,
    completedAt: null
  });
}

async function activateInitialImportOmitWithGet(run, get, importedCount) {
  const prev = await getInitialImportOmitState(get);
  await setInitialImportOmitState(run, {
    ...(prev || {}),
    active: true,
    permanent: true,
    importedAt: prev?.importedAt || new Date().toISOString(),
    importedCount: Number(importedCount) || Number(prev?.importedCount || 0) || 0,
    morningBriefingSkippedAt: null,
    completedAt: null
  });
}

const STALE_NEW_BOOK_SQL = `lower(trim(COALESCE(c.status, ''))) = 'new'
       AND LOWER(COALESCE(c.tags, '')) NOT LIKE ?
       AND datetime(COALESCE(act.last_at, c.created_at)) < datetime('now', '-7 days')`;

async function tagNewContactsAsImportedBook({ run, get }, { limit = null } = {}) {
  const like = `%${INITIAL_IMPORT_TAG}%`;
  const tag = INITIAL_IMPORT_TAG;
  const staleSelect = `SELECT c.id
         FROM contacts c
         LEFT JOIN (
           SELECT contact_id, MAX(datetime(created_at)) AS last_at
           FROM contact_activity
           GROUP BY contact_id
         ) act ON act.contact_id = c.id
         WHERE ${STALE_NEW_BOOK_SQL}`;
  let result;
  if (Number.isInteger(limit) && limit > 0) {
    result = await run(
      `UPDATE contacts
       SET tags = CASE
         WHEN trim(COALESCE(tags, '')) = '' THEN ?
         ELSE trim(tags) || ', ' || ?
       END,
       updated_at = CURRENT_TIMESTAMP
       WHERE id IN (
         ${staleSelect}
         ORDER BY c.id ASC
         LIMIT ?
       )`,
      [tag, tag, like, limit]
    );
  } else {
    result = await run(
      `UPDATE contacts
       SET tags = CASE
         WHEN trim(COALESCE(tags, '')) = '' THEN ?
         ELSE trim(tags) || ', ' || ?
       END,
       updated_at = CURRENT_TIMESTAMP
       WHERE id IN (${staleSelect})`,
      [tag, tag, like]
    );
  }
  const newlyTagged = Number(result?.changes || 0);
  const taggedCount = await countTaggedInitialImport(get);
  await activateInitialImportOmitWithGet(run, get, taggedCount || newlyTagged);
  return { newlyTagged, taggedCount };
}

async function completeInitialImportOmit({ run, all, get }) {
  const rows = await all(
    `SELECT id, tags FROM contacts WHERE LOWER(COALESCE(tags, '')) LIKE ?`,
    [`%${INITIAL_IMPORT_TAG}%`]
  );
  for (const row of Array.isArray(rows) ? rows : []) {
    const nextTags = stripInitialImportTag(row.tags);
    await run(`UPDATE contacts SET tags = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [
      nextTags,
      row.id
    ]);
  }
  const state = await getInitialImportOmitState(get);
  await setInitialImportOmitState(run, {
    ...(state || {}),
    active: false,
    permanent: false,
    completedAt: new Date().toISOString()
  });
}

function isInitialImportOmitActive(state) {
  return Boolean(state?.active) || Boolean(state?.permanent);
}

function shouldSkipMorningBriefing(_state) {
  return false;
}

async function markMorningBriefingSkippedForInitialImport(run, get) {
  const state = await getInitialImportOmitState(get);
  if (!state || state.morningBriefingSkippedAt) return;
  await setInitialImportOmitState(run, {
    ...state,
    morningBriefingSkippedAt: new Date().toISOString()
  });
}

/**
 * Older builds stripped initial-import tags after 24 hours, or never wrote them
 * on the first dump. Restore once so imported books do not look like new leads.
 */
async function maybeRestoreStrippedInitialImportTags({ get, run, all }) {
  const state = await getInitialImportOmitState(get);
  if (state?.tagsRestoredAt) return state;
  const tagged = await countTaggedInitialImport(get);
  if (tagged > 0) {
    if (state?.completedAt) {
      await setInitialImportOmitState(run, {
        ...state,
        active: true,
        permanent: true,
        completedAt: null,
        tagsRestoredAt: new Date().toISOString()
      });
    }
    return getInitialImportOmitState(get);
  }
  const untaggedNew = await countUntaggedNewContacts(get);
  const importedCount = Number(state?.importedCount);
  const looksLikeStrippedBook = Boolean(state?.completedAt) || (Number.isFinite(importedCount) && importedCount > 0);
  const looksLikeLegacyBookDump = !state && untaggedNew >= LEGACY_BOOK_DUMP_MIN_NEW;
  if (!looksLikeStrippedBook && !looksLikeLegacyBookDump) return state;
  const limit = Number.isFinite(importedCount) && importedCount > 0 ? Math.floor(importedCount) : null;
  await tagNewContactsAsImportedBook({ run, all, get }, { limit });
  const next = await getInitialImportOmitState(get);
  await setInitialImportOmitState(run, {
    ...(next || {}),
    tagsRestoredAt: new Date().toISOString(),
    restoredReason: looksLikeLegacyBookDump ? "legacy_book_dump" : "stripped_tags"
  });
  return getInitialImportOmitState(get);
}

async function maybeCompleteExpiredInitialImportOmit(deps) {
  return maybeRestoreStrippedInitialImportTags(deps);
}

module.exports = {
  INITIAL_IMPORT_TAG,
  SETTINGS_KEY,
  OMIT_GRACE_MS,
  sqlExcludeInitialImportTags,
  hasInitialImportTag,
  mergeInitialImportTag,
  stripInitialImportTag,
  getInitialImportOmitState,
  activateInitialImportOmit,
  activateInitialImportOmitWithGet,
  tagNewContactsAsImportedBook,
  countTaggedInitialImport,
  countUntaggedNewContacts,
  completeInitialImportOmit,
  isInitialImportOmitActive,
  shouldSkipMorningBriefing,
  markMorningBriefingSkippedForInitialImport,
  maybeRestoreStrippedInitialImportTags,
  maybeCompleteExpiredInitialImportOmit,
  LEGACY_BOOK_DUMP_MIN_NEW
};
