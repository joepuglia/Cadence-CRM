const QUICK_FILTER_SETTING_KEY = "contact_workspace_quick_filter_fields";
const STATUS_SETTING_KEY = "contact_workspace_status_labels";
const OUTCOME_SETTING_KEY = "contact_workspace_outcome_labels";
const LEAD_SOURCE_SETTING_KEY = "contact_workspace_lead_source_labels";
const SORT_BY_SETTING_KEY = "contact_workspace_sort_by_options";

const DISALLOWED_QUICK_FILTER_VALUES = new Set(["lead_score", "ai_lead_score", "ai_score", "minLeadScore"]);

/** Dropdown slug → [API sortBy column, sortOrder]. */
const SORT_BY_ORDER_MAP = {
  newest: ["created_at", "desc"],
  details_changed: ["updated_at", "desc"],
  last_emailed: ["last_emailed", "desc"],
  last_sms: ["last_sms", "desc"],
  last_called: ["last_called", "desc"],
  last_tagged: ["last_tagged", "desc"],
  full_name: ["full_name", "asc"],
  status: ["status", "asc"],
  outcome: ["outcome", "asc"],
  state: ["state", "asc"],
  lead_source: ["lead_source", "asc"],
  ai_lead_score: ["ai_lead_score", "desc"],
  gender: ["gender", "asc"],
  indian: ["indian", "asc"],
  age: ["age", "desc"],
  profession: ["profession", "asc"],
  income: ["income", "desc"],
  quote: ["quote", "desc"],
  commission: ["commission", "desc"],
  email: ["email", "asc"],
  city: ["city", "asc"],
  zip_code: ["zip_code", "asc"],
  communication_type: ["communication_type", "asc"],
  date_of_contact: ["date_of_contact", "desc"],
  date_of_birth: ["date_of_birth", "desc"],
  coverage_start_date: ["coverage_start_date", "desc"],
  insurance_type: ["insurance_type", "asc"],
  app_id: ["app_id", "asc"],
    household_size: ["household_size", "desc"],
    tags: ["tags", "asc"]
  };

/** Every sort field an admin can add in Settings (defaults use SORT_BY_OPTIONS_BASE only). */
const SORT_BY_FIELD_CATALOG_BASE = [
  { value: "newest", label: "Newest" },
  { value: "details_changed", label: "Details Changed" },
  { value: "last_emailed", label: "Last Emailed" },
  { value: "last_sms", label: "Last SMS" },
  { value: "last_called", label: "Last Called" },
  { value: "last_tagged", label: "Last Tagged" },
  { value: "full_name", label: "Name" },
  { value: "status", label: "Status" },
  { value: "outcome", label: "Outcome" },
  { value: "state", label: "State" },
  { value: "lead_source", label: "Lead Source" },
  { value: "ai_lead_score", label: "AI Score" },
  { value: "gender", label: "Gender" },
  { value: "age", label: "Age" },
  { value: "profession", label: "Profession" },
  { value: "income", label: "Income" },
  { value: "quote", label: "Quote" },
  { value: "commission", label: "Commission" },
  { value: "email", label: "Email" },
  { value: "city", label: "City" },
  { value: "zip_code", label: "Zip Code" },
  { value: "communication_type", label: "Communication Type" },
  { value: "date_of_contact", label: "Date of Contact" },
  { value: "date_of_birth", label: "Date of Birth" },
  { value: "coverage_start_date", label: "Coverage Start Date" },
  { value: "app_id", label: "Policy Number" },
    { value: "household_size", label: "Household Size" },
    { value: "tags", label: "Tags" }
  ];

const ALLOWED_SORT_BY_VALUES = new Set(Object.keys(SORT_BY_ORDER_MAP));

const SORT_BY_OPTIONS_BASE = [
  { value: "newest", label: "Newest" },
  { value: "details_changed", label: "Details Changed" },
  { value: "last_emailed", label: "Last Emailed" },
  { value: "last_sms", label: "Last SMS" },
  { value: "last_called", label: "Last Called" },
  { value: "last_tagged", label: "Last Tagged" },
  { value: "state", label: "State" },
  { value: "lead_source", label: "Lead Source" },
  { value: "ai_lead_score", label: "AI Score" },
  { value: "gender", label: "Gender" },
  { value: "profession", label: "Profession" },
  { value: "income", label: "Income" },
    { value: "date_of_contact", label: "Date of Contact" },
    { value: "household_size", label: "Household Size" }
  ];

const SORT_BY_OPTION_INDIAN_OWNER = { value: "indian", label: "Indian" };

function defaultSortByOptions() {
  // Indian is catalog-only: owners can add it from Settings, but it is no longer a default sort field.
  return SORT_BY_OPTIONS_BASE.map((x) => ({ ...x }));
}

function sortByFieldCatalog(includeIndian) {
  const fields = SORT_BY_FIELD_CATALOG_BASE.map((x) => ({ ...x }));
  if (includeIndian) fields.push({ ...SORT_BY_OPTION_INDIAN_OWNER });
  return fields;
}

const QUICK_FILTER_FIELDS_BASE = [
  { value: "tags", label: "Tags" },
  { value: "status", label: "Status" },
  { value: "outcome", label: "Outcome" },
  { value: "lead_source", label: "Lead Source" },
  { value: "insurance_type", label: "Insurance Type" }
];

/** Every Quick Filter field an admin can add in Settings (defaults use QUICK_FILTER_FIELDS_BASE only). */
const QUICK_FILTER_FIELD_CATALOG_BASE = [
  { value: "tags", label: "Tags" },
  { value: "status", label: "Status" },
  { value: "outcome", label: "Outcome" },
  { value: "lead_source", label: "Lead Source" },
  { value: "state", label: "State" },
  { value: "gender", label: "Gender" },
  { value: "city", label: "City" },
  { value: "zip_code", label: "Zip Code" },
  { value: "email", label: "Email" },
  { value: "profession", label: "Profession" },
  { value: "communication_type", label: "Communication Type" },
  { value: "app_id", label: "Policy Number" },
  { value: "income", label: "Income" },
  { value: "quote", label: "Quote" },
  { value: "commission", label: "Commission" },
  { value: "age", label: "Age" },
  { value: "household_size", label: "Household Size" },
  { value: "insurance_type", label: "Insurance Type" }
];

const QUICK_FILTER_FIELD_INDIAN_OWNER = { value: "indian", label: "Indian" };

const ALLOWED_QUICK_FILTER_VALUES = new Set([
  ...QUICK_FILTER_FIELD_CATALOG_BASE.map((x) => x.value),
  QUICK_FILTER_FIELD_INDIAN_OWNER.value
]);

function defaultQuickFilterFields() {
  // Indian is catalog-only: owners can add it from Settings, but it is no longer a default Quick Filter field.
  return QUICK_FILTER_FIELDS_BASE.map((x) => ({ ...x }));
}

function quickFilterFieldCatalog(includeIndian) {
  const fields = QUICK_FILTER_FIELD_CATALOG_BASE.map((x) => ({ ...x }));
  if (includeIndian) fields.push({ ...QUICK_FILTER_FIELD_INDIAN_OWNER });
  return fields;
}

const DEFAULT_STATUS_LABELS = ["NEW", "PENDING", "APPROVED", "DECLINED", "CLOSED", "WORKING", "NOT TAKEN"];

const DEFAULT_OUTCOME_LABELS = [
  "Bad Email",
  "Bad Number",
  "Call Back",
  "Cannot Afford",
  "Cannot Insure",
  "DECLINED",
  "DNC",
  "Drip Campaign",
  "Employer Plan",
  "Fake Lead",
  "Has Coverage",
  "Long Term CB",
  "No Contact",
  "Not Interested",
  "Referred",
  "Rude",
  "SOLD",
  "Stop",
  "Stopped Responding",
  "Too Many Calls",
  "Very Interested",
  "Wrong Number"
];

const DEFAULT_LEAD_SOURCE_LABELS = [
  "Website",
  "Referral",
  "Telemarketing",
  "Facebook",
  "Instagram",
  "Google",
  "Nextgen"
];

function normalizeLabelList(raw, fallback) {
  let arr = raw;
  if (typeof raw === "string") {
    try {
      arr = JSON.parse(raw);
    } catch {
      arr = [];
    }
  }
  if (!Array.isArray(arr)) return [...fallback];
  const out = [];
  const seen = new Set();
  for (const item of arr) {
    const label = String(item == null ? "" : item).trim();
    if (!label) continue;
    const key = label.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(label);
  }
  return out.length ? out : [...fallback];
}

function normalizeQuickFilterFields(raw, fallback) {
  let arr = raw;
  if (typeof raw === "string") {
    try {
      arr = JSON.parse(raw);
    } catch {
      arr = [];
    }
  }
  if (!Array.isArray(arr)) return fallback.map((x) => ({ ...x }));
  const defaultByValue = new Map(fallback.map((x) => [x.value, x.label]));
  for (const item of QUICK_FILTER_FIELD_CATALOG_BASE) {
    if (!defaultByValue.has(item.value)) defaultByValue.set(item.value, item.label);
  }
  const out = [];
  const seen = new Set();
  for (const item of arr) {
    const value = String((item && item.value) || "").trim();
    const label =
      String((item && item.label) || "").trim() ||
      String(defaultByValue.get(value) || value).trim() ||
      value;
    const normalizedLabel = label.toLowerCase().replace(/[^a-z0-9]+/g, "");
    if (
      DISALLOWED_QUICK_FILTER_VALUES.has(value) ||
      normalizedLabel === "leadscore" ||
      normalizedLabel === "aileadscore" ||
      !ALLOWED_QUICK_FILTER_VALUES.has(value) ||
      seen.has(value)
    ) {
      continue;
    }
    seen.add(value);
    out.push({ value, label });
  }
  return out.length ? out : fallback.map((x) => ({ ...x }));
}

function normalizeSortByOptions(raw, fallback, { omitIndian = false } = {}) {
  let arr = raw;
  if (typeof raw === "string") {
    try {
      arr = JSON.parse(raw);
    } catch {
      arr = [];
    }
  }
  if (!Array.isArray(arr)) return fallback.map((x) => ({ ...x }));
  const defaultByValue = new Map(fallback.map((x) => [x.value, x.label]));
  const out = [];
  const seen = new Set();
  for (const item of arr) {
    const value = String((item && item.value) || "").trim();
    if (!ALLOWED_SORT_BY_VALUES.has(value) || seen.has(value)) continue;
    if (omitIndian && value === "indian") continue;
    seen.add(value);
    const label =
      String((item && item.label) || "").trim() ||
      String(defaultByValue.get(value) || value).trim() ||
      value;
    out.push({ value, label });
  }
  return out.length ? out : fallback.map((x) => ({ ...x }));
}

function omitIndianSortByOptions(fields) {
  return (Array.isArray(fields) ? fields : []).filter((f) => String(f?.value || "").trim() !== "indian");
}

async function readSetting(get, key) {
  const row = await get(`SELECT value FROM crm_app_settings WHERE key = ?`, [key]);
  return row ? String(row.value || "") : "";
}

async function writeSetting(run, key, value) {
  await run(`INSERT OR REPLACE INTO crm_app_settings (key, value) VALUES (?, ?)`, [key, String(value || "")]);
}

function getDefaultContactWorkspaceOptions() {
  return {
    quickFilterFields: defaultQuickFilterFields(),
    statusLabels: [...DEFAULT_STATUS_LABELS],
    outcomeLabels: [...DEFAULT_OUTCOME_LABELS],
    leadSourceLabels: [...DEFAULT_LEAD_SOURCE_LABELS],
    sortByOptions: defaultSortByOptions()
  };
}

function parseJsonArray(raw) {
  const s = String(raw || "").trim();
  if (!s) return null;
  try {
    return JSON.parse(s);
  } catch {
    return null;
  }
}

function omitIndianQuickFilterFields(fields) {
  return (Array.isArray(fields) ? fields : []).filter((f) => String(f?.value || "").trim() !== "indian");
}

function omitInsuranceTypeSortOption(fields) {
  return (Array.isArray(fields) ? fields : []).filter((f) => String(f?.value || "").trim() !== "insurance_type");
}

function withInsuranceTypeQuickFilter(fields) {
  const list = Array.isArray(fields) ? fields.map((x) => ({ ...x })) : [];
  const existing = list.find((row) => String(row?.value || "") === "insurance_type");
  if (existing) {
    existing.label = "Insurance Type";
    return list;
  }
  const row = { value: "insurance_type", label: "Insurance Type" };
  const after = list.findIndex((item) => String(item?.value || "") === "lead_source");
  list.splice(after >= 0 ? after + 1 : list.length, 0, row);
  return list;
}

async function fetchDistinctContactLeadSources(all) {
  if (typeof all !== "function") return [];
  try {
    const rows = await all(
      `SELECT DISTINCT trim(lead_source) AS lead_source
       FROM contacts
       WHERE trim(COALESCE(lead_source, '')) != ''
       ORDER BY lower(trim(lead_source)) ASC`
    );
    return (Array.isArray(rows) ? rows : [])
      .map((row) => String(row?.lead_source || "").trim())
      .filter(Boolean);
  } catch {
    return [];
  }
}

function mergeLeadSourceLabels(configured, inUse) {
  const out = [];
  const seen = new Set();
  for (const item of [...(Array.isArray(configured) ? configured : []), ...(Array.isArray(inUse) ? inUse : [])]) {
    const label = String(item || "").trim();
    if (!label) continue;
    const key = label.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(label);
  }
  if (!out.length) return [...(Array.isArray(configured) ? configured : [])];
  return out.sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));
}

function mergeLabelLists(...lists) {
  const out = [];
  const seen = new Set();
  for (const list of lists) {
    for (const item of Array.isArray(list) ? list : []) {
      const label = String(item == null ? "" : item).trim();
      if (!label) continue;
      const key = label.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(label);
    }
  }
  return out;
}

async function fetchDistinctContactColumn(all, column) {
  if (typeof all !== "function") return [];
  const col = String(column || "").trim();
  if (!["status", "outcome", "lead_source"].includes(col)) return [];
  try {
    const rows = await all(
      `SELECT DISTINCT trim(${col}) AS value
       FROM contacts
       WHERE trim(COALESCE(${col}, '')) != ''
       ORDER BY lower(trim(${col})) ASC`
    );
    return (Array.isArray(rows) ? rows : [])
      .map((row) => String(row?.value || "").trim())
      .filter(Boolean);
  } catch {
    return [];
  }
}

async function contactWorkspaceSettingsNeedRecovery(get) {
  const keys = [
    QUICK_FILTER_SETTING_KEY,
    STATUS_SETTING_KEY,
    OUTCOME_SETTING_KEY,
    LEAD_SOURCE_SETTING_KEY,
    SORT_BY_SETTING_KEY
  ];
  for (const key of keys) {
    const raw = String((await readSetting(get, key)) || "").trim();
    if (!raw) return true;
    const parsed = parseJsonArray(raw);
    if (Array.isArray(parsed) && parsed.length === 0) return true;
  }
  return false;
}

async function restoreContactWorkspaceLabelsFromData(deps, opts = {}) {
  const { run, get, all } = deps;
  const omitIndian = Boolean(opts.omitIndian);
  const defaults = getDefaultContactWorkspaceOptions();
  const [statusInUse, outcomeInUse, leadInUse] = await Promise.all([
    fetchDistinctContactColumn(all, "status"),
    fetchDistinctContactColumn(all, "outcome"),
    fetchDistinctContactLeadSources(all)
  ]);
  return saveContactWorkspaceOptions(
    run,
    {
      quickFilterFields: defaults.quickFilterFields,
      statusLabels: mergeLabelLists(defaults.statusLabels, statusInUse),
      outcomeLabels: mergeLabelLists(defaults.outcomeLabels, outcomeInUse),
      leadSourceLabels: mergeLabelLists(defaults.leadSourceLabels, leadInUse),
      sortByOptions: defaults.sortByOptions
    },
    { omitIndian }
  );
}

async function loadContactWorkspaceOptions(get, opts = {}) {
  const omitIndian = Boolean(opts.omitIndian);
  const [quickRaw, statusRaw, outcomeRaw, leadSourceRaw, sortByRaw] = await Promise.all([
    readSetting(get, QUICK_FILTER_SETTING_KEY),
    readSetting(get, STATUS_SETTING_KEY),
    readSetting(get, OUTCOME_SETTING_KEY),
    readSetting(get, LEAD_SOURCE_SETTING_KEY),
    readSetting(get, SORT_BY_SETTING_KEY)
  ]);
  const defaultQuick = defaultQuickFilterFields();
  const defaultSortBy = defaultSortByOptions();
  let quickFilterFields = normalizeQuickFilterFields(parseJsonArray(quickRaw), defaultQuick);
  if (omitIndian) quickFilterFields = omitIndianQuickFilterFields(quickFilterFields);
  const quickFilterHadInsuranceType = quickFilterFields.some((row) => String(row?.value || "") === "insurance_type");
  quickFilterFields = withInsuranceTypeQuickFilter(quickFilterFields);
  let sortByOptions = normalizeSortByOptions(parseJsonArray(sortByRaw), defaultSortBy, { omitIndian });
  if (omitIndian) sortByOptions = omitIndianSortByOptions(sortByOptions);
  const sortHadInsuranceType = sortByOptions.some((row) => String(row?.value || "") === "insurance_type");
  sortByOptions = omitInsuranceTypeSortOption(sortByOptions);
  if (sortHadInsuranceType && typeof opts.run === "function") {
    await writeSetting(opts.run, SORT_BY_SETTING_KEY, JSON.stringify(sortByOptions));
  }
  if (!quickFilterHadInsuranceType && typeof opts.run === "function") {
    await writeSetting(opts.run, QUICK_FILTER_SETTING_KEY, JSON.stringify(quickFilterFields));
  }
  let statusLabels = normalizeLabelList(parseJsonArray(statusRaw), DEFAULT_STATUS_LABELS);
  let outcomeLabels = normalizeLabelList(parseJsonArray(outcomeRaw), DEFAULT_OUTCOME_LABELS);
  let leadSourceLabels = normalizeLabelList(parseJsonArray(leadSourceRaw), DEFAULT_LEAD_SOURCE_LABELS);
  if (opts.includeLeadSourcesInUse) {
    const inUse = await fetchDistinctContactLeadSources(opts.all);
    leadSourceLabels = mergeLeadSourceLabels(leadSourceLabels, inUse);
  }
  if (opts.includeOutcomesInUse) {
    const inUse = await fetchDistinctContactColumn(opts.all, "outcome");
    outcomeLabels = mergeLabelLists(outcomeLabels, inUse);
  }
  if (opts.includeStatusInUse) {
    const inUse = await fetchDistinctContactColumn(opts.all, "status");
    statusLabels = mergeLabelLists(statusLabels, inUse);
  }
  return {
    quickFilterFields,
    statusLabels,
    outcomeLabels,
    leadSourceLabels,
    sortByOptions
  };
}

async function saveContactWorkspaceOptions(run, body, opts = {}) {
  const omitIndian = Boolean(opts.omitIndian);
  const defaultQuick = defaultQuickFilterFields();
  const defaultSortBy = defaultSortByOptions();
  let quickFilterFields = withInsuranceTypeQuickFilter(
    omitIndian
      ? omitIndianQuickFilterFields(normalizeQuickFilterFields(body && body.quickFilterFields, defaultQuick))
      : normalizeQuickFilterFields(body && body.quickFilterFields, defaultQuick)
  );
  let sortByOptions = omitInsuranceTypeSortOption(
    omitIndian ? omitIndianSortByOptions(normalizeSortByOptions(body && body.sortByOptions, defaultSortBy, { omitIndian })) : normalizeSortByOptions(body && body.sortByOptions, defaultSortBy, { omitIndian })
  );
  const statusLabels = normalizeLabelList(body && body.statusLabels, DEFAULT_STATUS_LABELS);
  const outcomeLabels = normalizeLabelList(body && body.outcomeLabels, DEFAULT_OUTCOME_LABELS);
  const leadSourceLabels = normalizeLabelList(body && body.leadSourceLabels, DEFAULT_LEAD_SOURCE_LABELS);
  await writeSetting(run, QUICK_FILTER_SETTING_KEY, JSON.stringify(quickFilterFields));
  await writeSetting(run, STATUS_SETTING_KEY, JSON.stringify(statusLabels));
  await writeSetting(run, OUTCOME_SETTING_KEY, JSON.stringify(outcomeLabels));
  await writeSetting(run, LEAD_SOURCE_SETTING_KEY, JSON.stringify(leadSourceLabels));
  await writeSetting(run, SORT_BY_SETTING_KEY, JSON.stringify(sortByOptions));
  return { quickFilterFields, statusLabels, outcomeLabels, leadSourceLabels, sortByOptions };
}

function registerContactWorkspaceOptionsRoutes(app, {
  run,
  get,
  all,
  isTrialWorkspaceSession,
  isOwnerWorkspaceSession
}) {
  const isTrial = typeof isTrialWorkspaceSession === "function" ? isTrialWorkspaceSession : () => false;

  function requireOwnerWorkspace(req, res) {
    if (typeof isOwnerWorkspaceSession === "function" && isOwnerWorkspaceSession(req)) return true;
    res.status(403).json({ error: "Only the main workspace operator can change Contact Workspace labels." });
    return false;
  }

  app.get("/api/contacts/lead-sources-in-use", async (req, res) => {
    try {
      const leadSources = await fetchDistinctContactLeadSources(all);
      res.json({ leadSources });
    } catch (error) {
      res.status(500).json({ error: error.message || "Failed to load lead sources in use." });
    }
  });

  app.get("/api/settings/contact-workspace-options", async (req, res) => {
    try {
      if (!requireOwnerWorkspace(req, res)) return;
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const trial = isTrial(req);
      const options = await loadContactWorkspaceOptions(get, { omitIndian: trial, run });
      res.json(options);
    } catch (error) {
      res.status(500).json({ error: error.message || "Failed to load contact workspace labels." });
    }
  });

  app.get("/api/contacts/workspace-options", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const trial = isTrial(req);
      const options = await loadContactWorkspaceOptions(get, {
        omitIndian: trial,
        all,
        run,
        includeLeadSourcesInUse: true,
        includeOutcomesInUse: true,
        includeStatusInUse: true
      });
      res.json({
        ...options,
        workspaceUi: {
          type: trial ? "trial" : "owner",
          omitIndian: trial,
          indianFieldLabel: trial ? null : "Indian"
        }
      });
    } catch (error) {
      res.status(500).json({ error: error.message || "Failed to load contact workspace options" });
    }
  });

  /** How many contacts use each status/outcome/lead-source value — shown as
   *  counts on the label chips and in the delete confirmation. Keys lowercased. */
  app.get("/api/settings/contact-workspace-options/usage", async (req, res) => {
    try {
      if (!requireOwnerWorkspace(req, res)) return;
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const [statusRows, outcomeRows, leadRows] = await Promise.all([
        all(`SELECT lower(trim(COALESCE(status,''))) AS k, COUNT(*) AS n FROM contacts WHERE trim(COALESCE(status,'')) != '' GROUP BY k`),
        all(`SELECT lower(trim(COALESCE(outcome,''))) AS k, COUNT(*) AS n FROM contacts WHERE trim(COALESCE(outcome,'')) != '' GROUP BY k`),
        all(`SELECT lower(trim(COALESCE(lead_source,''))) AS k, COUNT(*) AS n FROM contacts WHERE trim(COALESCE(lead_source,'')) != '' GROUP BY k`)
      ]);
      const toMap = (rows) => {
        const out = {};
        for (const row of Array.isArray(rows) ? rows : []) out[String(row.k)] = Number(row.n) || 0;
        return out;
      };
      res.json({ status: toMap(statusRows), outcome: toMap(outcomeRows), leadSource: toMap(leadRows) });
    } catch (error) {
      res.status(500).json({ error: error.message || "Failed to load label usage counts." });
    }
  });

  app.post("/api/settings/contact-workspace-options/restore", async (req, res) => {
    try {
      if (!requireOwnerWorkspace(req, res)) return;
      const trial = isTrial(req);
      const restored = await restoreContactWorkspaceLabelsFromData({ run, get, all }, { omitIndian: trial });
      res.json({
        ...restored,
        restored: true
      });
    } catch (error) {
      res.status(500).json({ error: error.message || "Failed to restore contact workspace labels" });
    }
  });

  async function handleSaveContactWorkspaceOptions(req, res) {
    try {
      if (!requireOwnerWorkspace(req, res)) return;
      const saved = await saveContactWorkspaceOptions(run, req.body || {}, { omitIndian: isTrial(req) });
      res.json(saved);
    } catch (error) {
      res.status(400).json({ error: error.message || "Failed to save contact workspace options" });
    }
  }

  app.put("/api/settings/contact-workspace-options", handleSaveContactWorkspaceOptions);
  app.post("/api/settings/contact-workspace-options", handleSaveContactWorkspaceOptions);
}

module.exports = {
  registerContactWorkspaceOptionsRoutes,
  loadContactWorkspaceOptions,
  restoreContactWorkspaceLabelsFromData,
  contactWorkspaceSettingsNeedRecovery,
  getDefaultContactWorkspaceOptions,
  omitIndianQuickFilterFields,
  QUICK_FILTER_FIELDS_BASE,
  QUICK_FILTER_FIELD_CATALOG_BASE,
  QUICK_FILTER_FIELD_INDIAN_OWNER,
  defaultQuickFilterFields,
  quickFilterFieldCatalog,
  ALLOWED_QUICK_FILTER_VALUES,
  DEFAULT_STATUS_LABELS,
  DEFAULT_OUTCOME_LABELS,
  DEFAULT_LEAD_SOURCE_LABELS,
  SORT_BY_ORDER_MAP,
  SORT_BY_OPTIONS_BASE,
  SORT_BY_FIELD_CATALOG_BASE,
  SORT_BY_OPTION_INDIAN_OWNER,
  defaultSortByOptions,
  sortByFieldCatalog,
  ALLOWED_SORT_BY_VALUES
};
