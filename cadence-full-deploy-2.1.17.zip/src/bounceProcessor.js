"use strict";

// Automatic bounce processing.
//
// Polls the sending mailbox over POP3 (built-in TLS, no extra dependency),
// parses Non-Delivery Reports (NDRs), and marks the failed recipients
// "Do Not Email" so future campaigns/drips skip them. Hard bounces (5.x.x)
// suppress; soft bounces (4.x.x) are logged only. Everything is guarded — any
// failure logs and is skipped; it never throws into the app.
//
// Owner-scoped: the scheduler runs with no tenant context, so run/all/get hit
// the legacy (owner) DB. Configure via env:
//   BOUNCE_POP3_HOST, BOUNCE_POP3_PORT (default 995), BOUNCE_POP3_USER,
//   BOUNCE_POP3_PASS, BOUNCE_POP3_TLS (default "1"), BOUNCE_POP3_INSECURE,
//   BOUNCE_POLL_MINUTES (default 20), BOUNCE_MAX_PER_RUN (default 60)

const tls = require("tls");
const net = require("net");

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function bounceConfig() {
  const host = String(process.env.BOUNCE_POP3_HOST || "").trim();
  const user = String(process.env.BOUNCE_POP3_USER || "").trim();
  const pass = String(process.env.BOUNCE_POP3_PASS || "");
  const secure = String(process.env.BOUNCE_POP3_TLS ?? "1").trim() !== "0";
  const port = Number(process.env.BOUNCE_POP3_PORT || (secure ? 995 : 110)) || (secure ? 995 : 110);
  const insecure = String(process.env.BOUNCE_POP3_INSECURE || "").trim() === "1";
  const maxPerRun = Math.max(1, Number(process.env.BOUNCE_MAX_PER_RUN || 60) || 60);
  return { host, user, pass, secure, port, insecure, maxPerRun, configured: Boolean(host && user && pass) };
}

// ---- Pure parsers (unit-tested) ----

function unstuffDotStuffing(body) {
  // POP3 doubles any line-leading '.'; undo it.
  return String(body || "").replace(/^\.\./gm, ".");
}

function parsePop3Uidl(text) {
  // Multiline UIDL body: lines of "<msgNum> <uniqueId>".
  const out = [];
  for (const line of String(text || "").split(/\r?\n/)) {
    const m = line.match(/^\s*(\d+)\s+(\S+)\s*$/);
    if (m) out.push({ num: Number(m[1]), uid: m[2] });
  }
  return out;
}

// Returns { isBounce, recipients: [{ email, code, hard }] } where code is the
// enhanced status (e.g. "5.4.1") or the 3-digit SMTP code, and hard = 5.x.
function parseBounceMessage(raw) {
  const text = String(raw || "");
  const recipients = [];
  const seen = new Set();
  const add = (email, code) => {
    const e = String(email || "").trim().toLowerCase().replace(/^[<"]+|[>"]+$/g, "");
    if (!e || !EMAIL_RE.test(e) || seen.has(e)) return;
    const c = String(code || "").trim();
    const hard = /^5\b/.test(c) || /^5\./.test(c);
    seen.add(e);
    recipients.push({ email: e, code: c, hard });
  };

  // 1) DSN block: Final-Recipient ... Status: 5.x.x (anchored, IP-safe).
  const dsnRe =
    /Final-Recipient:\s*(?:rfc822;)?\s*<?([^\s;<>]+@[^\s;<>]+)>?[\s\S]{0,400}?Status:\s*([245]\.\d{1,3}\.\d{1,3})/gi;
  let m;
  while ((m = dsnRe.exec(text))) add(m[1], m[2]);

  // 2) Diagnostic-Code: smtp; 550 ... (anchored).
  const diagRe =
    /Final-Recipient:\s*(?:rfc822;)?\s*<?([^\s;<>]+@[^\s;<>]+)>?[\s\S]{0,400}?Diagnostic-Code:[^\n]*?\b([245]\d{2})\b/gi;
  while ((m = diagRe.exec(text))) add(m[1], m[2]);

  // 3) Human-readable Postfix style: <addr>: host ... said: 550 5.4.1 ...
  //    Anchor the code on "said:" so recipient-host IPs aren't mistaken for codes.
  const humanRe =
    /<([^>\s@]+@[^>\s]+)>:[\s\S]{0,400}?said:\s*([245]\d{2})(?:[ \t]+([245]\.\d{1,3}\.\d{1,3}))?/gi;
  while ((m = humanRe.exec(text))) add(m[1], m[3] || m[2]);

  const looksLikeNdr =
    recipients.length > 0 ||
    /mailer-daemon|postmaster@|mail delivery (?:system|subsystem)|delivery status notification|undelivered mail|returned to sender|delivery has failed|failure notice/i.test(
      text
    );

  return { isBounce: looksLikeNdr, recipients };
}

// ---- Schema ----

async function ensureBounceSchema(run) {
  await run(
    `CREATE TABLE IF NOT EXISTS email_bounces (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL,
      code TEXT,
      hard INTEGER NOT NULL DEFAULT 1,
      suppressed INTEGER NOT NULL DEFAULT 0,
      source_uid TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`
  );
  await run(`CREATE INDEX IF NOT EXISTS idx_email_bounces_email ON email_bounces(email)`);
  await run(
    `CREATE TABLE IF NOT EXISTS bounce_processed_uids (
      uid TEXT PRIMARY KEY,
      processed_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`
  );
}

// ---- POP3 over TLS (minimal, promise-based) ----

function makePop3(socket) {
  let buffer = "";
  let pending = null;
  socket.setEncoding("utf8");
  const failPending = (err) => {
    if (pending) {
      const p = pending;
      pending = null;
      p.reject(err);
    }
  };
  socket.on("error", failPending);
  socket.on("end", () => failPending(new Error("POP3 connection ended")));
  socket.on("data", (chunk) => {
    buffer += chunk;
    if (!pending) return;
    if (pending.multiline) {
      if (/^-ERR/i.test(buffer)) {
        const nl = buffer.indexOf("\r\n");
        if (nl === -1) return;
        const line = buffer.slice(0, nl);
        buffer = "";
        const p = pending;
        pending = null;
        p.reject(new Error(line));
        return;
      }
      if (/^\+OK/i.test(buffer)) {
        const term = buffer.indexOf("\r\n.\r\n");
        if (term === -1) return;
        const full = buffer.slice(0, term);
        buffer = buffer.slice(term + 5);
        const firstNl = full.indexOf("\r\n");
        const body = firstNl === -1 ? "" : full.slice(firstNl + 2);
        const p = pending;
        pending = null;
        p.resolve(body);
      }
      return;
    }
    const nl = buffer.indexOf("\r\n");
    if (nl === -1) return;
    const line = buffer.slice(0, nl);
    buffer = buffer.slice(nl + 2);
    const p = pending;
    pending = null;
    if (/^\+OK/i.test(line)) p.resolve(line);
    else p.reject(new Error(line || "POP3 error"));
  });

  function expect(multiline) {
    return new Promise((resolve, reject) => {
      pending = { resolve, reject, multiline: Boolean(multiline) };
    });
  }
  function send(cmd, multiline) {
    const p = expect(multiline);
    socket.write(cmd + "\r\n");
    return p;
  }
  return { expect, send };
}

function connectPop3(cfg, timeoutMs) {
  return new Promise((resolve, reject) => {
    const opts = { host: cfg.host, port: cfg.port };
    let socket;
    const onErr = (e) => reject(e);
    if (cfg.secure) {
      socket = tls.connect(
        { ...opts, servername: cfg.host, rejectUnauthorized: !cfg.insecure },
        () => resolve(socket)
      );
    } else {
      socket = net.connect(opts, () => resolve(socket));
    }
    socket.once("error", onErr);
    socket.setTimeout(timeoutMs, () => {
      socket.destroy();
      reject(new Error("POP3 connect timeout"));
    });
  });
}

async function fetchBounceCandidates(cfg, isProcessed, timeoutMs = 30000) {
  const socket = await connectPop3(cfg, timeoutMs);
  const client = makePop3(socket);
  const fetched = [];
  const overall = setTimeout(() => socket.destroy(), timeoutMs * 4);
  try {
    await client.expect(false); // greeting
    await client.send(`USER ${cfg.user}`, false);
    await client.send(`PASS ${cfg.pass}`, false);

    let list;
    try {
      list = parsePop3Uidl(await client.send("UIDL", true));
    } catch (e) {
      // UIDL unsupported — fall back to LIST (num only; uid = "n<num>").
      const listText = await client.send("LIST", true);
      list = parsePop3Uidl(listText).map((r) => ({ num: r.num, uid: "n" + r.num }));
    }

    // Newest first, then cap.
    list.sort((a, b) => b.num - a.num);
    let count = 0;
    for (const { num, uid } of list) {
      if (count >= cfg.maxPerRun) break;
      if (isProcessed(uid)) continue;
      count += 1;
      try {
        const raw = unstuffDotStuffing(await client.send(`RETR ${num}`, true));
        fetched.push({ uid, raw });
      } catch (e) {
        // skip unreadable message
      }
    }
    try {
      await client.send("QUIT", false);
    } catch (e) {
      /* ignore */
    }
  } finally {
    clearTimeout(overall);
    try {
      socket.end();
      socket.destroy();
    } catch (e) {
      /* ignore */
    }
  }
  return fetched;
}

// ---- Orchestration ----

let lastUnconfiguredLog = 0;
let lastRun = null;

function getLastRun() {
  return lastRun;
}

async function processBounces({ run, all, get }) {
  const done = (result) => {
    lastRun = { at: new Date().toISOString(), ...result };
    return result;
  };
  const cfg = bounceConfig();
  if (!cfg.configured) {
    const now = Date.now();
    if (now - lastUnconfiguredLog > 6 * 60 * 60 * 1000) {
      lastUnconfiguredLog = now;
      console.log("[bounce] POP3 not configured (set BOUNCE_POP3_HOST/USER/PASS) — bounce polling idle.");
    }
    return done({ configured: false, fetched: 0, bounces: 0, suppressed: 0 });
  }

  await ensureBounceSchema(run);

  const processedRows = await all(`SELECT uid FROM bounce_processed_uids`);
  const processed = new Set((processedRows || []).map((r) => String(r.uid)));
  const isProcessed = (uid) => processed.has(String(uid));

  let messages;
  try {
    messages = await fetchBounceCandidates(cfg, isProcessed);
  } catch (e) {
    console.error("[bounce] mailbox fetch failed:", e.message);
    return done({ configured: true, fetched: 0, bounces: 0, suppressed: 0, error: e.message });
  }

  let bounces = 0;
  let suppressed = 0;
  for (const msg of messages) {
    try {
      const parsed = parseBounceMessage(msg.raw);
      if (parsed.isBounce && parsed.recipients.length) {
        bounces += 1;
        for (const rcpt of parsed.recipients) {
          await run(
            `INSERT INTO email_bounces (email, code, hard, suppressed, source_uid) VALUES (?, ?, ?, ?, ?)`,
            [rcpt.email, rcpt.code || "", rcpt.hard ? 1 : 0, rcpt.hard ? 1 : 0, String(msg.uid)]
          );
          if (rcpt.hard) {
            const res = await run(
              `UPDATE contacts SET do_not_email = '1', updated_at = CURRENT_TIMESTAMP
               WHERE lower(trim(email)) = ? AND COALESCE(do_not_email, '') <> '1'`,
              [rcpt.email]
            );
            if (res && res.changes) suppressed += res.changes;
          }
        }
      }
    } catch (e) {
      console.error("[bounce] parse/suppress error:", e.message);
    } finally {
      try {
        await run(`INSERT OR IGNORE INTO bounce_processed_uids (uid) VALUES (?)`, [String(msg.uid)]);
      } catch (e) {
        /* ignore */
      }
    }
  }

  if (bounces || suppressed) {
    console.log(`[bounce] processed ${messages.length} msg(s): ${bounces} bounce(s), ${suppressed} contact(s) suppressed.`);
  }
  return done({ configured: true, fetched: messages.length, bounces, suppressed });
}

function startBounceScheduler(deps) {
  const minutes = Math.max(2, Number(process.env.BOUNCE_POLL_MINUTES || 20) || 20);
  const intervalMs = minutes * 60 * 1000;
  const tick = () => {
    processBounces(deps).catch((e) => console.error("[bounce] scheduler tick failed:", e.message));
  };
  setTimeout(tick, 45 * 1000); // first run shortly after boot
  const timer = setInterval(tick, intervalMs);
  if (timer.unref) timer.unref();
  return timer;
}

module.exports = {
  startBounceScheduler,
  processBounces,
  getLastRun,
  ensureBounceSchema,
  parseBounceMessage,
  parsePop3Uidl,
  unstuffDotStuffing,
  bounceConfig
};
