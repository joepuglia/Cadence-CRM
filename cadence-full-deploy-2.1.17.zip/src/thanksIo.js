const THANKS_IO_APP_URL = "https://thanks.io";
const THANKS_IO_API_BASE = "https://api.thanks.io/api/v2";

function maskThanksIoToken(token) {
  const s = String(token || "").trim();
  if (!s) return "";
  if (s.length <= 8) return "••••";
  return `${s.slice(0, 4)}…${s.slice(-4)}`;
}

async function verifyThanksIoApiKey(token) {
  const key = String(token || "").trim();
  if (!key) return { ok: false, error: "API key is missing." };
  let res;
  try {
    res = await fetch(`${THANKS_IO_API_BASE}/mailing-lists?page=1`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${key}`,
        Accept: "application/json"
      }
    });
  } catch (err) {
    return { ok: false, error: err.message || "Could not reach Thanks.io." };
  }
  if (res.ok || res.status === 404) return { ok: true };
  if (res.status === 401 || res.status === 403) {
    return {
      ok: false,
      error: "Thanks.io rejected this API key. Create a Personal Access Token in thanks.io → API Settings."
    };
  }
  let detail = "";
  try {
    const body = await res.json();
    detail = String(body.error || body.message || "").trim();
  } catch {
    /* ignore */
  }
  return { ok: false, error: detail || `Thanks.io HTTP ${res.status}` };
}

module.exports = {
  THANKS_IO_APP_URL,
  maskThanksIoToken,
  verifyThanksIoApiKey
};
