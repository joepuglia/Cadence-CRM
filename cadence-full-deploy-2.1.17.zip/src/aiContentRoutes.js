"use strict";

// AI Content: generate an SEO blog-post draft (+ topic ideas) via the shared
// Claude client, score it client-side, and (owner-only) publish it to the public
// Cadence marketing blog. Two audiences: insurance consumers, or agents (B2B,
// for Cadence's own blog).

const { callClaudeJson, getClaudeConfig } = require("./claudeClient");
const marketingBlog = require("./marketingBlog");

// "consumer" = an agent writing for insurance shoppers on their own site.
// "agents" = B2B content for Cadence's own blog, to rank on Google and attract
// insurance agents to the CRM.
const TOPICS_SYSTEM_CONSUMER =
  "You are an SEO content strategist for independent U.S. health insurance agents. " +
  "You know what their prospects (individuals, families, the self-employed, Medicare-eligible, ACA/marketplace shoppers, small-business owners) actually search for online. " +
  "Suggest practical, search-driven blog topics an agent could publish to attract and educate leads. " +
  "Stay accurate and compliant: no misleading claims and no specific premium/price guarantees.";

const TOPICS_SYSTEM_AGENTS =
  "You are an SEO strategist for Cadence CRM, a CRM built for independent health insurance agents. " +
  "Suggest blog topics that insurance AGENTS search for on Google — running and growing an insurance business, lead follow-up, CRM workflows, ACA/Medicare season prep, sales automation, and AI for agents — " +
  "topics Cadence's marketing blog could realistically rank for and that naturally lead a reader toward trying a CRM.";

const ARTICLE_SYSTEM_CONSUMER =
  "You are an expert SEO blog writer for the U.S. health insurance industry, writing for an independent agent's website to attract and educate prospects. " +
  "Write accurate, genuinely helpful, compliant content: no guarantees of coverage or price, no misleading claims, and encourage readers to speak with a licensed agent for their situation. " +
  "Use clear structure with H2/H3 subheadings, short paragraphs, and bullet lists where useful. Work the focus keyword in naturally — never keyword-stuff.";

const ARTICLE_SYSTEM_AGENTS =
  "You are an expert B2B content writer for Cadence CRM, a CRM built for independent health insurance agents. " +
  "You write blog posts for Cadence's marketing site to attract insurance agents via Google search. " +
  "Write accurate, genuinely useful articles about running and growing an insurance business: lead follow-up, CRM workflows, ACA and Medicare season prep, automation, AI for agents, and productivity. " +
  "Naturally position Cadence CRM as the solution where it genuinely fits (helpful, not pushy), and end with a call to action to start a free Cadence CRM trial. " +
  "Use clear H2/H3 structure, short paragraphs, and bullet lists. Work the focus keyword in naturally — never keyword-stuff.";

function isAgentsAudience(audience) {
  return String(audience || "").toLowerCase() === "agents";
}

function targetWords(length) {
  const l = String(length || "").toLowerCase();
  if (l === "short") return 550;
  if (l === "long") return 1100;
  return 800;
}

function registerAiContentRoutes(app, { createRateLimiter, isOwnerWorkspaceSession } = {}) {
  const limiter =
    typeof createRateLimiter === "function"
      ? createRateLimiter({ windowMs: 60_000, max: 12, label: "ai-content" })
      : (req, res, next) => next();

  // Publishing to the public Cadence blog is owner-only (never trust the client).
  function ensureOwner(req, res) {
    if (typeof isOwnerWorkspaceSession === "function" && isOwnerWorkspaceSession(req)) return true;
    res.status(403).json({ error: "Only the site owner can publish to the Cadence blog." });
    return false;
  }

  function audienceForRequest(req, body) {
    if (isAgentsAudience(body?.audience) && typeof isOwnerWorkspaceSession === "function" && isOwnerWorkspaceSession(req)) {
      return "agents";
    }
    return "consumer";
  }

  app.get("/api/ai-content/status", (req, res) => {
    const { configured, model } = getClaudeConfig();
    res.json({ configured, model });
  });

  app.post("/api/ai-content/topics", limiter, async (req, res) => {
    try {
      const seed = String(req.body?.seed || "").trim().slice(0, 200);
      const agents = audienceForRequest(req, req.body) === "agents";
      const system = agents ? TOPICS_SYSTEM_AGENTS : TOPICS_SYSTEM_CONSUMER;
      const user =
        (seed ? `Focus area: "${seed}". ` : "") +
        'Suggest 6 blog post ideas. Return JSON: {"topics":[{"title":"headline","keyword":"primary search phrase","why":"one line on why it attracts traffic"}]}';
      const result = await callClaudeJson({ system, user, maxTokens: 900 });
      const topics = Array.isArray(result?.topics)
        ? result.topics
            .map((t) => ({
              title: String(t?.title || "").trim(),
              keyword: String(t?.keyword || "").trim(),
              why: String(t?.why || "").trim()
            }))
            .filter((t) => t.title)
            .slice(0, 8)
        : [];
      res.json({ topics });
    } catch (error) {
      res.status(error?.statusCode || 500).json({ error: error?.message || "Could not suggest topics." });
    }
  });

  app.post("/api/ai-content/generate", limiter, async (req, res) => {
    try {
      const topic = String(req.body?.topic || "").trim();
      if (!topic) return res.status(400).json({ error: "Enter a topic to write about." });
      const tone = String(req.body?.tone || "professional").trim().slice(0, 40);
      const words = targetWords(req.body?.length);
      const focus = String(req.body?.keyword || "").trim().slice(0, 80);
      const agents = audienceForRequest(req, req.body) === "agents";
      const system = agents ? ARTICLE_SYSTEM_AGENTS : ARTICLE_SYSTEM_CONSUMER;
      const intro = agents
        ? "Write a blog post for Cadence CRM's marketing blog. Audience: independent health insurance agents searching Google."
        : "Write a blog post for a health insurance agent's website. Audience: insurance shoppers/consumers.";
      const cta = agents
        ? "end with a call to action to start a free Cadence CRM trial"
        : "end with a call to action to contact a licensed agent";
      const user =
        intro + "\n" +
        `Topic: "${topic.slice(0, 300)}"\n` +
        (focus ? `Focus keyword: "${focus}"\n` : "") +
        `Tone: ${tone}. Length: about ${words} words.\n\n` +
        "Return JSON with EXACTLY these fields:\n" +
        '{"title": "SEO title, 50-60 characters, naturally includes the focus keyword",\n' +
        ' "metaDescription": "compelling summary, 150-160 characters, includes the focus keyword",\n' +
        ' "focusKeyword": "the primary keyword",\n' +
        ' "keywords": ["3-6 related keywords"],\n' +
        ' "slug": "url-friendly-slug",\n' +
        ' "bodyHtml": "the article as clean semantic HTML using <h2>, <h3>, <p>, <ul>/<li>, <strong>. Do NOT include an <h1> (the title is separate). Open with a short intro that uses the focus keyword in the first sentence, and ' +
        cta +
        '."}';
      const result = await callClaudeJson({ system, user, maxTokens: 4000, timeoutMs: 90_000 });
      const out = {
        title: String(result?.title || "").trim(),
        metaDescription: String(result?.metaDescription || "").trim(),
        focusKeyword: String(result?.focusKeyword || focus || "").trim(),
        keywords: Array.isArray(result?.keywords)
          ? result.keywords.map((k) => String(k || "").trim()).filter(Boolean).slice(0, 8)
          : [],
        slug: String(result?.slug || "").trim(),
        bodyHtml: String(result?.bodyHtml || "").trim()
      };
      if (!out.bodyHtml) return res.status(502).json({ error: "AI returned an empty article. Try again." });
      res.json(out);
    } catch (error) {
      res.status(error?.statusCode || 500).json({ error: error?.message || "Could not generate the article." });
    }
  });

  // ---- Owner-only: publish drafts to the public Cadence blog ----

  app.get("/api/ai-content/posts", async (req, res) => {
    if (!ensureOwner(req, res)) return;
    try {
      const posts = await marketingBlog.listPosts({});
      res.json({ posts });
    } catch (error) {
      res.status(500).json({ error: error?.message || "Could not load posts." });
    }
  });

  app.post("/api/ai-content/publish", async (req, res) => {
    if (!ensureOwner(req, res)) return;
    try {
      const b = req.body || {};
      if (!String(b.title || "").trim() || !String(b.bodyHtml || "").trim()) {
        return res.status(400).json({ error: "A title and body are required to publish." });
      }
      const post = await marketingBlog.savePost({
        id: b.id,
        slug: b.slug,
        title: b.title,
        metaDescription: b.metaDescription,
        focusKeyword: b.focusKeyword,
        keywords: b.keywords,
        eyebrow: String(b.eyebrow || b.focusKeyword || "").trim(),
        bodyHtml: b.bodyHtml,
        status: "published"
      });
      res.json({ post, url: `/blog/${post.slug}` });
    } catch (error) {
      res.status(500).json({ error: error?.message || "Could not publish the post." });
    }
  });

  app.post("/api/ai-content/unpublish", async (req, res) => {
    if (!ensureOwner(req, res)) return;
    try {
      const post = await marketingBlog.setStatus(Number(req.body?.id), "draft");
      res.json({ post });
    } catch (error) {
      res.status(500).json({ error: error?.message || "Could not unpublish the post." });
    }
  });

  app.post("/api/ai-content/delete-post", async (req, res) => {
    if (!ensureOwner(req, res)) return;
    try {
      await marketingBlog.deletePost(Number(req.body?.id));
      res.json({ ok: true });
    } catch (error) {
      res.status(500).json({ error: error?.message || "Could not delete the post." });
    }
  });
}

module.exports = { registerAiContentRoutes };
