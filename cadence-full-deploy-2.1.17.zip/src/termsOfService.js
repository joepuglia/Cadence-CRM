/** Bump when terms content changes materially; stored on signup for audit. */
const TERMS_VERSION = "2026-06-03";
const TERMS_PATH = "/terms.html";

function isTermsAcceptanceValid(body) {
  const raw = body?.acceptTerms;
  return raw === true || raw === "true" || raw === "1" || raw === 1;
}

module.exports = {
  TERMS_VERSION,
  TERMS_PATH,
  isTermsAcceptanceValid
};
