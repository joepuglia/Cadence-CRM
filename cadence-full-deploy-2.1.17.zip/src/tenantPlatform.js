"use strict";

const fs = require("fs");
const path = require("path");
const {
  platformRun,
  platformGet,
  platformAll,
  openTenantDatabase,
  withTenantContext,
  run,
  LEGACY_TENANT_ID
} = require("./db");
const { normalizeSignupPhone } = require("./signupValidation");
const { hashLoginPassword, generateTempPassword } = require("./authPassword");
const { purchaseNumberForTenant, isMasterConfigured } = require("./twilioProvisioning");

const TRIAL_DAYS = 14;
const PRO_MONTHLY_USD = 79;

function slugify(input) {
  const base = String(input || "workspace")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 48);
  return base || "workspace";
}

async function ensureUniqueSlug(base) {
  let slug = slugify(base);
  let n = 0;
  for (;;) {
    const candidate = n ? `${slug}-${n}` : slug;
    const row = await platformGet(`SELECT id FROM tenants WHERE slug = ?`, [candidate]);
    if (!row) return candidate;
    n += 1;
  }
}

async function getTenantById(tenantId) {
  return platformGet(`SELECT * FROM tenants WHERE id = ?`, [tenantId]);
}

async function issueNewTrialPasswordForEmail(email) {
  const normalizedEmail = String(email || "").trim().toLowerCase();
  const existingUser = await getTenantUserByEmail(normalizedEmail);
  if (!existingUser) return null;
  const tempPassword = generateTempPassword();
  const passwordHash = hashLoginPassword(tempPassword);
  const previousHash = String(existingUser.password_hash || "");
  const nowSec = Math.floor(Date.now() / 1000);
  await platformRun(`UPDATE tenant_users SET password_hash = ?, updated_at = ? WHERE id = ?`, [
    passwordHash,
    nowSec,
    existingUser.id
  ]);
  const tenant = await getTenantById(existingUser.tenant_id);
  return { tempPassword, tenantUser: existingUser, tenant, previousHash };
}

async function restoreTrialPasswordHash(userId, passwordHash) {
  const id = Number(userId);
  if (!Number.isInteger(id) || id < 1) return;
  const nowSec = Math.floor(Date.now() / 1000);
  await platformRun(`UPDATE tenant_users SET password_hash = ?, updated_at = ? WHERE id = ?`, [
    String(passwordHash || ""),
    nowSec,
    id
  ]);
}

async function getTenantUserByEmail(email) {
  return platformGet(
    `SELECT tu.*, t.slug AS tenant_slug, t.status AS tenant_status, t.trial_ends_at, t.plan,
            t.stripe_customer_id, t.stripe_subscription_id, t.agency_name
     FROM tenant_users tu
     JOIN tenants t ON t.id = tu.tenant_id
     WHERE tu.email = ?`,
    [String(email || "").trim().toLowerCase()]
  );
}

function computeTrialState(tenant) {
  if (!tenant) return { allowed: false, reason: "missing" };
  const status = String(tenant.tenant_status || tenant.status || "").trim().toLowerCase();
  const trialEndsAt = Number(tenant.trial_ends_at || 0);
  const now = Date.now();
  if (status === "active") {
    return { allowed: true, status, trialEndsAt, daysLeft: null, needsPayment: false };
  }
  if (status === "cancelled") {
    return { allowed: false, status, trialEndsAt, daysLeft: 0, needsPayment: true, reason: "cancelled" };
  }
  if (trialEndsAt > now) {
    const daysLeft = Math.max(1, Math.ceil((trialEndsAt - now) / (24 * 60 * 60 * 1000)));
    return { allowed: true, status: status || "trial", trialEndsAt, daysLeft, needsPayment: false };
  }
  return {
    allowed: false,
    status: status === "trial" ? "expired" : status || "expired",
    trialEndsAt,
    daysLeft: 0,
    needsPayment: true,
    reason: "trial_expired"
  };
}

async function markTenantExpiredIfNeeded(tenantId) {
  const tenant = await getTenantById(tenantId);
  if (!tenant) return null;
  const status = String(tenant.status || "").toLowerCase();
  if (status === "active" || status === "cancelled") return tenant;
  const trialEndsAt = Number(tenant.trial_ends_at || 0);
  if (trialEndsAt > Date.now()) return tenant;
  if (status === "expired") return tenant;
  await platformRun(`UPDATE tenants SET status = 'expired', updated_at = ? WHERE id = ?`, [
    Math.floor(Date.now() / 1000),
    tenantId
  ]);
  return getTenantById(tenantId);
}

async function provisionTrialTenant({
  firstName,
  lastName,
  email,
  phone,
  agencyName,
  licensedState,
  licenseNumber,
  residentState,
  plan
}) {
  const normalizedEmail = String(email || "").trim().toLowerCase();
  const existingUser = await getTenantUserByEmail(normalizedEmail);
  if (existingUser) {
    const tenant = await getTenantById(existingUser.tenant_id);
    return {
      alreadyRegistered: true,
      tenant,
      tenantUser: existingUser,
      tempPassword: null
    };
  }

  const trialEndsAt = Date.now() + TRIAL_DAYS * 24 * 60 * 60 * 1000;
  const slug = await ensureUniqueSlug(agencyName || normalizedEmail.split("@")[0]);
  const tempPassword = generateTempPassword();
  const passwordHash = hashLoginPassword(tempPassword);
  const nowSec = Math.floor(Date.now() / 1000);

  await platformRun(
    `INSERT INTO tenants (
       slug, agency_name, owner_email, owner_first_name, owner_last_name, owner_phone,
       plan, status, trial_ends_at, created_at, updated_at
     ) VALUES (?, ?, ?, ?, ?, ?, ?, 'trial', ?, ?, ?)`,
    [
      slug,
      String(agencyName || "").trim(),
      normalizedEmail,
      String(firstName || "").trim(),
      String(lastName || "").trim(),
      normalizeSignupPhone(phone),
      String(plan || "pro").trim().toLowerCase() || "pro",
      trialEndsAt,
      nowSec,
      nowSec
    ]
  );

  const tenantRow = await platformGet(`SELECT * FROM tenants WHERE slug = ?`, [slug]);
  if (!tenantRow) throw new Error("Failed to create tenant");

  await platformRun(
    `INSERT INTO tenant_users (tenant_id, email, password_hash, role, created_at, updated_at)
     VALUES (?, ?, ?, 'owner', ?, ?)`,
    [tenantRow.id, normalizedEmail, passwordHash, nowSec, nowSec]
  );

  await openTenantDatabase(tenantRow.id);

  const trialPublicUrl =
    String(process.env.TRIAL_WELCOME_LOGIN_URL || "").trim().replace(/\/$/, "") || "https://crmcadence.com";

  // Auto-provision a Twilio phone number if master credentials are configured
  // Hard 12s timeout so a Twilio failure never blocks the signup response.
  let provisionedPhone = null;
  if (isMasterConfigured()) {
    try {
      const crmBase = String(process.env.CRM_PUBLIC_URL || "https://crmcadence.com").trim().replace(/\/$/, "");
      const timeout = new Promise((_, reject) =>
        setTimeout(() => reject(new Error("Provisioning timeout")), 12000)
      );
      provisionedPhone = await Promise.race([
        purchaseNumberForTenant({
          residentState: residentState || licensedState,
          voiceWebhookUrl: `${crmBase}/webhooks/twilio/voice`,
          messagingServiceSid: String(process.env.TWILIO_MESSAGING_SERVICE_SID || "").trim() || undefined
        }),
        timeout
      ]);
      console.log(`[provisioning] Purchased ${provisionedPhone} for tenant ${tenantRow.id} (${normalizedEmail})`);
    } catch (provErr) {
      console.error(`[provisioning] Failed to purchase number for tenant ${tenantRow.id}:`, provErr.message);
      // Non-fatal — tenant can set up Twilio manually
    }
  }

  await withTenantContext(tenantRow.id, async () => {
    await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, [
      "crmPublicUrl",
      trialPublicUrl
    ]);
    await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, ["loginEmail", normalizedEmail]);
    if (provisionedPhone) {
      await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, ["phoneNumber", provisionedPhone]);
      await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, ["residentState", String(residentState || licensedState || "").trim().toUpperCase()]);
    }
    // Seed Twilio Voice browser credentials from master account so agents can use click-to-call immediately
    const masterSid      = String(process.env.TWILIO_ACCOUNT_SID || "").trim();
    const masterToken    = String(process.env.TWILIO_AUTH_TOKEN || "").trim();
    const masterApiKey   = String(process.env.TWILIO_API_KEY || "").trim();
    const masterApiSecret= String(process.env.TWILIO_API_SECRET || "").trim();
    const twimlAppSid    = String(process.env.TWILIO_VOICE_TWIML_APP_SID || "").trim();
    const voiceIdentity  = String(process.env.TWILIO_VOICE_IDENTITY || "crm-agent").trim();
    if (masterSid)       await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('accountSid', ?)`, [masterSid]);
    if (masterToken)     await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('authToken', ?)`, [masterToken]);
    if (masterApiKey)    await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('apiKey', ?)`, [masterApiKey]);
    if (masterApiSecret) await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('apiSecret', ?)`, [masterApiSecret]);
    if (twimlAppSid)     await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('voiceTwimlAppSid', ?)`, [twimlAppSid]);
    if (voiceIdentity)   await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES ('voiceIdentity', ?)`, [voiceIdentity]);
  });

  await platformRun(`UPDATE subscription_signups SET tenant_id = ? WHERE email = ?`, [
    tenantRow.id,
    normalizedEmail
  ]);

  return {
    alreadyRegistered: false,
    tenant: tenantRow,
    tempPassword,
    trialEndsAt,
    provisionedPhone
  };
}

async function activateTenantSubscription(tenantId, { stripeCustomerId, stripeSubscriptionId } = {}) {
  const nowSec = Math.floor(Date.now() / 1000);
  await platformRun(
    `UPDATE tenants SET
       status = 'active',
       stripe_customer_id = COALESCE(?, stripe_customer_id),
       stripe_subscription_id = COALESCE(?, stripe_subscription_id),
       updated_at = ?
     WHERE id = ?`,
    [
      stripeCustomerId || null,
      stripeSubscriptionId || null,
      nowSec,
      tenantId
    ]
  );
  return getTenantById(tenantId);
}

module.exports = {
  TRIAL_DAYS,
  PRO_MONTHLY_USD,
  LEGACY_TENANT_ID,
  slugify,
  getTenantById,
  getTenantUserByEmail,
  issueNewTrialPasswordForEmail,
  computeTrialState,
  markTenantExpiredIfNeeded,
  provisionTrialTenant,
  activateTenantSubscription,
  restoreTrialPasswordHash,
  withTenantContext
};
