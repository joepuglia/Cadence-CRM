const { callClaudeJson } = require("./claudeClient");

const autoScoreInFlight = new Set();

function clean(value) {
  return String(value == null ? "" : value).trim();
}

function clampScore(value) {
  const n = Math.round(Number(value));
  if (!Number.isFinite(n)) return 1;
  return Math.max(1, Math.min(10, n));
}

function normalizedLabel(value) {
  return clean(value)
    .toLowerCase()
    .replace(/[\s_-]+/g, "");
}

function isDeclinedContact(contact) {
  return [contact?.status, contact?.outcome].some((value) => normalizedLabel(value).includes("declined"));
}

function isSoldContact(contact) {
  const tagValues = clean(contact?.tags)
    .split(",")
    .map((tag) => tag.trim())
    .filter(Boolean);
  const values = [contact?.status, contact?.outcome, ...tagValues]
    .map((value) => normalizedLabel(value))
    .filter(Boolean);
  return values.some((value) => value === "sold" || value === "closedsold");
}

function requireWebhookSecret(req) {
  const expected = clean(process.env.INBOUND_WEBHOOK_SECRET);
  if (!expected) {
    const err = new Error("Inbound webhook secret is not configured.");
    err.statusCode = 503;
    throw err;
  }
  const auth = clean(req.get("authorization"));
  const token = auth.replace(/^Bearer\s+/i, "").trim() || clean(req.query?.secret) || clean(req.body?.secret);
  if (token !== expected) {
    const err = new Error("Invalid webhook secret.");
    err.statusCode = 401;
    throw err;
  }
}

async function loadContactContext(get, all, contactId) {
  const id = Number(contactId);
  if (!Number.isInteger(id) || id <= 0) return null;
  const contact = await get(
    `SELECT id, full_name, email, phone, secondary_phone, status, outcome, tags, notes, special_notes,
            lead_source, quote, household_size, income, communication_type, date_of_contact,
            last_called, last_emailed, last_sms, last_tagged, created_at, updated_at,
            ai_lead_score, ai_lead_reason, ai_lead_scored_at
       FROM contacts
      WHERE id = ?`,
    [id]
  );
  if (!contact) return null;
  const history = await all(
    `SELECT id, activity_type, detail, created_at
       FROM contact_activity
      WHERE contact_id = ?
      ORDER BY datetime(created_at) DESC, id DESC
      LIMIT 12`,
    [id]
  );
  return { contact, history };
}

function contactForAi(contact) {
  return {
    id: contact.id,
    full_name: contact.full_name,
    status: contact.status,
    outcome: contact.outcome,
    tags: contact.tags,
    notes: contact.notes,
    special_notes: contact.special_notes,
    lead_source: contact.lead_source,
    quote: contact.quote,
    household_size: contact.household_size,
    income: contact.income,
    communication_type: contact.communication_type,
    date_of_contact: contact.date_of_contact,
    last_called: contact.last_called,
    last_emailed: contact.last_emailed,
    last_sms: contact.last_sms,
    last_tagged: contact.last_tagged,
    created_at: contact.created_at,
    updated_at: contact.updated_at
  };
}

function historyForAi(history) {
  return (history || []).map((h) => ({
    id: h.id,
    type: h.activity_type,
    detail: clean(h.detail).slice(0, 1500),
    created_at: h.created_at
  }));
}

async function logAiActivity(run, contactId, type, payload) {
  await run(
    `INSERT INTO contact_activity (contact_id, activity_type, detail)
     VALUES (?, ?, ?)`,
    [contactId, type, typeof payload === "string" ? payload : JSON.stringify(payload)]
  );
}

async function scoreContactWithAi(ctx, options = {}) {
  if (isDeclinedContact(ctx?.contact)) {
    return null;
  }
  if (isSoldContact(ctx?.contact)) {
    return {
      score: 10,
      reason: "Marked sold in Cadence, so this contact is automatically scored as a closed high-value lead.",
      nextBestAction: "Confirm enrollment details and move the contact into post-sale retention follow-up."
    };
  }
  const payload = await callClaudeJson({
    system:
      "You score health insurance CRM leads for agents. Return JSON only: {\"score\":1-10,\"reason\":\"short reason\",\"nextBestAction\":\"one recommended action\"}. Do not include bank or payment advice.",
    user: `Score this contact for urgency and likelihood to convert.\n${JSON.stringify(
      { contact: contactForAi(ctx.contact), recentHistory: historyForAi(ctx.history) },
      null,
      2
    )}`,
    maxTokens: 700,
    timeoutMs: options.timeoutMs
  });
  return {
    score: clampScore(payload?.score),
    reason: clean(payload?.reason).slice(0, 500) || "No reason returned.",
    nextBestAction: clean(payload?.nextBestAction).slice(0, 500)
  };
}

async function persistLeadScore(run, contactId, scored) {
  if (!scored) {
    await run(
      `UPDATE contacts
          SET ai_lead_score = '', ai_lead_reason = '', ai_lead_scored_at = ''
        WHERE id = ?`,
      [contactId]
    );
    return;
  }
  await run(
    `UPDATE contacts
        SET ai_lead_score = ?, ai_lead_reason = ?, ai_lead_scored_at = CURRENT_TIMESTAMP
      WHERE id = ?`,
    [String(scored.score), scored.reason, contactId]
  );
}

async function autoScoreContact({ run, get, all }, contactId) {
  const id = Number(contactId);
  if (!Number.isInteger(id) || id <= 0) return null;
  if (!clean(process.env.ANTHROPIC_API_KEY)) return null;
  const ctx = await loadContactContext(get, all, id);
  if (!ctx) return null;
  const scored = await scoreContactWithAi(ctx);
  await persistLeadScore(run, id, scored);
  return scored;
}

async function mapWithConcurrency(items, concurrency, mapper) {
  const out = new Array(items.length);
  let nextIndex = 0;
  const workers = Array.from({ length: Math.max(1, Math.min(concurrency, items.length || 1)) }, async () => {
    while (nextIndex < items.length) {
      const index = nextIndex;
      nextIndex += 1;
      out[index] = await mapper(items[index], index);
    }
  });
  await Promise.all(workers);
  return out;
}

async function scoreBatchContact({ run, get, all }, contactId, options = {}) {
  const ctx = await loadContactContext(get, all, contactId);
  if (!ctx) return null;
  const scored = await scoreContactWithAi(ctx, options);
  await persistLeadScore(run, ctx.contact.id, scored);
  return { id: ctx.contact.id, ...(scored || { score: null, reason: "", nextBestAction: "", cleared: true }) };
}

function scheduleAutoLeadScore(deps, contactId, reason = "contact_update") {
  const id = Number(contactId);
  if (!Number.isInteger(id) || id <= 0) return false;
  if (!clean(process.env.ANTHROPIC_API_KEY)) return false;
  if (autoScoreInFlight.has(id)) return false;
  autoScoreInFlight.add(id);
  setTimeout(() => {
    autoScoreContact(deps, id)
      .catch((error) => {
        console.error(`Auto lead score failed (${reason}) for contact ${id}:`, error.message || error);
      })
      .finally(() => {
        autoScoreInFlight.delete(id);
      });
  }, 0);
  return true;
}

async function normalizeSoldLeadScores(run) {
  await run(
    `UPDATE contacts
        SET ai_lead_score = '', ai_lead_reason = '', ai_lead_scored_at = ''
      WHERE lower(replace(trim(coalesce(status, '')), ' ', '')) LIKE '%declined%'
         OR lower(replace(trim(coalesce(outcome, '')), ' ', '')) LIKE '%declined%'`
  );
  await run(
    `UPDATE contacts
        SET ai_lead_score = '10',
            ai_lead_reason = 'Marked sold in Cadence, so this contact is automatically scored as a closed high-value lead.',
            ai_lead_scored_at = CURRENT_TIMESTAMP
      WHERE NOT (
            lower(replace(trim(coalesce(status, '')), ' ', '')) LIKE '%declined%'
         OR lower(replace(trim(coalesce(outcome, '')), ' ', '')) LIKE '%declined%'
      )
        AND (
            lower(replace(trim(coalesce(status, '')), ' ', '')) IN ('sold', 'closedsold')
         OR lower(replace(trim(coalesce(outcome, '')), ' ', '')) IN ('sold', 'closedsold')
         OR (',' || lower(replace(coalesce(tags, ''), ' ', '')) || ',') LIKE '%,sold,%'
        )`
  );
}

async function fetchTwilioRecordingAudio(recordingSid) {
  const accountSid = clean(process.env.TWILIO_ACCOUNT_SID);
  const authToken = clean(process.env.TWILIO_AUTH_TOKEN);
  if (!accountSid || !authToken) {
    const err = new Error("Twilio is not configured on this server.");
    err.statusCode = 503;
    throw err;
  }
  const sid = clean(recordingSid);
  const mediaUrl = `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Recordings/${encodeURIComponent(sid)}.mp3`;
  const response = await fetch(mediaUrl, {
    headers: {
      Authorization: `Basic ${Buffer.from(`${accountSid}:${authToken}`).toString("base64")}`
    },
    redirect: "follow"
  });
  if (!response.ok) {
    const err = new Error("Recording audio is unavailable from Twilio.");
    err.statusCode = response.status === 404 ? 404 : 502;
    throw err;
  }
  return Buffer.from(await response.arrayBuffer());
}

async function transcribeAudioWithOpenAi(buffer, recordingSid) {
  const apiKey = clean(process.env.OPENAI_API_KEY);
  if (!apiKey) {
    const err = new Error("OPENAI_API_KEY is required for Whisper transcription.");
    err.statusCode = 503;
    throw err;
  }
  const form = new FormData();
  form.append("model", clean(process.env.OPENAI_TRANSCRIPTION_MODEL) || "whisper-1");
  form.append("file", new Blob([buffer], { type: "audio/mpeg" }), `${clean(recordingSid) || "recording"}.mp3`);
  form.append("response_format", "json");
  const response = await fetch("https://api.openai.com/v1/audio/transcriptions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}` },
    body: form
  });
  let data = {};
  try {
    data = await response.json();
  } catch {
    data = {};
  }
  if (!response.ok) {
    const err = new Error(clean(data?.error?.message) || "Whisper transcription failed.");
    err.statusCode = response.status >= 400 && response.status < 600 ? response.status : 502;
    throw err;
  }
  const transcript = clean(data.text);
  if (!transcript) {
    const err = new Error("Whisper returned an empty transcript.");
    err.statusCode = 502;
    throw err;
  }
  return transcript;
}

async function createContactFromPayload(run, get, body, defaultSource) {
  const fullName =
    clean(body.full_name) ||
    clean(body.fullName) ||
    clean(body.name) ||
    [clean(body.first_name || body.firstName), clean(body.last_name || body.lastName)].filter(Boolean).join(" ");
  if (!fullName) {
    const err = new Error("Contact name is required.");
    err.statusCode = 400;
    throw err;
  }
  const email = clean(body.email).toLowerCase();
  const phone = clean(body.phone || body.primary_phone || body.primaryPhone);
  const existing =
    email || phone
      ? await get(
          `SELECT id FROM contacts
            WHERE (? != '' AND lower(trim(email)) = ?)
               OR (? != '' AND (phone = ? OR secondary_phone = ?))
            LIMIT 1`,
          [email, email, phone, phone, phone]
        )
      : null;
  const fields = {
    full_name: fullName,
    email,
    phone,
    secondary_phone: clean(body.secondary_phone || body.secondaryPhone),
    status: clean(body.status) || "NEW",
    outcome: clean(body.outcome),
    tags: clean(body.tags),
    notes: clean(body.notes),
    special_notes: clean(body.special_notes || body.specialNotes),
    lead_source: clean(body.lead_source || body.leadSource) || defaultSource,
    age: clean(body.age),
    gender: clean(body.gender),
    household_size: clean(body.household_size || body.householdSize),
    income: clean(body.income),
    communication_type: clean(body.communication_type || body.communicationType),
    home_address: clean(body.home_address || body.address),
    city: clean(body.city),
    state: clean(body.state),
    zip_code: clean(body.zip_code || body.zip || body.postal_code),
    quote: clean(body.quote),
    health_issues: clean(body.health_issues || body.healthIssues),
    coverage_start_date: clean(body.coverage_start_date || body.coverageStartDate)
  };

  if (existing?.id) {
    await run(
      `UPDATE contacts
          SET full_name = COALESCE(NULLIF(?, ''), full_name),
              email = COALESCE(NULLIF(?, ''), email),
              phone = COALESCE(NULLIF(?, ''), phone),
              secondary_phone = COALESCE(NULLIF(?, ''), secondary_phone),
              status = COALESCE(NULLIF(?, ''), status),
              outcome = COALESCE(NULLIF(?, ''), outcome),
              tags = COALESCE(NULLIF(?, ''), tags),
              notes = COALESCE(NULLIF(?, ''), notes),
              special_notes = COALESCE(NULLIF(?, ''), special_notes),
              lead_source = COALESCE(NULLIF(?, ''), lead_source),
              age = COALESCE(NULLIF(?, ''), age),
              gender = COALESCE(NULLIF(?, ''), gender),
              household_size = COALESCE(NULLIF(?, ''), household_size),
              income = COALESCE(NULLIF(?, ''), income),
              communication_type = COALESCE(NULLIF(?, ''), communication_type),
              home_address = COALESCE(NULLIF(?, ''), home_address),
              city = COALESCE(NULLIF(?, ''), city),
              state = COALESCE(NULLIF(?, ''), state),
              zip_code = COALESCE(NULLIF(?, ''), zip_code),
              quote = COALESCE(NULLIF(?, ''), quote),
              health_issues = COALESCE(NULLIF(?, ''), health_issues),
              coverage_start_date = COALESCE(NULLIF(?, ''), coverage_start_date),
              updated_at = CURRENT_TIMESTAMP
        WHERE id = ?`,
      [...Object.values(fields), existing.id]
    );
    return { id: existing.id, updated: true };
  }

  const result = await run(
    `INSERT INTO contacts
       (full_name, email, phone, secondary_phone, status, outcome, tags, notes, special_notes, lead_source,
        age, gender, household_size, income, communication_type, home_address, city, state, zip_code,
        quote, health_issues, coverage_start_date)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    Object.values(fields)
  );
  return { id: result.lastID, created: true };
}

function flattenTypeform(body) {
  const response = body?.form_response || body;
  const out = {};
  for (const answer of response?.answers || []) {
    const key = clean(answer?.field?.ref || answer?.field?.title || answer?.field?.id)
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "_")
      .replace(/^_+|_+$/g, "");
    if (!key) continue;
    out[key] =
      answer.text ??
      answer.email ??
      answer.phone_number ??
      answer.number ??
      answer.boolean ??
      answer.choice?.label ??
      (Array.isArray(answer.choices?.labels) ? answer.choices.labels.join(", ") : "");
  }
  return out;
}

function registerAiFeatureRoutes(app, { run, get, all, createRateLimiter } = {}) {
  const limiter = createRateLimiter
    ? createRateLimiter({ windowMs: 60_000, max: 20, label: "ai-features" })
    : (_req, _res, next) => next();

  app.post("/api/ai/contacts/:id/score", limiter, async (req, res) => {
    try {
      const ctx = await loadContactContext(get, all, req.params.id);
      if (!ctx) return res.status(404).json({ error: "Contact not found." });
      const scored = await scoreContactWithAi(ctx);
      await persistLeadScore(run, ctx.contact.id, scored);
      return res.json(scored || { score: null, reason: "", nextBestAction: "", cleared: true });
    } catch (error) {
      return res.status(Number(error.statusCode) || 500).json({ error: error.message || "Could not score lead." });
    }
  });

  app.post("/api/ai/contacts/score-batch", limiter, async (req, res) => {
    try {
      if (!clean(process.env.ANTHROPIC_API_KEY)) {
        return res.status(503).json({ error: "AI is not configured on this server." });
      }
      const limit = Math.max(1, Math.min(Number(req.body?.limit) || 25, 25));
      const requestedIds = Array.isArray(req.body?.contactIds)
        ? [
            ...new Set(
              req.body.contactIds
                .map((value) => Number(value))
                .filter((value) => Number.isInteger(value) && value > 0)
            )
          ].slice(0, limit)
        : [];
      const contacts = requestedIds.length
        ? requestedIds.map((id) => ({ id }))
        : await all(
            `SELECT id FROM contacts
              ORDER BY
                CASE WHEN ai_lead_scored_at IS NULL OR ai_lead_scored_at = '' THEN 0 ELSE 1 END ASC,
                datetime(updated_at) DESC,
                id ASC
              LIMIT ?`,
            [limit]
          );
      const outcomes = await mapWithConcurrency(contacts, 3, async (row) => {
        try {
          const result = await scoreBatchContact({ run, get, all }, row.id, { timeoutMs: 30_000 });
          return result ? { ok: true, result } : { ok: false, id: row.id, error: "Contact not found." };
        } catch (error) {
          return { ok: false, id: row.id, error: error.message || "Could not score lead." };
        }
      });
      const results = outcomes.filter((item) => item?.ok).map((item) => item.result);
      const errors = outcomes
        .filter((item) => item && !item.ok)
        .map((item) => ({ id: item.id, error: item.error }))
        .slice(0, 5);
      if (!results.length && errors.length) {
        return res.status(502).json({
          error: errors[0].error || "Could not score leads.",
          scored: 0,
          failed: errors.length,
          errors
        });
      }
      return res.json({ scored: results.length, failed: outcomes.length - results.length, results, errors });
    } catch (error) {
      return res.status(Number(error.statusCode) || 500).json({ error: error.message || "Could not score leads." });
    }
  });

  app.post("/api/ai/contacts/:id/objection-coach", limiter, async (req, res) => {
    try {
      const objection = clean(req.body?.objection);
      if (!objection) return res.status(400).json({ error: "Enter the client's objection." });
      const ctx = await loadContactContext(get, all, req.params.id);
      if (!ctx) return res.status(404).json({ error: "Contact not found." });
      const payload = await callClaudeJson({
        system:
          "You are an ACA and Medicare sales coach for licensed health insurance agents. Return JSON only: {\"rebuttals\":[\"...\"],\"bestQuestion\":\"...\",\"complianceNote\":\"...\"}. Keep advice compliant, plain-English, and specific.",
        user: `Client objection: ${objection}\nContact context:\n${JSON.stringify(
          { contact: contactForAi(ctx.contact), recentHistory: historyForAi(ctx.history) },
          null,
          2
        )}`,
        maxTokens: 1000
      });
      const result = {
        rebuttals: Array.isArray(payload?.rebuttals) ? payload.rebuttals.map(clean).filter(Boolean).slice(0, 3) : [],
        bestQuestion: clean(payload?.bestQuestion),
        complianceNote: clean(payload?.complianceNote)
      };
      await logAiActivity(run, ctx.contact.id, "ai_objection_coach", { objection, ...result });
      return res.json(result);
    } catch (error) {
      return res.status(Number(error.statusCode) || 500).json({ error: error.message || "Could not coach objection." });
    }
  });

  app.post("/api/ai/contacts/:id/call-summary", limiter, async (req, res) => {
    try {
      const notes = clean(req.body?.notes || req.body?.transcript);
      if (!notes) return res.status(400).json({ error: "Enter call notes or a transcript to summarize." });
      const ctx = await loadContactContext(get, all, req.params.id);
      if (!ctx) return res.status(404).json({ error: "Contact not found." });
      const payload = await callClaudeJson({
        system:
          "You summarize health insurance sales calls for CRM history. Return JSON only: {\"summary\":\"...\",\"discussed\":[\"...\"],\"nextSteps\":[\"...\"],\"followUpDate\":\"YYYY-MM-DD or empty\",\"recommendedStatus\":\"...\",\"recommendedOutcome\":\"...\"}.",
        user: `Call notes/transcript:\n${notes}\n\nContact context:\n${JSON.stringify({ contact: contactForAi(ctx.contact) }, null, 2)}`,
        maxTokens: 1000
      });
      const result = {
        summary: clean(payload?.summary),
        discussed: Array.isArray(payload?.discussed) ? payload.discussed.map(clean).filter(Boolean) : [],
        nextSteps: Array.isArray(payload?.nextSteps) ? payload.nextSteps.map(clean).filter(Boolean) : [],
        followUpDate: clean(payload?.followUpDate),
        recommendedStatus: clean(payload?.recommendedStatus),
        recommendedOutcome: clean(payload?.recommendedOutcome)
      };
      await logAiActivity(run, ctx.contact.id, "ai_call_summary", result);
      scheduleAutoLeadScore({ run, get, all }, ctx.contact.id, "call_summary");
      return res.json(result);
    } catch (error) {
      return res.status(Number(error.statusCode) || 500).json({ error: error.message || "Could not summarize call." });
    }
  });

  app.post("/api/ai/contacts/:id/recordings/:recordingSid/transcribe", limiter, async (req, res) => {
    const contactId = Number(req.params.id);
    const recordingSid = clean(req.params.recordingSid);
    try {
      if (!Number.isInteger(contactId) || contactId <= 0) return res.status(400).json({ error: "Invalid contact." });
      if (!recordingSid) return res.status(400).json({ error: "recordingSid is required." });
      await run(
        `UPDATE call_recordings SET transcript_status = 'processing', transcript_error = '', updated_at = CAST(strftime('%s','now') AS INTEGER)
          WHERE contact_id = ? AND recording_sid = ?`,
        [contactId, recordingSid]
      );
      const audio = await fetchTwilioRecordingAudio(recordingSid);
      const transcript = await transcribeAudioWithOpenAi(audio, recordingSid);
      await run(
        `UPDATE call_recordings
            SET transcript_text = ?, transcript_status = 'completed', transcript_error = '', transcribed_at = CURRENT_TIMESTAMP,
                updated_at = CAST(strftime('%s','now') AS INTEGER)
          WHERE contact_id = ? AND recording_sid = ?`,
        [transcript, contactId, recordingSid]
      );
      const ctx = await loadContactContext(get, all, contactId);
      if (ctx) {
        await logAiActivity(run, contactId, "call_transcript", { recordingSid, transcript });
      }
      return res.json({ transcript });
    } catch (error) {
      await run(
        `UPDATE call_recordings SET transcript_status = 'failed', transcript_error = ?, updated_at = CAST(strftime('%s','now') AS INTEGER)
          WHERE contact_id = ? AND recording_sid = ?`,
        [clean(error.message).slice(0, 500), contactId, recordingSid]
      ).catch(() => {});
      return res.status(Number(error.statusCode) || 500).json({ error: error.message || "Could not transcribe recording." });
    }
  });

  app.post("/api/ai/campaigns/:id/analyze", limiter, async (req, res) => {
    try {
      const campaignId = Number(req.params.id);
      if (!Number.isInteger(campaignId) || campaignId <= 0) return res.status(400).json({ error: "Invalid campaign." });
      const campaign = await get(`SELECT * FROM drip_campaigns WHERE id = ?`, [campaignId]);
      if (!campaign) return res.status(404).json({ error: "Campaign not found." });
      const steps = await all(`SELECT * FROM drip_steps WHERE campaign_id = ? ORDER BY step_order ASC, id ASC`, [campaignId]);
      const stats = await get(
        `SELECT
           COUNT(DISTINCT e.id) AS enrollments,
           SUM(CASE WHEN q.status = 'pending' THEN 1 ELSE 0 END) AS pending,
           SUM(CASE WHEN q.status = 'sent' THEN 1 ELSE 0 END) AS sent,
           SUM(CASE WHEN q.status = 'failed' THEN 1 ELSE 0 END) AS failed,
           SUM(CASE WHEN q.status = 'skipped' THEN 1 ELSE 0 END) AS skipped,
           SUM(CASE WHEN lower(coalesce(c.outcome,'')) = 'sold' THEN 1 ELSE 0 END) AS sold
         FROM drip_enrollments e
         LEFT JOIN drip_send_queue q ON q.enrollment_id = e.id
         LEFT JOIN contacts c ON c.id = e.contact_id
         WHERE e.campaign_id = ?`,
        [campaignId]
      );
      const payload = await callClaudeJson({
        system:
          "You analyze CRM drip campaign performance for health insurance agents. Return JSON only: {\"summary\":\"...\",\"whatWorked\":[\"...\"],\"whatDidNotWork\":[\"...\"],\"changes\":[\"...\"],\"nextTest\":\"...\"}.",
        user: JSON.stringify({ campaign, steps, stats }, null, 2),
        maxTokens: 1000
      });
      return res.json({
        summary: clean(payload?.summary),
        whatWorked: Array.isArray(payload?.whatWorked) ? payload.whatWorked.map(clean).filter(Boolean) : [],
        whatDidNotWork: Array.isArray(payload?.whatDidNotWork) ? payload.whatDidNotWork.map(clean).filter(Boolean) : [],
        changes: Array.isArray(payload?.changes) ? payload.changes.map(clean).filter(Boolean) : [],
        nextTest: clean(payload?.nextTest),
        stats
      });
    } catch (error) {
      return res.status(Number(error.statusCode) || 500).json({ error: error.message || "Could not analyze campaign." });
    }
  });

  app.post("/webhooks/inbound/contact", async (req, res) => {
    try {
      requireWebhookSecret(req);
      const result = await createContactFromPayload(run, get, req.body || {}, clean(req.body?.lead_source) || "Zapier");
      await logAiActivity(run, result.id, "inbound_webhook", { source: "generic", created: Boolean(result.created) });
      scheduleAutoLeadScore({ run, get, all }, result.id, "inbound_webhook");
      return res.json({ ok: true, ...result });
    } catch (error) {
      return res.status(Number(error.statusCode) || 500).json({ error: error.message || "Could not process webhook." });
    }
  });

  app.post("/webhooks/typeform/contact", async (req, res) => {
    try {
      requireWebhookSecret(req);
      const fields = flattenTypeform(req.body || {});
      const result = await createContactFromPayload(run, get, { ...fields, lead_source: fields.lead_source || "Typeform" }, "Typeform");
      await logAiActivity(run, result.id, "typeform_intake", { fields });
      scheduleAutoLeadScore({ run, get, all }, result.id, "typeform_intake");
      return res.json({ ok: true, ...result });
    } catch (error) {
      return res.status(Number(error.statusCode) || 500).json({ error: error.message || "Could not process Typeform webhook." });
    }
  });
}

module.exports = { registerAiFeatureRoutes, scheduleAutoLeadScore, autoScoreContact, normalizeSoldLeadScores };
