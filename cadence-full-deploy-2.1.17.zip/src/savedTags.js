/**
 * Workspace tag catalog. Contact tags disappear from pickers when unused;
 * this list keeps every created tag (campaign enroll, contact add, explicit save).
 */
const SETTING_KEY = "saved_contact_tags_v1";

function normalizeTag(raw) {
  return String(raw == null ? "" : raw).trim();
}

function uniqueTags(list) {
  const seen = new Map();
  for (const item of Array.isArray(list) ? list : []) {
    const tag = normalizeTag(item);
    if (!tag) continue;
    const key = tag.toLowerCase();
    if (!seen.has(key)) seen.set(key, tag);
  }
  return [...seen.values()];
}

function parseStored(raw) {
  const s = String(raw || "").trim();
  if (!s) return [];
  try {
    return uniqueTags(JSON.parse(s));
  } catch {
    return uniqueTags(s.split(/[,;\n\r]+/));
  }
}

async function loadSavedTags(get) {
  try {
    const row = await get(`SELECT value FROM crm_app_settings WHERE key = ?`, [SETTING_KEY]);
    return parseStored(row && row.value);
  } catch {
    return [];
  }
}

async function writeSavedTags(run, tags) {
  const list = uniqueTags(tags);
  list.sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));
  await run(`INSERT OR REPLACE INTO crm_app_settings (key, value) VALUES (?, ?)`, [SETTING_KEY, JSON.stringify(list)]);
  return list;
}

async function rememberTags({ get, run }, incoming) {
  const extra = uniqueTags(incoming);
  if (!extra.length) return loadSavedTags(get);
  const existing = await loadSavedTags(get);
  return writeSavedTags(run, [...existing, ...extra]);
}

function tagsFromContactRows(rows) {
  const out = [];
  for (const row of Array.isArray(rows) ? rows : []) {
    String(row.tags || "")
      .split(/[,;\n\r]+/)
      .map((t) => t.trim())
      .filter(Boolean)
      .forEach((t) => out.push(t));
  }
  return out;
}

function tagsFromCampaigns(campaigns) {
  const out = [];
  for (const c of Array.isArray(campaigns) ? campaigns : []) {
    const name = normalizeTag(c && c.name);
    if (name) out.push(name);
    let rules = Array.isArray(c && c.tag_rules) ? c.tag_rules : [];
    if (!rules.length && c && c.tag_config != null) {
      try {
        const parsed = typeof c.tag_config === "string" ? JSON.parse(c.tag_config || "[]") : c.tag_config;
        if (Array.isArray(parsed)) rules = parsed;
      } catch {
        rules = [];
      }
    }
    for (const r of rules) {
      const tag = normalizeTag(r && r.tag);
      const fn = String(r && r.function != null ? r.function : "enroll")
        .trim()
        .toLowerCase();
      if (tag && fn !== "none") out.push(tag);
    }
  }
  return out;
}

async function collectKnownTags({ get, all, run }) {
  const saved = await loadSavedTags(get);
  let contactTags = [];
  let campaignTags = [];
  try {
    const rows = await all(`SELECT tags FROM contacts WHERE tags IS NOT NULL AND trim(tags) != ''`);
    contactTags = tagsFromContactRows(rows);
  } catch {
    /* ignore */
  }
  try {
    const campaigns = await all(`SELECT name, tag_config FROM drip_campaigns`);
    campaignTags = tagsFromCampaigns(campaigns);
  } catch {
    /* drip tables may be missing on older DBs */
  }
  const merged = uniqueTags([...saved, ...contactTags, ...campaignTags]);
  merged.sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));
  if (run && merged.length) {
    const savedSet = new Set(saved.map((t) => t.toLowerCase()));
    if (merged.some((t) => !savedSet.has(t.toLowerCase()))) {
      try {
        await writeSavedTags(run, merged);
      } catch {
        /* listing must still succeed */
      }
    }
  }
  return merged;
}

module.exports = {
  SETTING_KEY,
  uniqueTags,
  rememberTags,
  collectKnownTags,
  loadSavedTags
};
