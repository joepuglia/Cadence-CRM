"use strict";

const { AsyncLocalStorage } = require("async_hooks");

/**
 * Trial requests used to copy their email, texting, and website settings onto
 * the shared process environment. Another request in the same process could
 * then send with those settings. This overlay keeps those writes on the
 * trial request only. The main account's environment is left alone.
 *
 * process.env rejects Object.defineProperty unless the descriptor is a
 * writable, enumerable, configurable data property. A partial descriptor
 * throws "'process.env' only accepts a configurable, writable, and enumerable
 * data descriptor" and that was aborting Twilio credential saves. Writes go
 * straight onto the real environment as strings instead.
 */
const runtimeEnvOverlay = new AsyncLocalStorage();

function envString(value) {
  if (value == null) return "";
  return String(value);
}

function writeRealEnv(target, prop, value) {
  target[prop] = envString(value);
  return true;
}

function installRuntimeEnvOverlay() {
  if (process.env && process.env.__cadenceEnvProxy) return;
  const realEnv = process.env;
  const proxy = new Proxy(realEnv, {
    get(target, prop, receiver) {
      if (prop === "__cadenceEnvProxy") return true;
      if (typeof prop === "string") {
        const overlay = runtimeEnvOverlay.getStore();
        if (overlay && Object.prototype.hasOwnProperty.call(overlay, prop)) {
          return overlay[prop];
        }
      }
      return Reflect.get(target, prop, receiver);
    },
    set(target, prop, value) {
      if (typeof prop !== "string") return false;
      const overlay = runtimeEnvOverlay.getStore();
      if (overlay) {
        overlay[prop] = envString(value);
        return true;
      }
      return writeRealEnv(target, prop, value);
    },
    defineProperty(target, prop, descriptor) {
      if (typeof prop !== "string" || !descriptor || typeof descriptor !== "object") return false;
      const hasValue = Object.prototype.hasOwnProperty.call(descriptor, "value");
      if (!hasValue && (descriptor.get || descriptor.set)) return false;
      const overlay = runtimeEnvOverlay.getStore();
      const stringValue = hasValue ? envString(descriptor.value) : "";
      if (overlay) {
        overlay[prop] = stringValue;
        return true;
      }
      return writeRealEnv(target, prop, stringValue);
    },
    deleteProperty(target, prop) {
      if (typeof prop !== "string") return false;
      const overlay = runtimeEnvOverlay.getStore();
      if (overlay) {
        overlay[prop] = "";
        return true;
      }
      delete target[prop];
      return true;
    },
    has(target, prop) {
      if (typeof prop === "string") {
        const overlay = runtimeEnvOverlay.getStore();
        if (overlay && Object.prototype.hasOwnProperty.call(overlay, prop)) return true;
      }
      return Reflect.has(target, prop);
    }
  });
  process.env = proxy;
}

function runWithIsolatedRuntimeEnv(fn) {
  return runtimeEnvOverlay.run(Object.create(null), fn);
}

/** Drop a trial-only mask so the request reads the site-wide value again. */
function releaseRuntimeEnvKey(key) {
  const overlay = runtimeEnvOverlay.getStore();
  if (!overlay || typeof key !== "string") return;
  delete overlay[key];
}

module.exports = {
  installRuntimeEnvOverlay,
  runWithIsolatedRuntimeEnv,
  releaseRuntimeEnvKey
};
