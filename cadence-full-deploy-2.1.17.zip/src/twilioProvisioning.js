"use strict";

/**
 * twilioProvisioning.js
 * Purchases and releases Twilio phone numbers using the master (owner) Twilio account.
 *
 * Required env vars (owner's Twilio account — NOT the tenant's):
 *   TWILIO_MASTER_ACCOUNT_SID
 *   TWILIO_MASTER_AUTH_TOKEN
 */

const twilio = require("twilio");

// One area code per US state — used to pick a local number for new agents.
const STATE_AREA_CODES = {
  AL: "205", AK: "907", AZ: "602", AR: "501", CA: "213",
  CO: "303", CT: "203", DE: "302", FL: "305", GA: "404",
  HI: "808", ID: "208", IL: "312", IN: "317", IA: "319",
  KS: "316", KY: "502", LA: "504", ME: "207", MD: "410",
  MA: "617", MI: "313", MN: "612", MS: "601", MO: "314",
  MT: "406", NE: "402", NV: "702", NH: "603", NJ: "201",
  NM: "505", NY: "212", NC: "704", ND: "701", OH: "216",
  OK: "405", OR: "503", PA: "215", RI: "401", SC: "803",
  SD: "605", TN: "615", TX: "214", UT: "801", VT: "802",
  VA: "703", WA: "206", WV: "304", WI: "414", WY: "307",
  DC: "202"
};

function getMasterClient() {
  const sid   = String(process.env.TWILIO_MASTER_ACCOUNT_SID || process.env.TWILIO_ACCOUNT_SID || "").trim();
  const token = String(process.env.TWILIO_MASTER_AUTH_TOKEN  || process.env.TWILIO_AUTH_TOKEN  || "").trim();
  if (!sid || !token) {
    throw new Error("No Twilio master credentials found. Set TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN in .env.");
  }
  return twilio(sid, token);
}

function isMasterConfigured() {
  const sid   = String(process.env.TWILIO_MASTER_ACCOUNT_SID || process.env.TWILIO_ACCOUNT_SID || "").trim();
  const token = String(process.env.TWILIO_MASTER_AUTH_TOKEN  || process.env.TWILIO_AUTH_TOKEN  || "").trim();
  return Boolean(sid) && Boolean(token);
}

/**
 * Purchase a local US phone number for a new tenant.
 * Tries multiple area codes for the state before falling back nationally.
 * Auto-configures voice webhook and messaging service if provided.
 * Returns the purchased number in E.164 format.
 */

// Multiple area codes per state for better availability
const STATE_AREA_CODES_ALL = {
  AL: ["205","251","256","334"], AK: ["907"], AZ: ["480","520","602","623","928"],
  AR: ["479","501","870"], CA: ["209","213","310","323","408","415","424","442","510","530","559","562","619","626","628","650","657","661","669","707","714","747","760","805","818","831","858","909","916","925","949","951"],
  CO: ["303","719","720","970"], CT: ["203","475","860","959"], DE: ["302"],
  FL: ["239","305","321","352","386","407","561","727","754","772","786","813","850","863","904","941","954"],
  GA: ["229","404","470","478","678","706","762","770","912"], HI: ["808"],
  ID: ["208","986"], IL: ["217","224","309","312","331","618","630","708","773","779","815","847"],
  IN: ["219","260","317","463","574","765","812","930"], IA: ["319","515","563","641","712"],
  KS: ["316","620","785","913"], KY: ["270","364","502","606","859"],
  LA: ["225","318","337","504","985"], ME: ["207"],
  MD: ["240","301","410","443","667"], MA: ["339","351","413","508","617","774","781","857","978"],
  MI: ["231","248","269","313","517","586","616","734","810","906","947","989"],
  MN: ["218","320","507","612","651","763","952"], MS: ["228","601","662","769"],
  MO: ["314","417","573","636","660","816"], MT: ["406"],
  NE: ["308","402","531"], NV: ["702","725","775"], NH: ["603"],
  NJ: ["201","551","609","732","848","856","862","908","973"],
  NM: ["505","575"], NY: ["212","315","332","347","516","518","585","607","631","646","680","716","718","838","845","914","917","929","934"],
  NC: ["252","336","704","743","828","910","919","980","984"],
  ND: ["701"], OH: ["216","220","234","330","380","419","440","513","567","614","740","937"],
  OK: ["405","539","580","918"], OR: ["458","503","541","971"],
  PA: ["215","223","267","272","412","445","484","570","610","717","724","814","878"],
  RI: ["401"], SC: ["803","839","843","854","864"],
  SD: ["605"], TN: ["423","615","629","731","865","901","931"],
  TX: ["210","214","254","281","325","346","361","409","430","432","469","512","682","713","726","737","806","817","830","832","903","915","936","940","956","972","979"],
  UT: ["385","435","801"], VT: ["802"],
  VA: ["276","434","540","571","703","757","804"],
  WA: ["206","253","360","425","509","564"], WV: ["304","681"],
  WI: ["262","414","534","608","715","920"], WY: ["307"], DC: ["202"]
};

async function purchaseNumberForTenant({ residentState, voiceWebhookUrl, messagingServiceSid } = {}) {
  const client   = getMasterClient();
  const state    = String(residentState || "").trim().toUpperCase();
  const areaCodes = STATE_AREA_CODES_ALL[state] || (STATE_AREA_CODES[state] ? [STATE_AREA_CODES[state]] : []);

  async function searchAndBuy(searchOpts) {
    const available = await client.availablePhoneNumbers("US")
      .local.list({ ...searchOpts, smsEnabled: true, voiceEnabled: true, limit: 5 });
    if (!available || available.length === 0) return null;
    const chosen = available[0];
    const createOpts = {
      phoneNumber: chosen.phoneNumber,
      friendlyName: `Cadence CRM — auto-provisioned`
    };
    if (voiceWebhookUrl) {
      createOpts.voiceUrl    = voiceWebhookUrl;
      createOpts.voiceMethod = "POST";
    }
    const purchased = await client.incomingPhoneNumbers.create(createOpts);

    // Add to messaging service sender pool for A2P 10DLC compliance
    if (messagingServiceSid && purchased.sid) {
      try {
        await client.messaging.v1.services(messagingServiceSid)
          .phoneNumbers
          .create({ phoneNumberSid: purchased.sid });
        console.log(`[provisioning] Added ${purchased.phoneNumber} to messaging service ${messagingServiceSid}`);
      } catch (msgErr) {
        console.error(`[provisioning] Failed to add to messaging service:`, msgErr.message);
        // Non-fatal — number still works for voice
      }
    }

    return purchased.phoneNumber;
  }

  // Try state area codes first
  let number = null;
  for (const areaCode of areaCodes) {
    if (number) break;
    try {
      number = await searchAndBuy({ areaCode });
    } catch (_) {}
  }

  // Fall back to any US number
  if (!number) {
    number = await searchAndBuy({});
  }
  if (!number) {
    throw new Error("No available US phone numbers found in your Twilio account.");
  }
  return number;
}

/**
 * Add an existing number to a messaging service sender pool.
 * Call this to fix numbers provisioned before the messaging service was configured.
 */
async function addNumberToMessagingService(phoneNumber, messagingServiceSid) {
  if (!phoneNumber || !messagingServiceSid) return;
  const client = getMasterClient();
  const numbers = await client.incomingPhoneNumbers.list({ phoneNumber, limit: 1 });
  if (!numbers || !numbers.length) throw new Error(`Number ${phoneNumber} not found in Twilio account.`);
  await client.messaging.v1.services(messagingServiceSid)
    .phoneNumbers
    .create({ phoneNumberSid: numbers[0].sid });
}

/**
 * Release a number back to Twilio (e.g. when a tenant cancels).
 * Looks up the number's SID from the master account and releases it.
 */
async function releaseNumber(phoneNumber) {
  if (!phoneNumber) return;
  const client = getMasterClient();
  const normalized = String(phoneNumber).trim();
  const numbers = await client.incomingPhoneNumbers.list({ phoneNumber: normalized, limit: 1 });
  if (!numbers || numbers.length === 0) return;
  await client.incomingPhoneNumbers(numbers[0].sid).remove();
}

module.exports = {
  purchaseNumberForTenant,
  releaseNumber,
  addNumberToMessagingService,
  isMasterConfigured,
  STATE_AREA_CODES
};
