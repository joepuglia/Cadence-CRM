const crypto = require("crypto");
const { callClaudeText, callClaudeJson, getClaudeConfig } = require("./claudeClient");
const { loadContactContextForAssistant } = require("./assistantRoutes");

const SESSION_TTL_MS = 2 * 60 * 60 * 1000;
const MAX_TURNS = 24;
const sessions = new Map();

const SCENARIOS = [
  {
    id: "too-expensive",
    label: "It's too expensive",
    insurance: "ACA / private",
    objection: "The premium is too high and they do not think they can afford it."
  },
  {
    id: "already-covered",
    label: "I already have coverage",
    insurance: "ACA / private",
    objection: "They already have a plan and do not see why they should look at anything else."
  },
  {
    id: "talk-to-spouse",
    label: "I need to talk to my spouse",
    insurance: "Family / household",
    objection: "They will not decide without their spouse, and they want to get off the phone."
  },
  {
    id: "wait-for-oep",
    label: "I'll wait until Open Enrollment",
    insurance: "ACA",
    objection: "They think they can wait and do not want to deal with it today."
  },
  {
    id: "better-quote-online",
    label: "I got a better quote online",
    insurance: "ACA / private",
    objection: "They found a cheaper quote on a website and think this call is a waste of time."
  },
  {
    id: "got-burned",
    label: "I don't trust insurance",
    insurance: "General",
    objection: "They got burned before, feel sold to, and are guarded."
  },
  {
    id: "like-current-medicare",
    label: "I like my current Medicare plan",
    insurance: "Medicare",
    objection: "They are happy enough with their current Medicare plan and do not want to change."
  },
  {
    id: "just-send-something",
    label: "Just send me something",
    insurance: "General",
    objection: "They want an email or brochure so they can hang up without answering questions."
  }
];

const DIFFICULTIES = {
  easy: {
    label: "Easy",
    persona: "polite and a little unsure",
    style:
      "Stay on one objection. Soften if the agent asks a good question. You can become willing to continue after 2-3 solid exchanges."
  },
  typical: {
    label: "Typical",
    persona: "skeptical but not rude",
    style:
      "Hold the main objection. Answer briefly. Ask the agent to prove why this matters. Do not fold after one rebuttal."
  },
  hard: {
    label: "Hard",
    persona: "rushed and interruptive",
    style:
      "Interrupt, change the subject, go quiet, or switch to a second objection. Do not make this easy. You may end the call if they only pitch."
  }
};

function pruneSessions() {
  const now = Date.now();
  for (const [key, session] of sessions) {
    if (!session || now - Number(session.updatedAt || 0) > SESSION_TTL_MS) sessions.delete(key);
  }
}

function tenantKey(req, getAuthSession) {
  const session = typeof getAuthSession === "function" ? getAuthSession(req) : null;
  const tenantId = Number(session?.tenantId || 1);
  return Number.isFinite(tenantId) && tenantId > 0 ? String(tenantId) : "1";
}

function storeKey(tenantId, sessionId) {
  return `${tenantId}:${sessionId}`;
}

function getSession(req, getAuthSession, sessionId) {
  pruneSessions();
  const id = String(sessionId || "").trim();
  if (!id) return null;
  return sessions.get(storeKey(tenantKey(req, getAuthSession), id)) || null;
}

function saveSession(req, getAuthSession, session) {
  session.updatedAt = Date.now();
  sessions.set(storeKey(tenantKey(req, getAuthSession), session.id), session);
}

function publicScenario(row) {
  return {
    id: row.id,
    label: row.label,
    insurance: row.insurance
  };
}

function formatContactForPrompt(ctx) {
  if (!ctx) return "";
  const lines = [
    ctx.fullName ? `Name: ${ctx.fullName}` : "",
    ctx.state ? `State: ${ctx.state}` : "",
    ctx.status ? `CRM status: ${ctx.status}` : "",
    ctx.outcome ? `Outcome: ${ctx.outcome}` : "",
    ctx.leadSource ? `Lead source: ${ctx.leadSource}` : "",
    ctx.tags ? `Tags: ${ctx.tags}` : "",
    ctx.notes ? `Notes: ${ctx.notes}` : "",
    ctx.specialNotes ? `Special notes: ${ctx.specialNotes}` : "",
    Array.isArray(ctx.recentActivity) && ctx.recentActivity.length
      ? `Recent activity:\n${ctx.recentActivity.join("\n")}`
      : ""
  ].filter(Boolean);
  return lines.join("\n");
}

function buildProspectSystem(session) {
  const scenario = session.scenario;
  const difficulty = DIFFICULTIES[session.difficulty] || DIFFICULTIES.typical;
  const contactBlock = session.contactPrompt
    ? `\nYou are this specific person from the agent's CRM. Use only these facts. Do not invent plan names, prices, subsidies, or eligibility.\n${session.contactPrompt}\n`
    : "\nYou are a realistic health-insurance prospect. Do not invent specific plan names, prices, or eligibility.\n";

  return `You are role-playing as a health insurance prospect on a live phone call inside Cadence CRM training.
${contactBlock}
Main objection: ${scenario.objection}
Insurance context: ${scenario.insurance}
Personality: ${difficulty.persona}
Difficulty rules: ${difficulty.style}

Rules:
- Stay in character as the prospect the entire time
- Speak like a real person on a phone call: short, 1 to 3 sentences
- Never coach the agent, never mention AI, training, role play, or Cadence
- Do not give the agent the "right" answer
- Do not agree to buy on the first pitch
- If they are consultative and earn trust, you may warm up slightly
- If they pressure, guarantee savings, or dump a script, get colder
- No medical, legal, or tax advice`;
}

function formatTranscript(session) {
  return (Array.isArray(session.messages) ? session.messages : [])
    .filter((m) => m && m.content && m.content !== "[call connected]")
    .map((m) => `${m.role === "assistant" ? "Prospect" : "Agent"}: ${m.content}`)
    .join("\n");
}

function registerRolePlayRoutes(app, { all, get, createRateLimiter, getAuthSession }) {
  const limiter = createRateLimiter
    ? createRateLimiter({ windowMs: 60_000, max: 30, label: "role-play" })
    : (_req, _res, next) => next();

  app.get("/api/role-play/status", (_req, res) => {
    const { configured, model, keyLooksValid } = getClaudeConfig();
    return res.json({ configured, model, provider: "claude", keyLooksValid });
  });

  app.get("/api/role-play/contacts", async (req, res) => {
    try {
      if (!all) return res.status(500).json({ error: "Contact search unavailable." });
      const q = String(req.query.q || "").trim();
      let rows;
      if (!q) {
        rows = await all(
          `SELECT id, full_name, email, outcome
           FROM contacts
           ORDER BY datetime(created_at) DESC, id DESC
           LIMIT 12`
        );
      } else {
        const like = `%${q.replace(/[%_]/g, "")}%`;
        rows = await all(
          `SELECT id, full_name, email, outcome
           FROM contacts
           WHERE full_name LIKE ? OR IFNULL(email,'') LIKE ? OR IFNULL(phone,'') LIKE ?
           ORDER BY full_name COLLATE NOCASE ASC
           LIMIT 12`,
          [like, like, like]
        );
      }
      return res.json({
        items: (Array.isArray(rows) ? rows : []).map((row) => ({
          id: row.id,
          full_name: String(row.full_name || "").trim(),
          email: String(row.email || "").trim(),
          outcome: String(row.outcome || "").trim()
        }))
      });
    } catch (error) {
      return res.status(500).json({ error: error.message || "Could not search contacts." });
    }
  });

  app.get("/api/role-play/scenarios", (_req, res) => {
    return res.json({
      scenarios: SCENARIOS.map(publicScenario),
      difficulties: Object.entries(DIFFICULTIES).map(([id, row]) => ({
        id,
        label: row.label
      }))
    });
  });

  app.post("/api/role-play/start", limiter, async (req, res) => {
    try {
      const scenarioId = String(req.body?.scenarioId || "").trim();
      const scenario = SCENARIOS.find((s) => s.id === scenarioId) || SCENARIOS[0];
      const difficultyKey = String(req.body?.difficulty || "typical")
        .trim()
        .toLowerCase();
      const difficulty = DIFFICULTIES[difficultyKey] ? difficultyKey : "typical";

      let contactCtx = null;
      if (get && req.body?.contactId) {
        contactCtx = await loadContactContextForAssistant(get, all, req.body.contactId);
      }

      const session = {
        id: crypto.randomBytes(16).toString("hex"),
        scenario,
        difficulty,
        contactId: contactCtx?.id || null,
        contactName: contactCtx?.fullName || "",
        contactPrompt: formatContactForPrompt(contactCtx),
        messages: [],
        createdAt: Date.now(),
        updatedAt: Date.now()
      };

      const opening = await callClaudeText({
        system: buildProspectSystem(session),
        user: "The agent just picked up. Greet them naturally and raise your main objection in 1-3 short spoken sentences.",
        maxTokens: 220,
        temperature: 0.8
      });

      session.messages.push({ role: "user", content: "[call connected]" });
      session.messages.push({ role: "assistant", content: opening });
      saveSession(req, getAuthSession, session);

      return res.json({
        sessionId: session.id,
        scenario: publicScenario(scenario),
        difficulty,
        contactName: session.contactName,
        prospectMessage: opening
      });
    } catch (error) {
      return res.status(Number(error.statusCode) || 500).json({
        error: error.message || "Could not start role play."
      });
    }
  });

  app.post("/api/role-play/turn", limiter, async (req, res) => {
    try {
      const session = getSession(req, getAuthSession, req.body?.sessionId);
      if (!session) return res.status(404).json({ error: "Call ended or expired. Start a new role play." });
      const agentMessage = String(req.body?.message || "").trim();
      if (!agentMessage) return res.status(400).json({ error: "Say something to the prospect." });
      const agentTurns = session.messages.filter((m) => m.role === "user" && m.content !== "[call connected]").length;
      if (agentTurns >= MAX_TURNS) {
        return res.status(400).json({ error: "This practice call is long enough. End the call for a scorecard." });
      }

      session.messages.push({ role: "user", content: agentMessage });
      const prospectMessage = await callClaudeText({
        system: buildProspectSystem(session),
        messages: session.messages,
        maxTokens: 220,
        temperature: 0.75
      });
      session.messages.push({ role: "assistant", content: prospectMessage });
      saveSession(req, getAuthSession, session);
      return res.json({ prospectMessage });
    } catch (error) {
      return res.status(Number(error.statusCode) || 500).json({
        error: error.message || "Could not continue the role play."
      });
    }
  });

  app.post("/api/role-play/hint", limiter, async (req, res) => {
    try {
      const session = getSession(req, getAuthSession, req.body?.sessionId);
      if (!session) return res.status(404).json({ error: "Call ended or expired. Start a new role play." });
      const transcript = formatTranscript(session) || "The call just started.";
      const hint = await callClaudeText({
        system: `You are a quiet sales coach sitting next to a licensed health insurance agent during role play.
Give ONE short hint (1-2 sentences) for their next line.
Be specific to the last prospect line.
Do not write a full script. Do not invent prices, plan names, or eligibility.
Stay compliant: no pressure, no guarantees, no medical/legal/tax advice.`,
        user: `Scenario: ${session.scenario.label}\nDifficulty: ${session.difficulty}\n\nTranscript:\n${transcript}\n\nGive the next-line hint only.`,
        maxTokens: 160,
        temperature: 0.4
      });
      return res.json({ hint });
    } catch (error) {
      return res.status(Number(error.statusCode) || 500).json({
        error: error.message || "Could not load a hint."
      });
    }
  });

  app.post("/api/role-play/end", limiter, async (req, res) => {
    try {
      const session = getSession(req, getAuthSession, req.body?.sessionId);
      if (!session) return res.status(404).json({ error: "Call ended or expired. Start a new role play." });
      const transcript = formatTranscript(session);
      if (!transcript) return res.status(400).json({ error: "Say at least one line before ending the call." });

      const debrief = await callClaudeJson({
        system: `You coach licensed health insurance agents after a practice call.
Return JSON only:
{
  "score": 1-10 integer,
  "whatWorked": "1-2 sentences",
  "betterQuestion": "one better question they should have asked",
  "lineToUse": "one spoken line they can use tomorrow",
  "watchOut": "one compliance or habit watch-out"
}
Be direct and specific to the transcript. No guarantees, no invented prices or plan names.`,
        user: `Scenario: ${session.scenario.label}\nDifficulty: ${session.difficulty}\n\nTranscript:\n${transcript}`,
        maxTokens: 500
      });

      const payload = {
        score: Math.max(1, Math.min(10, Number(debrief?.score) || 5)),
        whatWorked: String(debrief?.whatWorked || "").trim(),
        betterQuestion: String(debrief?.betterQuestion || "").trim(),
        lineToUse: String(debrief?.lineToUse || "").trim(),
        watchOut: String(debrief?.watchOut || "").trim()
      };
      sessions.delete(storeKey(tenantKey(req, getAuthSession), session.id));
      return res.json({ debrief: payload, scenario: publicScenario(session.scenario) });
    } catch (error) {
      return res.status(Number(error.statusCode) || 500).json({
        error: error.message || "Could not score the call."
      });
    }
  });
}

module.exports = { registerRolePlayRoutes };
