"use strict";

const crypto = require("crypto");

function isPublicOrigin(origin) {
  const raw = String(origin || "").trim().replace(/\/$/, "");
  if (!raw) return "";
  try {
    const host = new URL(raw).hostname.toLowerCase();
    if (!host || host === "localhost" || host === "127.0.0.1" || host === "::1") return "";
    return raw;
  } catch {
    return "";
  }
}

function ensureTrackingPixelHtml(html, pixelUrl) {
  const body = String(html || "").trim();
  const pixel = `<img src="${pixelUrl}" alt="" width="1" height="1" style="display:block;width:1px;height:1px;border:0;opacity:0;" />`;
  if (!body) return pixel;
  if (/<\/body>/i.test(body)) return body.replace(/<\/body>/i, `${pixel}</body>`);
  return `${body}${pixel}`;
}

/** Record the send, then append the 1x1 image that rings the browser tone on open. */
async function attachEmailOpenPixel({ html, publicOrigin, run, contactIds, toEmails, subject }) {
  const origin = isPublicOrigin(publicOrigin);
  const currentHtml = String(html || "");
  if (!origin || typeof run !== "function") return { html: currentHtml, token: "" };
  const token = crypto.randomBytes(24).toString("hex");
  const trackingUrl = `${origin}/api/email/open/${encodeURIComponent(token)}`;
  await run(
    `INSERT INTO email_open_tracking (open_token, contact_ids, to_emails, subject)
     VALUES (?, ?, ?, ?)`,
    [
      token,
      String(contactIds || ""),
      String(toEmails || ""),
      String(subject || "").trim() || "(no subject)"
    ]
  );
  return { html: ensureTrackingPixelHtml(currentHtml, trackingUrl), token };
}

module.exports = {
  isPublicOrigin,
  ensureTrackingPixelHtml,
  attachEmailOpenPixel
};
