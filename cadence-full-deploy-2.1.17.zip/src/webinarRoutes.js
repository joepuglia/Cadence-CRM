"use strict";

function parseZoomJoinInput(raw) {
  const value = String(raw || "").trim();
  if (!value) return { joinUrl: "", meetingId: "", passcode: "" };
  try {
    if (/^https?:\/\//i.test(value)) {
      const url = new URL(value);
      const pathMatch = url.pathname.match(/\/(?:j|wc\/join)\/(\d+)/i);
      const meetingId = pathMatch ? pathMatch[1] : "";
      const passcode = String(url.searchParams.get("pwd") || "").trim();
      return { joinUrl: value, meetingId, passcode };
    }
  } catch {
    /* fall through */
  }
  const digits = value.replace(/\D/g, "");
  if (digits.length >= 9 && digits.length <= 12) {
    return {
      joinUrl: `https://zoom.us/j/${digits}`,
      meetingId: digits,
      passcode: ""
    };
  }
  return { joinUrl: value, meetingId: "", passcode: "" };
}

function webinarRowToJson(row) {
  if (!row) return null;
  const startsAt = Number(row.starts_at || 0);
  const durationMin = Math.max(15, Number(row.duration_minutes || 60));
  const endsAt = startsAt > 0 ? startsAt + durationMin * 60 : 0;
  const now = Math.floor(Date.now() / 1000);
  let liveState = "scheduled";
  if (String(row.status || "") === "ended") liveState = "ended";
  else if (String(row.status || "") === "draft") liveState = "draft";
  else if (startsAt > 0 && now >= startsAt - 900 && now <= endsAt + 900) liveState = "live";
  else if (startsAt > 0 && now > endsAt) liveState = "ended";

  return {
    id: Number(row.id),
    title: String(row.title || ""),
    description: String(row.description || ""),
    hostName: String(row.host_name || ""),
    startsAt,
    durationMinutes: durationMin,
    endsAt,
    zoomMeetingId: String(row.zoom_meeting_id || ""),
    zoomPasscode: String(row.zoom_passcode || ""),
    zoomJoinUrl: String(row.zoom_join_url || ""),
    zoomStartUrl: String(row.zoom_start_url || ""),
    status: String(row.status || "scheduled"),
    isPublished: Number(row.is_published) === 1,
    liveState,
    registrationCount: Number(row.registration_count || 0),
    createdAt: Number(row.created_at || 0),
    updatedAt: Number(row.updated_at || 0)
  };
}

function registerWebinarRoutes(app, deps) {
  const { run, all, get, withTenantContext, LEGACY_TENANT_ID } = deps;

  app.get("/api/webinars/public", async (req, res) => {
    try {
      const rows = await withTenantContext(LEGACY_TENANT_ID, async () => {
        return all(
          `SELECT * FROM webinars
           WHERE is_published = 1 AND status != 'draft'
           ORDER BY starts_at ASC, id ASC`
        );
      });
      const items = (rows || []).map(webinarRowToJson).filter(Boolean);
      return res.json({ ok: true, items });
    } catch (err) {
      console.error("Public webinars list error:", err);
      return res.status(500).json({ error: "Could not load webinars." });
    }
  });

  app.post("/api/webinars/register", async (req, res) => {
    try {
      const webinarId = Number(req.body?.webinarId || req.body?.webinar_id || 0);
      const fullName = String(req.body?.fullName || req.body?.name || "").trim();
      const email = String(req.body?.email || "")
        .trim()
        .toLowerCase();
      const phone = String(req.body?.phone || "").trim();
      if (!Number.isInteger(webinarId) || webinarId < 1) {
        return res.status(400).json({ error: "Invalid webinar." });
      }
      if (!fullName) return res.status(400).json({ error: "Name is required." });
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return res.status(400).json({ error: "Valid email is required." });
      }

      await withTenantContext(LEGACY_TENANT_ID, async () => {
        const webinar = await get(`SELECT id FROM webinars WHERE id = ? AND is_published = 1`, [webinarId]);
        if (!webinar) throw Object.assign(new Error("Webinar not found."), { status: 404 });
        await run(
          `INSERT INTO webinar_registrations (webinar_id, full_name, email, phone)
           VALUES (?, ?, ?, ?)`,
          [webinarId, fullName, email, phone]
        );
      });

      return res.status(201).json({ ok: true });
    } catch (err) {
      if (err.status === 404) return res.status(404).json({ error: err.message });
      console.error("Webinar registration error:", err);
      return res.status(500).json({ error: "Could not complete registration." });
    }
  });

  app.get("/api/webinars", async (req, res) => {
    try {
      const rows = await all(
        `SELECT w.*,
                (SELECT COUNT(*) FROM webinar_registrations r WHERE r.webinar_id = w.id) AS registration_count
         FROM webinars w
         ORDER BY w.starts_at DESC, w.id DESC`
      );
      return res.json({ ok: true, items: (rows || []).map(webinarRowToJson).filter(Boolean) });
    } catch (err) {
      console.error("Webinars list error:", err);
      return res.status(500).json({ error: "Could not load webinars." });
    }
  });

  app.post("/api/webinars", async (req, res) => {
    try {
      const title = String(req.body?.title || "").trim();
      if (!title) return res.status(400).json({ error: "Title is required." });

      const description = String(req.body?.description || "").trim();
      const hostName = String(req.body?.hostName || req.body?.host_name || "").trim();
      const startsAt = Math.floor(Number(req.body?.startsAt || req.body?.starts_at || 0));
      const durationMinutes = Math.max(15, Number(req.body?.durationMinutes || req.body?.duration_minutes || 60));
      const status = String(req.body?.status || "scheduled").trim() || "scheduled";
      const isPublished = req.body?.isPublished === true || req.body?.is_published === 1 || req.body?.is_published === "1" ? 1 : 0;

      const zoomJoinRaw = String(req.body?.zoomJoinUrl || req.body?.zoom_join_url || "").trim();
      const zoomStartUrl = String(req.body?.zoomStartUrl || req.body?.zoom_start_url || "").trim();
      const zoomPasscodeInput = String(req.body?.zoomPasscode || req.body?.zoom_passcode || "").trim();
      const parsed = parseZoomJoinInput(zoomJoinRaw);
      const zoomPasscode = zoomPasscodeInput || parsed.passcode;
      const zoomMeetingId = String(req.body?.zoomMeetingId || req.body?.zoom_meeting_id || parsed.meetingId || "").trim();
      const zoomJoinUrl = parsed.joinUrl || zoomJoinRaw;

      if (isPublished && !zoomJoinUrl) {
        return res.status(400).json({ error: "Zoom join link is required for published webinars." });
      }

      const now = Math.floor(Date.now() / 1000);
      const result = await run(
        `INSERT INTO webinars (
           title, description, host_name, starts_at, duration_minutes,
           zoom_meeting_id, zoom_passcode, zoom_join_url, zoom_start_url,
           status, is_published, created_at, updated_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          title,
          description,
          hostName,
          startsAt,
          durationMinutes,
          zoomMeetingId,
          zoomPasscode,
          zoomJoinUrl,
          zoomStartUrl,
          status,
          isPublished,
          now,
          now
        ]
      );

      const row = await get(`SELECT * FROM webinars WHERE id = ?`, [result.lastID]);
      return res.status(201).json({ ok: true, item: webinarRowToJson(row) });
    } catch (err) {
      console.error("Webinar create error:", err);
      return res.status(500).json({ error: "Could not save webinar." });
    }
  });

  app.put("/api/webinars/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid webinar id." });
      const existing = await get(`SELECT * FROM webinars WHERE id = ?`, [id]);
      if (!existing) return res.status(404).json({ error: "Webinar not found." });

      const title = String(req.body?.title ?? existing.title).trim();
      if (!title) return res.status(400).json({ error: "Title is required." });

      const description = String(req.body?.description ?? existing.description ?? "").trim();
      const hostName = String(req.body?.hostName ?? req.body?.host_name ?? existing.host_name ?? "").trim();
      const startsAt = Math.floor(Number(req.body?.startsAt ?? req.body?.starts_at ?? existing.starts_at ?? 0));
      const durationMinutes = Math.max(
        15,
        Number(req.body?.durationMinutes ?? req.body?.duration_minutes ?? existing.duration_minutes ?? 60)
      );
      const status = String(req.body?.status ?? existing.status ?? "scheduled").trim() || "scheduled";
      const isPublished =
        req.body?.isPublished === true || req.body?.is_published === 1 || req.body?.is_published === "1"
          ? 1
          : req.body?.isPublished === false || req.body?.is_published === 0 || req.body?.is_published === "0"
            ? 0
            : Number(existing.is_published) === 1
              ? 1
              : 0;

      const zoomJoinRaw = String(req.body?.zoomJoinUrl ?? req.body?.zoom_join_url ?? existing.zoom_join_url ?? "").trim();
      const zoomStartUrl = String(req.body?.zoomStartUrl ?? req.body?.zoom_start_url ?? existing.zoom_start_url ?? "").trim();
      const zoomPasscodeInput = String(req.body?.zoomPasscode ?? req.body?.zoom_passcode ?? existing.zoom_passcode ?? "").trim();
      const parsed = parseZoomJoinInput(zoomJoinRaw);
      const zoomPasscode = zoomPasscodeInput || parsed.passcode;
      const zoomMeetingId = String(
        req.body?.zoomMeetingId ?? req.body?.zoom_meeting_id ?? parsed.meetingId ?? existing.zoom_meeting_id ?? ""
      ).trim();
      const zoomJoinUrl = parsed.joinUrl || zoomJoinRaw;

      if (isPublished && !zoomJoinUrl) {
        return res.status(400).json({ error: "Zoom join link is required for published webinars." });
      }

      const now = Math.floor(Date.now() / 1000);
      await run(
        `UPDATE webinars SET
           title = ?, description = ?, host_name = ?, starts_at = ?, duration_minutes = ?,
           zoom_meeting_id = ?, zoom_passcode = ?, zoom_join_url = ?, zoom_start_url = ?,
           status = ?, is_published = ?, updated_at = ?
         WHERE id = ?`,
        [
          title,
          description,
          hostName,
          startsAt,
          durationMinutes,
          zoomMeetingId,
          zoomPasscode,
          zoomJoinUrl,
          zoomStartUrl,
          status,
          isPublished,
          now,
          id
        ]
      );

      const row = await get(`SELECT * FROM webinars WHERE id = ?`, [id]);
      return res.json({ ok: true, item: webinarRowToJson(row) });
    } catch (err) {
      console.error("Webinar update error:", err);
      return res.status(500).json({ error: "Could not update webinar." });
    }
  });

  app.delete("/api/webinars/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid webinar id." });
      await run(`DELETE FROM webinar_registrations WHERE webinar_id = ?`, [id]);
      await run(`DELETE FROM webinars WHERE id = ?`, [id]);
      return res.json({ ok: true });
    } catch (err) {
      console.error("Webinar delete error:", err);
      return res.status(500).json({ error: "Could not delete webinar." });
    }
  });

  app.get("/api/webinars/:id/registrations", async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid webinar id." });
      const rows = await all(
        `SELECT id, webinar_id, full_name, email, phone, created_at
         FROM webinar_registrations WHERE webinar_id = ? ORDER BY created_at DESC`,
        [id]
      );
      return res.json({ ok: true, items: rows || [] });
    } catch (err) {
      console.error("Webinar registrations error:", err);
      return res.status(500).json({ error: "Could not load registrations." });
    }
  });
}

module.exports = { registerWebinarRoutes, parseZoomJoinInput };
