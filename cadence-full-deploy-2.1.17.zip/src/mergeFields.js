/**
 * Server-side merge fields for emails/SMS (must stay aligned with public/email.js applyMergeFields).
 * Includes `phone` for campaign/drip templates that used the legacy placeholder helper.
 * `coverage_start_date` and `policy_renewal` are emitted as MM/DD/YYYY (month/date/year).
 */

function splitFirstLastName(fullName) {
  const name = String(fullName || "").trim();
  if (!name) return { first: "", last: "" };
  const parts = name.split(/\s+/).filter(Boolean);
  if (!parts.length) return { first: "", last: "" };
  return {
    first: parts[0] || "",
    last: parts.slice(1).join(" ")
  };
}

/**
 * `good_through` is computed dynamically: today + 7 days, formatted as
 * "Month Day, Year" (e.g. "May 18, 2026"). Used for quotes/offers that should
 * be honored for one week from the moment the email is generated.
 */
function computeGoodThroughDate(daysFromToday = 7, baseDate = new Date()) {
  const base = baseDate instanceof Date && !Number.isNaN(baseDate.getTime()) ? baseDate : new Date();
  const target = new Date(base.getFullYear(), base.getMonth(), base.getDate() + daysFromToday);
  try {
    return target.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  } catch {
    const pad = (n) => String(n).padStart(2, "0");
    return `${target.getFullYear()}-${pad(target.getMonth() + 1)}-${pad(target.getDate())}`;
  }
}

/** Date merge output: month/date/year (MM/DD/YYYY). */
function formatCoverageStartDateForMerge(raw) {
  const s = String(raw || "").trim();
  if (!s) return "";
  let m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (m) return `${m[2]}/${m[3]}/${m[1]}`;
  m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(s);
  if (m) {
    const mo = String(Number(m[1])).padStart(2, "0");
    const da = String(Number(m[2])).padStart(2, "0");
    return `${mo}/${da}/${m[3]}`;
  }
  return s;
}

/**
 * @param {Record<string, unknown>} data - contact row
 * @param {string} [fallbackEmail]
 */
function contactRowToMergeFields(data, fallbackEmail = "") {
  const row = data && typeof data === "object" ? data : {};
  const fullName = String(row.full_name || "").trim();
  const firstName = String(row.first_name || "").trim();
  const lastName = String(row.last_name || "").trim();
  const split = splitFirstLastName(fullName);
  return {
    full_name: fullName,
    first_name: firstName || split.first,
    last_name: lastName || split.last,
    age: String(row.age || "").trim(),
    email: String(row.email || "").trim() || fallbackEmail,
    phone: String(row.phone || "").trim(),
    state: String(row.state || "").trim(),
    date_of_contact: String(row.date_of_contact || "").trim(),
    quote: String(row.quote || "").trim(),
    app_id: String(row.app_id || "").trim(),
    policy_number: String(row.app_id || row.policy_number || "").trim(),
    coverage_start_date: formatCoverageStartDateForMerge(String(row.coverage_start_date || "").trim()),
    policy_renewal: formatCoverageStartDateForMerge(String(row.policy_renewal || row.policy_renewal_date || "").trim()),
    upon_approval: String(row.upon_approval || "").trim(),
    vcall: String(row.vcall || "").trim(),
    insurance_type: String(row.insurance_type || "").trim(),
    good_through: computeGoodThroughDate(7),
    agent_name: String(process.env.CRM_AGENT_NAME || "").trim(),
    agent_phone: String(process.env.CRM_AGENT_PHONE || "").trim()
  };
}

/** Map a key like " First Name " or "First-Name" to its canonical slug "first_name". */
function normalizeMergeKey(raw) {
  return String(raw || "")
    .toLowerCase()
    .replace(/[\s-]+/g, "_")
    .replace(/[^a-z0-9_]/g, "")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "");
}

/**
 * Reserved built-in slugs. The settings UI / API reject these so that a custom
 * merge field cannot shadow a real contact value at render time.
 */
const RESERVED_MERGE_FIELD_KEYS = new Set([
  "full_name",
  "first_name",
  "last_name",
  "age",
  "email",
  "phone",
  "state",
  "date_of_contact",
  "quote",
  "app_id",
  "policy_number",
  "coverage_start_date",
  "policy_renewal",
  "policy_renewal_date",
  "polcy_renewal",
  "upon_approval",
  "vcall",
  "insurance_type",
  "good_through",
  "agent_name",
  "agent_phone"
]);

/**
 * @param {string} raw
 * @param {ReturnType<typeof contactRowToMergeFields>} fields
 * @param {{ keepHtmlNbsp?: boolean, customFields?: Record<string,string> }} [options]
 */
/** Rich editors sometimes store `{` / `}` as HTML entities; normalize before token replace. */
function prepareTextForMergeFields(raw) {
  let s = String(raw || "")
    .replace(/&#123;/g, "{")
    .replace(/&#125;/g, "}")
    .replace(/&lcub;/gi, "{")
    .replace(/&rcub;/gi, "}");
  s = s.replace(/\{\{([\s\S]*?)\}\}/g, (m, inner) => {
    const slug = String(inner || "")
      .replace(/<[^>]*>/g, "")
      .replace(/&nbsp;/gi, " ")
      .trim();
    return slug ? `{{${slug}}}` : m;
  });
  return s;
}

function applyMergeFields(raw, fields, options = {}) {
  const s = prepareTextForMergeFields(raw);
  if (!s) return s;
  const keepHtmlNbsp = Boolean(options.keepHtmlNbsp);
  const merge = fields || {};
  const map = {
    full_name: String(merge.full_name || "").trim(),
    first_name: String(merge.first_name || "").trim(),
    last_name: String(merge.last_name || "").trim(),
    age: String(merge.age || "").trim(),
    email: String(merge.email || "").trim(),
    phone: String(merge.phone || "").trim(),
    state: String(merge.state || "").trim(),
    date_of_contact: String(merge.date_of_contact || "").trim(),
    quote: String(merge.quote || "").trim(),
    app_id: String(merge.app_id || merge.policy_number || "").trim(),
    policy_number: String(merge.policy_number || merge.app_id || "").trim(),
    coverage_start_date: formatCoverageStartDateForMerge(String(merge.coverage_start_date || "").trim()),
    policy_renewal: formatCoverageStartDateForMerge(
      String(merge.policy_renewal || merge.policy_renewal_date || "").trim()
    ),
    policy_renewal_date: formatCoverageStartDateForMerge(
      String(merge.policy_renewal || merge.policy_renewal_date || "").trim()
    ),
    polcy_renewal: formatCoverageStartDateForMerge(
      String(merge.policy_renewal || merge.policy_renewal_date || merge.polcy_renewal || "").trim()
    ),
    upon_approval: String(merge.upon_approval || "").trim(),
    vcall: String(merge.vcall || "").trim(),
    insurance_type: String(merge.insurance_type || "").trim(),
    // Always recompute against "now" so a drip step rendered tomorrow has a fresh date,
    // but honor an explicit override passed via the fields object.
    good_through: String(merge.good_through || "").trim() || computeGoodThroughDate(7),
    unsubscribe_url: String(merge.unsubscribe_url || "").trim()
  };
  const replaceKey = (key) => {
    const normalized = String(key || "")
      .toLowerCase()
      .replace(/\s+/g, "")
      .replace("dateof_contact", "date_of_contact")
      .replace("goodthrough", "good_through")
      .replace("policynumber", "policy_number")
      .replace("policyrenewaldate", "policy_renewal")
      .replace("policyrenewal", "policy_renewal")
      .replace("polcyrenewal", "policy_renewal")
      .replace("insurancetype", "insurance_type")
      .replace("appid", "app_id");
    return map[normalized] != null ? map[normalized] : "";
  };
  // Same field list as public/email.js, plus `phone` for legacy drip step templates.
  let merged = s.replace(
    /\(\s*(full_name|first_name|last_name|age|email|phone|state|date_of_contact|date_of\s*_\s*contact|quote|app_id|policy_number|policy\s*_\s*number|coverage_start_date|policy_renewal|policy_renewal_date|policy\s*_\s*renewal|polcy_renewal|upon_approval|vcall|insurance_type|insurance\s*_\s*type|good_through|good\s*_\s*through|unsubscribe_url|unsubscribe\s*_\s*url)\s*\)/gi,
    (m, key) => replaceKey(key)
  );
  merged = merged.replace(
    /\{\{\s*(full_name|first_name|last_name|age|email|phone|state|date_of_contact|date_of\s*_\s*contact|quote|app_id|policy_number|policy\s*_\s*number|coverage_start_date|policy_renewal|policy_renewal_date|policy\s*_\s*renewal|polcy_renewal|upon_approval|vcall|insurance_type|insurance\s*_\s*type|good_through|good\s*_\s*through|unsubscribe_url|unsubscribe\s*_\s*url)\s*\}\}/gi,
    (m, key) => replaceKey(key)
  );

  /**
   * Custom merge fields defined by the user from Settings. We normalize each
   * defined key to a slug, then sweep over any remaining `{{...}}` / `(...)`
   * placeholders and substitute when the slug matches. Reserved built-ins
   * already consumed above are skipped so a typo'd custom field can't shadow
   * a real contact value.
   */
  const customSource = options.customFields && typeof options.customFields === "object" ? options.customFields : null;
  if (customSource) {
    const customMap = {};
    for (const rawKey of Object.keys(customSource)) {
      const slug = normalizeMergeKey(rawKey);
      if (!slug || RESERVED_MERGE_FIELD_KEYS.has(slug) || isPolicyRenewalMergeSlug(slug)) continue;
      customMap[slug] = String(customSource[rawKey] == null ? "" : customSource[rawKey]);
    }
    if (Object.keys(customMap).length > 0) {
      const customReplace = (key) => {
        const slug = normalizeMergeKey(key);
        return Object.prototype.hasOwnProperty.call(customMap, slug) ? customMap[slug] : null;
      };
      merged = merged.replace(/\{\{\s*([a-zA-Z][a-zA-Z0-9 _\-]*)\s*\}\}/g, (m, key) => {
        const v = customReplace(key);
        return v == null ? m : v;
      });
      merged = merged.replace(/\(\s*([a-zA-Z][a-zA-Z0-9 _\-]*)\s*\)/g, (m, key) => {
        const v = customReplace(key);
        return v == null ? m : v;
      });
    }
  }

  merged = merged.replace(/&amp;nbsp;/gi, "&nbsp;");
  if (!keepHtmlNbsp) {
    merged = merged
      .replace(/&nbsp;/gi, " ")
      .replace(/\u00a0/g, " ")
      .replace(/[ \t]{2,}/g, " ")
      .replace(/ +([:;,])/g, "$1")
      .trim();
  }
  return merged;
}

/** @deprecated use applyMergeFields with contactRowToMergeFields */
function applyPlaceholders(template, contact) {
  const f = contactRowToMergeFields(contact, String(contact?.email || "").trim());
  return applyMergeFields(String(template || ""), f, { keepHtmlNbsp: false });
}

function normalizeMergeFieldScope(raw) {
  const s = String(raw || "")
    .trim()
    .toLowerCase()
    .replace(/[\s-]+/g, "_");
  return s === "contact" || s === "per_contact" || s === "percontact" ? "contact" : "shared";
}

function parseContactCustomFieldValues(raw) {
  if (!raw) return {};
  if (typeof raw === "object" && !Array.isArray(raw)) {
    return sanitizeCustomFieldValueMap(raw);
  }
  const text = String(raw).trim();
  if (!text) return {};
  try {
    return sanitizeCustomFieldValueMap(JSON.parse(text));
  } catch {
    return {};
  }
}

/** True for policy_renewal and common typos such as polcy_renewal. */
function isPolicyRenewalMergeSlug(raw) {
  const compact = normalizeMergeKey(raw).replace(/_/g, "");
  return /^poli?cyrenewal(date)?$/.test(compact);
}

function sanitizeCustomFieldValueMap(obj) {
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return {};
  const out = {};
  for (const [key, value] of Object.entries(obj)) {
    const slug = normalizeMergeKey(key);
    if (!slug || RESERVED_MERGE_FIELD_KEYS.has(slug) || isPolicyRenewalMergeSlug(slug)) continue;
    out[slug] = String(value == null ? "" : value);
  }
  return out;
}

function overlayContactCustomFields(shared, contactRow) {
  const base = shared && typeof shared === "object" && !Array.isArray(shared) ? { ...shared } : {};
  const extra = parseContactCustomFieldValues(contactRow?.custom_fields);
  return { ...base, ...extra };
}

module.exports = {
  contactRowToMergeFields,
  applyMergeFields,
  applyPlaceholders,
  prepareTextForMergeFields,
  computeGoodThroughDate,
  formatCoverageStartDateForMerge,
  normalizeMergeKey,
  normalizeMergeFieldScope,
  parseContactCustomFieldValues,
  overlayContactCustomFields,
  isPolicyRenewalMergeSlug,
  RESERVED_MERGE_FIELD_KEYS
};
