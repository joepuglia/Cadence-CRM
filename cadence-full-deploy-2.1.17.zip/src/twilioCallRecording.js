"use strict";

const {
  fetchCompletedRecordingsForCallSid,
  fetchCompletedRecordingsForPhone
} = require("./twilioService");

const CONFIG_KEY = "callRecordingDefault";

function parseRecordCallFlag(raw, defaultEnabled) {
  if (raw === true || raw === 1 || raw === "1") return true;
  if (raw === false || raw === 0 || raw === "0") return false;
  const s = String(raw ?? "")
    .trim()
    .toLowerCase();
  if (s === "true" || s === "yes" || s === "on") return true;
  if (s === "false" || s === "no" || s === "off") return false;
  return !!defaultEnabled;
}

function isVoiceWebhookRecordEnabled(body) {
  const b = body && typeof body === "object" ? body : {};
  const raw = b.recordCall ?? b.RecordCall ?? b.record ?? b.Record;
  return raw === true || raw === 1 || raw === "1" || String(raw).toLowerCase() === "true";
}

/** Headset voice webhook: explicit recordCall param, else Settings → default record. */
async function resolveVoiceWebhookRecordEnabled(body, get) {
  const b = body && typeof body === "object" ? body : {};
  const raw = b.recordCall ?? b.RecordCall ?? b.record ?? b.Record;
  if (raw === true || raw === 1 || raw === "1") return true;
  if (raw === false || raw === 0 || raw === "0") return false;
  const s = String(raw ?? "")
    .trim()
    .toLowerCase();
  if (s === "true" || s === "yes" || s === "on") return true;
  if (s === "false" || s === "no" || s === "off") return false;
  try {
    return await getCallRecordingDefault(get);
  } catch {
    return false;
  }
}

async function resolveContactIdByPhone(get, phone) {
  const p = String(phone || "").trim();
  if (!p) return null;
  const row = await get(
    `SELECT id FROM contacts WHERE phone = ? OR secondary_phone = ? ORDER BY id DESC LIMIT 1`,
    [p, p]
  );
  const id = Number(row?.id);
  return Number.isInteger(id) && id > 0 ? id : null;
}

async function getCallRecordingDefault(get) {
  const row = await get(`SELECT value FROM twilio_runtime_config WHERE key = ?`, [CONFIG_KEY]);
  if (!row || row.value == null || String(row.value).trim() === "") return true;
  const v = String(row.value)
    .trim()
    .toLowerCase();
  return v === "1" || v === "true" || v === "yes";
}

async function setCallRecordingDefault(run, enabled) {
  await run(`INSERT OR REPLACE INTO twilio_runtime_config (key, value) VALUES (?, ?)`, [
    CONFIG_KEY,
    enabled ? "1" : "0"
  ]);
}

/** Webhooks and API callbacks always live at the site root — never under /crm or similar paths. */
function getWebhookPublicOrigin(publicOrigin) {
  const raw = String(publicOrigin || "").trim().replace(/\/$/, "");
  if (!raw) return "";
  try {
    const parsed = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
    return `${parsed.protocol}//${parsed.host}`;
  } catch {
    return raw;
  }
}

function crmPublicUrlHasPathSuffix(publicOrigin) {
  const raw = String(publicOrigin || "").trim().replace(/\/$/, "");
  if (!raw) return false;
  try {
    const parsed = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
    const path = String(parsed.pathname || "/").replace(/\/$/, "") || "/";
    return path !== "" && path !== "/";
  } catch {
    return false;
  }
}

function buildRecordingStatusCallbackUrl(publicOrigin, { contactId, callSid, phone } = {}) {
  const base = getWebhookPublicOrigin(publicOrigin);
  if (!base || !/^https?:\/\//i.test(base)) return "";
  const params = new URLSearchParams();
  const cid = Number(contactId);
  if (Number.isInteger(cid) && cid > 0) params.set("contactId", String(cid));
  const sid = String(callSid || "").trim();
  if (sid) params.set("callSid", sid);
  const ph = String(phone || "").trim();
  if (ph) params.set("phone", ph);
  const q = params.toString();
  return `${base}/webhooks/twilio/recording-status${q ? `?${q}` : ""}`;
}

function formatRecordingDuration(seconds) {
  const n = Math.max(0, Math.floor(Number(seconds || 0)));
  if (!n) return "";
  const m = Math.floor(n / 60);
  const s = n % 60;
  return m > 0 ? `${m}:${String(s).padStart(2, "0")}` : `${s}s`;
}

function buildRecordingPlayPath(recordingSid) {
  const sid = String(recordingSid || "").trim();
  if (!sid) return "";
  return `/api/twilio/recordings/${encodeURIComponent(sid)}/audio`;
}

function extractRecordingSid(value) {
  const raw = String(value || "").trim();
  if (!raw) return "";
  const direct = raw.match(/\b(RE[a-f0-9]{32})\b/i);
  return direct ? direct[1] : "";
}

function normalizeRecordingPayload(payload) {
  const p = payload && typeof payload === "object" ? payload : {};
  const recordingSid =
    extractRecordingSid(p.recordingSid) ||
    extractRecordingSid(p.playUrl) ||
    extractRecordingSid(p.url) ||
    extractRecordingSid(p.recordingUrl);
  const playUrl = String(p.playUrl || buildRecordingPlayPath(recordingSid) || "").trim();
  return {
    ...p,
    recordingSid,
    playUrl,
    url: playUrl || String(p.url || p.recordingUrl || "").trim()
  };
}

const CALL_RECORDING_PENDING_DETAIL = "Started call (recording on)";

function buildCallWithRecordingDetail({
  status = "completed",
  recordingUrl,
  playUrl,
  durationSeconds,
  recordingSid
} = {}) {
  const play = String(playUrl || buildRecordingPlayPath(recordingSid) || "").trim();
  const url = play || String(recordingUrl || "").trim();
  return `CALL_WITH_RECORDING:${JSON.stringify({
    status: status === "pending" ? "pending" : "completed",
    url,
    playUrl: play,
    recordingSid: String(recordingSid || "").trim(),
    durationSeconds: Math.max(0, Math.floor(Number(durationSeconds || 0)))
  })}`;
}

function buildCallRecordingActivityDetail({ recordingUrl, playUrl, durationSeconds, recordingSid }) {
  return buildCallWithRecordingDetail({
    status: "completed",
    recordingUrl,
    playUrl,
    durationSeconds,
    recordingSid
  });
}

function formatCallActivityDetailForDisplay(detail) {
  const raw = String(detail || "").trim();
  const parsed = parseCallWithRecordingDetail(raw);
  if (parsed) {
    if (parsed.status === "pending") return "Recorded call (processing audio…)";
    const dur = formatRecordingDuration(parsed.durationSeconds);
    return dur ? `Recorded call (${dur})` : "Recorded call";
  }
  if (raw === "Started call") return "Call started";
  if (/^started call campaign call$/i.test(raw)) return "Campaign call started";
  return raw || "Call logged";
}

function parseCallWithRecordingDetail(detail) {
  const raw = String(detail || "").trim();
  if (raw === CALL_RECORDING_PENDING_DETAIL) {
    return { status: "pending" };
  }
  if (raw.startsWith("CALL_WITH_RECORDING:")) {
    try {
      return normalizeRecordingPayload(JSON.parse(raw.slice("CALL_WITH_RECORDING:".length)));
    } catch {
      return null;
    }
  }
  if (raw.startsWith("CALL_RECORDING:")) {
    try {
      const payload = JSON.parse(raw.slice("CALL_RECORDING:".length));
      return normalizeRecordingPayload({ ...payload, status: "completed" });
    } catch {
      return null;
    }
  }
  return null;
}

async function findPendingRecordingActivity(all, contactId) {
  const cid = Number(contactId);
  if (!Number.isInteger(cid) || cid < 1) return null;
  const rows = await all(
    `SELECT id, detail FROM contact_activity
     WHERE contact_id = ? AND activity_type = 'call'
       AND (detail = ? OR detail LIKE 'CALL_WITH_RECORDING:%')
     ORDER BY id DESC
     LIMIT 8`,
    [cid, CALL_RECORDING_PENDING_DETAIL]
  );
  for (const row of rows || []) {
    const parsed = parseCallWithRecordingDetail(row.detail);
    if (parsed && parsed.status === "pending") return row;
  }
  return null;
}

async function trackCallRecordingPending(run, { callSid, contactId, phone }) {
  const sid = String(callSid || "").trim();
  if (!sid) return;
  const now = Math.floor(Date.now() / 1000);
  const cid = Number(contactId);
  const contactIdVal = Number.isInteger(cid) && cid > 0 ? cid : null;
  await run(
    `INSERT INTO call_recordings (call_sid, contact_id, phone, status, created_at, updated_at)
     VALUES (?, ?, ?, 'pending', ?, ?)
     ON CONFLICT(call_sid) DO UPDATE SET
       contact_id = COALESCE(excluded.contact_id, call_recordings.contact_id),
       phone = COALESCE(excluded.phone, call_recordings.phone),
       updated_at = excluded.updated_at`,
    [sid, contactIdVal, String(phone || "").trim(), now, now]
  );
}

async function resolveRecordingRow(get, { callSid, contactId }) {
  const sid = String(callSid || "").trim();
  if (sid) {
    const bySid = await get(`SELECT * FROM call_recordings WHERE call_sid = ?`, [sid]);
    if (bySid) return bySid;
  }
  const cid = Number(contactId);
  if (Number.isInteger(cid) && cid > 0) {
    return get(
      `SELECT * FROM call_recordings
       WHERE contact_id = ?
       ORDER BY
         CASE WHEN status = 'pending' THEN 0 ELSE 1 END,
         updated_at DESC,
         id DESC
       LIMIT 1`,
      [cid]
    );
  }
  return null;
}

async function historyHasRecordingUrl(get, contactId, recordingUrl) {
  const url = String(recordingUrl || "").trim();
  if (!url) return true;
  const cid = Number(contactId);
  if (!Number.isInteger(cid) || cid < 1) return false;
  const row = await get(
    `SELECT id FROM contact_activity
     WHERE contact_id = ? AND activity_type = 'call' AND detail LIKE ? LIMIT 1`,
    [cid, `%${url.replace(/%/g, "\\%")}%`]
  );
  return Boolean(row);
}

async function ensureRecordingHistoryEntry(deps, { contactId, recordingUrl, playUrl, durationSeconds, recordingSid }) {
  const { get, run, all, logContactActivity } = deps;
  const cid = Number(contactId);
  const url = String(recordingUrl || "").trim();
  const play = String(playUrl || buildRecordingPlayPath(recordingSid) || "").trim();
  const recSid = String(recordingSid || "").trim();
  const historyUrl = play || url;
  if (!Number.isInteger(cid) || cid < 1 || !historyUrl) return false;
  if (recSid) {
    const bySid = await get(
      `SELECT id FROM contact_activity
       WHERE contact_id = ? AND activity_type = 'call' AND detail LIKE ? LIMIT 1`,
      [cid, `%${recSid.replace(/%/g, "\\%")}%`]
    );
    if (bySid) return false;
  }
  if (await historyHasRecordingUrl(get, cid, historyUrl)) return false;
  if (url && url !== historyUrl && (await historyHasRecordingUrl(get, cid, url))) return false;

  const completedDetail = buildCallWithRecordingDetail({
    status: "completed",
    recordingUrl: url,
    playUrl: play,
    durationSeconds,
    recordingSid: recSid
  });

  const pending = await findPendingRecordingActivity(all, cid);
  if (pending) {
    await run(`UPDATE contact_activity SET detail = ? WHERE id = ?`, [completedDetail, pending.id]);
    if (recSid) {
      const dupes = await all(
        `SELECT id FROM contact_activity
         WHERE contact_id = ? AND activity_type = 'call' AND id != ?
           AND detail LIKE 'CALL_RECORDING:%' AND detail LIKE ?`,
        [cid, pending.id, `%${recSid.replace(/%/g, "\\%")}%`]
      );
      for (const dupe of dupes || []) {
        await run(`DELETE FROM contact_activity WHERE id = ?`, [dupe.id]);
      }
    }
    return true;
  }

  await logContactActivity(cid, "call", completedDetail);
  return true;
}

async function upsertCompletedRecording(deps, { callSid, contactId, phone, recordingSid, recordingUrl, durationSeconds }) {
  const { run, get } = deps;
  const recSid = String(recordingSid || "").trim();
  const sid = String(callSid || "").trim();
  const cid = Number(contactId);
  let contactIdVal = Number.isInteger(cid) && cid > 0 ? cid : null;
  if (!contactIdVal) {
    contactIdVal = await resolveContactIdByPhone(get, phone);
  }
  const playUrl = buildRecordingPlayPath(recSid);
  const now = Math.floor(Date.now() / 1000);

  let row = null;
  if (recSid) {
    row = await get(`SELECT * FROM call_recordings WHERE recording_sid = ?`, [recSid]);
  }
  if (!row && sid) {
    row = await get(`SELECT * FROM call_recordings WHERE call_sid = ?`, [sid]);
  }
  if (!row && contactIdVal) {
    row = await resolveRecordingRow(get, { callSid: sid, contactId: contactIdVal });
  }

  if (row) {
    await run(
      `UPDATE call_recordings SET
         call_sid = ?,
         contact_id = COALESCE(?, contact_id),
         phone = COALESCE(?, phone),
         recording_sid = COALESCE(?, recording_sid),
         recording_url = COALESCE(?, recording_url),
         duration_seconds = CASE WHEN ? > 0 THEN ? ELSE duration_seconds END,
         status = 'completed',
         updated_at = ?
       WHERE id = ?`,
      [
        sid || row.call_sid,
        contactIdVal,
        String(phone || "").trim() || null,
        recSid || null,
        String(recordingUrl || "").trim() || null,
        durationSeconds,
        durationSeconds,
        now,
        row.id
      ]
    );
  } else if (sid || recSid) {
    await run(
      `INSERT INTO call_recordings (
         call_sid, contact_id, phone, recording_sid, recording_url, duration_seconds, status, created_at, updated_at
       ) VALUES (?, ?, ?, ?, ?, ?, 'completed', ?, ?)`,
      [
        sid || recSid,
        contactIdVal,
        String(phone || "").trim(),
        recSid,
        String(recordingUrl || "").trim(),
        durationSeconds,
        now,
        now
      ]
    );
  }

  const effectiveContactId = contactIdVal || Number(row?.contact_id) || null;
  if (effectiveContactId) {
    await ensureRecordingHistoryEntry(deps, {
      contactId: effectiveContactId,
      recordingUrl: String(recordingUrl || "").trim(),
      playUrl,
      durationSeconds,
      recordingSid: recSid
    });
  }
  return Boolean(recSid || sid);
}

async function syncCallRecordingsFromTwilio(deps, { contactId, callSid, phone } = {}) {
  const { get, all } = deps;
  const cid = Number(contactId);
  const sids = new Set();
  const primary = String(callSid || "").trim();
  if (primary) sids.add(primary);

  let phoneToSearch = String(phone || "").trim();
  if (Number.isInteger(cid) && cid > 0) {
    const rows = await all(
      `SELECT call_sid, phone FROM call_recordings
       WHERE contact_id = ?
       ORDER BY updated_at DESC
       LIMIT 12`,
      [cid]
    );
    for (const row of rows || []) {
      const sid = String(row.call_sid || "").trim();
      if (sid) sids.add(sid);
      if (!phoneToSearch) phoneToSearch = String(row.phone || "").trim();
    }
    if (!phoneToSearch) {
      const contact = await get(`SELECT phone, secondary_phone FROM contacts WHERE id = ?`, [cid]);
      phoneToSearch = String(contact?.phone || contact?.secondary_phone || "").trim();
    }
  }

  const recBySid = new Map();
  for (const sid of sids) {
    try {
      const recs = await fetchCompletedRecordingsForCallSid(sid);
      for (const rec of recs) recBySid.set(rec.recordingSid, rec);
    } catch (err) {
      console.error("syncCallRecordingsFromTwilio fetch:", err.message || err);
    }
  }

  if (phoneToSearch) {
    try {
      const phoneRecs = await fetchCompletedRecordingsForPhone(phoneToSearch);
      for (const rec of phoneRecs) recBySid.set(rec.recordingSid, rec);
    } catch (err) {
      console.error("syncCallRecordingsFromTwilio phone fetch:", err.message || err);
    }
  }

  let imported = 0;
  for (const rec of recBySid.values()) {
    const stored = await upsertCompletedRecording(deps, {
      callSid: rec.callSid,
      contactId: cid,
      phone: phoneToSearch || phone,
      recordingSid: rec.recordingSid,
      recordingUrl: rec.recordingUrl,
      durationSeconds: rec.durationSeconds
    });
    if (stored) imported += 1;
  }
  return { imported, scanned: recBySid.size };
}

async function handleTwilioRecordingStatusWebhook(deps, req, res) {
  const { run, get, all, logContactActivity } = deps;
  try {
    const body = req.body && typeof req.body === "object" ? req.body : {};
    const callSid = String(body.CallSid || req.query?.callSid || "").trim();
    const recordingSid = String(body.RecordingSid || "").trim();
    const recordingUrl = String(body.RecordingUrl || "").trim();
    const recordingStatus = String(body.RecordingStatus || body.Status || "").trim().toLowerCase();
    const durationSeconds = Math.max(0, Math.floor(Number(body.RecordingDuration || 0)));
    const queryContactId = Number(req.query?.contactId || 0);
    const queryPhone = String(req.query?.phone || "").trim();

    if (!callSid && !recordingUrl) {
      return res.status(200).type("text/plain").send("OK");
    }

    const now = Math.floor(Date.now() / 1000);
    let row = await resolveRecordingRow(get, { callSid, contactId: queryContactId });

    if (!row && callSid && (recordingStatus === "completed" || recordingUrl)) {
      const cid =
        Number.isInteger(queryContactId) && queryContactId > 0 ? queryContactId : null;
      await run(
        `INSERT INTO call_recordings (call_sid, contact_id, phone, status, created_at, updated_at)
         VALUES (?, ?, '', 'pending', ?, ?)`,
        [callSid, cid, now, now]
      );
      row = await get(`SELECT * FROM call_recordings WHERE call_sid = ?`, [callSid]);
    }

    if (row) {
      const wasCompleted = String(row.status || "").toLowerCase() === "completed";
      let contactId =
        Number.isInteger(queryContactId) && queryContactId > 0
          ? queryContactId
          : Number(row.contact_id) || null;
      if (!contactId && queryPhone) {
        contactId = await resolveContactIdByPhone(get, queryPhone);
      }
      const storeSid = callSid || row.call_sid;
      await run(
        `UPDATE call_recordings SET
           call_sid = ?,
           contact_id = COALESCE(?, contact_id),
           recording_sid = COALESCE(?, recording_sid),
           recording_url = COALESCE(?, recording_url),
           duration_seconds = CASE WHEN ? > 0 THEN ? ELSE duration_seconds END,
           status = ?,
           updated_at = ?
         WHERE id = ?`,
        [
          storeSid,
          contactId,
          recordingSid || null,
          recordingUrl || null,
          durationSeconds,
          durationSeconds,
          recordingStatus || "completed",
          now,
          row.id
        ]
      );

      if (recordingStatus === "completed" && recordingUrl) {
        console.info(
          `Twilio recording completed: RE=${recordingSid || "?"} CA=${storeSid || callSid} contact=${contactId || "none"}`
        );
        if (contactId) {
          await ensureRecordingHistoryEntry(deps, {
            contactId,
            recordingUrl,
            durationSeconds,
            recordingSid
          });
        } else if (!wasCompleted) {
          const matches = await all(
            `SELECT id FROM contacts WHERE phone = ? OR secondary_phone = ? LIMIT 5`,
            [String(row.phone || "").trim(), String(row.phone || "").trim()]
          );
          for (const c of matches || []) {
            await ensureRecordingHistoryEntry(deps, {
              contactId: c.id,
              recordingUrl,
              durationSeconds,
              recordingSid
            });
          }
        }
      }
    } else if (recordingStatus === "completed" && recordingUrl && queryContactId > 0) {
      await run(
        `INSERT INTO call_recordings (
           call_sid, contact_id, phone, recording_sid, recording_url, duration_seconds, status, created_at, updated_at
         ) VALUES (?, ?, '', ?, ?, ?, 'completed', ?, ?)`,
        [callSid || recordingSid, queryContactId, recordingSid, recordingUrl, durationSeconds, now, now]
      );
      await ensureRecordingHistoryEntry(deps, {
        contactId: queryContactId,
        recordingUrl,
        durationSeconds,
        recordingSid
      });
    }

    return res.status(200).type("text/plain").send("OK");
  } catch (err) {
    console.error("Twilio recording status webhook error:", err);
    return res.status(200).type("text/plain").send("OK");
  }
}

async function listContactCallRecordings(deps, contactId, options = {}) {
  const { get, all, logContactActivity } = deps;
  const cid = Number(contactId);
  if (!Number.isInteger(cid) || cid < 1) return [];

  if (options.sync !== false) {
    try {
      await syncCallRecordingsFromTwilio(deps, { contactId: cid });
    } catch (err) {
      console.error("listContactCallRecordings sync:", err.message || err);
    }
  }

  const rows = await all(
    `SELECT id, call_sid, recording_sid, recording_url, duration_seconds, status, created_at, updated_at
     FROM call_recordings
     WHERE contact_id = ?
     ORDER BY updated_at DESC, id DESC`,
    [cid]
  );
  const historyRows = await all(
    `SELECT id, detail, created_at
     FROM contact_activity
     WHERE contact_id = ?
       AND activity_type = 'call'
       AND (detail = ? OR detail LIKE 'CALL_WITH_RECORDING:%' OR detail LIKE 'CALL_RECORDING:%')
     ORDER BY id DESC
     LIMIT 50`,
    [cid, CALL_RECORDING_PENDING_DETAIL]
  );

  for (const row of rows || []) {
    const url = String(row.recording_url || "").trim();
    if (String(row.status || "").toLowerCase() !== "completed" || !url) continue;
    await ensureRecordingHistoryEntry(deps, {
      contactId: cid,
      recordingUrl: url,
      durationSeconds: row.duration_seconds,
      recordingSid: row.recording_sid
    });
  }

  const out = (rows || []).map((row) => {
    const recordingSid = String(row.recording_sid || "").trim();
    const playUrl = buildRecordingPlayPath(recordingSid);
    return {
      id: Number(row.id),
      callSid: String(row.call_sid || ""),
      recordingSid,
      recordingUrl: String(row.recording_url || ""),
      playUrl,
      durationSeconds: Number(row.duration_seconds || 0),
      status: String(row.status || ""),
      createdAt: row.created_at,
      updatedAt: row.updated_at
    };
  });
  const seen = new Set(
    out.map((item) => String(item.recordingSid || item.playUrl || item.recordingUrl || item.callSid || "")).filter(Boolean)
  );
  for (const history of historyRows || []) {
    const payload = parseCallWithRecordingDetail(history.detail);
    if (!payload) continue;
    const recordingSid = String(payload.recordingSid || "").trim();
    const playUrl = String(payload.playUrl || buildRecordingPlayPath(recordingSid) || "").trim();
    const recordingUrl = String(payload.recordingUrl || payload.url || "").trim();
    const key = String(recordingSid || playUrl || recordingUrl || `history-${history.id}`);
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({
      id: Number(history.id),
      callSid: "",
      recordingSid,
      recordingUrl,
      playUrl,
      durationSeconds: Number(payload.durationSeconds || 0),
      status: String(payload.status || "completed"),
      createdAt: history.created_at,
      updatedAt: history.created_at,
      source: "history"
    });
  }
  return out;
}

module.exports = {
  CONFIG_KEY,
  parseRecordCallFlag,
  isVoiceWebhookRecordEnabled,
  resolveVoiceWebhookRecordEnabled,
  resolveContactIdByPhone,
  getCallRecordingDefault,
  setCallRecordingDefault,
  buildRecordingStatusCallbackUrl,
  getWebhookPublicOrigin,
  crmPublicUrlHasPathSuffix,
  formatRecordingDuration,
  buildCallRecordingActivityDetail,
  buildCallWithRecordingDetail,
  formatCallActivityDetailForDisplay,
  parseCallWithRecordingDetail,
  trackCallRecordingPending,
  resolveRecordingRow,
  ensureRecordingHistoryEntry,
  handleTwilioRecordingStatusWebhook,
  listContactCallRecordings,
  syncCallRecordingsFromTwilio,
  buildRecordingPlayPath
};
