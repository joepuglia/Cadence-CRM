let processing = false;

function nowUnix() {
  return Math.floor(Date.now() / 1000);
}

async function publishSocialPostRecord({
  postId,
  run,
  get,
  all,
  postSocialTargetViaWebhook,
  buildMediaUrl,
  resolveSocialPostMediaUrl
}) {
  const row = await get(
    `SELECT id, content, media_asset_id, video_id, targets_json FROM social_posts WHERE id = ? AND publish_status = 'scheduled'`,
    [postId]
  );
  if (!row) return { ok: false, reason: "not_found" };

  let targets = [];
  try {
    const parsed = JSON.parse(String(row.targets_json || "[]"));
    targets = Array.isArray(parsed) ? parsed.map((t) => String(t || "").trim().toLowerCase()).filter(Boolean) : [];
  } catch {
    targets = [];
  }
  if (!targets.length) {
    await run(`UPDATE social_posts SET publish_status = 'published', targets_json = '[]' WHERE id = ?`, [postId]);
    return { ok: false, reason: "no_targets" };
  }

  let mediaRow = null;
  let videoRow = null;
  const mediaId = Number(row.media_asset_id || 0);
  const videoId = Number(row.video_id || 0);
  if (Number.isInteger(mediaId) && mediaId > 0) {
    mediaRow = await get(`SELECT id, file_name, storage_path FROM social_media_assets WHERE id = ?`, [mediaId]);
  }
  if (Number.isInteger(videoId) && videoId > 0) {
    videoRow = await get(`SELECT id, title, source_type, video_url FROM videos WHERE id = ?`, [videoId]);
  }
  const mediaUrl = resolveSocialPostMediaUrl
    ? resolveSocialPostMediaUrl({ mediaRow, videoRow })
    : mediaRow && buildMediaUrl
      ? buildMediaUrl(mediaRow.id)
      : "";
  const message = String(row.content || "").trim();
  const delivery = [];

  for (const target of targets) {
    const result = await postSocialTargetViaWebhook({ target, message, mediaUrl });
    await run(
      `INSERT INTO social_post_targets (post_id, target, status, response_text, posted_at) VALUES (?, ?, ?, ?, ?)`,
      [postId, target, result.status, result.responseText || "", result.status === "sent" ? nowUnix() : null]
    );
    delivery.push({ target, status: result.status, detail: result.responseText || "" });
  }

  await run(`UPDATE social_posts SET publish_status = 'published', targets_json = '[]' WHERE id = ?`, [postId]);
  return { ok: true, delivery };
}

async function processDueSocialPosts(deps) {
  if (processing) return;
  processing = true;
  const { run, all, get, postSocialTargetViaWebhook, buildMediaUrl, resolveSocialPostMediaUrl } = deps;
  try {
    const due = await all(
      `SELECT id FROM social_posts
       WHERE publish_status = 'scheduled'
         AND scheduled_at IS NOT NULL
         AND scheduled_at <= ?
       ORDER BY scheduled_at ASC, id ASC
       LIMIT 20`,
      [nowUnix()]
    );
    for (const row of due || []) {
      const postId = Number(row.id);
      if (!Number.isInteger(postId) || postId < 1) continue;
      try {
        await publishSocialPostRecord({
          postId,
          run,
          get,
          all,
          postSocialTargetViaWebhook,
          buildMediaUrl,
          resolveSocialPostMediaUrl
        });
      } catch (err) {
        console.error(`Social scheduler failed for post #${postId}:`, err);
      }
    }
  } finally {
    processing = false;
  }
}

function startSocialScheduler(deps) {
  const hosted = String(process.env.NODE_ENV || "").toLowerCase() === "production";
  const tickMs = Number(process.env.SOCIAL_TICK_MS || (hosted ? 45_000 : 120_000));
  const tick = () => {
    processDueSocialPosts(deps).catch((err) => console.error("Social scheduler error:", err));
  };
  const id = setInterval(tick, tickMs);
  setTimeout(tick, hosted ? 4000 : 22000);
  if (typeof id.unref === "function") id.unref();
  return () => clearInterval(id);
}

module.exports = {
  startSocialScheduler,
  processDueSocialPosts,
  publishSocialPostRecord
};
