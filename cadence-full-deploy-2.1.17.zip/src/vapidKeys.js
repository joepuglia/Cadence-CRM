const fs = require("fs");
const path = require("path");
const webpush = require("web-push");

/** Persisted keys (gitignored). Env VAPID_* overrides when both are set. */
const KEYS_FILE = path.join(__dirname, "..", "crm-vapid-keys.json");

let cached = null;

function getSubject() {
  return String(process.env.VAPID_SUBJECT || "mailto:noreply@localhost").trim();
}

function loadFromFile() {
  try {
    if (!fs.existsSync(KEYS_FILE)) return null;
    const j = JSON.parse(fs.readFileSync(KEYS_FILE, "utf8"));
    const publicKey = String(j.publicKey || "").trim();
    const privateKey = String(j.privateKey || "").trim();
    if (publicKey && privateKey) return { publicKey, privateKey };
  } catch (err) {
    console.warn("[vapid] Could not read crm-vapid-keys.json:", err.message);
  }
  return null;
}

function saveToFile(keys) {
  fs.writeFileSync(KEYS_FILE, JSON.stringify(keys, null, 2), "utf8");
}

/**
 * Resolve VAPID keys: .env → crm-vapid-keys.json → generate & save.
 * Applies webpush.setVapidDetails once.
 */
function ensureVapidKeys() {
  if (cached) return cached;

  const pubEnv = String(process.env.VAPID_PUBLIC_KEY || "").trim();
  const privEnv = String(process.env.VAPID_PRIVATE_KEY || "").trim();

  if (pubEnv && privEnv) {
    cached = { publicKey: pubEnv, privateKey: privEnv };
  } else {
    const fromDisk = loadFromFile();
    if (fromDisk) {
      cached = fromDisk;
    } else {
      const generated = webpush.generateVAPIDKeys();
      cached = {
        publicKey: generated.publicKey,
        privateKey: generated.privateKey
      };
      saveToFile({ publicKey: cached.publicKey, privateKey: cached.privateKey });
      console.log(
        "[vapid] Generated Web Push keys → crm-vapid-keys.json (optional: set VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY in .env)"
      );
    }
  }

  webpush.setVapidDetails(getSubject(), cached.publicKey, cached.privateKey);
  return cached;
}

/** Call before sending push / exposing public key to clients. */
function applyVapidToWebPush() {
  try {
    ensureVapidKeys();
    return !!(cached && cached.publicKey && cached.privateKey);
  } catch (err) {
    console.error("[vapid]", err.message || err);
    return false;
  }
}

function isPushConfigured() {
  try {
    ensureVapidKeys();
    return !!(cached && cached.publicKey && cached.privateKey);
  } catch {
    return false;
  }
}

function getVapidPublicKey() {
  ensureVapidKeys();
  return cached ? cached.publicKey : "";
}

module.exports = {
  ensureVapidKeys,
  applyVapidToWebPush,
  isPushConfigured,
  getVapidPublicKey
};
