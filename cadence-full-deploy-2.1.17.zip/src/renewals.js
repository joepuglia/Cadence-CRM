"use strict";

const MS_DAY = 86_400_000;

function startOfLocalDay(date) {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
}

function parseCoverageStart(raw) {
  const text = String(raw || "").trim();
  if (!text) return null;
  const ymd = text.slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(ymd)) return null;
  const [year, month, day] = ymd.split("-").map((n) => Number(n));
  if (!year || month < 1 || month > 12 || day < 1 || day > 31) return null;
  const dt = new Date(year, month - 1, day);
  if (dt.getFullYear() !== year || dt.getMonth() !== month - 1 || dt.getDate() !== day) {
    return new Date(year, month, 0);
  }
  dt.setHours(0, 0, 0, 0);
  return dt;
}

function addMonths(date, months) {
  const start = startOfLocalDay(date);
  const totalMonths = start.getFullYear() * 12 + start.getMonth() + Number(months);
  const year = Math.floor(totalMonths / 12);
  const month = ((totalMonths % 12) + 12) % 12;
  const day = start.getDate();
  const lastDay = new Date(year, month + 1, 0).getDate();
  const dt = new Date(year, month, Math.min(day, lastDay));
  dt.setHours(0, 0, 0, 0);
  return dt;
}

function parseRenewalInterval(row) {
  const raw = String(row && row.renewal_interval != null ? row.renewal_interval : "").trim();
  if (raw === "3" || raw === "6" || raw === "12") return Number(raw);
  if (String(row && row.annual_renewal ? row.annual_renewal : "") === "1") return 12;
  return 0;
}

function nextRenewalDate(startDate, today, intervalMonths = 12) {
  const n = Number(intervalMonths);
  const months = n === 3 || n === 6 || n === 12 ? n : 12;
  const start = startOfLocalDay(startDate);
  const now = startOfLocalDay(today);
  let candidate = addMonths(start, months);
  let guard = 0;
  while (candidate.getTime() <= start.getTime() && guard < 8) {
    candidate = addMonths(candidate, months);
    guard += 1;
  }
  guard = 0;
  while (daysUntil(candidate, now) < -30 && guard < 48) {
    candidate = addMonths(candidate, months);
    guard += 1;
  }
  const until = daysUntil(candidate, now);
  if (until > 90) return null;
  return candidate;
}

function formatYmd(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function daysUntil(date, today) {
  const a = startOfLocalDay(date).getTime();
  const b = startOfLocalDay(today).getTime();
  return Math.round((a - b) / MS_DAY);
}

function buildRenewalItems(rows, today = new Date()) {
  const now = startOfLocalDay(today);
  const items = [];
  for (const row of Array.isArray(rows) ? rows : []) {
    const interval = parseRenewalInterval(row);
    if (interval !== 3 && interval !== 6 && interval !== 12) continue;
    const start = parseCoverageStart(row.coverage_start_date);
    if (!start || start.getTime() > now.getTime()) continue;
    const next = nextRenewalDate(start, now, interval);
    if (!next) continue;
    const until = daysUntil(next, now);
    if (until < -30 || until > 90) continue;
    items.push({
      id: Number(row.id) || 0,
      full_name: String(row.full_name || "").trim(),
      email: String(row.email || "").trim(),
      phone: String(row.phone || "").trim(),
      coverage_start_date: formatYmd(start),
      next_renewal: formatYmd(next),
      days_until: until,
      renewal_interval: interval,
      quote: String(row.quote || "").trim(),
      coverages_sold: String(row.coverages_sold || "").trim(),
      status: String(row.status || "").trim(),
      outcome: String(row.outcome || "").trim(),
      lead_source: String(row.lead_source || "").trim()
    });
  }
  items.sort((a, b) => a.days_until - b.days_until || String(a.full_name).localeCompare(String(b.full_name)));
  const counts = {
    overdue: items.filter((it) => it.days_until < 0).length,
    next30: items.filter((it) => it.days_until <= 30).length,
    next60: items.filter((it) => it.days_until <= 60).length,
    next90: items.filter((it) => it.days_until <= 90).length
  };
  return { asOf: formatYmd(now), items, counts };
}

/** All renewal dates for a contact that fall within [rangeStart, rangeEnd] (inclusive). */
function renewalsInDateRange(rows, rangeStartIso, rangeEndIso) {
  const rangeStart = parseCoverageStart(rangeStartIso);
  const rangeEnd = parseCoverageStart(rangeEndIso);
  if (!rangeStart || !rangeEnd || rangeEnd < rangeStart) return [];
  const out = [];
  for (const row of Array.isArray(rows) ? rows : []) {
    const interval = parseRenewalInterval(row);
    if (interval !== 3 && interval !== 6 && interval !== 12) continue;
    const start = parseCoverageStart(row.coverage_start_date);
    if (!start) continue;
    let candidate = addMonths(start, interval);
    let guard = 0;
    while (candidate < rangeStart && guard < 120) {
      candidate = addMonths(candidate, interval);
      guard += 1;
    }
    guard = 0;
    while (candidate <= rangeEnd && guard < 48) {
      if (candidate >= rangeStart && candidate > start) {
        out.push({
          id: `renewal-${Number(row.id) || 0}-${formatYmd(candidate)}`,
          contact_id: Number(row.id) || 0,
          full_name: String(row.full_name || "").trim(),
          next_renewal: formatYmd(candidate),
          renewal_interval: interval,
          coverages_sold: String(row.coverages_sold || "").trim(),
          quote: String(row.quote || "").trim()
        });
      }
      candidate = addMonths(candidate, interval);
      guard += 1;
    }
  }
  out.sort((a, b) => String(a.next_renewal).localeCompare(String(b.next_renewal))
    || String(a.full_name).localeCompare(String(b.full_name)));
  return out;
}

module.exports = {
  parseCoverageStart,
  parseRenewalInterval,
  nextRenewalDate,
  buildRenewalItems,
  renewalsInDateRange
};
