const crypto = require("crypto");
const dns = require("dns").promises;
const net = require("net");
const nodemailer = require("nodemailer");

/** Set EMAIL_EMBED_REMOTE_IMAGES=0 to leave http(s) image URLs unchanged (no server fetch). */
function shouldEmbedRemoteImages() {
  const v = String(process.env.EMAIL_EMBED_REMOTE_IMAGES || "1").trim().toLowerCase();
  return v !== "0" && v !== "false" && v !== "no" && v !== "off";
}

/**
 * Parse a data: URL into buffer + mime. Returns null if invalid.
 */
function parseDataUrl(dataUrl) {
  const s = String(dataUrl || "").trim();
  if (!s.toLowerCase().startsWith("data:")) return null;
  const comma = s.indexOf(",");
  if (comma === -1) return null;
  const header = s.slice(5, comma);
  const payload = s.slice(comma + 1);
  const lower = header.toLowerCase();
  const isBase64 = lower.includes(";base64");
  let mime = "application/octet-stream";
  const typePart = header.split(";")[0].trim();
  if (typePart.includes("/")) mime = typePart;

  let buffer;
  try {
    buffer = isBase64 ? Buffer.from(payload, "base64") : Buffer.from(decodeURIComponent(payload));
  } catch {
    return null;
  }
  if (!buffer || buffer.length === 0) return null;
  const maxInline = 12 * 1024 * 1024;
  if (buffer.length > maxInline) return null;

  const sub = mime.split("/")[1] || "bin";
  const safeSub = String(sub).replace(/[^a-z0-9+-]/gi, "") || "png";
  return {
    mime,
    buffer,
    filename: `embedded.${safeSub}`
  };
}

/**
 * Gmail, Outlook, and others often strip <img src="data:...">. Replace with CID attachments.
 */
function promoteDataUrlImagesToCid(html) {
  if (!html || typeof html !== "string" || !html.includes("data:")) {
    return { html, attachments: [] };
  }
  const attachments = [];
  const ctr = { n: 0 };
  const out = html.replace(/<img\b[^>]*>/gi, (tag) => {
    const m = /\bsrc\s*=\s*(["'])(data:[^"']+)\1/i.exec(tag);
    if (!m) return tag;
    const parsed = parseDataUrl(m[2]);
    if (!parsed) return tag;
    const cid = `crm.sig.${ctr.n++}.${crypto.randomBytes(4).toString("hex")}@inline`;
    attachments.push({
      filename: parsed.filename,
      content: parsed.buffer,
      contentType: parsed.mime,
      cid
    });
    return tag.replace(/\bsrc\s*=\s*(["'])data:[^"']+\1/i, (_, quote) => `src=${quote}cid:${cid}${quote}`);
  });
  return { html: out, attachments };
}

function guessMimeFromPath(pathname) {
  const lower = String(pathname || "").toLowerCase();
  if (lower.endsWith(".png")) return "image/png";
  if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
  if (lower.endsWith(".gif")) return "image/gif";
  if (lower.endsWith(".webp")) return "image/webp";
  if (lower.endsWith(".svg") || lower.endsWith(".svgz")) return "image/svg+xml";
  if (lower.endsWith(".bmp")) return "image/bmp";
  if (lower.endsWith(".ico")) return "image/x-icon";
  return "";
}

/** Returns true if dotted IPv4 string is in private/reserved ranges (block SSRF). */
function isPrivateOrReservedIPv4(ip) {
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(String(ip || "").trim());
  if (!m) return false;
  const [a, b] = [Number(m[1]), Number(m[2])];
  if ([m[1], m[2], m[3], m[4]].some((x) => Number(x) > 255)) return true;
  if (a === 10) return true;
  if (a === 127) return true;
  if (a === 0) return true;
  if (a === 169 && b === 254) return true;
  if (a === 192 && b === 168) return true;
  if (a === 172 && b >= 16 && b <= 31) return true;
  return false;
}

async function assertRemoteImageUrlSafe(urlStr) {
  let u;
  try {
    u = new URL(urlStr);
  } catch {
    return false;
  }
  if (u.protocol !== "http:" && u.protocol !== "https:") return false;
  const host = u.hostname.toLowerCase();
  if (host === "localhost" || host.endsWith(".localhost") || host === "[::1]" || host === "::1") return false;
  if (/^\d+\.\d+\.\d+\.\d+$/.test(host)) {
    return !isPrivateOrReservedIPv4(host);
  }
  try {
    const { address } = await dns.lookup(host);
    if (address === "::1" || address === "127.0.0.1") return false;
    if (/^\d+\.\d+\.\d+\.\d+$/.test(address)) {
      return !isPrivateOrReservedIPv4(address);
    }
    if (address.includes(":")) {
      const lc = address.toLowerCase();
      if (lc.startsWith("fd") || lc.startsWith("fe80:") || lc === "::1") return false;
    }
  } catch {
    return false;
  }
  return true;
}

async function fetchRemoteImage(urlStr) {
  const maxBytes = 12 * 1024 * 1024;
  const ok = await assertRemoteImageUrlSafe(urlStr);
  if (!ok) return null;
  if (typeof fetch !== "function") {
    console.warn("[email] fetch() is not available; cannot embed remote signature images. Use Node 18+.");
    return null;
  }
  const controller = new AbortController();
  const timeoutRaw = Number(process.env.EMAIL_REMOTE_IMAGE_FETCH_TIMEOUT_MS || 5000);
  const timeoutMs = Number.isFinite(timeoutRaw) && timeoutRaw > 0 ? Math.floor(timeoutRaw) : 5000;
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(urlStr, {
      redirect: "follow",
      headers: {
        Accept: "image/*,*/*;q=0.8",
        "User-Agent": "Cadence-CRM/1.0 (email inline image)"
      },
      signal: controller.signal
    });
    if (!res.ok) return null;
    const buf = Buffer.from(await res.arrayBuffer());
    if (!buf.length || buf.length > maxBytes) return null;
    let mime = String(res.headers.get("content-type") || "")
      .split(";")[0]
      .trim()
      .toLowerCase();
    if (!mime.startsWith("image/")) {
      mime = guessMimeFromPath(new URL(urlStr).pathname) || "";
    }
    if (!mime.startsWith("image/")) return null;
    const sub = mime.split("/")[1]?.replace(/[^a-z0-9]/gi, "") || "img";
    return { buffer: buf, mime, filename: `remote.${sub}` };
  } catch (e) {
    const msg = e && e.message ? String(e.message) : String(e);
    if (!/abort|timeout/i.test(msg)) {
      console.warn(`[email] Could not fetch image for embedding: ${msg.slice(0, 120)}`);
    }
    return null;
  } finally {
    clearTimeout(timer);
  }
}

function normalizeUrlDedupKey(urlStr) {
  try {
    const u = new URL(urlStr);
    return `${u.protocol}//${u.host}${u.pathname}${u.search}`;
  } catch {
    return String(urlStr || "").trim();
  }
}

const IMG_HTTP_SRC_RE = /\bsrc\s*=\s*(["'])(https?:\/\/[^"']+)\1/i;

function stripOpenTrackingImages(html) {
  return String(html || "").replace(
    /<img\b[^>]*\bsrc\s*=\s*(["'])[^"']*\/api\/email\/open\/[^"']*\1[^>]*>/gi,
    ""
  );
}

function isEmailOpenTrackingUrl(urlStr) {
  try {
    const u = new URL(String(urlStr || ""));
    return /^\/api\/email\/open\/[^/]+$/i.test(u.pathname);
  } catch {
    return false;
  }
}

/**
 * Fetch http(s) images and attach as CID so Gmail/Outlook show them without relying on external loads.
 */
async function promoteHttpUrlImagesToCid(html) {
  if (!shouldEmbedRemoteImages()) {
    return { html, attachments: [] };
  }
  if (!html || typeof html !== "string" || !/https?:\/\//i.test(html)) {
    return { html, attachments: [] };
  }
  if (!/<img\b/i.test(html)) {
    return { html, attachments: [] };
  }
  const attachments = [];
  const urlToCid = new Map();
  let seq = 0;
  const matches = [...html.matchAll(/<img\b[^>]*>/gi)].sort((a, b) => b.index - a.index);
  let result = html;
  for (const match of matches) {
    const tag = match[0];
    const sm = IMG_HTTP_SRC_RE.exec(tag);
    if (!sm) continue;
    const urlStr = sm[2];
    if (isEmailOpenTrackingUrl(urlStr)) continue;
    const key = normalizeUrlDedupKey(urlStr);
    let cid = urlToCid.get(key);
    if (!cid) {
      const fetched = await fetchRemoteImage(urlStr);
      if (!fetched) continue;
      cid = `crm.url.${seq++}.${crypto.randomBytes(4).toString("hex")}@inline`;
      urlToCid.set(key, cid);
      attachments.push({
        filename: fetched.filename,
        content: fetched.buffer,
        contentType: fetched.mime,
        cid
      });
    }
    const newTag = tag.replace(IMG_HTTP_SRC_RE, (_, quote) => `src=${quote}cid:${cid}${quote}`);
    result = result.slice(0, match.index) + newTag + result.slice(match.index + tag.length);
  }
  return { html: result, attachments };
}

function getSmtpMissing() {
  const missing = [];
  if (!process.env.SMTP_HOST) missing.push("SMTP_HOST");
  if (!process.env.SMTP_USER) missing.push("SMTP_USER");
  if (!process.env.SMTP_PASS) missing.push("SMTP_PASS");
  return missing;
}

function isEmailConfigured() {
  return getSmtpMissing().length === 0;
}

/** Env SMTP or a sender saved under Settings → Email Sender Addresses. */
async function isOutboundEmailReady() {
  if (isEmailConfigured()) return true;
  return hasReadyFromAddressSmtp();
}

function mailboxFromHeader(raw) {
  const s = String(raw || "").trim();
  const angled = s.match(/^(.*)<([^<>]+)>\s*$/);
  if (!angled) return { address: s, name: "" };
  const address = String(angled[2] || "").trim();
  let name = String(angled[1] || "").trim();
  if (
    (name.startsWith('"') && name.endsWith('"')) ||
    (name.startsWith("'") && name.endsWith("'"))
  ) {
    name = name.slice(1, -1).trim();
  }
  return { address, name };
}

/** True when a saved sender address has its own mail server and username. */
async function hasReadyFromAddressSmtp() {
  try {
    const { all } = require("./db");
    const rows = await all(`SELECT smtp_host, smtp_user FROM email_from_addresses`);
    return (Array.isArray(rows) ? rows : []).some((row) => {
      return String(row?.smtp_host || "").trim() && String(row?.smtp_user || "").trim();
    });
  } catch {
    return false;
  }
}

function getTrialWelcomeFromAddress() {
  return String(
    process.env.TRIAL_WELCOME_FROM ||
      process.env.TRIAL_WELCOME_SMTP_FROM ||
      "support@crmcadence.com"
  ).trim();
}

function getTrialWelcomeSmtpMissing() {
  const missing = [];
  if (!process.env.TRIAL_WELCOME_SMTP_HOST) missing.push("TRIAL_WELCOME_SMTP_HOST");
  if (!process.env.TRIAL_WELCOME_SMTP_USER) missing.push("TRIAL_WELCOME_SMTP_USER");
  if (!process.env.TRIAL_WELCOME_SMTP_PASS) missing.push("TRIAL_WELCOME_SMTP_PASS");
  return missing;
}

function isTrialWelcomeSmtpConfigured() {
  return getTrialWelcomeSmtpMissing().length === 0;
}

/** True when general SMTP exists (welcome may still show wrong From without TRIAL_WELCOME_SMTP_*). */
function canSendTrialWelcomeEmail() {
  return isEmailConfigured() || isTrialWelcomeSmtpConfigured();
}

let transporter;

/** smtp.example.com is a documentation placeholder and does not resolve (ENOTFOUND). */
function resolveSmtpHost() {
  const h = String(process.env.SMTP_HOST || "").trim();
  if (/^smtp\.example\.com$/i.test(h)) {
    console.warn(
      "[email] SMTP_HOST is smtp.example.com (invalid placeholder). Using smtp.gmail.com. Set SMTP_HOST in .env to your real server (e.g. smtp.gmail.com, smtp.office365.com)."
    );
    return "smtp.gmail.com";
  }
  return h;
}

/**
 * Spacemail for @crmcadence.com mailboxes. Common misconfigs do not resolve (ENOTFOUND).
 * mail.crmcadence.com and localhost are wrong — auto-correct so welcome mail still sends after deploy.
 */
function resolveTrialWelcomeSmtpHost() {
  const raw = String(process.env.TRIAL_WELCOME_SMTP_HOST || "").trim();
  if (!raw) return raw;
  if (/^mail\.crmcadence\.com$/i.test(raw) || /^localhost$/i.test(raw) || /^127\.0\.0\.1$/i.test(raw)) {
    console.warn(
      `[email] TRIAL_WELCOME_SMTP_HOST=${raw} is invalid for external delivery. Using mail.spacemail.com — update .env and cPanel Node env vars.`
    );
    return "mail.spacemail.com";
  }
  return raw;
}

function getTrialWelcomeSmtpHost() {
  return resolveTrialWelcomeSmtpHost();
}

/** Default: verify TLS certs. Set SMTP_TLS_REJECT_UNAUTHORIZED=0 if you hit "self-signed certificate in certificate chain" (e.g. corporate proxy) — use only on trusted networks. */
function tlsRejectUnauthorized() {
  const raw = process.env.SMTP_TLS_REJECT_UNAUTHORIZED;
  if (raw === undefined || String(raw).trim() === "") return true;
  const v = String(raw).trim().toLowerCase();
  return v !== "0" && v !== "false" && v !== "no" && v !== "off";
}

function positiveEnvMs(name, fallbackMs) {
  const raw = Number(process.env[name] || fallbackMs);
  return Number.isFinite(raw) && raw > 0 ? Math.floor(raw) : fallbackMs;
}

function createOsDnsSocketFactory(defaultHost) {
  return (options, callback) => {
    const host = String(options?.host || defaultHost || "").trim();
    const port = Number(options?.port || 587);
    if (!host || !Number.isFinite(port) || port < 1) {
      callback(new Error("Invalid SMTP host or port."));
      return;
    }
    dns
      .lookup(host, { family: 4 })
      .then(({ address }) => {
        let settled = false;
        const socket = net.connect({ host: address, port });
        const finish = (err, result) => {
          if (settled) return;
          settled = true;
          callback(err, result);
        };
        socket.setTimeout(positiveEnvMs("SMTP_CONNECTION_TIMEOUT_MS", 15000));
        socket.once("connect", () => finish(null, { connection: socket }));
        socket.once("timeout", () => {
          socket.destroy();
          finish(new Error(`SMTP connection timed out to ${host}:${port}`));
        });
        socket.once("error", (err) => finish(err));
      })
      .catch((err) => callback(err));
  };
}

function getTransporter() {
  if (!isEmailConfigured()) {
    throw new Error("SMTP is not configured. Set SMTP_HOST, SMTP_USER, and SMTP_PASS in your environment.");
  }
  if (!transporter) {
    const rejectUnauthorized = tlsRejectUnauthorized();
    if (!rejectUnauthorized) {
      console.warn(
        "[email] SMTP TLS certificate verification is disabled (SMTP_TLS_REJECT_UNAUTHORIZED=0). Prefer fixing the server certificate or trust store; only use in dev/trusted networks."
      );
    }
    transporter = nodemailer.createTransport({
      host: resolveSmtpHost(),
      port: Number(process.env.SMTP_PORT || 587),
      secure: process.env.SMTP_SECURE === "1" || String(process.env.SMTP_SECURE).toLowerCase() === "true",
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
      },
      connectionTimeout: positiveEnvMs("SMTP_CONNECTION_TIMEOUT_MS", 15000),
      greetingTimeout: positiveEnvMs("SMTP_GREETING_TIMEOUT_MS", 15000),
      socketTimeout: positiveEnvMs("SMTP_SOCKET_TIMEOUT_MS", 30000),
      getSocket: createOsDnsSocketFactory(resolveSmtpHost()),
      tls: {
        servername: resolveSmtpHost(),
        rejectUnauthorized
      }
    });
  }
  return transporter;
}

function trialWelcomeTlsRejectUnauthorized() {
  const raw = process.env.TRIAL_WELCOME_SMTP_TLS_REJECT_UNAUTHORIZED;
  if (raw !== undefined && String(raw).trim() !== "") {
    const v = String(raw).trim().toLowerCase();
    return v !== "0" && v !== "false" && v !== "no" && v !== "off";
  }
  return tlsRejectUnauthorized();
}

function getTrialWelcomeSmtpAttempts() {
  const envPort = Number(process.env.TRIAL_WELCOME_SMTP_PORT || 587);
  const envSecure =
    process.env.TRIAL_WELCOME_SMTP_SECURE === "1" ||
    String(process.env.TRIAL_WELCOME_SMTP_SECURE || "").toLowerCase() === "true";
  const attempts = [{ port: envPort, secure: envSecure, label: "env" }];
  const has465 = attempts.some((a) => a.port === 465 && a.secure);
  const has587 = attempts.some((a) => a.port === 587 && !a.secure);
  if (!has465) attempts.push({ port: 465, secure: true, label: "465/ssl" });
  if (!has587) attempts.push({ port: 587, secure: false, label: "587/starttls" });
  return attempts;
}

function createTrialWelcomeSmtpTransport(port, secure) {
  const rejectUnauthorized = trialWelcomeTlsRejectUnauthorized();
  const host = getTrialWelcomeSmtpHost();
  return nodemailer.createTransport({
    host,
    port,
    secure,
    requireTLS: !secure && port === 587,
    connectionTimeout: positiveEnvMs("SMTP_CONNECTION_TIMEOUT_MS", 15000),
    greetingTimeout: positiveEnvMs("SMTP_GREETING_TIMEOUT_MS", 15000),
    socketTimeout: positiveEnvMs("SMTP_SOCKET_TIMEOUT_MS", 30000),
    getSocket: createOsDnsSocketFactory(host),
    auth: {
      user: process.env.TRIAL_WELCOME_SMTP_USER,
      pass: process.env.TRIAL_WELCOME_SMTP_PASS
    },
    tls: { rejectUnauthorized, servername: host }
  });
}

function createTrialWelcomeSendmailTransport(fromAddr) {
  const sendmailPath = String(process.env.TRIAL_WELCOME_SENDMAIL_PATH || "/usr/sbin/sendmail").trim();
  return nodemailer.createTransport({
    sendmail: true,
    path: sendmailPath,
    args: `-f ${fromAddr} -t`
  });
}

function trialWelcomeSendmailEnabled() {
  const raw = String(process.env.TRIAL_WELCOME_USE_SENDMAIL || "1").trim().toLowerCase();
  return raw !== "0" && raw !== "false" && raw !== "no" && process.platform !== "win32";
}

/** Cache of per-address transporters keyed by lowercase email address. */
const perAddressTransporters = new Map();
/** Cache of per-address SMTP rows keyed by lowercase email address. */
const perAddressConfigCache = new Map();

function invalidatePerAddressTransporters(emailAddress) {
  if (emailAddress == null) {
    perAddressTransporters.clear();
    perAddressConfigCache.clear();
    return;
  }
  const key = String(emailAddress || "").trim().toLowerCase();
  if (!key) return;
  perAddressTransporters.delete(key);
  perAddressConfigCache.delete(key);
}

async function loadPerAddressSmtpConfig(emailAddress) {
  const key = String(emailAddress || "").trim().toLowerCase();
  if (!key) return null;
  if (perAddressConfigCache.has(key)) return perAddressConfigCache.get(key);
  let row = null;
  try {
    const { get } = require("./db");
    row = await get(
      `SELECT email_address, smtp_host, smtp_port, smtp_secure, smtp_user, smtp_pass, reply_to
       FROM email_from_addresses WHERE LOWER(email_address) = ?`,
      [key]
    );
  } catch {
    row = null;
  }
  const config =
    row && String(row.smtp_host || "").trim()
      ? {
          host: String(row.smtp_host || "").trim(),
          port: Number(row.smtp_port || 0) > 0 ? Number(row.smtp_port) : 587,
          secure: Number(row.smtp_secure || 0) === 1,
          user: String(row.smtp_user || "").trim(),
          pass: String(row.smtp_pass || ""),
          replyTo: String(row.reply_to || "").trim()
        }
      : row && String(row.reply_to || "").trim()
        ? { replyTo: String(row.reply_to || "").trim() }
        : null;
  perAddressConfigCache.set(key, config);
  return config;
}

function getPerAddressTransporter(config) {
  if (!config || !config.host || !config.user) return null;
  const key = `${config.host.toLowerCase()}|${config.port}|${config.secure ? 1 : 0}|${config.user}`;
  if (perAddressTransporters.has(key)) return perAddressTransporters.get(key);
  const tx = nodemailer.createTransport({
    host: config.host,
    port: Number(config.port) || 587,
    secure: Boolean(config.secure),
    auth: {
      user: config.user,
      pass: config.pass
    },
    connectionTimeout: positiveEnvMs("SMTP_CONNECTION_TIMEOUT_MS", 15000),
    greetingTimeout: positiveEnvMs("SMTP_GREETING_TIMEOUT_MS", 15000),
    socketTimeout: positiveEnvMs("SMTP_SOCKET_TIMEOUT_MS", 30000),
    getSocket: createOsDnsSocketFactory(config.host),
    tls: {
      servername: config.host,
      rejectUnauthorized: tlsRejectUnauthorized()
    }
  });
  perAddressTransporters.set(key, tx);
  return tx;
}

async function sendEmail({ to, cc, bcc, from, replyTo: replyToOverride, subject, text, html, attachments, headers }) {
  let skipEnvDefaults = false;
  try {
    const { isTrialTenantContext } = require("./db");
    skipEnvDefaults = isTrialTenantContext();
  } catch {
    skipEnvDefaults = false;
  }
  const envFrom = skipEnvDefaults ? "" : String(process.env.SMTP_FROM || process.env.SMTP_USER || "").trim();
  const parsedFrom = mailboxFromHeader(from || envFrom);
  const resolvedFrom = parsedFrom.address;
  if (!resolvedFrom) {
    throw new Error(
      skipEnvDefaults
        ? "Choose a From address in Send Email or add a sender under Settings → Email Sender Addresses (with SMTP credentials)."
        : "Set SMTP_FROM (recommended) or SMTP_USER as the sender address."
    );
  }
  const perAddressConfig = await loadPerAddressSmtpConfig(resolvedFrom);
  const perAddressTransport = perAddressConfig ? getPerAddressTransporter(perAddressConfig) : null;
  const transport = perAddressTransport || getTransporter();
  const replyTo =
    String(replyToOverride || "").trim() ||
    (perAddressConfig && perAddressConfig.replyTo ? perAddressConfig.replyTo : "");
  let htmlOut = html ? stripOpenTrackingImages(html) : html;
  const baseAttachments = Array.isArray(attachments) ? attachments : [];
  let cidAttachments = [];
  if (htmlOut && String(htmlOut).includes("data:")) {
    const promoted = promoteDataUrlImagesToCid(String(htmlOut));
    htmlOut = promoted.html;
    cidAttachments = promoted.attachments;
  }
  if (htmlOut && /https?:\/\//i.test(String(htmlOut))) {
    const remote = await promoteHttpUrlImagesToCid(String(htmlOut));
    htmlOut = remote.html;
    cidAttachments = [...cidAttachments, ...remote.attachments];
  }
  const ccStr = String(cc || "").trim();
  const bccStr = String(bcc || "").trim();
  const extraHeaders = headers && typeof headers === "object" ? { ...headers } : {};
  delete extraHeaders["List-Unsubscribe"];
  delete extraHeaders["List-Unsubscribe-Post"];
  try {
    const info = await transport.sendMail({
      from: parsedFrom.name ? { name: parsedFrom.name, address: resolvedFrom } : resolvedFrom,
      to,
      ...(ccStr ? { cc: ccStr } : {}),
      ...(bccStr ? { bcc: bccStr } : {}),
      ...(replyTo ? { replyTo } : {}),
      subject: subject || "(no subject)",
      text: text || "",
      html: htmlOut || undefined,
      attachments: [...baseAttachments, ...cidAttachments],
      headers: extraHeaders
    });
    return { messageId: info.messageId };
  } catch (err) {
    throw wrapSmtpSendError(err, {
      fromAddress: resolvedFrom,
      host: String(perAddressConfig?.host || process.env.SMTP_HOST || "")
    });
  }
}

function wrapSmtpSendError(err, meta) {
  const msg = String(err && err.message ? err.message : err);
  const host = String(meta?.host || "").toLowerCase();
  const fromAddress = String(meta?.fromAddress || "").trim();
  const googleAppPassword =
    /535|5\.7\.8|invalidsecondfactor|application-specific password|invalid login|authentication failed|badcredentials/i.test(
      msg
    ) &&
    (host.includes("gmail") ||
      host.includes("google") ||
      /p=invalidsecondfactor|support\.google\.com\/mail/i.test(msg));
  if (googleAppPassword) {
    const who = fromAddress ? ` for ${fromAddress}` : "";
    const wrapped = new Error(
      "Google needs an App Password, not your normal mailbox password" +
        who +
        ". Open Google Account → Security → 2-Step Verification → App passwords, create one, then paste the 16-character password under Settings → Email Sender Addresses (SMTP password). Keep SMTP host smtp.gmail.com."
    );
    wrapped.stack = err.stack;
    return wrapped;
  }
  return err;
}

function getAllowedFromAddresses() {
  const options = [];
  const pushIf = (v) => {
    const t = String(v || "").trim();
    if (t && !options.find((o) => o.toLowerCase() === t.toLowerCase())) options.push(t);
  };
  let skipEnvDefaults = false;
  try {
    const { isTrialTenantContext } = require("./db");
    skipEnvDefaults = isTrialTenantContext();
  } catch {
    skipEnvDefaults = false;
  }
  if (!skipEnvDefaults) {
    pushIf(process.env.SMTP_FROM);
    pushIf(process.env.SMTP_USER);
  }
  return options;
}

/**
 * Async — env defaults plus user-managed addresses from `email_from_addresses` table.
 * Lazy-required to avoid circular deps with db.js.
 */
async function loadAllowedFromAddresses() {
  const options = getAllowedFromAddresses();
  try {
    const { all } = require("./db");
    const rows = await all(
      `SELECT email_address FROM email_from_addresses ORDER BY created_at ASC, id ASC`
    );
    for (const row of Array.isArray(rows) ? rows : []) {
      const t = String(row?.email_address || "").trim();
      if (t && !options.find((o) => o.toLowerCase() === t.toLowerCase())) {
        options.push(t);
      }
    }
  } catch {
    // DB not ready — fall back to env-only list.
  }
  return options;
}

/**
 * Empty input → null (use sendEmail default). Non-empty must match an allowed sender.
 */
async function normalizeCampaignEmailFrom(raw) {
  const s = String(raw ?? "").trim();
  if (!s) return null;
  const allowed = await loadAllowedFromAddresses();
  if (!allowed.length) {
    let trial = false;
    try {
      const { isTrialTenantContext } = require("./db");
      trial = isTrialTenantContext();
    } catch {
      trial = false;
    }
    throw new Error(
      trial
        ? "No sender addresses configured. Add one under Settings → Email Sender Addresses with SMTP credentials."
        : "No sender addresses configured. Set SMTP_FROM or SMTP_USER, or add an address in Settings."
    );
  }
  const match = allowed.find((a) => a.toLowerCase() === s.toLowerCase());
  if (!match) {
    throw new Error(`email_from must be empty (default) or one of: ${allowed.join(", ")}`);
  }
  return match;
}

/**
 * Trial welcome mail must authenticate as support@crmcadence.com (cPanel mailbox).
 * Gmail SMTP rewrites From to SMTP_USER when you only set from: support@...
 */
/** Off by default — Gmail shows as joseph@ewisehealth.com, not support@crmcadence.com */
function trialWelcomeGmailFallbackEnabled() {
  const raw = String(process.env.TRIAL_WELCOME_ALLOW_GMAIL_FALLBACK || "0").trim().toLowerCase();
  return raw === "1" || raw === "true" || raw === "yes";
}

async function verifyTrialWelcomeSmtp() {
  if (!isTrialWelcomeSmtpConfigured()) {
    return { ok: false, error: `Missing: ${getTrialWelcomeSmtpMissing().join(", ")}` };
  }
  const errors = [];
  for (const att of getTrialWelcomeSmtpAttempts()) {
    const transport = createTrialWelcomeSmtpTransport(att.port, att.secure);
    try {
      await transport.verify();
      transport.close();
      return { ok: true, via: att.label };
    } catch (err) {
      errors.push(`${att.label}: ${err && err.message ? err.message : err}`);
      try {
        transport.close();
      } catch {
        /* ignore */
      }
    }
  }
  return { ok: false, error: errors.join(" | ") };
}

async function sendTrialWelcomeEmail({ to, subject, text, html }) {
  const fromAddr = getTrialWelcomeFromAddress();
  const fromHeader = `"Cadence CRM" <${fromAddr}>`;
  const replyTo = fromAddr;

  let htmlOut = html;
  let cidAttachments = [];
  if (htmlOut && String(htmlOut).includes("data:")) {
    const promoted = promoteDataUrlImagesToCid(String(htmlOut));
    htmlOut = promoted.html;
    cidAttachments = promoted.attachments;
  }
  if (htmlOut && /https?:\/\//i.test(String(htmlOut))) {
    const remote = await promoteHttpUrlImagesToCid(String(htmlOut));
    htmlOut = remote.html;
    cidAttachments = [...cidAttachments, ...remote.attachments];
  }

  const mailOptions = {
    from: fromHeader,
    sender: fromAddr,
    to,
    replyTo,
    envelope: { from: fromAddr, to: Array.isArray(to) ? to : [to] },
    subject: subject || "(no subject)",
    text: text || "",
    html: htmlOut || undefined,
    attachments: cidAttachments
  };

  const smtpErrors = [];

  if (isTrialWelcomeSmtpConfigured()) {
    for (const att of getTrialWelcomeSmtpAttempts()) {
      const transport = createTrialWelcomeSmtpTransport(att.port, att.secure);
      try {
        const info = await transport.sendMail(mailOptions);
        transport.close();
        console.log(`[email] Trial welcome sent from ${fromAddr} to ${to} via SMTP ${att.label}.`);
        return { messageId: info.messageId, via: `trial_smtp:${att.label}` };
      } catch (err) {
        smtpErrors.push(`${att.label}: ${err && err.message ? err.message : err}`);
        try {
          transport.close();
        } catch {
          /* ignore */
        }
      }
    }
  }

  if (trialWelcomeSendmailEnabled()) {
    try {
      const transport = createTrialWelcomeSendmailTransport(fromAddr);
      const info = await transport.sendMail(mailOptions);
      console.log(`[email] Trial welcome sent from ${fromAddr} to ${to} via sendmail.`);
      return { messageId: info.messageId, via: "sendmail" };
    } catch (err) {
      smtpErrors.push(`sendmail: ${err && err.message ? err.message : err}`);
    }
  }

  if (trialWelcomeGmailFallbackEnabled() && isEmailConfigured()) {
    console.warn(
      `[email] Trial welcome using Gmail for ${to} — will show as ${process.env.SMTP_USER}, not ${fromAddr}. Set TRIAL_WELCOME_ALLOW_GMAIL_FALLBACK=0 and fix cPanel SMTP.`
    );
    const info = await sendEmail({ from: fromHeader, replyTo, to, subject, text, html: htmlOut });
    return { messageId: info.messageId, via: "gmail_fallback" };
  }

  throw new Error(
    `Could not send from ${fromAddr}. ${smtpErrors.join(" | ") || "Set TRIAL_WELCOME_SMTP_* in .env"}. ` +
      "In cPanel → Email → Connect Devices, confirm host/port/password. Try port 465 with TRIAL_WELCOME_SMTP_SECURE=true."
  );
}

async function findPerAddressSmtpFromCandidates() {
  const out = [];
  const seen = new Set();
  const push = (v) => {
    const parts = String(v || "").split(/[;,]+/);
    for (const part of parts) {
      const t = String(part || "").trim();
      const key = t.toLowerCase();
      if (!t || !t.includes("@") || seen.has(key)) continue;
      seen.add(key);
      out.push(t);
    }
  };
  push(process.env.SMTP_FROM);
  push(process.env.SMTP_USER);
  push(process.env.CONTACT_SALES_NOTIFY_EMAIL);
  push(process.env.TRIAL_SIGNUP_NOTIFY_EMAIL);
  push(getTrialWelcomeFromAddress());
  try {
    const { all } = require("./db");
    const rows = await all(
      `SELECT email_address FROM email_from_addresses
       WHERE smtp_host IS NOT NULL AND TRIM(smtp_host) != ''
         AND smtp_user IS NOT NULL AND TRIM(smtp_user) != ''`
    );
    for (const row of rows || []) push(row.email_address);
  } catch {
    /* DB not ready */
  }
  return out;
}

async function canSendSystemNotificationEmail() {
  if (isEmailConfigured()) return true;
  if (isTrialWelcomeSmtpConfigured()) return true;
  if (trialWelcomeSendmailEnabled()) return true;
  const candidates = await findPerAddressSmtpFromCandidates();
  for (const addr of candidates) {
    const cfg = await loadPerAddressSmtpConfig(addr);
    if (cfg && cfg.host && cfg.user) return true;
  }
  return false;
}

/** Trial signup, Contact Sales, and other server-side alerts — tries env SMTP, per-address SMTP, then welcome SMTP. */
async function sendSystemNotificationEmail({ to, subject, text, from }) {
  const toStr = Array.isArray(to) ? to.join(", ") : String(to || "").trim();
  if (!toStr) throw new Error("No recipients for system notification.");

  const errors = [];
  const fromCandidates = [];
  const seenFrom = new Set();
  const pushFrom = (v) => {
    const t = String(v || "").trim();
    const key = t.toLowerCase();
    if (!t || !t.includes("@") || seenFrom.has(key)) return;
    seenFrom.add(key);
    fromCandidates.push(t);
  };
  pushFrom(from);
  for (const addr of await findPerAddressSmtpFromCandidates()) pushFrom(addr);

  if (isEmailConfigured()) {
    const attempts = fromCandidates.length ? fromCandidates : [""];
    for (const fromAddr of attempts) {
      try {
        const info = await sendEmail({
          to: toStr,
          subject,
          text,
          ...(fromAddr ? { from: fromAddr } : {})
        });
        console.log(
          `[email] System notification sent to ${toStr} via env SMTP${fromAddr ? ` from ${fromAddr}` : ""}.`
        );
        return { messageId: info.messageId, via: "env_smtp" };
      } catch (err) {
        errors.push(
          `env_smtp${fromAddr ? `(${fromAddr})` : ""}: ${err && err.message ? err.message : err}`
        );
      }
    }
  }

  for (const fromAddr of fromCandidates) {
    const perAddr = await loadPerAddressSmtpConfig(fromAddr);
    const transport = perAddr ? getPerAddressTransporter(perAddr) : null;
    if (!transport || !perAddr?.host) continue;
    try {
      const info = await transport.sendMail({
        from: fromAddr,
        to: toStr,
        subject: subject || "(no subject)",
        text: text || ""
      });
      console.log(`[email] System notification sent to ${toStr} via per-address SMTP from ${fromAddr}.`);
      return { messageId: info.messageId, via: "per_address_smtp" };
    } catch (err) {
      errors.push(`per_address(${fromAddr}): ${err && err.message ? err.message : err}`);
    }
  }

  if (canSendTrialWelcomeEmail()) {
    try {
      const info = await sendTrialWelcomeEmail({ to: toStr, subject, text });
      console.log(`[email] System notification sent to ${toStr} via trial welcome SMTP (${info.via || "trial"}).`);
      return { messageId: info.messageId, via: info.via || "trial_welcome" };
    } catch (err) {
      errors.push(`trial_welcome: ${err && err.message ? err.message : err}`);
    }
  }

  throw new Error(errors.join(" | ") || "No SMTP configured for system notifications.");
}

module.exports = {
  sendEmail,
  sendTrialWelcomeEmail,
  sendSystemNotificationEmail,
  verifyTrialWelcomeSmtp,
  isEmailConfigured,
  canSendTrialWelcomeEmail,
  canSendSystemNotificationEmail,
  isTrialWelcomeSmtpConfigured,
  getTrialWelcomeFromAddress,
  getTrialWelcomeSmtpHost,
  getSmtpMissing,
  hasReadyFromAddressSmtp,
  isOutboundEmailReady,
  getTrialWelcomeSmtpMissing,
  getAllowedFromAddresses,
  loadAllowedFromAddresses,
  normalizeCampaignEmailFrom,
  invalidatePerAddressTransporters,
  loadPerAddressSmtpConfig
};
