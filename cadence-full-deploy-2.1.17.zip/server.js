// cPanel / Passenger entry point — loads the real CRM server.
const fs = require("fs");
const path = require("path");

require("dotenv").config({ path: path.join(__dirname, ".env") });

const errorLog = path.join(__dirname, "startup-error.log");

function logStartupError(err) {
  const text = `${new Date().toISOString()}\n${err && err.stack ? err.stack : String(err)}\n\n`;
  try {
    fs.appendFileSync(errorLog, text);
  } catch {
    /* ignore */
  }
  console.error("CRM failed to start:", err);
}

try {
  module.exports = require("./src/server.js");
} catch (err) {
  logStartupError(err);
  throw err;
}
