const formEl = document.getElementById("landingPagesForm");
const messageEl = document.getElementById("message");
const listBodyEl = document.getElementById("landingPagesBody");
const refreshBtn = document.getElementById("landingPagesRefreshBtn");
const cancelEditBtn = document.getElementById("landingPagesCancelEditBtn");
const saveBtn = document.getElementById("landingPagesSaveBtn");

const idInput = document.getElementById("landingPageId");
const nameInput = document.getElementById("lpName");
const platformSelect = document.getElementById("lpPlatform");
const platformOtherInput = document.getElementById("lpPlatformOther");
const websiteUrlInput = document.getElementById("lpWebsiteUrl");
const landingPageUrlInput = document.getElementById("lpLandingPageUrl");
const notesInput = document.getElementById("lpNotes");

const PLATFORM_OPTIONS = new Set([
  "",
  "WordPress",
  "Wix",
  "Squarespace",
  "Leadpages",
  "ClickFunnels",
  "GoHighLevel",
  "Facebook",
  "Custom/Other"
]);

let cachedRows = [];

function getCrmApiBase() {
  const injected =
    typeof window.__CRM_API_ORIGIN__ === "string" ? window.__CRM_API_ORIGIN__.trim().replace(/\/$/, "") : "";
  if (injected) return injected;
  const fromMeta = document.querySelector('meta[name="crm-api-base"]')?.getAttribute("content") || "";
  return String(fromMeta || "").trim().replace(/\/$/, "");
}

function apiUrl(path) {
  const p = path.startsWith("/") ? path : `/${path}`;
  const base = getCrmApiBase();
  return base ? `${base}${p}` : p;
}

async function fetchApiJson(pathAndQuery, init) {
  const response = await fetch(apiUrl(pathAndQuery), init);
  const text = await response.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = {};
  }
  return { response, data };
}

function showMessage(text, isError = false) {
  const str = String(text == null ? "" : text);
  if (isError && typeof window.crmHandleAuthErrorMessage === "function" && window.crmHandleAuthErrorMessage(str, isError)) {
    return;
  }
  messageEl.textContent = str;
  messageEl.style.color = isError ? "#c62828" : "#1b5e20";
}

function escapeHtml(text) {
  return String(text == null ? "" : text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

async function copyTextToClipboard(text) {
  const value = String(text || "");
  if (navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(value);
    return;
  }
  const ta = document.createElement("textarea");
  ta.value = value;
  ta.setAttribute("readonly", "");
  ta.style.position = "fixed";
  ta.style.left = "-9999px";
  document.body.appendChild(ta);
  ta.select();
  document.execCommand("copy");
  document.body.removeChild(ta);
}

function toExternalLink(url) {
  const raw = String(url || "").trim();
  if (!raw) return "";
  if (/^https?:\/\//i.test(raw)) return raw;
  return `https://${raw}`;
}

function getPrimaryPageUrl(row) {
  const landing = String(row.landing_page_url || "").trim();
  const site = String(row.website_url || "").trim();
  return toExternalLink(landing || site);
}

function getLandingSnapshotImgSrc(pageUrl) {
  if (!pageUrl) return "";
  return `https://s.wordpress.com/mshots/v1/${encodeURIComponent(pageUrl)}?w=320&h=200`;
}

const LANDING_SNAPSHOT_PLACEHOLDER =
  "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='100'%3E%3Crect fill='%23eef2f7' width='100%25' height='100%25' rx='4'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' fill='%2394a3b8' font-size='11' font-family='system-ui,sans-serif'%3ENo preview%3C/text%3E%3C/svg%3E";

function syncPlatformOtherField() {
  if (!platformOtherInput || !platformSelect) return;
  const showOther = platformSelect.value === "Custom/Other";
  platformOtherInput.hidden = !showOther;
  if (!showOther) platformOtherInput.value = "";
}

function getPlatformValueFromForm() {
  if (!platformSelect) return "";
  const selected = String(platformSelect.value || "").trim();
  if (selected === "Custom/Other") {
    return String(platformOtherInput?.value || "").trim() || "Custom/Other";
  }
  return selected;
}

function setPlatformInForm(platformRaw) {
  if (!platformSelect) return;
  const platform = String(platformRaw || "").trim();
  if (!platform) {
    platformSelect.value = "";
    if (platformOtherInput) platformOtherInput.value = "";
    syncPlatformOtherField();
    return;
  }
  if (PLATFORM_OPTIONS.has(platform)) {
    platformSelect.value = platform;
    if (platformOtherInput) platformOtherInput.value = "";
  } else {
    platformSelect.value = "Custom/Other";
    if (platformOtherInput) platformOtherInput.value = platform;
  }
  syncPlatformOtherField();
}

function renderUrlCell(url) {
  const href = toExternalLink(url);
  if (!href) return "—";
  return `<span class="landing-url-cell">
    <a href="${escapeHtml(href)}" target="_blank" rel="noopener noreferrer" class="landing-url-open">Open</a>
    <button type="button" class="landing-url-copy-btn" data-url="${escapeHtml(href)}" title="Copy URL to clipboard">Copy</button>
  </span>`;
}

function clearForm() {
  idInput.value = "";
  nameInput.value = "";
  setPlatformInForm("");
  websiteUrlInput.value = "";
  landingPageUrlInput.value = "";
  notesInput.value = "";
  saveBtn.textContent = "Save";
  cancelEditBtn.style.display = "none";
}

function startEdit(row) {
  idInput.value = String(row.id || "");
  nameInput.value = String(row.name || "");
  setPlatformInForm(row.platform || "");
  websiteUrlInput.value = String(row.website_url || "");
  landingPageUrlInput.value = String(row.landing_page_url || "");
  notesInput.value = String(row.notes || "");
  saveBtn.textContent = "Update";
  cancelEditBtn.style.display = "inline-block";
  window.scrollTo({ top: 0, behavior: "smooth" });
}

async function deleteRow(id) {
  const n = Number(id);
  if (!Number.isInteger(n) || n < 1) return;
  if (!window.confirm("Delete this landing page record?")) return;
  const { response, data } = await fetchApiJson(`/api/landing-pages/${n}`, { method: "DELETE" });
  if (!response.ok) throw new Error(data.error || "Failed to delete record");
  showMessage("Landing page record deleted.");
  await loadLandingPages();
}

function renderRows(rows) {
  const list = Array.isArray(rows) ? rows : [];
  listBodyEl.innerHTML = "";
  if (!list.length) {
    listBodyEl.innerHTML =
      '<tr><td colspan="7" class="landing-pages-empty hint"><strong>No landing pages saved yet.</strong> Add your website or campaign pages above to track where your leads are coming from.</td></tr>';
    return;
  }
  for (const row of list) {
    const tr = document.createElement("tr");
    const primaryPage = getPrimaryPageUrl(row);
    const snapSrc = primaryPage ? getLandingSnapshotImgSrc(primaryPage) : "";
    const previewCell =
      primaryPage && snapSrc
        ? `<a href="${escapeHtml(primaryPage)}" target="_blank" rel="noopener noreferrer" class="landing-page-snapshot-link" title="Open page (snapshot is approximate)">
            <img class="landing-page-snapshot" src="${snapSrc}" alt="" width="160" height="100" loading="lazy" decoding="async" />
          </a>`
        : `<span class="landing-page-snapshot-empty">—</span>`;
    tr.innerHTML = `
      <td>${escapeHtml(row.name || "")}</td>
      <td class="landing-page-preview-cell">${previewCell}</td>
      <td>${escapeHtml(row.platform || "")}</td>
      <td>${renderUrlCell(row.website_url)}</td>
      <td>${renderUrlCell(row.landing_page_url)}</td>
      <td title="${escapeHtml(row.notes || "")}">${escapeHtml(row.notes || "")}</td>
      <td>
        <button type="button" class="landing-edit-btn" data-id="${row.id}">Edit</button>
        <button type="button" class="danger landing-delete-btn" data-id="${row.id}">Delete</button>
      </td>
    `;
    const snapImg = tr.querySelector(".landing-page-snapshot");
    if (snapImg) {
      snapImg.addEventListener("error", () => {
        snapImg.src = LANDING_SNAPSHOT_PLACEHOLDER;
        snapImg.removeAttribute("width");
        snapImg.removeAttribute("height");
      });
    }
    tr.querySelector(".landing-edit-btn").addEventListener("click", () => startEdit(row));
    tr.querySelector(".landing-delete-btn").addEventListener("click", async () => {
      try {
        await deleteRow(row.id);
      } catch (error) {
        showMessage(error.message || "Delete failed.", true);
      }
    });
    listBodyEl.appendChild(tr);
  }
}

async function loadLandingPages() {
  const { response, data } = await fetchApiJson("/api/landing-pages");
  if (!response.ok) throw new Error(data.error || "Failed to load landing pages");
  cachedRows = Array.isArray(data) ? data : [];
  renderRows(cachedRows);
}

formEl.addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const id = Number(idInput.value);
    const payload = {
      name: String(nameInput.value || "").trim(),
      platform: getPlatformValueFromForm(),
      websiteUrl: String(websiteUrlInput.value || "").trim(),
      landingPageUrl: String(landingPageUrlInput.value || "").trim(),
      notes: String(notesInput.value || "").trim()
    };
    if (!payload.name) throw new Error("Name is required.");
    const isEdit = Number.isInteger(id) && id > 0;
    const path = isEdit ? `/api/landing-pages/${id}` : "/api/landing-pages";
    const method = isEdit ? "PUT" : "POST";
    const { response, data } = await fetchApiJson(path, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (!response.ok) throw new Error(data.error || "Failed to save record");
    showMessage(isEdit ? "Landing page record updated." : "Landing page record created.");
    clearForm();
    await loadLandingPages();
  } catch (error) {
    showMessage(error.message || "Save failed.", true);
  }
});

cancelEditBtn.addEventListener("click", () => {
  clearForm();
  showMessage("");
});

refreshBtn.addEventListener("click", async () => {
  try {
    await loadLandingPages();
    showMessage("Landing pages refreshed.");
  } catch (error) {
    showMessage(error.message || "Refresh failed.", true);
  }
});

if (platformSelect) {
  platformSelect.addEventListener("change", syncPlatformOtherField);
  syncPlatformOtherField();
}

if (listBodyEl) {
  listBodyEl.addEventListener("click", async (event) => {
    const btn = event.target?.closest?.(".landing-url-copy-btn");
    if (!btn) return;
    const url = btn.getAttribute("data-url");
    if (!url) return;
    try {
      await copyTextToClipboard(url);
      showMessage("URL copied to clipboard.");
    } catch {
      showMessage("Could not copy URL.", true);
    }
  });
}

const backToContactsBtn = document.getElementById("backToContactsBtn");
if (backToContactsBtn) {
  backToContactsBtn.addEventListener("click", () => {
    window.location.href = "/index.html";
  });
}

loadLandingPages().catch((error) => {
  showMessage(error.message || "Failed to load landing pages.", true);
});
