const pastDaysSelect = document.getElementById("pipelinePastDays");
const futureDaysSelect = document.getElementById("pipelineFutureDays");
const refreshBtn = document.getElementById("pipelineRefreshBtn");
const statusHintEl = document.getElementById("pipelineStatusHint");
const nextActionsList = document.getElementById("pipelineNextActionsList");
const pipelineAiSummarizeBtn = document.getElementById("pipelineAiSummarizeBtn");
const pipelineAiStatusBadge = document.getElementById("pipelineAiStatusBadge");
const pipelineAiSummaryDetails = document.getElementById("pipelineAiSummaryDetails");
const pipelineAiSummaryContent = document.getElementById("pipelineAiSummaryContent");
const pipelineAiRobotTip = document.getElementById("pipelineAiRobotTip");
const pipelineAiSummarizeDefaultLabel = pipelineAiSummarizeBtn ? pipelineAiSummarizeBtn.textContent : "Summarize with AI";
const PIPELINE_COLUMN_SCROLL_THRESHOLD = 10;
const PIPELINE_CLOSED_LOST_OUTCOMES = new Set([
  "not interested",
  "cannot afford",
  "employer plan",
  "cannot insure",
  "has coverage",
  "rude",
  "stop"
]);
const PIPELINE_STAGE_UPDATES = {
  newLeads: { status: "NEW", outcome: "" },
  recentlyUpdated: { status: "PENDING" },
  interested: { outcome: "Call Back" },
  appointments: { outcome: "Call Back", follow_up_date: "__today__" },
  closedSold: { status: "CLOSED", outcome: "SOLD" },
  closedLost: { status: "CLOSED", outcome: "Not Interested" }
};
let suppressPipelineCardClickUntil = 0;
let completedFollowUpContactIds = new Set();

async function fetchApiJson(pathAndQuery, init) {
  const response = await fetch(pathAndQuery, {
    credentials: "include",
    ...(init || {})
  });
  let data = {};
  try {
    data = await response.json();
  } catch {
    data = {};
  }
  return { response, data };
}

function parseDateLike(raw) {
  const text = String(raw || "").trim();
  if (!text) return null;
  let normalized = text;
  if (/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(\.\d+)?$/.test(text)) {
    normalized = `${text.replace(" ", "T")}Z`;
  }
  const d = new Date(normalized);
  if (!Number.isNaN(d.getTime())) return d;
  return null;
}

function parseYmd(raw) {
  const text = String(raw || "").trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) return null;
  const d = new Date(`${text}T00:00:00`);
  if (!Number.isNaN(d.getTime())) return d;
  return null;
}

function formatIsoDate(dt) {
  const y = dt.getFullYear();
  const m = String(dt.getMonth() + 1).padStart(2, "0");
  const d = String(dt.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function isWithinLastDays(dateValue, days) {
  if (!(dateValue instanceof Date)) return false;
  const now = new Date();
  const past = new Date(now);
  past.setDate(now.getDate() - Number(days));
  return dateValue >= past && dateValue <= now;
}

function isWithinPreviousDaysWindow(dateValue, days) {
  if (!(dateValue instanceof Date)) return false;
  const now = new Date();
  const windowEnd = new Date(now);
  windowEnd.setDate(now.getDate() - Number(days));
  const windowStart = new Date(windowEnd);
  windowStart.setDate(windowEnd.getDate() - Number(days));
  return dateValue >= windowStart && dateValue < windowEnd;
}

function isWithinNextDays(dateValue, days) {
  if (!(dateValue instanceof Date)) return false;
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  const end = new Date(now);
  end.setDate(now.getDate() + Number(days));
  return dateValue >= now && dateValue <= end;
}

function normalizeOutcome(value) {
  return String(value || "")
    .trim()
    .toLowerCase();
}

function outcomeMatchKey(value) {
  return normalizeOutcome(value).replace(/[\s-]+/g, "");
}

function isCallbackOutcome(value) {
  return outcomeMatchKey(value) === "callback";
}

function hasBulkTag(tagsRaw) {
  return String(tagsRaw || "")
    .split(",")
    .map((t) => t.trim().toLowerCase())
    .filter(Boolean)
    .some((tag) => tag.includes("bulk"));
}

function hasInitialImportTag(tagsRaw) {
  return String(tagsRaw || "")
    .split(",")
    .map((t) => t.trim().toLowerCase())
    .filter(Boolean)
    .some((tag) => tag === "initial-import" || tag.includes("initial-import"));
}

function shouldOmitInitialImportFromPipeline(contact) {
  return hasInitialImportTag(contact?.tags);
}

function setText(id, value) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = String(value);
}

function escapeHtml(text) {
  return String(text || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function contactIdOf(contact) {
  const id = Number(contact?.contact_id || contact?.id || 0);
  return Number.isInteger(id) && id > 0 ? id : 0;
}

function uniqueContactIds(contacts) {
  return [
    ...new Set((Array.isArray(contacts) ? contacts : []).map(contactIdOf).filter((id) => Number.isInteger(id) && id > 0))
  ];
}

function buildContactIdsDrillUrl(contacts, fallbackHref = "/index.html") {
  const ids = uniqueContactIds(contacts);
  if (!ids.length) return fallbackHref;
  const idsStr = ids.join(",");
  const joiner = fallbackHref.includes("?") ? "&" : "?";
  if (idsStr.length > 900 || ids.length > 40) {
    try {
      sessionStorage.setItem("cadencePendingContactIdsFilter", idsStr);
    } catch {
      /* ignore */
    }
    return `${fallbackHref}${joiner}contactIdBatch=1`;
  }
  return `${fallbackHref}${joiner}contactIds=${encodeURIComponent(idsStr)}`;
}

function recentContacts(contacts, days, limit = 25) {
  return (Array.isArray(contacts) ? contacts : [])
    .filter((contact) => isWithinLastDays(parseDateLike(contact?.updated_at) || parseDateLike(contact?.created_at), days))
    .sort((a, b) => {
      const da = parseDateLike(a?.updated_at) || parseDateLike(a?.created_at);
      const db = parseDateLike(b?.updated_at) || parseDateLike(b?.created_at);
      return (db?.getTime() || 0) - (da?.getTime() || 0);
    })
    .slice(0, limit);
}

function mergeContactsById(...groups) {
  const out = [];
  const seen = new Set();
  for (const group of groups) {
    for (const contact of Array.isArray(group) ? group : []) {
      const id = contactIdOf(contact);
      if (!id || seen.has(id)) continue;
      seen.add(id);
      out.push(contact);
    }
  }
  return out;
}

function formatShortDate(date) {
  return date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

function isContactClosedOut(contact) {
  const outcome = normalizeOutcome(contact?.outcome);
  if (outcome === "sold" || PIPELINE_CLOSED_LOST_OUTCOMES.has(outcome)) return true;
  return String(contact?.status || "")
    .trim()
    .toUpperCase() === "CLOSED";
}

function isFollowUpCompletedForContact(contact) {
  const id = contactIdOf(contact);
  if (id && completedFollowUpContactIds.has(id)) return true;
  const condition = String(contact?.condition || "")
    .trim()
    .toLowerCase();
  return condition === "completed";
}

function pipelineTaskSectionHref(contactId) {
  const id = Number(contactId);
  if (!Number.isInteger(id) || id < 1) return "";
  return `/contact.html?id=${encodeURIComponent(String(id))}&focus=tasks`;
}

function wrapPipelineTaskBadge(contactId, badgeHtml) {
  const href = pipelineTaskSectionHref(contactId);
  if (!href || !badgeHtml) return badgeHtml;
  return `<a class="pipeline-follow-up-badge-link" href="${href}">${badgeHtml}</a>`;
}

function followUpBadge(contact) {
  const contactId = contactIdOf(contact);
  if (isContactClosedOut(contact) || isFollowUpCompletedForContact(contact)) {
    return "";
  }
  const rawDate = String(contact?.task_date || contact?.follow_up_date || "").trim();
  if (!rawDate) {
    return wrapPipelineTaskBadge(
      contactId,
      '<span class="pipeline-follow-up-badge pipeline-follow-up-badge--none">No follow-up</span>'
    );
  }
  const date = parseYmd(rawDate);
  if (!date) {
    return wrapPipelineTaskBadge(
      contactId,
      '<span class="pipeline-follow-up-badge pipeline-follow-up-badge--future">Follow-up set</span>'
    );
  }
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  date.setHours(0, 0, 0, 0);
  const diffDays = Math.round((date.getTime() - today.getTime()) / 86_400_000);
  const time = String(contact?.task_time || contact?.follow_up_time || "").trim();
  const suffix = time ? ` ${escapeHtml(time)}` : "";
  if (diffDays < 0) {
    return wrapPipelineTaskBadge(
      contactId,
      `<span class="pipeline-follow-up-badge pipeline-follow-up-badge--overdue">Overdue ${escapeHtml(formatShortDate(date))}${suffix}</span>`
    );
  }
  if (diffDays === 0) {
    return wrapPipelineTaskBadge(
      contactId,
      `<span class="pipeline-follow-up-badge pipeline-follow-up-badge--today">Today${suffix}</span>`
    );
  }
  return wrapPipelineTaskBadge(
    contactId,
    `<span class="pipeline-follow-up-badge pipeline-follow-up-badge--future">${escapeHtml(formatShortDate(date))}${suffix}</span>`
  );
}

function getPastDays() {
  const n = Number(pastDaysSelect?.value || 7);
  return Number.isFinite(n) && n > 0 ? n : 7;
}

function getFutureDays() {
  const n = Number(futureDaysSelect?.value || 14);
  return Number.isFinite(n) && n > 0 ? n : 14;
}

function formatTrend(current, previous) {
  const cur = Number(current || 0);
  const prev = Number(previous || 0);
  const diff = cur - prev;
  if (diff > 0) return `<span class="pipeline-trend pipeline-trend--up" title="Up ${diff} vs prior period">↑${diff}</span>`;
  if (diff < 0) return `<span class="pipeline-trend pipeline-trend--down" title="Down ${Math.abs(diff)} vs prior period">↓${Math.abs(diff)}</span>`;
  return `<span class="pipeline-trend pipeline-trend--flat" title="Unchanged vs prior period">—</span>`;
}

function setTrendHtml(id, current, previous) {
  const el = document.getElementById(id);
  if (!el) return;
  el.innerHTML = formatTrend(current, previous);
}

function buildNewLeadsDrillUrl(pastDays) {
  const end = new Date();
  const start = new Date(end);
  start.setDate(end.getDate() - pastDays);
  return `/index.html?createdFrom=${encodeURIComponent(formatIsoDate(start))}&createdTo=${encodeURIComponent(formatIsoDate(end))}`;
}

function updateDrillLinks(pastDays, futureDays) {
  const newLeads = document.getElementById("pipelineNewLeadsDrill");
  if (newLeads) newLeads.href = buildNewLeadsDrillUrl(pastDays);

  setText("pipelineNewLeadsKpiLabel", `New Leads Last ${pastDays} Days`);
  setText("pipelineContactedKpiLabel", `Recently Updated Last ${pastDays} Days`);
  setText("pipelineInterestedKpiLabel", `Interested Last ${pastDays} Days`);
  setText("pipelineAppointmentsKpiLabel", `Appointments Scheduled Next ${futureDays} Days`);
  setText("pipelineNewLeadsColumnLabel", `New Leads Last ${pastDays} Days`);
  setText("pipelineContactedColumnLabel", `Recently Updated Last ${pastDays} Days`);
  setText("pipelineInterestedColumnLabel", `Interested Last ${pastDays} Days`);
  setText("pipelineAppointmentsColumnLabel", `Appointments Scheduled Next ${futureDays} Days`);
  setText("pipelineClosedSoldKpiLabel", `Total Closed SOLD Last ${pastDays} Days`);
  setText("pipelineClosedLostKpiLabel", `Total Closed Lost Last ${pastDays} Days`);
  setText("pipelineClosedSoldColumnLabel", `Total Closed SOLD Last ${pastDays} Days`);
  setText("pipelineClosedLostColumnLabel", `Total Closed Lost Last ${pastDays} Days`);
}

function updateMetricDrillLinksFromBuckets(metrics, pastDays) {
  const setHref = (id, href) => {
    const el = document.getElementById(id);
    if (el) el.href = href;
  };
  setHref("pipelineNewLeadsDrill", buildContactIdsDrillUrl(metrics.bucket.newLeads, buildNewLeadsDrillUrl(pastDays)));
  setHref("pipelineContactedDrill", buildContactIdsDrillUrl(metrics.bucket.contacted, "/index.html?sortBy=details_changed"));
  setHref("pipelineInterestedDrill", buildContactIdsDrillUrl(metrics.bucket.interested, "/index.html?outcome=Call%20Back"));
  setHref("pipelineAppointmentsDrill", buildContactIdsDrillUrl(metrics.bucket.appointments, "/calendar.html"));
  setHref("pipelineClosedSoldDrill", buildContactIdsDrillUrl(metrics.bucket.closedSold, "/index.html?outcome=SOLD"));
  setHref("pipelineClosedLostDrill", buildContactIdsDrillUrl(metrics.bucket.closedLost, "/index.html?outcome=Not%20Interested"));
}

function applyPipelineColumnScroll(host, cardCount) {
  if (!host) return;
  const needsScroll = cardCount > PIPELINE_COLUMN_SCROLL_THRESHOLD;
  host.classList.toggle("pipeline-column-cards--scroll", needsScroll);
  host.style.maxHeight = "";
  if (!needsScroll) return;
  const cards = [...host.querySelectorAll(".pipeline-card")];
  if (!cards.length) return;
  let maxH = 16;
  const visibleCount = Math.min(PIPELINE_COLUMN_SCROLL_THRESHOLD, cards.length);
  for (let i = 0; i < visibleCount; i += 1) {
    maxH += cards[i].getBoundingClientRect().height;
    if (i < visibleCount - 1) maxH += 8;
  }
  host.style.maxHeight = `${Math.ceil(maxH)}px`;
}

function renderCards(hostId, contacts, emptyHint, options = {}) {
  const host = document.getElementById(hostId);
  if (!host) return;
  const allRows = Array.isArray(contacts) ? contacts : [];
  const rows = allRows;
  const stage = String(options.stage || host.closest(".pipeline-column")?.getAttribute("data-pipeline-stage") || "");
  if (!rows.length) {
    host.classList.remove("pipeline-column-cards--scroll");
    host.style.maxHeight = "";
    host.innerHTML = `<p class="pipeline-column-empty hint">${escapeHtml(emptyHint || "No contacts in this stage yet.")}</p>`;
    return;
  }
  host.innerHTML = rows
    .map((c) => {
      const name = escapeHtml(String(c?.full_name || c?.email || `Contact #${c?.contact_id || c?.id || ""}`).trim());
      const outcome = escapeHtml(String(c?.outcome || "—"));
      const contactId = contactIdOf(c);
      const clickAttrs = Number.isInteger(contactId) && contactId > 0 ? ` data-contact-id="${contactId}"` : "";
      const clickableClass = clickAttrs ? " pipeline-card--clickable" : "";
      const draggableAttr = clickAttrs ? ' draggable="true"' : "";
      const nameMarkup = contactId
        ? `<a class="pipeline-card-name" href="/contact.html?id=${encodeURIComponent(String(contactId))}">${name}</a>`
        : name;
      const badge = followUpBadge(c);
      const metaRow = badge ? `<div class="pipeline-card-meta-row">${badge}</div>` : "";
      return `<article class="pipeline-card${clickableClass}"${clickAttrs} data-pipeline-source-stage="${escapeHtml(stage)}"${draggableAttr}>
        <h4>${nameMarkup}</h4>
        <p>Outcome: ${outcome}</p>
        ${metaRow}
      </article>`;
    })
    .join("");
  applyPipelineColumnScroll(host, allRows.length);

  host.querySelectorAll(".pipeline-card[data-contact-id]").forEach((card) => {
    card.addEventListener("click", (event) => {
      if (performance.now() < suppressPipelineCardClickUntil) return;
      if (event.target?.closest?.("a")) return;
      const id = Number(card.getAttribute("data-contact-id"));
      if (!Number.isInteger(id) || id < 1) return;
      window.location.href = `/contact.html?id=${encodeURIComponent(String(id))}`;
    });
    card.addEventListener("dragstart", (event) => {
      const id = Number(card.getAttribute("data-contact-id"));
      if (!Number.isInteger(id) || id < 1) {
        event.preventDefault();
        return;
      }
      event.dataTransfer.effectAllowed = "move";
      event.dataTransfer.setData("text/plain", String(id));
      event.dataTransfer.setData("application/x-pipeline-contact-id", String(id));
      event.dataTransfer.setData(
        "application/x-pipeline-source-stage",
        String(card.getAttribute("data-pipeline-source-stage") || "")
      );
      card.classList.add("is-dragging");
    });
    card.addEventListener("dragend", () => {
      suppressPipelineCardClickUntil = performance.now() + 250;
      card.classList.remove("is-dragging");
      document.querySelectorAll(".pipeline-column.is-drag-over").forEach((col) => col.classList.remove("is-drag-over"));
    });
  });
}

function setLastRefreshed(ok = true) {
  const el = document.getElementById("pipelineLastRefreshed");
  if (!el) return;
  if (ok) {
    el.textContent = `Last updated just now · ${new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}`;
    el.style.color = "";
  } else {
    el.textContent = "Could not refresh snapshot.";
    el.style.color = "#b91c1c";
  }
}

function setStatusHint(text, isError = false) {
  if (!statusHintEl) return;
  const str = String(text || "").trim();
  statusHintEl.hidden = !str;
  statusHintEl.textContent = str;
  statusHintEl.style.color = isError ? "#b91c1c" : "#64748b";
}

function renderCloseRate(closedSold, closedLost) {
  const sold = Number(closedSold || 0);
  const lost = Number(closedLost || 0);
  const total = sold + lost;
  const rateEl = document.getElementById("pipelineCloseRate");
  const noteEl = document.getElementById("pipelineCloseRateNote");
  if (!rateEl) return;
  if (total === 0) {
    rateEl.textContent = "—";
    if (noteEl) noteEl.textContent = "No closed deals yet — update contact outcomes to track close rate.";
    return;
  }
  const pct = Math.round((sold / total) * 100);
  rateEl.textContent = `${pct}%`;
  if (noteEl) noteEl.textContent = `${sold} sold · ${lost} lost`;
}

function formatPipelineSummaryMarkdown(text) {
  const lines = String(text || "").split(/\r?\n/);
  const parts = [];
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    if (/^##\s+/.test(trimmed)) {
      parts.push(`<h4 class="pipeline-ai-summary-h4">${escapeHtml(trimmed.replace(/^##\s+/, ""))}</h4>`);
    } else if (/^(SNAPSHOT|WHAT NEEDS ATTENTION|TOP 3 ACTIONS)\b/i.test(trimmed)) {
      parts.push(`<h4 class="pipeline-ai-summary-h4">${escapeHtml(trimmed)}</h4>`);
    } else if (/^[-*]\s+/.test(trimmed)) {
      parts.push(`<p class="pipeline-ai-summary-bullet">• ${escapeHtml(trimmed.replace(/^[-*]\s+/, ""))}</p>`);
    } else if (/^\d+\.\s+/.test(trimmed)) {
      parts.push(`<p class="pipeline-ai-summary-numbered">${escapeHtml(trimmed)}</p>`);
    } else {
      parts.push(`<p>${escapeHtml(trimmed)}</p>`);
    }
  }
  return parts.join("");
}

function playPipelineRobot() {
  const robot = document.querySelector(".pipeline-ai-robot lottie-player");
  if (robot) window.setTimeout(() => { try { robot.play(); } catch { /* ignore */ } }, 50);
}

function setPipelineAiStatus(state, text) {
  if (!pipelineAiStatusBadge) return;
  pipelineAiStatusBadge.dataset.state = state;
  pipelineAiStatusBadge.textContent = text;
}

function setPipelineAiSummarizing(loading) {
  if (!pipelineAiSummarizeBtn) return;
  pipelineAiSummarizeBtn.disabled = Boolean(loading) || pipelineAiSummarizeBtn.dataset.aiReady === "0";
  pipelineAiSummarizeBtn.textContent = loading ? "Summarizing…" : pipelineAiSummarizeDefaultLabel;
}

function clearPipelineAiSummary() {
  if (pipelineAiSummaryContent) pipelineAiSummaryContent.innerHTML = "";
  if (pipelineAiSummaryDetails) {
    pipelineAiSummaryDetails.hidden = true;
    pipelineAiSummaryDetails.open = false;
  }
}

function renderPipelineAiSummary(data) {
  if (!pipelineAiSummaryContent || !pipelineAiSummaryDetails) return;
  const snap = data?.snapshot || {};
  const statsHtml = `
    <div class="pipeline-ai-stats">
      <span><strong>${escapeHtml(String(snap.totalContacts ?? "—"))}</strong> contacts</span>
      <span><strong>${escapeHtml(String(snap.closeRate != null ? `${snap.closeRate}%` : "—"))}</strong> close rate</span>
      <span><strong>${escapeHtml(String(snap.newLeads ?? "—"))}</strong> new leads (${escapeHtml(String(snap.pastDays || ""))}d)</span>
      <span><strong>${escapeHtml(String(snap.staleLeads ?? "—"))}</strong> NEW no activity (7d+)</span>
    </div>`;
  const summaryHtml = formatPipelineSummaryMarkdown(data?.summary || "");
  pipelineAiSummaryContent.innerHTML = `${statsHtml}<div class="pipeline-ai-summary-body">${summaryHtml}</div>
    <p class="hint pipeline-ai-summary-note">Review before acting — AI suggestions are not guaranteed accurate.</p>`;
  pipelineAiSummaryDetails.hidden = false;
  pipelineAiSummaryDetails.open = true;
  if (pipelineAiRobotTip) pipelineAiRobotTip.textContent = "Summary ready — review the suggestions below.";
  playPipelineRobot();
}

async function loadPipelineAiStatus() {
  if (!pipelineAiStatusBadge) return;
  try {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), 12000);
    const { response, data } = await fetchApiJson("/api/assistant/status", { signal: controller.signal });
    window.clearTimeout(timer);
    if (!response.ok) throw new Error(data.error || "Could not reach AI.");
    if (data.configured) {
      setPipelineAiStatus("ready", "AI ready");
      if (pipelineAiSummarizeBtn) pipelineAiSummarizeBtn.dataset.aiReady = "1";
      if (pipelineAiRobotTip) pipelineAiRobotTip.textContent = "Click Summarize — I'll read your pipeline stats.";
    } else {
      setPipelineAiStatus("unconfigured", "AI not configured");
      if (pipelineAiSummarizeBtn) {
        pipelineAiSummarizeBtn.dataset.aiReady = "0";
        pipelineAiSummarizeBtn.disabled = true;
      }
      if (pipelineAiRobotTip) pipelineAiRobotTip.textContent = "Ask your administrator to add the Claude API key.";
    }
  } catch (err) {
    const timedOut = err && (err.name === "AbortError" || /aborted/i.test(String(err.message || "")));
    setPipelineAiStatus("error", timedOut ? "AI check timed out" : "AI unavailable");
    if (pipelineAiSummarizeBtn) {
      pipelineAiSummarizeBtn.dataset.aiReady = "0";
      pipelineAiSummarizeBtn.disabled = true;
    }
    if (pipelineAiRobotTip) {
      pipelineAiRobotTip.textContent = timedOut
        ? "Server slow or offline — refresh, or open AI Assistant."
        : "Could not reach AI — refresh or open AI Assistant.";
    }
  }
}

async function runPipelineAiSummary() {
  if (!pipelineAiSummarizeBtn || pipelineAiSummarizeBtn.dataset.aiReady === "0") return;
  const pastDays = getPastDays();
  const futureDays = getFutureDays();
  setPipelineAiSummarizing(true);
  if (pipelineAiRobotTip) pipelineAiRobotTip.textContent = "Reading your pipeline…";
  playPipelineRobot();
  try {
    const { response, data } = await fetchApiJson("/api/assistant/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode: "pipeline", pastDays, futureDays })
    });
    if (!response.ok) throw new Error(data.error || "Could not summarize pipeline.");
    renderPipelineAiSummary(data);
  } catch (err) {
    if (pipelineAiSummaryContent && pipelineAiSummaryDetails) {
      pipelineAiSummaryContent.innerHTML = `<p class="pipeline-ai-error">${escapeHtml(err.message || "Could not summarize pipeline.")}</p>`;
      pipelineAiSummaryDetails.hidden = false;
      pipelineAiSummaryDetails.open = true;
    }
  } finally {
    setPipelineAiSummarizing(false);
  }
}

function renderNextActions(metrics, pastDays) {
  if (!nextActionsList) return;
  const items = [];
  if (metrics.newLeadsLast5 > 0) {
    items.push({
      label: `Follow up with ${metrics.newLeadsLast5} new lead${metrics.newLeadsLast5 === 1 ? "" : "s"}`,
      href: buildContactIdsDrillUrl(metrics.bucket.newLeads, buildNewLeadsDrillUrl(pastDays))
    });
  }
  if (metrics.interestedLast14 > 0) {
    items.push({
      label: `Call back ${metrics.interestedLast14} interested contact${metrics.interestedLast14 === 1 ? "" : "s"}`,
      href: buildContactIdsDrillUrl(metrics.bucket.interested, "/index.html?outcome=Call%20Back")
    });
  }
  if (metrics.appointmentsNext14 > 0) {
    items.push({
      label: `Review ${metrics.appointmentsNext14} upcoming appointment${metrics.appointmentsNext14 === 1 ? "" : "s"}`,
      href: buildContactIdsDrillUrl(metrics.bucket.appointments, "/index.html")
    });
  }
  if (metrics.outcomeChangedLast5 > 0) {
    items.push({
      label: "Review contacts with recent updates",
      href: buildContactIdsDrillUrl(metrics.bucket.contacted, "/index.html?sortBy=details_changed")
    });
  }
  if (metrics.recentClosedSold > 0) {
    items.push({
      label: `Celebrate and request referrals from ${metrics.recentClosedSold} recently sold client${metrics.recentClosedSold === 1 ? "" : "s"}`,
      href: buildContactIdsDrillUrl(metrics.bucket.recentClosedSold, "/index.html")
    });
  } else if (metrics.closedSold > 0) {
    const soldContacts = metrics.bucket.closedSold.slice(0, 25);
    items.push({
      label: "Celebrate and request referrals from sold clients",
      href: buildContactIdsDrillUrl(soldContacts, "/index.html?outcome=SOLD")
    });
  }
  if (!items.length) {
    items.push({ label: "Add your first contact to start building pipeline", href: "/" });
    items.push({ label: "Import or create contacts in Contacts Workspace", href: "/" });
  }
  nextActionsList.innerHTML = items
    .map((item) => `<li><a href="${escapeHtml(item.href)}">${escapeHtml(item.label)} <span aria-hidden="true">&rarr;</span></a></li>`)
    .join("");
}

async function loadAllContacts() {
  const allRows = [];
  let page = 1;
  const limit = 500;
  while (page <= 200) {
    const { response, data } = await fetchApiJson(`/api/contacts?q=&status=&page=${page}&limit=${limit}`);
    if (!response.ok) throw new Error(data.error || "Failed to load contacts for pipeline");
    const rows = Array.isArray(data?.items) ? data.items : Array.isArray(data) ? data : [];
    if (!rows.length) break;
    allRows.push(...rows);
    if (rows.length < limit) break;
    page += 1;
  }
  return allRows;
}

async function loadCompletedFollowUpContactIds() {
  const { response, data } = await fetchApiJson("/api/pipeline/completed-follow-ups");
  if (!response.ok) throw new Error(data.error || "Failed to load completed follow-up status");
  const ids = Array.isArray(data?.contactIds) ? data.contactIds : [];
  completedFollowUpContactIds = new Set(
    ids.map((id) => Number(id)).filter((id) => Number.isInteger(id) && id > 0)
  );
}

async function loadRecentOutcomeChangedContacts(days = 7) {
  const { response, data } = await fetchApiJson(`/api/pipeline/status-changes?days=${encodeURIComponent(String(days))}`);
  if (!response.ok) throw new Error(data.error || "Failed to load outcome change metrics");
  return Array.isArray(data?.items) ? data.items : [];
}

async function loadScheduledTaskContacts(days = 14) {
  const { response, data } = await fetchApiJson(`/api/pipeline/scheduled-tasks?days=${encodeURIComponent(String(days))}`);
  if (!response.ok) throw new Error(data.error || "Failed to load scheduled tasks metrics");
  return Array.isArray(data?.items) ? data.items : [];
}

async function updateContactForPipelineStage(contactId, stage) {
  const id = Number(contactId);
  const patch = PIPELINE_STAGE_UPDATES[String(stage || "")];
  if (!Number.isInteger(id) || id < 1 || !patch) return false;
  const payload = { ...patch };
  if (payload.follow_up_date === "__today__") {
    payload.follow_up_date = formatIsoDate(new Date());
  }
  const { response, data } = await fetchApiJson(`/api/contacts/${encodeURIComponent(String(id))}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  if (!response.ok) throw new Error(data.error || "Could not update contact stage.");
  return true;
}

function stageLabel(stage) {
  const labels = {
    newLeads: "New Leads",
    recentlyUpdated: "Recently Updated",
    interested: "Interested",
    appointments: "Appointments",
    closedSold: "Closed SOLD",
    closedLost: "Closed Lost"
  };
  return labels[String(stage || "")] || "Pipeline";
}

function wirePipelineDragAndDrop() {
  document.querySelectorAll(".pipeline-column[data-pipeline-stage]").forEach((column) => {
    column.addEventListener("dragover", (event) => {
      const types = Array.from(event.dataTransfer?.types || []);
      if (!types.includes("application/x-pipeline-contact-id") && !types.includes("text/plain")) return;
      event.preventDefault();
      event.dataTransfer.dropEffect = "move";
      column.classList.add("is-drag-over");
    });
    column.addEventListener("dragleave", (event) => {
      if (event.relatedTarget && column.contains(event.relatedTarget)) return;
      column.classList.remove("is-drag-over");
    });
    column.addEventListener("drop", async (event) => {
      const contactId = event.dataTransfer.getData("application/x-pipeline-contact-id") || event.dataTransfer.getData("text/plain");
      const sourceStage = event.dataTransfer.getData("application/x-pipeline-source-stage");
      const targetStage = String(column.getAttribute("data-pipeline-stage") || "");
      if (!contactId || !targetStage) return;
      event.preventDefault();
      column.classList.remove("is-drag-over");
      if (sourceStage === targetStage) return;
      try {
        await updateContactForPipelineStage(contactId, targetStage);
        setStatusHint(`Status updated to ${stageLabel(targetStage)}.`, false);
        await loadPipeline();
      } catch (error) {
        setStatusHint(error.message || "Could not update pipeline stage.", true);
      }
    });
  });
}

function computePipelineMetrics(contacts, pastDays, futureDays) {
  const interestedOutcomeKeys = new Set(["callback", "veryinterested"]);

  let newLeadsLast5 = 0;
  let newLeadsPrev = 0;
  let interestedLast14 = 0;
  let interestedPrev = 0;
  let appointmentsNext14 = 0;
  let closedSold = 0;
  let closedSoldPrev = 0;
  let closedLost = 0;
  let closedLostPrev = 0;
  const bucket = {
    newLeads: [],
    contacted: [],
    interested: [],
    appointments: [],
    recentClosedSold: [],
    closedSold: [],
    closedLost: []
  };

  for (const c of contacts) {
    const omitFromNewLeads = shouldOmitInitialImportFromPipeline(c);
    const outcome = normalizeOutcome(c?.outcome);
    const outcomeKey = outcomeMatchKey(outcome);
    const createdAt = parseDateLike(c?.created_at);
    const changedAt = parseDateLike(c?.updated_at) || createdAt;
    const followUpDate = parseYmd(c?.follow_up_date);

    if (!omitFromNewLeads && isWithinLastDays(createdAt, pastDays) && !hasBulkTag(c?.tags)) {
      newLeadsLast5 += 1;
      bucket.newLeads.push(c);
    } else if (!omitFromNewLeads && isWithinPreviousDaysWindow(createdAt, pastDays) && !hasBulkTag(c?.tags)) {
      newLeadsPrev += 1;
    }

    if (interestedOutcomeKeys.has(outcomeKey) && isWithinLastDays(changedAt, pastDays)) {
      if (!isFollowUpCompletedForContact(c) && !isContactClosedOut(c)) {
        interestedLast14 += 1;
        bucket.interested.push(c);
      }
    } else if (interestedOutcomeKeys.has(outcomeKey) && isWithinPreviousDaysWindow(changedAt, pastDays)) {
      interestedPrev += 1;
    }

    if (isCallbackOutcome(outcome) && isWithinNextDays(followUpDate, futureDays)) {
      appointmentsNext14 += 1;
      bucket.appointments.push(c);
    }
    if (outcome === "sold") {
      if (isWithinLastDays(changedAt, pastDays)) {
        closedSold += 1;
        bucket.closedSold.push(c);
      } else if (isWithinPreviousDaysWindow(changedAt, pastDays)) {
        closedSoldPrev += 1;
      }
    }
    if (PIPELINE_CLOSED_LOST_OUTCOMES.has(outcome)) {
      if (isWithinLastDays(changedAt, pastDays)) {
        closedLost += 1;
        bucket.closedLost.push(c);
      } else if (isWithinPreviousDaysWindow(changedAt, pastDays)) {
        closedLostPrev += 1;
      }
    }
  }

  bucket.recentClosedSold = recentContacts(bucket.closedSold, pastDays);

  return {
    total: contacts.length,
    newLeadsLast5,
    newLeadsPrev,
    interestedLast14,
    interestedPrev,
    appointmentsNext14,
    closedSold,
    closedSoldPrev,
    closedLost,
    closedLostPrev,
    recentClosedSold: bucket.recentClosedSold.length,
    bucket
  };
}

async function loadPipeline() {
  const pastDays = getPastDays();
  const futureDays = getFutureDays();
  updateDrillLinks(pastDays, futureDays);
  setStatusHint("");

  const contacts = await loadAllContacts();
  const [statusChangedContacts, scheduledTaskContacts] = await Promise.all([
    loadRecentOutcomeChangedContacts(pastDays),
    loadScheduledTaskContacts(futureDays),
    loadCompletedFollowUpContactIds().catch(() => {
      completedFollowUpContactIds = new Set();
    })
  ]);
  const m = computePipelineMetrics(contacts, pastDays, futureDays);

  m.outcomeChangedLast5 = statusChangedContacts.length;
  m.bucket.contacted = statusChangedContacts;
  m.bucket.appointments = mergeContactsById(scheduledTaskContacts, m.bucket.appointments);
  m.appointmentsNext14 = m.bucket.appointments.length;
  updateMetricDrillLinksFromBuckets(m, pastDays);

  setText("pipelineNewLeadsKpiCount", m.newLeadsLast5);
  setText("pipelineNewLeadsCount", m.newLeadsLast5);
  setText("pipelineContactedKpiCount", m.outcomeChangedLast5);
  setText("pipelineContactedColumnCount", m.outcomeChangedLast5);
  setText("pipelineInterestedKpiCount", m.interestedLast14);
  setText("pipelineInterestedColumnCount", m.interestedLast14);
  setText("pipelineAppointmentsKpiCount", m.appointmentsNext14);
  setText("pipelineAppointmentsColumnCount", m.appointmentsNext14);
  setText("pipelineClosedSoldKpiCount", m.closedSold);
  setText("pipelineClosedSoldColumnCount", m.closedSold);
  setText("pipelineClosedLostKpiCount", m.closedLost);
  setText("pipelineClosedLostColumnCount", m.closedLost);

  setTrendHtml("pipelineNewLeadsTrend", m.newLeadsLast5, m.newLeadsPrev);
  setTrendHtml("pipelineInterestedTrend", m.interestedLast14, m.interestedPrev);
  setTrendHtml("pipelineContactedTrend", m.outcomeChangedLast5, 0);
  setTrendHtml("pipelineAppointmentsTrend", m.appointmentsNext14, 0);
  setTrendHtml("pipelineClosedSoldTrend", m.closedSold, m.closedSoldPrev);
  setTrendHtml("pipelineClosedLostTrend", m.closedLost, m.closedLostPrev);

  renderCloseRate(m.closedSold, m.closedLost);
  renderNextActions(m, pastDays);

  renderCards("pipelineNewLeadsCards", m.bucket.newLeads, `No new leads in the last ${pastDays} days.`, {
    stage: "newLeads"
  });
  renderCards("pipelineContactedCards", m.bucket.contacted, `No recent updates in the last ${pastDays} days.`, {
    stage: "recentlyUpdated"
  });
  renderCards("pipelineInterestedCards", m.bucket.interested, `No interested contacts in the last ${pastDays} days.`, {
    stage: "interested"
  });
  renderCards("pipelineAppointmentsCards", m.bucket.appointments, `No scheduled tasks in the next ${futureDays} days.`, {
    stage: "appointments"
  });
  renderCards("pipelineClosedSoldCards", m.bucket.closedSold, `No sold contacts in the last ${pastDays} days.`, {
    stage: "closedSold"
  });
  renderCards("pipelineClosedLostCards", m.bucket.closedLost, `No lost outcomes in the last ${pastDays} days.`, {
    stage: "closedLost"
  });

  if (m.total === 0) {
    setStatusHint("Your pipeline is empty — add contacts in Contacts Workspace to populate these metrics.");
  } else if (contacts.some((c) => hasInitialImportTag(c?.tags))) {
    setStatusHint(
      "Imported book contacts are hidden from New leads counts. They still appear in sold, follow-ups, and Contacts Workspace."
    );
  } else if (
    m.newLeadsLast5 === 0 &&
    m.outcomeChangedLast5 === 0 &&
    m.interestedLast14 === 0 &&
    m.appointmentsNext14 === 0 &&
    m.closedSold === 0 &&
    m.closedLost === 0
  ) {
    setStatusHint("No activity in the selected time windows yet. Zeros are normal for a new account — adjust the day ranges above or add contacts.");
  }

  setLastRefreshed(true);
}

if (pipelineAiSummarizeBtn) {
  pipelineAiSummarizeBtn.addEventListener("click", () => {
    runPipelineAiSummary().catch((err) => {
      if (pipelineAiSummaryContent && pipelineAiSummaryDetails) {
        pipelineAiSummaryContent.innerHTML = `<p class="pipeline-ai-error">${escapeHtml(err.message || "Could not summarize pipeline.")}</p>`;
        pipelineAiSummaryDetails.hidden = false;
        pipelineAiSummaryDetails.open = true;
      }
    });
  });
}

loadPipelineAiStatus();

if (pastDaysSelect) {
  pastDaysSelect.addEventListener("change", () => {
    clearPipelineAiSummary();
    loadPipeline().catch((err) => {
      setLastRefreshed(false);
      setStatusHint(err.message || "Failed to load pipeline.", true);
    });
  });
}

if (futureDaysSelect) {
  futureDaysSelect.addEventListener("change", () => {
    clearPipelineAiSummary();
    loadPipeline().catch((err) => {
      setLastRefreshed(false);
      setStatusHint(err.message || "Failed to load pipeline.", true);
    });
  });
}

if (refreshBtn) {
  refreshBtn.addEventListener("click", () => {
    clearPipelineAiSummary();
    loadPipeline().catch((err) => {
      setLastRefreshed(false);
      setStatusHint(err.message || "Failed to load pipeline.", true);
    });
  });
}

wirePipelineDragAndDrop();

loadPipeline().catch((err) => {
  setLastRefreshed(false);
  setStatusHint(err.message || "Failed to load pipeline summary. Check your connection and try Refresh.", true);
});
