(function () {
  const form = document.getElementById("agentDemoForm");
  const messageEl = document.getElementById("agentDemoMessage");
  const submitBtn = document.getElementById("agentDemoSubmit");
  const formWrap = document.getElementById("agentDemoFormWrap");
  const card = document.getElementById("agentDemoCard");

  if (!form || !messageEl || !submitBtn) return;

  function setMessage(text, isError) {
    messageEl.textContent = text || "";
    messageEl.classList.remove("signup-message--error", "signup-message--ok");
    if (!text) return;
    messageEl.classList.add(isError ? "signup-message--error" : "signup-message--ok");
  }

  function escapeHtml(s) {
    return String(s || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function showSuccess(data) {
    formWrap.innerHTML = `
      <div class="signup-success contact-sales-success">
        <svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
          <polyline points="22 4 12 14.01 9 11.01"/>
        </svg>
        <h2>Demo request received</h2>
        <p>
          We will contact <strong>${escapeHtml(data.email || "")}</strong> to schedule your Cadence walkthrough.
        </p>
        <a href="/signup.html" class="welcome-btn welcome-btn--primary welcome-btn--lg">Start 14-day free trial</a>
        <p class="signup-cancel-note">Or <a href="/welcome.html">return to overview</a></p>
      </div>
    `;
    card.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    setMessage("");

    const name = String(form.name?.value || "").trim();
    const email = String(form.email?.value || "").trim().toLowerCase();
    const phone = String(form.phone?.value || "").trim();
    const companyName = String(form.companyName?.value || "").trim();
    const companySize = String(form.companySize?.value || "").trim();
    const preferredTime = String(form.preferredTime?.value || "").trim();
    const focus = String(form.message?.value || "").trim();

    if (!name) {
      setMessage("Please enter your name.", true);
      return;
    }
    if (!email || !email.includes("@")) {
      setMessage("Please enter a valid email address.", true);
      return;
    }
    if (!companyName) {
      setMessage("Please enter your agency or company name.", true);
      return;
    }
    if (!companySize) {
      setMessage("Please select your agency size.", true);
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = "Submitting...";

    const message = [
      "Agent demo request.",
      preferredTime ? `Best time to contact: ${preferredTime}` : "",
      focus ? `Demo focus: ${focus}` : ""
    ]
      .filter(Boolean)
      .join("\n\n");

    try {
      const res = await fetch("/api/sales/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          email,
          phone,
          country: "United States",
          companyName,
          companySize,
          hearAbout: "Agent demo page",
          message
        })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Could not submit your demo request. Please try again.");
      showSuccess(data);
    } catch (err) {
      setMessage(err.message || "Something went wrong.", true);
      submitBtn.disabled = false;
      submitBtn.textContent = "Request demo";
    }
  });
})();
