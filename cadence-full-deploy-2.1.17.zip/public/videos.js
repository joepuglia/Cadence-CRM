const messageEl = document.getElementById("message");
const videosForm = document.getElementById("videosForm");
const refreshBtn = document.getElementById("videosRefreshBtn");
const videosListEl = document.getElementById("videosList");
const sourceTypeEl = document.getElementById("videoSourceType");
const titleEl = document.getElementById("videoTitle");
const urlEl = document.getElementById("videoUrl");
const fileEl = document.getElementById("videoFile");
const notesEl = document.getElementById("videoNotes");

function getCrmApiBase() {
  const injected =
    typeof window.__CRM_API_ORIGIN__ === "string" ? window.__CRM_API_ORIGIN__.trim().replace(/\/$/, "") : "";
  if (injected) return injected;
  const fromMeta = document.querySelector('meta[name="crm-api-base"]')?.getAttribute("content") || "";
  return String(fromMeta || "").trim().replace(/\/$/, "");
}

function apiUrl(path) {
  const p = path.startsWith("/") ? path : `/${path}`;
  const base = getCrmApiBase();
  return base ? `${base}${p}` : p;
}

async function fetchApiJson(pathAndQuery, init) {
  const response = await fetch(apiUrl(pathAndQuery), { credentials: "include", ...init });
  const text = await response.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = {};
  }
  return { response, data };
}

function showMessage(text, isError = false) {
  const str = String(text == null ? "" : text);
  if (isError && /please log in to continue/i.test(str)) {
    messageEl.textContent = "";
    const link = document.createElement("a");
    link.href = "/login.html";
    link.textContent = str;
    link.className = "login-redirect-link";
    messageEl.appendChild(link);
    messageEl.style.color = "#c62828";
    return;
  }
  messageEl.textContent = str;
  messageEl.style.color = isError ? "#c62828" : "#1b5e20";
}

function escapeHtml(text) {
  return String(text == null ? "" : text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function formatBytes(n) {
  const size = Number(n || 0);
  if (!Number.isFinite(size) || size <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  let val = size;
  let idx = 0;
  while (val >= 1024 && idx < units.length - 1) {
    val /= 1024;
    idx += 1;
  }
  return `${val.toFixed(idx === 0 ? 0 : 1)} ${units[idx]}`;
}

function setVideoFileHint() {
  const hint = document.getElementById("videoFileHint");
  if (!hint) return;
  const mode = sourceTypeEl.value;
  const f = fileEl.files && fileEl.files[0];
  if (mode === "file" && f) {
    hint.textContent = `Selected from your PC: ${f.name} (${formatBytes(f.size)})`;
    hint.style.display = "block";
  } else {
    hint.textContent = "";
    hint.style.display = "none";
  }
}

function resetForm() {
  videosForm.reset();
  sourceTypeEl.value = "url";
  urlEl.style.display = "block";
  fileEl.style.display = "none";
  setVideoFileHint();
}

function updateSourceInputs() {
  const mode = sourceTypeEl.value;
  if (mode === "file") {
    urlEl.style.display = "none";
    fileEl.style.display = "block";
  } else {
    urlEl.style.display = "block";
    fileEl.style.display = "none";
  }
  setVideoFileHint();
}

const VIDEO_EXT = /\.(mp4|webm|ogg|ogv|mov|m4v|avi|mkv|wmv|mpeg|mpg|3gp|3g2)$/i;

function isPcVideoFile(file) {
  if (!file) return false;
  const mime = String(file.type || "").toLowerCase();
  if (mime.startsWith("video/")) return true;
  if (mime === "application/octet-stream" && VIDEO_EXT.test(file.name || "")) return true;
  if (!mime && VIDEO_EXT.test(file.name || "")) return true;
  return VIDEO_EXT.test(file.name || "");
}

function buildVideoSrc(row) {
  if (String(row.source_type) === "file") return apiUrl(`/api/videos/${row.id}/stream`);
  return String(row.video_url || "").trim();
}

async function deleteVideo(id) {
  const n = Number(id);
  if (!Number.isInteger(n) || n < 1) return;
  if (!window.confirm("Delete this video?")) return;
  const { response, data } = await fetchApiJson(`/api/videos/${n}`, { method: "DELETE" });
  if (!response.ok) throw new Error(data.error || "Failed to delete video");
}

function renderVideos(rows) {
  const list = Array.isArray(rows) ? rows : [];
  if (!list.length) {
    videosListEl.innerHTML = '<div class="contact-history-empty">No videos saved yet.</div>';
    return;
  }
  videosListEl.innerHTML = "";
  for (const row of list) {
    const wrap = document.createElement("article");
    wrap.className = "document-item";
    const sourceLabel = String(row.source_type) === "file" ? "File" : "URL";
    const src = buildVideoSrc(row);
    wrap.innerHTML = `
      <div class="document-item-main">
        <div class="document-item-name">${escapeHtml(row.title || "Untitled Video")}</div>
        <div class="document-item-meta">Source: ${escapeHtml(sourceLabel)}</div>
        ${
          String(row.source_type) === "file"
            ? `<div class="document-item-meta">${escapeHtml(row.file_name || "")} • ${escapeHtml(formatBytes(row.size_bytes))}</div>`
            : `<div class="document-item-meta">${escapeHtml(row.video_url || "")}</div>`
        }
        ${row.notes ? `<div class="document-item-meta">${escapeHtml(row.notes)}</div>` : ""}
      </div>
      <div style="width: min(460px, 100%); margin: 8px 0">
        <video controls preload="metadata" style="width: 100%; max-height: 260px; border-radius: 8px; background: #000" src="${escapeHtml(src)}"></video>
      </div>
      <div class="document-item-actions">
        <button type="button" class="danger video-delete-btn" data-id="${row.id}">Delete</button>
      </div>
    `;
    wrap.querySelector(".video-delete-btn").addEventListener("click", async () => {
      try {
        await deleteVideo(row.id);
        showMessage("Video deleted.");
        await loadVideos();
      } catch (error) {
        showMessage(error.message || "Delete failed.", true);
      }
    });
    videosListEl.appendChild(wrap);
  }
}

async function loadVideos() {
  const { response, data } = await fetchApiJson("/api/videos");
  if (!response.ok) throw new Error(data.error || "Failed to load videos");
  renderVideos(Array.isArray(data) ? data : []);
}

videosForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const title = String(titleEl.value || "").trim();
    const sourceType = String(sourceTypeEl.value || "url").trim();
    const notes = String(notesEl.value || "").trim();
    if (!title) throw new Error("Video title is required.");

    if (sourceType === "url") {
      const videoUrl = String(urlEl.value || "").trim();
      if (!videoUrl) throw new Error("Video URL is required.");
      const { response, data } = await fetchApiJson("/api/videos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, videoUrl, notes })
      });
      if (!response.ok) throw new Error(data.error || "Failed to save video URL");
    } else {
      const file = fileEl.files && fileEl.files[0];
      if (!file) throw new Error("Choose a video file from your computer first.");
      if (!isPcVideoFile(file)) {
        throw new Error("That does not look like a video file. Use .mp4, .mov, .webm, or another common video format.");
      }
      showMessage("Uploading video from your computer...");
      const formData = new FormData();
      formData.append("video", file);
      formData.append("title", title);
      formData.append("notes", notes);
      const response = await fetch(apiUrl("/api/videos/upload"), {
        method: "POST",
        body: formData
      });
      const text = await response.text();
      let data = {};
      try {
        data = text ? JSON.parse(text) : {};
      } catch {
        data = {};
      }
      if (!response.ok) throw new Error(data.error || "Failed to upload video file");
    }

    showMessage("Video saved.");
    resetForm();
    await loadVideos();
  } catch (error) {
    showMessage(error.message || "Save failed.", true);
  }
});

fileEl.addEventListener("change", setVideoFileHint);
sourceTypeEl.addEventListener("change", updateSourceInputs);

const backToContactsBtn = document.getElementById("backToContactsBtn");
if (backToContactsBtn) {
  backToContactsBtn.addEventListener("click", () => {
    window.location.href = "/";
  });
}

refreshBtn.addEventListener("click", async () => {
  try {
    await loadVideos();
    showMessage("Videos refreshed.");
  } catch (error) {
    showMessage(error.message || "Refresh failed.", true);
  }
});

updateSourceInputs();
loadVideos().catch((error) => {
  showMessage(error.message || "Failed to load videos.", true);
});
