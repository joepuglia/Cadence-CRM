(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) {
    module.exports = api;
  }
  if (root) {
    root.SignupValidation = api;
  }
})(typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : this, function () {
  "use strict";

  function isEmailLike(value) {
    const s = String(value || "").trim();
    if (!s || s.length > 254 || /\s/.test(s)) return false;
    const parts = s.split("@");
    if (parts.length !== 2) return false;
    const local = parts[0];
    const domain = parts[1];
    if (!local || !domain) return false;
    if (local.startsWith(".") || local.endsWith(".") || local.includes("..")) return false;
    if (domain.startsWith(".") || domain.endsWith(".") || domain.includes("..")) return false;
    const lastDot = domain.lastIndexOf(".");
    if (lastDot <= 0 || lastDot >= domain.length - 1) return false;
    const tld = domain.slice(lastDot + 1);
    if (!/^[a-zA-Z]{2,}$/.test(tld)) return false;
    if (!/^[a-zA-Z0-9.-]+$/.test(domain)) return false;
    return /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+$/.test(local);
  }

  function normalizeSignupPhone(raw) {
    const digits = String(raw || "").replace(/\D/g, "");
    if (!digits) return "";
    if (digits.length === 11 && digits.startsWith("1")) return digits.slice(1);
    return digits;
  }

  function isValidSignupPhone(raw) {
    const normalized = normalizeSignupPhone(raw);
    if (!normalized) return true;
    return normalized.length === 10;
  }

  function emailErrorMessage(value) {
    const s = String(value || "").trim();
    if (!s) return "Please enter your work email.";
    if (!isEmailLike(s)) {
      return "That email does not look valid. Use a format like you@agency.com (include @ and a domain such as .com).";
    }
    return "";
  }

  return {
    isEmailLike,
    normalizeSignupPhone,
    isValidSignupPhone,
    emailErrorMessage
  };
});
