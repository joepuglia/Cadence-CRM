const messageEl = document.getElementById("tasksMessage");
const refreshBtn = document.getElementById("tasksRefreshBtn");
const newBtn = document.getElementById("tasksNewBtn");
const newPanel = document.getElementById("tasksNewPanel");
const newForm = document.getElementById("tasksNewForm");
const listEl = document.getElementById("tasksList");
const filterHintEl = document.getElementById("tasksFilterHint");
const searchInput = document.getElementById("tasksSearchInput");
const summaryGrid = document.querySelector(".tasks-summary-grid");
const countOverdueEl = document.getElementById("tasksCountOverdue");
const countTodayEl = document.getElementById("tasksCountToday");
const countUpcomingEl = document.getElementById("tasksCountUpcoming");
const countUnscheduledEl = document.getElementById("tasksCountUnscheduled");
const countCompletedEl = document.getElementById("tasksCountCompleted");

const contactSearch = document.getElementById("tasksContactSearch");
const contactIdEl = document.getElementById("tasksContactId");
const contactResults = document.getElementById("tasksContactResults");
const contactChip = document.getElementById("tasksContactChip");
const contactChipLabel = document.getElementById("tasksContactChipLabel");
const contactClear = document.getElementById("tasksContactClear");
const taskNameEl = document.getElementById("tasksNewName");
const taskActionEl = document.getElementById("tasksNewAction");
const taskDateEl = document.getElementById("tasksNewDate");
const taskTimeEl = document.getElementById("tasksNewTime");

let allItems = [];
let activeFilter = "overdue";
let searchTimer = 0;

function showMessage(text, isError = false) {
  if (!messageEl) return;
  const str = String(text == null ? "" : text);
  if (isError && typeof window.crmHandleAuthErrorMessage === "function" && window.crmHandleAuthErrorMessage(str, isError)) {
    return;
  }
  messageEl.textContent = str;
  messageEl.classList.toggle("attention-message--error", Boolean(isError));
}

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function fetchApiJson(path, init) {
  if (window.CrmApi && typeof window.CrmApi.fetchApiJson === "function") {
    return window.CrmApi.fetchApiJson(path, init);
  }
  return fetch(path, { credentials: "include", ...(init || {}) }).then(async (response) => {
    let data = {};
    try {
      data = await response.json();
    } catch {
      data = {};
    }
    return { response, data };
  });
}

function formatDue(dateYmd, timeHhmm) {
  const datePart = String(dateYmd || "").trim().slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(datePart)) return "No date";
  const [y, m, d] = datePart.split("-").map((n) => Number(n));
  const dt = new Date(y, m - 1, d);
  let label = dt.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
  const t = String(timeHhmm || "").trim();
  if (/^\d{2}:\d{2}$/.test(t)) {
    const [hh, mm] = t.split(":").map((n) => Number(n));
    const tm = new Date(y, m - 1, d, hh, mm);
    label += ` · ${tm.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}`;
  }
  return label;
}

function whenLabel(item) {
  const due = formatDue(item.task_date, item.task_time);
  if (item.bucket === "overdue") return due === "No date" ? "Past due" : `Past due · ${due}`;
  if (item.bucket === "today") return due === "No date" ? "Today" : due.replace(/^[^·]+/, "Today");
  if (item.bucket === "unscheduled") return "No date";
  if (item.bucket === "completed") return due === "No date" ? "Completed" : `Completed · ${due}`;
  return due;
}

function itemToneClass(bucket) {
  if (bucket === "overdue") return "attention-item--overdue";
  if (bucket === "today") return "attention-item--today";
  if (bucket === "upcoming") return "tasks-item--upcoming";
  if (bucket === "unscheduled") return "tasks-item--unscheduled";
  if (bucket === "completed") return "tasks-item--completed";
  return "";
}

function kindBadgeClass(bucket) {
  if (bucket === "overdue") return "attention-kind attention-kind--overdue";
  if (bucket === "today") return "attention-kind attention-kind--today";
  if (bucket === "upcoming") return "attention-kind attention-kind--renewal";
  if (bucket === "unscheduled") return "attention-kind attention-kind--stale";
  return "attention-kind";
}

function bucketLabel(bucket) {
  if (bucket === "overdue") return "Overdue";
  if (bucket === "today") return "Due today";
  if (bucket === "upcoming") return "Upcoming";
  if (bucket === "unscheduled") return "No date";
  if (bucket === "completed") return "Completed";
  return "Task";
}

function contactHref(item) {
  const id = Number(item.contact_id);
  if (!Number.isInteger(id) || id < 1) return "#";
  return `/contact.html?id=${encodeURIComponent(id)}&full=1`;
}

function preferredDefaultFilter(counts) {
  if (Number(counts.overdue) > 0) return "overdue";
  if (Number(counts.today) > 0) return "today";
  if (Number(counts.upcoming) > 0) return "upcoming";
  if (Number(counts.unscheduled) > 0) return "unscheduled";
  if (Number(counts.completed) > 0) return "completed";
  return "overdue";
}

function searchNeedle() {
  return String(searchInput?.value || "").trim().toLowerCase();
}

function matchesFilter(item) {
  if (item.bucket !== activeFilter) return false;
  const q = searchNeedle();
  if (!q) return true;
  const hay = `${item.task_name || ""} ${item.contact_name || ""} ${item.action_type || ""}`.toLowerCase();
  return hay.includes(q);
}

function filterHint(filter, count) {
  const n = Number(count) || 0;
  const noun = n === 1 ? "task" : "tasks";
  if (filter === "overdue") return `Showing ${n} overdue ${noun}`;
  if (filter === "today") return `Showing ${n} due today`;
  if (filter === "upcoming") return `Showing ${n} upcoming ${noun}`;
  if (filter === "unscheduled") return `Showing ${n} ${noun} with no date`;
  if (filter === "completed") return `Showing ${n} completed ${noun}`;
  return `Showing ${n} ${noun}`;
}

function setActiveFilter(filter) {
  activeFilter = filter || "overdue";
  summaryGrid?.querySelectorAll("[data-filter]").forEach((btn) => {
    btn.classList.toggle("is-active", btn.getAttribute("data-filter") === activeFilter);
  });
  renderList();
}

function renderList() {
  if (!listEl) return;
  const rows = allItems.filter(matchesFilter);
  if (filterHintEl) filterHintEl.textContent = filterHint(activeFilter, rows.length);
  if (!rows.length) {
    const emptyByFilter = {
      overdue: "No overdue tasks.",
      today: "Nothing due today.",
      upcoming: "No upcoming tasks.",
      unscheduled: "No tasks without a date.",
      completed: "No completed tasks yet."
    };
    listEl.innerHTML = `<div class="attention-empty">${escapeHtml(emptyByFilter[activeFilter] || "No tasks.")}</div>`;
    return;
  }

  listEl.innerHTML = rows
    .map((item) => {
      const href = contactHref(item);
      const canComplete = item.bucket !== "completed" && Number(item.id) > 0 && Number(item.contact_id) > 0;
      const name = escapeHtml(item.contact_name || "Unnamed contact");
      const hit =
        href !== "#"
          ? `<a class="tasks-item-hit" href="${escapeHtml(href)}" aria-label="Open ${name}"></a>`
          : "";
      return (
        `<article class="attention-item tasks-item ${itemToneClass(item.bucket)}">` +
        hit +
        `<div class="attention-item-main">` +
        `<div class="attention-item-top">` +
        `<span class="${kindBadgeClass(item.bucket)}">${escapeHtml(bucketLabel(item.bucket))}</span>` +
        `<span class="attention-item-when">${escapeHtml(whenLabel(item))}</span>` +
        `</div>` +
        `<div class="attention-item-name">${name}</div>` +
        `<div class="attention-item-title">${escapeHtml(item.task_name || "Task")}</div>` +
        `<div class="attention-item-detail">${escapeHtml(item.action_type || "Other")} · ${escapeHtml(item.condition || "")}</div>` +
        `</div>` +
        `<div class="tasks-item-actions">` +
        (canComplete
          ? `<button type="button" class="tasks-complete-btn" data-contact-id="${Number(item.contact_id)}" data-task-id="${Number(item.id)}">Mark completed</button>`
          : "") +
        `</div>` +
        `</article>`
      );
    })
    .join("");
}

async function loadTasks(opts = {}) {
  showMessage("");
  const { response, data } = await fetchApiJson("/api/tasks?limit=400");
  if (!response.ok) throw new Error((data && data.error) || "Could not load tasks.");
  allItems = Array.isArray(data.items) ? data.items : [];
  const counts = data.counts || {};
  if (countOverdueEl) countOverdueEl.textContent = String(Number(counts.overdue || 0));
  if (countTodayEl) countTodayEl.textContent = String(Number(counts.today || 0));
  if (countUpcomingEl) countUpcomingEl.textContent = String(Number(counts.upcoming || 0));
  if (countUnscheduledEl) countUnscheduledEl.textContent = String(Number(counts.unscheduled || 0));
  if (countCompletedEl) countCompletedEl.textContent = String(Number(counts.completed || 0));
  setActiveFilter(opts.keepFilter ? activeFilter : preferredDefaultFilter(counts));
  const openCount = Number(counts.open || 0);
  showMessage(`Updated ${new Date().toLocaleTimeString()} · ${openCount} open task${openCount === 1 ? "" : "s"}`);
}

async function markCompleted(contactId, taskId) {
  const { response, data } = await fetchApiJson(`/api/contacts/${contactId}/tasks/${taskId}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ condition: "Completed" })
  });
  if (!response.ok) throw new Error((data && data.error) || "Failed to mark task completed.");
}

function hideContactResults() {
  if (!contactResults) return;
  contactResults.innerHTML = "";
  contactResults.hidden = true;
  contactResults.classList.add("hidden");
}

function setSelectedContact(id, name) {
  if (contactIdEl) contactIdEl.value = String(id || "");
  if (contactChipLabel) contactChipLabel.textContent = name || "";
  if (contactChip) {
    const on = Boolean(id);
    contactChip.hidden = !on;
    contactChip.classList.toggle("hidden", !on);
  }
  if (contactSearch) {
    contactSearch.value = "";
    contactSearch.hidden = Boolean(id);
  }
  hideContactResults();
}

function renderContactResults(items, emptyText) {
  if (!contactResults) return;
  const rows = Array.isArray(items) ? items : [];
  if (!rows.length) {
    contactResults.innerHTML = `<li class="tasks-contact-empty">${escapeHtml(emptyText || "No contacts found.")}</li>`;
  } else {
    contactResults.innerHTML = rows
      .map((c) => {
        const meta = [c.email, c.phone].filter(Boolean).join(" · ");
        return (
          `<li><button type="button" class="tasks-contact-pick" data-id="${escapeHtml(c.id)}" data-name="${escapeHtml(
            c.full_name || "Unnamed"
          )}">${escapeHtml(c.full_name || "Unnamed")}${
            meta ? `<span class="tasks-contact-pick-meta">${escapeHtml(meta)}</span>` : ""
          }</button></li>`
        );
      })
      .join("");
    contactResults.querySelectorAll(".tasks-contact-pick").forEach((btn) => {
      btn.addEventListener("click", () => {
        setSelectedContact(btn.getAttribute("data-id"), btn.getAttribute("data-name"));
      });
    });
  }
  contactResults.hidden = false;
  contactResults.classList.remove("hidden");
}

async function searchContacts(q) {
  const query = String(q || "").trim();
  if (query.length < 2) {
    hideContactResults();
    return;
  }
  const { response, data } = await fetchApiJson(
    `/api/contacts?q=${encodeURIComponent(query)}&searchBy=name&page=1&limit=8`
  );
  if (!response.ok) throw new Error((data && data.error) || "Could not search contacts.");
  const rows = Array.isArray(data) ? data : Array.isArray(data.items) ? data.items : [];
  renderContactResults(rows, "No contacts found.");
}

if (summaryGrid) {
  summaryGrid.addEventListener("click", (event) => {
    const btn = event.target.closest("[data-filter]");
    if (!btn) return;
    setActiveFilter(btn.getAttribute("data-filter"));
  });
}

if (searchInput) {
  searchInput.addEventListener("input", () => renderList());
}

if (listEl) {
  listEl.addEventListener("click", async (event) => {
    const btn = event.target.closest(".tasks-complete-btn");
    if (!btn) return;
    const contactId = Number(btn.getAttribute("data-contact-id"));
    const taskId = Number(btn.getAttribute("data-task-id"));
    if (!Number.isInteger(contactId) || contactId < 1 || !Number.isInteger(taskId) || taskId < 1) return;
    btn.disabled = true;
    try {
      await markCompleted(contactId, taskId);
      await loadTasks({ keepFilter: true });
      showMessage("Task marked as completed.");
    } catch (err) {
      btn.disabled = false;
      showMessage(err.message || "Failed to mark task completed.", true);
    }
  });
}

if (newBtn && newPanel) {
  newBtn.addEventListener("click", () => {
    const next = newPanel.classList.contains("hidden");
    newPanel.classList.toggle("hidden", !next);
    if (next && taskNameEl) taskNameEl.focus();
  });
}

if (contactSearch) {
  contactSearch.addEventListener("input", () => {
    clearTimeout(searchTimer);
    searchTimer = window.setTimeout(() => {
      searchContacts(contactSearch.value).catch((err) => showMessage(err.message, true));
    }, 220);
  });
}

if (contactClear) {
  contactClear.addEventListener("click", () => {
    setSelectedContact("", "");
    if (contactSearch) {
      contactSearch.hidden = false;
      contactSearch.focus();
    }
  });
}

document.addEventListener("click", (event) => {
  if (!event.target.closest(".tasks-contact-field")) hideContactResults();
});

if (newForm) {
  newForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const contactId = Number(contactIdEl?.value);
    const taskName = String(taskNameEl?.value || "").trim();
    if (!Number.isInteger(contactId) || contactId < 1) {
      showMessage("Choose a contact for this task.", true);
      return;
    }
    if (!taskName) {
      showMessage("Task note is required.", true);
      return;
    }
    try {
      const { response, data } = await fetchApiJson(`/api/contacts/${contactId}/tasks`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          task_name: taskName,
          action_type: String(taskActionEl?.value || "Other").trim() || "Other",
          task_date: String(taskDateEl?.value || "").trim(),
          task_time: String(taskTimeEl?.value || "").trim(),
          condition: "Yet to Start"
        })
      });
      if (!response.ok) throw new Error((data && data.error) || "Failed to save task.");
      newForm.reset();
      setSelectedContact("", "");
      if (newPanel) newPanel.classList.add("hidden");
      await loadTasks({ keepFilter: true });
      showMessage("Task saved.");
    } catch (err) {
      showMessage(err.message || "Failed to save task.", true);
    }
  });
}

if (refreshBtn) {
  refreshBtn.addEventListener("click", () => {
    loadTasks().catch((err) => showMessage(err.message || "Could not load tasks.", true));
  });
}

loadTasks().catch((err) => showMessage(err.message || "Could not load tasks.", true));
