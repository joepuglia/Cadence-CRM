const messageEl = document.getElementById("renewalsMessage");
const windowSelect = document.getElementById("renewalsWindowSelect");
const refreshBtn = document.getElementById("renewalsRefreshBtn");
const tableBody = document.getElementById("renewalsTableBody");
const countOverdueEl = document.getElementById("renewalsCountOverdue");
const count30El = document.getElementById("renewalsCount30");
const count60El = document.getElementById("renewalsCount60");
const count90El = document.getElementById("renewalsCount90");

let allItems = [];

function showMessage(text, isError = false) {
  if (!messageEl) return;
  const str = String(text == null ? "" : text);
  if (isError && typeof window.crmHandleAuthErrorMessage === "function" && window.crmHandleAuthErrorMessage(str, isError)) {
    return;
  }
  messageEl.textContent = str;
  messageEl.style.color = isError ? "#c62828" : "#1b5e20";
}

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function formatDate(ymd) {
  const text = String(ymd || "").slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) return escapeHtml(ymd || "—");
  const [y, m, d] = text.split("-").map((n) => Number(n));
  const dt = new Date(y, m - 1, d);
  return dt.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}

function daysLabel(daysUntil) {
  const n = Number(daysUntil);
  if (!Number.isFinite(n)) return "—";
  if (n < 0) return `${Math.abs(n)} day${Math.abs(n) === 1 ? "" : "s"} overdue`;
  if (n === 0) return "Today";
  return `${n} day${n === 1 ? "" : "s"}`;
}

function daysClass(daysUntil) {
  const n = Number(daysUntil);
  if (n < 0) return "renewals-days--overdue";
  if (n === 0) return "renewals-days--today";
  if (n <= 14) return "renewals-days--soon";
  return "";
}

function rowClass(daysUntil) {
  const n = Number(daysUntil);
  if (n < 0) return "renewals-row--overdue";
  if (n <= 14) return "renewals-row--soon";
  return "";
}

function termLabel(interval) {
  const n = Number(interval);
  if (n === 3) return "3 months";
  if (n === 6) return "6 months";
  if (n === 12) return "12 months";
  return "—";
}

function renderTable() {
  const windowDays = Number(windowSelect && windowSelect.value) || 30;
  const rows = allItems.filter((item) => Number(item.days_until) <= windowDays);
  if (!tableBody) return;
  if (!rows.length) {
    tableBody.innerHTML = `<tr><td colspan="8" class="renewals-empty">No renewals in this window. On Contact Details → Coverage, set Coverage Start Date and choose a 3, 6, or 12 month renewal.</td></tr>`;
    return;
  }
  tableBody.innerHTML = rows
    .map((item) => {
      const id = Number(item.id) || 0;
      const href = id ? `/contact.html?id=${encodeURIComponent(id)}` : "#";
      const name = escapeHtml(item.full_name || "Unnamed contact");
      return (
        `<tr class="${rowClass(item.days_until)}" data-contact-id="${id || ""}">` +
        `<td><a class="renewals-name" href="${href}">${name}</a></td>` +
        `<td>${formatDate(item.coverage_start_date)}</td>` +
        `<td>${formatDate(item.next_renewal)}</td>` +
        `<td>${escapeHtml(termLabel(item.renewal_interval))}</td>` +
        `<td class="${daysClass(item.days_until)}">${escapeHtml(daysLabel(item.days_until))}</td>` +
        `<td>${escapeHtml(item.quote || "—")}</td>` +
        `<td>${escapeHtml(item.coverages_sold || "—")}</td>` +
        `<td>${escapeHtml(item.status || item.outcome || "—")}</td>` +
        `</tr>`
      );
    })
    .join("");
}

async function loadRenewals() {
  showMessage("");
  const { response, data } = await window.CrmApi.fetchApiJson("/api/renewals");
  if (!response.ok) throw new Error((data && data.error) || "Could not load renewals.");
  allItems = Array.isArray(data.items) ? data.items : [];
  const counts = data.counts || {};
  if (countOverdueEl) countOverdueEl.textContent = String(Number(counts.overdue || 0));
  if (count30El) count30El.textContent = String(Number(counts.next30 || 0));
  if (count60El) count60El.textContent = String(Number(counts.next60 || 0));
  if (count90El) count90El.textContent = String(Number(counts.next90 || 0));
  renderTable();
  const asOf = data.asOf ? ` as of ${formatDate(data.asOf)}` : "";
  showMessage(`Updated ${new Date().toLocaleTimeString()}${asOf ? ` · ${asOf.replace(/^ as of /, "")}` : ""}`);
}

if (tableBody) {
  tableBody.addEventListener("click", (event) => {
    const link = event.target.closest("a.renewals-name");
    if (link) return;
    const row = event.target.closest("tr[data-contact-id]");
    const id = row && row.getAttribute("data-contact-id");
    if (id) window.location.href = `/contact.html?id=${encodeURIComponent(id)}`;
  });
}

if (windowSelect) {
  windowSelect.addEventListener("change", renderTable);
}

if (refreshBtn) {
  refreshBtn.addEventListener("click", () => {
    loadRenewals().catch((error) => showMessage(error.message, true));
  });
}

loadRenewals().catch((error) => showMessage(error.message, true));
