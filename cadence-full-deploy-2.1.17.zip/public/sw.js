/* global self */

self.addEventListener("push", (event) => {
  let data = { title: "Cadence", body: "Follow-up reminder", url: "/" };
  try {
    if (event.data) {
      const text = event.data.text();
      const parsed = JSON.parse(text);
      if (parsed && typeof parsed === "object") Object.assign(data, parsed);
    }
  } catch {
    /* use defaults */
  }
  const rel = typeof data.url === "string" && data.url.startsWith("/") ? data.url : "/";
  const openUrl = new URL(rel, self.location.origin).href;
  event.waitUntil(
    self.registration.showNotification(data.title || "Cadence", {
      body: data.body || "",
      icon: "/favicon.svg",
      badge: "/favicon.svg",
      tag: data.tag || "crm-followup",
      renotify: true,
      data: { url: openUrl }
    })
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const raw = event.notification.data && event.notification.data.url;
  const url =
    typeof raw === "string" && raw.startsWith("http")
      ? raw
      : new URL(typeof raw === "string" && raw.startsWith("/") ? raw : "/", self.location.origin).href;
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      for (const c of clientList) {
        if (c.url === url && "focus" in c) return c.focus();
      }
      if (self.clients.openWindow) return self.clients.openWindow(url);
      return undefined;
    })
  );
});
