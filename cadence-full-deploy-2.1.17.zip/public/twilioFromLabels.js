function displayTwilioNumber(e164) {
  return String(e164 || "").trim() || "—";
}

function sortTwilioFromEntries(entries) {
  if (window.CrmTwilioNumberSort && typeof window.CrmTwilioNumberSort.sortTwilioFromEntries === "function") {
    return window.CrmTwilioNumberSort.sortTwilioFromEntries(entries);
  }
  const lineOrder = { primary: 0, secondary: 1, third: 2, custom: 3 };
  return [...entries].sort((a, b) => {
    const da = String(a.number || "").replace(/\D/g, "") || "0";
    const db = String(b.number || "").replace(/\D/g, "") || "0";
    if (da.length !== db.length) return da.length - db.length;
    if (da < db) return -1;
    if (da > db) return 1;
    return (lineOrder[a.line] ?? 9) - (lineOrder[b.line] ?? 9);
  });
}

function collectTwilioFromEntries(data) {
  const entries = [];
  const labels = data.builtinLabels || {};
  const built = [
    { line: "primary", value: "primary", number: data.primary, label: labels.primary },
    { line: "secondary", value: "secondary", number: data.secondary, label: labels.secondary },
    { line: "third", value: "third", number: data.third, label: labels.third }
  ];
  for (const row of built) {
    const number = String(row.number || "").trim();
    if (!number) continue;
    entries.push({
      line: row.line,
      value: row.value,
      number,
      label: String(row.label || "").trim(),
      isCustom: false
    });
  }
  for (const row of Array.isArray(data.custom) ? data.custom : []) {
    const number = String(row?.number || "").trim();
    if (!number) continue;
    entries.push({
      line: "custom",
      value: number,
      number,
      label: String(row?.label || "").trim(),
      isCustom: true
    });
  }
  return sortTwilioFromEntries(entries);
}

function createTwilioFromOption(entry) {
  const opt = document.createElement("option");
  opt.value = entry.value;
  if (entry.isCustom) opt.dataset.customTwilio = "1";
  const display = displayTwilioNumber(entry.number);
  opt.textContent = entry.label ? `${entry.label}: ${display}` : display;
  return opt;
}

function restoreTwilioFromSelection(sel, prevValue) {
  if (prevValue === undefined || prevValue === null || prevValue === "") return;
  const prevOpt = Array.from(sel.options || []).find((opt) => opt.value === prevValue);
  if (prevOpt && !prevOpt.disabled && !prevOpt.hidden) sel.value = prevValue;
}

/** Per-step SMS sender (Campaign Builder). First option = inherit campaign default. */
function applyTwilioFromToStepSelect(sel, data) {
  if (!sel) return;
  const prevValue = sel.value;
  sel.innerHTML = "";
  const inh = document.createElement("option");
  inh.value = "";
  inh.textContent = "Same as campaign default";
  sel.appendChild(inh);

  for (const entry of collectTwilioFromEntries(data)) {
    sel.appendChild(createTwilioFromOption(entry));
  }

  if (prevValue !== undefined && prevValue !== null && prevValue !== "") {
    restoreTwilioFromSelection(sel, prevValue);
  } else {
    sel.value = "";
  }
}

function applyTwilioFromToSelect(sel, data) {
  if (!sel) return;
  const prevValue = sel.value;
  sel.innerHTML = "";
  for (const entry of collectTwilioFromEntries(data)) {
    sel.appendChild(createTwilioFromOption(entry));
  }
  restoreTwilioFromSelection(sel, prevValue);
}

async function loadTwilioFromData() {
  // Always prefer the live API. The HTML stub (window.__TWILIO_FROM_NUMBERS__)
  // only has env primary/secondary/third and hardcodes custom: [], so using it
  // as a cache hid every number saved in Settings → Twilio numbers.
  try {
    const r = await fetch("/api/twilio/from-numbers");
    if (r.ok) {
      const data = await r.json();
      if (typeof window !== "undefined") window.__TWILIO_FROM_NUMBERS__ = data;
      return data;
    }
  } catch {
    // ignore
  }
  if (typeof window !== "undefined" && window.__TWILIO_FROM_NUMBERS__) {
    return window.__TWILIO_FROM_NUMBERS__;
  }
  return { primary: null, secondary: null, third: null, custom: [], builtinLabels: {} };
}

async function applyTwilioFromLabels() {
  const data = await loadTwilioFromData();

  document.querySelectorAll('select[name="twilioFrom"]').forEach((sel) => {
    applyTwilioFromToSelect(sel, data);
  });

  document.querySelectorAll("select.step-twilio-from").forEach((sel) => {
    applyTwilioFromToStepSelect(sel, data);
  });

  if (typeof window.__crmSyncTwilioFromPairs === "function") {
    window.__crmSyncTwilioFromPairs();
  }

  if (typeof window.__crmOnTwilioFromLabelsApplied === "function") {
    try {
      window.__crmOnTwilioFromLabelsApplied();
    } catch {
      /* ignore */
    }
  }
}

/** Copy selected line (primary / secondary / third / custom E.164) from one dropdown to another if that option exists. */
function mirrorTwilioFromSelect(fromEl, toEl) {
  if (!fromEl || !toEl) return;
  const v = fromEl.value;
  // Avoid querySelector on E.164 values — "+" breaks CSS attribute selectors.
  const opt = Array.from(toEl.options || []).find((o) => o.value === v);
  if (opt && !opt.disabled && !opt.hidden) toEl.value = v;
}

/** First usable Twilio caller ID on a select (primary, then secondary, then third, then custom). */
function pickDefaultTwilioFromSelect(sel) {
  if (!sel) return "primary";
  const preferred = ["primary", "secondary", "third"];
  for (const value of preferred) {
    const opt = Array.from(sel.options || []).find((o) => o.value === value);
    if (opt && !opt.disabled && !opt.hidden) return value;
  }
  const custom = Array.from(sel.options || []).find(
    (opt) => opt.dataset && opt.dataset.customTwilio === "1" && !opt.disabled && !opt.hidden && opt.value
  );
  return custom ? custom.value : "primary";
}

window.mirrorTwilioFromSelect = mirrorTwilioFromSelect;
window.pickDefaultTwilioFromSelect = pickDefaultTwilioFromSelect;
window.applyTwilioFromToStepSelect = applyTwilioFromToStepSelect;
window.loadTwilioFromData = loadTwilioFromData;

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", applyTwilioFromLabels);
} else {
  applyTwilioFromLabels();
}
