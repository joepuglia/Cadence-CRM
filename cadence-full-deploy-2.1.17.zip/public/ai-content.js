"use strict";

/* Pure on-page SEO scorer (no DOM) so it can be unit-tested and reused. */
function aiContentSeoScore({ title, metaDescription, focusKeyword, bodyHtml } = {}) {
  const t = String(title || "").trim();
  const meta = String(metaDescription || "").trim();
  const kw = String(focusKeyword || "").trim().toLowerCase();
  const html = String(bodyHtml || "");
  const text = html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
  const words = text ? text.split(" ").filter(Boolean).length : 0;
  const h2count = (html.match(/<h2\b/gi) || []).length;
  const firstParaMatch = html.match(/<p\b[^>]*>([\s\S]*?)<\/p>/i);
  const firstPara = (firstParaMatch ? firstParaMatch[1] : "").replace(/<[^>]+>/g, " ").toLowerCase();
  const headings = (html.match(/<h[1-6]\b[^>]*>([\s\S]*?)<\/h[1-6]>/gi) || [])
    .join(" ")
    .replace(/<[^>]+>/g, " ")
    .toLowerCase();
  const hasLink = /<a\b[^>]*href/i.test(html);

  const checks = [];
  const add = (ok, label, hint) => checks.push({ ok: !!ok, label, hint: ok ? "" : hint });
  add(t.length >= 40 && t.length <= 65, "Title is 40–65 characters", t ? `Currently ${t.length} characters` : "Add a title");
  add(!!kw && t.toLowerCase().includes(kw), "Focus keyword in the title", kw ? "Work the keyword into the title" : "Set a focus keyword");
  add(meta.length >= 140 && meta.length <= 160, "Meta description 140–160 characters", meta ? `Currently ${meta.length} characters` : "Add a meta description");
  add(!!kw && meta.toLowerCase().includes(kw), "Keyword in the meta description", "Include the keyword in the meta description");
  add(!!kw && firstPara.includes(kw), "Keyword in the opening paragraph", "Use the keyword in the first paragraph");
  add(!!kw && headings.includes(kw), "Keyword in a subheading", "Use the keyword in an H2 or H3");
  add(words >= 600, "At least 600 words", `Currently about ${words} words`);
  add(h2count >= 2, "Two or more subheadings (H2)", `Currently ${h2count} H2 heading${h2count === 1 ? "" : "s"}`);
  add(hasLink, "Includes at least one link", "Add a relevant link (e.g. your quote or contact page)");

  const passed = checks.filter((c) => c.ok).length;
  const score = checks.length ? Math.round((passed / checks.length) * 100) : 0;
  return { score, checks, words };
}

if (typeof window !== "undefined") window.aiContentSeoScore = aiContentSeoScore;

(function () {
  if (typeof document === "undefined") return;
  const $ = (id) => document.getElementById(id);
  const apiBase = String(window.__CRM_API_ORIGIN__ || "");
  const escapeHtml = (s) =>
    String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

  async function api(path, opts) {
    const res = await fetch(apiBase + path, { credentials: "include", ...(opts || {}) });
    let data = {};
    try {
      data = await res.json();
    } catch (e) {
      /* non-JSON */
    }
    return { res, data };
  }

  const topicEl = $("aiContentTopic");
  const suggestBtn = $("aiContentSuggestBtn");
  const suggestStatus = $("aiContentSuggestStatus");
  const suggestionsEl = $("aiContentTopicSuggestions");
  const toneEl = $("aiContentTone");
  const lengthEl = $("aiContentLength");
  const keywordEl = $("aiContentKeyword");
  const genBtn = $("aiContentGenerateBtn");
  const statusEl = $("aiContentStatus");
  const resultEl = $("aiContentResult");
  const titleEl = $("aiContentTitle");
  const metaEl = $("aiContentMeta");
  const focusKwEl = $("aiContentFocusKw");
  const keywordsEl = $("aiContentKeywords");
  const bodyEl = $("aiContentBody");
  const copyBtn = $("aiContentCopyBtn");
  const downloadBtn = $("aiContentDownloadBtn");
  const previewToggle = $("aiContentPreviewToggle");
  const previewFrame = $("aiContentPreview");
  const editorStatus = $("aiContentEditorStatus");
  const scoreEl = $("aiContentScore");
  const checksEl = $("aiContentChecks");
  const statusBadgeEl = $("aiContentStatusBadge");
  const statusTextEl = $("aiContentStatusText");
  const audienceEl = $("aiContentAudience");
  const publishPanel = $("aiContentPublishPanel");
  const eyebrowEl = $("aiContentEyebrow");
  const publishBtn = $("aiContentPublishBtn");
  const publishStatus = $("aiContentPublishStatus");
  const publishedLink = $("aiContentPublishedLink");
  const postsPanel = $("aiContentPostsPanel");
  const postsListEl = $("aiContentPostsList");
  let currentPostId = null;

  if (!genBtn) return;

  function setAiStatusBadge(state, text) {
    if (statusBadgeEl) statusBadgeEl.dataset.state = state;
    if (statusTextEl) statusTextEl.textContent = text;
  }

  (async () => {
    try {
      const { res, data } = await api("/api/ai-content/status");
      if (!res.ok) {
        setAiStatusBadge("error", "Could not check AI status. Refresh this page and try again.");
        return;
      }
      if (data && data.configured) {
        setAiStatusBadge(
          "ready",
          `AI ready - Drafts are suggestions; review before sending.`
        );
      } else {
        setAiStatusBadge(
          "unconfigured",
          "AI is not configured on this server yet. Add your Claude API key in Settings to use AI Content."
        );
      }
    } catch (e) {
      setAiStatusBadge("error", "Could not check AI status. Refresh this page and try again.");
    }
  })();

  function renderKeywords(list) {
    if (!keywordsEl) return;
    keywordsEl.innerHTML = "";
    (Array.isArray(list) ? list : []).forEach((k) => {
      const s = document.createElement("span");
      s.className = "ai-content-keyword-chip";
      s.textContent = String(k || "");
      keywordsEl.appendChild(s);
    });
  }

  function updateScore() {
    if (!scoreEl) return;
    const r = aiContentSeoScore({
      title: titleEl ? titleEl.value : "",
      metaDescription: metaEl ? metaEl.value : "",
      focusKeyword: focusKwEl ? focusKwEl.value : "",
      bodyHtml: bodyEl ? bodyEl.value : ""
    });
    scoreEl.innerHTML = r.score + '<small>/100</small>';
    scoreEl.className = "ai-content-score " + (r.score >= 80 ? "good" : r.score >= 50 ? "ok" : "bad");
    if (checksEl) {
      checksEl.innerHTML = "";
      r.checks.forEach((c) => {
        const li = document.createElement("li");
        li.className = c.ok ? "ok" : "no";
        li.textContent = c.label;
        if (!c.ok && c.hint) {
          const h = document.createElement("span");
          h.className = "hint";
          h.textContent = c.hint;
          li.appendChild(h);
        }
        checksEl.appendChild(li);
      });
    }
  }

  if (suggestBtn) {
    suggestBtn.addEventListener("click", async () => {
      const orig = suggestBtn.textContent;
      suggestBtn.disabled = true;
      suggestBtn.textContent = "Thinking…";
      if (suggestStatus) suggestStatus.textContent = "";
      try {
        const { res, data } = await api("/api/ai-content/topics", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            seed: String(topicEl ? topicEl.value : "").trim(),
            audience: audienceEl ? audienceEl.value : "consumer"
          })
        });
        if (!res.ok) throw new Error(data.error || "Could not suggest topics.");
        const topics = Array.isArray(data.topics) ? data.topics : [];
        suggestionsEl.innerHTML = "";
        if (!topics.length) {
          if (suggestStatus) suggestStatus.textContent = "No suggestions — try a focus area in the topic box.";
          suggestionsEl.hidden = true;
          return;
        }
        topics.forEach((t) => {
          const b = document.createElement("button");
          b.type = "button";
          b.className = "ai-content-suggestion";
          const strong = document.createElement("strong");
          strong.textContent = String(t.title || "");
          const span = document.createElement("span");
          span.textContent = [t.keyword ? "Keyword: " + t.keyword : "", t.why].filter(Boolean).join(" · ");
          b.appendChild(strong);
          b.appendChild(span);
          b.addEventListener("click", () => {
            if (topicEl) topicEl.value = String(t.title || "");
            if (keywordEl && t.keyword) keywordEl.value = String(t.keyword);
            suggestionsEl.hidden = true;
          });
          suggestionsEl.appendChild(b);
        });
        suggestionsEl.hidden = false;
      } catch (e) {
        if (suggestStatus) suggestStatus.textContent = e.message || "Could not suggest topics.";
      } finally {
        suggestBtn.disabled = false;
        suggestBtn.textContent = orig;
      }
    });
  }

  genBtn.addEventListener("click", async () => {
    const topic = String(topicEl ? topicEl.value : "").trim();
    if (!topic) {
      if (statusEl) statusEl.textContent = "Enter a topic first.";
      return;
    }
    const orig = genBtn.textContent;
    genBtn.disabled = true;
    genBtn.textContent = "Generating…";
    if (statusEl) statusEl.textContent = "Writing your draft — this can take ~20–40 seconds…";
    try {
      const { res, data } = await api("/api/ai-content/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          topic,
          tone: toneEl ? toneEl.value : "professional",
          length: lengthEl ? lengthEl.value : "medium",
          keyword: keywordEl ? keywordEl.value : "",
          audience: audienceEl ? audienceEl.value : "consumer"
        })
      });
      if (!res.ok) throw new Error(data.error || "Could not generate the draft.");
      if (titleEl) titleEl.value = data.title || "";
      if (metaEl) metaEl.value = data.metaDescription || "";
      if (focusKwEl) focusKwEl.value = data.focusKeyword || "";
      if (bodyEl) bodyEl.value = data.bodyHtml || "";
      renderKeywords(data.keywords || []);
      currentPostId = null;
      if (eyebrowEl && !String(eyebrowEl.value || "").trim()) eyebrowEl.value = data.focusKeyword || "";
      if (publishPanel) publishPanel.hidden = false;
      if (publishedLink) publishedLink.hidden = true;
      if (publishStatus) publishStatus.textContent = "";
      if (publishBtn) publishBtn.textContent = "Publish to blog";
      if (resultEl) resultEl.hidden = false;
      updateScore();
      if (statusEl) statusEl.textContent = "Draft ready — review and tweak it below.";
      if (resultEl) resultEl.scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (e) {
      if (statusEl) statusEl.textContent = e.message || "Could not generate the draft.";
    } finally {
      genBtn.disabled = false;
      genBtn.textContent = orig;
    }
  });

  if (copyBtn) {
    copyBtn.addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(bodyEl ? bodyEl.value : "");
        if (editorStatus) editorStatus.textContent = "HTML copied to clipboard.";
      } catch (e) {
        if (bodyEl) bodyEl.select();
        if (editorStatus) editorStatus.textContent = "Press Ctrl+C to copy.";
      }
      if (editorStatus) setTimeout(() => { editorStatus.textContent = ""; }, 4000);
    });
  }

  if (downloadBtn) {
    downloadBtn.addEventListener("click", () => {
      const title = String(titleEl ? titleEl.value : "Untitled").trim() || "Untitled";
      const slug =
        title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60) || "article";
      const metaAttr = String(metaEl ? metaEl.value : "").replace(/"/g, "&quot;");
      const doc =
        '<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n' +
        '<meta name="viewport" content="width=device-width, initial-scale=1">\n' +
        "<title>" + escapeHtml(title) + "</title>\n" +
        '<meta name="description" content="' + metaAttr + '">\n</head>\n<body>\n' +
        "<h1>" + escapeHtml(title) + "</h1>\n" +
        (bodyEl ? bodyEl.value : "") +
        "\n</body>\n</html>\n";
      const blob = new Blob([doc], { type: "text/html" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = slug + ".html";
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 2000);
      if (editorStatus) {
        editorStatus.textContent = "Downloaded " + slug + ".html";
        setTimeout(() => { editorStatus.textContent = ""; }, 4000);
      }
    });
  }

  if (previewToggle && previewFrame) {
    let on = false;
    previewToggle.addEventListener("click", () => {
      on = !on;
      previewFrame.hidden = !on;
      previewToggle.textContent = on ? "Hide preview" : "Show preview";
      if (on) {
        previewFrame.srcdoc =
          '<!doctype html><html><head><meta charset="utf-8"><style>' +
          "body{font:16px/1.6 system-ui,Segoe UI,Arial,sans-serif;color:#1f2937;max-width:680px;margin:0 auto;padding:20px;}" +
          "h1,h2,h3{line-height:1.25;}img{max-width:100%;height:auto;}a{color:#4f46e5;}" +
          "</style></head><body><h1>" +
          escapeHtml(String(titleEl ? titleEl.value : "")) +
          "</h1>" +
          (bodyEl ? bodyEl.value : "") +
          "</body></html>";
      }
    });
  }

  [titleEl, metaEl, focusKwEl, bodyEl].forEach((el) => {
    if (el) el.addEventListener("input", updateScore);
  });

  // ---- Owner-only: publish to the Cadence blog + manage posts ----
  // (For non-owners the publish/posts sections are stripped server-side, so
  // these elements are absent and every handler below no-ops.)

  function keywordsFromChips() {
    if (!keywordsEl) return [];
    return Array.from(keywordsEl.querySelectorAll(".ai-content-keyword-chip"))
      .map((s) => String(s.textContent || "").trim())
      .filter(Boolean);
  }

  function currentDraft() {
    return {
      id: currentPostId || undefined,
      title: titleEl ? titleEl.value : "",
      metaDescription: metaEl ? metaEl.value : "",
      focusKeyword: focusKwEl ? focusKwEl.value : "",
      keywords: keywordsFromChips(),
      eyebrow: eyebrowEl ? eyebrowEl.value : "",
      bodyHtml: bodyEl ? bodyEl.value : ""
    };
  }

  function loadPostIntoEditor(p) {
    currentPostId = p.id || null;
    if (titleEl) titleEl.value = p.title || "";
    if (metaEl) metaEl.value = p.metaDescription || "";
    if (focusKwEl) focusKwEl.value = p.focusKeyword || "";
    if (eyebrowEl) eyebrowEl.value = p.eyebrow || "";
    if (bodyEl) bodyEl.value = p.bodyHtml || "";
    renderKeywords(p.keywords || []);
    if (resultEl) resultEl.hidden = false;
    if (publishPanel) publishPanel.hidden = false;
    if (publishedLink) {
      publishedLink.href = "/blog/" + (p.slug || "");
      publishedLink.hidden = p.status === "draft";
    }
    if (publishStatus) publishStatus.textContent = "Editing a published post — Publish saves your changes.";
    if (publishBtn) publishBtn.textContent = "Update post";
    updateScore();
    if (resultEl) resultEl.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function renderPosts(posts) {
    if (!postsListEl) return;
    postsListEl.innerHTML = "";
    if (!posts.length) {
      postsListEl.innerHTML = '<p class="hint" style="margin:0">No posts yet. Generate a draft and click Publish.</p>';
      return;
    }
    posts.forEach((p) => {
      const row = document.createElement("div");
      row.className = "ai-content-post-row";
      const meta = document.createElement("div");
      const title = document.createElement("div");
      title.className = "ai-content-post-title";
      title.textContent = p.title || "(untitled)";
      const sub = document.createElement("div");
      sub.className = "ai-content-post-sub";
      sub.textContent = "/blog/" + (p.slug || "");
      if (p.status === "draft") {
        const d = document.createElement("span");
        d.className = "draft";
        d.textContent = " · unpublished";
        sub.appendChild(d);
      }
      meta.appendChild(title);
      meta.appendChild(sub);

      const actions = document.createElement("div");
      actions.className = "ai-content-post-actions";
      const view = document.createElement("a");
      view.href = "/blog/" + (p.slug || "");
      view.target = "_blank";
      view.rel = "noopener";
      view.textContent = "View";
      const edit = document.createElement("button");
      edit.type = "button";
      edit.textContent = "Edit";
      edit.addEventListener("click", () => loadPostIntoEditor(p));
      const toggle = document.createElement("button");
      toggle.type = "button";
      toggle.textContent = p.status === "draft" ? "Republish" : "Unpublish";
      toggle.addEventListener("click", () => toggleStatus(p));
      const del = document.createElement("button");
      del.type = "button";
      del.className = "agile-cancel-btn";
      del.textContent = "Delete";
      del.addEventListener("click", () => deletePost(p));
      actions.appendChild(view);
      actions.appendChild(edit);
      actions.appendChild(toggle);
      actions.appendChild(del);

      row.appendChild(meta);
      row.appendChild(actions);
      postsListEl.appendChild(row);
    });
  }

  async function loadPosts() {
    if (!postsPanel || !postsListEl) return;
    try {
      const { res, data } = await api("/api/ai-content/posts");
      if (!res.ok) {
        if (res.status === 403) postsPanel.hidden = true;
        return;
      }
      renderPosts(Array.isArray(data.posts) ? data.posts : []);
    } catch (e) {
      /* ignore */
    }
  }

  async function toggleStatus(p) {
    try {
      let res;
      if (p.status === "draft") {
        ({ res } = await api("/api/ai-content/publish", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            id: p.id,
            slug: p.slug,
            title: p.title,
            metaDescription: p.metaDescription,
            focusKeyword: p.focusKeyword,
            keywords: p.keywords,
            eyebrow: p.eyebrow,
            bodyHtml: p.bodyHtml
          })
        }));
      } else {
        ({ res } = await api("/api/ai-content/unpublish", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: p.id })
        }));
      }
      if (res.ok) loadPosts();
    } catch (e) {
      /* ignore */
    }
  }

  async function deletePost(p) {
    if (!window.confirm('Delete "' + (p.title || "this post") + '"? This removes it from your blog.')) return;
    try {
      const { res } = await api("/api/ai-content/delete-post", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: p.id })
      });
      if (res.ok) {
        if (currentPostId === p.id) currentPostId = null;
        loadPosts();
      }
    } catch (e) {
      /* ignore */
    }
  }

  if (publishBtn) {
    publishBtn.addEventListener("click", async () => {
      const draft = currentDraft();
      if (!String(draft.title || "").trim() || !String(draft.bodyHtml || "").trim()) {
        if (publishStatus) publishStatus.textContent = "Generate a draft with a title and body first.";
        return;
      }
      const orig = publishBtn.textContent;
      publishBtn.disabled = true;
      publishBtn.textContent = currentPostId ? "Updating…" : "Publishing…";
      if (publishStatus) publishStatus.textContent = "";
      try {
        const { res, data } = await api("/api/ai-content/publish", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(draft)
        });
        if (!res.ok) throw new Error(data.error || "Could not publish.");
        if (data.post && data.post.id) currentPostId = data.post.id;
        if (publishedLink && data.url) {
          publishedLink.href = data.url;
          publishedLink.hidden = false;
        }
        if (publishStatus) publishStatus.textContent = "Published! It's live on your blog.";
        publishBtn.textContent = "Update post";
        loadPosts();
      } catch (e) {
        if (publishStatus) publishStatus.textContent = e.message || "Could not publish.";
        publishBtn.textContent = orig;
      } finally {
        publishBtn.disabled = false;
      }
    });
  }

  loadPosts();
})();
