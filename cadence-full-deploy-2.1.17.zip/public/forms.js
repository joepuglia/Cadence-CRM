const messageEl = document.getElementById("message");
const formsForm = document.getElementById("formsForm");
const refreshBtn = document.getElementById("formsRefreshBtn");
const formsListEl = document.getElementById("formsList");
const sourceTypeEl = document.getElementById("formSourceType");
const titleEl = document.getElementById("formTitle");
const urlEl = document.getElementById("formUrl");
const fileEl = document.getElementById("formFile");
const notesEl = document.getElementById("formNotes");

const FORM_EXT =
  /\.(pdf|doc|docx|xls|xlsx|ppt|pptx|csv|txt|html|htm|rtf|odt|ods|jpg|jpeg|png|gif|tif|tiff|webp)$/i;

function getCrmApiBase() {
  const injected =
    typeof window.__CRM_API_ORIGIN__ === "string" ? window.__CRM_API_ORIGIN__.trim().replace(/\/$/, "") : "";
  if (injected) return injected;
  const fromMeta = document.querySelector('meta[name="crm-api-base"]')?.getAttribute("content") || "";
  return String(fromMeta || "").trim().replace(/\/$/, "");
}

function apiUrl(path) {
  const p = path.startsWith("/") ? path : `/${path}`;
  const base = getCrmApiBase();
  return base ? `${base}${p}` : p;
}

async function fetchApiJson(pathAndQuery, init) {
  const response = await fetch(apiUrl(pathAndQuery), init);
  const text = await response.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = {};
  }
  return { response, data };
}

function showMessage(text, isError = false) {
  const str = String(text == null ? "" : text);
  if (isError && /please log in to continue/i.test(str)) {
    messageEl.textContent = "";
    const link = document.createElement("a");
    link.href = "/login.html";
    link.textContent = str;
    link.className = "login-redirect-link";
    messageEl.appendChild(link);
    messageEl.style.color = "#c62828";
    return;
  }
  messageEl.textContent = str;
  messageEl.style.color = isError ? "#c62828" : "#1b5e20";
}

function escapeHtml(text) {
  return String(text == null ? "" : text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function toExternalLink(url) {
  const raw = String(url || "").trim();
  if (!raw) return "";
  if (/^https?:\/\//i.test(raw)) return raw;
  return `https://${raw}`;
}

/** Remote page preview via WordPress mshots (same service as Landing Pages). */
function getFormUrlSnapshotSrc(formUrl) {
  const pageUrl = toExternalLink(formUrl);
  if (!pageUrl) return "";
  return `https://s.wordpress.com/mshots/v1/${encodeURIComponent(pageUrl)}?w=320&h=200`;
}

const FORM_SNAPSHOT_PLACEHOLDER =
  "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='100'%3E%3Crect fill='%23eef2f7' width='100%25' height='100%25' rx='4'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' fill='%2394a3b8' font-size='11' font-family='system-ui,sans-serif'%3ENo preview%3C/text%3E%3C/svg%3E";

function fileExtensionLabel(fileName) {
  const m = String(fileName || "").match(/\.([^.]+)$/);
  return m ? m[1].toUpperCase().slice(0, 8) : "FILE";
}

function isImageMime(mime, fileName) {
  const m = String(mime || "").toLowerCase();
  if (m.startsWith("image/")) return true;
  return /\.(jpe?g|png|gif|webp|tif|tiff|bmp|svg)$/i.test(fileName || "");
}

/** Thumbnail column: URL → mshot; uploaded image → image; other files → extension badge. */
function buildFormThumbMarkup(row, isFile, dl, url) {
  const empty = `<div class="form-thumb-cell"><span class="form-thumb-empty">—</span></div>`;

  if (!isFile && url) {
    const snapSrc = getFormUrlSnapshotSrc(url);
    const href = escapeHtml(toExternalLink(url));
    if (!snapSrc) return empty;
    return `<div class="form-thumb-cell"><a class="form-thumb-link" href="${href}" target="_blank" rel="noopener noreferrer" title="Open form (snapshot is approximate)"><img class="form-thumb-img form-thumb-mshot" src="${snapSrc}" alt="" width="160" height="100" loading="lazy" decoding="async" /></a></div>`;
  }

  if (isFile && dl) {
    const hrefDl = escapeHtml(dl);
    if (isImageMime(row.mime_type, row.file_name)) {
      return `<div class="form-thumb-cell"><a class="form-thumb-link" href="${hrefDl}" target="_blank" rel="noopener noreferrer" title="Open image"><img class="form-thumb-img form-thumb-img-file" src="${hrefDl}" alt="" width="160" height="100" loading="lazy" decoding="async" /></a></div>`;
    }
    const label = escapeHtml(fileExtensionLabel(row.file_name));
    return `<div class="form-thumb-cell"><a class="form-thumb-badge-link" href="${hrefDl}" title="Download"><div class="form-thumb-badge" aria-label="Form file"><span class="form-thumb-badge-ext">${label}</span><span class="form-thumb-badge-hint">Form file</span></div></a></div>`;
  }

  return empty;
}

function formatBytes(n) {
  const size = Number(n || 0);
  if (!Number.isFinite(size) || size <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  let val = size;
  let idx = 0;
  while (val >= 1024 && idx < units.length - 1) {
    val /= 1024;
    idx += 1;
  }
  return `${val.toFixed(idx === 0 ? 0 : 1)} ${units[idx]}`;
}

function isPcFormFile(file) {
  if (!file) return false;
  const mime = String(file.type || "").toLowerCase();
  if (mime.startsWith("image/") || mime.startsWith("text/")) return true;
  if (
    mime === "application/pdf" ||
    mime.includes("word") ||
    mime.includes("excel") ||
    mime.includes("spreadsheet") ||
    mime.includes("powerpoint") ||
    mime.includes("officedocument") ||
    mime.includes("opendocument")
  ) {
    return true;
  }
  if (mime === "application/octet-stream" && FORM_EXT.test(file.name || "")) return true;
  if (!mime && FORM_EXT.test(file.name || "")) return true;
  return FORM_EXT.test(file.name || "");
}

function setFormFileHint() {
  const hint = document.getElementById("formFileHint");
  if (!hint) return;
  const mode = sourceTypeEl.value;
  const f = fileEl.files && fileEl.files[0];
  if (mode === "file" && f) {
    hint.textContent = `Selected from your PC: ${f.name} (${formatBytes(f.size)})`;
    hint.style.display = "block";
  } else {
    hint.textContent = "";
    hint.style.display = "none";
  }
}

function resetForm() {
  formsForm.reset();
  sourceTypeEl.value = "url";
  urlEl.style.display = "block";
  fileEl.style.display = "none";
  setFormFileHint();
}

function updateSourceInputs() {
  const mode = sourceTypeEl.value;
  if (mode === "file") {
    urlEl.style.display = "none";
    fileEl.style.display = "block";
  } else {
    urlEl.style.display = "block";
    fileEl.style.display = "none";
  }
  setFormFileHint();
}

function openUrl(raw) {
  let u = String(raw || "").trim();
  if (!u) return;
  if (!/^https?:\/\//i.test(u)) u = `https://${u}`;
  window.open(u, "_blank", "noopener,noreferrer");
}

async function deleteForm(id) {
  const n = Number(id);
  if (!Number.isInteger(n) || n < 1) return;
  if (!window.confirm("Remove this saved form?")) return;
  const { response, data } = await fetchApiJson(`/api/forms/${n}`, { method: "DELETE" });
  if (!response.ok) throw new Error(data.error || "Failed to delete form");
}

function renderForms(rows) {
  const list = Array.isArray(rows) ? rows : [];
  if (!list.length) {
    formsListEl.innerHTML = '<div class="contact-history-empty">No forms saved yet.</div>';
    return;
  }
  formsListEl.innerHTML = "";
  for (const row of list) {
    const wrap = document.createElement("article");
    wrap.className = "document-item form-document-item";
    const isFile = String(row.source_type) === "file";
    const url = String(row.form_url || "").trim();
    const dl = isFile ? apiUrl(`/api/forms/${row.id}/download`) : "";
    const thumbHtml = buildFormThumbMarkup(row, isFile, dl, url);
    wrap.innerHTML = `
      ${thumbHtml}
      <div class="form-document-main-col">
        <div class="document-item-main">
          <div class="document-item-name">${escapeHtml(row.title || "Untitled")}</div>
          <div class="document-item-meta">${isFile ? `File: ${escapeHtml(row.file_name || "")}` : `URL`}</div>
          ${
            !isFile && url
              ? `<div class="document-item-meta">${escapeHtml(url)}</div>`
              : isFile
                ? `<div class="document-item-meta">${escapeHtml(formatBytes(row.size_bytes))}</div>`
                : ""
          }
          ${row.notes ? `<div class="document-item-meta">${escapeHtml(row.notes)}</div>` : ""}
        </div>
        <div class="document-item-actions">
          ${
            isFile
              ? `<a class="campaign-inline-duplicate" href="${escapeHtml(dl)}">Download</a>`
              : `<button type="button" class="campaign-inline-edit form-open-url-btn">Open link</button>`
          }
          <button type="button" class="danger form-delete-btn" data-id="${row.id}">Delete</button>
        </div>
      </div>
    `;
    wrap.querySelectorAll("img.form-thumb-mshot, img.form-thumb-img-file").forEach((img) => {
      img.addEventListener("error", () => {
        img.src = FORM_SNAPSHOT_PLACEHOLDER;
        img.classList.remove("form-thumb-mshot", "form-thumb-img-file");
        img.alt = "";
        img.removeAttribute("width");
        img.removeAttribute("height");
      });
    });
    const openBtn = wrap.querySelector(".form-open-url-btn");
    if (openBtn) {
      openBtn.addEventListener("click", () => openUrl(row.form_url));
    }
    wrap.querySelector(".form-delete-btn").addEventListener("click", async () => {
      try {
        await deleteForm(row.id);
        showMessage("Form removed.");
        await loadForms();
      } catch (error) {
        showMessage(error.message || "Delete failed.", true);
      }
    });
    formsListEl.appendChild(wrap);
  }
}

async function loadForms() {
  const { response, data } = await fetchApiJson("/api/forms");
  if (!response.ok) throw new Error(data.error || "Failed to load forms");
  renderForms(Array.isArray(data) ? data : []);
}

formsForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const title = String(titleEl.value || "").trim();
    const sourceType = String(sourceTypeEl.value || "url").trim();
    const notes = String(notesEl.value || "").trim();
    if (!title) throw new Error("Form name is required.");

    if (sourceType === "url") {
      const formUrl = String(urlEl.value || "").trim();
      if (!formUrl) throw new Error("Form URL is required.");
      const { response, data } = await fetchApiJson("/api/forms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, formUrl, notes })
      });
      if (!response.ok) throw new Error(data.error || "Failed to save form link");
    } else {
      const file = fileEl.files && fileEl.files[0];
      if (!file) throw new Error("Choose a form file from your computer first.");
      if (!isPcFormFile(file)) {
        throw new Error(
          "That file type is not supported. Use PDF, Word, Excel, CSV, HTML, or a common image type."
        );
      }
      showMessage("Uploading form file...");
      const formData = new FormData();
      formData.append("form", file);
      formData.append("title", title);
      formData.append("notes", notes);
      const response = await fetch(apiUrl("/api/forms/upload"), {
        method: "POST",
        body: formData
      });
      const text = await response.text();
      let data = {};
      try {
        data = text ? JSON.parse(text) : {};
      } catch {
        data = {};
      }
      if (!response.ok) throw new Error(data.error || "Failed to upload form file");
    }

    showMessage("Form saved.");
    resetForm();
    await loadForms();
  } catch (error) {
    showMessage(error.message || "Save failed.", true);
  }
});

fileEl.addEventListener("change", setFormFileHint);
sourceTypeEl.addEventListener("change", updateSourceInputs);

const backToContactsBtn = document.getElementById("backToContactsBtn");
if (backToContactsBtn) {
  backToContactsBtn.addEventListener("click", () => {
    window.location.href = "/";
  });
}

refreshBtn.addEventListener("click", async () => {
  try {
    await loadForms();
    showMessage("Forms refreshed.");
  } catch (error) {
    showMessage(error.message || "Refresh failed.", true);
  }
});

updateSourceInputs();
loadForms().catch((error) => {
  showMessage(error.message || "Failed to load forms.", true);
});
