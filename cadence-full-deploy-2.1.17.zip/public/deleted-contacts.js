(function () {
  "use strict";
  const api = window.CrmApi;
  const listEl = document.getElementById("recycleList");
  const statusEl = document.getElementById("recycleStatus");

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
    );
  }

  function daysLeft(deletedAt) {
    const t = Date.parse(String(deletedAt || "").replace(" ", "T") + "Z");
    if (!Number.isFinite(t)) return 30;
    const left = 30 - Math.floor((Date.now() - t) / 86400000);
    return Math.max(0, Math.min(30, left));
  }

  function setStatus(msg, isError) {
    if (!statusEl) return;
    statusEl.textContent = msg || "";
    statusEl.style.color = isError ? "#b91c1c" : "";
  }

  async function load() {
    setStatus("Loading…");
    try {
      const { response, data } = await api.fetchApiJson("/api/contacts/deleted");
      if (!response.ok) throw new Error((data && data.error) || "Failed to load deleted contacts.");
      render(Array.isArray(data.items) ? data.items : []);
      setStatus("");
    } catch (e) {
      setStatus(e.message || "Failed to load deleted contacts.", true);
    }
  }

  function render(items) {
    if (!listEl) return;
    if (!items.length) {
      listEl.innerHTML = '<p class="hint">No deleted contacts.</p>';
      return;
    }
    const rows = items
      .map((it) => {
        const left = daysLeft(it.deleted_at);
        return (
          "<tr>" +
          `<td>${esc(it.full_name) || "(no name)"}</td>` +
          `<td>${esc(it.email)}</td>` +
          `<td>${esc(String(it.deleted_at || "").slice(0, 10))}</td>` +
          `<td>${left} day${left === 1 ? "" : "s"} left</td>` +
          `<td><button type="button" data-restore="${it.id}">Restore</button></td>` +
          "</tr>"
        );
      })
      .join("");
    listEl.innerHTML =
      '<table class="recycle-table"><thead><tr>' +
      "<th>Name</th><th>Email</th><th>Deleted</th><th>Expires</th><th></th>" +
      `</tr></thead><tbody>${rows}</tbody></table>`;
    listEl.querySelectorAll("[data-restore]").forEach((btn) => {
      btn.addEventListener("click", () => restore(Number(btn.getAttribute("data-restore")), btn));
    });
  }

  async function restore(id, btn) {
    if (!Number.isInteger(id) || id < 1) return;
    btn.disabled = true;
    btn.textContent = "Restoring…";
    try {
      const { response, data } = await api.fetchApiJson("/api/contacts/deleted/restore", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: [id] })
      });
      if (!response.ok || !(data && data.restored)) {
        throw new Error((data && data.error) || "Restore failed.");
      }
      setStatus("Contact restored — it's back in Contacts Workspace.");
      load();
    } catch (e) {
      setStatus(e.message || "Restore failed.", true);
      btn.disabled = false;
      btn.textContent = "Restore";
    }
  }

  if (api && typeof api.fetchApiJson === "function") {
    load();
  } else {
    setStatus("Could not load the API helper. Hard-refresh the page.", true);
  }
})();
