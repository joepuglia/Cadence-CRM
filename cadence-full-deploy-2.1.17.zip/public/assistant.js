const ASSISTANT_EMAIL_DRAFT_KEY = "crm_assistant_email_draft";

const statusBadgeEl = document.getElementById("assistantStatusBadge");
const statusTextEl = document.getElementById("assistantStatusText");
const tabButtons = Array.from(document.querySelectorAll("[data-assistant-tab]"));
const tabPanels = Array.from(document.querySelectorAll("[data-assistant-panel]"));

const lastGeneratePayload = new Map();

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function formatFetchError(err) {
  const msg = String(err?.message || err || "").trim();
  if (/failed to fetch|fetch failed|networkerror|load failed/i.test(msg)) {
    return (
      "Could not reach the CRM server. Log in again, or refresh the page."
    );
  }
  return msg || "Request failed.";
}

async function fetchApiJson(path, init) {
  let response;
  try {
    response = await fetch(path, {
      credentials: "include",
      ...(init || {})
    });
  } catch (err) {
    throw new Error(formatFetchError(err));
  }
  let data = {};
  try {
    data = await response.json();
  } catch {
    data = {};
  }
  return { response, data };
}

function setStatusBadge(state, text) {
  if (!statusBadgeEl || !statusTextEl) return;
  statusBadgeEl.dataset.state = state;
  statusTextEl.textContent = text;
}

function setGenerating(form, loading) {
  const btn = form?.querySelector(".assistant-generate-btn");
  if (!btn) return;
  btn.disabled = Boolean(loading);
  btn.textContent = loading ? "Generating..." : btn.dataset.defaultLabel || btn.textContent;
}

function initGenerateButtons() {
  document.querySelectorAll(".assistant-generate-btn").forEach((btn) => {
    if (!btn.dataset.defaultLabel) btn.dataset.defaultLabel = btn.textContent;
  });
}

function showPanel(name) {
  tabButtons.forEach((btn) => {
    const active = btn.getAttribute("data-assistant-tab") === name;
    btn.classList.toggle("is-active", active);
    btn.setAttribute("aria-selected", active ? "true" : "false");
  });
  tabPanels.forEach((panel) => {
    const active = panel.getAttribute("data-assistant-panel") === name;
    panel.classList.toggle("is-active", active);
    panel.hidden = !active;
  });
}

tabButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    showPanel(btn.getAttribute("data-assistant-tab"));
  });
});

function renderResult(el, html) {
  if (!el) return;
  el.hidden = false;
  el.classList.remove("assistant-result--empty");
  el.innerHTML = html;
  // Keep the robot animation running after result renders
  const robot = document.querySelector(".assistant-avatar-sidebar lottie-player");
  if (robot) setTimeout(() => { try { robot.play(); } catch (_) {} }, 50);
}

function emptyActionButtonsHtml(formKey, { email = false, sms = false } = {}) {
  const copyLabel = sms ? "Copy SMS" : "Copy to clipboard";
  const parts = [
    `<button type="button" class="assistant-copy-btn" disabled>${copyLabel}</button>`
  ];
  if (email) {
    parts.push(`<button type="button" class="assistant-use-email-btn" disabled>Open in Send Email</button>`);
  }
  parts.push(
    `<button type="button" class="assistant-regenerate-btn" data-form-key="${escapeHtml(formKey)}" disabled>Regenerate</button>`,
    `<button type="button" class="assistant-clear-result-btn" data-form-key="${escapeHtml(formKey)}">Clear</button>`
  );
  return `<div class="assistant-result-actions">${parts.join("")}</div>`;
}

function buildEmptyResultHtml(formKey) {
  if (formKey === "email") {
    return `
      <h4>Suggested email</h4>
      <p class="hint" style="margin-top:0">Drafts are suggestions - review before sending.</p>
      <p><strong>Subject:</strong> <span class="assistant-result-placeholder">—</span></p>
      <div class="assistant-email-draft-body assistant-email-draft-body--empty">
        <p class="hint assistant-result-empty-note">Your draft will appear here after you generate.</p>
      </div>
      ${emptyActionButtonsHtml(formKey, { email: true })}
    `;
  }
  if (formKey === "sms") {
    return `
      <h4>Suggested SMS</h4>
      <pre class="assistant-result-pre assistant-result-pre--empty">Your SMS draft will appear here after you generate.</pre>
      ${emptyActionButtonsHtml(formKey, { sms: true })}
      <p class="hint">Paste into the SMS field when you text a contact from Contacts Workspace.</p>
    `;
  }
  if (formKey === "automation") {
    return `
      <h4>Automation ideas</h4>
      <p class="hint assistant-result-empty-note">Ideas will appear here after you generate.</p>
      ${emptyActionButtonsHtml(formKey)}
    `;
  }
  if (formKey === "pipeline") {
    return `
      <h4>Pipeline summary</h4>
      <p class="hint assistant-result-empty-note">Your pipeline summary will appear here after you generate.</p>
      ${emptyActionButtonsHtml(formKey)}
      <p><a href="/pipeline.html">Open Pipeline Summary →</a></p>
    `;
  }
  const title = textToolTitle(formKey);
  return `
    <h4>${escapeHtml(title)}</h4>
    <pre class="assistant-result-pre assistant-result-pre--empty">Your ${escapeHtml(title.toLowerCase())} will appear here after you generate.</pre>
    ${emptyActionButtonsHtml(formKey)}
  `;
}

function bindEmptyResultActions(container, { formKey, form, resultEl } = {}) {
  container.querySelectorAll(".assistant-clear-result-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      if (formKey) lastGeneratePayload.delete(formKey);
      renderEmptyResult(resultEl, formKey, form);
    });
  });
}

function renderEmptyResult(el, formKey, form) {
  if (!el) return;
  el.hidden = false;
  el.classList.add("assistant-result--empty");
  el.innerHTML = buildEmptyResultHtml(formKey);
  bindEmptyResultActions(el, { formKey, form, resultEl: el });
}

function clearResult(el, formKey, form) {
  renderEmptyResult(el, formKey, form);
}

function formatEmailDraftBody(text) {
  const paragraphs = String(text || "")
    .replace(/\r\n/g, "\n")
    .split(/\n\s*\n/)
    .map((part) => part.trim())
    .filter(Boolean);
  if (!paragraphs.length) return `<p class="hint">No body returned.</p>`;
  return paragraphs.map((part) => `<p>${escapeHtml(part.replace(/\n/g, " "))}</p>`).join("");
}

function actionButtonsHtml({ copyText, emailDraft, smsText, formKey }) {
  const parts = [];
  if (copyText) {
    parts.push(
      `<button type="button" class="assistant-copy-btn" data-copy="${escapeHtml(copyText)}" data-copy-label="Copy to clipboard">Copy to clipboard</button>`
    );
  }
  if (emailDraft) {
    parts.push(`<button type="button" class="assistant-use-email-btn">Open in Send Email</button>`);
  }
  if (smsText) {
    parts.push(
      `<button type="button" class="assistant-copy-btn" data-copy="${escapeHtml(smsText)}" data-copy-label="Copy SMS">Copy SMS</button>`
    );
  }
  if (formKey) {
    parts.push(`<button type="button" class="assistant-regenerate-btn" data-form-key="${escapeHtml(formKey)}">Regenerate</button>`);
    parts.push(`<button type="button" class="assistant-clear-result-btn" data-form-key="${escapeHtml(formKey)}">Clear</button>`);
  }
  return `<div class="assistant-result-actions">${parts.join("")}</div>`;
}

function formatPipelineSummaryMarkdown(text) {
  const lines = String(text || "").split(/\r?\n/);
  const parts = [];
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    if (/^##\s+/.test(trimmed)) {
      parts.push(`<h4 class="assistant-summary-h4">${escapeHtml(trimmed.replace(/^##\s+/, ""))}</h4>`);
    } else if (/^(SNAPSHOT|WHAT NEEDS ATTENTION|TOP 3 ACTIONS)\b/i.test(trimmed)) {
      parts.push(`<h4 class="assistant-summary-h4">${escapeHtml(trimmed)}</h4>`);
    } else if (/^[-*]\s+/.test(trimmed)) {
      parts.push(`<p class="assistant-summary-bullet">• ${escapeHtml(trimmed.replace(/^[-*]\s+/, ""))}</p>`);
    } else if (/^\d+\.\s+/.test(trimmed)) {
      parts.push(`<p class="assistant-summary-numbered">${escapeHtml(trimmed)}</p>`);
    } else {
      parts.push(`<p>${escapeHtml(trimmed)}</p>`);
    }
  }
  return parts.join("");
}

function smsCountClass(count, limit = 160) {
  if (count > limit) return "assistant-sms-meta--warn";
  if (count >= limit - 20) return "assistant-sms-meta--caution";
  return "";
}

function bindResultActions(container, { emailDraft, formKey, form, resultEl } = {}) {
  container.querySelectorAll(".assistant-copy-btn").forEach((btn) => {
    const defaultLabel = btn.getAttribute("data-copy-label") || "Copy";
    btn.addEventListener("click", async () => {
      const text = btn.getAttribute("data-copy") || "";
      try {
        await navigator.clipboard.writeText(text);
        btn.textContent = "Copied!";
        setTimeout(() => {
          btn.textContent = defaultLabel;
        }, 1500);
      } catch {
        window.prompt("Copy this text:", text);
      }
    });
  });

  const emailBtn = container.querySelector(".assistant-use-email-btn");
  if (emailBtn && emailDraft) {
    emailBtn.addEventListener("click", () => {
      try {
        sessionStorage.setItem(ASSISTANT_EMAIL_DRAFT_KEY, JSON.stringify(emailDraft));
      } catch {
        /* ignore */
      }
      window.location.href = "/email.html";
    });
  }

  container.querySelectorAll(".assistant-regenerate-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      if (form) form.requestSubmit();
    });
  });

  container.querySelectorAll(".assistant-clear-result-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      if (formKey) lastGeneratePayload.delete(formKey);
      clearResult(resultEl, formKey, form);
    });
  });
}

async function postGenerate(body) {
  return fetchApiJson("/api/assistant/generate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
}

function resolvePurpose(form) {
  const select = form.querySelector(".assistant-purpose-select");
  const hidden = form.querySelector('input[name="purpose"]');
  const customWrap = form.querySelector(".assistant-purpose-custom-wrap");
  const customInput = form.querySelector(".assistant-purpose-custom-input");
  if (!select || !hidden) return String(hidden?.value || "").trim();

  if (select.value === "__custom__") {
    if (customWrap) customWrap.hidden = false;
    if (customInput) customInput.required = true;
    hidden.value = String(customInput?.value || "").trim();
  } else {
    if (customWrap) customWrap.hidden = true;
    if (customInput) {
      customInput.required = false;
      customInput.value = "";
    }
    hidden.value = String(select.value || "").trim();
  }
  return hidden.value;
}

function wirePurposeSelect(form) {
  const select = form.querySelector(".assistant-purpose-select");
  if (!select) return;
  select.addEventListener("change", () => resolvePurpose(form));
  const customInput = form.querySelector(".assistant-purpose-custom-input");
  const hiddenPurpose = form.querySelector('input[name="purpose"]');
  // Update the hidden purpose field directly on each keystroke — do NOT call
  // resolvePurpose() here because its else-branch would clear customInput.value.
  customInput?.addEventListener("input", () => {
    if (hiddenPurpose) hiddenPurpose.value = customInput.value.trim();
  });
}

function formFields(form) {
  resolvePurpose(form);
  const data = {};
  if (!form) return data;
  new FormData(form).forEach((value, key) => {
    data[key] = String(value || "").trim();
  });
  return data;
}

function formatContactPreview(ctx) {
  if (!ctx) return "";

  // Strip JSON blobs and skip pure-API entries from activity lines
  function cleanActivity(raw) {
    if (!raw || typeof raw !== "string") return null;
    // Remove everything from the first { or [ onward (raw JSON payloads)
    let line = raw.replace(/[\{\[][\s\S]*/g, "").trim();
    // Skip lines that are only a technical marker with no human content
    if (!line || /^CALL_WITH_RECORDING$/i.test(line)) return null;
    // Trim trailing punctuation left after stripping
    line = line.replace(/[-–—\s]+$/, "").trim();
    return line || null;
  }

  const recentLines = (ctx.recentActivity || [])
    .map(cleanActivity)
    .filter(Boolean)
    .slice(0, 3);

  const lines = [
    ctx.fullName             ? `Name: ${ctx.fullName}`                                              : "",
    (ctx.status || ctx.outcome) ? `Status: ${ctx.status || "-"} — Outcome: ${ctx.outcome || "-"}` : "",
    ctx.leadSource           ? `Lead source: ${ctx.leadSource}`                                     : "",
    ctx.state                ? `State: ${ctx.state}`                                                : "",
    ctx.email                ? `Email: ${ctx.email}`                                                : "",
    ctx.phone                ? `Phone: ${ctx.phone}`                                                : "",
    ctx.tags                 ? `Tags: ${ctx.tags}`                                                  : "",
    recentLines.length       ? `Recent activity:\n${recentLines.join("\n")}`                        : ""
  ].filter(Boolean);

  return lines.join("\n");
}

function wireContactSearch(form) {
  const field = form.querySelector(".assistant-contact-field");
  if (!field) return;

  const searchInput = field.querySelector(".assistant-contact-search");
  const resultsEl = field.querySelector(".assistant-contact-results");
  const chipEl = field.querySelector(".assistant-contact-chip");
  const chipLabel = field.querySelector(".assistant-contact-chip__label");
  const chipClear = field.querySelector(".assistant-contact-chip__clear");
  const idInput = form.querySelector('input[name="contactId"]');
  const nameInput = form.querySelector('input[name="contactName"]');
  // Dynamically ensure a hidden contactEmail field exists on the form
  let emailInput = form.querySelector('input[name="contactEmail"]');
  if (!emailInput) {
    emailInput = document.createElement("input");
    emailInput.type = "hidden";
    emailInput.name = "contactEmail";
    form.appendChild(emailInput);
  }
  const previewEl = form.querySelector(".assistant-contact-preview");
  const previewBody = form.querySelector(".assistant-contact-preview__body");

  let debounceTimer = null;

  function hideResults() {
    if (resultsEl) {
      resultsEl.hidden = true;
      resultsEl.innerHTML = "";
    }
  }

  function clearContact() {
    if (idInput) idInput.value = "";
    if (nameInput) nameInput.value = "";
    if (searchInput) {
      searchInput.value = "";
      searchInput.hidden = false;
    }
    if (chipEl) chipEl.hidden = true;
    if (previewEl) previewEl.hidden = true;
    if (previewBody) previewBody.textContent = "";
    hideResults();
  }

  async function selectContact(contact) {
    const id = contact.id;
    const label = contact.full_name || contact.fullName || contact.email || `Contact #${id}`;
    if (idInput) idInput.value = String(id);
    if (nameInput) nameInput.value = String(label);
    if (searchInput) {
      searchInput.value = "";
      searchInput.hidden = true;
    }
    if (chipEl && chipLabel) {
      chipLabel.textContent = label;
      chipEl.hidden = false;
    }
    hideResults();

    try {
      const { response, data } = await fetchApiJson(`/api/assistant/contact/${encodeURIComponent(id)}`);
      if (response.ok && data) {
        if (previewBody) previewBody.textContent = formatContactPreview(data);
        if (previewEl) previewEl.hidden = false;
        if (nameInput) nameInput.value = String(data.fullName || label);
        if (emailInput) emailInput.value = String(data.email || "");
      }
    } catch {
      /* optional preview */
    }
  }

  chipClear?.addEventListener("click", clearContact);

  searchInput?.addEventListener("input", () => {
    const q = String(searchInput.value || "").trim();
    clearTimeout(debounceTimer);
    if (q.length < 2) {
      hideResults();
      return;
    }
    debounceTimer = setTimeout(async () => {
      try {
        const { response, data } = await fetchApiJson(
          `/api/contacts?q=${encodeURIComponent(q)}&page=1&limit=8&sortBy=full_name&sortOrder=asc`
        );
        const rows = Array.isArray(data?.items) ? data.items : Array.isArray(data?.contacts) ? data.contacts : [];
        if (!response.ok || !rows.length) {
          hideResults();
          return;
        }
        resultsEl.innerHTML = rows
          .map(
            (c) =>
              `<li><button type="button" class="assistant-contact-pick" data-id="${escapeHtml(c.id)}" data-name="${escapeHtml(c.full_name || "")}">${escapeHtml(c.full_name || "Unnamed")}<span class="assistant-contact-pick__meta">${escapeHtml([c.outcome, c.email].filter(Boolean).join(" - "))}</span></button></li>`
          )
          .join("");
        resultsEl.hidden = false;
        resultsEl.querySelectorAll(".assistant-contact-pick").forEach((btn) => {
          btn.addEventListener("click", () => {
            selectContact({
              id: btn.getAttribute("data-id"),
              full_name: btn.getAttribute("data-name")
            });
          });
        });
      } catch {
        hideResults();
      }
    }, 280);
  });

  document.addEventListener("click", (event) => {
    if (!field.contains(event.target)) hideResults();
  });
}

function wireClearForm(form, resultEl, formKey) {
  form.querySelector(".assistant-clear-form-btn")?.addEventListener("click", () => {
    form.reset();
    const customWrap = form.querySelector(".assistant-purpose-custom-wrap");
    if (customWrap) customWrap.hidden = true;
    const searchInput = form.querySelector(".assistant-contact-search");
    if (searchInput) searchInput.hidden = false;
    const chip = form.querySelector(".assistant-contact-chip");
    if (chip) chip.hidden = true;
    const preview = form.querySelector(".assistant-contact-preview");
    if (preview) preview.hidden = true;
    clearResult(resultEl, formKey, form);
    if (formKey) lastGeneratePayload.delete(formKey);
  });
}

async function handleEmailSubmit(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const fields = formFields(form);
  if (!fields.purpose) {
    alert("Choose or enter an email purpose.");
    return;
  }
  const resultEl = document.getElementById("assistantEmailResult");
  const formKey = "email";
  lastGeneratePayload.set(formKey, { ...fields });
  setGenerating(form, true);
  try {
    const { response, data } = await postGenerate({ mode: "email", ...fields });
    if (!response.ok) throw new Error(data.error || "Could not generate email draft.");
    const draft = {
      subject: data.subject || "",
      text: data.text || "",
      html: data.html || data.text || "",
      contactId: fields.contactId || "",
      contactEmail: fields.contactEmail || ""
    };
    const html = `
      <h4>Suggested email</h4>
      <p class="hint" style="margin-top:0">Drafts are suggestions - review before sending.</p>
      <p><strong>Subject:</strong> ${escapeHtml(draft.subject || "(none)")}</p>
      <div class="assistant-email-draft-body">${formatEmailDraftBody(draft.text || "")}</div>
      ${actionButtonsHtml({
        copyText: `Subject: ${draft.subject}\n\n${draft.text}`,
        emailDraft: draft,
        formKey
      })}
    `;
    renderResult(resultEl, html);
    bindResultActions(resultEl, { emailDraft: draft, formKey, form, resultEl });
  } catch (err) {
    renderResult(resultEl, `<p class="assistant-error">${escapeHtml(err.message)}</p>`);
  } finally {
    setGenerating(form, false);
  }
}

async function handleSmsSubmit(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const fields = formFields(form);
  if (!fields.purpose) {
    alert("Choose or enter an SMS purpose.");
    return;
  }
  const resultEl = document.getElementById("assistantSmsResult");
  const formKey = "sms";
  const maxLimit = Number(fields.maxChars) || 160;
  setGenerating(form, true);
  try {
    const { response, data } = await postGenerate({
      mode: "sms",
      ...fields,
      maxChars: maxLimit
    });
    if (!response.ok) throw new Error(data.error || "Could not generate SMS draft.");
    const message = String(data.message || "").trim();
    const message2 = String(data.message2 || "").trim();
    const count1 = Number(data.characterCount) || message.length;
    const count2 = message2 ? Number(data.characterCount2) || message2.length : 0;
    const smsCopy = message2 ? `${message}\n\n---\n\n${message2}` : message;
    const warn1 = count1 > 160 && maxLimit <= 160;
    const warn2 = count2 > 160 && maxLimit <= 160;
    let smsBody = `
      <h4>Suggested SMS</h4>
      <p class="assistant-sms-meta ${smsCountClass(count1, 160)}">Message 1: <strong>${count1}</strong> / 160 characters${warn1 ? " - exceeds single SMS; will use 2+ segments" : ""}</p>
      <pre class="assistant-result-pre">${escapeHtml(message)}</pre>`;
    if (message2) {
      smsBody += `
      <p class="assistant-sms-meta ${smsCountClass(count2, 160)}">Message 2: <strong>${count2}</strong> / 160 characters (send as a second text)${warn2 ? " - long segment" : ""}</p>
      <pre class="assistant-result-pre">${escapeHtml(message2)}</pre>`;
    }
    if (data.isTwoPart || message2) {
      smsBody += `<p class="hint assistant-sms-split-note">This draft splits into two texts - each counts toward Twilio usage.</p>`;
    }
    const html = `${smsBody}
      ${actionButtonsHtml({ smsText: smsCopy, formKey })}
      <p class="hint">Paste into the SMS field when you text a contact from Contacts Workspace.</p>
    `;
    renderResult(resultEl, html);
    bindResultActions(resultEl, { formKey, form, resultEl });
  } catch (err) {
    renderResult(resultEl, `<p class="assistant-error">${escapeHtml(err.message)}</p>`);
  } finally {
    setGenerating(form, false);
  }
}

async function handleAutomationSubmit(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const fields = formFields(form);
  const resultEl = document.getElementById("assistantAutomationResult");
  const formKey = "automation";
  setGenerating(form, true);
  try {
    const { response, data } = await postGenerate({ mode: "automation", ...fields });
    if (!response.ok) throw new Error(data.error || "Could not generate automation ideas.");
    const ideas = Array.isArray(data.ideas) ? data.ideas : [];
    let body = "";
    if (ideas.length) {
      body = ideas
        .map((idea, index) => {
          const trigger = idea.trigger || idea.triggerTag || "";
          const action = idea.action || "";
          const purpose = idea.purpose || idea.summary || "";
          const setup = idea.setup || "";
          return `<article class="assistant-idea-card">
            <h4>${index + 1}. ${escapeHtml(idea.name || "Automation idea")}</h4>
            <p><strong>Trigger -></strong> ${escapeHtml(trigger)}</p>
            <p><strong>Action -></strong> ${escapeHtml(action)}</p>
            <p><strong>Purpose -></strong> ${escapeHtml(purpose)}</p>
            <p><strong>How to set it up:</strong> ${escapeHtml(setup)}</p>
            <p><a href="/automations.html">Build in Automations -></a></p>
          </article>`;
        })
        .join("");
      body += actionButtonsHtml({ formKey });
    } else {
      body = `<pre class="assistant-result-pre">${escapeHtml(data.raw || "No structured ideas returned.")}</pre>`;
    }
    renderResult(resultEl, body);
    bindResultActions(resultEl, { formKey, form, resultEl });
  } catch (err) {
    renderResult(resultEl, `<p class="assistant-error">${escapeHtml(err.message)}</p>`);
  } finally {
    setGenerating(form, false);
  }
}

async function handlePipelineSubmit(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const fields = formFields(form);
  const resultEl = document.getElementById("assistantPipelineResult");
  const formKey = "pipeline";
  setGenerating(form, true);
  try {
    const { response, data } = await postGenerate({
      mode: "pipeline",
      pastDays: Number(fields.pastDays) || 30,
      futureDays: Number(fields.futureDays) || 14
    });
    if (!response.ok) throw new Error(data.error || "Could not summarize pipeline.");
    const snap = data.snapshot || {};
    const stats = `
      <div class="assistant-pipeline-stats">
        <span><strong>${escapeHtml(String(snap.totalContacts ?? "-"))}</strong> contacts</span>
        <span><strong>${escapeHtml(String(snap.closeRate != null ? snap.closeRate + "%" : "-"))}</strong> close rate</span>
        <span><strong>${escapeHtml(String(snap.newLeads ?? "-"))}</strong> new leads (${escapeHtml(String(snap.pastDays || 30))}d)</span>
        <span><strong>${escapeHtml(String(snap.staleLeads ?? "-"))}</strong> NEW no activity (7d+)</span>
      </div>`;
    const summaryHtml = formatPipelineSummaryMarkdown(data.summary || "");
    renderResult(
      resultEl,
      `<h4>Pipeline summary</h4>${stats}<div class="assistant-summary-body">${summaryHtml}</div>
       ${actionButtonsHtml({ formKey })}
       <p><a href="/pipeline.html">Open Pipeline Summary -></a></p>`
    );
    bindResultActions(resultEl, { formKey, form, resultEl });
  } catch (err) {
    renderResult(resultEl, `<p class="assistant-error">${escapeHtml(err.message)}</p>`);
  } finally {
    setGenerating(form, false);
  }
}

function textToolTitle(mode) {
  if (mode === "objection") return "Objection Coach";
  if (mode === "call-script") return "Call Script";
  if (mode === "voicemail") return "Voicemail Script";
  if (mode === "follow-up-sequence") return "Follow-Up Sequence";
  if (mode === "plan-comparison") return "Plan Comparison";
  return "AI Result";
}

function validateTextTool(mode, fields) {
  if (mode === "objection" && !fields.objection) return "Enter the client objection.";
  if (mode === "call-script" && !fields.callType) return "Choose a call type.";
  if (mode === "voicemail" && !fields.purpose) return "Enter the voicemail purpose.";
  if (mode === "follow-up-sequence" && !fields.situation && !fields.contactId) {
    return "Describe the contact situation or select a contact.";
  }
  if (mode === "plan-comparison" && (!fields.planA || !fields.planB)) return "Paste details for both plans.";
  return "";
}

async function handleTextToolSubmit(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const mode = form.dataset.assistantForm || "";
  const fields = formFields(form);
  const error = validateTextTool(mode, fields);
  if (error) {
    alert(error);
    return;
  }
  const resultEl = document.getElementById(`assistant${modeToResultId(mode)}Result`);
  const formKey = mode;
  setGenerating(form, true);
  try {
    const { response, data } = await postGenerate({ mode, ...fields });
    if (!response.ok) throw new Error(data.error || "Could not generate this assistant result.");
    const text = String(data.text || "").trim();
    renderResult(
      resultEl,
      `<h4>${escapeHtml(textToolTitle(mode))}</h4>
       <pre class="assistant-result-pre">${escapeHtml(text || "No response returned.")}</pre>
       ${actionButtonsHtml({ copyText: text, formKey })}`
    );
    bindResultActions(resultEl, { formKey, form, resultEl });
  } catch (err) {
    renderResult(resultEl, `<p class="assistant-error">${escapeHtml(err.message)}</p>`);
  } finally {
    setGenerating(form, false);
  }
}

function modeToResultId(mode) {
  return String(mode || "")
    .split("-")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join("");
}

const emailForm = document.getElementById("assistantEmailForm");
const smsForm = document.getElementById("assistantSmsForm");
const automationForm = document.getElementById("assistantAutomationForm");
const pipelineForm = document.getElementById("assistantPipelineForm");
const textToolForms = [
  document.getElementById("assistantObjectionForm"),
  document.getElementById("assistantCallScriptForm"),
  document.getElementById("assistantVoicemailForm"),
  document.getElementById("assistantFollowUpSequenceForm"),
  document.getElementById("assistantPlanComparisonForm")
].filter(Boolean);

[emailForm, smsForm, ...textToolForms].forEach((form) => {
  if (!form) return;
  wirePurposeSelect(form);
  wireContactSearch(form);
  const resultEl = document.getElementById(`assistant${modeToResultId(form.dataset.assistantForm)}Result`);
  wireClearForm(form, resultEl, form.dataset.assistantForm);
});

automationForm && wireClearForm(automationForm, document.getElementById("assistantAutomationResult"), "automation");
pipelineForm && wireClearForm(pipelineForm, document.getElementById("assistantPipelineResult"), "pipeline");

emailForm?.addEventListener("submit", handleEmailSubmit);
smsForm?.addEventListener("submit", handleSmsSubmit);
textToolForms.forEach((form) => form.addEventListener("submit", handleTextToolSubmit));
automationForm?.addEventListener("submit", handleAutomationSubmit);
pipelineForm?.addEventListener("submit", handlePipelineSubmit);

// Re-engagement Detector
const reengageForm = document.getElementById("assistantReengageForm");
const reengageResultEl = document.getElementById("assistantReengageResult");
reengageForm && wireClearForm(reengageForm, reengageResultEl, "reengage");

reengageForm?.addEventListener("submit", async (event) => {
  event.preventDefault();
  const fields = formFields(reengageForm);
  setGenerating(reengageForm, true);
  clearResult(reengageResultEl);
  try {
    const { response, data } = await fetchApiJson("/api/assistant/reengage", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(fields)
    });
    if (!response.ok) throw new Error(data.error || "Re-engagement scan failed.");
    if (!data.contacts?.length) {
      renderResult(reengageResultEl, `<p class="hint">${escapeHtml(data.message || "No inactive contacts found.")}</p>`);
      return;
    }
    const channel = fields.channel || "email";
    const cards = data.contacts.map(({ contact, subject, body, error }) => {
      const name = escapeHtml(contact.full_name || "Contact");
      const daysSince = contact.days_since_contact ? `${contact.days_since_contact} days inactive` : "inactive";
      const status = escapeHtml(contact.status || "");
      if (error) return `<div class="reengage-card"><p class="reengage-card__name">${name}</p><p class="assistant-error">${escapeHtml(error)}</p></div>`;
      const copyText = channel === "email" ? `Subject: ${subject}\n\n${body}` : body;
      return `
        <div class="reengage-card">
          <div class="reengage-card__meta">
            <span class="reengage-card__name">${name}</span>
            <span class="reengage-card__days">${daysSince}${status ? ` · ${status}` : ""}</span>
          </div>
          ${subject ? `<p class="reengage-card__subject">Subject: ${escapeHtml(subject)}</p>` : ""}
          <p class="reengage-card__body">${escapeHtml(body)}</p>
          <div class="assistant-result-actions">
            <button type="button" class="assistant-copy-btn" data-copy="${escapeHtml(copyText)}">Copy</button>
            ${channel === "email" && contact.email ? `<a href="/email.html" class="assistant-action-btn" onclick="try{sessionStorage.setItem('crm_assistant_email_draft',JSON.stringify({subject:${JSON.stringify(subject)},text:${JSON.stringify(body)},html:${JSON.stringify(body)},contactEmail:${JSON.stringify(contact.email)}}));}catch(e){}">Open in Send Email</a>` : ""}
          </div>
        </div>`;
    }).join("");
    renderResult(reengageResultEl, `
      <h4>${data.contacts.length} inactive contact${data.contacts.length !== 1 ? "s" : ""} found — ${data.days}+ days</h4>
      <p class="hint" style="margin-top:0">Review each draft and send or copy as needed.</p>
      <div class="reengage-cards">${cards}</div>
    `);
    reengageResultEl.querySelectorAll(".assistant-copy-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        navigator.clipboard.writeText(btn.dataset.copy || "").catch(() => {});
        btn.textContent = "Copied!";
        setTimeout(() => { btn.textContent = "Copy"; }, 2000);
      });
    });
  } catch (err) {
    renderResult(reengageResultEl, `<p class="assistant-error">${escapeHtml(err.message)}</p>`);
  } finally {
    setGenerating(reengageForm, false);
  }
});

async function loadAssistantStatus() {
  try {
    const { response, data } = await fetchApiJson("/api/assistant/status");
    if (!response.ok) {
      if (response.status === 404) {
        throw new Error("not_found");
      }
      throw new Error(data.error || "Could not load AI status.");
    }
    if (data.configured) {
      setStatusBadge(
        "ready",
        `AI ready - Drafts are suggestions; review before sending.`
      );
    } else {
      setStatusBadge(
        "unconfigured",
        "AI not configured on this server - ask your CRM administrator to add the Claude API key."
      );
      document.querySelectorAll(".assistant-generate-btn").forEach((btn) => {
        btn.disabled = true;
      });
    }
  } catch (err) {
    const msg = String(err.message || "");
    if (/not found/i.test(msg)) {
      setStatusBadge("error", "Connection error - restart the CRM server, then refresh this page.");
      return;
    }
    setStatusBadge("error", msg || "Connection error - could not reach AI Assistant.");
  }
}

function initResultPanels() {
  document.querySelectorAll(".assistant-result").forEach((resultEl) => {
    const panel = resultEl.closest("[data-assistant-panel]");
    const formKey = panel?.getAttribute("data-assistant-panel") || "";
    const form = formKey
      ? document.querySelector(`[data-assistant-form="${formKey}"]`)
      : null;
    renderEmptyResult(resultEl, formKey, form);
  });
}

initGenerateButtons();
initResultPanels();
loadAssistantStatus();
