const loginForm = document.getElementById("loginForm");
const loginEmailInput = document.getElementById("loginEmail");
const loginPasswordInput = document.getElementById("loginPassword");
const loginMessageEl = document.getElementById("loginMessage");
const login2faPanel = document.getElementById("login2faPanel");
const login2faCode = document.getElementById("login2faCode");
const login2faVerifyBtn = document.getElementById("login2faVerifyBtn");
const login2faBackBtn = document.getElementById("login2faBackBtn");
const loginSubmitBtn = document.getElementById("loginSubmitBtn");
const loginSubmitLabel = document.getElementById("loginSubmitLabel");
const loginForgotToggle = document.getElementById("loginForgotToggle");
const loginForgotPanel = document.getElementById("loginForgotPanel");
const loginForgotSubmitBtn = document.getElementById("loginForgotSubmitBtn");

let loginPasswordRequired = false;
let pending2faChallenge = "";
const LOGIN_TIMEOUT_MESSAGE_KEY = "crm_login_timeout_msg";
const LOGIN_TIMEOUT_AT_KEY = "crm_login_timeout_at";
const HAD_AUTH_SESSION_KEY = "crm_had_authenticated_session";

function setMessage(text, isError = false) {
  if (!loginMessageEl) return;
  loginMessageEl.textContent = String(text || "");
  loginMessageEl.classList.remove("signin-message--error", "signin-message--ok");
  if (text) {
    loginMessageEl.classList.add(isError ? "signin-message--error" : "signin-message--ok");
  }
}

function getNextPath() {
  // Always open Contacts Workspace after sign-in (idle timeout, logout, or fresh login).
  // Ignore ?next= so agents don't land back on whatever page timed them out.
  return "/index.html";
}

function apiUrl(path) {
  const p = path.startsWith("/") ? path : `/${path}`;
  return p;
}

async function fetchApiJson(path, options = {}, attempt = 0) {
  const url = apiUrl(path);
  let response;
  try {
    response = await fetch(url, { credentials: "include", ...options });
  } catch {
    if (attempt < 1) {
      await new Promise((resolve) => setTimeout(resolve, 1500));
      return fetchApiJson(path, options, attempt + 1);
    }
    throw new Error("Cannot reach Cadence right now. Wait a few seconds and sign in again.");
  }
  const text = await response.text();
  const trimmed = String(text || "").trim();
  if (trimmed.startsWith("<")) {
    if (attempt < 1) {
      await new Promise((resolve) => setTimeout(resolve, 1500));
      return fetchApiJson(path, options, attempt + 1);
    }
    throw new Error("The connection to Cadence dropped. Wait a few seconds and sign in again.");
  }
  let payload = {};
  try {
    payload = trimmed ? JSON.parse(trimmed) : {};
  } catch {
    throw new Error("Cadence sent an unexpected response. Wait a few seconds and sign in again.");
  }
  if (!response.ok) {
    throw new Error(String(payload?.error || payload?.message || "Request failed"));
  }
  return payload;
}

function show2faStep(challengeToken) {
  pending2faChallenge = challengeToken;
  if (login2faPanel) {
    login2faPanel.classList.remove("hidden");
    login2faPanel.setAttribute("aria-hidden", "false");
  }
  if (loginEmailInput) loginEmailInput.disabled = true;
  if (loginPasswordInput) loginPasswordInput.disabled = true;
  if (loginSubmitBtn) loginSubmitBtn.disabled = true;
  if (login2faCode) {
    login2faCode.value = "";
    login2faCode.focus();
  }
  setMessage("Password accepted. Enter your authenticator code.");
}

function hide2faStep() {
  pending2faChallenge = "";
  if (login2faPanel) {
    login2faPanel.classList.add("hidden");
    login2faPanel.setAttribute("aria-hidden", "true");
  }
  if (loginEmailInput) loginEmailInput.disabled = false;
  if (loginPasswordInput) loginPasswordInput.disabled = false;
  if (loginSubmitBtn) loginSubmitBtn.disabled = false;
}

async function resolveIdleTimeoutMinutes(fallbackFromUrl) {
  const fromUrl = Number(fallbackFromUrl);
  try {
    const status = await fetchApiJson("/api/auth/status");
    const fromServer = Number(status?.idleTimeoutMinutes);
    if (Number.isFinite(fromServer) && fromServer > 0) return fromServer;
  } catch {
    /* ignore — fall through */
  }
  if (Number.isFinite(fromUrl) && fromUrl > 0) return fromUrl;
  return 60;
}

async function showInactivityLogoutMessage() {
  const params = new URLSearchParams(window.location.search);
  const signedOutExplicitly = params.get("signedOut") === "1";
  const mins = await resolveIdleTimeoutMinutes(params.get("idle"));
  const text = `You were signed out after ${mins} minutes of inactivity.`;

  function clearTimeoutStorage() {
    try {
      sessionStorage.removeItem(LOGIN_TIMEOUT_MESSAGE_KEY);
      sessionStorage.removeItem(LOGIN_TIMEOUT_AT_KEY);
      localStorage.removeItem(LOGIN_TIMEOUT_MESSAGE_KEY);
      localStorage.removeItem(LOGIN_TIMEOUT_AT_KEY);
      localStorage.removeItem(HAD_AUTH_SESSION_KEY);
      sessionStorage.removeItem(HAD_AUTH_SESSION_KEY);
    } catch {
      /* ignore */
    }
  }

  if (params.get("timeout") === "1" || params.get("sessionExpired") === "1") {
    setMessage(text, true);
    clearTimeoutStorage();
    return true;
  }
  try {
    const stored = String(sessionStorage.getItem(LOGIN_TIMEOUT_MESSAGE_KEY) || "").trim();
    if (stored) {
      // Always show the live server timeout (ignore stale "30 minutes" text in storage).
      setMessage(text, true);
      clearTimeoutStorage();
      return true;
    }
  } catch {
    /* ignore */
  }
  try {
    const stored = String(localStorage.getItem(LOGIN_TIMEOUT_MESSAGE_KEY) || "").trim();
    const at = Number(localStorage.getItem(LOGIN_TIMEOUT_AT_KEY) || 0);
    const fresh = Number.isFinite(at) && at > 0 && Date.now() - at < 5 * 60 * 1000;
    if (stored && fresh) {
      setMessage(text, true);
      clearTimeoutStorage();
      return true;
    }
  } catch {
    /* ignore */
  }
  if (!signedOutExplicitly) {
    try {
      const hadSession =
        localStorage.getItem(HAD_AUTH_SESSION_KEY) === "1" || sessionStorage.getItem(HAD_AUTH_SESSION_KEY) === "1";
      if (hadSession) {
        setMessage(text, true);
        clearTimeoutStorage();
        return true;
      }
    } catch {
      /* ignore */
    }
  }
  return false;
}

function looksLikeTwilioAccountSid(value) {
  return /^AC[a-f0-9]{32}$/i.test(String(value || "").trim());
}

function clearLoginCredentialFields() {
  if (loginEmailInput) loginEmailInput.value = "";
  if (loginPasswordInput) loginPasswordInput.value = "";
}

/** Browsers sometimes autofill Twilio Account SID + Auth Token into the sign-in form. */
function sanitizeLoginAutofill() {
  if (!loginEmailInput) return;
  const emailVal = String(loginEmailInput.value || "").trim();
  if (looksLikeTwilioAccountSid(emailVal)) {
    clearLoginCredentialFields();
  }
}

function scheduleLoginAutofillSanitize() {
  sanitizeLoginAutofill();
  window.requestAnimationFrame(sanitizeLoginAutofill);
  window.setTimeout(sanitizeLoginAutofill, 100);
  window.setTimeout(sanitizeLoginAutofill, 500);
}

async function initLoginPage() {
  const params = new URLSearchParams(window.location.search);
  if (params.get("signedOut") === "1") {
    clearLoginCredentialFields();
  }
  scheduleLoginAutofillSanitize();
  const hadTimeoutMessage = await showInactivityLogoutMessage();
  try {
    const status = await fetchApiJson("/api/auth/status");
    if (!status.loginRequired && !hadTimeoutMessage) {
      window.location.href = getNextPath();
      return;
    }
    loginPasswordRequired = Boolean(status.passwordRequired);
    if (loginPasswordInput) {
      loginPasswordInput.required = loginPasswordRequired;
    }
    if (status.authenticated && !hadTimeoutMessage) {
      window.location.href = getNextPath();
    }
  } catch {
    // ignore status errors; user can still submit login.
  }
}

async function verify2faAndContinue() {
  const code = String(login2faCode?.value || "").trim();
  if (!code) throw new Error("Enter your 6-digit code.");
  if (!pending2faChallenge) throw new Error("Session expired. Sign in again.");
  setMessage("Verifying...");
  await fetchApiJson("/api/auth/verify-2fa", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ challengeToken: pending2faChallenge, code }),
    credentials: "include"
  });
  setMessage("Signed in.");
  window.location.href = getNextPath();
}

function setForgotPanelVisible(show) {
  if (!loginForgotPanel || !loginForgotToggle) return;
  loginForgotPanel.classList.toggle("hidden", !show);
  loginForgotPanel.setAttribute("aria-hidden", show ? "false" : "true");
  loginForgotToggle.setAttribute("aria-expanded", show ? "true" : "false");
}

if (loginForgotToggle) {
  loginForgotToggle.addEventListener("click", () => {
    const show = loginForgotPanel?.classList.contains("hidden");
    setForgotPanelVisible(Boolean(show));
    if (show) setMessage("");
  });
}

if (loginForgotSubmitBtn) {
  loginForgotSubmitBtn.addEventListener("click", async () => {
    try {
      const email = String(loginEmailInput?.value || "")
        .trim()
        .toLowerCase();
      if (!email) throw new Error("Enter your email address first.");
      loginForgotSubmitBtn.disabled = true;
      setMessage("Sending a temporary password…");
      const result = await fetchApiJson("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email })
      });
      if (!result.sent) {
        setMessage(result.error || result.message || "We could not email a password. Nothing was changed.", true);
        return;
      }
      setMessage(result.message || "We emailed a temporary password. Check your inbox and spam folder.");
      setForgotPanelVisible(false);
    } catch (error) {
      setMessage(error.message || "Could not send reset email.", true);
    } finally {
      loginForgotSubmitBtn.disabled = false;
    }
  });
}

if (loginForm) {
  loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (pending2faChallenge) return;
    try {
      const email = String(loginEmailInput?.value || "")
        .trim()
        .toLowerCase();
      if (!email) throw new Error("Enter your email address.");
      const password = String(loginPasswordInput?.value || "");
      if (loginPasswordRequired && !password.trim()) {
        throw new Error("Enter your password.");
      }
      setMessage("Signing in...");
      try {
        await fetchApiJson("/api/auth/logout", { method: "POST", credentials: "include" });
      } catch {
        // ignore — clears any previous owner/trial cookie before new login
      }
      const result = await fetchApiJson("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
        credentials: "include"
      });
      const workspaceType =
        result.workspace === "trial" || (result.tenantId && result.tenantId !== 1) ? "trial" : "owner";
      try {
        sessionStorage.setItem("crm_expected_workspace", workspaceType);
      } catch {
        // ignore
      }
      if (result.requires2fa && result.challengeToken) {
        show2faStep(result.challengeToken);
        return;
      }
      if (result.billingRequired) {
        window.location.href = "/billing.html";
        return;
      }
      try {
        localStorage.setItem(HAD_AUTH_SESSION_KEY, "1");
      } catch {
        // ignore
      }
      setMessage("Signed in.");
      window.location.href = getNextPath();
    } catch (error) {
      setMessage(error.message || "Login failed.", true);
    }
  });
}

if (login2faVerifyBtn) {
  login2faVerifyBtn.addEventListener("click", async () => {
    try {
      await verify2faAndContinue();
    } catch (error) {
      setMessage(error.message || "Verification failed.", true);
    }
  });
}

if (login2faBackBtn) {
  login2faBackBtn.addEventListener("click", () => {
    hide2faStep();
    setMessage("");
  });
}

if (login2faCode) {
  login2faCode.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      login2faVerifyBtn?.click();
    }
  });
}

initLoginPage();
if (typeof window.crmInitPasswordToggles === "function") {
  window.crmInitPasswordToggles(document);
}
