"use strict";

const formEl = document.getElementById("webinarForm");
const messageEl = document.getElementById("message");
const listBodyEl = document.getElementById("webinarsBody");
const refreshBtn = document.getElementById("webinarsRefreshBtn");
const cancelEditBtn = document.getElementById("webinarCancelEditBtn");
const saveBtn = document.getElementById("webinarSaveBtn");
const hostStartLink = document.getElementById("webinarHostStartLink");
const regsPanel = document.getElementById("webinarRegsPanel");
const regsTitleEl = document.getElementById("webinarRegsTitle");
const regsBodyEl = document.getElementById("webinarRegsBody");
const publicPageUrlEl = document.getElementById("webinarPublicPageUrl");
const publishedLabelEl = document.getElementById("webinarPublishedLabel");
const publishedTextEl = document.getElementById("webinarPublishedText");
const filterTabEls = document.querySelectorAll(".webinar-filter-tab");

const idInput = document.getElementById("webinarId");
const titleInput = document.getElementById("webinarTitle");
const hostInput = document.getElementById("webinarHost");
const startsAtInput = document.getElementById("webinarStartsAt");
const durationInput = document.getElementById("webinarDuration");
const statusInput = document.getElementById("webinarStatus");
const publishedInput = document.getElementById("webinarPublished");
const zoomJoinInput = document.getElementById("webinarZoomJoin");
const zoomStartInput = document.getElementById("webinarZoomStart");
const zoomPassInput = document.getElementById("webinarZoomPass");
const descInput = document.getElementById("webinarDescription");

let cachedRows = [];
let listFilter = "upcoming";

function getCrmApiBase() {
  const injected =
    typeof window.__CRM_API_ORIGIN__ === "string" ? window.__CRM_API_ORIGIN__.trim().replace(/\/$/, "") : "";
  if (injected) return injected;
  const fromMeta = document.querySelector('meta[name="crm-api-base"]')?.getAttribute("content") || "";
  return String(fromMeta || "").trim().replace(/\/$/, "");
}

function apiUrl(path) {
  const p = path.startsWith("/") ? path : `/${path}`;
  const base = getCrmApiBase();
  return base ? `${base}${p}` : p;
}

function getPublicWebinarsPageUrl() {
  const base = getCrmApiBase() || String(window.location.origin || "").replace(/\/$/, "");
  return `${base}/webinars.html`;
}

async function fetchApiJson(pathAndQuery, init) {
  const response = await fetch(apiUrl(pathAndQuery), init);
  const text = await response.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = {};
  }
  return { response, data };
}

function showMessage(text, isError = false) {
  const str = String(text == null ? "" : text);
  if (isError && typeof window.crmHandleAuthErrorMessage === "function" && window.crmHandleAuthErrorMessage(str, isError)) {
    return;
  }
  messageEl.textContent = str;
  messageEl.style.color = isError ? "#c62828" : "#1b5e20";
}

function escapeHtml(text) {
  return String(text == null ? "" : text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

async function copyTextToClipboard(text) {
  const value = String(text || "");
  if (navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(value);
    return;
  }
  const ta = document.createElement("textarea");
  ta.value = value;
  ta.setAttribute("readonly", "");
  ta.style.position = "fixed";
  ta.style.left = "-9999px";
  document.body.appendChild(ta);
  ta.select();
  document.execCommand("copy");
  document.body.removeChild(ta);
}

async function copyShareLink() {
  try {
    await copyTextToClipboard(getPublicWebinarsPageUrl());
    showMessage("Share link copied to clipboard.");
  } catch {
    showMessage("Could not copy link. Select and copy the URL manually.", true);
  }
}

function syncPublicPageUrlDisplay() {
  const url = getPublicWebinarsPageUrl();
  if (publicPageUrlEl) publicPageUrlEl.textContent = url;
  document.querySelectorAll('a[href="/webinars.html"]').forEach((link) => {
    if (link.id === "webinarPreviewPublicBtn" || link.id === "webinarPreviewPublicTopBtn") {
      link.href = url;
    }
  });
}

function syncPublishedLabelUi() {
  if (!publishedLabelEl || !publishedTextEl || !publishedInput) return;
  const on = publishedInput.checked;
  publishedLabelEl.classList.toggle("webinar-publish-label--on", on);
  publishedLabelEl.classList.toggle("webinar-publish-label--off", !on);
  publishedTextEl.textContent = on
    ? "Published — visible to clients on /webinars.html"
    : "Unpublished — hidden from clients on /webinars.html";
}

function unixToDatetimeLocal(ts) {
  const n = Number(ts || 0);
  if (!n) return "";
  const d = new Date(n * 1000);
  const pad = (v) => String(v).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function datetimeLocalToUnix(value) {
  const raw = String(value || "").trim();
  if (!raw) return 0;
  const ms = new Date(raw).getTime();
  if (!Number.isFinite(ms)) return 0;
  return Math.floor(ms / 1000);
}

function formatWhen(item) {
  const ts = Number(item.startsAt || 0);
  if (!ts) return "—";
  const d = new Date(ts * 1000);
  return d.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit"
  });
}

function getRowEndsAt(row) {
  const startsAt = Number(row.startsAt || 0);
  const durationMin = Math.max(15, Number(row.durationMinutes || 60));
  return Number(row.endsAt || 0) || (startsAt > 0 ? startsAt + durationMin * 60 : 0);
}

function isUpcomingRow(row) {
  if (String(row.status || "") === "ended") return false;
  const endsAt = getRowEndsAt(row);
  if (!endsAt) return true;
  return endsAt >= Math.floor(Date.now() / 1000);
}

function filterRows(rows) {
  const list = Array.isArray(rows) ? rows.slice() : [];
  let filtered = list;
  if (listFilter === "upcoming") {
    filtered = list.filter(isUpcomingRow);
    filtered.sort((a, b) => Number(a.startsAt || 0) - Number(b.startsAt || 0));
  } else if (listFilter === "past") {
    filtered = list.filter((row) => !isUpcomingRow(row));
    filtered.sort((a, b) => Number(b.startsAt || 0) - Number(a.startsAt || 0));
  } else {
    filtered.sort((a, b) => Number(b.startsAt || 0) - Number(a.startsAt || 0));
  }
  return filtered;
}

function publishedPillHtml(isPublished) {
  const on = !!isPublished;
  return `<span class="webinar-published-pill ${on ? "is-on" : "is-off"}">${on ? "Published" : "Unpublished"}</span>`;
}

function clearForm() {
  idInput.value = "";
  titleInput.value = "";
  hostInput.value = "";
  startsAtInput.value = "";
  durationInput.value = "60";
  statusInput.value = "scheduled";
  publishedInput.checked = false;
  zoomJoinInput.value = "";
  zoomStartInput.value = "";
  zoomPassInput.value = "";
  descInput.value = "";
  saveBtn.textContent = "Save";
  cancelEditBtn.style.display = "none";
  hostStartLink.hidden = true;
  hostStartLink.removeAttribute("href");
  syncPublishedLabelUi();
}

function startEdit(row) {
  idInput.value = String(row.id || "");
  titleInput.value = String(row.title || "");
  hostInput.value = String(row.hostName || "");
  startsAtInput.value = unixToDatetimeLocal(row.startsAt);
  durationInput.value = String(row.durationMinutes || 60);
  statusInput.value = String(row.status || "scheduled");
  publishedInput.checked = !!row.isPublished;
  zoomJoinInput.value = String(row.zoomJoinUrl || "");
  zoomStartInput.value = String(row.zoomStartUrl || "");
  zoomPassInput.value = String(row.zoomPasscode || "");
  descInput.value = String(row.description || "");
  saveBtn.textContent = "Update";
  cancelEditBtn.style.display = "inline-block";
  syncPublishedLabelUi();
  if (row.zoomStartUrl) {
    hostStartLink.href = row.zoomStartUrl;
    hostStartLink.hidden = false;
  } else {
    hostStartLink.hidden = true;
  }
  window.scrollTo({ top: 0, behavior: "smooth" });
}

async function deleteRow(id) {
  const n = Number(id);
  if (!Number.isInteger(n) || n < 1) return;
  if (!window.confirm("Delete this webinar and all registrations?")) return;
  const { response, data } = await fetchApiJson(`/api/webinars/${n}`, { method: "DELETE" });
  if (!response.ok) throw new Error(data.error || "Failed to delete webinar");
  showMessage("Webinar deleted.");
  regsPanel.hidden = true;
  await loadWebinars();
}

async function loadRegistrations(id, title) {
  const { response, data } = await fetchApiJson(`/api/webinars/${id}/registrations`);
  if (!response.ok) throw new Error(data.error || "Failed to load registrations");
  const rows = Array.isArray(data.items) ? data.items : [];
  regsTitleEl.textContent = title || "";
  regsBodyEl.innerHTML = "";
  if (!rows.length) {
    regsBodyEl.innerHTML = '<tr><td colspan="4" class="hint">No registrations yet.</td></tr>';
  } else {
    for (const r of rows) {
      const tr = document.createElement("tr");
      const when = r.created_at ? new Date(Number(r.created_at) * 1000).toLocaleString() : "—";
      tr.innerHTML = `
        <td>${escapeHtml(r.full_name)}</td>
        <td><a href="mailto:${escapeHtml(r.email)}">${escapeHtml(r.email)}</a></td>
        <td>${escapeHtml(r.phone || "—")}</td>
        <td>${escapeHtml(when)}</td>
      `;
      regsBodyEl.appendChild(tr);
    }
  }
  regsPanel.hidden = false;
  regsPanel.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function renderRows(rows) {
  const list = filterRows(rows);
  listBodyEl.innerHTML = "";
  if (!list.length) {
    const emptyMsg =
      listFilter === "upcoming"
        ? "No upcoming webinars. Schedule one above or switch to Past or All."
        : listFilter === "past"
          ? "No past webinars yet."
          : "No webinars yet. Schedule one above.";
    listBodyEl.innerHTML = `<tr><td colspan="6" class="hint">${emptyMsg}</td></tr>`;
    return;
  }
  for (const row of list) {
    const tr = document.createElement("tr");
    const live = row.liveState === "live" ? " (live)" : "";
    const regCount = Math.max(0, Number(row.registrationCount || 0));
    const regLabel = regCount === 1 ? "1 registrant" : `${regCount} registrants`;
    tr.innerHTML = `
      <td>${escapeHtml(row.title)}</td>
      <td>${escapeHtml(formatWhen(row))}</td>
      <td>${escapeHtml(String(row.status || "") + live)}</td>
      <td>${publishedPillHtml(row.isPublished)}</td>
      <td><button type="button" class="webinar-regs-btn" data-id="${row.id}" data-title="${escapeHtml(row.title)}">${escapeHtml(regLabel)}</button></td>
      <td>
        <button type="button" class="webinar-edit-btn" data-id="${row.id}">Edit</button>
        <button type="button" class="danger webinar-delete-btn" data-id="${row.id}">Delete</button>
      </td>
    `;
    tr.querySelector(".webinar-edit-btn").addEventListener("click", () => startEdit(row));
    tr.querySelector(".webinar-delete-btn").addEventListener("click", async () => {
      try {
        await deleteRow(row.id);
      } catch (err) {
        showMessage(err.message || "Delete failed.", true);
      }
    });
    tr.querySelector(".webinar-regs-btn").addEventListener("click", async () => {
      try {
        await loadRegistrations(row.id, row.title);
      } catch (err) {
        showMessage(err.message || "Could not load registrations.", true);
      }
    });
    listBodyEl.appendChild(tr);
  }
}

async function loadWebinars() {
  const { response, data } = await fetchApiJson("/api/webinars");
  if (!response.ok) throw new Error(data.error || "Failed to load webinars");
  cachedRows = Array.isArray(data.items) ? data.items : [];
  renderRows(cachedRows);
}

function setListFilter(next) {
  listFilter = String(next || "upcoming");
  filterTabEls.forEach((tab) => {
    const active = tab.getAttribute("data-filter") === listFilter;
    tab.classList.toggle("is-active", active);
    tab.setAttribute("aria-selected", active ? "true" : "false");
  });
  renderRows(cachedRows);
}

formEl.addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const id = Number(idInput.value);
    const payload = {
      title: String(titleInput.value || "").trim(),
      hostName: String(hostInput.value || "").trim(),
      description: String(descInput.value || "").trim(),
      startsAt: datetimeLocalToUnix(startsAtInput.value),
      durationMinutes: Math.max(15, Number(durationInput.value || 60)),
      status: String(statusInput.value || "scheduled"),
      isPublished: publishedInput.checked,
      zoomJoinUrl: String(zoomJoinInput.value || "").trim(),
      zoomStartUrl: String(zoomStartInput.value || "").trim(),
      zoomPasscode: String(zoomPassInput.value || "").trim()
    };
    if (!payload.title) throw new Error("Title is required.");
    const isEdit = Number.isInteger(id) && id > 0;
    const path = isEdit ? `/api/webinars/${id}` : "/api/webinars";
    const method = isEdit ? "PUT" : "POST";
    const { response, data } = await fetchApiJson(path, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (!response.ok) throw new Error(data.error || "Failed to save webinar");
    showMessage(isEdit ? "Webinar updated." : "Webinar created.");
    if (data.item?.zoomStartUrl) {
      hostStartLink.href = data.item.zoomStartUrl;
      hostStartLink.hidden = false;
    }
    clearForm();
    await loadWebinars();
  } catch (err) {
    showMessage(err.message || "Save failed.", true);
  }
});

cancelEditBtn.addEventListener("click", () => {
  clearForm();
  showMessage("");
});

refreshBtn.addEventListener("click", async () => {
  try {
    await loadWebinars();
    showMessage("Webinars refreshed.");
  } catch (err) {
    showMessage(err.message || "Refresh failed.", true);
  }
});

publishedInput.addEventListener("change", syncPublishedLabelUi);

filterTabEls.forEach((tab) => {
  tab.addEventListener("click", () => setListFilter(tab.getAttribute("data-filter")));
});

["webinarCopyShareLinkBtn", "webinarCopyShareLinkTopBtn"].forEach((id) => {
  const btn = document.getElementById(id);
  if (btn) btn.addEventListener("click", () => copyShareLink());
});

const backToContactsBtn = document.getElementById("backToContactsBtn");
if (backToContactsBtn) {
  backToContactsBtn.addEventListener("click", () => {
    window.location.href = "/index.html";
  });
}

syncPublicPageUrlDisplay();
syncPublishedLabelUi();

loadWebinars().catch((err) => {
  showMessage(err.message || "Failed to load webinars.", true);
});
