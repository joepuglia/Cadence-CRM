(function (global) {
  "use strict";

  const STATIC_DEV_PORTS = new Set([
    "",
    "80",
    "443",
    "3000",
    "3001",
    "4173",
    "4200",
    "4201",
    "5000",
    "5001",
    "5173",
    "5500",
    "5501",
    "8080",
    "8888",
    "1234",
    "9000",
    "9630",
    "3939"
  ]);

  let cachedApiBase;
  let stickyApiBase;

  function pageOrigin() {
    if (typeof window === "undefined") return "";
    return window.location.origin.replace(/\/$/, "");
  }

  function originHostKey(origin) {
    try {
      const u = new URL(origin);
      const host = u.hostname.replace(/^www\./i, "").toLowerCase();
      const port = u.port || (u.protocol === "https:" ? "443" : "80");
      return `${u.protocol}//${host}:${port}`;
    } catch {
      return String(origin || "")
        .replace(/\/$/, "")
        .toLowerCase();
    }
  }

  function originsEquivalent(a, b) {
    if (!a || !b) return false;
    return originHostKey(a) === originHostKey(b);
  }

  function getCrmApiBase() {
    if (stickyApiBase !== undefined) return stickyApiBase;
    if (cachedApiBase !== undefined) return cachedApiBase;
    if (typeof window === "undefined") {
      cachedApiBase = "";
      return cachedApiBase;
    }
    const params = new URLSearchParams(window.location.search);
    const fromQuery = params.get("api");
    if (fromQuery && String(fromQuery).trim()) {
      cachedApiBase = String(fromQuery).trim().replace(/\/$/, "");
      return cachedApiBase;
    }
    const injected =
      typeof window.__CRM_API_ORIGIN__ === "string" ? window.__CRM_API_ORIGIN__.trim().replace(/\/$/, "") : "";
    if (injected && !originsEquivalent(injected, pageOrigin())) {
      cachedApiBase = injected;
      return cachedApiBase;
    }
    const host = window.location.hostname;
    const port = window.location.port || "";
    const apiPortParam = params.get("apiPort");
    if (
      apiPortParam &&
      /^\d{2,5}$/.test(apiPortParam) &&
      (host === "localhost" || host === "127.0.0.1")
    ) {
      cachedApiBase = `${window.location.protocol}//${host}:${apiPortParam}`.replace(/\/$/, "");
      return cachedApiBase;
    }
    const servedMeta = document.querySelector('meta[name="crm-served-by-api"]');
    if (servedMeta && servedMeta.getAttribute("content") === "1") {
      cachedApiBase = "";
      return cachedApiBase;
    }
    const meta = document.querySelector('meta[name="crm-api-base"]');
    const fromMeta = meta && meta.getAttribute("content");
    if (fromMeta && String(fromMeta).trim()) {
      const metaBase = String(fromMeta).trim().replace(/\/$/, "");
      cachedApiBase = originsEquivalent(metaBase, pageOrigin()) ? "" : metaBase;
      return cachedApiBase;
    }
    if ((host === "localhost" || host === "127.0.0.1") && STATIC_DEV_PORTS.has(port)) {
      cachedApiBase = `${window.location.protocol}//${host}:3000`.replace(/\/$/, "");
      return cachedApiBase;
    }
    cachedApiBase = "";
    return cachedApiBase;
  }

  function apiUrl(path) {
    const base = getCrmApiBase();
    const p = path.startsWith("/") ? path : `/${path}`;
    if (!base) return p;
    return `${base}${p}`;
  }

  function toAbsoluteUrl(url) {
    if (url.startsWith("http://") || url.startsWith("https://")) return url;
    return new URL(url.startsWith("/") ? url : `/${url}`, window.location.href).href;
  }

  function rememberSuccessfulApiOrigin(urlUsed) {
    try {
      const abs = toAbsoluteUrl(urlUsed);
      const origin = new URL(abs).origin.replace(/\/$/, "");
      stickyApiBase = originsEquivalent(origin, pageOrigin()) ? "" : origin;
    } catch {
      //
    }
  }

  function apiUrlCandidates(pathAndQuery) {
    const p = pathAndQuery.startsWith("/") ? pathAndQuery : `/${pathAndQuery}`;
    const out = [];
    const push = (u) => {
      const abs = toAbsoluteUrl(u);
      if (!out.includes(abs)) out.push(abs);
    };
    // Always hit the same host as this page first (Passenger / cPanel).
    push(p);
    const params = new URLSearchParams(window.location.search);
    const forcedApi = params.get("api");
    if (forcedApi && String(forcedApi).trim()) {
      const forced = String(forcedApi).trim().replace(/\/$/, "");
      push(`${forced}${p}`);
    }
    const h = window.location.hostname;
    if (h === "localhost" || h === "127.0.0.1") {
      push(`http://127.0.0.1:3000${p}`);
      push(`http://localhost:3000${p}`);
      push(`http://${h}:3000${p}`);
    }
    return out;
  }

  function requestTooLargeError() {
    return new Error(
      "The request was too large (HTTP 414). Select fewer contacts, clear filters, or hard-refresh this page and try again."
    );
  }

  function mergeFetchInit(init) {
    const base = { credentials: "include", ...(init || {}) };
    // Safari/Mac can hang forever on a stalled connection; abort so the UI can retry.
    if (!base.signal && typeof AbortController !== "undefined") {
      const controller = new AbortController();
      const timeoutMs = Number(base.timeoutMs) > 0 ? Number(base.timeoutMs) : 25000;
      const timer = setTimeout(() => {
        try {
          controller.abort();
        } catch {
          /* ignore */
        }
      }, timeoutMs);
      const clear = () => clearTimeout(timer);
      if (typeof controller.signal.addEventListener === "function") {
        controller.signal.addEventListener("abort", clear, { once: true });
      }
      base.signal = controller.signal;
      delete base.timeoutMs;
      const userSignal = init && init.signal;
      if (userSignal) {
        const onAbort = () => {
          try {
            controller.abort();
          } catch {
            /* ignore */
          }
        };
        if (userSignal.aborted) onAbort();
        else if (typeof userSignal.addEventListener === "function") {
          userSignal.addEventListener("abort", onAbort, { once: true });
        }
      }
    } else if (base.timeoutMs != null) {
      delete base.timeoutMs;
    }
    return base;
  }

  function isAbortError(err) {
    return (
      err &&
      (err.name === "AbortError" ||
        /aborted|abort/i.test(String(err.message || err.name || "")))
    );
  }

  async function fetchApi(pathAndQuery, init) {
    const urls = apiUrlCandidates(pathAndQuery);
    const fetchInit = mergeFetchInit(init);
    let sawHtml = false;
    let lastStatus = 0;
    let lastError = null;
    for (const url of urls) {
      let response;
      try {
        response = await fetch(url, fetchInit);
      } catch (err) {
        lastError = err;
        if (isAbortError(err)) {
          throw new Error(
            "The CRM API request timed out. On Mac/Safari, hard-refresh (Cmd+Shift+R), confirm you are on https://crmcadence.com (not a different subdomain), then try Contacts again."
          );
        }
        continue;
      }
      lastStatus = response.status;
      if (response.status === 414) throw requestTooLargeError();
      const contentType = String(response.headers.get("content-type") || "").toLowerCase();
      if (!contentType.includes("text/html")) {
        rememberSuccessfulApiOrigin(url);
        return response;
      }
      const text = await response.text();
      const trimmed = text.trim();
      if (!trimmed || !trimmed.startsWith("<")) {
        rememberSuccessfulApiOrigin(url);
        return new Response(text, {
          status: response.status,
          statusText: response.statusText,
          headers: response.headers
        });
      }
      sawHtml = true;
    }
    if (sawHtml) {
      throw new Error(
        "Server returned a web page instead of JSON (HTML). Run npm start and open http://localhost:3000, or add ?apiPort=3000 (or your API port) to this page's URL, or set the crm-api-base meta tag."
      );
    }
    if (lastError && isAbortError(lastError)) {
      throw new Error(
        "The CRM API request timed out. Hard-refresh and try again, or check your network/VPN."
      );
    }
    throw new Error(`API request failed (last status ${lastStatus}).`);
  }

  async function fetchApiJson(pathAndQuery, init) {
    const urls = apiUrlCandidates(pathAndQuery);
    const fetchInit = mergeFetchInit(init);
    let sawHtml = false;
    let lastStatus = 0;
    let lastError = null;
    for (const url of urls) {
      let response;
      try {
        response = await fetch(url, fetchInit);
      } catch (err) {
        lastError = err;
        if (isAbortError(err)) {
          throw new Error(
            "Contacts API timed out. On Mac: use Chrome or Safari, open https://crmcadence.com (same host you logged into), then Cmd+Shift+R and reopen Contacts Workspace."
          );
        }
        continue;
      }
      lastStatus = response.status;
      if (response.status === 414) throw requestTooLargeError();
      const text = await response.text();
      const trimmed = text.trim();
      if (!trimmed) continue;
      if (trimmed.startsWith("<")) {
        sawHtml = true;
        continue;
      }
      let data;
      try {
        data = JSON.parse(trimmed);
      } catch {
        continue;
      }
      rememberSuccessfulApiOrigin(url);
      return { response, data };
    }
    if (sawHtml) {
      throw new Error(
        "Server returned a web page instead of JSON (HTML). Run npm start and open http://localhost:3000, or add ?apiPort=3000 (or your API port) to this page's URL, or set the crm-api-base meta tag."
      );
    }
    if (lastError && isAbortError(lastError)) {
      throw new Error(
        "Contacts API timed out. Hard-refresh (Cmd+Shift+R) and try Contacts Workspace again."
      );
    }
    throw new Error(`Empty or invalid JSON from API (last status ${lastStatus}).`);
  }

  global.CrmApi = {
    getCrmApiBase,
    apiUrl,
    apiUrlCandidates,
    fetchApi,
    fetchApiJson,
    resetApiBaseCache() {
      cachedApiBase = undefined;
      stickyApiBase = undefined;
    }
  };
})(typeof window !== "undefined" ? window : globalThis);
