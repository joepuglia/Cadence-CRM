"use strict";

const gridEl = document.getElementById("webinarsGrid");
const statusEl = document.getElementById("webinarsStatus");
const registerDialog = document.getElementById("webinarRegisterDialog");
const registerForm = document.getElementById("webinarRegisterForm");
const registerTitleEl = document.getElementById("webinarRegisterTitle");
const registerMetaEl = document.getElementById("webinarRegisterMeta");
const registerIdEl = document.getElementById("webinarRegisterId");
const registerMessageEl = document.getElementById("webinarRegisterMessage");
const regNameEl = document.getElementById("webinarRegName");
const regEmailEl = document.getElementById("webinarRegEmail");
const regPhoneEl = document.getElementById("webinarRegPhone");

let webinars = [];

function escapeHtml(text) {
  return String(text == null ? "" : text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function formatWhen(startsAt, durationMinutes) {
  const ts = Number(startsAt || 0);
  if (!ts) return "Date TBA";
  const start = new Date(ts * 1000);
  const end = new Date((ts + Math.max(15, Number(durationMinutes || 60)) * 60) * 1000);
  const opts = { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" };
  const startStr = start.toLocaleString(undefined, opts);
  const endTime = end.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });
  return `${startStr} – ${endTime}`;
}

function liveBadge(liveState) {
  if (liveState === "live") return '<span class="webinar-badge webinar-badge--live">Live presentation</span>';
  if (liveState === "ended") return '<span class="webinar-badge webinar-badge--ended">Ended</span>';
  return '<span class="webinar-badge webinar-badge--scheduled">Scheduled</span>';
}

function openRegister(w) {
  registerIdEl.value = String(w.id);
  registerTitleEl.textContent = `Reserve your spot — ${w.title}`;
  registerMetaEl.textContent = formatWhen(w.startsAt, w.durationMinutes);
  registerMessageEl.textContent = "";
  regNameEl.value = "";
  regEmailEl.value = "";
  regPhoneEl.value = "";
  if (typeof registerDialog.showModal === "function") registerDialog.showModal();
}

function closeRegister() {
  if (registerDialog.open) registerDialog.close();
}

function renderCard(w) {
  const canJoin = w.liveState === "live" && w.zoomJoinUrl;
  const joinBtn = canJoin
    ? `<a class="welcome-btn welcome-btn--primary webinar-join-btn" href="${escapeHtml(w.zoomJoinUrl)}" target="_blank" rel="noopener noreferrer">Join presentation</a>`
    : w.liveState === "ended"
      ? `<button type="button" class="welcome-btn welcome-btn--ghost" disabled>Presentation ended</button>`
      : `<button type="button" class="welcome-btn welcome-btn--ghost webinar-register-btn" data-id="${w.id}">Reserve spot</button>`;

  const hostLine = w.hostName
    ? `<p class="webinar-card-host">Your advisor: ${escapeHtml(w.hostName)}</p>`
    : "";
  const desc = w.description
    ? `<p class="webinar-card-desc">${escapeHtml(w.description)}</p>`
    : "";

  return `
    <article class="webinar-card" data-id="${w.id}">
      <div class="webinar-card-head">
        <h3>${escapeHtml(w.title)}</h3>
        ${liveBadge(w.liveState)}
      </div>
      <p class="webinar-card-when">${escapeHtml(formatWhen(w.startsAt, w.durationMinutes))}</p>
      ${hostLine}
      ${desc}
      <div class="webinar-card-actions">
        ${joinBtn}
        ${canJoin ? `<button type="button" class="welcome-btn welcome-btn--ghost webinar-register-btn" data-id="${w.id}">Reserve spot</button>` : ""}
      </div>
    </article>
  `;
}

function bindGrid() {
  gridEl.querySelectorAll(".webinar-register-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = Number(btn.getAttribute("data-id"));
      const w = webinars.find((x) => x.id === id);
      if (w) openRegister(w);
    });
  });
}

function renderList(items) {
  webinars = Array.isArray(items) ? items : [];
  if (!webinars.length) {
    statusEl.textContent =
      "No presentations are scheduled right now. If your advisor sent you this link, check back closer to your appointment time.";
    gridEl.innerHTML = "";
    return;
  }
  statusEl.textContent = `${webinars.length} presentation${webinars.length === 1 ? "" : "s"} you can join or reserve.`;
  gridEl.innerHTML = webinars.map(renderCard).join("");
  bindGrid();
}

async function loadWebinars() {
  statusEl.textContent = "Loading your sessions…";
  try {
    const res = await fetch("/api/webinars/public");
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Could not load webinars.");
    renderList(data.items);
  } catch (err) {
    statusEl.textContent = err.message || "Could not load webinars.";
    gridEl.innerHTML = "";
  }
}

registerForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const webinarId = Number(registerIdEl.value);
  const fullName = String(regNameEl.value || "").trim();
  const email = String(regEmailEl.value || "").trim();
  const phone = String(regPhoneEl.value || "").trim();
  registerMessageEl.textContent = "";
  try {
    const res = await fetch("/api/webinars/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ webinarId, fullName, email, phone })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Registration failed.");
    registerMessageEl.textContent =
      "You're reserved. Return to this page at your scheduled time and use Join presentation when it goes live.";
    registerMessageEl.style.color = "#166534";
    setTimeout(closeRegister, 2200);
  } catch (err) {
    registerMessageEl.textContent = err.message || "Registration failed.";
    registerMessageEl.style.color = "#b91c1c";
  }
});

document.getElementById("webinarRegisterClose")?.addEventListener("click", closeRegister);
document.getElementById("webinarRegisterCancel")?.addEventListener("click", closeRegister);

loadWebinars();
