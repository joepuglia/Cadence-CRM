/**
 * Cadence appearance: light / dark.
 * Apply as early as possible in <head> so the first paint matches the saved theme.
 */
(function () {
  "use strict";
  var KEY = "crm.theme";

  function read() {
    try {
      return localStorage.getItem(KEY) === "dark" ? "dark" : "light";
    } catch {
      return "light";
    }
  }

  function apply(theme) {
    var next = theme === "dark" ? "dark" : "light";
    document.documentElement.setAttribute("data-theme", next);
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", next === "dark" ? "#0b1220" : "#4f46e5");
    try {
      localStorage.setItem(KEY, next);
    } catch {
      /* ignore quota / private mode */
    }
    var toggle = document.getElementById("crmDarkModeToggle");
    if (toggle) toggle.checked = next === "dark";
    document.dispatchEvent(new CustomEvent("crm-theme-change", { detail: { theme: next } }));
  }

  apply(read());

  window.CrmTheme = {
    get: read,
    set: apply,
    toggle: function () {
      apply(read() === "dark" ? "light" : "dark");
      return read();
    }
  };

  document.addEventListener("DOMContentLoaded", function () {
    var toggle = document.getElementById("crmDarkModeToggle");
    if (!toggle) return;
    toggle.checked = read() === "dark";
    toggle.addEventListener("change", function () {
      apply(toggle.checked ? "dark" : "light");
    });
  });
})();
