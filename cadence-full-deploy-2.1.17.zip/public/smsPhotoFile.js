/* Shrink a picture in the browser before it is attached to a text.
   Phone companies reject many full-size photos, and that stops the whole message. */
(function () {
  var MAX_BYTES = 450 * 1024;
  var MAX_EDGE = 1280;

  function loadImage(file) {
    return new Promise(function (resolve, reject) {
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () {
        URL.revokeObjectURL(url);
        resolve(img);
      };
      img.onerror = function () {
        URL.revokeObjectURL(url);
        reject(new Error("Save this photo as a JPG or PNG, then try again."));
      };
      img.src = url;
    });
  }

  function blobAt(canvas, quality) {
    return new Promise(function (resolve) {
      canvas.toBlob(resolve, "image/jpeg", quality);
    });
  }

  function isJpegFile(file) {
    var name = String((file && file.name) || "").toLowerCase();
    var type = String((file && file.type) || "").toLowerCase();
    return type === "image/jpeg" || type === "image/jpg" || type === "image/pjpeg" || /\.jpe?g$/.test(name);
  }

  async function prepareSmsPhotoFile(file) {
    if (!file) return file;
    if (file.size > 5 * 1024 * 1024) {
      throw new Error("That photo is too large for a text. Use a picture under 5 MB.");
    }
    var img;
    try {
      img = await loadImage(file);
    } catch (err) {
      if (isJpegFile(file)) return file;
      throw err;
    }
    var scale = Math.min(1, MAX_EDGE / Math.max(img.width || 1, img.height || 1));
    var width = Math.max(1, Math.round((img.width || 1) * scale));
    var height = Math.max(1, Math.round((img.height || 1) * scale));
    var canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    var ctx = canvas.getContext("2d");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, width, height);
    ctx.drawImage(img, 0, 0, width, height);
    var quality = 0.82;
    var blob = await blobAt(canvas, quality);
    while (blob && blob.size > MAX_BYTES && quality > 0.45) {
      quality -= 0.12;
      blob = await blobAt(canvas, quality);
    }
    if (!blob) {
      if (isJpegFile(file)) return file;
      throw new Error("Could not prepare that photo. Use a JPG or PNG.");
    }
    if (blob.size > 5 * 1024 * 1024) {
      throw new Error("That photo is too large for a text. Use a picture under 5 MB.");
    }
    var base = String(file.name || "photo").replace(/\.[^.]+$/, "") || "photo";
    return new File([blob], base + ".jpg", { type: "image/jpeg" });
  }

  window.prepareSmsPhotoFile = prepareSmsPhotoFile;
})();
