const CALENDAR_TZ_STORAGE_KEY = "cadence_calendar_timezone";
const GOOGLE_BANNER_SEEN_STORAGE_KEY = "cadence_calendar_google_banner_seen";
const CALENDAR_FILTERS_STORAGE_KEY = "cadence_calendar_filters_v1";
const MONTH_MAX_VISIBLE_CHIPS = 3;
const WEEK_MAX_VISIBLE_CHIPS = 8;

const ADD_TAB_DESCRIPTIONS = {
  event: "A general appointment or meeting.",
  google: "Import or sync from Google Calendar.",
  contact: "Schedule a call or meeting tied to a specific contact.",
  task: "A to-do item or reminder for yourself."
};

const DEFAULT_FILTERS = {
  events: true,
  tasks: true,
  follow_ups: true,
  renewals: true,
  google: true
};

const messageEl = document.getElementById("message");
const periodLabelEl = document.getElementById("calendarPeriodLabel");
const gridEl = document.getElementById("calendarGrid");
const emptyStateEl = document.getElementById("calendarEmptyState");
const filtersEl = document.getElementById("calendarFilters");
const todayBtn = document.getElementById("calendarTodayBtn");
const prevBtn = document.getElementById("calendarPrevBtn");
const nextBtn = document.getElementById("calendarNextBtn");
const addEventBtn = document.getElementById("calendarAddEventBtn");
const viewTabEls = document.querySelectorAll(".calendar-view-tab");

const googleBanner = document.getElementById("calendarGoogleBanner");
const googleStatusText = document.getElementById("calendarGoogleStatusText");
const googleHint = document.getElementById("calendarGoogleHint");
const googleConnectBtn = document.getElementById("calendarGoogleConnectBtn");
const googleSyncBtn = document.getElementById("calendarGoogleSyncBtn");
const googleDisconnectBtn = document.getElementById("calendarGoogleDisconnectBtn");
const googleSettingsLink = document.getElementById("calendarGoogleSettingsLink");

const eventModal = document.getElementById("calendarEventModal");
const eventModalTitle = document.getElementById("calendarEventModalTitle");
const eventForm = document.getElementById("calendarEventForm");
const addTabEls = document.querySelectorAll(".calendar-add-tab");
const addTabDescEl = document.getElementById("calendarAddTabDesc");
const googleTabPanel = document.getElementById("calendarGoogleTabPanel");
const googleTabStatus = document.getElementById("calendarGoogleTabStatus");
const googleTabConnectBtn = document.getElementById("calendarGoogleTabConnectBtn");
const googleTabSyncBtn = document.getElementById("calendarGoogleTabSyncBtn");
const eventIdField = document.getElementById("calendarEventId");
const titleField = document.getElementById("calendarEventTitle");
const titleLabel = document.getElementById("calendarEventTitleLabel");
const dateField = document.getElementById("calendarEventDate");
const endDateField = document.getElementById("calendarEventEndDate");
const allDayField = document.getElementById("calendarEventAllDay");
const timeField = document.getElementById("calendarEventTime");
const endTimeField = document.getElementById("calendarEventEndTime");
const timeRow = document.getElementById("calendarTimeRow");
const timezoneHintEl = document.getElementById("calendarTimezoneHint");
const eventOnlyFields = document.getElementById("calendarEventOnlyFields");
const recurrenceField = document.getElementById("calendarEventRecurrence");
const locationField = document.getElementById("calendarEventLocation");
const colorField = document.getElementById("calendarEventColor");
const descriptionField = document.getElementById("calendarEventDescription");
const contactFieldWrap = document.getElementById("calendarContactFieldWrap");
const contactLabel = document.getElementById("calendarEventContactLabel");
const contactInput = document.getElementById("calendarEventContact");
const contactList = document.getElementById("calendarEventContactList");
const contactIdField = document.getElementById("calendarEventContactId");
const googlePushRow = document.getElementById("calendarGooglePushRow");
const pushGoogleField = document.getElementById("calendarEventPushGoogle");
const googlePushHint = document.getElementById("calendarGooglePushHint");
const formError = document.getElementById("calendarEventFormError");
const deleteBtn = document.getElementById("calendarEventDeleteBtn");
const saveBtn = document.getElementById("calendarEventSaveBtn");

let viewMode = "month";
let viewAnchor = new Date();
let cachedEvents = [];
let cachedTasks = [];
let cachedFollowUps = [];
let cachedRenewals = [];
let cachedContacts = [];
let calendarFilters = loadCalendarFilters();
let googleStatus = { connected: false, configured: false, accountEmail: "", lastSyncAt: 0 };
let isSubmitting = false;
let activeAddTab = "event";
let editingEvent = false;

function loadCalendarFilters() {
  try {
    const raw = localStorage.getItem(CALENDAR_FILTERS_STORAGE_KEY);
    if (!raw) return { ...DEFAULT_FILTERS };
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_FILTERS, ...parsed };
  } catch {
    return { ...DEFAULT_FILTERS };
  }
}

function saveCalendarFilters() {
  try {
    localStorage.setItem(CALENDAR_FILTERS_STORAGE_KEY, JSON.stringify(calendarFilters));
  } catch {
    // ignore
  }
}

function syncFilterControls() {
  if (!filtersEl) return;
  for (const btn of filtersEl.querySelectorAll("[data-filter]")) {
    const key = btn.dataset.filter;
    const on = Boolean(calendarFilters[key]);
    btn.classList.toggle("is-on", on);
    btn.setAttribute("aria-pressed", on ? "true" : "false");
  }
}

function eventPassesFilters(ev) {
  if (ev && ev.google_event_id) return calendarFilters.google !== false;
  return calendarFilters.events !== false;
}

function itemKindPasses(kind) {
  if (kind === "task") return calendarFilters.tasks !== false;
  if (kind === "follow_up") return calendarFilters.follow_ups !== false;
  if (kind === "renewal") return calendarFilters.renewals !== false;
  return true;
}

function showMessage(text, isError = false) {
  const str = String(text == null ? "" : text);
  if (isError && typeof window.crmHandleAuthErrorMessage === "function" && window.crmHandleAuthErrorMessage(str, isError)) {
    return;
  }
  messageEl.textContent = str;
  messageEl.style.color = isError ? "#c62828" : "#1b5e20";
}

function getCrmApiBase() {
  const injected = typeof window.__CRM_API_ORIGIN__ === "string"
    ? window.__CRM_API_ORIGIN__.trim().replace(/\/$/, "")
    : "";
  if (injected) return injected;
  const fromMeta = document.querySelector('meta[name="crm-api-base"]')?.getAttribute("content") || "";
  return String(fromMeta || "").trim().replace(/\/$/, "");
}

function apiUrl(path) {
  const base = getCrmApiBase();
  const p = path.startsWith("/") ? path : `/${path}`;
  return base ? `${base}${p}` : p;
}

async function fetchApiJson(pathAndQuery, init = {}) {
  const response = await fetch(apiUrl(pathAndQuery), { credentials: "include", ...init });
  const text = await response.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { error: text || `HTTP ${response.status}` };
  }
  return { response, data };
}

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function pad2(n) {
  const s = String(n);
  return s.length === 1 ? `0${s}` : s;
}

function formatIsoDate(dt) {
  return `${dt.getFullYear()}-${pad2(dt.getMonth() + 1)}-${pad2(dt.getDate())}`;
}

function parseIsoDate(value) {
  const m = String(value || "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return null;
  const dt = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  return Number.isNaN(dt.getTime()) ? null : dt;
}

function addDays(date, days) {
  const dt = new Date(date);
  dt.setDate(dt.getDate() + Number(days || 0));
  return dt;
}

function startOfWeek(date) {
  const dt = new Date(date);
  dt.setDate(dt.getDate() - dt.getDay());
  return dt;
}

function endOfWeek(date) {
  return addDays(startOfWeek(date), 6);
}

function monthLabel(year, month) {
  const dt = new Date(year, month, 1);
  return dt.toLocaleDateString(undefined, { month: "long", year: "numeric" });
}

function getCalendarTimezone() {
  try {
    const stored = localStorage.getItem(CALENDAR_TZ_STORAGE_KEY);
    if (stored) return stored;
  } catch {
    // ignore
  }
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
  } catch {
    return "UTC";
  }
}

function hasSeenGoogleBanner() {
  try {
    return localStorage.getItem(GOOGLE_BANNER_SEEN_STORAGE_KEY) === "1";
  } catch {
    return true;
  }
}

function markGoogleBannerSeen() {
  try {
    localStorage.setItem(GOOGLE_BANNER_SEEN_STORAGE_KEY, "1");
  } catch {
    // ignore
  }
}

function getTimezoneDisplayLabel(tz) {
  try {
    const parts = new Intl.DateTimeFormat("en-US", {
      timeZone: tz,
      timeZoneName: "long"
    }).formatToParts(new Date());
    const longName = parts.find((p) => p.type === "timeZoneName")?.value || tz;
    const shortParts = new Intl.DateTimeFormat("en-US", {
      timeZone: tz,
      timeZoneName: "short"
    }).formatToParts(new Date());
    const shortName = shortParts.find((p) => p.type === "timeZoneName")?.value || "";
    return { longName, shortName };
  } catch {
    return { longName: tz, shortName: "" };
  }
}

function renderTimezoneHint() {
  if (!timezoneHintEl) return;
  const tz = getCalendarTimezone();
  const { longName, shortName } = getTimezoneDisplayLabel(tz);
  const abbr = shortName ? ` (${shortName})` : "";
  timezoneHintEl.innerHTML = `Times shown in ${escapeHtml(longName)}${escapeHtml(abbr)} — <a href="/settings.html?section=calendar">change in Settings</a>.`;
}

function getMonthRange(year, month) {
  const firstOfMonth = new Date(year, month, 1);
  const startWeekday = firstOfMonth.getDay();
  const gridStart = new Date(year, month, 1 - startWeekday);
  const gridEnd = new Date(gridStart);
  gridEnd.setDate(gridStart.getDate() + 41);
  return { gridStart, gridEnd };
}

function getViewRange() {
  if (viewMode === "day") {
    const iso = formatIsoDate(viewAnchor);
    const label = viewAnchor.toLocaleDateString(undefined, {
      weekday: "long",
      month: "long",
      day: "numeric",
      year: "numeric"
    });
    return { start: iso, end: iso, label };
  }
  if (viewMode === "week") {
    const startDt = startOfWeek(viewAnchor);
    const endDt = endOfWeek(viewAnchor);
    const start = formatIsoDate(startDt);
    const end = formatIsoDate(endDt);
    const sameMonth = startDt.getMonth() === endDt.getMonth() && startDt.getFullYear() === endDt.getFullYear();
    const label = sameMonth
      ? `${startDt.toLocaleDateString(undefined, { month: "short", day: "numeric" })} – ${endDt.toLocaleDateString(undefined, { day: "numeric", year: "numeric" })}`
      : `${startDt.toLocaleDateString(undefined, { month: "short", day: "numeric" })} – ${endDt.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}`;
    return { start, end, label, weekStart: startDt };
  }
  const year = viewAnchor.getFullYear();
  const month = viewAnchor.getMonth();
  const { gridStart, gridEnd } = getMonthRange(year, month);
  return {
    start: formatIsoDate(gridStart),
    end: formatIsoDate(gridEnd),
    label: monthLabel(year, month),
    year,
    month
  };
}

function setPeriodLabel() {
  if (periodLabelEl) periodLabelEl.textContent = getViewRange().label;
}

function formatHhmm(value) {
  const m = String(value || "").match(/^(\d{1,2}):(\d{2})/);
  if (!m) return "";
  const h = pad2(m[1]);
  return `${h}:${m[2]}`;
}

function humanReadableTime(hhmm) {
  if (!hhmm) return "";
  const m = String(hhmm).match(/^(\d{1,2}):(\d{2})/);
  if (!m) return "";
  let hour = Number(m[1]);
  const minute = m[2];
  const ampm = hour >= 12 ? "PM" : "AM";
  hour = hour % 12;
  if (hour === 0) hour = 12;
  return `${hour}:${minute} ${ampm}`;
}

function isTaskOverdue(task) {
  if (String(task.condition || "") === "Completed") return false;
  const taskDate = String(task.task_date || "").trim();
  if (!taskDate) return false;
  const today = formatIsoDate(new Date());
  if (taskDate < today) return true;
  if (taskDate === today && task.task_time) {
    const now = new Date();
    const parts = String(task.task_time).match(/^(\d{1,2}):(\d{2})/);
    if (!parts) return false;
    const due = new Date(now.getFullYear(), now.getMonth(), now.getDate(), Number(parts[1]), Number(parts[2]));
    return now > due;
  }
  return false;
}

function expandRecurringEvent(ev, rangeStartIso, rangeEndIso) {
  const recurrence = String(ev.recurrence || "").trim().toLowerCase();
  if (!recurrence) return [ev];
  const startDt = parseIsoDate(ev.event_date);
  const rangeStart = parseIsoDate(rangeStartIso);
  const rangeEnd = parseIsoDate(rangeEndIso);
  if (!startDt || !rangeStart || !rangeEnd) return [ev];

  const out = [];
  const cursor = new Date(startDt);
  const maxOccurrences = 400;
  let count = 0;

  while (cursor <= rangeEnd && count < maxOccurrences) {
    const iso = formatIsoDate(cursor);
    if (iso >= rangeStartIso) {
      out.push({
        ...ev,
        event_date: iso,
        end_date: iso,
        _occurrenceDate: iso,
        _isRecurrenceOccurrence: iso !== ev.event_date
      });
    }
    count += 1;
    if (recurrence === "daily") cursor.setDate(cursor.getDate() + 1);
    else if (recurrence === "weekly") cursor.setDate(cursor.getDate() + 7);
    else if (recurrence === "monthly") cursor.setMonth(cursor.getMonth() + 1);
    else if (recurrence === "yearly") cursor.setFullYear(cursor.getFullYear() + 1);
    else break;
    if (cursor < startDt) break;
  }
  return out.length ? out : [ev];
}

function getExpandedEventsForRange(startIso, endIso) {
  const out = [];
  for (const ev of cachedEvents) {
    out.push(...expandRecurringEvent(ev, startIso, endIso));
  }
  return out;
}

function buildDayCell(date, isOtherMonth) {
  const iso = formatIsoDate(date);
  const today = formatIsoDate(new Date());
  const cell = document.createElement("div");
  cell.className = "calendar-day-cell";
  cell.tabIndex = 0;
  cell.setAttribute("role", "button");
  if (isOtherMonth) cell.classList.add("calendar-day-cell--other");
  if (iso === today) cell.classList.add("calendar-day-cell--today");
  cell.dataset.date = iso;
  cell.title = `Click to add an event on ${date.toDateString()}`;
  cell.setAttribute("aria-label", `Click to add an event on ${date.toDateString()}`);

  const head = document.createElement("div");
  head.className = "calendar-day-head";
  const numberEl = document.createElement("span");
  numberEl.className = "calendar-day-number";
  numberEl.textContent = String(date.getDate());
  head.appendChild(numberEl);
  if (iso === today) {
    const todayBadge = document.createElement("span");
    todayBadge.className = "calendar-day-today-badge";
    todayBadge.textContent = "Today";
    head.appendChild(todayBadge);
  }
  cell.appendChild(head);

  const itemsWrap = document.createElement("div");
  itemsWrap.className = "calendar-day-items";
  cell.appendChild(itemsWrap);
  return cell;
}

function compactCalendarEventTitle(title, contactName) {
  let base = String(title || "(no title)").trim();
  const contact = String(contactName || "").trim();
  if (!contact) return base || "(no title)";
  const escapedContact = contact.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  base = base
    .replace(new RegExp(`\\s*(?:-|–|—|·|with)\\s*${escapedContact}\\s*$`, "i"), "")
    .replace(new RegExp(`\\s*${escapedContact}\\s*$`, "i"), "")
    .trim();
  return `${base || "Event"} · ${contact}`;
}

function renderEventChip(ev) {
  const chip = document.createElement("button");
  chip.type = "button";
  chip.className = "calendar-chip calendar-chip--event";
  if (ev.google_event_id) chip.classList.add("calendar-chip--google");
  if (ev._isRecurrenceOccurrence) chip.classList.add("calendar-chip--recurring");
  chip.dataset.eventId = String(ev.id);
  const accentColor = ev.color || (ev.google_event_id ? "#16a34a" : "#2563eb");
  chip.style.borderLeftColor = accentColor;
  const timeText = ev.all_day ? "All day" : humanReadableTime(ev.event_time) || "";
  const recurMark = ev._isRecurrenceOccurrence ? " ↻" : "";
  const displayTitle = compactCalendarEventTitle(ev.title, ev.contact_name);
  chip.title = `${timeText ? `${timeText} · ` : ""}${displayTitle}${recurMark}`;
  chip.innerHTML = `<span class="calendar-chip-title">${escapeHtml(displayTitle)}${recurMark}</span>${timeText ? `<span class="calendar-chip-time">${escapeHtml(timeText)}</span>` : ""}`;
  return chip;
}

function renderTaskChip(t) {
  const kind = String(t.calendar_kind || "task");
  const chip = document.createElement("a");
  chip.className = "calendar-chip";
  if (kind === "follow_up") chip.classList.add("calendar-chip--followup");
  else if (kind === "renewal") chip.classList.add("calendar-chip--renewal");
  else chip.classList.add("calendar-chip--task");
  if (kind !== "renewal" && isTaskOverdue(t)) chip.classList.add("calendar-chip--overdue");
  chip.href = `/contact.html?id=${encodeURIComponent(t.contact_id)}${kind === "renewal" ? "" : "#tasks"}`;
  chip.dataset.taskId = String(t.id);
  chip.dataset.kind = kind;
  const timeText = humanReadableTime(t.task_time) || "";
  const contactName = String(t.contact_name || "").trim();
  const name = t.task_name || (kind === "follow_up" ? "Follow-up" : kind === "renewal" ? "Renewal" : "Task");
  const label = contactName ? `${name} · ${contactName}` : name;
  const overdueMark = kind !== "renewal" && isTaskOverdue(t) ? " — overdue" : "";
  chip.title = `${name}${contactName ? ` (${contactName})` : ""}${timeText ? ` · ${timeText}` : ""}${overdueMark}`;
  chip.innerHTML = `<span class="calendar-chip-title">${escapeHtml(label)}</span>${timeText ? `<span class="calendar-chip-time">${escapeHtml(timeText)}</span>` : ""}`;
  return chip;
}

function collectVisibleItems() {
  const range = getViewRange();
  const expandedEvents = getExpandedEventsForRange(range.start, range.end);
  const items = [];
  for (const ev of expandedEvents) {
    if (!eventPassesFilters(ev)) continue;
    items.push({ kind: "event", item: ev, sortKey: `${ev.event_date} ${ev.event_time || "99:99"}` });
  }
  for (const t of cachedTasks) {
    if (!itemKindPasses("task")) continue;
    items.push({ kind: "task", item: t, sortKey: `${t.task_date} ${t.task_time || "99:99"}` });
  }
  for (const t of cachedFollowUps) {
    if (!itemKindPasses("follow_up")) continue;
    items.push({ kind: "follow_up", item: t, sortKey: `${t.task_date} ${t.task_time || "99:99"}` });
  }
  for (const t of cachedRenewals) {
    if (!itemKindPasses("renewal")) continue;
    items.push({ kind: "renewal", item: t, sortKey: `${t.task_date} ${t.task_time || "99:99"}` });
  }
  items.sort((a, b) => a.sortKey.localeCompare(b.sortKey));
  return items;
}

function appendChipForEntry(wrap, entry) {
  if (entry.kind === "event") wrap.appendChild(renderEventChip(entry.item));
  else wrap.appendChild(renderTaskChip(entry.item));
}

function renderOverflowButton(wrap, iso, hiddenCount, hiddenTitles) {
  const more = document.createElement("button");
  more.type = "button";
  more.className = "calendar-chip calendar-chip--more";
  more.dataset.date = iso;
  more.dataset.more = "1";
  more.title = hiddenTitles.join("\n");
  more.textContent = `+${hiddenCount} more`;
  wrap.appendChild(more);
}

function renderItemsIntoCells(cells, maxVisible) {
  const grouped = new Map();
  for (const cell of cells) {
    grouped.set(cell.dataset.date, cell.querySelector(".calendar-day-items"));
  }

  const byDate = new Map();
  for (const entry of collectVisibleItems()) {
    if (entry.kind === "event") {
      const ev = entry.item;
      const displayDate = ev._occurrenceDate || ev.event_date;
      const startDate = displayDate;
      const endDate = ev.end_date && ev.end_date >= startDate && !ev._occurrenceDate ? ev.end_date : startDate;
      const startDt = parseIsoDate(startDate);
      const endDt = parseIsoDate(endDate);
      if (!startDt || !endDt) continue;
      const cursor = new Date(startDt);
      while (cursor <= endDt) {
        const iso = formatIsoDate(cursor);
        if (!byDate.has(iso)) byDate.set(iso, []);
        byDate.get(iso).push(entry);
        cursor.setDate(cursor.getDate() + 1);
      }
    } else {
      const iso = String(entry.item.task_date || "");
      if (!iso) continue;
      if (!byDate.has(iso)) byDate.set(iso, []);
      byDate.get(iso).push(entry);
    }
  }

  let totalVisible = 0;
  for (const [iso, wrap] of grouped) {
    const dayItems = byDate.get(iso) || [];
    totalVisible += dayItems.length;
    const limit = Number(maxVisible) > 0 ? Number(maxVisible) : dayItems.length;
    const show = dayItems.slice(0, limit);
    const hidden = dayItems.slice(limit);
    for (const entry of show) appendChipForEntry(wrap, entry);
    if (hidden.length) {
      const titles = hidden.map((entry) => {
        if (entry.kind === "event") return entry.item.title || "Event";
        return entry.item.task_name || "Item";
      });
      renderOverflowButton(wrap, iso, hidden.length, titles);
    }
  }
  return totalVisible;
}

function updateEmptyState(visibleCount) {
  if (!emptyStateEl) return;
  if (viewMode === "day") {
    emptyStateEl.hidden = true;
    return;
  }
  const hasAny = Number(visibleCount) > 0;
  emptyStateEl.hidden = hasAny;
  if (viewMode === "week") {
    emptyStateEl.textContent = "No events this week — click a day or + Add.";
  } else {
    emptyStateEl.textContent = "No events this month — click a day or + Add.";
  }
}

function buildMonthGrid() {
  gridEl.innerHTML = "";
  gridEl.className = "calendar-grid calendar-grid--month";
  gridEl.setAttribute("aria-label", "Month view");
  const headers = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  for (const label of headers) {
    const head = document.createElement("div");
    head.className = "calendar-day-header";
    head.textContent = label;
    gridEl.appendChild(head);
  }
  const year = viewAnchor.getFullYear();
  const month = viewAnchor.getMonth();
  const { gridStart } = getMonthRange(year, month);
  const cursor = new Date(gridStart);
  const cells = [];
  for (let i = 0; i < 42; i += 1) {
    const isOther = cursor.getMonth() !== month;
    const cell = buildDayCell(new Date(cursor), isOther);
    gridEl.appendChild(cell);
    cells.push(cell);
    cursor.setDate(cursor.getDate() + 1);
  }
  const visibleCount = renderItemsIntoCells(cells, MONTH_MAX_VISIBLE_CHIPS);
  updateEmptyState(visibleCount);
}

function buildWeekGrid() {
  gridEl.innerHTML = "";
  gridEl.className = "calendar-grid calendar-grid--week";
  gridEl.setAttribute("aria-label", "Week view");
  const weekStart = startOfWeek(viewAnchor);
  const cursor = new Date(weekStart);
  const cells = [];
  for (let i = 0; i < 7; i += 1) {
    const day = new Date(cursor);
    const head = document.createElement("div");
    head.className = "calendar-day-header calendar-day-header--week";
    const weekday = day.toLocaleDateString(undefined, { weekday: "short" });
    const datePart = day.toLocaleDateString(undefined, { month: "short", day: "numeric" });
    head.innerHTML = `<span class="calendar-week-weekday">${escapeHtml(weekday)}</span><span class="calendar-week-date">${escapeHtml(datePart)}</span>`;
    if (formatIsoDate(day) === formatIsoDate(new Date())) {
      head.classList.add("calendar-day-header--today");
    }
    gridEl.appendChild(head);
    cursor.setDate(cursor.getDate() + 1);
  }
  cursor.setTime(weekStart.getTime());
  for (let i = 0; i < 7; i += 1) {
    const cell = buildDayCell(new Date(cursor), false);
    cell.classList.add("calendar-day-cell--week");
    gridEl.appendChild(cell);
    cells.push(cell);
    cursor.setDate(cursor.getDate() + 1);
  }
  const visibleCount = renderItemsIntoCells(cells, WEEK_MAX_VISIBLE_CHIPS);
  updateEmptyState(visibleCount);
}

function buildDayGrid() {
  gridEl.innerHTML = "";
  gridEl.className = "calendar-grid calendar-grid--day";
  gridEl.setAttribute("aria-label", "Day view");
  updateEmptyState(1);
  const iso = formatIsoDate(viewAnchor);
  const agenda = document.createElement("div");
  agenda.className = "calendar-day-agenda";

  const items = collectVisibleItems().filter((entry) => {
    if (entry.kind === "event") {
      const ev = entry.item;
      return String(ev.event_date) === iso || ev._occurrenceDate === iso
        || (ev.end_date && ev.event_date <= iso && ev.end_date >= iso && !ev._occurrenceDate);
    }
    return String(entry.item.task_date) === iso;
  });

  if (!items.length) {
    const empty = document.createElement("p");
    empty.className = "calendar-day-agenda-empty hint";
    empty.textContent = "Nothing scheduled for this day. Click a filter above or + Add to create one.";
    agenda.appendChild(empty);
  } else {
    for (const entry of items) {
      const row = document.createElement("div");
      row.className = "calendar-day-agenda-row";
      appendChipForEntry(row, entry);
      agenda.appendChild(row);
    }
  }

  gridEl.appendChild(agenda);
}

function buildGrid() {
  if (viewMode === "week") buildWeekGrid();
  else if (viewMode === "day") buildDayGrid();
  else buildMonthGrid();
}

async function syncTaskRemindersFromApi() {
  if (typeof window.CadenceTaskReminder?.start !== "function") return;
  try {
    const { response, data } = await fetchApiJson("/api/tasks/upcoming?limit=100");
    if (!response.ok) return;
    const rows = Array.isArray(data) ? data : [];
    window.CadenceTaskReminder.start(rows);
  } catch {
    // ignore
  }
}

async function loadCalendarData() {
  const range = getViewRange();
  try {
    const { response, data } = await fetchApiJson(
      `/api/calendar/events?start=${range.start}&end=${range.end}`
    );
    if (!response.ok) throw new Error(data.error || "Failed to load calendar.");
    cachedEvents = Array.isArray(data.events) ? data.events : [];
    cachedTasks = Array.isArray(data.tasks) ? data.tasks : [];
    cachedFollowUps = Array.isArray(data.followUps) ? data.followUps : [];
    cachedRenewals = Array.isArray(data.renewals) ? data.renewals : [];
    // Back-compat: older API merged follow-ups into tasks
    if (!cachedFollowUps.length && cachedTasks.some((t) => String(t.id || "").startsWith("follow-up-"))) {
      const split = { tasks: [], followUps: [] };
      for (const t of cachedTasks) {
        if (String(t.id || "").startsWith("follow-up-") || t.calendar_kind === "follow_up") {
          split.followUps.push({ ...t, calendar_kind: "follow_up" });
        } else {
          split.tasks.push({ ...t, calendar_kind: t.calendar_kind || "task" });
        }
      }
      cachedTasks = split.tasks;
      cachedFollowUps = split.followUps;
    }
    buildGrid();
    showMessage("");
    syncTaskRemindersFromApi().catch(() => {});
  } catch (err) {
    showMessage(err.message || "Failed to load calendar.", true);
  }
}

function renderGoogleTabPanel() {
  if (!googleTabStatus) return;
  if (!googleStatus.configured) {
    googleTabStatus.textContent = "Google OAuth is not configured on this server. Add GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in Settings.";
    if (googleTabConnectBtn) googleTabConnectBtn.hidden = true;
    if (googleTabSyncBtn) googleTabSyncBtn.hidden = true;
    return;
  }
  if (googleStatus.connected) {
    googleTabStatus.textContent = `Connected${googleStatus.accountEmail ? ` as ${googleStatus.accountEmail}` : ""}. Use Sync to import events for the current view.`;
    if (googleTabConnectBtn) googleTabConnectBtn.hidden = true;
    if (googleTabSyncBtn) googleTabSyncBtn.hidden = false;
  } else {
    googleTabStatus.textContent = "Not connected yet. Connect your Google account to import and sync events.";
    if (googleTabConnectBtn) googleTabConnectBtn.hidden = false;
    if (googleTabSyncBtn) googleTabSyncBtn.hidden = true;
  }
}

function renderGooglePushControls() {
  const canPush = googleStatus.configured && googleStatus.connected;
  if (googlePushRow) googlePushRow.hidden = !canPush || activeAddTab === "task";
  if (googlePushHint) googlePushHint.hidden = canPush || activeAddTab === "task" || activeAddTab === "google";
  if (pushGoogleField) {
    pushGoogleField.disabled = !canPush;
    if (!canPush) pushGoogleField.checked = false;
  }
}

async function loadGoogleStatus() {
  try {
    const { response, data } = await fetchApiJson(`/api/google/calendar/status`);
    if (!response.ok) throw new Error(data.error || "Status check failed.");
    googleStatus = {
      connected: Boolean(data.connected),
      configured: Boolean(data.configured),
      accountEmail: String(data.accountEmail || ""),
      lastSyncAt: Number(data.lastSyncAt || 0)
    };
    renderGoogleBanner();
    renderGoogleTabPanel();
    renderGooglePushControls();
  } catch (_e) {
    googleBanner.hidden = true;
  }
}

function renderGoogleBanner() {
  // Expand only for first-time prompt when not connected; otherwise keep compact.
  const expanded = !googleStatus.connected && !hasSeenGoogleBanner();
  googleBanner.classList.toggle("calendar-google-banner--expanded", expanded);
  googleBanner.classList.toggle("calendar-google-banner--compact", !expanded);
  if (googleStatus.connected) {
    googleBanner.classList.add("calendar-google-banner--connected");
  } else {
    googleBanner.classList.remove("calendar-google-banner--connected");
  }
  if (googleSettingsLink) googleSettingsLink.hidden = false;
  if (!googleStatus.configured) {
    googleStatusText.textContent = "Google Calendar — not connected";
    googleHint.textContent = "Connect Google Calendar from Settings if you want syncing. You can ignore this if you only use Cadence.";
    googleConnectBtn.hidden = true;
    googleSyncBtn.hidden = true;
    googleDisconnectBtn.hidden = true;
    googleBanner.hidden = false;
    markGoogleBannerSeen();
    return;
  }
  googleBanner.hidden = false;
  if (googleStatus.connected) {
    const email = googleStatus.accountEmail ? ` · ${googleStatus.accountEmail}` : "";
    googleStatusText.textContent = expanded
      ? `Google Calendar — connected${googleStatus.accountEmail ? ` (${googleStatus.accountEmail})` : ""}`
      : `Google connected${email}`;
    const lastSync = googleStatus.lastSyncAt
      ? new Date(googleStatus.lastSyncAt * 1000).toLocaleString()
      : "Never";
    googleHint.textContent = `Last sync: ${lastSync}. Click Sync to refresh this view.`;
    googleConnectBtn.hidden = true;
    googleSyncBtn.hidden = false;
    googleDisconnectBtn.hidden = true; // keep disconnect in Settings when compact
    if (googleSettingsLink) googleSettingsLink.textContent = "Manage";
  } else {
    googleStatusText.textContent = "Google Calendar — not connected";
    googleHint.textContent = "Connect your Google account to sync events both ways.";
    googleConnectBtn.hidden = false;
    googleSyncBtn.hidden = true;
    googleDisconnectBtn.hidden = true;
    if (googleSettingsLink) googleSettingsLink.textContent = "Settings";
  }
  markGoogleBannerSeen();
}

async function loadContacts() {
  try {
    const { response, data } = await fetchApiJson(`/api/contacts?limit=500`);
    if (!response.ok) return;
    const items = Array.isArray(data?.items) ? data.items : Array.isArray(data) ? data : [];
    cachedContacts = items.map((c) => ({ id: Number(c.id), name: String(c.full_name || "") }));
    refreshContactList();
  } catch (_e) {
    cachedContacts = [];
  }
}

function refreshContactList() {
  if (!contactList) return;
  contactList.innerHTML = "";
  for (const c of cachedContacts) {
    if (!c.name) continue;
    const opt = document.createElement("option");
    opt.value = `${c.name} #${c.id}`;
    contactList.appendChild(opt);
  }
}

function resolveContactInputToId(value) {
  const v = String(value || "").trim();
  if (!v) return null;
  const idMatch = v.match(/#(\d+)\s*$/);
  if (idMatch) return Number(idMatch[1]);
  const found = cachedContacts.find((c) => c.name && c.name.toLowerCase() === v.toLowerCase());
  return found ? found.id : null;
}

function setAddTab(tab, { skipFormReset = false } = {}) {
  if (editingEvent && tab !== "event") return;
  activeAddTab = tab;
  for (const el of addTabEls) {
    const isActive = el.dataset.addTab === tab;
    el.classList.toggle("is-active", isActive);
    el.setAttribute("aria-selected", isActive ? "true" : "false");
  }
  if (addTabDescEl) addTabDescEl.textContent = ADD_TAB_DESCRIPTIONS[tab] || "";
  const isGoogle = tab === "google";
  if (googleTabPanel) googleTabPanel.hidden = !isGoogle;
  if (eventForm) eventForm.hidden = isGoogle;
  if (saveBtn) saveBtn.hidden = isGoogle;
  if (deleteBtn && !editingEvent) deleteBtn.hidden = true;

  if (eventOnlyFields) eventOnlyFields.hidden = tab === "task";
  if (endDateField && endDateField.closest(".contact-field-box")) {
    endDateField.closest(".contact-field-box").hidden = tab === "task";
  }
  if (allDayField && allDayField.closest(".contact-field-box")) {
    allDayField.closest(".contact-field-box").hidden = tab === "task";
  }

  if (titleLabel) {
    titleLabel.textContent = tab === "task" ? "Task name *" : "Title *";
  }
  if (titleField) {
    titleField.placeholder = tab === "task" ? "e.g. Send renewal quote" : "e.g. Discovery call with Acme";
  }
  if (contactLabel) {
    if (tab === "contact" || tab === "task") {
      contactLabel.textContent = "Contact *";
    } else {
      contactLabel.textContent = "Linked contact (optional)";
    }
  }
  if (timeRow) {
    const timeLabel = timeRow.querySelector('label[for="calendarEventTime"]');
    if (timeLabel) timeLabel.textContent = tab === "task" ? "Due time" : "Start time";
  }
  if (saveBtn) {
    saveBtn.textContent = tab === "task" ? "Save Task" : tab === "contact" ? "Save Contact Event" : "Save Event";
  }
  if (eventModalTitle && !editingEvent) {
    const titles = { event: "Add Event", google: "Google Calendar", contact: "Add Contact Event", task: "Add Task" };
    eventModalTitle.textContent = titles[tab] || "Add Event";
  }
  renderGooglePushControls();
  renderGoogleTabPanel();
  if (!skipFormReset) renderTimezoneHint();
}

function openModalForCreate(prefDate, preferredTab = "event") {
  editingEvent = false;
  eventForm.reset();
  formError.textContent = "";
  eventIdField.value = "";
  dateField.value = prefDate || formatIsoDate(new Date());
  endDateField.value = "";
  allDayField.checked = false;
  colorField.value = "#2563eb";
  contactIdField.value = "";
  contactInput.value = "";
  if (recurrenceField) recurrenceField.value = "";
  deleteBtn.hidden = true;
  for (const el of addTabEls) el.hidden = false;
  setAddTab(preferredTab);
  syncTimeRowVisibility();
  renderGooglePushControls();
  if (pushGoogleField && googleStatus.connected) pushGoogleField.checked = true;
  eventModal.classList.remove("hidden");
  setTimeout(() => titleField.focus(), 50);
}

function openModalForEdit(ev) {
  editingEvent = true;
  eventModalTitle.textContent = "Edit Event";
  eventForm.reset();
  formError.textContent = "";
  eventIdField.value = String(ev.id);
  titleField.value = ev.title || "";
  dateField.value = ev.event_date || "";
  endDateField.value = ev.end_date && ev.end_date !== ev.event_date ? ev.end_date : "";
  allDayField.checked = Number(ev.all_day) === 1;
  timeField.value = ev.event_time || "";
  endTimeField.value = ev.end_time || "";
  locationField.value = ev.location || "";
  colorField.value = ev.color || "#2563eb";
  descriptionField.value = ev.description || "";
  if (recurrenceField) recurrenceField.value = String(ev.recurrence || "");
  if (ev.contact_id && ev.contact_name) {
    contactInput.value = `${ev.contact_name} #${ev.contact_id}`;
    contactIdField.value = String(ev.contact_id);
  } else {
    contactInput.value = "";
    contactIdField.value = "";
  }
  if (pushGoogleField) {
    pushGoogleField.checked = Boolean(ev.google_event_id);
    pushGoogleField.disabled = Boolean(ev.google_event_id) || !googleStatus.connected;
  }
  deleteBtn.hidden = false;
  for (const el of addTabEls) el.hidden = true;
  setAddTab("event", { skipFormReset: true });
  syncTimeRowVisibility();
  renderGooglePushControls();
  eventModal.classList.remove("hidden");
  setTimeout(() => titleField.focus(), 50);
}

function closeModal() {
  eventModal.classList.add("hidden");
  isSubmitting = false;
  editingEvent = false;
  formError.textContent = "";
  for (const el of addTabEls) el.hidden = false;
}

function syncTimeRowVisibility() {
  const allDay = allDayField.checked;
  timeRow.style.display = allDay && activeAddTab !== "task" ? "none" : "";
}

async function submitTaskForm() {
  const contactId = resolveContactInputToId(contactInput.value);
  if (!contactId) {
    formError.textContent = "Pick a contact for this task.";
    isSubmitting = false;
    return;
  }
  const taskName = titleField.value.trim();
  if (!taskName) {
    formError.textContent = "Task name is required.";
    isSubmitting = false;
    return;
  }
  const taskDate = dateField.value.trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(taskDate)) {
    formError.textContent = "Please pick a valid date.";
    isSubmitting = false;
    return;
  }
  try {
    const { response, data } = await fetchApiJson(`/api/contacts/${contactId}/tasks`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        task_name: taskName,
        task_date: taskDate,
        task_time: formatHhmm(timeField.value),
        action_type: "Other",
        condition: "Yet to Start"
      })
    });
    if (!response.ok) throw new Error(data.error || "Failed to save task.");
    closeModal();
    await loadCalendarData();
    showMessage("Task added.");
  } catch (err) {
    formError.textContent = err.message || "Failed to save task.";
  } finally {
    isSubmitting = false;
  }
}

async function submitEvent(e) {
  e.preventDefault();
  if (isSubmitting) return;
  if (activeAddTab === "google") return;
  isSubmitting = true;
  formError.textContent = "";

  if (activeAddTab === "task") {
    await submitTaskForm();
    return;
  }

  const id = eventIdField.value.trim();
  const allDay = allDayField.checked;
  const contactId = resolveContactInputToId(contactInput.value);
  if (activeAddTab === "contact" && !contactId) {
    formError.textContent = "Pick a contact for this event.";
    isSubmitting = false;
    return;
  }

  const payload = {
    title: titleField.value.trim(),
    description: descriptionField.value.trim(),
    event_date: dateField.value.trim(),
    event_time: allDay ? "" : formatHhmm(timeField.value),
    end_date: (endDateField.value.trim() || dateField.value.trim()),
    end_time: allDay ? "" : formatHhmm(endTimeField.value),
    all_day: allDay ? 1 : 0,
    location: locationField.value.trim(),
    color: colorField.value || "#2563eb",
    contact_id: contactId,
    recurrence: recurrenceField ? recurrenceField.value : ""
  };
  if (!payload.title) {
    formError.textContent = "Title is required.";
    isSubmitting = false;
    return;
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(payload.event_date)) {
    formError.textContent = "Please pick a valid date.";
    isSubmitting = false;
    return;
  }
  if (!id && pushGoogleField && pushGoogleField.checked) {
    payload.push_to_google = true;
  }

  try {
    const path = id ? `/api/calendar/events/${id}` : `/api/calendar/events`;
    const method = id ? "PATCH" : "POST";
    const { response, data } = await fetchApiJson(path, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (!response.ok) throw new Error(data.error || "Failed to save event.");
    closeModal();
    await loadCalendarData();
    if (data && data.google_push_error) {
      showMessage(`Saved locally; Google push failed: ${data.google_push_error}`, true);
    } else {
      showMessage(id ? "Event updated." : "Event added.");
    }
  } catch (err) {
    formError.textContent = err.message || "Failed to save event.";
  } finally {
    isSubmitting = false;
  }
}

async function deleteCurrentEvent() {
  const id = eventIdField.value.trim();
  if (!id) return;
  if (!window.confirm("Delete this event? If it is synced to Google Calendar, it will also be removed there.")) return;
  try {
    const { response, data } = await fetchApiJson(`/api/calendar/events/${id}`, { method: "DELETE" });
    if (!response.ok) throw new Error(data.error || "Failed to delete event.");
    closeModal();
    await loadCalendarData();
    showMessage("Event deleted.");
  } catch (err) {
    formError.textContent = err.message || "Failed to delete event.";
  }
}

function handleGridClick(e) {
  const moreBtn = e.target.closest(".calendar-chip--more");
  if (moreBtn && moreBtn.dataset.date) {
    e.stopPropagation();
    e.preventDefault();
    viewAnchor = parseIsoDate(moreBtn.dataset.date) || viewAnchor;
    setViewMode("day");
    return;
  }
  const chip = e.target.closest(".calendar-chip");
  if (chip) {
    e.stopPropagation();
    const eid = chip.dataset.eventId;
    if (!eid) return;
    const found = cachedEvents.find((ev) => String(ev.id) === eid);
    if (found) openModalForEdit(found);
    return;
  }
  const cell = e.target.closest(".calendar-day-cell");
  if (cell && cell.dataset.date) {
    openModalForCreate(cell.dataset.date);
  }
}

gridEl.addEventListener("keydown", (e) => {
  if (e.key !== "Enter" && e.key !== " ") return;
  const cell = e.target.closest(".calendar-day-cell");
  if (!cell || !cell.dataset.date) return;
  e.preventDefault();
  openModalForCreate(cell.dataset.date);
});

function shiftPeriod(delta) {
  if (viewMode === "day") {
    viewAnchor = addDays(viewAnchor, delta);
  } else if (viewMode === "week") {
    viewAnchor = addDays(viewAnchor, delta * 7);
  } else {
    viewAnchor = new Date(viewAnchor.getFullYear(), viewAnchor.getMonth() + delta, 1);
  }
  setPeriodLabel();
  loadCalendarData();
}

function jumpToToday() {
  viewAnchor = new Date();
  setPeriodLabel();
  loadCalendarData();
}

function setViewMode(mode) {
  viewMode = mode;
  for (const el of viewTabEls) {
    const isActive = el.dataset.view === mode;
    el.classList.toggle("is-active", isActive);
    el.setAttribute("aria-selected", isActive ? "true" : "false");
  }
  setPeriodLabel();
  loadCalendarData();
}

async function connectGoogle() {
  try {
    const { response, data } = await fetchApiJson(`/api/google/calendar/auth-url?next=${encodeURIComponent("/calendar.html")}`);
    if (!response.ok) throw new Error(data.error || "Failed to start Google connect flow.");
    if (data.url) window.location.href = data.url;
  } catch (err) {
    showMessage(err.message || "Failed to connect Google Calendar.", true);
  }
}

async function disconnectGoogle() {
  if (!window.confirm("Disconnect Google Calendar? Synced events will remain in this CRM but will no longer be updated.")) return;
  try {
    const { response, data } = await fetchApiJson(`/api/google/calendar/disconnect`, { method: "POST" });
    if (!response.ok) throw new Error(data.error || "Failed to disconnect.");
    showMessage("Google Calendar disconnected.");
    await loadGoogleStatus();
  } catch (err) {
    showMessage(err.message || "Failed to disconnect.", true);
  }
}

async function syncGoogle() {
  const range = getViewRange();
  try {
    showMessage("Syncing with Google Calendar...");
    const { response, data } = await fetchApiJson(`/api/google/calendar/sync`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ start: range.start, end: range.end })
    });
    if (!response.ok) throw new Error(data.error || "Sync failed.");
    showMessage(`Synced. Imported: ${data.imported || 0}, updated: ${data.updated || 0}, pushed: ${data.pushed || 0}.`);
    await Promise.all([loadGoogleStatus(), loadCalendarData()]);
  } catch (err) {
    showMessage(err.message || "Sync failed.", true);
  }
}

function handleQueryParamFlags() {
  const params = new URLSearchParams(window.location.search);
  if (params.get("google_connected") === "1") {
    showMessage("Google Calendar connected successfully.");
    cleanupQueryParams();
  } else if (params.get("google_error")) {
    showMessage(`Google connection error: ${params.get("google_error")}`, true);
    cleanupQueryParams();
  }
}

function cleanupQueryParams() {
  if (window.history && window.history.replaceState) {
    const url = new URL(window.location.href);
    url.searchParams.delete("google_connected");
    url.searchParams.delete("google_error");
    window.history.replaceState({}, "", url.toString());
  }
}

function cleanupNewTaskQueryParams() {
  if (window.history && window.history.replaceState) {
    const url = new URL(window.location.href);
    url.searchParams.delete("newTask");
    url.searchParams.delete("contactId");
    window.history.replaceState({}, "", url.toString());
  }
}

function maybeOpenTaskFromContactsLink() {
  const params = new URLSearchParams(window.location.search);
  if (params.get("newTask") !== "1") return;
  const cid = Number(params.get("contactId") || 0);
  openModalForCreate(formatIsoDate(new Date()), "task");
  if (Number.isInteger(cid) && cid >= 1) {
    const found = cachedContacts.find((c) => Number(c.id) === cid);
    contactInput.value = found && found.name ? `${found.name} #${cid}` : `Contact #${cid}`;
    contactIdField.value = String(cid);
  }
  cleanupNewTaskQueryParams();
}

prevBtn.addEventListener("click", () => shiftPeriod(-1));
nextBtn.addEventListener("click", () => shiftPeriod(1));
todayBtn.addEventListener("click", jumpToToday);
addEventBtn.addEventListener("click", () => openModalForCreate(formatIsoDate(new Date()), "event"));
gridEl.addEventListener("click", handleGridClick);
allDayField.addEventListener("change", syncTimeRowVisibility);
eventForm.addEventListener("submit", submitEvent);
deleteBtn.addEventListener("click", deleteCurrentEvent);

for (const el of viewTabEls) {
  el.addEventListener("click", () => setViewMode(el.dataset.view || "month"));
}

for (const el of addTabEls) {
  el.addEventListener("click", () => setAddTab(el.dataset.addTab || "event"));
}

eventModal.addEventListener("click", (e) => {
  if (e.target.dataset && e.target.dataset.calendarClose !== undefined) closeModal();
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && !eventModal.classList.contains("hidden")) closeModal();
});

contactInput.addEventListener("change", () => {
  const id = resolveContactInputToId(contactInput.value);
  contactIdField.value = id ? String(id) : "";
});

if (googleConnectBtn) googleConnectBtn.addEventListener("click", () => connectGoogle("/calendar.html"));
if (googleDisconnectBtn) googleDisconnectBtn.addEventListener("click", disconnectGoogle);
if (googleSyncBtn) googleSyncBtn.addEventListener("click", syncGoogle);
if (googleTabConnectBtn) googleTabConnectBtn.addEventListener("click", () => connectGoogle("/calendar.html"));
if (googleTabSyncBtn) googleTabSyncBtn.addEventListener("click", syncGoogle);

if (filtersEl) {
  syncFilterControls();
  filtersEl.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-filter]");
    if (!btn) return;
    const key = btn.dataset.filter;
    if (!key) return;
    calendarFilters[key] = !Boolean(calendarFilters[key]);
    saveCalendarFilters();
    syncFilterControls();
    buildGrid();
  });
}

setPeriodLabel();
renderTimezoneHint();
handleQueryParamFlags();
loadCalendarData();
loadGoogleStatus();
loadContacts().then(() => {
  maybeOpenTaskFromContactsLink();
});

const CALENDAR_TASK_REMINDER_POLL_MS = 90_000;
setInterval(() => {
  syncTaskRemindersFromApi().catch(() => {});
}, CALENDAR_TASK_REMINDER_POLL_MS);
