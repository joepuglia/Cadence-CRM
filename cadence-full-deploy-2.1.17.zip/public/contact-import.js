const MAX_BYTES = 10 * 1024 * 1024;

const state = {
  csv: "",
  fileName: "",
  mappings: [],
  fields: [],
  totalRows: 0,
  preview: [],
  validRowCount: 0
};

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

async function fetchApiJson(path, init) {
  const response = await fetch(path, { credentials: "include", ...(init || {}) });
  let data = {};
  try {
    data = await response.json();
  } catch {
    data = {};
  }
  return { response, data };
}

function setStep(step) {
  document.querySelectorAll(".import-step").forEach((el) => {
    const n = Number(el.getAttribute("data-step"));
    el.classList.toggle("is-active", n === step);
    el.classList.toggle("is-done", n < step);
  });
  document.querySelectorAll(".import-panel").forEach((panel) => {
    const n = Number(panel.getAttribute("data-import-step"));
    const active = n === step;
    panel.classList.toggle("is-active", active);
    panel.hidden = !active;
  });
}

function showError(el, msg) {
  if (!el) return;
  if (!msg) {
    el.hidden = true;
    el.textContent = "";
    return;
  }
  el.hidden = false;
  el.textContent = msg;
}

function confidenceBadge(confidence) {
  const c = String(confidence || "skipped").toLowerCase();
  if (c === "auto") return '<span class="import-badge import-badge--auto">Auto</span>';
  if (c === "review") return '<span class="import-badge import-badge--review">Review</span>';
  return '<span class="import-badge import-badge--skip">Skipped</span>';
}

const NAME_FIELD_KEYS = new Set(["full_name", "first_name", "last_name"]);

function normalizeImportFieldKey(field) {
  const raw = String(field || "").trim();
  if (!raw) return "";
  if (NAME_FIELD_KEYS.has(raw)) return raw;
  const key = raw.toLowerCase().replace(/[\s-]+/g, "_");
  if (NAME_FIELD_KEYS.has(key)) return key;
  if (key === "firstname" || key === "fname") return "first_name";
  if (key === "lastname" || key === "lname") return "last_name";
  if (key === "fullname" || key === "name" || key === "contact_name") return "full_name";
  return raw;
}

function inferNameFieldFromHeader(header) {
  const key = String(header || "")
    .replace(/^\uFEFF/, "")
    .trim()
    .toLowerCase()
    .replace(/-/g, " ")
    .replace(/\s+/g, " ");
  if (["first name", "first_name", "fname", "first"].includes(key)) return "first_name";
  if (["last name", "last_name", "lname", "last", "surname"].includes(key)) return "last_name";
  if (
    [
      "full name",
      "full_name",
      "name",
      "contact name",
      "primary applicant full name",
      "primary applicant name",
      "applicant name",
      "insured name",
      "member name",
      "client name",
      "lead name"
    ].includes(key)
  ) {
    return "full_name";
  }
  return "";
}

function readSelectMappingField(select, mapping) {
  const rawValue = String(select?.value ?? "");
  if (rawValue) return normalizeImportFieldKey(rawValue);
  if (select?.dataset?.touched === "1") return "";
  const fromInitial = normalizeImportFieldKey(select?.dataset?.initialField || "");
  if (fromInitial) return fromInitial;
  return inferNameFieldFromHeader(mapping?.header || "");
}

function fieldOptions(fields, selected) {
  const normalizedSelected = normalizeImportFieldKey(selected);
  const opts = ['<option value="">— Skip column —</option>'];
  for (const f of fields) {
    const sel = f.key === selected || f.key === normalizedSelected ? " selected" : "";
    opts.push(`<option value="${escapeHtml(f.key)}"${sel}>${escapeHtml(f.label)}</option>`);
  }
  return opts.join("");
}

function syncMappingSelectValues() {
  document.querySelectorAll("#importMapBody tr[data-map-idx]").forEach((row) => {
    const idx = parseInt(row.getAttribute("data-map-idx"), 10);
    const select = row.querySelector(".import-field-select");
    if (!select || !Number.isFinite(idx) || !state.mappings[idx]) return;
    const desired = normalizeImportFieldKey(state.mappings[idx].field || select.dataset.initialField || "");
    if (!desired) return;
    if ([...select.options].some((opt) => opt.value === desired)) {
      select.value = desired;
    }
  });
}

function hasNameMapping(mappings) {
  readMappingsFromTable();
  const list = Array.isArray(mappings) ? mappings : [];
  if (list.some((m) => NAME_FIELD_KEYS.has(normalizeImportFieldKey(m.field)))) return true;
  for (const select of document.querySelectorAll("#importMapBody .import-field-select")) {
    const field = normalizeImportFieldKey(select.value || select.dataset.initialField || "");
    if (NAME_FIELD_KEYS.has(field)) return true;
  }
  return list.some((m) => NAME_FIELD_KEYS.has(inferNameFieldFromHeader(m.header)));
}

function updateMappingConfidence(row, field) {
  const staticAliases = row.dataset.staticField || "";
  if (!field) return "skipped";
  if (staticAliases && staticAliases === field) return "auto";
  return row.querySelector(".import-field-select")?.dataset.initialField === field ? row.dataset.initialConfidence || "review" : "review";
}

function renderMapTable(data) {
  const tbody = document.getElementById("importMapBody");
  const hint = document.getElementById("importMapHint");
  if (!tbody) return;

  const samplesByHeader = new Map();
  if (state.csv) {
    /* samples come from server in mapping response - store in data if needed */
  }

  tbody.innerHTML = state.mappings
    .map((m, idx) => {
      const samples = (m.samples || []).join(" · ") || "—";
      return `<tr data-map-idx="${idx}" data-initial-confidence="${escapeHtml(m.confidence || "")}">
        <td><strong>${escapeHtml(m.header)}</strong></td>
        <td class="import-samples">${escapeHtml(samples)}</td>
        <td>
          <select class="import-field-select" data-initial-field="${escapeHtml(m.field || "")}">
            ${fieldOptions(state.fields, m.field || "")}
          </select>
        </td>
        <td class="import-confidence-cell">${confidenceBadge(m.confidence)}</td>
      </tr>`;
    })
    .join("");

  tbody.querySelectorAll(".import-field-select").forEach((select) => {
    select.addEventListener("change", () => {
      select.dataset.touched = "1";
      const row = select.closest("tr");
      const idx = parseInt(row?.getAttribute("data-map-idx"), 10);
      const field = normalizeImportFieldKey(select.value);
      const conf = field ? (select.dataset.initialField === field ? row.dataset.initialConfidence || "review" : "review") : "skipped";
      if (Number.isFinite(idx) && idx >= 0 && idx < state.mappings.length) {
        state.mappings[idx].field = field;
        state.mappings[idx].confidence = conf;
      }
      const cell = row?.querySelector(".import-confidence-cell");
      if (cell) cell.innerHTML = confidenceBadge(conf);
    });
  });
  syncMappingSelectValues();

  if (hint) {
    const parts = [];
    if (data.aiUsed) parts.push("Claude mapped your columns.");
    else if (data.aiUnavailable) {
      parts.push(
        data.aiError
          ? "AI could not map columns — using built-in aliases. Review any unmapped columns below."
          : "AI unavailable — using built-in column aliases only."
      );
    } else parts.push("Columns matched using built-in aliases.");
    parts.push(`${state.totalRows} row(s) detected.`);
    hint.textContent = parts.join(" ");
  }
}

function readMappingsFromTable() {
  document.querySelectorAll("#importMapBody tr[data-map-idx]").forEach((row) => {
    const idx = parseInt(row.getAttribute("data-map-idx"), 10);
    const select = row.querySelector(".import-field-select");
    if (!Number.isFinite(idx) || idx < 0 || idx >= state.mappings.length || !select) return;
    const field = readSelectMappingField(select, state.mappings[idx]);
    state.mappings[idx].field = field;
    state.mappings[idx].confidence = field
      ? select.dataset.initialField === field
        ? row.dataset.initialConfidence || "review"
        : "review"
      : "skipped";
  });
}

async function loadAiMapping() {
  showError(document.getElementById("importUploadError"), "");
  setStep(2);
  const mapBody = document.getElementById("importMapBody");
  if (mapBody) mapBody.innerHTML = '<tr><td colspan="4">Analyzing columns with AI…</td></tr>';

  const { response, data } = await fetchApiJson("/api/contacts/import-csv/suggest-mapping", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ csv: state.csv })
  });

  if (!response.ok) throw new Error(data.error || "Could not analyze CSV columns.");

  state.mappings = Array.isArray(data.mappings) ? data.mappings : [];
  state.fields = Array.isArray(data.fields) ? data.fields : [];
  state.totalRows = Number(data.totalRows) || 0;

  /* samples included from server */
  renderMapTable(data);
}

async function loadPreview() {
  readMappingsFromTable();
  showError(document.getElementById("importMapError"), "");

  if (!hasNameMapping(state.mappings)) {
    showError(document.getElementById("importMapError"), "Map at least one name column (Full name, First name, or Last name).");
    return false;
  }

  const { response, data } = await fetchApiJson("/api/contacts/import-csv/preview", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ csv: state.csv, mappings: state.mappings })
  });

  if (!response.ok) {
    showError(document.getElementById("importMapError"), data.error || "Preview failed.");
    return false;
  }

  state.preview = Array.isArray(data.preview) ? data.preview : [];
  state.validRowCount = Number(data.totalRows) || state.totalRows;

  const head = document.getElementById("importPreviewHead");
  const body = document.getElementById("importPreviewBody");
  const meta = document.getElementById("importPreviewMeta");
  if (!head || !body) return true;

  const cols = ["full_name", "email", "phone", "status", "outcome", "lead_source"];
  const labels = { full_name: "Name", email: "Email", phone: "Phone", status: "Status", outcome: "Outcome", lead_source: "Lead source" };
  head.innerHTML = `<tr>${cols.map((c) => `<th>${labels[c]}</th>`).join("")}</tr>`;
  body.innerHTML = state.preview.length
    ? state.preview
        .map(
          (row) =>
            `<tr>${cols.map((c) => `<td>${escapeHtml(row[c] || "—")}</td>`).join("")}</tr>`
        )
        .join("")
    : '<tr><td colspan="6">No valid preview rows — check your name mapping.</td></tr>';

  if (meta) {
    meta.textContent = `Showing ${Math.min(3, state.preview.length)} of ${state.validRowCount} row(s).`;
  }

  if (data.parseErrors?.length) {
    showError(
      document.getElementById("importPreviewError"),
      data.parseErrors.map((e) => `Row ${e.row}: ${e.message}`).join(" ")
    );
  } else {
    showError(document.getElementById("importPreviewError"), "");
  }

  setStep(3);
  return true;
}

function showImportConfirm() {
  readMappingsFromTable();
  const mappedCount = state.mappings.filter((m) => m.field).length;
  const summary = document.getElementById("importDoneSummary");
  if (summary) {
    summary.textContent = `Ready to import up to ${state.validRowCount} contact(s) from "${state.fileName}". ${mappedCount} column(s) mapped.`;
  }
  document.getElementById("importSuccessBox").hidden = true;
  document.getElementById("importRunBtn").hidden = false;
  document.querySelector("#importStepDone .import-actions").hidden = false;
  setStep(4);
}

async function runImport() {
  const errEl = document.getElementById("importDoneError");
  const btn = document.getElementById("importRunBtn");
  showError(errEl, "");
  readMappingsFromTable();
  btn.disabled = true;
  btn.textContent = "Importing…";

  try {
    const { response, data } = await fetchApiJson("/api/contacts/import-csv", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        csv: state.csv,
        mappings: state.mappings,
        preserveCsvCreatedDates: Boolean(document.getElementById("importPreserveCsvCreatedDates")?.checked),
        existingBookImport: Boolean(document.getElementById("importExistingBook")?.checked)
      })
    });

    if (!response.ok) {
      const detail =
        Array.isArray(data.details) && data.details.length
          ? ` ${data.details.map((d) => `row ${d.row}: ${d.message}`).join("; ")}`
          : "";
      throw new Error((data.error || "Import failed") + detail);
    }

    const skipped = Number(data.skipped) || 0;
    const imported = Number(data.imported) || 0;
    const initialOmit = data?.initialImportOmit?.active;
    document.getElementById("importSuccessText").textContent = `Imported ${imported} contact(s).${
      skipped ? ` Skipped ${skipped} row(s).` : ""
    }${
      initialOmit
        ? " These contacts are tagged as an imported book and will not appear as new leads in Morning Briefing or Pipeline."
        : ""
    }`;
    document.getElementById("importSuccessBox").hidden = false;
    document.getElementById("importRunBtn").hidden = true;
    document.querySelector("#importStepDone .import-actions").hidden = true;
    document.getElementById("importDoneTitle").textContent = "Import complete";
    document.getElementById("importDoneSummary").textContent = "";
  } catch (err) {
    showError(errEl, err.message || "Import failed.");
    btn.disabled = false;
    btn.textContent = "Import contacts";
  }
}

async function loadParadigmaiPreset() {
  const errEl = document.getElementById("importParadigmaiError");
  const btn = document.getElementById("importParadigmaiReviewBtn");
  showError(errEl, "");
  if (btn) {
    btn.disabled = true;
    btn.textContent = "Loading…";
  }
  try {
    const res = await fetch("/paradigmai-cadence-import.csv", { credentials: "include" });
    if (!res.ok) throw new Error("Could not load Paradigmai import file.");
    state.csv = await res.text();
    state.fileName = "paradigmai-cadence-import.csv";
    await loadAiMapping();
  } catch (err) {
    showError(errEl, err.message || "Paradigmai import failed.");
    setStep(1);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = "Review in import wizard";
    }
  }
}

function isOwnerWorkspaceClient() {
  return window.__CRM_WORKSPACE_TYPE__ !== "trial";
}

async function importParadigmaiNow() {
  if (!isOwnerWorkspaceClient()) {
    showError(
      document.getElementById("importParadigmaiError"),
      "Paradigmai import is only available on the main operator workspace (not trial accounts)."
    );
    return;
  }
  const errEl = document.getElementById("importParadigmaiError");
  const successEl = document.getElementById("importParadigmaiSuccess");
  const successText = document.getElementById("importParadigmaiSuccessText");
  const btn = document.getElementById("importParadigmaiNowBtn");
  showError(errEl, "");
  if (successEl) successEl.hidden = true;

  if (
    !window.confirm(
      "Import all 250 Paradigmai agents into your current workspace? Existing contacts with the same email or name will be skipped."
    )
  ) {
    return;
  }

  if (btn) {
    btn.disabled = true;
    btn.textContent = "Importing…";
  }
  try {
    const { response, data } = await fetchApiJson("/api/contacts/import-paradigmai-bundle", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ skipDuplicates: true })
    });
    if (!response.ok) throw new Error(data.error || data.message || "Import failed.");
    const msg =
      data.message ||
      `Imported ${data.imported || 0} contact(s).${data.skipped ? ` Skipped ${data.skipped} duplicate(s).` : ""}`;
    if (successText) successText.textContent = msg;
    if (successEl) successEl.hidden = false;
    successEl?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  } catch (err) {
    showError(errEl, err.message || "Paradigmai import failed.");
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = "Import all 250 now";
    }
  }
}

async function handleFile(file) {
  if (!file) return;
  if (!/\.csv$/i.test(file.name) && file.type !== "text/csv") {
    showError(document.getElementById("importUploadError"), "Please upload a .csv file.");
    return;
  }
  if (file.size > MAX_BYTES) {
    showError(document.getElementById("importUploadError"), "File is too large (max 10 MB).");
    return;
  }

  state.fileName = file.name;
  state.csv = await file.text();
  try {
    await loadAiMapping();
  } catch (err) {
    showError(document.getElementById("importUploadError"), err.message || "Could not read CSV.");
    setStep(1);
  }
}

function resetWizard() {
  state.csv = "";
  state.fileName = "";
  state.mappings = [];
  state.preview = [];
  state.validRowCount = 0;
  document.getElementById("importFileInput").value = "";
  document.getElementById("importSuccessBox").hidden = true;
  document.getElementById("importRunBtn").hidden = false;
  document.querySelector("#importStepDone .import-actions").hidden = false;
  document.getElementById("importDoneTitle").textContent = "Ready to import";
  showError(document.getElementById("importUploadError"), "");
  showError(document.getElementById("importMapError"), "");
  showError(document.getElementById("importPreviewError"), "");
  showError(document.getElementById("importDoneError"), "");
  setStep(1);
}

const dropzone = document.getElementById("importDropzone");
const fileInput = document.getElementById("importFileInput");

dropzone?.addEventListener("click", () => fileInput?.click());
dropzone?.addEventListener("keydown", (e) => {
  if (e.key === "Enter" || e.key === " ") {
    e.preventDefault();
    fileInput?.click();
  }
});
dropzone?.addEventListener("dragover", (e) => {
  e.preventDefault();
  dropzone.classList.add("is-dragover");
});
dropzone?.addEventListener("dragleave", () => dropzone.classList.remove("is-dragover"));
dropzone?.addEventListener("drop", (e) => {
  e.preventDefault();
  dropzone.classList.remove("is-dragover");
  const file = e.dataTransfer?.files?.[0];
  handleFile(file);
});
fileInput?.addEventListener("change", () => handleFile(fileInput.files?.[0]));

document.getElementById("importMapNextBtn")?.addEventListener("click", () => {
  loadPreview();
});

document.getElementById("importPreviewNextBtn")?.addEventListener("click", () => {
  readMappingsFromTable();
  if (!hasNameMapping(state.mappings)) {
    showError(document.getElementById("importPreviewError"), "Map at least one name column before importing.");
    return;
  }
  showImportConfirm();
});

document.getElementById("importRunBtn")?.addEventListener("click", runImport);
document.getElementById("importAnotherBtn")?.addEventListener("click", resetWizard);

document.querySelectorAll("[data-go-step]").forEach((btn) => {
  btn.addEventListener("click", () => setStep(Number(btn.getAttribute("data-go-step"))));
});

document.getElementById("importParadigmaiNowBtn")?.addEventListener("click", () => importParadigmaiNow());
document.getElementById("importParadigmaiReviewBtn")?.addEventListener("click", () => loadParadigmaiPreset());

const importParams = new URLSearchParams(window.location.search);
if (importParams.get("paradigmai") === "1" && importParams.get("auto") === "1") {
  importParadigmaiNow();
}

async function loadImportedBookContext() {
  const checkbox = document.getElementById("importExistingBook");
  const repair = document.getElementById("importBookRepair");
  const repairText = document.getElementById("importBookRepairText");
  try {
    const { response, data } = await fetchApiJson("/api/contacts/imported-book");
    if (!response.ok) return;
    if (checkbox) checkbox.checked = Boolean(data?.isEmptyWorkspace) || !data?.contactCount;
    const untaggedNew = Number(data?.untaggedNewCount || 0);
    if (repair && repairText && untaggedNew >= 20) {
      repair.hidden = false;
      repairText.textContent = `${untaggedNew.toLocaleString(
        "en-US"
      )} NEW contacts are currently counted as new leads in Morning Briefing. If they came from another CRM, exclude them.`;
    }
  } catch {
    if (checkbox) checkbox.checked = true;
  }
}

async function markExistingBookFromImportPage() {
  const errEl = document.getElementById("importBookRepairError");
  const doneEl = document.getElementById("importBookRepairDone");
  const btn = document.getElementById("importBookRepairBtn");
  showError(errEl, "");
  if (doneEl) {
    doneEl.hidden = true;
    doneEl.textContent = "";
  }
  if (
    !window.confirm(
      "Exclude NEW contacts with no Cadence activity for 7+ days from Morning Briefing and Pipeline new-lead counts? Contacts you add later will still count as new."
    )
  ) {
    return;
  }
  if (btn) {
    btn.disabled = true;
    btn.textContent = "Updating…";
  }
  try {
    const { response, data } = await fetchApiJson("/api/contacts/imported-book", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "mark-new" })
    });
    if (!response.ok) throw new Error(data.error || "Could not update contacts.");
    const tagged = Number(data?.newlyTagged || data?.taggedCount || 0);
    if (doneEl) {
      doneEl.hidden = false;
      doneEl.textContent = `Excluded ${tagged.toLocaleString("en-US")} contact(s) from new-lead counts.`;
    }
    const repair = document.getElementById("importBookRepair");
    if (repair && Number(data?.untaggedNewCount || 0) < 20) repair.hidden = true;
  } catch (err) {
    showError(errEl, err.message || "Could not update contacts.");
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = "Exclude them from new-lead counts";
    }
  }
}

document.getElementById("importBookRepairBtn")?.addEventListener("click", () => markExistingBookFromImportPage());

loadImportedBookContext();
setStep(1);
