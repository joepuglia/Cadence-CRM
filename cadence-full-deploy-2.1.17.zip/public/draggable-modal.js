/**
 * Makes any `.contact-modal[data-draggable="1"]` element user-movable by
 * dragging its `.contact-modal-header`. The drag converts the card from the
 * default `margin: auto` centering to absolute positioning so inline
 * left/top values take effect; releasing the pointer simply leaves the card
 * wherever the user dropped it.
 *
 * Used by:
 *   - Contacts Workspace -> #twilioModal (Send SMS + Start Call)
 *   - Contact Details   -> #contactTwilioCallModal, #contactTwilioSmsModal
 */
(function () {
  "use strict";

  function isInteractiveTarget(node) {
    if (!node || typeof node.closest !== "function") return false;
    return Boolean(node.closest("button, a, input, select, textarea, .contact-modal-close"));
  }

  function clampToViewport(card, left, top) {
    const margin = 8;
    const maxLeft = Math.max(margin, window.innerWidth - card.offsetWidth - margin);
    // Keep at least 40px of the header visible so the user can always grab to move it back.
    const maxTop = Math.max(margin, window.innerHeight - 40);
    return {
      left: Math.min(Math.max(margin, left), maxLeft),
      top: Math.min(Math.max(margin, top), maxTop)
    };
  }

  function wireOne(modal) {
    if (!modal || modal.dataset.draggableWired === "1") return;
    const card = modal.querySelector(".contact-modal-card");
    const header = modal.querySelector(".contact-modal-header");
    if (!card || !header) return;

    let dragState = null;

    header.addEventListener("pointerdown", (event) => {
      if (event.button !== undefined && event.button !== 0) return;
      if (isInteractiveTarget(event.target)) return;
      const rect = card.getBoundingClientRect();
      card.classList.add("is-dragged");
      card.style.left = `${rect.left}px`;
      card.style.top = `${rect.top}px`;
      header.classList.add("is-dragging");
      dragState = {
        pointerId: event.pointerId,
        offsetX: event.clientX - rect.left,
        offsetY: event.clientY - rect.top
      };
      try {
        header.setPointerCapture(event.pointerId);
      } catch {
        // Pointer capture may fail in embedded contexts (e.g. iframes); ignore.
      }
      event.preventDefault();
    });

    header.addEventListener("pointermove", (event) => {
      if (!dragState || event.pointerId !== dragState.pointerId) return;
      const next = clampToViewport(card, event.clientX - dragState.offsetX, event.clientY - dragState.offsetY);
      card.style.left = `${next.left}px`;
      card.style.top = `${next.top}px`;
    });

    function endDrag(event) {
      if (!dragState || (event && event.pointerId !== dragState.pointerId)) return;
      try {
        header.releasePointerCapture(dragState.pointerId);
      } catch {
        //
      }
      dragState = null;
      header.classList.remove("is-dragging");
    }

    header.addEventListener("pointerup", endDrag);
    header.addEventListener("pointercancel", endDrag);

    /**
     * On resize, pull a dragged card back inside the viewport if the window
     * shrank past it. Skipped when the user has never moved the card.
     */
    window.addEventListener("resize", () => {
      if (!card.classList.contains("is-dragged")) return;
      const currentLeft = parseFloat(card.style.left || "0") || 0;
      const currentTop = parseFloat(card.style.top || "0") || 0;
      const next = clampToViewport(card, currentLeft, currentTop);
      card.style.left = `${next.left}px`;
      card.style.top = `${next.top}px`;
    });

    modal.dataset.draggableWired = "1";
  }

  function init() {
    const modals = document.querySelectorAll('.contact-modal[data-draggable="1"]');
    modals.forEach(wireOne);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  // Expose for late-arriving modals (kept lightweight to avoid a global namespace surprise).
  window.crmMakeContactModalDraggable = wireOne;
})();
