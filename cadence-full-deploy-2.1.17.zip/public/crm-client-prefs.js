/**
 * Lightweight client prefs helpers (localStorage + sessionStorage fallback).
 * Used by onboarding tour, setup bar, and first-login wizard.
 */
(function initCrmClientPrefs() {
  function isMobileLayout() {
    try {
      return window.matchMedia("(max-width: 768px)").matches;
    } catch {
      return false;
    }
  }

  function readFlag(key) {
    try {
      if (localStorage.getItem(key) === "1") return true;
    } catch {
      /* ignore */
    }
    try {
      if (sessionStorage.getItem(key) === "1") return true;
    } catch {
      /* ignore */
    }
    return false;
  }

  function writeFlag(key) {
    try {
      localStorage.setItem(key, "1");
    } catch {
      /* ignore */
    }
    try {
      sessionStorage.setItem(key, "1");
    } catch {
      /* ignore */
    }
  }

  async function resolveOnboardingAccount() {
    if (window.__CRM_ONBOARDING_ACCOUNT__) return window.__CRM_ONBOARDING_ACCOUNT__;
    try {
      const res = await fetch("/api/auth/status", { credentials: "include" });
      const data = await res.json();
      const ws = data && data.workspace ? data.workspace : {};
      const type = String(ws.type || (data && data.authenticated ? "owner" : "anon"));
      const tenantId = ws.tenantId != null ? String(ws.tenantId) : "";
      const email = String(ws.email || "").trim().toLowerCase();
      window.__CRM_WORKSPACE_TYPE__ = window.__CRM_WORKSPACE_TYPE__ || type;
      window.__CRM_ONBOARDING_ACCOUNT__ = [type, tenantId, email].filter(Boolean).join(":") || "anon";
    } catch {
      window.__CRM_ONBOARDING_ACCOUNT__ = window.__CRM_ONBOARDING_ACCOUNT__ || "anon";
    }
    return window.__CRM_ONBOARDING_ACCOUNT__;
  }

  function accountFlagKey(baseKey) {
    const acct = String(window.__CRM_ONBOARDING_ACCOUNT__ || "");
    return acct ? `${baseKey}::${acct}` : baseKey;
  }

  function readAccountFlag(baseKey) {
    if (readFlag(accountFlagKey(baseKey))) return true;
    // A new trial login must not inherit dismissals from a previous account in this browser.
    if (String(window.__CRM_WORKSPACE_TYPE__) === "trial") return false;
    return readFlag(baseKey);
  }

  function writeAccountFlag(baseKey) {
    writeFlag(accountFlagKey(baseKey));
  }

  window.CrmClientPrefs = {
    isMobileLayout,
    readFlag,
    writeFlag,
    resolveOnboardingAccount,
    readAccountFlag,
    writeAccountFlag
  };
})();
