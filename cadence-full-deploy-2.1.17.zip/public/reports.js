const messageEl = document.getElementById("reportsMessage");
const daysSelect = document.getElementById("reportsDaysSelect");
const refreshBtn = document.getElementById("reportsRefreshBtn");
const exportBtn = document.getElementById("reportsExportBtn");
const tableBody = document.getElementById("reportsTableBody");
const totalsSourceEl = document.getElementById("reportsTotalsSource");
const totalsTotalEl = document.getElementById("reportsTotalsTotal");
const totalsSoldEl = document.getElementById("reportsTotalsSold");
const totalsRateEl = document.getElementById("reportsTotalsRate");
const emailSentEl = document.getElementById("reportsEmailSent");
const emailOpenedEl = document.getElementById("reportsEmailOpened");
const emailOpenRateEl = document.getElementById("reportsEmailOpenRate");
const emailClickOpenedEl = document.getElementById("reportsEmailClickOpened");
const emailClickedEl = document.getElementById("reportsEmailClicked");
const emailClickRateEl = document.getElementById("reportsEmailClickRate");

let currentReport = { items: [], totals: { total: 0, sold: 0, close_rate: 0 }, days: null };
let currentEmailReport = {
  items: [],
  totals: { sent: 0, opened: 0, clicked: 0, open_rate: 0, click_to_open_rate: 0 },
  days: null
};

function showMessage(text, isError = false) {
  if (!messageEl) return;
  const str = String(text == null ? "" : text);
  if (isError && typeof window.crmHandleAuthErrorMessage === "function" && window.crmHandleAuthErrorMessage(str, isError)) {
    return;
  }
  messageEl.textContent = str;
  messageEl.style.color = isError ? "#c62828" : "#1b5e20";
}

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function csvEscape(value) {
  const text = String(value == null ? "" : value);
  if (/[",\n]/.test(text)) return `"${text.replace(/"/g, '""')}"`;
  return text;
}

function formatRate(rate) {
  const n = Number(rate);
  if (!Number.isFinite(n)) return "—";
  return `${n.toFixed(1)}%`;
}

function formatCount(value) {
  return String(Number(value || 0).toLocaleString());
}

function selectedDays() {
  const raw = daysSelect ? String(daysSelect.value || "30") : "30";
  if (raw === "all") return 0;
  const n = Number(raw);
  return Number.isFinite(n) && n > 0 ? n : 30;
}

function emptyTableRow(colspan, text) {
  return `<tr><td colspan="${colspan}" class="renewals-empty">${escapeHtml(text)}</td></tr>`;
}

function renderReport(data) {
  currentReport = data || currentReport;
  const items = Array.isArray(currentReport.items) ? currentReport.items : [];
  const totals = currentReport.totals || { total: 0, sold: 0, close_rate: 0 };
  if (totalsSourceEl) totalsSourceEl.textContent = String(items.length);
  if (totalsTotalEl) totalsTotalEl.textContent = formatCount(totals.total);
  if (totalsSoldEl) totalsSoldEl.textContent = formatCount(totals.sold);
  if (totalsRateEl) totalsRateEl.textContent = formatRate(totals.close_rate);
  if (!tableBody) return;
  if (!items.length) {
    tableBody.innerHTML = emptyTableRow(4, "No contacts in this date range.");
    return;
  }
  tableBody.innerHTML = items
    .map((row) => {
      return (
        `<tr>` +
        `<td>${escapeHtml(row.lead_source || "(None)")}</td>` +
        `<td>${formatCount(row.total)}</td>` +
        `<td>${formatCount(row.sold)}</td>` +
        `<td>${formatRate(row.close_rate)}</td>` +
        `</tr>`
      );
    })
    .join("");
}

function renderEmailReport(data) {
  currentEmailReport = data || currentEmailReport;
  const totals = currentEmailReport.totals || {
    sent: 0,
    opened: 0,
    clicked: 0,
    open_rate: 0,
    click_to_open_rate: 0
  };
  if (emailSentEl) emailSentEl.textContent = formatCount(totals.sent);
  if (emailOpenedEl) emailOpenedEl.textContent = formatCount(totals.opened);
  if (emailOpenRateEl) emailOpenRateEl.textContent = formatRate(totals.open_rate);
  if (emailClickOpenedEl) emailClickOpenedEl.textContent = formatCount(totals.opened);
  if (emailClickedEl) emailClickedEl.textContent = formatCount(totals.clicked);
  if (emailClickRateEl) emailClickRateEl.textContent = formatRate(totals.click_to_open_rate);
}

function reportPath(base, days) {
  return days > 0 ? `${base}?days=${days}` : base;
}

async function loadReport() {
  showMessage("");
  const days = selectedDays();
  const closePath = reportPath("/api/reports/close-rate-by-lead-source", days);
  const emailPath = reportPath("/api/reports/email-engagement", days);
  const [closeResult, emailResult] = await Promise.all([
    window.CrmApi.fetchApiJson(closePath),
    window.CrmApi.fetchApiJson(emailPath)
  ]);
  if (!closeResult.response.ok) {
    throw new Error((closeResult.data && closeResult.data.error) || "Could not load close rate report.");
  }
  if (!emailResult.response.ok) {
    throw new Error((emailResult.data && emailResult.data.error) || "Could not load email report.");
  }
  renderReport(closeResult.data);
  renderEmailReport(emailResult.data);
  const range = days > 0 ? `last ${days} days` : "all time";
  showMessage(`Updated ${new Date().toLocaleTimeString()} · ${range}`);
}

function exportCsv() {
  const items = Array.isArray(currentReport.items) ? currentReport.items : [];
  const totals = currentReport.totals || { total: 0, sold: 0, close_rate: 0 };
  const emailTotals = currentEmailReport.totals || {
    sent: 0,
    opened: 0,
    clicked: 0,
    open_rate: 0,
    click_to_open_rate: 0
  };
  const lines = [
    "Close rate by lead source",
    "Lead source,Total contacts,Sold,Close rate %",
    ...items.map((row) => [csvEscape(row.lead_source), row.total, row.sold, row.close_rate].join(",")),
    ["Total", totals.total, totals.sold, totals.close_rate].join(","),
    "",
    "Emails opened vs sent",
    "Sent,Opened,Open rate %",
    [emailTotals.sent, emailTotals.opened, emailTotals.open_rate].join(","),
    "",
    "Emails clicked vs opened",
    "Opened,Clicked,Click-to-open rate %",
    [emailTotals.opened, emailTotals.clicked, emailTotals.click_to_open_rate].join(",")
  ];
  const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "cadence-reports.csv";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

if (daysSelect) {
  daysSelect.addEventListener("change", () => {
    loadReport().catch((error) => showMessage(error.message, true));
  });
}

if (refreshBtn) {
  refreshBtn.addEventListener("click", () => {
    loadReport().catch((error) => showMessage(error.message, true));
  });
}

if (exportBtn) {
  exportBtn.addEventListener("click", exportCsv);
}

loadReport().catch((error) => showMessage(error.message, true));
