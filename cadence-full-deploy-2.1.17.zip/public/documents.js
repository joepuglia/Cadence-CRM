const messageEl = document.getElementById("message");
const uploadForm = document.getElementById("documentUploadForm");
const fileInput = document.getElementById("documentFileInput");
const categorySelect = document.getElementById("documentCategorySelect");
const addCategoryBtn = document.getElementById("addDocumentCategoryBtn");
const deleteCategoryBtn = document.getElementById("deleteDocumentCategoryBtn");
const deleteCategoryModal = document.getElementById("deleteCategoryModal");
const deleteCategoryModalCloseBtn = document.getElementById("deleteCategoryModalCloseBtn");
const deleteCategoryModalForm = document.getElementById("deleteCategoryModalForm");
const deleteCategorySelect = document.getElementById("deleteCategorySelect");
const categoryFiltersEl = document.getElementById("documentsCategoryFilters");
const listEl = document.getElementById("documentsList");
const deleteSelectedBtn = document.getElementById("deleteSelectedDocumentsBtn");
const toggleEmptyCategoriesBtn = document.getElementById("toggleEmptyDocumentCategoriesBtn");
const uploadProgressEl = document.getElementById("documentUploadProgress");
const previewModal = document.getElementById("documentPreviewModal");
const previewModalCloseBtn = document.getElementById("documentPreviewModalCloseBtn");
const previewTitleEl = document.getElementById("documentPreviewTitle");
const previewBodyEl = document.getElementById("documentPreviewBody");
const previewDownloadLink = document.getElementById("documentPreviewDownloadLink");
const DEFAULT_DOCUMENT_CATEGORIES = ["State Licenses", "Health Summaries", "Vision Brochures", "Dental Brochures"];
const DOCUMENT_CATEGORY_RELEVANCE = [
  "Health Brochures",
  "Health Summaries",
  "Dental Brochures",
  "Vision Brochures",
  "State Licenses"
];
const DOCUMENT_CATEGORY_STORAGE_KEY = "crm.documents.customCategories";
const MAX_DOCUMENT_BYTES = 15 * 1024 * 1024;
let selectedDocumentCategory = "NONE";
let cachedDocuments = [];
const selectedDocumentIds = new Set();
let documentCategories = [...DEFAULT_DOCUMENT_CATEGORIES];
let showEmptyDocumentCategories = false;

function showMessage(text, isError = false) {
  const str = String(text == null ? "" : text);
  if (isError && typeof window.crmHandleAuthErrorMessage === "function" && window.crmHandleAuthErrorMessage(str, isError)) {
    return;
  }
  messageEl.textContent = str;
  messageEl.style.color = isError ? "#c62828" : "#1b5e20";
}

function getCrmApiBase() {
  const injected =
    typeof window.__CRM_API_ORIGIN__ === "string" ? window.__CRM_API_ORIGIN__.trim().replace(/\/$/, "") : "";
  if (injected) return injected;
  const fromMeta = document.querySelector('meta[name="crm-api-base"]')?.getAttribute("content") || "";
  return String(fromMeta || "").trim().replace(/\/$/, "");
}

function apiUrl(path) {
  const base = getCrmApiBase();
  const p = path.startsWith("/") ? path : `/${path}`;
  return base ? `${base}${p}` : p;
}

async function fetchApiJson(pathAndQuery, init) {
  const response = await fetch(apiUrl(pathAndQuery), init);
  const text = await response.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = {};
  }
  return { response, data };
}

function formatBytes(n) {
  const bytes = Number(n || 0);
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function formatUnix(sec) {
  const n = Number(sec || 0);
  if (!Number.isFinite(n) || n <= 0) return "";
  return new Date(n * 1000).toLocaleString();
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function cssEscape(value) {
  if (window.CSS && typeof window.CSS.escape === "function") return window.CSS.escape(String(value));
  return String(value).replace(/[^a-zA-Z0-9_-]/g, "\\$&");
}

function sortDocumentCategoryNames(names) {
  const priority = new Map(DOCUMENT_CATEGORY_RELEVANCE.map((name, index) => [name.toLowerCase(), index]));
  return [...new Set((Array.isArray(names) ? names : []).map((name) => String(name || "").trim()).filter(Boolean))].sort(
    (a, b) => {
      const ai = priority.has(a.toLowerCase()) ? priority.get(a.toLowerCase()) : 999;
      const bi = priority.has(b.toLowerCase()) ? priority.get(b.toLowerCase()) : 999;
      if (ai !== bi) return ai - bi;
      return a.localeCompare(b, undefined, { sensitivity: "base" });
    }
  );
}

function getDocumentTypeLabel(fileName, mimeType) {
  const ext = String(fileName || "")
    .split(".")
    .pop()
    ?.toLowerCase() || "";
  const mime = String(mimeType || "").toLowerCase();
  const extMap = {
    pdf: "PDF",
    doc: "DOC",
    docx: "DOCX",
    xls: "XLS",
    xlsx: "XLSX",
    ppt: "PPT",
    pptx: "PPTX",
    png: "PNG",
    jpg: "JPG",
    jpeg: "JPG",
    gif: "GIF",
    webp: "WEBP",
    txt: "TXT",
    csv: "CSV"
  };
  if (extMap[ext]) return extMap[ext];
  if (mime.includes("pdf")) return "PDF";
  if (mime.includes("word")) return "DOCX";
  if (mime.includes("excel") || mime.includes("spreadsheet")) return "XLSX";
  if (mime.includes("powerpoint") || mime.includes("presentation")) return "PPTX";
  if (mime.includes("image/")) return "IMAGE";
  return ext ? ext.toUpperCase() : "FILE";
}

function loadCustomDocumentCategories() {
  try {
    const raw = window.localStorage.getItem(DOCUMENT_CATEGORY_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(parsed)) return [];
    return parsed.map((v) => String(v || "").trim()).filter(Boolean);
  } catch {
    return [];
  }
}

function saveCustomDocumentCategories() {
  const custom = documentCategories.filter((name) => !DEFAULT_DOCUMENT_CATEGORIES.includes(name));
  try {
    window.localStorage.setItem(DOCUMENT_CATEGORY_STORAGE_KEY, JSON.stringify(custom));
  } catch {
    //
  }
}

function syncDocumentCategorySelect() {
  if (!categorySelect) return;
  const previous = String(categorySelect.value || "").trim();
  const options = [...documentCategories, "Uncategorized"];
  categorySelect.replaceChildren();
  const placeholder = document.createElement("option");
  placeholder.value = "";
  placeholder.textContent = "Choose Category";
  categorySelect.appendChild(placeholder);
  for (const name of options) {
    const opt = document.createElement("option");
    opt.value = name;
    opt.textContent = name;
    categorySelect.appendChild(opt);
  }
  categorySelect.value = previous && options.includes(previous) ? previous : "";
}

function getCustomDocumentCategories() {
  return documentCategories.filter((name) => !DEFAULT_DOCUMENT_CATEGORIES.includes(name));
}

function populateDeleteCategorySelect() {
  if (!deleteCategorySelect) return;
  const customCategories = getCustomDocumentCategories();
  deleteCategorySelect.replaceChildren();
  for (const name of customCategories) {
    const opt = document.createElement("option");
    opt.value = name;
    opt.textContent = name;
    deleteCategorySelect.appendChild(opt);
  }
}

function openDeleteCategoryModal() {
  if (!deleteCategoryModal) return;
  populateDeleteCategorySelect();
  if (!deleteCategorySelect || !deleteCategorySelect.options.length) {
    showMessage("No custom categories to delete.", true);
    return;
  }
  const current = String(categorySelect?.value || "").trim().toLowerCase();
  const match = [...deleteCategorySelect.options].find((o) => String(o.value || "").trim().toLowerCase() === current);
  deleteCategorySelect.value = match ? match.value : deleteCategorySelect.options[0].value;
  deleteCategoryModal.classList.remove("hidden");
  deleteCategoryModal.setAttribute("aria-hidden", "false");
}

function closeDeleteCategoryModal() {
  if (!deleteCategoryModal) return;
  deleteCategoryModal.classList.add("hidden");
  deleteCategoryModal.setAttribute("aria-hidden", "true");
}

function refreshDocumentCategories(rows) {
  const fromRows = (Array.isArray(rows) ? rows : [])
    .map((row) => String(row?.category_name || "").trim())
    .filter((name) => name && name !== "Uncategorized");
  const base = [...DEFAULT_DOCUMENT_CATEGORIES, ...loadCustomDocumentCategories(), ...fromRows];
  documentCategories = sortDocumentCategoryNames(base);
  saveCustomDocumentCategories();
  syncDocumentCategorySelect();
}

function normalizeDocumentCategory(raw) {
  const value = String(raw || "").trim();
  return value || "Uncategorized";
}

function renderCategoryFilters(rows) {
  if (!categoryFiltersEl) return;
  const list = Array.isArray(rows) ? rows : [];
  const counts = new Map();
  for (const name of documentCategories) counts.set(name, 0);
  counts.set("Uncategorized", 0);
  for (const row of list) {
    const category = normalizeDocumentCategory(row?.category_name);
    counts.set(category, Number(counts.get(category) || 0) + 1);
  }
  const options = ["ALL", ...documentCategories, "Uncategorized"];
  if (selectedDocumentCategory !== "NONE" && !options.includes(selectedDocumentCategory)) {
    selectedDocumentCategory = "NONE";
  }
  const visibleOptions = options.filter((name) => {
    if (name === "ALL") return true;
    const count = Number(counts.get(name) || 0);
    return showEmptyDocumentCategories || count > 0 || selectedDocumentCategory === name;
  });
  const hiddenEmptyCount = options.filter((name) => name !== "ALL" && Number(counts.get(name) || 0) === 0).length;
  if (toggleEmptyCategoriesBtn) {
    toggleEmptyCategoriesBtn.hidden = hiddenEmptyCount === 0;
    toggleEmptyCategoriesBtn.textContent = showEmptyDocumentCategories
      ? "Hide empty categories"
      : `+ Show empty categories (${hiddenEmptyCount})`;
  }
  categoryFiltersEl.innerHTML = visibleOptions
    .map((name) => {
      const label = name === "ALL" ? "All Documents" : name;
      const count = name === "ALL" ? list.length : Number(counts.get(name) || 0);
      const active = selectedDocumentCategory === name ? " is-active" : "";
      const empty = name !== "ALL" && count === 0 ? " documents-category-btn--empty" : "";
      return `<button type="button" class="documents-category-btn${active}${empty}" data-doc-category="${escapeHtml(name)}">${escapeHtml(label)} <strong>${count}</strong></button>`;
    })
    .join("");
  syncCategoryAdminControls();
}

function getVisibleDocuments() {
  if (selectedDocumentCategory === "NONE") return [];
  if (selectedDocumentCategory === "ALL") return [...cachedDocuments];
  return cachedDocuments.filter((row) => normalizeDocumentCategory(row?.category_name) === selectedDocumentCategory);
}

function syncDeleteSelectedButton() {
  if (!deleteSelectedBtn) return;
  const selectedCount = selectedDocumentIds.size;
  deleteSelectedBtn.hidden = selectedCount === 0;
  deleteSelectedBtn.textContent = selectedCount > 0 ? `Delete Selected (${selectedCount})` : "Delete Selected";
}

function syncCategoryAdminControls() {
  if (!deleteCategoryBtn || !categorySelect) return;
  const current = String(categorySelect.value || "").trim();
  const isCustom = getCustomDocumentCategories().some((name) => name.toLowerCase() === current.toLowerCase());
  deleteCategoryBtn.hidden = !isCustom;
}

async function fetchDocumentsHealth() {
  try {
    const { response, data } = await fetchApiJson("/api/documents/health");
    if (!response.ok) return null;
    return data && typeof data === "object" ? data : null;
  } catch {
    return null;
  }
}

function renderDocumentsEmptyListMessage() {
  if (cachedDocuments.length === 0) {
    return `<div class="documents-empty-state">
      <p><strong>No documents yet.</strong></p>
      <p class="hint">Upload your first file above to make it available as an email attachment on the <a href="/email.html">Send Email</a> page.</p>
    </div>`;
  }
  const categoryMsg =
    selectedDocumentCategory === "NONE"
      ? "Select a category above (or <strong>All Documents</strong>) to view your saved documents."
      : "No documents in this category yet. Upload a file above or choose another category.";
  return `<div class="contact-history-empty">${categoryMsg}</div>`;
}

function renderDocumentsRecoveryPanel(health) {
  const dbCount = Number(health?.dbCount || 0);
  const missing = Number(health?.missing || 0);
  const diskFileCount = Number(health?.diskFileCount || 0);
  const resolvable = Number(health?.resolvable || 0);

  if (cachedDocuments.length > 0) {
    return renderDocumentsEmptyListMessage();
  }

  if (dbCount > 0 && missing > 0) {
    return `<div class="documents-recovery-panel">
      <p><strong>${dbCount} document(s)</strong> are in the database, but <strong>${missing}</strong> file(s) are missing on this server.</p>
      <p class="hint">Deploy zips do not include your <code>uploads/documents/</code> folder. From your PC: run <code>npm run pack:uploads</code>, upload and extract <code>crmcadence-uploads-pack.zip</code> on cPanel, then run <code>node scripts/repair-upload-paths.js</code> and restart Node.</p>
    </div>`;
  }

  if (dbCount === 0 && diskFileCount > 0) {
    return `<div class="documents-recovery-panel">
      <p><strong>${diskFileCount} file(s)</strong> exist in <code>uploads/documents/</code>, but the database lists <strong>0</strong> documents for this workspace.</p>
      <p class="hint">Restore <code>crm.sqlite</code> from a backup (after backing up the server copy), or re-upload documents from your PC. Sign in with your <strong>owner</strong> login if documents were saved there—not a trial workspace.</p>
    </div>`;
  }

  if (dbCount > 0 && resolvable > 0) {
    return `<div class="contact-history-empty">Click <strong>All Documents</strong> above to see ${dbCount} saved document(s).</div>`;
  }

  if (dbCount === 0 && diskFileCount === 0) {
    return renderDocumentsEmptyListMessage();
  }

  return `<div class="documents-recovery-panel">
    <p>No saved documents in this workspace.</p>
    <p class="hint">If you had documents before: upload <code>uploads/</code> and <code>crm.sqlite</code> from your PC (see deploy notes), run <code>node scripts/diagnose-media.js</code>, restart Node, and use your owner login email.</p>
  </div>`;
}

function documentCategoryChoices(current) {
  const names = [];
  const seen = new Set();
  const add = (name) => {
    const value = String(name || "").trim();
    if (!value) return;
    const key = value.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    names.push(value);
  };
  for (const name of documentCategories) add(name);
  add("Uncategorized");
  add(current);
  return names;
}

function renderDocumentRow(d) {
  const typeLabel = getDocumentTypeLabel(d.file_name, d.mime_type);
  const category = normalizeDocumentCategory(d.category_name);
  const uploadedAt = formatUnix(d.created_at);
  return `<div class="document-row" data-document-id="${d.id}">
    <label class="document-row-select" title="Select for bulk actions">
      <input type="checkbox" class="document-select" data-id="${d.id}" aria-label="Select ${escapeHtml(d.file_name)}" ${selectedDocumentIds.has(Number(d.id)) ? "checked" : ""} />
      <span class="document-row-select-label">Bulk select</span>
    </label>
    <div class="document-row-main">
      <div class="document-row-title-line">
        <button type="button" class="document-name document-preview-btn" data-id="${d.id}" title="Preview ${escapeHtml(d.file_name)}">${escapeHtml(d.file_name)}</button>
        <button type="button" class="document-rename-btn" data-id="${d.id}" title="Rename this document" aria-label="Rename ${escapeHtml(d.file_name)}">Rename</button>
        <span class="document-type-badge">${escapeHtml(typeLabel)}</span>
      </div>
      <form class="document-rename-form" data-id="${d.id}" hidden>
        <input class="document-rename-input" value="${escapeHtml(d.file_name)}" aria-label="New document name" />
        <button type="submit">Save</button>
        <button type="button" class="document-rename-cancel">Cancel</button>
      </form>
      <div class="document-row-meta-line">
        <span>${formatBytes(d.size_bytes)}</span>
        <span class="document-meta-sep" aria-hidden="true">·</span>
        <label class="document-category-move">
          <span class="document-category-move-label">Category</span>
          <select class="document-category-select" data-id="${d.id}" aria-label="Move ${escapeHtml(d.file_name)} to a different category">
            ${documentCategoryChoices(category)
              .map((name) => {
                const selected = name.toLowerCase() === category.toLowerCase() ? " selected" : "";
                return `<option value="${escapeHtml(name)}"${selected}>${escapeHtml(name)}</option>`;
              })
              .join("")}
          </select>
        </label>
        <span class="document-meta-sep" aria-hidden="true">·</span>
        <span>Uploaded ${escapeHtml(uploadedAt || "—")}</span>
      </div>
    </div>
    <div class="document-item-actions">
      <a class="document-download-link" href="/api/documents/${d.id}/download" title="Download ${escapeHtml(d.file_name)}">Download</a>
      <button type="button" class="document-delete" data-id="${d.id}" title="Delete ${escapeHtml(d.file_name)}" aria-label="Delete ${escapeHtml(d.file_name)}">
        <svg aria-hidden="true" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M3 6h18"></path><path d="M8 6V4h8v2"></path><path d="M6 6l1 15h10l1-15"></path><path d="M10 11v6"></path><path d="M14 11v6"></path>
        </svg>
      </button>
    </div>
  </div>`;
}

function previewKindForDocument(row) {
  const mime = String(row?.mime_type || "").toLowerCase();
  const name = String(row?.file_name || "").toLowerCase();
  if (mime.startsWith("image/") || /\.(png|jpe?g|gif|webp)$/i.test(name)) return "image";
  if (mime.includes("pdf") || /\.pdf$/i.test(name)) return "frame";
  if (mime.startsWith("text/") || /\.(txt|csv)$/i.test(name)) return "frame";
  return "download";
}

function closeDocumentPreviewModal() {
  if (!previewModal) return;
  previewModal.classList.add("hidden");
  previewModal.setAttribute("aria-hidden", "true");
  if (previewBodyEl) previewBodyEl.replaceChildren();
}

function openDocumentPreview(id) {
  const row = cachedDocuments.find((doc) => Number(doc.id) === Number(id));
  if (!row || !previewModal || !previewBodyEl) return;
  const fileName = String(row.file_name || "Document");
  const previewUrl = `/api/documents/${encodeURIComponent(String(id))}/download?inline=1`;
  const downloadUrl = `/api/documents/${encodeURIComponent(String(id))}/download`;
  if (previewTitleEl) previewTitleEl.textContent = fileName;
  if (previewDownloadLink) previewDownloadLink.href = downloadUrl;
  previewBodyEl.replaceChildren();
  const kind = previewKindForDocument(row);
  if (kind === "image") {
    const img = document.createElement("img");
    img.src = previewUrl;
    img.alt = fileName;
    img.className = "document-preview-image";
    previewBodyEl.appendChild(img);
  } else if (kind === "frame") {
    const iframe = document.createElement("iframe");
    iframe.src = previewUrl;
    iframe.title = `Preview ${fileName}`;
    iframe.className = "document-preview-frame";
    previewBodyEl.appendChild(iframe);
  } else {
    previewBodyEl.innerHTML = `<div class="documents-empty-state">
      <p><strong>Preview is not available for this file type.</strong></p>
      <p class="hint">Download the document to review it before attaching it to an email.</p>
    </div>`;
  }
  previewModal.classList.remove("hidden");
  previewModal.setAttribute("aria-hidden", "false");
}

function startInlineRename(id) {
  const rowEl = listEl?.querySelector(`.document-row[data-document-id="${cssEscape(String(id))}"]`);
  if (!rowEl) return;
  const titleLine = rowEl.querySelector(".document-row-title-line");
  const form = rowEl.querySelector(".document-rename-form");
  const input = rowEl.querySelector(".document-rename-input");
  if (!titleLine || !form || !input) return;
  titleLine.hidden = true;
  form.hidden = false;
  input.focus();
  input.select();
}

function stopInlineRename(form) {
  const rowEl = form?.closest?.(".document-row");
  if (!rowEl) return;
  const titleLine = rowEl.querySelector(".document-row-title-line");
  if (titleLine) titleLine.hidden = false;
  form.hidden = true;
}

async function submitInlineRename(form) {
  const id = Number(form?.getAttribute("data-id"));
  if (!Number.isInteger(id) || id < 1) return;
  const input = form.querySelector(".document-rename-input");
  const row = cachedDocuments.find((doc) => Number(doc.id) === id);
  const currentName = String(row?.file_name || "").trim();
  const nextName = String(input?.value || "").trim();
  if (!nextName || nextName === currentName) {
    stopInlineRename(form);
    return;
  }
  const { response: patchResp, data: patchBody } = await fetchApiJson(`/api/documents/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ fileName: nextName })
  });
  if (!patchResp.ok) throw new Error(patchBody.error || "Failed to rename document");
  showMessage("Document renamed.");
  await loadDocuments();
}

async function loadDocuments() {
  const { response, data } = await fetchApiJson("/api/documents");
  if (!response.ok) throw new Error(data.error || "Failed to load documents");
  const rows = Array.isArray(data) ? data : [];
  refreshDocumentCategories(rows);
  cachedDocuments = rows;
  const validIds = new Set(rows.map((row) => Number(row.id)).filter((id) => Number.isInteger(id) && id > 0));
  [...selectedDocumentIds].forEach((id) => {
    if (!validIds.has(id)) selectedDocumentIds.delete(id);
  });
  renderCategoryFilters(rows);
  const visibleRows = getVisibleDocuments();
  if (!visibleRows.length) {
    const health = await fetchDocumentsHealth();
    listEl.innerHTML = renderDocumentsRecoveryPanel(health);
    syncDeleteSelectedButton();
    return;
  }
  listEl.innerHTML = visibleRows.map(renderDocumentRow).join("");

  listEl.querySelectorAll(".document-delete").forEach((el) => {
    el.addEventListener("click", async () => {
      const id = Number(el.getAttribute("data-id"));
      if (!Number.isInteger(id) || id < 1) return;
      const row = cachedDocuments.find((doc) => Number(doc.id) === id);
      const label = row?.file_name ? `"${row.file_name}"` : `#${id}`;
      if (!window.confirm(`Delete ${label}?`)) return;
      const { response: delResp, data: delBody } = await fetchApiJson(`/api/documents/${id}`, { method: "DELETE" });
      if (!delResp.ok) throw new Error(delBody.error || "Failed to delete document");
      showMessage("Document deleted.");
      await loadDocuments();
    });
  });
  listEl.querySelectorAll(".document-preview-btn").forEach((el) => {
    el.addEventListener("click", () => openDocumentPreview(Number(el.getAttribute("data-id"))));
  });
  listEl.querySelectorAll(".document-rename-btn").forEach((el) => {
    el.addEventListener("click", () => startInlineRename(Number(el.getAttribute("data-id"))));
  });
  listEl.querySelectorAll(".document-rename-form").forEach((form) => {
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      try {
        await submitInlineRename(form);
      } catch (error) {
        showMessage(error.message || "Failed to rename document.", true);
      }
    });
    form.querySelector(".document-rename-cancel")?.addEventListener("click", () => stopInlineRename(form));
  });
  listEl.querySelectorAll(".document-select").forEach((el) => {
    el.addEventListener("change", () => {
      const id = Number(el.getAttribute("data-id"));
      if (!Number.isInteger(id) || id < 1) return;
      if (el.checked) selectedDocumentIds.add(id);
      else selectedDocumentIds.delete(id);
      syncDeleteSelectedButton();
    });
  });
  listEl.querySelectorAll(".document-category-select").forEach((el) => {
    el.addEventListener("change", async () => {
      const id = Number(el.getAttribute("data-id"));
      if (!Number.isInteger(id) || id < 1) return;
      const row = cachedDocuments.find((doc) => Number(doc.id) === id);
      const current = normalizeDocumentCategory(row?.category_name);
      const nextCategory = String(el.value || "").trim() || "Uncategorized";
      if (nextCategory.toLowerCase() === current.toLowerCase()) return;
      el.disabled = true;
      try {
        const { response: patchResp, data: patchBody } = await fetchApiJson(`/api/documents/${id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ categoryName: nextCategory })
        });
        if (!patchResp.ok) throw new Error(patchBody.error || "Failed to move document");
        showMessage(`Moved to ${nextCategory}.`);
        await loadDocuments();
      } catch (error) {
        el.value = current;
        el.disabled = false;
        showMessage(error.message || "Failed to move document.", true);
      }
    });
  });
  syncDeleteSelectedButton();
}

document.getElementById("backToContactsBtn").addEventListener("click", () => {
  window.location.href = "/index.html";
});

document.getElementById("refreshDocumentsBtn").addEventListener("click", () => {
  loadDocuments().catch((e) => showMessage(e.message, true));
});

if (deleteSelectedBtn) {
  deleteSelectedBtn.addEventListener("click", async () => {
    try {
      const ids = [...selectedDocumentIds].filter((id) => Number.isInteger(id) && id > 0);
      if (!ids.length) {
        showMessage("Select at least one document first.", true);
        return;
      }
      if (!window.confirm(`Delete ${ids.length} selected document(s)?`)) return;
      let deleted = 0;
      const failed = [];
      for (const id of ids) {
        const { response: delResp, data: delBody } = await fetchApiJson(`/api/documents/${id}`, { method: "DELETE" });
        if (delResp.ok) {
          deleted += 1;
          selectedDocumentIds.delete(id);
        } else {
          failed.push(`#${id}: ${delBody.error || "Delete failed"}`);
        }
      }
      if (deleted && !failed.length) {
        showMessage(`Deleted ${deleted} document(s).`);
      } else if (deleted && failed.length) {
        showMessage(`Deleted ${deleted} document(s). ${failed.length} failed: ${failed.join("; ")}`, true);
      } else {
        showMessage(`No documents deleted: ${failed.join("; ")}`, true);
      }
      await loadDocuments();
    } catch (error) {
      showMessage(error.message, true);
    }
  });
}

if (categoryFiltersEl) {
  categoryFiltersEl.addEventListener("click", (event) => {
    const btn = event.target?.closest?.(".documents-category-btn");
    if (!btn) return;
    const value = String(btn.getAttribute("data-doc-category") || "").trim() || "ALL";
    if (selectedDocumentCategory === value) {
      selectedDocumentCategory = "NONE";
    } else {
      selectedDocumentCategory = value;
    }
    loadDocuments().catch((e) => showMessage(e.message, true));
  });
}

if (toggleEmptyCategoriesBtn) {
  toggleEmptyCategoriesBtn.addEventListener("click", () => {
    showEmptyDocumentCategories = !showEmptyDocumentCategories;
    renderCategoryFilters(cachedDocuments);
  });
}

if (categorySelect) {
  categorySelect.addEventListener("change", syncCategoryAdminControls);
}

if (addCategoryBtn) {
  addCategoryBtn.addEventListener("click", () => {
    const raw = window.prompt("New document category name:", "");
    const name = String(raw || "").trim();
    if (!name) return;
    const exists = documentCategories.some((c) => c.toLowerCase() === name.toLowerCase());
    if (exists || name.toLowerCase() === "uncategorized") {
      if (categorySelect) categorySelect.value = name.toLowerCase() === "uncategorized" ? "Uncategorized" : documentCategories.find((c) => c.toLowerCase() === name.toLowerCase()) || name;
      return;
    }
    documentCategories = [...documentCategories, name].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));
    saveCustomDocumentCategories();
    syncDocumentCategorySelect();
    if (categorySelect) categorySelect.value = name;
    syncCategoryAdminControls();
    showMessage(`Added category "${name}".`);
  });
}

if (deleteCategoryBtn) {
  deleteCategoryBtn.addEventListener("click", () => {
    openDeleteCategoryModal();
  });
}

if (deleteCategoryModalCloseBtn) {
  deleteCategoryModalCloseBtn.addEventListener("click", closeDeleteCategoryModal);
}

if (deleteCategoryModal) {
  deleteCategoryModal.addEventListener("click", (event) => {
    const target = event.target;
    if (target && target.getAttribute && target.getAttribute("data-close-delete-category-modal") === "1") {
      closeDeleteCategoryModal();
    }
  });
}

if (previewModalCloseBtn) {
  previewModalCloseBtn.addEventListener("click", closeDocumentPreviewModal);
}

if (previewModal) {
  previewModal.addEventListener("click", (event) => {
    const target = event.target;
    if (target && target.getAttribute && target.getAttribute("data-close-document-preview-modal") === "1") {
      closeDocumentPreviewModal();
    }
  });
}

if (deleteCategoryModalForm) {
  deleteCategoryModalForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const name = String(deleteCategorySelect?.value || "").trim();
    if (!name) return;
    const customCategories = getCustomDocumentCategories();
    const match = customCategories.find((c) => c.toLowerCase() === name.toLowerCase());
    if (!match) {
      showMessage("That category was not found in custom categories.", true);
      closeDeleteCategoryModal();
      return;
    }
    if (
      !window.confirm(
        `Delete category "${match}"? All documents in this category will move to Uncategorized. This cannot be undone.`
      )
    ) {
      return;
    }
    const { response: moveResp, data: moveBody } = await fetchApiJson("/api/documents/delete-category", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ categoryName: match })
    });
    if (!moveResp.ok) {
      showMessage(moveBody.error || "Failed to move documents before deleting category", true);
      return;
    }
    documentCategories = documentCategories.filter((c) => c.toLowerCase() !== match.toLowerCase());
    if (selectedDocumentCategory.toLowerCase() === match.toLowerCase()) selectedDocumentCategory = "ALL";
    saveCustomDocumentCategories();
    syncDocumentCategorySelect();
    if (categorySelect && String(categorySelect.value || "").toLowerCase() === match.toLowerCase()) {
      categorySelect.value = "Uncategorized";
    }
    closeDeleteCategoryModal();
    const movedCount = Number(moveBody.movedCount || 0);
    showMessage(
      movedCount > 0
        ? `Deleted category "${match}" and moved ${movedCount} document(s) to Uncategorized.`
        : `Deleted category "${match}".`
    );
    await loadDocuments();
  });
}

function renderUploadProgress(files, statuses = new Map()) {
  if (!uploadProgressEl) return;
  const rows = Array.from(files || []);
  uploadProgressEl.hidden = rows.length === 0;
  uploadProgressEl.innerHTML = rows
    .map((file) => {
      const status = statuses.get(file.name) || { text: "Waiting", tone: "pending" };
      return `<div class="documents-upload-progress-row documents-upload-progress-row--${escapeHtml(status.tone)}">
        <span>${escapeHtml(file.name)}</span>
        <strong>${escapeHtml(status.text)}</strong>
      </div>`;
    })
    .join("");
}

uploadForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const files = Array.from(fileInput.files || []);
    if (!files.length) {
      showMessage("Choose at least one file first.", true);
      return;
    }
    if (!String(categorySelect?.value || "").trim()) {
      showMessage("Choose a category first.", true);
      return;
    }
    const toBase64 = (file) =>
      new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          const text = String(reader.result || "");
          const idx = text.indexOf(",");
          resolve(idx >= 0 ? text.slice(idx + 1) : text);
        };
        reader.onerror = () => reject(new Error(`Failed to read ${file.name}`));
        reader.readAsDataURL(file);
      });
    const statuses = new Map();
    renderUploadProgress(files, statuses);
    const uploadOne = async (file) => {
      statuses.set(file.name, { text: "Uploading...", tone: "pending" });
      renderUploadProgress(files, statuses);
      if (file.size > MAX_DOCUMENT_BYTES) {
        statuses.set(file.name, { text: "Failed - over 15MB", tone: "error" });
        renderUploadProgress(files, statuses);
        return { ok: false, message: `${file.name}: File exceeds 15MB limit` };
      }
      try {
        const contentBase64 = await toBase64(file);
        const { response, data } = await fetchApiJson("/api/documents", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            fileName: file.name,
            mimeType: file.type || "application/octet-stream",
            categoryName: String(categorySelect?.value || "").trim(),
            contentBase64
          })
        });
        if (!response.ok) throw new Error(data.error || "Upload failed");
        statuses.set(file.name, { text: "Uploaded", tone: "ok" });
        renderUploadProgress(files, statuses);
        return { ok: true };
      } catch (uploadError) {
        statuses.set(file.name, { text: "Failed", tone: "error" });
        renderUploadProgress(files, statuses);
        return { ok: false, message: `${file.name}: ${uploadError.message || "Upload failed"}` };
      }
    };
    const results = await Promise.all(files.map(uploadOne));
    const uploaded = results.filter((result) => result.ok).length;
    const failed = results.filter((result) => !result.ok).map((result) => result.message);
    if (uploaded && !failed.length) {
      showMessage(`Uploaded ${uploaded} document(s).`);
    } else if (uploaded && failed.length) {
      showMessage(
        `Uploaded ${uploaded} document(s). ${failed.length} failed: ${failed.join("; ")}`,
        true
      );
    } else {
      showMessage(`All uploads failed: ${failed.join("; ")}`, true);
    }
    fileInput.value = "";
    await loadDocuments();
    window.setTimeout(() => {
      if (uploadProgressEl) uploadProgressEl.hidden = true;
    }, 1600);
  } catch (error) {
    showMessage(error.message, true);
  }
});

loadDocuments().catch((e) => showMessage(e.message, true));
