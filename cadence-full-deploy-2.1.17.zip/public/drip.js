const messageEl = document.getElementById("message");
const dripSetupStatus = document.getElementById("dripSetupStatus");
let campaignsById = new Map();

function showMessage(text, isError = false) {
  const str = String(text == null ? "" : text);
  if (isError && /please log in to continue/i.test(str)) {
    messageEl.textContent = "";
    const link = document.createElement("a");
    link.href = "/login.html";
    link.textContent = str;
    link.className = "login-redirect-link";
    messageEl.appendChild(link);
    messageEl.style.color = "#c62828";
    return;
  }
  messageEl.textContent = str;
  messageEl.style.color = isError ? "#c62828" : "#1b5e20";
}

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

async function fetchApiJson(pathAndQuery, init) {
  const response = await fetch(pathAndQuery, init);
  let data = {};
  try {
    data = await response.json();
  } catch {
    data = {};
  }
  return { response, data };
}

function formatUnixUtc(sec) {
  const n = Number(sec);
  if (!Number.isFinite(n)) return "";
  return new Date(n * 1000).toISOString().replace("T", " ").replace(/\.\d{3}Z$/, " UTC");
}

async function loadDripSetup() {
  try {
    const { response, data: body } = await fetchApiJson("/api/drip/setup-status");
    if (!response.ok) throw new Error(body.error || "Failed to load drip setup status");
    const smsLabel = body.sms.ready
      ? "SMS (Twilio): ready"
      : `SMS (Twilio): missing ${(body.sms.missing || []).join(", ") || "env vars"}`;
    const emailLabel = body.email.ready
      ? "Email (SMTP): ready"
      : `Email (SMTP): missing ${(body.email.missing || []).join(", ") || "env vars"}`;
    dripSetupStatus.innerHTML = `
      <span class="pill ${body.sms.ready ? "ok" : "bad"}">${smsLabel}</span>
      <span class="pill ${body.email.ready ? "ok" : "bad"}">${emailLabel}</span>
    `;
  } catch (error) {
    dripSetupStatus.textContent = error.message;
  }
}

async function loadDripCampaignOptions() {
  const sel = document.getElementById("dripCampaignSelect");
  const previous = sel.value;
  const { response, data: list } = await fetchApiJson("/api/drip/campaigns");
  if (!response.ok) throw new Error(list.error || "Failed to load campaigns");
  const campaigns = Array.isArray(list) ? list : [];
  campaignsById = new Map(campaigns.map((campaign) => [Number(campaign.id), campaign]));
  sel.innerHTML = '<option value="">Select a campaign…</option>';
  for (const c of campaigns) {
    const opt = document.createElement("option");
    opt.value = String(c.id);
    const stepCount = Array.isArray(c.steps) ? c.steps.length : 0;
    opt.textContent = `${c.name} (${stepCount} steps)`;
    sel.appendChild(opt);
  }
  if (previous && [...sel.options].some((o) => o.value === previous)) {
    sel.value = previous;
  }
  return campaigns;
}

function capitalize(value) {
  const text = String(value || "").trim().toLowerCase();
  if (!text) return "";
  return text.charAt(0).toUpperCase() + text.slice(1);
}

function summarizeCampaignRows(rows) {
  const summary = {
    total: rows.length,
    sent: 0,
    pending: 0,
    failed: 0,
    skipped: 0,
    latest: 0
  };
  for (const row of rows) {
    const status = String(row.status || "").toLowerCase();
    if (status === "sent") summary.sent += 1;
    else if (status === "pending") summary.pending += 1;
    else if (status === "failed") summary.failed += 1;
    else if (status === "skipped") summary.skipped += 1;
    const stamp = Number(row.scheduled_at);
    if (Number.isFinite(stamp) && stamp > summary.latest) summary.latest = stamp;
  }
  return summary;
}

function dripProblemListHtml(rows) {
  const problems = rows.filter((row) => {
    const status = String(row.status || "").toLowerCase();
    return status === "failed" || status === "skipped";
  });
  if (!problems.length) return "";
  return `<ul class="drip-problem-list">${problems
    .map((row) => {
      const status = String(row.status || "").toLowerCase();
      const contactId = Number(row.contact_id) || 0;
      const name = escapeHtml(row.full_name || "Unknown");
      const nameHtml =
        contactId > 0 ? `<a href="/contact.html?id=${encodeURIComponent(contactId)}">${name}</a>` : name;
      const stepOrder = Number(row.step_order);
      const stepLabel = Number.isFinite(stepOrder) ? `Step ${stepOrder + 1}` : "Step";
      const err = String(row.error_message || "").trim();
      const label = status === "failed" ? "Failed" : "Skipped";
      return `<li><strong>${label}</strong> · ${nameHtml} · ${escapeHtml(capitalize(row.channel))} · ${escapeHtml(
        stepLabel
      )}${err ? ` · ${escapeHtml(err)}` : ""}</li>`;
    })
    .join("")}</ul>`;
}

function paintDripStatColors(root) {
  const colors = {
    "pending sms": "#2563eb",
    pending: "#2563eb",
    "sent successful": "#16a34a",
    failed: "#7c3aed",
  };
  const scope = root && typeof root.querySelectorAll === "function" ? root : document;
  scope.querySelectorAll(".drip-metric-card, .drip-campaign-stat").forEach((node) => {
    const labelEl = node.querySelector("span");
    const label = String(labelEl ? labelEl.textContent : "").trim().toLowerCase();
    const color = colors[label];
    if (color) node.style.setProperty("background", color, "important");
  });
}

function renderCampaignBlocks(items, runningCampaignCountByContact = new Map(), campaignSummaries = null) {
  const host = document.getElementById("dripCampaignBlocks");
  if (!host) return;
  const summaryById = new Map(
    (Array.isArray(campaignSummaries) ? campaignSummaries : []).map((row) => [Number(row.campaignId) || 0, row])
  );
  if (!items.length && !summaryById.size) {
    host.innerHTML = '<div class="contact-history-empty">No drip activity yet.</div>';
    return;
  }
  const grouped = new Map();
  for (const row of items) {
    const key = Number(row.campaign_id) || 0;
    if (!grouped.has(key)) grouped.set(key, []);
    grouped.get(key).push(row);
  }
  for (const campaignId of summaryById.keys()) {
    if (!grouped.has(campaignId)) grouped.set(campaignId, []);
  }
  const groups = [...grouped.entries()]
    .map(([campaignId, rows]) => {
      const counted = summaryById.get(campaignId);
      const fromRows = summarizeCampaignRows(rows);
      const summary = counted
        ? {
            total: Number(counted.contacts || 0),
            sent: Number(counted.sent || 0),
            pending: Number(counted.pending || 0),
            failed: Number(counted.failed || 0),
            skipped: Number(counted.skipped || 0),
            latest: Number(counted.latest || fromRows.latest || 0),
            totalLabel: "Contacts"
          }
        : { ...fromRows, totalLabel: "Total" };
      return { campaignId, rows, summary };
    })
    .sort((a, b) => b.summary.latest - a.summary.latest);

  host.innerHTML = groups
    .map(({ campaignId, rows, summary }) => {
      const campaign = campaignsById.get(campaignId);
      const campaignName = escapeHtml((campaign && campaign.name) || "Campaign");
      const activeBadge = summary.failed > 0 ? "Needs attention" : summary.pending > 0 ? "Active" : "Healthy";
      const badgeClass =
        summary.failed > 0 ? "drip-campaign-badge drip-campaign-badge--attention" : "drip-campaign-badge";
      const latestText = summary.latest ? formatUnixUtc(summary.latest) : "No schedule time";
      const rankedRows = [...rows].sort((a, b) => {
        const rank = (row) => {
          const status = String(row.status || "").toLowerCase();
          if (status === "failed") return 0;
          if (status === "skipped") return 1;
          if (status === "pending") return 2;
          return 3;
        };
        return rank(a) - rank(b);
      });
      const topContactsHtml = rankedRows
        .slice(0, 3)
        .map((row) => {
          const contactId = Number(row.contact_id) || 0;
          const running = Number(runningCampaignCountByContact.get(contactId) || 0);
          const runLabel = `${running} running campaign${running === 1 ? "" : "s"}`;
          const contactRows = rows.filter((r) => Number(r.contact_id) === contactId);
          const pendingSteps = contactRows.filter((r) => String(r.status || "").toLowerCase() === "pending").length;
          const failedSteps = contactRows.filter((r) => String(r.status || "").toLowerCase() === "failed").length;
          let enrolledBadge = "";
          if (contactRows.length > 0) {
            enrolledBadge =
              failedSteps > 0
                ? '<span class="drip-enrolled-badge drip-enrolled-badge--failed">Failed</span>'
                : pendingSteps > 0
                  ? '<span class="drip-enrolled-badge drip-enrolled-badge--live">Enrolled Live</span>'
                  : '<span class="drip-enrolled-badge drip-enrolled-badge--completed">Completed</span>';
          } else if (running > 0) {
            enrolledBadge = '<span class="drip-enrolled-badge drip-enrolled-badge--live">Enrolled Live</span>';
          }
          return `<span class="drip-contact-chip">${escapeHtml(row.full_name || "Unknown")} (${escapeHtml(
            capitalize(row.channel)
          )} · ${escapeHtml(runLabel)}) ${enrolledBadge}</span>`;
        })
        .join("");
      return `
        <article class="drip-campaign-block">
          <div class="drip-campaign-head">
            <div>
              <h4>${campaignName}</h4>
              <p>Latest schedule: ${latestText}</p>
            </div>
            <span class="${badgeClass}">${activeBadge}</span>
          </div>
          ${
            summary.failed > 0
              ? `<p class="drip-attention-note">Needs attention means a message in this campaign did not send.</p>`
              : ""
          }
          <div class="drip-campaign-stat-grid">
            <div class="drip-campaign-stat drip-campaign-stat--dark"><span>${escapeHtml(summary.totalLabel || "Contacts")}</span><strong>${summary.total}</strong></div>
            <div class="drip-campaign-stat drip-campaign-stat--sent" style="background:#16a34a"><span>Sent Successful</span><strong>${summary.sent}</strong></div>
            <div class="drip-campaign-stat drip-campaign-stat--pending" style="background:#2563eb"><span>Pending</span><strong>${summary.pending}</strong></div>
            <div class="drip-campaign-stat drip-campaign-stat--failed" style="background:#7c3aed"><span>Failed</span><strong>${summary.failed}</strong></div>
          </div>
          ${dripProblemListHtml(rows)}
          <p class="drip-campaign-footnote">${
            topContactsHtml || '<span class="drip-contact-chip">No contact details available yet.</span>'
          }</p>
        </article>
      `;
    })
    .join("");
}

async function loadDripQueue() {
  const metricCampaigns = document.getElementById("dripMetricCampaigns");
  const metricPending = document.getElementById("dripMetricPending");
  const metricSent = document.getElementById("dripMetricSent");
  const metricFailed = document.getElementById("dripMetricFailed");
  const { response, data: payload } = await fetchApiJson("/api/drip/queue?summary=1&limit=80");
  if (!response.ok) throw new Error(payload.error || "Failed to load queue");
  const items = Array.isArray(payload) ? payload : Array.isArray(payload?.rows) ? payload.rows : [];
  const campaignSummaries = Array.isArray(payload?.campaigns) ? payload.campaigns : null;
  const queueTotals = payload && payload.totals && typeof payload.totals === "object" ? payload.totals : null;
  const activeRows = items.filter((row) => String(row.status || "").toLowerCase() === "pending");
  const runningCampaignIdsByContact = new Map();
  for (const row of activeRows) {
    const contactId = Number(row.contact_id);
    const campaignId = Number(row.campaign_id);
    if (!Number.isInteger(contactId) || contactId < 1 || !Number.isInteger(campaignId) || campaignId < 1) continue;
    if (!runningCampaignIdsByContact.has(contactId)) runningCampaignIdsByContact.set(contactId, new Set());
    runningCampaignIdsByContact.get(contactId).add(campaignId);
  }
  const runningCampaignCountByContact = new Map(
    [...runningCampaignIdsByContact.entries()].map(([contactId, campaignIds]) => [contactId, campaignIds.size])
  );
  const runningCampaignsTotal = queueTotals
    ? Number(queueTotals.campaigns || 0)
    : [...runningCampaignCountByContact.values()].reduce((sum, n) => sum + Number(n || 0), 0);
  const pendingCount = queueTotals
    ? Number(queueTotals.pending || 0)
    : items.filter((row) => String(row.status || "").toLowerCase() === "pending").length;
  const sentCount = queueTotals
    ? Number(queueTotals.sent || 0)
    : items.filter((row) => String(row.status || "").toLowerCase() === "sent").length;
  const failedCount = queueTotals
    ? Number(queueTotals.failed || 0)
    : items.filter((row) => String(row.status || "").toLowerCase() === "failed").length;
  if (metricCampaigns) metricCampaigns.textContent = String(runningCampaignsTotal);
  if (metricPending) metricPending.textContent = String(pendingCount);
  if (metricSent) metricSent.textContent = String(sentCount);
  if (metricFailed) metricFailed.textContent = String(failedCount);
  renderCampaignBlocks(items, runningCampaignCountByContact, campaignSummaries);
  paintDripStatColors(document);
}

document.getElementById("backToContactsBtn").addEventListener("click", () => {
  window.location.href = "/";
});

document.getElementById("refreshDripSetupBtn").addEventListener("click", () => {
  loadDripSetup().catch((e) => showMessage(e.message, true));
});

document.getElementById("refreshDripQueueBtn").addEventListener("click", () => {
  Promise.resolve()
    .then(() => loadDripCampaignOptions())
    .then(() => loadDripQueue())
    .catch((e) => showMessage(e.message, true));
});

document.getElementById("dripCreateForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const formData = new FormData(event.target);
  const tag = String(formData.get("tag") || "").trim();
  const description = String(formData.get("description") || "").trim();
  if (!tag) {
    showMessage("Tag is required.", true);
    return;
  }
  if (!description) {
    showMessage("Campaign description is required.", true);
    return;
  }
  try {
    const steps = [
      {
        offset_hours: 0,
        channel: "sms",
        body: "New campaign draft step. Update this in AI Campaign Builder."
      }
    ];
    const { response, data: body } = await fetchApiJson("/api/drip/campaigns", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: description,
        description,
        schedule_mode: "on_tag",
        tag_rules: [{ tag, function: "enroll" }],
        steps
      })
    });
    if (!response.ok) throw new Error(body.error || "Failed to create campaign");
    showMessage("Campaign Saved. Opening AI Campaign Builder...");
    const campaignId = Number(body && body.id);
    if (Number.isInteger(campaignId) && campaignId > 0) {
      window.location.href = `/campaigns.html?editCampaignId=${encodeURIComponent(String(campaignId))}`;
      return;
    }
    await loadDripCampaignOptions();
  } catch (error) {
    showMessage(error.message, true);
  }
});

document.getElementById("dripEnrollForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const formData = new FormData(event.target);
  const campaignId = Number(formData.get("campaignId"));
  const contactName = String(formData.get("contactName") || "").trim();
  if (!contactName) {
    showMessage("Contact name is required.", true);
    return;
  }
  try {
    const { response: contactResp, data: contactBody } = await fetchApiJson(
      `/api/contacts?q=${encodeURIComponent(contactName)}&page=1&limit=25`
    );
    if (!contactResp.ok) throw new Error(contactBody.error || "Failed to look up contact");
    const rows = Array.isArray(contactBody?.items) ? contactBody.items : Array.isArray(contactBody) ? contactBody : [];
    if (!rows.length) {
      showMessage(`No contact found for "${contactName}".`, true);
      return;
    }
    const exact = rows.find(
      (row) => String(row.full_name || "").trim().toLowerCase() === contactName.toLowerCase()
    );
    const picked = exact || rows[0];
    const contactId = Number(picked && picked.id);
    if (!Number.isInteger(contactId) || contactId < 1) {
      showMessage("Could not resolve contact from that name.", true);
      return;
    }

    const { response, data: body } = await fetchApiJson("/api/drip/enroll", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ campaignId, contactId })
    });
    if (!response.ok) throw new Error(body.error || "Failed to enroll contact");
    showMessage(`Saved: ${picked.full_name || "Contact"} enrolled in campaign (${body.scheduledSteps} scheduled sends).`);
    event.target.reset();
    await loadDripQueue();
  } catch (error) {
    showMessage(error.message, true);
  }
});

Promise.resolve()
  .then(() => loadDripSetup())
  .then(() => loadDripCampaignOptions())
  .then(() => loadDripQueue())
  .catch((e) => showMessage(e.message, true));
