(function () {
  const heading = document.getElementById("billingHeading");
  const lead = document.getElementById("billingLead");
  const note = document.getElementById("billingNote");
  const msg = document.getElementById("billingMessage");
  const btn = document.getElementById("subscribeBtn");
  const portalBtn = document.getElementById("manageBillingBtn");
  const goCrmBtn = document.getElementById("goCrmBtn");

  const params = new URLSearchParams(window.location.search);
  const checkoutStatus = params.get("status");
  const nextPath = (() => {
    const n = String(params.get("next") || "/").trim();
    if (!n.startsWith("/") || n.startsWith("//")) return "/";
    return n;
  })();

  function setMsg(text, isError) {
    if (!msg) return;
    msg.textContent = text || "";
    msg.classList.remove("signup-message--error", "signup-message--ok");
    if (text) msg.classList.add(isError ? "signup-message--error" : "signup-message--ok");
  }

  async function loadStatus() {
    const res = await fetch("/api/billing/status", { credentials: "same-origin" });
    if (res.status === 401) {
      window.location.href = "/login.html?next=" + encodeURIComponent("/billing.html");
      return null;
    }
    return res.json().catch(() => ({}));
  }

  async function refreshUi() {
    const data = await loadStatus();
    if (!data) return;

    if (data.legacy) {
      if (heading) heading.textContent = "Primary workspace";
      if (lead) lead.textContent = "This account does not require a trial subscription.";
      if (btn) btn.style.display = "none";
      if (portalBtn) portalBtn.style.display = "none";
      return;
    }

    const end = data.trialEndsAt
      ? new Date(data.trialEndsAt).toLocaleDateString(undefined, { month: "long", day: "numeric", year: "numeric" })
      : "";

    if (data.status === "active") {
      if (heading) heading.textContent = "You're subscribed";
      if (lead) {
        lead.textContent =
          "Cadence Pro is active for " + (data.agencyName || "your workspace") + ". Open the CRM to continue.";
      }
      if (btn) btn.style.display = "none";
      if (goCrmBtn) {
        goCrmBtn.style.display = "";
        goCrmBtn.href = nextPath;
      }
      if (note) note.textContent = "Manage your card or cancel anytime in the Stripe customer portal.";
      if (portalBtn && data.stripeConfigured) {
        portalBtn.style.display = "";
        portalBtn.disabled = false;
        portalBtn.onclick = openPortal;
      }
      return;
    }

    if (heading) heading.textContent = data.needsPayment ? "Trial ended" : "Cadence Pro";
    if (lead) {
      lead.textContent = data.needsPayment
        ? "Your 14-day trial has ended. Subscribe for $" +
          (data.monthlyPrice || 79) +
          "/month to keep using your workspace."
        : "Your trial runs through " + end + " (" + (data.daysLeft || "—") + " days left). You can subscribe early anytime.";
    }
    if (goCrmBtn) goCrmBtn.style.display = data.needsPayment ? "none" : "";
    if (portalBtn) portalBtn.style.display = "none";

    if (!data.stripeConfigured) {
      setMsg(
        "Online checkout is not configured on this server yet. Contact support@crmcadence.com to activate your account.",
        true
      );
      if (btn) btn.disabled = true;
      return;
    }

    if (btn) {
      btn.style.display = "";
      btn.disabled = false;
      btn.textContent = "Subscribe with card";
      btn.onclick = startCheckout;
    }
    if (note) {
      note.textContent =
        "Secure payment by Stripe. After checkout you'll return here, then we unlock your CRM automatically.";
    }
  }

  async function startCheckout() {
    if (btn) {
      btn.disabled = true;
      btn.textContent = "Redirecting…";
    }
    setMsg("");
    try {
      const res = await fetch("/api/billing/create-checkout-session", {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: "{}"
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Could not start checkout.");
      if (data.url) {
        window.location.href = data.url;
        return;
      }
      throw new Error("No checkout URL returned.");
    } catch (err) {
      setMsg(err.message || "Checkout failed.", true);
      if (btn) {
        btn.disabled = false;
        btn.textContent = "Subscribe with card";
      }
    }
  }

  async function openPortal() {
    if (portalBtn) {
      portalBtn.disabled = true;
      portalBtn.textContent = "Opening…";
    }
    setMsg("");
    try {
      const res = await fetch("/api/billing/portal", {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: "{}"
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Could not open billing portal.");
      if (data.url) {
        window.location.href = data.url;
        return;
      }
      throw new Error("No portal URL returned.");
    } catch (err) {
      setMsg(err.message || "Portal failed.", true);
      if (portalBtn) {
        portalBtn.disabled = false;
        portalBtn.textContent = "Manage subscription";
      }
    }
  }

  async function pollUntilActive(maxAttempts) {
    for (let i = 0; i < maxAttempts; i += 1) {
      await new Promise((r) => setTimeout(r, 2000));
      const data = await loadStatus();
      if (data && data.status === "active") {
        setMsg("Subscription active — opening your CRM…", false);
        window.location.href = nextPath;
        return;
      }
    }
    setMsg(
      "Payment received. If the CRM is still locked, wait a minute and refresh, or contact support.",
      false
    );
    await refreshUi();
  }

  if (checkoutStatus === "success") {
    setMsg("Payment received — activating your account…", false);
    pollUntilActive(15);
  } else if (checkoutStatus === "cancelled") {
    setMsg("Checkout cancelled. You can try again when ready.", true);
    refreshUi();
  } else {
    refreshUi();
  }
})();
