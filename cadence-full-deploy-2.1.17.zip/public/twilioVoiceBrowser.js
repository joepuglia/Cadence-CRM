(function () {
  let device = null;
  let activeCall = null;
  let registerPromise = null;
  let lastDeviceError = null;
  let lastCallError = null;
  let micPermissionStream = null;
  let onVolumeHook = null;
  let audioUnlockCtx = null;
  let micReleaseTimer = null;
  let micReleaseGeneration = 0;
  const MIC_DEVICE_STORAGE_KEY = "crm.twilioVoice.preferredInputDeviceId";
  const USE_HEADSET_STORAGE_KEY = "crm.twilioVoice.useHeadset.v2";
  const REST_PROVIDER_STORAGE_KEY = "crm.voice.restProvider";
  const VOICE_AUDIO_CONSTRAINTS = {
    echoCancellation: true,
    noiseSuppression: true,
    autoGainControl: true
  };
  const CONNECT_STUCK_MESSAGE =
    "Call is stuck on Starting — Twilio never reached the voice webhook, so the phone did not ring. Uncheck “Use headset / this computer” to place the call now. For computer audio, set CRM Public URL in Settings → Runtime to your live HTTPS site (not localhost), then re-save Twilio credentials.";

  function withTimeout(promise, ms, message) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error(message)), ms);
      Promise.resolve(promise).then(
        (value) => {
          clearTimeout(timer);
          resolve(value);
        },
        (err) => {
          clearTimeout(timer);
          reject(err);
        }
      );
    });
  }

  function showIncomingRejectDebug() {
    let box = document.getElementById("crmTwilioIncomingRejectDebug");
    if (!box) {
      box = document.createElement("div");
      box.id = "crmTwilioIncomingRejectDebug";
      box.style.position = "fixed";
      box.style.left = "16px";
      box.style.bottom = "16px";
      box.style.zIndex = "10000";
      box.style.background = "rgba(15,23,42,0.92)";
      box.style.color = "#e2e8f0";
      box.style.border = "1px solid rgba(148,163,184,0.45)";
      box.style.borderRadius = "8px";
      box.style.padding = "8px 10px";
      box.style.font = "600 12px/1.3 system-ui,Segoe UI,Arial,sans-serif";
      box.style.pointerEvents = "none";
      document.body.appendChild(box);
    }
    const now = new Date().toLocaleTimeString();
    box.textContent = `Incoming browser invite auto-rejected (${now})`;
    box.style.opacity = "1";
    window.clearTimeout(showIncomingRejectDebug._hideTimer);
    showIncomingRejectDebug._hideTimer = window.setTimeout(() => {
      box.style.transition = "opacity 180ms ease";
      box.style.opacity = "0";
    }, 3000);
  }

  function getTwilio() {
    if (typeof Twilio === "undefined" || !Twilio.Device) {
      throw new Error("Twilio Voice SDK failed to load.");
    }
    return Twilio;
  }

  function normalizePhoneForTwilio(raw) {
    let t = String(raw || "")
      .trim()
      .replace(/[^\d+]/g, "");
    if (t.startsWith("++")) return "";
    if (!t.startsWith("+") && t.length === 10) t = "+1" + t;
    if (!t.startsWith("+") && t.length === 11 && t.startsWith("1")) t = "+" + t;
    if (!t.startsWith("+") && t.length >= 8 && t.length <= 15) t = "+" + t;
    return t;
  }

  async function fetchToken() {
    const r = await fetch("/api/twilio/voice-token", { method: "POST", credentials: "include" });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) {
      const detail = data.missingEnv && data.missingEnv.length ? ` Missing: ${data.missingEnv.join(", ")}.` : "";
      const hint = data.hint && String(data.hint).trim() ? ` — ${String(data.hint).trim()}` : "";
      throw new Error((data.error || "Voice token request failed") + detail + hint);
    }
    return data.token;
  }

  async function listInputDevices(options = {}) {
    const forcePrompt = Boolean(options && options.forcePrompt);
    if (!navigator.mediaDevices || typeof navigator.mediaDevices.enumerateDevices !== "function") return [];
    let list = await navigator.mediaDevices.enumerateDevices();
    let inputs = list.filter((x) => x.kind === "audioinput");
    const hasLabels = inputs.some((x) => String(x.label || "").trim());
    let activeTrackLabel = "";
    let activeTrackDeviceId = "";
    if ((forcePrompt || !hasLabels) && navigator.mediaDevices.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        const track = stream?.getAudioTracks?.()[0] || null;
        if (track) {
          activeTrackLabel = String(track.label || "").trim();
          try {
            const settings = typeof track.getSettings === "function" ? track.getSettings() : {};
            activeTrackDeviceId = String(settings?.deviceId || "").trim();
          } catch {
            // ignore settings read failures
          }
        }
        if (stream && typeof stream.getTracks === "function") {
          for (const track of stream.getTracks()) {
            try {
              track.stop();
            } catch {
              // ignore
            }
          }
        }
        list = await navigator.mediaDevices.enumerateDevices();
        inputs = list.filter((x) => x.kind === "audioinput");
      } catch {
        // ignore; return unlabeled list if permission denied
      }
    }
    const mapped = inputs.map((x) => ({
      deviceId: String(x.deviceId || ""),
      label: String(x.label || "").trim() || "Microphone"
    }));
    const hasActiveNamed = mapped.some((x) => x.label.toLowerCase().includes("jabra"));
    if (activeTrackLabel && !hasActiveNamed) {
      const normalized = activeTrackLabel.toLowerCase();
      const existingByLabel = mapped.some((x) => x.label.toLowerCase() === normalized);
      if (!existingByLabel) {
        mapped.unshift({
          deviceId: activeTrackDeviceId || "default",
          label: activeTrackLabel
        });
      }
    }
    return mapped;
  }

  function getPreferredInputDeviceId() {
    try {
      return String(window.localStorage.getItem(MIC_DEVICE_STORAGE_KEY) || "").trim();
    } catch {
      return "";
    }
  }

  function getUseHeadsetPreference(defaultValue = true) {
    try {
      const raw = window.localStorage.getItem(USE_HEADSET_STORAGE_KEY);
      if (raw === "0") return false;
      if (raw === "1") return true;
    } catch {
      // ignore
    }
    return defaultValue;
  }

  function setUseHeadsetPreference(on) {
    try {
      window.localStorage.setItem(USE_HEADSET_STORAGE_KEY, on ? "1" : "0");
    } catch {
      // ignore
    }
  }

  function buildHeadsetUiState(cfg) {
    const c = cfg && typeof cfg === "object" ? cfg : {};
    const ready = !!(c.browserCallReady || c.voiceApiCredentialsValid);
    const missing = Array.isArray(c.missingEnv) ? c.missingEnv.join(", ") : "";
    const webhookNote =
      ready && c.voiceWebhookUrl
        ? c.voiceWebhookSynced
          ? ""
          : ` TwiML app voice URL should be ${c.voiceWebhookUrl}.`
        : "";
    const webhookHint =
      !ready && c.voiceWebhookTestHint ? ` ${c.voiceWebhookTestHint}` : "";
    const apiHint = !ready && c.voiceApiCredentialsError ? ` ${c.voiceApiCredentialsError}` : "";
    const hint = ready
      ? `Talk and listen on this computer (headset, mic, or speakers). Keep this checked and allow the microphone when prompted.${webhookNote}`
      : `Computer audio is not set up yet. In Settings → Twilio add ${missing || "API Key, API Secret, and Voice TwiML App"}, set CRM Public URL in Settings → Runtime, then save Twilio again.${webhookHint}${apiHint} ${c.hint || ""}`.trim();
    const statusMessage = ready
      ? "Headset / computer audio is ready. Keep the box checked to talk on this call."
      : hint;
    return { ready, hint, statusMessage };
  }

  function applyHeadsetUi(options = {}) {
    const cfg = options.cfg && typeof options.cfg === "object" ? options.cfg : {};
    const state = buildHeadsetUiState(cfg);
    const checkboxes = Array.isArray(options.checkboxes)
      ? options.checkboxes.filter(Boolean)
      : options.checkbox
        ? [options.checkbox]
        : [];
    const hintEls = Array.isArray(options.hintElements)
      ? options.hintElements.filter(Boolean)
      : options.hintEl
        ? [options.hintEl]
        : [];
    for (const el of checkboxes) {
      el.disabled = false;
      el.checked = getUseHeadsetPreference(true);
      el.title = state.hint;
      const label = el.closest("label");
      if (label) {
        label.classList.remove("twilio-headset-opt--disabled");
        label.classList.toggle("twilio-headset-opt--ready", state.ready);
        label.style.pointerEvents = "auto";
        label.style.opacity = "1";
        label.style.cursor = "pointer";
      }
    }
    for (const hintEl of hintEls) {
      hintEl.textContent = state.statusMessage;
      hintEl.classList.toggle("is-ready", state.ready);
      hintEl.classList.toggle("is-blocked", !state.ready);
    }
    return state;
  }

  function applyRestProviderUi(options = {}) {
    const cfg = options.cfg && typeof options.cfg === "object" ? options.cfg : {};
    const signalwireReady = !!cfg.signalwireReady;
    const twilioRestReady = cfg.twilioRestReady !== false;
    const showChooser = false;
    const selects = Array.isArray(options.selects)
      ? options.selects.filter(Boolean)
      : options.select
        ? [options.select]
        : [];
    const boxes = Array.isArray(options.boxes)
      ? options.boxes.filter(Boolean)
      : options.box
        ? [options.box]
        : [];
    let preferred = String(cfg.voiceProvider || "signalwire").toLowerCase() === "twilio" ? "twilio" : "signalwire";
    try {
      const stored = window.localStorage.getItem(REST_PROVIDER_STORAGE_KEY);
      if (stored === "twilio" || stored === "signalwire") preferred = stored;
    } catch {
      // ignore
    }
    if (!signalwireReady) preferred = "twilio";
    else if (!twilioRestReady) preferred = "signalwire";
    for (const box of boxes) {
      if (showChooser) box.removeAttribute("hidden");
      else box.setAttribute("hidden", "");
    }
    for (const el of selects) {
      el.disabled = !showChooser;
      if (showChooser) el.value = preferred;
      if (el.dataset.crmRestProviderBound) continue;
      el.dataset.crmRestProviderBound = "1";
      el.addEventListener("change", () => {
        const v = String(el.value || "").trim().toLowerCase();
        if (v !== "twilio" && v !== "signalwire") return;
        try {
          window.localStorage.setItem(REST_PROVIDER_STORAGE_KEY, v);
        } catch {
          // ignore
        }
      });
    }
    return { showChooser, preferred, signalwireReady, twilioRestReady };
  }

  function setPreferredInputDeviceId(deviceId) {
    const id = String(deviceId || "").trim();
    try {
      if (!id || id === "default") {
        window.localStorage.removeItem(MIC_DEVICE_STORAGE_KEY);
      } else {
        window.localStorage.setItem(MIC_DEVICE_STORAGE_KEY, id);
      }
    } catch {
      // ignore storage errors
    }
  }

  function stopMediaStreamTracks(stream) {
    if (!stream || typeof stream.getTracks !== "function") return;
    for (const track of stream.getTracks()) {
      try {
        track.stop();
      } catch {
        /* ignore */
      }
    }
  }

  function releaseMicPermissionStream() {
    stopMediaStreamTracks(micPermissionStream);
    micPermissionStream = null;
  }

  function stopActiveCallMediaTracks(call) {
    if (!call) return;
    stopMediaStreamTracks(call.mediaStream);
    if (typeof call.getLocalStream === "function") {
      try {
        stopMediaStreamTracks(call.getLocalStream());
      } catch {
        /* ignore */
      }
    }
    if (typeof call.getRemoteStream === "function") {
      try {
        stopMediaStreamTracks(call.getRemoteStream());
      } catch {
        /* ignore */
      }
    }
  }

  function stopKnownAudioStreams(audio) {
    if (!audio) return;
    const candidates = [
      audio.inputStream,
      audio._inputStream,
      audio._stream,
      audio.processedStream,
      audio._processedStream
    ];
    for (const stream of candidates) {
      stopMediaStreamTracks(stream);
    }
  }

  /**
   * Twilio keeps the mic open after hangup via setInputDevice — that is what
   * leaves Chrome/Windows showing the red "on a call" / mic-in-use indicator.
   * Await unset, stop leftover tracks, then destroy the Device so nothing holds the mic.
   */
  async function releaseDeviceMic() {
    const d = device;
    if (!d?.audio) return;
    try {
      if (typeof d.audio.unsetInputDevice === "function") {
        await d.audio.unsetInputDevice();
      }
    } catch {
      /* ignore */
    }
    stopKnownAudioStreams(d.audio);
  }

  function destroyVoiceDevice() {
    const d = device;
    device = null;
    registerPromise = null;
    if (!d) return;
    try {
      if (typeof d.disconnectAll === "function") d.disconnectAll();
    } catch {
      /* ignore */
    }
    try {
      if (d.audio && typeof d.audio.unsetInputDevice === "function") {
        const unset = d.audio.unsetInputDevice();
        if (unset && typeof unset.then === "function") unset.catch(() => {});
      }
    } catch {
      /* ignore */
    }
    stopKnownAudioStreams(d.audio);
    try {
      if (typeof d.destroy === "function") d.destroy();
    } catch {
      /* ignore */
    }
  }

  function scheduleMicReleasePass() {
    // Second pass: some Twilio builds reopen/hold tracks briefly after disconnect.
    // Cancel any pending pass when a new call starts (see connectCall).
    if (micReleaseTimer) {
      window.clearTimeout(micReleaseTimer);
      micReleaseTimer = null;
    }
    const generation = ++micReleaseGeneration;
    micReleaseTimer = window.setTimeout(() => {
      micReleaseTimer = null;
      if (generation !== micReleaseGeneration) return;
      if (activeCall) return;
      releaseDeviceMic()
        .catch(() => {})
        .finally(() => {
          if (generation !== micReleaseGeneration) return;
          if (!activeCall) destroyVoiceDevice();
        });
    }, 250);
  }

  function cancelScheduledMicRelease() {
    micReleaseGeneration += 1;
    if (micReleaseTimer) {
      window.clearTimeout(micReleaseTimer);
      micReleaseTimer = null;
    }
  }

  async function resolveMicDeviceId() {
    const preferred = getPreferredInputDeviceId();
    if (preferred) {
      try {
        const list = await navigator.mediaDevices.enumerateDevices();
        const inputs = list.filter((entry) => entry.kind === "audioinput");
        if (inputs.some((entry) => entry.deviceId === preferred)) return preferred;
      } catch {
        /* ignore */
      }
    }
    return "default";
  }

  // Play through this computer's current Windows/Chrome default output
  // (speakers, headset, or whatever the user selected in the OS). Guessing a
  // Bluetooth "headset" device often routes audio to a disconnected sink.
  async function resolveOutputDeviceId() {
    return "default";
  }

  function ensureRemoteAudioEl() {
    let el = document.getElementById("crm-twilio-remote-audio");
    if (el) return el;
    el = document.createElement("audio");
    el.id = "crm-twilio-remote-audio";
    el.autoplay = true;
    el.setAttribute("playsinline", "");
    el.setAttribute("webkit-playsinline", "");
    el.controls = false;
    el.muted = false;
    el.volume = 1;
    el.style.cssText = "position:fixed;left:0;bottom:0;width:1px;height:1px;opacity:0.01;pointer-events:none;z-index:1";
    document.body.appendChild(el);
    return el;
  }

  async function attachRemoteAudio(call) {
    const el = ensureRemoteAudioEl();
    el.muted = false;
    el.volume = 1;
    let stream = null;
    try {
      if (call && typeof call.getRemoteStream === "function") stream = call.getRemoteStream();
    } catch {
      stream = null;
    }
    if (stream && el.srcObject !== stream) el.srcObject = stream;
    try {
      const outId = await resolveOutputDeviceId();
      if (outId && outId !== "default" && typeof el.setSinkId === "function") {
        await el.setSinkId(outId);
      }
    } catch {
      /* keep browser default output */
    }
    try {
      await el.play();
    } catch {
      /* autoplay may wait for the original click; unlockAudioPlayback already ran */
    }
  }

  function detachRemoteAudio() {
    const el = document.getElementById("crm-twilio-remote-audio");
    if (!el) return;
    try {
      el.pause();
    } catch {
      /* ignore */
    }
    el.srcObject = null;
  }

  async function listOutputDevices() {
    if (!navigator.mediaDevices || typeof navigator.mediaDevices.enumerateDevices !== "function") return [];
    const list = await navigator.mediaDevices.enumerateDevices();
    return list
      .filter((entry) => entry.kind === "audiooutput")
      .map((entry) => ({ deviceId: String(entry.deviceId || ""), label: String(entry.label || "").trim() || "Speaker" }));
  }

  // Resume an AudioContext during the user's click so the browser's autoplay
  // policy doesn't silently mute the remote call audio.
  function unlockAudioPlayback() {
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      if (!audioUnlockCtx) audioUnlockCtx = new Ctx();
      if (audioUnlockCtx.state === "suspended") audioUnlockCtx.resume().catch(() => {});
    } catch {
      /* ignore */
    }
  }

  let ringbackNodes = null;
  let ringbackCadenceTimer = null;
  let ringbackSafetyTimer = null;
  let fourToneNodes = null;
  let fourToneDoneTimer = null;
  let callProgressAnswered = false;

  function getCallAudioContext() {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return null;
    if (!audioUnlockCtx || audioUnlockCtx.state === "closed") audioUnlockCtx = new Ctx();
    if (audioUnlockCtx.state === "suspended") audioUnlockCtx.resume().catch(() => {});
    return audioUnlockCtx;
  }

  function stopFourToneCue() {
    if (fourToneDoneTimer) {
      clearTimeout(fourToneDoneTimer);
      fourToneDoneTimer = null;
    }
    if (!fourToneNodes) return;
    try {
      fourToneNodes.gain.gain.value = 0;
    } catch {
      /* ignore */
    }
    for (const osc of fourToneNodes.oscillators || []) {
      try {
        osc.stop();
      } catch {
        /* ignore */
      }
    }
    try {
      fourToneNodes.gain.disconnect();
    } catch {
      /* ignore */
    }
    fourToneNodes = null;
  }

  /** Four short beeps played as soon as we place the call — other dialers play
   *  this right before the far end starts ringing, not after they pick up. */
  function playFourToneCue(onDone) {
    stopFourToneCue();
    const ctx = getCallAudioContext();
    if (!ctx) {
      if (typeof onDone === "function") onDone();
      return;
    }
    try {
      const gain = ctx.createGain();
      gain.gain.value = 0;
      gain.connect(ctx.destination);
      const oscillators = [];
      const now = ctx.currentTime;
      const beepMs = 0.09;
      const gapMs = 0.07;
      const freqs = [480, 620, 480, 620];
      freqs.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        osc.type = "sine";
        osc.frequency.value = freq;
        osc.connect(gain);
        const startAt = now + i * (beepMs + gapMs);
        gain.gain.setValueAtTime(0.09, startAt);
        gain.gain.setValueAtTime(0, startAt + beepMs);
        osc.start(startAt);
        osc.stop(startAt + beepMs + 0.01);
        oscillators.push(osc);
      });
      fourToneNodes = { gain, oscillators };
      const totalMs = Math.ceil((freqs.length * (beepMs + gapMs) + 0.05) * 1000);
      fourToneDoneTimer = setTimeout(() => {
        fourToneDoneTimer = null;
        stopFourToneCue();
        if (typeof onDone === "function") onDone();
      }, totalMs);
    } catch {
      stopFourToneCue();
      if (typeof onDone === "function") onDone();
    }
  }

  /** Local US ringback tone (440+480 Hz, 2s on / 4s off) played while an outbound
   *  call is ringing. Many numbers send no early-media ringback, so without this the
   *  agent hears silence. Stopped the instant real call audio flows (see the "volume"
   *  handler) or the call ends — so it never overlaps live conversation. */
  function startSyntheticRingback() {
    if (callProgressAnswered) return;
    stopSyntheticRingback();
    try {
      const ctx = getCallAudioContext();
      if (!ctx) return;
      const gain = ctx.createGain();
      gain.gain.value = 0;
      gain.connect(ctx.destination);
      const o1 = ctx.createOscillator();
      const o2 = ctx.createOscillator();
      o1.frequency.value = 440;
      o2.frequency.value = 480;
      o1.connect(gain);
      o2.connect(gain);
      o1.start();
      o2.start();
      ringbackNodes = { o1, o2, gain };
      const cadence = () => {
        if (!ringbackNodes || callProgressAnswered) return;
        const t = ctx.currentTime;
        try {
          gain.gain.cancelScheduledValues(t);
          gain.gain.setValueAtTime(0.06, t);
          gain.gain.setValueAtTime(0, t + 2);
        } catch {
          /* ignore */
        }
      };
      cadence();
      ringbackCadenceTimer = setInterval(cadence, 6000);
      ringbackSafetyTimer = setTimeout(stopSyntheticRingback, 60000);
    } catch {
      stopSyntheticRingback();
    }
  }

  function stopSyntheticRingback() {
    if (ringbackCadenceTimer) {
      clearInterval(ringbackCadenceTimer);
      ringbackCadenceTimer = null;
    }
    if (ringbackSafetyTimer) {
      clearTimeout(ringbackSafetyTimer);
      ringbackSafetyTimer = null;
    }
    if (ringbackNodes) {
      try { ringbackNodes.gain.gain.value = 0; } catch { /* ignore */ }
      try { ringbackNodes.o1.stop(); } catch { /* ignore */ }
      try { ringbackNodes.o2.stop(); } catch { /* ignore */ }
      try { ringbackNodes.gain.disconnect(); } catch { /* ignore */ }
      ringbackNodes = null;
    }
  }

  function stopCallProgressTones() {
    callProgressAnswered = true;
    stopFourToneCue();
    stopSyntheticRingback();
  }

  function startDialProgressTones() {
    callProgressAnswered = false;
    playFourToneCue(() => {
      if (!callProgressAnswered) startSyntheticRingback();
    });
  }

  function callLooksAnswered(call) {
    try {
      if (call && typeof call.status === "function" && String(call.status() || "").toLowerCase() === "open") {
        return true;
      }
    } catch {
      /* ignore */
    }
    return false;
  }

  function setOnVolume(fn) {
    onVolumeHook = typeof fn === "function" ? fn : null;
  }

  // Live call-quality indicator: surfaces Twilio SDK media warnings (packet loss,
  // jitter, mic not detected) as a small banner so a bad call tells you why.
  let callQualityBannerEl = null;
  const activeCallWarnings = new Map();
  const warningShowTimers = new Map();
  const SETUP_ONLY_WARNINGS = new Set([
    "low-bytes-received",
    "low-bytes-sent",
    "constant-audio-output-level",
    // Browser WebRTC often reports these even when the call sounds fine.
    "high-packet-loss",
    "high-jitter",
    "high-rtt",
    "low-mos"
  ]);

  function clearWarningTimers() {
    for (const timer of warningShowTimers.values()) clearTimeout(timer);
    warningShowTimers.clear();
  }

  function describeCallWarning(name) {
    const n = String(name || "").toLowerCase();
    if (n === "constant-audio-input-level") return "We can't detect your mic - check your headset is selected.";
    if (n === "ice-connectivity-lost") return "Call connection dropped - check Wi-Fi or VPN, then try again.";
    return "";
  }

  function renderCallQualityBanner() {
    if (activeCallWarnings.size === 0) {
      if (callQualityBannerEl) callQualityBannerEl.style.display = "none";
      return;
    }
    if (!callQualityBannerEl) {
      callQualityBannerEl = document.createElement("div");
      callQualityBannerEl.setAttribute("role", "status");
      callQualityBannerEl.style.cssText =
        "position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:99999;max-width:90vw;padding:10px 16px;border-radius:10px;background:#fef3c7;color:#92400e;border:1px solid #fcd34d;font:600 13px/1.45 Arial,Helvetica,sans-serif;box-shadow:0 4px 14px rgba(0,0,0,0.15);text-align:center;";
      document.body.appendChild(callQualityBannerEl);
    }
    const messages = [...activeCallWarnings.values()];
    callQualityBannerEl.textContent = messages[messages.length - 1];
    callQualityBannerEl.style.display = "block";
  }

  function noteCallWarning(name, call) {
    const key = String(name || "").trim().toLowerCase();
    if (!key || SETUP_ONLY_WARNINGS.has(key) || /bytes/.test(key)) return;
    // ICE gathering / disconnect blips are normal while the far phone is still ringing.
    if (key.startsWith("ice-") && key !== "ice-connectivity-lost") return;
    if (!callLooksAnswered(call) && key !== "constant-audio-input-level") return;
    const message = describeCallWarning(key);
    if (!message) return;
    if (activeCallWarnings.has(key) || warningShowTimers.has(key)) return;
    const delayMs = key === "constant-audio-input-level" ? 2500 : 4000;
    const timer = setTimeout(() => {
      warningShowTimers.delete(key);
      if (activeCall !== call) return;
      if (key !== "constant-audio-input-level" && !callLooksAnswered(call)) return;
      activeCallWarnings.set(key, message);
      renderCallQualityBanner();
    }, delayMs);
    warningShowTimers.set(key, timer);
  }

  function clearCallWarning(name) {
    const key = String(name || "").trim().toLowerCase();
    if (warningShowTimers.has(key)) {
      clearTimeout(warningShowTimers.get(key));
      warningShowTimers.delete(key);
    }
    activeCallWarnings.delete(key);
    renderCallQualityBanner();
  }

  async function prepareDeviceAudio(d) {
    if (!d?.audio) return;
    if (typeof d.audio.incoming === "function") {
      try {
        d.audio.incoming(true);
      } catch {
        /* ignore */
      }
    }
    // Use our own pre-ring cue + ringback. Twilio's outgoing sound often fires
    // when the callee answers instead of when ringing starts.
    if (typeof d.audio.outgoing === "function") {
      try {
        d.audio.outgoing(false);
      } catch {
        /* ignore */
      }
    }
    // Route the agent's MIC to the headset (falls back to default).
    if (typeof d.audio.setInputDevice === "function") {
      try {
        const micId = await resolveMicDeviceId();
        await d.audio.setInputDevice(micId || "default");
        if (micId && micId !== "default" && micId !== "communications") setPreferredInputDeviceId(micId);
      } catch (e) {
        console.warn("Twilio setInputDevice:", e);
        try {
          await d.audio.setInputDevice("default");
        } catch {
          /* ignore */
        }
      }
    }
    // Route the CALL AUDIO the agent hears to the headset (falls back to default).
    const outId = await resolveOutputDeviceId();
    if (d.audio.speakerDevices && typeof d.audio.speakerDevices.set === "function") {
      try {
        await d.audio.speakerDevices.set(outId);
      } catch (e) {
        console.warn("Twilio speakerDevices:", e);
        try {
          await d.audio.speakerDevices.set("default");
        } catch {
          /* ignore */
        }
      }
    }
    // Route the ringtone to the same place so the agent hears it ring.
    if (d.audio.ringtoneDevices && typeof d.audio.ringtoneDevices.set === "function") {
      try {
        await d.audio.ringtoneDevices.set(outId);
      } catch {
        try {
          await d.audio.ringtoneDevices.set("default");
        } catch {
          /* ignore */
        }
      }
    }
  }

  function unmuteCall(call) {
    if (!call || typeof call.mute !== "function") return;
    try {
      call.mute(false);
    } catch {
      /* ignore */
    }
  }

  async function ensureDevice() {
    const Twilio = getTwilio();
    if (device && device.state === Twilio.Device.State.Registered) {
      return device;
    }
    if (registerPromise) return registerPromise;
    registerPromise = (async () => {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("This browser does not support microphone access.");
      }
      // Acquire mic permission first so enumerateDevices() returns device
      // LABELS — without labels we can't tell which device is the headset and
      // routing falls back to the wrong (silent) default. Release the stream
      // right away; the SDK acquires its own for the call. Labels persist for
      // the page session once permission is granted.
      try {
        const permStream = await navigator.mediaDevices.getUserMedia({ audio: VOICE_AUDIO_CONSTRAINTS, video: false });
        stopMediaStreamTracks(permStream);
      } catch (permErr) {
        console.warn("Twilio mic permission:", permErr);
        throw new Error(
          "Microphone permission is required for headset calls. Click the lock icon in the address bar, allow the Microphone, then try the call again."
        );
      }
      const token = await fetchToken();
      const d = new Twilio.Device(token, {
        logLevel: "warn",
        closeProtection: true,
        // Prefer Opus: handles jitter/packet loss far better than PCMU, so call
        // audio degrades more gracefully on a shaky connection.
        codecPreferences: ["opus", "pcmu"]
      });
      // Keep inbound handler passive; auto-reject can interrupt valid voice flows.
      d.on("incoming", () => {
        showIncomingRejectDebug();
      });
      d.on("error", (err) => {
        lastDeviceError = err || null;
        console.error("Twilio.Device error", err);
      });
      d.on("tokenWillExpire", async () => {
        try {
          await d.updateToken(await fetchToken());
        } catch (e) {
          console.error(e);
        }
      });
      await withTimeout(
        d.register(),
        12000,
        "Twilio did not register this computer for calling. Check API Key + API Secret in Settings → Twilio (they must be from the same key), then refresh this page."
      );
      await prepareDeviceAudio(d);
      device = d;
      return d;
    })();
    try {
      await registerPromise;
    } finally {
      registerPromise = null;
    }
    return device;
  }

  async function connectCall({ to, twilioFrom, recordCall, contactId, onRinging }) {
    const Twilio = getTwilio();
    cancelScheduledMicRelease();
    unlockAudioPlayback();
    const toE164 = normalizePhoneForTwilio(to);
    if (!toE164.startsWith("+")) {
      throw new Error("Enter a 10-digit U.S. number or a full number with country code.");
    }
    const d = await ensureDevice();
    if (activeCall) {
      try {
        activeCall.disconnect();
      } catch (e) {
        /* ignore */
      }
      activeCall = null;
    }
    await prepareDeviceAudio(d);
    const line = String(twilioFrom || "secondary");
    const params = {
      dialTo: toE164,
      To: toE164,
      phoneNumber: toE164,
      twilioFrom: line
    };
    if (recordCall) params.recordCall = "1";
    const cid = Number(contactId);
    if (Number.isInteger(cid) && cid > 0) params.contactId = String(cid);
    lastCallError = null;
    startDialProgressTones();
    let call;
    try {
      call = await withTimeout(
        d.connect({
          params,
          rtcConstraints: { audio: true }
        }),
        15000,
        CONNECT_STUCK_MESSAGE
      );
    } catch (connectErr) {
      stopCallProgressTones();
      releaseMicPermissionStream();
      throw connectErr;
    }
    activeCall = call;
    unmuteCall(call);
    attachRemoteAudio(call);
    if (callLooksAnswered(call)) stopCallProgressTones();
    const emitRinging = (hasEarlyMedia) => {
      if (typeof onRinging === "function") {
        try {
          onRinging({
            hasEarlyMedia: Boolean(hasEarlyMedia),
            callSid: getBrowserCallSid()
          });
        } catch {
          /* ignore */
        }
      }
    };
    call.on("ringing", (hasEarlyMedia) => {
      emitRinging(hasEarlyMedia);
      attachRemoteAudio(call);
      unmuteCall(call);
      if (callLooksAnswered(call)) {
        stopCallProgressTones();
        return;
      }
      if (hasEarlyMedia) stopSyntheticRingback();
      else if (!ringbackNodes && !fourToneNodes && !callProgressAnswered) startSyntheticRingback();
    });
    if (typeof call.status === "function" && String(call.status() || "").toLowerCase() === "ringing") {
      emitRinging(false);
    }
    call.on("accept", () => {
      unmuteCall(call);
      attachRemoteAudio(call);
      prepareDeviceAudio(d);
      if (callLooksAnswered(call)) stopCallProgressTones();
    });
    const answerWatch = setInterval(() => {
      if (callLooksAnswered(call)) {
        clearInterval(answerWatch);
        stopCallProgressTones();
      }
    }, 200);
    call.on("volume", (input, output) => {
      if ((Number(output) || 0) > 0.04) stopCallProgressTones();
      if (typeof onVolumeHook === "function") {
        try {
          onVolumeHook(Number(input) || 0, Number(output) || 0);
        } catch {
          /* ignore */
        }
      }
      if (input === 0 && output === 0) {
        console.warn("Twilio call volume: no input/output detected — check headset/speaker device in Chrome.");
      }
    });
    const finishCallMedia = () => {
      clearInterval(answerWatch);
      stopCallProgressTones();
      detachRemoteAudio();
      stopActiveCallMediaTracks(call);
      if (activeCall === call) activeCall = null;
      onVolumeHook = null;
      activeCallWarnings.clear();
      clearWarningTimers();
      renderCallQualityBanner();
      if (device && typeof device.disconnectAll === "function") {
        try {
          device.disconnectAll();
        } catch {
          /* ignore */
        }
      }
      releaseMicPermissionStream();
      releaseDeviceMic()
        .catch(() => {})
        .finally(() => {
          if (!activeCall) destroyVoiceDevice();
          scheduleMicReleasePass();
        });
    };
    call.on("disconnect", finishCallMedia);
    call.on("error", (err) => {
      const errMsg = String((err && err.message) || "").trim();
      if (!/device has been destroyed/i.test(errMsg)) {
        lastCallError = err || null;
        console.error("Twilio Call error", err);
      }
      finishCallMedia();
    });
    call.on("cancel", () => {
      lastCallError = lastCallError || { message: "Call canceled before connect." };
      finishCallMedia();
    });
    call.on("reject", () => {
      lastCallError = lastCallError || { message: "Call rejected." };
      finishCallMedia();
    });
    call.on("warning", (name) => {
      console.warn("Twilio Call warning", name);
      noteCallWarning(name, call);
    });
    call.on("warning-cleared", (name) => {
      console.info("Twilio Call warning cleared", name);
      clearCallWarning(name);
    });
    return call;
  }

  function assertBrowserCallReady(cfg) {
    const c = cfg && typeof cfg === "object" ? cfg : {};
    if (c.browserCallReady || c.voiceApiCredentialsValid) return;
    const msg =
      String(c.voiceApiCredentialsError || c.voiceWebhookTestHint || "").trim() ||
      "Computer calling is not ready. Open Settings → Twilio (fix any red warning) and Settings → Runtime (CRM Public URL).";
    throw new Error(msg);
  }

  function formatCallError(err) {
    const source = err || lastCallError || lastDeviceError;
    if (!source) {
      return "Headset call could not connect. Check Settings → Twilio for a red warning, allow the mic, and confirm CRM Public URL in Settings → Runtime.";
    }
    const code = Number(source.code != null ? source.code : source.errorCode);
    const msg = String(source.message || source.twilioError || "").trim();
    let text = "Headset call failed.";
    if (code) text += ` Error ${code}.`;
    if (msg) text += ` ${msg}`;
    if (/stuck on Starting|never reached the voice webhook/i.test(msg)) {
      return CONNECT_STUCK_MESSAGE;
    }
    if (
      code === 20101 ||
      /access token expired|unable to validate your access token/i.test(msg)
    ) {
      text =
        "Headset audio failed (Twilio 20101: API Key and API Secret do not match). The call will ring on the phone line. In Settings → Twilio paste a matching API Key + Secret from the same Twilio key.";
    } else if (
      code === 20103 ||
      /issuer|subject invalid/i.test(msg)
    ) {
      text =
        "Headset call failed. Contact support@crmcadence.com and they can reconnect calling.";
    } else if (code === 31005 || /connectionerror|gateway/i.test(msg)) {
      text =
        "Headset call failed (error 31005). Twilio could not reach your voice webhook. Uncheck “Use headset / this computer” to ring the phone now. Then in Settings → Twilio re-save credentials, and set CRM Public URL in Settings → Runtime to your live site (https://crmcadence.com), not localhost.";
    } else if (code === 31208 || /jwt|token/i.test(msg)) {
      text += " Voice token issue — re-save Twilio API Key and Secret in Settings → Twilio.";
    } else if (code === 31401 || /permission|microphone|notallowed/i.test(msg)) {
      text += " Allow microphone access in the browser.";
    } else if (/device has been destroyed/i.test(msg)) {
      text =
        "Headset call ended unexpectedly. Refresh the page (Ctrl+Shift+R) and try the call again.";
    } else if (/silent|no audio|ice connection|ice failed|media error|no media/i.test(msg)) {
      text +=
        " Call connected but audio failed — this is almost always a VPN or security software blocking call audio (e.g. Avast SecureLine VPN, NordVPN, or an antivirus firewall). Turn off your VPN and try again. If you don't use a VPN, allow the Microphone (lock icon in the address bar) and try a phone hotspot.";
    }
    return text.trim();
  }

  function getBrowserCallSid() {
    if (!activeCall || !activeCall.parameters) return "";
    return String(activeCall.parameters.CallSid || activeCall.parameters.callSid || "").trim();
  }

  function releaseCallMedia() {
    const call = activeCall;
    if (call) {
      stopActiveCallMediaTracks(call);
      try {
        call.disconnect();
      } catch (e) {
        /* ignore */
      }
      activeCall = null;
    }
    onVolumeHook = null;
    if (device && typeof device.disconnectAll === "function") {
      try {
        device.disconnectAll();
      } catch (e) {
        /* ignore */
      }
    }
    releaseMicPermissionStream();
    releaseDeviceMic()
      .catch(() => {})
      .finally(() => {
        if (!activeCall) destroyVoiceDevice();
        scheduleMicReleasePass();
      });
  }

  function teardownVoiceMedia() {
    releaseCallMedia();
    destroyVoiceDevice();
  }

  function disconnectActive() {
    releaseCallMedia();
  }

  if (typeof window !== "undefined") {
    window.addEventListener("pagehide", teardownVoiceMedia);
    window.addEventListener("beforeunload", teardownVoiceMedia);
  }

  function sendDigits(digits) {
    const value = String(digits || "").trim();
    if (!activeCall || !value) return false;
    if (!/^[0-9*#]+$/.test(value)) return false;
    if (typeof activeCall.sendDigits !== "function") return false;
    activeCall.sendDigits(value);
    return true;
  }

  async function fetchVoiceConfig() {
    try {
      const r = await fetch("/api/twilio/voice-config", { credentials: "include" });
      if (r.ok) return await r.json();
    } catch {
      // ignore
    }
    return {
      browserCallReady: false,
      missingEnv: [],
      hint: "",
      voiceWebhookPath: "/webhooks/twilio/voice"
    };
  }

  async function fetchBrowserCallReady() {
    const c = await fetchVoiceConfig();
    return !!(c.browserCallReady || c.voiceApiCredentialsValid);
  }

  function isLocalCrmHost() {
    const host = String((typeof location !== "undefined" && location.hostname) || "").toLowerCase();
    return (
      host === "localhost" ||
      host === "127.0.0.1" ||
      host === "::1" ||
      host === "0.0.0.0" ||
      host.endsWith(".local") ||
      host.endsWith(".localhost")
    );
  }

  function shouldFallbackToPhoneLine(voiceCfg) {
    const cfg = voiceCfg && typeof voiceCfg === "object" ? voiceCfg : {};
    if (cfg.browserCallReady === true || cfg.voiceApiCredentialsValid === true) return false;
    if (cfg.browserCallReady === false) return true;
    return false;
  }

  function getLastCallError() {
    return lastCallError || lastDeviceError || null;
  }

  window.CrmTwilioVoice = {
    connectCall,
    assertBrowserCallReady,
    disconnectActive,
    releaseCallMedia,
    teardownVoiceMedia,
    sendDigits,
    formatCallError,
    getLastCallError,
    fetchBrowserCallReady,
    fetchVoiceConfig,
    shouldFallbackToPhoneLine,
    isLocalCrmHost,
    listInputDevices,
    listOutputDevices,
    getPreferredInputDeviceId,
    setPreferredInputDeviceId,
    getUseHeadsetPreference,
    setUseHeadsetPreference,
    buildHeadsetUiState,
    applyHeadsetUi,
    applyRestProviderUi,
    setOnVolume,
    unlockAudioPlayback,
    getActiveCall: () => activeCall,
    getBrowserCallSid,
    ensureDevice,
    normalizePhoneForTwilio
  };
})();
