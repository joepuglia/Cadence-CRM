(function () {
  const SKIP_PATH = /^\/(login|signup|welcome|billing|agent-demo|contact-sales|webinars)(\.html)?$/i;
  const MAX_MOUNT_RETRIES = 30;
  const NAV_COLLAPSED_KEY = "crm.navCollapsed";
  const NAV_ICON = "/nav-icons.svg?v=20260921tasks";

  const NAV_GROUPS = [
    {
      id: "workspace",
      label: null,
      items: [
        { href: "/home.html", match: ["/home.html", "/home"], label: "Live Dashboard", icon: "nav-dashboard" },
        { href: "/", match: ["/", "/index.html", "/contacts"], label: "Contacts Workspace", icon: "nav-contacts" },
        { href: "/tasks.html", match: ["/tasks.html", "/tasks"], label: "Tasks", icon: "nav-tasks" }
      ]
    },
    {
      id: "pipeline",
      label: "Pipeline",
      icon: "nav-group-pipeline",
      items: [
        { href: "/pipeline.html", match: ["/pipeline.html", "/pipeline"], label: "Pipeline Summary", icon: "nav-pipeline" },
        { href: "/attention.html", match: ["/attention.html", "/attention"], label: "Attention Queue", icon: "nav-attention" },
        { href: "/renewals.html", match: ["/renewals.html", "/renewals"], label: "Renewals", icon: "nav-renewals" },
        { href: "/reports.html", match: ["/reports.html", "/reports"], label: "Reports", icon: "nav-reports" }
      ]
    },
    {
      id: "outreach",
      label: "Outreach",
      icon: "nav-group-outreach",
      items: [
        { href: "/automations.html", match: ["/automations.html", "/automations"], label: "Automations", icon: "nav-journey" },
        { href: "/email.html", match: ["/email.html", "/email"], label: "Send Email", icon: "nav-email" },
        {
          href: "/email-templates.html",
          match: ["/email-templates.html", "/email-templates"],
          label: "Email Templates",
          icon: "nav-email-templates"
        }
      ]
    },
    {
      id: "prospecting",
      label: "Prospecting",
      icon: "nav-group-attract",
      items: [
        { href: "/social.html", match: ["/social.html", "/social"], label: "Social Marketing", icon: "nav-social" },
        {
          href: "/lead-capture.html",
          match: ["/lead-capture.html", "/lead-capture"],
          label: "Lead Capture Form",
          icon: "nav-landing"
        },
        {
          href: "/landing-pages.html",
          match: ["/landing-pages.html", "/landing-pages"],
          label: "Landing Pages",
          icon: "nav-landing"
        },
        { href: "/webinar-admin.html", match: ["/webinar-admin.html", "/webinar-admin"], label: "Webinars", icon: "nav-webinar" }
      ]
    },
    {
      id: "ai",
      label: "AI Tools",
      icon: "nav-group-ai",
      items: [
        { href: "/campaigns.html", match: ["/campaigns.html", "/campaigns"], label: "AI Campaign Builder", icon: "nav-campaign" },
        { href: "/assistant.html", match: ["/assistant.html", "/assistant"], label: "AI Assistant", icon: "nav-assistant" },
        { href: "/role-play.html", match: ["/role-play.html", "/role-play"], label: "AI Role Play", icon: "nav-role-play" },
        { href: "/ai-content.html", match: ["/ai-content.html", "/ai-content"], label: "AI Content", icon: "nav-documents" }
      ]
    },
    {
      id: "schedule",
      label: "Schedule",
      icon: "nav-group-schedule",
      items: [
        { href: "/calendar.html", match: ["/calendar.html", "/calendar"], label: "Calendar", icon: "nav-calendar" },
        { href: "/activities.html", match: ["/activities.html", "/activities"], label: "Activities", icon: "nav-activities" }
      ]
    },
    {
      id: "library",
      label: null,
      items: [
        { href: "/documents.html", match: ["/documents.html", "/documents"], label: "Documents", icon: "nav-documents" },
        { href: "/settings.html", match: ["/settings.html", "/settings"], label: "Settings", icon: "nav-settings" }
      ]
    }
  ];

  function escapeHtml(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function currentPath() {
    let raw = String(window.location.pathname || "/").toLowerCase();
    if (raw.length > 1) raw = raw.replace(/\/+$/, "");
    return raw || "/";
  }

  function normalizeMatchPath(value) {
    let norm = String(value || "").toLowerCase().trim();
    if (!norm) return "/";
    if (norm.length > 1) norm = norm.replace(/\/+$/, "");
    return norm || "/";
  }

  function itemIsActive(item) {
    const path = currentPath();
    return (item.match || [item.href]).some((m) => {
      const norm = normalizeMatchPath(m);
      if (norm === "/" || norm === "/index.html") {
        return path === "/" || path === "/index.html" || path === "/contacts";
      }
      return path === norm;
    });
  }

  function navItemHtml(item) {
    const active = itemIsActive(item);
    const icon = `<svg class="agile-nav-icon" aria-hidden="true" width="20" height="20"><use href="${NAV_ICON}#${escapeHtml(item.icon)}"/></svg>`;
    const label = escapeHtml(item.label);
    if (active) return `<span class="active">${icon}${label}</span>`;
    return `<a href="${escapeHtml(item.href)}">${icon}${label}</a>`;
  }

  function buildGroupedNavHtml() {
    // Groups stay collapsed unless this page lives inside one.
    const openIds = new Set();
    for (const group of NAV_GROUPS) {
      if (group.label && group.items.some(itemIsActive)) openIds.add(group.id);
    }

    return NAV_GROUPS.map((group) => {
      const itemsHtml = group.items.map(navItemHtml).join("");
      if (!group.label) {
        return `<div class="agile-nav-top-links">${itemsHtml}</div>`;
      }
      const isOpen = openIds.has(group.id);
      const icon = group.icon
        ? `<svg class="agile-nav-icon" aria-hidden="true" width="20" height="20"><use href="${NAV_ICON}#${escapeHtml(group.icon)}"/></svg>`
        : "";
      return (
        `<details class="agile-nav-group" data-nav-group="${escapeHtml(group.id)}"${isOpen ? " open" : ""}>` +
        `<summary class="agile-nav-group-toggle">${icon}<span class="agile-nav-group-label">${escapeHtml(group.label)}</span></summary>` +
        `<div class="agile-nav-group-items">${itemsHtml}</div>` +
        `</details>`
      );
    }).join("");
  }

  function renderGroupedNav(inner) {
    if (!inner || inner.dataset.crmGroupedNav === "1") return;
    try {
      localStorage.removeItem("crm.navOpenGroups");
    } catch {
      /* ignore */
    }
    inner.innerHTML = buildGroupedNavHtml();
    inner.dataset.crmGroupedNav = "1";
  }

  function isNarrowNav() {
    return window.matchMedia("(max-width: 980px)").matches;
  }

  function readNavCollapsed() {
    if (isNarrowNav()) {
      try {
        return sessionStorage.getItem("crm.navCollapsedPhone") !== "0";
      } catch {
        return true;
      }
    }
    try {
      return localStorage.getItem(NAV_COLLAPSED_KEY) === "1";
    } catch {
      return false;
    }
  }

  function writeNavCollapsed(collapsed) {
    const value = collapsed ? "1" : "0";
    try {
      if (isNarrowNav()) sessionStorage.setItem("crm.navCollapsedPhone", value);
      else localStorage.setItem(NAV_COLLAPSED_KEY, value);
    } catch {
      /* ignore */
    }
  }

  function setNavCollapsed(collapsed) {
    const isCollapsed = Boolean(collapsed);
    document.body.classList.toggle("crm-nav-collapsed", isCollapsed);
    document.body.classList.toggle("crm-nav-expanded", !isCollapsed && isNarrowNav());
    writeNavCollapsed(isCollapsed);
    const collapseBtn = document.getElementById("crmNavCollapseBtn");
    const expandBtn = document.getElementById("crmNavExpandBtn");
    if (collapseBtn) collapseBtn.setAttribute("aria-expanded", collapsed ? "false" : "true");
    if (expandBtn) {
      expandBtn.setAttribute("aria-expanded", collapsed ? "false" : "true");
      expandBtn.hidden = !collapsed;
    }
  }

  function ensureNavCollapseControls() {
    if (SKIP_PATH.test(window.location.pathname)) return;
    const nav = document.querySelector(".agile-nav");
    if (!nav) return;

    let collapseBtn = document.getElementById("crmNavCollapseBtn");
    if (!collapseBtn) {
      collapseBtn = document.createElement("button");
      collapseBtn.id = "crmNavCollapseBtn";
      collapseBtn.type = "button";
      collapseBtn.className = "crm-nav-collapse-btn";
      collapseBtn.setAttribute("aria-controls", "crmMainNav");
      collapseBtn.innerHTML = '<span aria-hidden="true">&#x2039;</span><span>Hide menu</span>';
      collapseBtn.addEventListener("click", () => setNavCollapsed(true));
      nav.appendChild(collapseBtn);
    }
    if (!nav.id) nav.id = "crmMainNav";

    let expandBtn = document.getElementById("crmNavExpandBtn");
    if (!expandBtn) {
      expandBtn = document.createElement("button");
      expandBtn.id = "crmNavExpandBtn";
      expandBtn.type = "button";
      expandBtn.className = "crm-nav-expand-btn";
      expandBtn.setAttribute("aria-controls", "crmMainNav");
      expandBtn.setAttribute("aria-label", "Show menu");
      expandBtn.innerHTML = '<span aria-hidden="true">&#x203A;</span><span>Menu</span>';
      expandBtn.addEventListener("click", () => setNavCollapsed(false));
      document.body.appendChild(expandBtn);
    }

    setNavCollapsed(readNavCollapsed());
  }

  if (!SKIP_PATH.test(window.location.pathname) && readNavCollapsed()) {
    const applyEarly = () => {
      document.body.classList.add("crm-nav-collapsed");
    };
    if (document.body) applyEarly();
    else document.addEventListener("DOMContentLoaded", applyEarly, { once: true });
  }

  function renderProfile(el, data) {
    const enabled = data && data.enabled === true;
    const companyName = String(data?.companyName || "").trim();
    const photoUrl = String(data?.photoUrl || "").trim();
    const hasPhoto = data?.hasPhoto === true;
    if (!enabled || (!companyName && !photoUrl && !hasPhoto)) {
      el.hidden = true;
      el.setAttribute("aria-hidden", "true");
      el.innerHTML = "";
      return;
    }

    const photoHtml = photoUrl
      ? `<div class="crm-nav-agent-profile-photo"><img src="${escapeHtml(photoUrl)}" alt="" width="48" height="48" decoding="async" /></div>`
      : "";
    const nameHtml = companyName
      ? `<p class="crm-nav-agent-profile-name">${escapeHtml(companyName)}</p>`
      : "";

    el.hidden = false;
    el.removeAttribute("aria-hidden");
    el.innerHTML = `<div class="crm-nav-agent-profile-inner">${photoHtml}${nameHtml}</div>`;
  }

  async function loadProfile(el) {
    try {
      const res = await fetch("/api/email/template-branding", { credentials: "include" });
      if (res.status === 401) {
        el.hidden = true;
        el.setAttribute("aria-hidden", "true");
        return;
      }
      if (!res.ok) throw new Error("load failed");
      const data = await res.json();
      renderProfile(el, data);
    } catch {
      el.hidden = true;
      el.setAttribute("aria-hidden", "true");
    }
  }

  function ensureMount() {
    if (SKIP_PATH.test(window.location.pathname)) return null;

    const nav = document.querySelector(".agile-nav");
    const brand = nav && nav.querySelector(".agile-brand-link");
    const inner = nav && nav.querySelector(".agile-nav-inner");
    if (!nav || !brand || !inner) return null;

    renderGroupedNav(inner);
    ensureNavCollapseControls();

    let el = document.getElementById("crmNavAgentProfile");
    if (!el) {
      el = document.createElement("div");
      el.id = "crmNavAgentProfile";
      el.className = "crm-nav-agent-profile";
      el.hidden = true;
      el.setAttribute("aria-hidden", "true");
      brand.insertAdjacentElement("afterend", el);
    }
    return el;
  }

  let mountAttempts = 0;

  function mount() {
    const el = ensureMount();
    if (el) {
      mountAttempts = 0;
      loadProfile(el);
      return;
    }
    if (mountAttempts < MAX_MOUNT_RETRIES) {
      mountAttempts += 1;
      window.setTimeout(mount, 100);
    }
  }

  window.addEventListener("crm:template-branding-updated", mount);

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mount);
  } else {
    mount();
  }
})();
