/**
 * Email signature storage: server-backed (crm.sqlite per tenant) with localStorage cache.
 * One default block plus optional per–From-address copies in `byFrom`.
 */
(function (global) {
  const EMAIL_SIGNATURE_KEY = "crm.emailSignatureSettings";
  const EMAIL_INCLUDE_SIGNATURE_KEY = "crm.emailIncludeSignature";

  function readRaw() {
    try {
      const raw = global.localStorage.getItem(EMAIL_SIGNATURE_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  }

  function writeRaw(obj) {
    try {
      global.localStorage.setItem(EMAIL_SIGNATURE_KEY, JSON.stringify(obj && typeof obj === "object" ? obj : {}));
    } catch (e) {
      console.warn("[emailSignatureStorage] local write failed", e);
    }
  }

  function stripByFrom(raw) {
    if (!raw || typeof raw !== "object") return {};
    const o = { ...raw };
    delete o.byFrom;
    delete o.include;
    return o;
  }

  function normalizeBlock(obj) {
    if (!obj || typeof obj !== "object") return {};
    return {
      text: String(obj.text || "").trim(),
      html: String(obj.html || "").trim(),
      fontSize: String(obj.fontSize != null && obj.fontSize !== "" ? obj.fontSize : "16"),
      color: String(obj.color != null && obj.color !== "" ? obj.color : "#1f2937").trim(),
      linkText: String(obj.linkText || "").trim(),
      linkUrl: String(obj.linkUrl || "").trim(),
      imageUrl: String(obj.imageUrl || "").trim()
    };
  }

  function hasBlockContent(block) {
    const b = normalizeBlock(block);
    if (b.text || b.html) return true;
    if (b.linkText && b.linkUrl) return true;
    if (b.imageUrl) return true;
    if (b.html && /<img[\s>]/i.test(b.html)) return true;
    return false;
  }

  function applyServerPayloadToLocal(payload) {
    const data = payload && typeof payload === "object" ? payload : {};
    const settings = data.settings && typeof data.settings === "object" ? data.settings : data;
    const include = data.include === false ? false : true;
    const byFrom = settings.byFrom && typeof settings.byFrom === "object" ? settings.byFrom : {};
    const top = normalizeBlock(stripByFrom(settings));
    writeRaw({ ...top, byFrom });
    try {
      global.localStorage.setItem(EMAIL_INCLUDE_SIGNATURE_KEY, include ? "1" : "0");
    } catch {
      //
    }
    return { settings: { ...top, byFrom }, include };
  }

  function buildPayloadFromLocal(includeOverride) {
    const raw = readRaw();
    const byFrom = raw.byFrom && typeof raw.byFrom === "object" ? raw.byFrom : {};
    const top = normalizeBlock(stripByFrom(raw));
    const normalizedByFrom = {};
    for (const [addr, block] of Object.entries(byFrom)) {
      const key = String(addr || "").trim().toLowerCase();
      if (!key) continue;
      normalizedByFrom[key] = normalizeBlock(block);
    }
    let include = true;
    try {
      const includeRaw = global.localStorage.getItem(EMAIL_INCLUDE_SIGNATURE_KEY);
      include = includeRaw == null ? true : includeRaw === "1";
    } catch {
      //
    }
    if (typeof includeOverride === "boolean") include = includeOverride;
    return {
      settings: { ...top, byFrom: normalizedByFrom },
      include
    };
  }

  async function fetchEmailSignatureFromServer() {
    const response = await fetch("/api/email/signature-settings", { credentials: "include", cache: "no-store" });
    const text = await response.text();
    let data = {};
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      data = {};
    }
    if (!response.ok) {
      throw new Error((data && data.error) || "Failed to load email signature from server");
    }
    const serverHasContent = hasBlockContent(
      stripByFrom(data.settings && typeof data.settings === "object" ? data.settings : {})
    );
    const localBefore = readRaw();
    const localHasContent = hasBlockContent(stripByFrom(localBefore));
    if (!serverHasContent && localHasContent) {
      const migrated = buildPayloadFromLocal();
      await persistEmailSignatureToServer(migrated);
      return applyServerPayloadToLocal(migrated);
    }
    return applyServerPayloadToLocal(data);
  }

  async function persistEmailSignatureToServer(payload) {
    const body = payload && typeof payload === "object" ? payload : buildPayloadFromLocal();
    const response = await fetch("/api/email/signature-settings", {
      method: "PUT",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    const text = await response.text();
    let data = {};
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      data = {};
    }
    if (!response.ok) {
      throw new Error((data && data.error) || "Failed to save email signature to server");
    }
    applyServerPayloadToLocal(data);
    return data;
  }

  function getDefaultSignatureBlock() {
    return normalizeBlock(stripByFrom(readRaw()));
  }

  function getSignatureForFromAddress(fromEmail) {
    const def = getDefaultSignatureBlock();
    const raw = readRaw();
    const byFrom = raw.byFrom && typeof raw.byFrom === "object" ? raw.byFrom : {};
    const key = String(fromEmail || "").trim().toLowerCase();
    if (!key) return { ...def };
    const o = byFrom[key];
    if (!o || typeof o !== "object") return { ...def };
    return normalizeBlock({ ...def, ...o });
  }

  function prefillSignatureForAllFromAddresses(addresses) {
    const list = (Array.isArray(addresses) ? addresses : [])
      .map((s) => String(s || "").trim().toLowerCase())
      .filter(Boolean);
    if (!list.length) return false;
    const raw = readRaw();
    const def = getDefaultSignatureBlock();
    if (!hasBlockContent(def)) return false;
    const byFrom = { ...(raw.byFrom && typeof raw.byFrom === "object" ? raw.byFrom : {}) };
    let changed = false;
    for (const addr of list) {
      if (byFrom[addr] == null) {
        byFrom[addr] = { ...def };
        changed = true;
      }
    }
    if (!changed) return false;
    const top = stripByFrom(raw);
    writeRaw({ ...normalizeBlock({ ...top, ...def }), byFrom });
    return true;
  }

  function syncByFromWithDefaultForAddresses(addresses, defaultBlock) {
    const list = (Array.isArray(addresses) ? addresses : [])
      .map((s) => String(s || "").trim().toLowerCase())
      .filter(Boolean);
    const def = normalizeBlock(defaultBlock);
    const byFrom = {};
    for (const addr of list) {
      byFrom[addr] = { ...def };
    }
    writeRaw({ ...def, byFrom });
  }

  global.getDefaultSignatureBlock = getDefaultSignatureBlock;
  global.getSignatureForFromAddress = getSignatureForFromAddress;
  global.prefillSignatureForAllFromAddresses = prefillSignatureForAllFromAddresses;
  global.syncByFromWithDefaultForAddresses = syncByFromWithDefaultForAddresses;
  global.fetchEmailSignatureFromServer = fetchEmailSignatureFromServer;
  global.persistEmailSignatureToServer = persistEmailSignatureToServer;
  global.buildEmailSignaturePayloadFromLocal = buildPayloadFromLocal;
})(typeof window !== "undefined" ? window : global);
