/*
 * contactsAiPanel.js — floating robot launcher + inline "Cadence AI" column
 * for the Contacts Workspace page.
 *
 * A small robot icon (the same Lottie animation as the contact summary page)
 * floats on the right edge. Clicking it docks an inline AI column on the right
 * (no dark overlay) styled like the contact page's "Cadence AI by Claude" panel,
 * pushing the page content left. Actions that work without a single contact:
 * Summarize pipeline, Draft email, Objection coaching. All calls go to the
 * existing /api/assistant/generate endpoint (server AI key).
 *
 * Critical layout uses !important so the page's global button/width rules can't
 * stretch or move the launcher. Self-contained: delete this file and its <script>
 * tag to fully revert.
 */
(function () {
  "use strict";

  // Self-hosted (same origin) so the animation isn't at the mercy of a CDN.
  var LOTTIE_SRC = "/vendor/lottie-player.js?v=208";
  var ROBOT_JSON = "/ai-robot.json?v=20260825csmooth5";
  var LOTTIE_LOAD_TIMEOUT_MS = 20000;
  var LOTTIE_MAX_ATTEMPTS = 4;

  // Temporary placeholder only — never leave this up once Lottie is available.
  var CLAUDE_STARBURST =
    '<svg viewBox="0 0 32 32" width="34" height="34" role="img" aria-label="Cadence AI">' +
    '<circle cx="16" cy="16" r="15" fill="#D97757" opacity="0.18"></circle>' +
    '<path fill="#D97757" d="M16 4.8l3.2 7.5 8-1.1-5.2 6.1 5.2 6.1-8-1.1-3.2 7.5-3.2-7.5-8 1.1 5.2-6.1-5.2-6.1 8 1.1L16 4.8z"></path>' +
    '<circle cx="16" cy="16" r="3.6" fill="#fff7ed"></circle>' +
    "</svg>";

  // Mount on any authenticated app page (they render the left nav) EXCEPT pages
  // that already have their own built-in AI robot / panel — otherwise you get
  // a second (smaller) floating launcher next to the page's large Lottie.
  function pageHasOwnAi() {
    return !!(
      document.getElementById("contactAiPanel") || // contact summary
      document.getElementById("emailAiDraftPanel") || // Send Email
      document.querySelector(".pipeline-ai-robot") || // Pipeline Summary
      document.querySelector(".assistant-avatar-sidebar") || // AI Assistant / AI Content
      (document.body && document.body.classList.contains("page-pipeline")) ||
      (document.body && document.body.classList.contains("page-campaigns")) ||
      (document.body && document.body.classList.contains("page-assistant")) ||
      (document.body && document.body.classList.contains("page-ai-content")) ||
      (document.body && document.body.classList.contains("page-role-play"))
    );
  }

  // The contact page reuses one file for two views: the Summary view (which
  // shows the built-in "Cadence AI" panel) and the Full Contact Details / edit
  // view (which hides it). We only want the floating launcher on the Full
  // Details view. contact.js sets these body classes synchronously before this
  // script runs, so treat the built-in panel as "active" only outside full mode.
  function ownAiPanelActive() {
    if (document.body && document.body.classList.contains("contact-full-mode")) return false;
    return pageHasOwnAi();
  }

  function shouldMount() {
    if (ownAiPanelActive()) return false;
    return !!document.querySelector(".agile-nav");
  }

  // ── Lottie loader (retry until ready; star is only a brief placeholder) ─
  var lottieState = "idle"; // idle | loading | ready
  var lottieWaiters = [];
  var lottieAttempts = 0;
  var lottieRetryTimer = null;
  var robotHosts = [];

  function isLottieDefined() {
    try {
      return !!(window.customElements && customElements.get("lottie-player"));
    } catch (e) {
      return false;
    }
  }

  function flushLottie(ok) {
    var ws = lottieWaiters.slice();
    lottieWaiters.length = 0;
    ws.forEach(function (r) {
      r(ok);
    });
  }

  function robotMarkup(size) {
    return (
      '<lottie-player src="' +
      ROBOT_JSON +
      '" background="transparent" speed="1" style="width:' +
      size +
      "px;height:" +
      size +
      'px" loop autoplay></lottie-player>'
    );
  }

  function starMarkup(size) {
    return (
      '<span class="cai-star-fallback" style="display:inline-flex;transform:scale(' +
      (size / 34).toFixed(2) +
      ')">' +
      CLAUDE_STARBURST +
      "</span>"
    );
  }

  function upgradeAllRobotHosts() {
    robotHosts = robotHosts.filter(function (entry) {
      return entry && entry.host && entry.host.isConnected;
    });
    robotHosts.forEach(function (entry) {
      if (!entry.host.querySelector("lottie-player")) {
        entry.host.innerHTML = robotMarkup(entry.size);
      }
    });
  }

  function scheduleLottieRetry() {
    if (lottieRetryTimer || lottieState === "ready") return;
    if (lottieAttempts >= LOTTIE_MAX_ATTEMPTS) return;
    var delay = Math.min(1200 * Math.pow(2, Math.max(0, lottieAttempts - 1)), 8000);
    lottieRetryTimer = setTimeout(function () {
      lottieRetryTimer = null;
      lottieState = "idle";
      ensureLottie().then(function (ok) {
        if (ok) upgradeAllRobotHosts();
      });
    }, delay);
  }

  function ensureLottie() {
    return new Promise(function (resolve) {
      if (lottieState === "ready" || isLottieDefined()) {
        lottieState = "ready";
        return resolve(true);
      }
      lottieWaiters.push(resolve);
      if (lottieState === "loading") return;

      lottieState = "loading";
      lottieAttempts += 1;

      var sc = document.querySelector('script[src*="lottie-player"]');
      if (!sc) {
        sc = document.createElement("script");
        sc.src = LOTTIE_SRC;
        sc.async = true;
        document.head.appendChild(sc);
      }

      var settled = false;
      var to = setTimeout(onFail, LOTTIE_LOAD_TIMEOUT_MS);

      function onSuccess() {
        if (settled) return;
        settled = true;
        clearTimeout(to);
        lottieState = "ready";
        if (lottieRetryTimer) {
          clearTimeout(lottieRetryTimer);
          lottieRetryTimer = null;
        }
        flushLottie(true);
        upgradeAllRobotHosts();
      }

      function onFail() {
        if (settled) return;
        settled = true;
        clearTimeout(to);
        lottieState = "idle";
        flushLottie(false);
        scheduleLottieRetry();
      }

      function afterScriptAvailable() {
        if (isLottieDefined()) {
          onSuccess();
          return;
        }
        if (window.customElements && customElements.whenDefined) {
          customElements.whenDefined("lottie-player").then(onSuccess).catch(onFail);
          return;
        }
        onFail();
      }

      if (isLottieDefined() || sc.getAttribute("data-loaded") === "1") {
        afterScriptAvailable();
        return;
      }

      sc.addEventListener(
        "load",
        function () {
          try {
            sc.setAttribute("data-loaded", "1");
          } catch (e) {
            /* ignore */
          }
          afterScriptAvailable();
        },
        { once: true }
      );
      sc.addEventListener("error", onFail, { once: true });
    });
  }

  // Fill a host with the robot as soon as Lottie is ready. Star is temporary.
  function renderRobot(host, size) {
    if (!host) return;
    robotHosts.push({ host: host, size: size });
    if (isLottieDefined() || lottieState === "ready") {
      host.innerHTML = robotMarkup(size);
      return;
    }
    host.innerHTML = starMarkup(size);
    ensureLottie().then(function (ok) {
      if (!host.isConnected) return;
      if (ok) host.innerHTML = robotMarkup(size);
    });
  }

  function injectStyles() {
    if (document.getElementById("cai-styles")) return;
    var s = document.createElement("style");
    s.id = "cai-styles";
    s.textContent = [
      // Floating robot launcher — hardened against global button rules
      ".cai-launcher{position:fixed !important;top:50% !important;right:16px !important;left:auto !important;bottom:auto !important;transform:translateY(-50%) !important;width:64px !important;height:64px !important;min-width:0 !important;max-width:64px !important;min-height:0 !important;margin:0 !important;padding:6px !important;box-sizing:border-box !important;display:flex !important;align-items:center;justify-content:center;background:#ffffff !important;border:1px solid #e5e7eb !important;border-radius:50% !important;box-shadow:0 8px 24px rgba(49,46,129,.28) !important;cursor:pointer !important;z-index:99997 !important;overflow:visible;animation:cai-bob 3.4s ease-in-out infinite;}",
      ".cai-launcher:hover{box-shadow:0 12px 30px rgba(49,46,129,.42) !important;}",
      ".cai-launcher:before{content:'';position:absolute;inset:-4px;border-radius:50%;background:conic-gradient(from 0deg,#4f46e5,#7c3aed,#0d9488,#4f46e5);opacity:.0;transition:opacity .2s ease;z-index:-1;}",
      ".cai-launcher:hover:before{opacity:.35;}",
      ".cai-launcher lottie-player{width:52px !important;height:52px !important;}",
      "@keyframes cai-bob{0%,100%{transform:translateY(-50%);}50%{transform:translateY(calc(-50% - 6px));}}",
      ".cai-launcher.cai-hidden{display:none !important;}",
      // Inline docked AI column (no dark overlay)
      ".cai-col{position:fixed !important;top:0 !important;right:0 !important;left:auto !important;height:100vh !important;width:370px !important;max-width:94vw !important;background:radial-gradient(circle at top right, rgba(124,58,237,0.22), transparent 36%), linear-gradient(135deg,#0b1636 0%,#142852 100%) !important;box-shadow:-14px 0 40px rgba(15,23,42,.28) !important;border-left:1px solid #2a4d95 !important;z-index:99998 !important;display:flex !important;flex-direction:column !important;transform:translateX(100%);transition:transform .7s cubic-bezier(.22,.61,.36,1);font:inherit;color:#ffffff;box-sizing:border-box;}",
      ".cai-col.cai-open{transform:translateX(0);}",
      // Push page content left when open (inline feel, no dimming)
      "body.cai-docked main.container{padding-right:384px !important;transition:padding .7s cubic-bezier(.22,.61,.36,1);}",
      // Wide tables (e.g. contacts) scroll horizontally instead of squeezing
      "body.cai-docked .contacts-table-wrap{overflow-x:auto !important;}",
      "body.cai-docked .contacts-table-wrap>table{width:max-content !important;min-width:100% !important;}",
      "@media (max-width:900px){body.cai-docked main.container{padding-right:0 !important;}.cai-col{width:100vw !important;max-width:100vw !important;}body.cai-docked .contacts-table-wrap>table{width:auto !important;}}",
      // Column header
      ".cai-head{position:relative;padding:18px 18px 14px;background:transparent;color:#fff;text-align:center;}",
      ".cai-head::after{content:'AI';position:absolute;top:10px;left:16px;font-size:38px;font-weight:900;letter-spacing:.08em;color:#ffffff !important;pointer-events:none;line-height:1;}",
      ".cai-robot{width:96px;height:96px;margin:0 auto 4px;display:flex;align-items:center;justify-content:center;}",
      ".cai-title{display:flex;align-items:center;justify-content:center;gap:7px;font-size:16px;font-weight:700;margin:0;}",
      ".cai-sub{margin:7px 0 0;font-size:12px;line-height:1.4;color:#c7d2fe;}",
      ".cai-close{position:absolute;top:12px;right:12px;width:30px;height:30px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.14);border:none;border-radius:8px;color:#fff;font-size:20px;line-height:1;cursor:pointer;}",
      ".cai-close:hover{background:rgba(255,255,255,.26);}",
      ".cai-status{display:inline-flex;align-items:center;gap:6px;margin-top:11px;font-size:11px;font-weight:600;padding:3px 9px;border-radius:999px;background:rgba(255,255,255,.14);color:#e0e7ff;}",
      ".cai-status .cai-dot{width:7px;height:7px;border-radius:50%;background:#94a3b8;}",
      ".cai-status[data-ok='1'] .cai-dot{background:#4ade80;}",
      ".cai-status[data-ok='0'] .cai-dot{background:#f87171;}",
      // Body
      ".cai-body{flex:1;overflow-y:auto;padding:14px 16px 24px;}",
      ".cai-card{background:#122446;border:1px solid #2a4d95;border-radius:12px;padding:13px;margin-bottom:13px;box-shadow:0 1px 2px rgba(0,0,0,.18);}",
      ".cai-card h4{margin:0 0 3px;font-size:13.5px;font-weight:700;color:#ffffff;}",
      ".cai-card p.cai-hint{margin:0 0 9px;font-size:11.5px;color:rgba(255,255,255,.62);line-height:1.4;}",
      ".cai-ta{width:100%;box-sizing:border-box;border:1px solid #2a4d95;border-radius:8px;padding:8px 10px;font:inherit;font-size:12.5px;resize:vertical;min-height:58px;margin-bottom:9px;background:#10244b;color:#f8fafc;}",
      ".cai-ta::placeholder{color:rgba(255,255,255,.55);}",
      ".cai-ta:focus{outline:2px solid #4f46e5;outline-offset:1px;border-color:#6366f1;}",
      ".cai-run{display:inline-flex;align-items:center;justify-content:center;gap:6px;width:100%;box-sizing:border-box;background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;border:1px solid rgba(255,255,255,.22);border-radius:8px;padding:9px 14px;font:inherit;font-weight:600;font-size:12.5px;cursor:pointer;box-shadow:0 10px 24px rgba(79,70,229,.28);}",
      ".cai-run:hover{background:linear-gradient(135deg,#4338ca,#6d28d9);}",
      ".cai-run:disabled{opacity:.55;cursor:default;}",
      ".cai-res{margin-top:9px;font-size:12.5px;line-height:1.5;color:#ffffff;white-space:pre-wrap;word-break:break-word;background:#142852;border:1px solid #2a4d95;border-radius:8px;padding:10px 12px;display:none;}",
      ".cai-res.cai-show{display:block;}",
      ".cai-res.cai-err{background:#fef2f2;border-color:#fecaca;color:#b91c1c;}",
      ".cai-res-subject{font-weight:700;margin-bottom:6px;}",
      ".cai-chips{display:flex;gap:8px;margin:0 0 9px;}",
      ".cai-chip{flex:1;background:#10244b;color:#e0e7ff;border:1px solid #2a4d95;border-radius:8px;padding:7px 10px;font:inherit;font-size:12px;font-weight:700;cursor:pointer;}",
      ".cai-chip.is-active{background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;border-color:rgba(255,255,255,.22);}",
      ".cai-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px;}",
      ".cai-copy{display:inline-flex;align-items:center;gap:5px;background:#fff;color:#4f46e5;border:1px solid #c7d2fe;border-radius:7px;padding:5px 10px;font:inherit;font-size:11.5px;font-weight:600;cursor:pointer;}",
      ".cai-copy:hover{background:#eef2ff;}",
      ".cai-spin{display:inline-block;width:13px;height:13px;border:2px solid rgba(255,255,255,.5);border-top-color:#fff;border-radius:50%;animation:cai-rot .7s linear infinite;}",
      "@keyframes cai-rot{to{transform:rotate(360deg);}}",
      ".cai-col,.cai-col h3,.cai-col h4,.cai-col p,.cai-col span,.cai-col .cai-title,.cai-col .cai-sub,.cai-col .cai-hint,.cai-col .cai-status,.cai-col .cai-status-text,.cai-col .cai-res,.cai-col .cai-res-subject{color:#ffffff !important;}",
      ".cai-col .cai-ta{color:#ffffff !important;}",
      ".cai-col .cai-ta::placeholder{color:rgba(255,255,255,.72) !important;}",
      ".cai-col .cai-chip{color:#ffffff !important;}",
      ".cai-col .cai-copy{color:#4f46e5 !important;}",
      ".cai-col .cai-res.cai-err{color:#b91c1c !important;}"
    ].join("\n");
    document.head.appendChild(s);
  }

  var els = {};
  var configured = null;

  function contactPageId() {
    try {
      if (!/\/contact\.html$/i.test(window.location.pathname)) return 0;
      var id = Number(new URLSearchParams(window.location.search).get("id"));
      return Number.isInteger(id) && id > 0 ? id : 0;
    } catch (e) {
      return 0;
    }
  }

  function notifyContactPage(name) {
    try {
      window.dispatchEvent(new CustomEvent(name));
    } catch (e) {
      /* ignore */
    }
  }

  async function fetchApiJson(path, init) {
    var response;
    try {
      response = await fetch(path, { credentials: "include", ...(init || {}) });
    } catch (e) {
      throw new Error("Could not reach the CRM server. Refresh and try again.");
    }
    var data = {};
    try {
      data = await response.json();
    } catch (e) {
      data = {};
    }
    return { response: response, data: data };
  }

  async function checkStatus() {
    try {
      var r = await fetchApiJson("/api/assistant/status");
      configured = !!(r.data && r.data.configured);
    } catch (e) {
      configured = false;
    }
    if (els.status) {
      els.status.setAttribute("data-ok", configured ? "1" : "0");
      els.status.querySelector(".cai-status-text").textContent = configured
        ? "AI ready"
        : "AI key not set";
    }
  }

  function setBtnLoading(btn, loading) {
    if (!btn) return;
    btn.disabled = loading;
    if (loading) {
      btn.dataset.label = btn.textContent;
      btn.innerHTML = '<span class="cai-spin"></span> Working...';
    } else {
      btn.textContent = btn.dataset.label || "Run";
    }
  }

  function showRes(box, content, isError) {
    box.classList.add("cai-show");
    box.classList.toggle("cai-err", !!isError);
    if (typeof content === "string") {
      box.textContent = content;
    } else {
      box.innerHTML = "";
      box.appendChild(content);
    }
  }

  function copyButton(getText) {
    var b = document.createElement("button");
    b.type = "button";
    b.className = "cai-copy";
    b.textContent = "Copy";
    b.addEventListener("click", function () {
      var t = getText();
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(t).then(function () {
          b.textContent = "Copied!";
          setTimeout(function () {
            b.textContent = "Copy";
          }, 1500);
        });
      }
    });
    return b;
  }

  function actionButton(label, onClick) {
    var b = document.createElement("button");
    b.type = "button";
    b.className = "cai-copy";
    b.textContent = label;
    b.addEventListener("click", onClick);
    return b;
  }

  function contactFieldValue(id) {
    var el = document.getElementById(id);
    return el ? String(el.value || "").trim() : "";
  }

  function selectedMessageChannel(col) {
    var active = col.querySelector(".cai-chip.is-active");
    return active && active.getAttribute("data-channel") === "sms" ? "sms" : "email";
  }

  async function runGenerate(body, btn, box, render) {
    if (configured === false) {
      showRes(
        box,
        "AI is included with Cadence, and it is not turned on for this site yet.",
        true
      );
      return;
    }
    setBtnLoading(btn, true);
    box.classList.remove("cai-show", "cai-err");
    try {
      var r = await fetchApiJson("/api/assistant/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      if (!r.response.ok) throw new Error((r.data && r.data.error) || "AI request failed.");
      render(r.data);
    } catch (e) {
      showRes(box, (e && e.message) || "AI request failed.", true);
    } finally {
      setBtnLoading(btn, false);
    }
  }

  function listHtml(items) {
    var list = Array.isArray(items)
      ? items.map(function (item) { return String(item || "").trim(); }).filter(Boolean)
      : [];
    if (!list.length) return "";
    return list.map(function (item) { return "• " + item; }).join("\n");
  }

  function showTextResult(box, text) {
    var wrap = document.createElement("div");
    var t = document.createElement("div");
    t.textContent = text;
    wrap.appendChild(t);
    wrap.appendChild(copyButton(function () { return text; }));
    showRes(box, wrap);
  }

  function buildColumn() {
    var col = document.createElement("aside");
    var contactId = contactPageId();
    col.className = "cai-col";
    col.setAttribute("role", "complementary");
    col.setAttribute("aria-label", "Cadence AI");
    var sub = contactId
      ? "Score this lead, draft a message, summarize a call, or get objection coaching from the server AI key."
      : "Summarize your pipeline, draft an email, or get objection coaching \u2014 powered by the server AI key.";
    var objectionCard =
      '<div class="cai-card"><h4>Objection coaching</h4>' +
      '<p class="cai-hint">Paste a client objection and get a suggested response.</p>' +
      '<textarea class="cai-ta" data-in="objection" placeholder="e.g. It costs too much / I already have coverage / I need to think about it."></textarea>' +
      '<button type="button" class="cai-run" data-act="objection">Coach objection</button>' +
      '<div class="cai-res" data-res="objection"></div></div>';
    var body = contactId
      ? objectionCard +
        '<div class="cai-card"><h4>Score this lead</h4>' +
        '<p class="cai-hint">Rate this contact from the record, notes, and recent activity.</p>' +
        '<button type="button" class="cai-run" data-act="score">Score Lead</button>' +
        '<div class="cai-res" data-res="score"></div></div>' +
        '<div class="cai-card"><h4>Draft a message</h4>' +
        '<p class="cai-hint">Describe the purpose. Cadence AI writes an email or SMS using this contact\'s details.</p>' +
        '<textarea class="cai-ta" data-in="message" placeholder="e.g. follow up after the missed call and offer a time to reconnect."></textarea>' +
        '<div class="cai-chips" role="group" aria-label="Message type">' +
        '<button type="button" class="cai-chip is-active" data-channel="email">Email</button>' +
        '<button type="button" class="cai-chip" data-channel="sms">SMS</button>' +
        "</div>" +
        '<button type="button" class="cai-run" data-act="message">Draft message</button>' +
        '<div class="cai-res" data-res="message"></div></div>' +
        '<div class="cai-card"><h4>Summarize call</h4>' +
        '<p class="cai-hint">Paste call notes or a transcript. Cadence AI writes a summary and next steps.</p>' +
        '<textarea class="cai-ta" data-in="call" placeholder="Paste rough call notes or a transcript, then summarize."></textarea>' +
        '<button type="button" class="cai-run" data-act="call">Summarize Call</button>' +
        '<div class="cai-res" data-res="call"></div></div>'
      : objectionCard +
        '<div class="cai-card"><h4>Summarize my pipeline</h4>' +
        '<p class="cai-hint">A quick read on recent activity, upcoming renewals, and where to focus next.</p>' +
        '<button type="button" class="cai-run" data-act="pipeline">Summarize pipeline</button>' +
        '<div class="cai-res" data-res="pipeline"></div></div>' +
        '<div class="cai-card"><h4>Draft an email</h4>' +
        '<p class="cai-hint">Describe the purpose and Cadence AI writes a subject line and body you can copy.</p>' +
        '<textarea class="cai-ta" data-in="email" placeholder="e.g. Follow up with ACA leads who haven\'t responded, invite them to book a call."></textarea>' +
        '<button type="button" class="cai-run" data-act="email">Draft email</button>' +
        '<div class="cai-res" data-res="email"></div></div>';
    col.innerHTML =
      '<div class="cai-head">' +
      '<button type="button" class="cai-close" aria-label="Close AI panel">&times;</button>' +
      '<div class="cai-robot" id="cai-robot-host"></div>' +
      '<h3 class="cai-title">Cadence AI by Claude</h3>' +
      '<p class="cai-sub">' +
      sub +
      "</p>" +
      '<span class="cai-status" data-ok=""><span class="cai-dot"></span><span class="cai-status-text">Checking\u2026</span></span>' +
      "</div>" +
      '<div class="cai-body">' +
      body +
      "</div>";

    document.body.appendChild(col);
    els.col = col;
    els.status = col.querySelector(".cai-status");

    renderRobot(col.querySelector("#cai-robot-host"), 96);
    col.querySelector(".cai-close").addEventListener("click", closePanel);
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") closePanel();
    });

    var pipeBtn = col.querySelector('[data-act="pipeline"]');
    var pipeRes = col.querySelector('[data-res="pipeline"]');
    if (pipeBtn && pipeRes) {
      pipeBtn.addEventListener("click", function () {
        runGenerate({ mode: "pipeline" }, pipeBtn, pipeRes, function (data) {
          showTextResult(pipeRes, (data && data.summary) || "No summary returned.");
        });
      });
    }

    var emailBtn = col.querySelector('[data-act="email"]');
    var emailIn = col.querySelector('[data-in="email"]');
    var emailRes = col.querySelector('[data-res="email"]');
    if (emailBtn && emailIn && emailRes) {
      emailBtn.addEventListener("click", function () {
        var purpose = (emailIn.value || "").trim();
        if (!purpose) return showRes(emailRes, "Describe the email purpose first.", true);
        runGenerate({ mode: "email", purpose: purpose }, emailBtn, emailRes, function (data) {
          var subject = (data && data.subject) || "";
          var text = (data && data.text) || "";
          var wrap = document.createElement("div");
          if (subject) {
            var subEl = document.createElement("div");
            subEl.className = "cai-res-subject";
            subEl.textContent = "Subject: " + subject;
            wrap.appendChild(subEl);
          }
          var bodyEl = document.createElement("div");
          bodyEl.textContent = text;
          wrap.appendChild(bodyEl);
          wrap.appendChild(copyButton(function () {
            return (subject ? "Subject: " + subject + "\n\n" : "") + text;
          }));
          showRes(emailRes, wrap);
        });
      });
    }

    col.querySelectorAll(".cai-chip[data-channel]").forEach(function (chip) {
      chip.addEventListener("click", function () {
        col.querySelectorAll(".cai-chip[data-channel]").forEach(function (other) {
          other.classList.toggle("is-active", other === chip);
        });
      });
    });

    var messageBtn = col.querySelector('[data-act="message"]');
    var messageIn = col.querySelector('[data-in="message"]');
    var messageRes = col.querySelector('[data-res="message"]');
    if (messageBtn && messageIn && messageRes && contactId) {
      messageBtn.addEventListener("click", function () {
        var purpose = (messageIn.value || "").trim();
        if (!purpose) return showRes(messageRes, "Describe the message purpose first.", true);
        var channel = selectedMessageChannel(col);
        runGenerate(
          { mode: channel, purpose: purpose, contactId: contactId, tone: "warm" },
          messageBtn,
          messageRes,
          function (data) {
            var wrap = document.createElement("div");
            var actions = document.createElement("div");
            actions.className = "cai-actions";
            if (channel === "sms") {
              var smsText = String((data && data.message) || "").trim();
              var smsText2 = String((data && data.message2) || "").trim();
              var shown = smsText;
              if (smsText2) shown += "\n\n" + smsText2;
              var bodyEl = document.createElement("div");
              bodyEl.textContent = shown || "No SMS draft returned.";
              wrap.appendChild(bodyEl);
              actions.appendChild(copyButton(function () { return shown; }));
              actions.appendChild(
                actionButton("Use in Send SMS", function () {
                  var smsBody = document.getElementById("contactTwilioSmsBody");
                  if (smsBody) smsBody.value = shown;
                  var smsOpen = document.getElementById("contactPageSmsBtn");
                  if (smsOpen) smsOpen.click();
                })
              );
            } else {
              var subject = String((data && data.subject) || "").trim();
              var text = String((data && data.text) || "").trim();
              if (subject) {
                var subEl = document.createElement("div");
                subEl.className = "cai-res-subject";
                subEl.textContent = "Subject: " + subject;
                wrap.appendChild(subEl);
              }
              var emailBody = document.createElement("div");
              emailBody.textContent = text || "No email draft returned.";
              wrap.appendChild(emailBody);
              actions.appendChild(
                copyButton(function () {
                  return (subject ? "Subject: " + subject + "\n\n" : "") + text;
                })
              );
              actions.appendChild(
                actionButton("Open in Send Email", function () {
                  try {
                    sessionStorage.setItem(
                      "crm_assistant_email_draft",
                      JSON.stringify({
                        subject: subject,
                        text: text,
                        html: (data && data.html) || text,
                        contactEmail: contactFieldValue("email")
                      })
                    );
                  } catch (e) {
                    /* ignore */
                  }
                  window.location.href = "/email.html";
                })
              );
            }
            wrap.appendChild(actions);
            showRes(messageRes, wrap);
          }
        );
      });
    }

    var scoreBtn = col.querySelector('[data-act="score"]');
    var scoreRes = col.querySelector('[data-res="score"]');
    if (scoreBtn && scoreRes && contactId) {
      scoreBtn.addEventListener("click", function () {
        runContactAi(
          "/api/ai/contacts/" + encodeURIComponent(String(contactId)) + "/score",
          {},
          scoreBtn,
          scoreRes,
          function (data) {
            if (data && data.cleared) {
              showTextResult(scoreRes, "This contact is declined, so the AI score was removed.");
            } else {
              var text = String((data && data.score) || "-") + "/10";
              if (data && data.reason) text += "\n" + data.reason;
              if (data && data.nextBestAction) text += "\nNext action: " + data.nextBestAction;
              showTextResult(scoreRes, text);
            }
            notifyContactPage("crm-refresh-contact");
          }
        );
      });
    }

    var callBtn = col.querySelector('[data-act="call"]');
    var callIn = col.querySelector('[data-in="call"]');
    var callRes = col.querySelector('[data-res="call"]');
    if (callBtn && callIn && callRes && contactId) {
      callBtn.addEventListener("click", function () {
        var notes = (callIn.value || "").trim();
        if (!notes) return showRes(callRes, "Paste call notes or a transcript first.", true);
        runContactAi(
          "/api/ai/contacts/" + encodeURIComponent(String(contactId)) + "/call-summary",
          { notes: notes },
          callBtn,
          callRes,
          function (data) {
            var text = (data && data.summary) || "Summary created.";
            var discussed = listHtml(data && data.discussed);
            var next = listHtml(data && data.nextSteps);
            if (discussed) text += "\n\nDiscussed:\n" + discussed;
            if (next) text += "\n\nNext steps:\n" + next;
            if (data && data.followUpDate) text += "\nFollow up: " + data.followUpDate;
            showTextResult(callRes, text);
            callIn.value = "";
            notifyContactPage("crm-reload-history");
          }
        );
      });
    }

    var objBtn = col.querySelector('[data-act="objection"]');
    var objIn = col.querySelector('[data-in="objection"]');
    var objRes = col.querySelector('[data-res="objection"]');
    if (objBtn && objIn && objRes) {
      objBtn.addEventListener("click", function () {
        var objection = (objIn.value || "").trim();
        if (!objection) return showRes(objRes, "Enter the client objection first.", true);
        if (contactId) {
          runContactAi(
            "/api/ai/contacts/" + encodeURIComponent(String(contactId)) + "/objection-coach",
            { objection: objection },
            objBtn,
            objRes,
            function (data) {
              var text = listHtml(data && data.rebuttals) || "No response returned.";
              if (data && data.bestQuestion) text += "\n\nBest question: " + data.bestQuestion;
              if (data && data.complianceNote) text += "\nCompliance note: " + data.complianceNote;
              showTextResult(objRes, text);
              notifyContactPage("crm-reload-history");
            }
          );
          return;
        }
        runGenerate({ mode: "objection", objection: objection }, objBtn, objRes, function (data) {
          showTextResult(objRes, (data && data.text) || "No response returned.");
        });
      });
    }
  }

  async function runContactAi(path, body, btn, box, render) {
    if (configured === false) {
      showRes(
        box,
        "AI is included with Cadence, and it is not turned on for this site yet.",
        true
      );
      return;
    }
    setBtnLoading(btn, true);
    box.classList.remove("cai-show", "cai-err");
    try {
      var r = await fetchApiJson(path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body || {})
      });
      if (!r.response.ok) throw new Error((r.data && r.data.error) || "AI request failed.");
      render(r.data);
    } catch (e) {
      showRes(box, (e && e.message) || "AI request failed.", true);
    } finally {
      setBtnLoading(btn, false);
    }
  }

  function openPanel() {
    if (!els.col) buildColumn();
    if (!els.col) return;
    if (els.launcher) els.launcher.classList.add("cai-hidden");
    if (configured === null) checkStatus();
    if (els.col.classList.contains("cai-open")) return;
    /* First open used to snap: the column was created and opened in the same
       frame, so the closed transform never painted. Force a closed paint, then slide. */
    void els.col.offsetWidth;
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        if (!els.col) return;
        els.col.classList.add("cai-open");
        document.body.classList.add("cai-docked");
      });
    });
  }

  function closePanel() {
    if (els.col) els.col.classList.remove("cai-open");
    document.body.classList.remove("cai-docked");
    if (els.launcher) els.launcher.classList.remove("cai-hidden");
  }

  function injectLauncher() {
    if (document.getElementById("cai-launcher")) return;
    var btn = document.createElement("button");
    btn.id = "cai-launcher";
    btn.type = "button";
    btn.className = "cai-launcher";
    btn.setAttribute("aria-label", "Open Cadence AI");
    btn.setAttribute("title", "Cadence AI");
    btn.addEventListener("click", openPanel);
    document.body.appendChild(btn);
    els.launcher = btn;
    renderRobot(btn, 52);
    if (!els.col) buildColumn();
  }

  function boot() {
    var tries = 0;
    var timer = setInterval(function () {
      tries++;
      // Skip pages that already have a built-in AI panel (Send Email, etc.).
      // Contact Details uses this floating launcher, including Score Lead
      // and Summarize Call.
      if (ownAiPanelActive()) {
        clearInterval(timer);
        return;
      }
      if (document.querySelector(".agile-nav")) {
        clearInterval(timer);
        if (shouldMount()) {
          injectStyles();
          injectLauncher();
        }
        return;
      }
      if (tries > 15) clearInterval(timer);
    }, 300);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
