const homeMessageEl = document.getElementById("homeMessage");
const homeTotalActivitiesEl = document.getElementById("homeTotalActivities");
const homeContactsTouchedEl = document.getElementById("homeContactsTouched");
const homeLast24hEl = document.getElementById("homeLast24h");
const homeLast7dEl = document.getElementById("homeLast7d");
const homeSoldCategoryEl = document.getElementById("homeSoldCategory");
const homeEmailOpens24hEl = document.getElementById("homeEmailOpens24h");
const homeEmailOpens7dEl = document.getElementById("homeEmailOpens7d");
const homeEmailClicks7dEl = document.getElementById("homeEmailClicks7d");
const homeEmailClicks24hEl = document.getElementById("homeEmailClicks24h");
const homeEmailSent7dEl = document.getElementById("homeEmailSent7d");
const homeEmailSent24hEl = document.getElementById("homeEmailSent24h");
const homeCategoriesEl = document.getElementById("homeCategories");
const homeCategoryDonutEl = document.getElementById("homeCategoryDonut");
const homeDonutLegendEl = document.getElementById("homeDonutLegend");
const homeUpcomingTasksEl = document.getElementById("homeUpcomingTasks");
const homeUpcomingBirthdaysEl = document.getElementById("homeUpcomingBirthdays");
const homeRecentActivitiesEl = document.getElementById("homeRecentActivities");
const homeRunningAutomationsEl = document.getElementById("homeRunningAutomations");
const homePastAutomationsEl = document.getElementById("homePastAutomations");
const homeRefreshBtn = document.getElementById("homeRefreshBtn");
const homeRefreshDripQueueBtn = document.getElementById("homeRefreshDripQueueBtn");
const homeEmailCampaignsEl = document.getElementById("homeEmailCampaigns");
const homeLoadingStatusEl = document.getElementById("homeLoadingStatus");
const dripMetricPendingEl = document.getElementById("dripMetricPending");
const dripMetricSentEl = document.getElementById("dripMetricSent");
const dripMetricFailedEl = document.getElementById("dripMetricFailed");
const dripMetricCampaignsEl = document.getElementById("dripMetricCampaigns");
const dripCampaignBlocksEl = document.getElementById("dripCampaignBlocks");
const homeSnapshotEl = document.getElementById("homeSnapshot");

const STATIC_DEV_PORTS = new Set(["5500", "5501", "5173", "4173", "8080", "1234", "8888", "4200", "5000"]);
const CHART_COLORS = ["#2563eb", "#0891b2", "#059669", "#7c3aed", "#ea580c", "#db2777", "#475569", "#65a30d"];

let cachedApiBase;
let stickyApiBase;
let dripCampaignsById = new Map();

function setHomeLoading(loading) {
  if (!homeLoadingStatusEl) return;
  if (loading) {
    homeLoadingStatusEl.textContent = "Loading Live Dashboard";
    homeLoadingStatusEl.style.display = "";
  } else {
    homeLoadingStatusEl.textContent = "";
    homeLoadingStatusEl.style.display = "none";
  }
}

function showMessage(text, isError = false) {
  const str = String(text == null ? "" : text);
  if (isError && typeof window.crmHandleAuthErrorMessage === "function" && window.crmHandleAuthErrorMessage(str, isError)) {
    return;
  }
  homeMessageEl.textContent = str;
  homeMessageEl.style.color = isError ? "#c62828" : "#1b5e20";
}

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function getCrmApiBase() {
  if (stickyApiBase !== undefined) return stickyApiBase;
  if (cachedApiBase !== undefined) return cachedApiBase;
  const params = new URLSearchParams(window.location.search);
  const fromQuery = params.get("api");
  if (fromQuery && String(fromQuery).trim()) {
    cachedApiBase = String(fromQuery).trim().replace(/\/$/, "");
    return cachedApiBase;
  }
  const injected =
    typeof window.__CRM_API_ORIGIN__ === "string" ? window.__CRM_API_ORIGIN__.trim().replace(/\/$/, "") : "";
  if (injected) {
    const pageOrigin = window.location.origin.replace(/\/$/, "");
    cachedApiBase = injected === pageOrigin ? "" : injected;
    return cachedApiBase;
  }
  const servedMeta = document.querySelector('meta[name="crm-served-by-api"]');
  if (servedMeta && servedMeta.getAttribute("content") === "1") {
    cachedApiBase = "";
    return cachedApiBase;
  }
  const meta = document.querySelector('meta[name="crm-api-base"]');
  const fromMeta = meta && meta.getAttribute("content");
  if (fromMeta && String(fromMeta).trim()) {
    cachedApiBase = String(fromMeta).trim().replace(/\/$/, "");
    return cachedApiBase;
  }
  const host = window.location.hostname;
  const port = window.location.port || "";
  if ((host === "localhost" || host === "127.0.0.1") && STATIC_DEV_PORTS.has(port)) {
    cachedApiBase = `${window.location.protocol}//${host}:3000`;
    return cachedApiBase;
  }
  cachedApiBase = "";
  return cachedApiBase;
}

function toAbsoluteUrl(url) {
  if (url.startsWith("http://") || url.startsWith("https://")) return url;
  return new URL(url.startsWith("/") ? url : `/${url}`, window.location.href).href;
}

function apiUrl(path) {
  const p = path.startsWith("/") ? path : `/${path}`;
  const base = getCrmApiBase();
  return base ? `${base}${p}` : p;
}

function apiUrlCandidates(path) {
  const p = path.startsWith("/") ? path : `/${path}`;
  const out = [];
  const push = (u) => {
    const abs = toAbsoluteUrl(u);
    if (!out.includes(abs)) out.push(abs);
  };
  push(apiUrl(p));
  const host = window.location.hostname;
  if (host === "localhost" || host === "127.0.0.1") {
    push(`http://127.0.0.1:3000${p}`);
    push(`http://localhost:3000${p}`);
  }
  return out;
}

function rememberSuccessfulApiOrigin(urlUsed) {
  try {
    const origin = new URL(toAbsoluteUrl(urlUsed)).origin.replace(/\/$/, "");
    const pageOrigin = window.location.origin.replace(/\/$/, "");
    stickyApiBase = origin === pageOrigin ? "" : origin;
  } catch {
    // no-op
  }
}

async function fetchApiJson(path) {
  const urls = apiUrlCandidates(path);
  let sawHtml = false;
  let lastStatus = 0;
  let lastUrl = "";
  for (const url of urls) {
    lastUrl = url;
    const response = await fetch(url, { credentials: "include" });
    lastStatus = response.status;
    const text = await response.text();
    const trimmed = text.trim();
    if (!trimmed) continue;
    if (trimmed.startsWith("<")) {
      sawHtml = true;
      continue;
    }
    try {
      const data = JSON.parse(trimmed);
      rememberSuccessfulApiOrigin(url);
      return { response, data };
    } catch {
      // try next candidate
    }
  }
  if (sawHtml) {
    throw new Error(
      `Server returned HTML instead of JSON for ${path} (tried ${lastUrl || "same origin"}). ` +
        "Check https://crmcadence.com/api/health in your browser — it must show JSON, not a web page. " +
        "In cPanel, restart the Node.js app (startup file server.js) and remove duplicate CRM files from public_html."
    );
  }
  throw new Error(`Empty or invalid JSON from API for ${path} (last status ${lastStatus}).`);
}

function titleCase(value) {
  return String(value || "event")
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .split(" ")
    .filter(Boolean)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

function categoryColor(type, idx) {
  if (String(type || "").trim().toLowerCase() === "sold") return "#16a34a";
  return CHART_COLORS[idx % CHART_COLORS.length];
}

function formatLocalTime(value) {
  const d = new Date(value);
  if (!Number.isFinite(d.getTime())) return String(value || "");
  return d.toLocaleString();
}

function formatUnixLocal(sec) {
  const n = Number(sec);
  if (!Number.isFinite(n) || n <= 0) return "";
  return new Date(n * 1000).toLocaleString();
}

function capitalizeWord(value) {
  const text = String(value || "").trim().toLowerCase();
  if (!text) return "";
  return text.charAt(0).toUpperCase() + text.slice(1);
}

function automationStatusClass(status) {
  const s = String(status || "").trim().toLowerCase();
  if (s === "pending") return "home-automation-status--pending";
  if (s === "sent") return "home-automation-status--sent";
  if (s === "failed") return "home-automation-status--failed";
  if (s === "skipped") return "home-automation-status--skipped";
  return "home-automation-status--other";
}

function automationStatusLabel(status) {
  const s = String(status || "").trim().toLowerCase();
  if (s === "pending") return "Scheduled";
  if (s === "sent") return "Sent";
  if (s === "failed") return "Failed";
  if (s === "skipped") return "Skipped";
  return titleCase(s || "Update");
}

function formatUpcomingDueLabel(taskDateRaw, taskTimeRaw) {
  const dateRaw = String(taskDateRaw || "").trim();
  const timeRaw = String(taskTimeRaw || "").trim();
  if (!dateRaw) return "Due: No schedule";
  const dt = new Date(`${dateRaw}T${timeRaw || "23:59:59"}`);
  if (!Number.isFinite(dt.getTime())) return `Due: ${dateRaw}`;
  const datePart = dt.toLocaleDateString();
  const timePart = timeRaw
    ? dt.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })
    : "No time set";
  return `Due: ${datePart} • ${timePart}`;
}

function isTaskPastDue(taskDateRaw, taskTimeRaw) {
  const dateRaw = String(taskDateRaw || "").trim();
  if (!dateRaw) return false;
  const timeRaw = String(taskTimeRaw || "").trim();
  const dt = new Date(`${dateRaw}T${timeRaw || "23:59:59"}`);
  if (!Number.isFinite(dt.getTime())) return false;
  return dt.getTime() < Date.now();
}

function getInitials(name) {
  const parts = String(name || "")
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  if (!parts.length) return "?";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
}

function getAvatarStyle(name) {
  const s = String(name || "").trim();
  let hash = 0;
  for (let i = 0; i < s.length; i += 1) {
    hash = (hash * 31 + s.charCodeAt(i)) >>> 0;
  }
  const hue = hash % 360;
  return {
    background: `hsl(${hue} 78% 92%)`,
    color: `hsl(${hue} 62% 36%)`
  };
}

function taskActionClass(actionType) {
  const normalized = String(actionType || "")
    .trim()
    .toLowerCase();
  if (normalized === "call") return "home-upcoming-item-call";
  if (normalized === "text") return "home-upcoming-item-text";
  if (normalized === "email") return "home-upcoming-item-email";
  return "home-upcoming-item-other";
}

function renderTopStats(totals) {
  const emails = Number(totals?.emailsLast7d || 0);
  const calls = Number(totals?.callsLast7d || 0);
  const sms = Number(totals?.smsLast7d || 0);
  const commsTotal = emails + calls + sms;
  if (homeTotalActivitiesEl)
    homeTotalActivitiesEl.textContent = String(commsTotal || Number(totals?.totalLast7d || 0));
  homeContactsTouchedEl.textContent = String(Number(totals?.newContactsCreatedLast7d || 0));
  homeLast24hEl.textContent = String(Number(totals?.contactsCreatedLast24h || 0));
  homeLast7dEl.textContent = String(Number(totals?.contactsSoldLast7d || 0));
  homeSoldCategoryEl.textContent = String(Number(totals?.soldCategory || 0));
}

function renderCategories(categories) {
  if (!categories.length) {
    homeCategoriesEl.innerHTML = '<div class="home-empty">No activity categories yet.</div>';
    return;
  }
  const max = Math.max(...categories.map((row) => Number(row.count || 0)), 1);
  homeCategoriesEl.innerHTML = categories
    .map((row, idx) => {
      const count = Number(row.count || 0);
      const width = Math.max(6, Math.round((count / max) * 100));
      const label = titleCase(row.type);
      const color = categoryColor(row.type, idx);
      return `<div class="home-category-row">
        <div class="home-category-meta"><span>${escapeHtml(label)}</span><strong>${count}</strong></div>
        <div class="home-category-track"><div class="home-category-fill" style="width:${width}%;background:${color};"></div></div>
      </div>`;
    })
    .join("");
}

function renderDonut(categories) {
  const total = categories.reduce((sum, row) => sum + Number(row.count || 0), 0);
  if (!total) {
    homeCategoryDonutEl.style.background = "#e2e8f0";
    homeCategoryDonutEl.innerHTML = '<span class="home-donut-center">No Data</span>';
    homeDonutLegendEl.innerHTML = "";
    return;
  }
  let cursor = 0;
  const segments = [];
  const legend = [];
  categories.forEach((row, idx) => {
    const count = Number(row.count || 0);
    const pct = (count / total) * 100;
    const start = cursor;
    const end = cursor + pct;
    const color = categoryColor(row.type, idx);
    segments.push(`${color} ${start.toFixed(2)}% ${end.toFixed(2)}%`);
    legend.push(
      `<div class="home-legend-item"><span class="home-legend-dot" style="background:${color};"></span>${escapeHtml(titleCase(row.type))} (${count})</div>`
    );
    cursor = end;
  });
  homeCategoryDonutEl.style.background = `conic-gradient(${segments.join(",")})`;
  homeCategoryDonutEl.innerHTML = `<span class="home-donut-center">${total}</span>`;
  homeDonutLegendEl.innerHTML = legend.join("");
}

function renderUpcomingTasks(tasks) {
  if (!homeUpcomingTasksEl) return;
  if (!tasks.length) {
    homeUpcomingTasksEl.innerHTML = '<div class="home-empty">No upcoming tasks yet.</div>';
    return;
  }
  const sortedTasks = [...tasks].sort((a, b) => {
    const aDate = String(a?.task_date || "").trim();
    const bDate = String(b?.task_date || "").trim();
    const aTime = String(a?.task_time || "").trim();
    const bTime = String(b?.task_time || "").trim();
    const aTs = aDate ? new Date(`${aDate}T${aTime || "23:59:59"}`).getTime() : Number.POSITIVE_INFINITY;
    const bTs = bDate ? new Date(`${bDate}T${bTime || "23:59:59"}`).getTime() : Number.POSITIVE_INFINITY;
    if (aTs !== bTs) return aTs - bTs;
    return Number(a?.id || 0) - Number(b?.id || 0);
  });
  homeUpcomingTasksEl.innerHTML = sortedTasks
    .map((task) => {
      const id = Number(task.contact_id);
      const href =
        Number.isInteger(id) && id > 0
          ? `/contact.html?id=${encodeURIComponent(id)}&full=1&focus=tasks#contactTasksSection`
          : "";
      const itemClass = taskActionClass(task.action_type);
      const whenRawDate = String(task.task_date || "").trim();
      const whenRawTime = String(task.task_time || "").trim();
      const when = formatUpcomingDueLabel(whenRawDate, whenRawTime);
      const pastDue = isTaskPastDue(whenRawDate, whenRawTime);
      const pastDueLabel = pastDue
        ? '<span class="home-upcoming-past-due">Past Due</span>'
        : "";
      const content = `<div class="home-upcoming-item-content">
        <div class="home-upcoming-top">
          <span class="home-upcoming-name">${escapeHtml(String(task.task_name || "-"))}</span>
          <span class="home-upcoming-top-meta">
            ${pastDueLabel}
            <span class="home-upcoming-action">${escapeHtml(String(task.action_type || "Other"))}</span>
          </span>
        </div>
        <div class="home-upcoming-contact">${escapeHtml(String(task.contact_name || `Contact #${id}`))}</div>
        <div class="home-upcoming-when">${escapeHtml(when)}</div>
      </div>`;
      if (!href) return `<div class="home-upcoming-item ${itemClass}">${content}</div>`;
      return `<a class="home-upcoming-item home-upcoming-item-link ${itemClass}" href="${href}">${content}</a>`;
    })
    .join("");
}

function formatBirthdayMd(raw) {
  const s = String(raw || "").trim();
  let m = /^(\d{4})-(\d{1,2})-(\d{1,2})/.exec(s);
  let mo;
  let d;
  if (m) {
    mo = Number(m[2]);
    d = Number(m[3]);
  } else {
    m = /^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})$/.exec(s);
    if (!m) return "";
    mo = Number(m[1]);
    d = Number(m[2]);
  }
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  if (mo < 1 || mo > 12 || d < 1) return "";
  return `${months[mo - 1]} ${d}`;
}

function birthdayWhenLabel(daysAway) {
  const days = Number(daysAway);
  if (days <= 0) return "Today";
  if (days === 1) return "Tomorrow";
  return `in ${days} days`;
}

function birthdayTone(daysAway) {
  const days = Number(daysAway);
  if (days <= 0) return "today";
  if (days <= 7) return "soon";
  return "later";
}

function renderUpcomingBirthdays(rows) {
  if (!homeUpcomingBirthdaysEl) return;
  if (!rows.length) {
    homeUpcomingBirthdaysEl.innerHTML =
      '<div class="home-empty">No upcoming birthdays in the next 30 days.</div>';
    return;
  }
  homeUpcomingBirthdaysEl.innerHTML = rows
    .map((row) => {
      const id = Number(row.contact_id || row.id);
      const href =
        Number.isInteger(id) && id > 0 ? `/contact.html?id=${encodeURIComponent(id)}&full=1` : "";
      const days = Number(row.daysAway);
      const tone = birthdayTone(days);
      const turning = Number(row.turningAge);
      const ageLabel = Number.isFinite(turning) && turning > 0 ? `Turning ${turning}` : "";
      const dateLabel = formatBirthdayMd(row.date_of_birth);
      const content = `<div class="home-upcoming-item-content">
        <div class="home-upcoming-top">
          <span class="home-upcoming-name">${escapeHtml(String(row.full_name || `Contact #${id}`))}</span>
        </div>
        <div class="home-birthday-meta">
          <span class="home-birthday-days home-birthday-days--${tone}">${escapeHtml(birthdayWhenLabel(days))}</span>
          ${dateLabel ? `<span class="home-birthday-age">${escapeHtml(dateLabel)}</span>` : ""}
          ${ageLabel ? `<span class="home-birthday-age">${escapeHtml(ageLabel)}</span>` : ""}
        </div>
      </div>`;
      if (!href) return `<div class="home-upcoming-item">${content}</div>`;
      return `<a class="home-upcoming-item home-upcoming-item-link" href="${href}">${content}</a>`;
    })
    .join("");
}

function renderRecent(recent) {
  if (!recent.length) {
    homeRecentActivitiesEl.innerHTML = '<div class="home-empty">No recent activities yet.</div>';
    return;
  }
  homeRecentActivitiesEl.innerHTML = recent
    .map((item) => {
      const activityType = String(item.activity_type || "").trim().toLowerCase();
      const label = titleCase(activityType);
      const rawDetail = String(item.detail || "");
      const detail =
        activityType === "email"
          ? rawDetail.toLowerCase().startsWith("email opened")
            ? "Email Opened"
            : "Email Sent"
          : escapeHtml(rawDetail || "-");
      const contactNameRaw = String(item.contact_name || `Contact #${item.contact_id}`);
      const contactName = escapeHtml(contactNameRaw);
      const initials = getInitials(contactNameRaw);
      const avatarStyle = getAvatarStyle(contactNameRaw);
      const contactId = Number(item.contact_id);
      const contactHref = Number.isInteger(contactId) && contactId > 0 ? `/contact.html?id=${encodeURIComponent(contactId)}` : "";
      const time = escapeHtml(formatLocalTime(item.created_at));
      const content = `<div class="home-recent-item-content">
        <div class="home-recent-body">
          <div class="home-recent-avatar" style="background:${avatarStyle.background};color:${avatarStyle.color};">${escapeHtml(
            initials
          )}</div>
          <div class="home-recent-main">
            <div class="home-recent-top">
              <span class="home-recent-type">${escapeHtml(label)}</span>
              <span class="home-recent-time">${time}</span>
            </div>
            <div class="home-recent-contact">${contactName}</div>
            <div class="home-recent-detail">${detail}</div>
          </div>
        </div>
      </div>`;
      if (!contactHref) return `<div class="home-recent-item">${content}</div>`;
      return `<a class="home-recent-item home-recent-item-link" href="${contactHref}">${content}</a>`;
    })
    .join("");
}

function buildGraphicsCategories(activityCategories, totals) {
  return Array.isArray(activityCategories) ? [...activityCategories] : [];
}

function formatUnixUtc(sec) {
  const n = Number(sec);
  if (!Number.isFinite(n)) return "";
  return new Date(n * 1000).toISOString().replace("T", " ").replace(/\.\d{3}Z$/, " UTC");
}

function summarizeDripQueueRows(rows) {
  const summary = { total: rows.length, sent: 0, pending: 0, failed: 0, skipped: 0, latest: 0 };
  for (const row of rows) {
    const status = String(row.status || "").toLowerCase();
    if (status === "sent") summary.sent += 1;
    else if (status === "pending") summary.pending += 1;
    else if (status === "failed") summary.failed += 1;
    else if (status === "skipped") summary.skipped += 1;
    const stamp = Number(row.scheduled_at);
    if (Number.isFinite(stamp) && stamp > summary.latest) summary.latest = stamp;
  }
  return summary;
}

async function loadDripCampaignMap() {
  const { response, data: list } = await fetchApiJson("/api/drip/campaigns");
  if (!response.ok) throw new Error(list.error || "Failed to load campaigns");
  const campaigns = Array.isArray(list) ? list : [];
  dripCampaignsById = new Map(campaigns.map((campaign) => [Number(campaign.id), campaign]));
  return campaigns;
}

function dripProblemListHtml(rows) {
  const problems = rows.filter((row) => {
    const status = String(row.status || "").toLowerCase();
    return status === "failed" || status === "skipped";
  });
  if (!problems.length) return "";
  return `<ul class="drip-problem-list">${problems
    .map((row) => {
      const status = String(row.status || "").toLowerCase();
      const contactId = Number(row.contact_id) || 0;
      const name = escapeHtml(row.full_name || "Unknown");
      const nameHtml =
        contactId > 0 ? `<a href="/contact.html?id=${encodeURIComponent(contactId)}">${name}</a>` : name;
      const stepOrder = Number(row.step_order);
      const stepLabel = Number.isFinite(stepOrder) ? `Step ${stepOrder + 1}` : "Step";
      const err = String(row.error_message || "").trim();
      const label = status === "failed" ? "Failed" : "Skipped";
      return `<li><strong>${label}</strong> · ${nameHtml} · ${escapeHtml(capitalizeWord(row.channel))} · ${escapeHtml(
        stepLabel
      )}${err ? ` · ${escapeHtml(err)}` : ""}</li>`;
    })
    .join("")}</ul>`;
}

function paintDripStatColors(root) {
  const colors = {
    "pending sms": "#2563eb",
    pending: "#2563eb",
    "sent successful": "#16a34a",
    failed: "#7c3aed",
  };
  const scope = root && typeof root.querySelectorAll === "function" ? root : document;
  scope.querySelectorAll(".drip-metric-card, .drip-campaign-stat").forEach((node) => {
    const labelEl = node.querySelector("span");
    const label = String(labelEl ? labelEl.textContent : "").trim().toLowerCase();
    const color = colors[label];
    if (color) node.style.setProperty("background", color, "important");
  });
}

function renderDripCampaignBlocks(items, runningCampaignCountByContact = new Map(), campaignSummaries = null) {
  if (!dripCampaignBlocksEl) return;
  const summaryById = new Map(
    (Array.isArray(campaignSummaries) ? campaignSummaries : []).map((row) => [Number(row.campaignId) || 0, row])
  );
  if (!items.length && !summaryById.size) {
    dripCampaignBlocksEl.innerHTML = '<div class="contact-history-empty">No drip activity yet.</div>';
    return;
  }
  const grouped = new Map();
  for (const row of items) {
    const key = Number(row.campaign_id) || 0;
    if (!grouped.has(key)) grouped.set(key, []);
    grouped.get(key).push(row);
  }
  for (const campaignId of summaryById.keys()) {
    if (!grouped.has(campaignId)) grouped.set(campaignId, []);
  }
  const groups = [...grouped.entries()]
    .map(([campaignId, rows]) => {
      const counted = summaryById.get(campaignId);
      const fromRows = summarizeDripQueueRows(rows);
      const summary = counted
        ? {
            total: Number(counted.contacts || 0),
            sent: Number(counted.sent || 0),
            pending: Number(counted.pending || 0),
            failed: Number(counted.failed || 0),
            skipped: Number(counted.skipped || 0),
            latest: Number(counted.latest || fromRows.latest || 0),
            totalLabel: "Contacts"
          }
        : { ...fromRows, totalLabel: "Total" };
      return { campaignId, rows, summary };
    })
    .sort((a, b) => b.summary.latest - a.summary.latest);

  dripCampaignBlocksEl.innerHTML = groups
    .map(({ campaignId, rows, summary }) => {
      const campaign = dripCampaignsById.get(campaignId);
      const campaignName = escapeHtml((campaign && campaign.name) || "Campaign");
      const activeBadge = summary.failed > 0 ? "Needs attention" : summary.pending > 0 ? "Active" : "Healthy";
      const badgeClass =
        summary.failed > 0 ? "drip-campaign-badge drip-campaign-badge--attention" : "drip-campaign-badge";
      const latestText = summary.latest ? formatUnixUtc(summary.latest) : "No schedule time";
      const rankedRows = [...rows].sort((a, b) => {
        const rank = (row) => {
          const status = String(row.status || "").toLowerCase();
          if (status === "failed") return 0;
          if (status === "skipped") return 1;
          if (status === "pending") return 2;
          return 3;
        };
        return rank(a) - rank(b);
      });
      const topContactsHtml = rankedRows
        .slice(0, 3)
        .map((row) => {
          const contactId = Number(row.contact_id) || 0;
          const running = Number(runningCampaignCountByContact.get(contactId) || 0);
          const runLabel = `${running} running campaign${running === 1 ? "" : "s"}`;
          const contactRows = rows.filter((r) => Number(r.contact_id) === contactId);
          const pendingSteps = contactRows.filter((r) => String(r.status || "").toLowerCase() === "pending").length;
          const failedSteps = contactRows.filter((r) => String(r.status || "").toLowerCase() === "failed").length;
          let enrolledBadge = "";
          if (contactRows.length > 0) {
            enrolledBadge =
              failedSteps > 0
                ? '<span class="drip-enrolled-badge drip-enrolled-badge--failed">Failed</span>'
                : pendingSteps > 0
                  ? '<span class="drip-enrolled-badge drip-enrolled-badge--live">Enrolled Live</span>'
                  : '<span class="drip-enrolled-badge drip-enrolled-badge--completed">Completed</span>';
          } else if (running > 0) {
            enrolledBadge = '<span class="drip-enrolled-badge drip-enrolled-badge--live">Enrolled Live</span>';
          }
          return `<span class="drip-contact-chip">${escapeHtml(row.full_name || "Unknown")} (${escapeHtml(
            capitalizeWord(row.channel)
          )} · ${escapeHtml(runLabel)}) ${enrolledBadge}</span>`;
        })
        .join("");
      return `
        <article class="drip-campaign-block">
          <div class="drip-campaign-head">
            <div>
              <h4>${campaignName}</h4>
              <p>Latest schedule: ${escapeHtml(latestText)}</p>
            </div>
            <span class="${badgeClass}">${activeBadge}</span>
          </div>
          ${
            summary.failed > 0
              ? `<p class="drip-attention-note">Needs attention means a message in this campaign did not send.</p>`
              : ""
          }
          <div class="drip-campaign-stat-grid">
            <div class="drip-campaign-stat drip-campaign-stat--dark"><span>${escapeHtml(summary.totalLabel || "Contacts")}</span><strong>${summary.total}</strong></div>
            <div class="drip-campaign-stat drip-campaign-stat--sent" style="background:#16a34a"><span>Sent Successful</span><strong>${summary.sent}</strong></div>
            <div class="drip-campaign-stat drip-campaign-stat--pending" style="background:#2563eb"><span>Pending</span><strong>${summary.pending}</strong></div>
            <div class="drip-campaign-stat drip-campaign-stat--failed" style="background:#7c3aed"><span>Failed</span><strong>${summary.failed}</strong></div>
          </div>
          ${dripProblemListHtml(rows)}
          <p class="drip-campaign-footnote">${
            topContactsHtml || '<span class="drip-contact-chip">No contact details available yet.</span>'
          }</p>
        </article>
      `;
    })
    .join("");
}

async function loadDripQueueDashboard() {
  if (!dripCampaignBlocksEl && !dripMetricPendingEl) return;
  await loadDripCampaignMap();
  const { response, data: payload } = await fetchApiJson("/api/drip/queue?summary=1&limit=80");
  if (!response.ok) throw new Error(payload.error || "Failed to load queue");
  const items = Array.isArray(payload) ? payload : Array.isArray(payload?.rows) ? payload.rows : [];
  const campaignSummaries = Array.isArray(payload?.campaigns) ? payload.campaigns : null;
  const queueTotals = payload && payload.totals && typeof payload.totals === "object" ? payload.totals : null;
  const activeRows = items.filter((row) => String(row.status || "").toLowerCase() === "pending");
  const runningCampaignIdsByContact = new Map();
  for (const row of activeRows) {
    const contactId = Number(row.contact_id);
    const campaignId = Number(row.campaign_id);
    if (!Number.isInteger(contactId) || contactId < 1 || !Number.isInteger(campaignId) || campaignId < 1) continue;
    if (!runningCampaignIdsByContact.has(contactId)) runningCampaignIdsByContact.set(contactId, new Set());
    runningCampaignIdsByContact.get(contactId).add(campaignId);
  }
  const runningCampaignCountByContact = new Map(
    [...runningCampaignIdsByContact.entries()].map(([contactId, campaignIds]) => [contactId, campaignIds.size])
  );
  const runningCampaignsTotal = queueTotals
    ? Number(queueTotals.campaigns || 0)
    : [...runningCampaignCountByContact.values()].reduce((sum, n) => sum + Number(n || 0), 0);
  const pendingCount = queueTotals
    ? Number(queueTotals.pending || 0)
    : items.filter((row) => String(row.status || "").toLowerCase() === "pending").length;
  const sentCount = queueTotals
    ? Number(queueTotals.sent || 0)
    : items.filter((row) => String(row.status || "").toLowerCase() === "sent").length;
  const failedCount = queueTotals
    ? Number(queueTotals.failed || 0)
    : items.filter((row) => String(row.status || "").toLowerCase() === "failed").length;
  if (dripMetricCampaignsEl) dripMetricCampaignsEl.textContent = String(runningCampaignsTotal);
  if (dripMetricPendingEl) dripMetricPendingEl.textContent = String(pendingCount);
  if (dripMetricSentEl) dripMetricSentEl.textContent = String(sentCount);
  if (dripMetricFailedEl) dripMetricFailedEl.textContent = String(failedCount);
  renderDripCampaignBlocks(items, runningCampaignCountByContact, campaignSummaries);
  paintDripStatColors(document);
}

function renderRunningAutomations(rows) {
  if (!homeRunningAutomationsEl) return;
  if (!rows.length) {
    homeRunningAutomationsEl.innerHTML = '<div class="home-empty">No automations running right now.</div>';
    return;
  }
  homeRunningAutomationsEl.innerHTML = rows
    .map((row) => {
      const contactId = Number(row.contact_id);
      const href =
        Number.isInteger(contactId) && contactId > 0
          ? `/contact.html?id=${encodeURIComponent(contactId)}`
          : "";
      const contactName = escapeHtml(String(row.contact_name || `Contact #${contactId}`));
      const campaignName = escapeHtml(String(row.campaign_name || "Campaign"));
      const channel = capitalizeWord(row.next_channel || "step");
      const stepOrder = Number(row.next_step_order);
      const stepLabel = Number.isFinite(stepOrder) ? `Step ${stepOrder + 1}` : "Next step";
      const pending = Number(row.pending_count || 0);
      const when = formatUnixLocal(row.next_scheduled_at);
      const detail = `${channel} · ${stepLabel} · ${pending} pending`;
      const content = `<div class="home-automation-item-content">
        <div class="home-automation-top">
          <span class="home-automation-status home-automation-status--running">Running</span>
          <span class="home-automation-time">${escapeHtml(when || "Scheduled")}</span>
        </div>
        <div class="home-automation-contact">${contactName}</div>
        <div class="home-automation-campaign">${campaignName}</div>
        <div class="home-automation-detail">${escapeHtml(detail)}</div>
      </div>`;
      if (!href) return `<div class="home-automation-item home-automation-item--running">${content}</div>`;
      return `<a class="home-automation-item home-automation-item-link home-automation-item--running" href="${href}">${content}</a>`;
    })
    .join("");
}

function renderPastAutomations(rows) {
  if (!homePastAutomationsEl) return;
  if (!rows.length) {
    homePastAutomationsEl.innerHTML = '<div class="home-empty">No automation activity in the last 7 days.</div>';
    return;
  }
  homePastAutomationsEl.innerHTML = rows
    .map((row) => {
      const contactId = Number(row.contact_id);
      const href =
        Number.isInteger(contactId) && contactId > 0
          ? `/contact.html?id=${encodeURIComponent(contactId)}`
          : "";
      const contactName = escapeHtml(String(row.contact_name || `Contact #${contactId}`));
      const campaignName = escapeHtml(String(row.campaign_name || "Campaign"));
      const channel = capitalizeWord(row.channel || "step");
      const status = String(row.status || "").toLowerCase();
      const statusClass = automationStatusClass(status);
      const statusLabel = automationStatusLabel(status);
      const when = formatUnixLocal(row.sent_at || row.scheduled_at);
      const stepOrder = Number(row.step_order);
      const stepLabel = Number.isFinite(stepOrder) ? `Step ${stepOrder + 1}` : "Step";
      const err = String(row.error_message || "").trim();
      const errHtml = err ? `<div class="home-automation-error">${escapeHtml(err)}</div>` : "";
      const content = `<div class="home-automation-item-content">
        <div class="home-automation-top">
          <span class="home-automation-status ${statusClass}">${escapeHtml(statusLabel)}</span>
          <span class="home-automation-time">${escapeHtml(when)}</span>
        </div>
        <div class="home-automation-contact">${contactName}</div>
        <div class="home-automation-campaign">${campaignName}</div>
        <div class="home-automation-detail">${escapeHtml(`${channel} · ${stepLabel}`)}</div>
        ${errHtml}
      </div>`;
      if (!href) return `<div class="home-automation-item">${content}</div>`;
      return `<a class="home-automation-item home-automation-item-link" href="${href}">${content}</a>`;
    })
    .join("");
}

async function loadAutomationsDashboard() {
  const { response, data } = await fetchApiJson("/api/drip/automations-dashboard");
  if (!response.ok) throw new Error(data.error || "Failed to load automations");
  renderRunningAutomations(Array.isArray(data.running) ? data.running : []);
  renderPastAutomations(Array.isArray(data.past7d) ? data.past7d : []);
}

/** Snapshot of contact counts per Status / Outcome / Lead Source. Pills deep-link
 *  to Contacts Workspace filtered to that segment. Usage data is owner-only — the
 *  whole section hides on any failure so trial dashboards are unaffected. */
const SNAPSHOT_TOP_N = 6;
const SNAPSHOT_ACCENTS = { status: "#7f77dd", outcome: "#1d9e75", lead_source: "#d85a30" };

/** Canonical display names — DB/CSV often stores compacted forms like "hascoverage". */
const SNAPSHOT_CANONICAL_LABELS = {
  status: ["NEW", "PENDING", "APPROVED", "DECLINED", "CLOSED", "WORKING", "NOT TAKEN", "REFERRED"],
  outcome: [
    "Bad Email",
    "Bad Number",
    "Call Back",
    "Cannot Afford",
    "Cannot Insure",
    "Cannot Meet",
    "Cold",
    "DECLINED",
    "DNC",
    "Drip Campaign",
    "Employer Plan",
    "Fake Lead",
    "Has Coverage",
    "Long Term CB",
    "No Contact",
    "No Answer",
    "Not Interested",
    "Referred",
    "Rude",
    "SOLD",
    "Stop",
    "Stopped Responding",
    "Too Many Calls",
    "Very Interested",
    "Wrong Number",
    "Connected",
    "Busy"
  ],
  lead_source: [
    "Website",
    "Referral",
    "Telemarketing",
    "Facebook",
    "Instagram",
    "Google",
    "Nextgen",
    "Marketplace",
    "healthcare.gov",
    "Budget",
    "Solar"
  ]
};

function snapshotNormKey(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[\s-]+/g, "");
}

function snapshotLabelPrettyScore(label) {
  const s = String(label || "").trim();
  if (!s) return -1;
  let score = 0;
  if (/\s/.test(s)) score += 8;
  if (/[A-Z]/.test(s) && /[a-z]/.test(s)) score += 4;
  if (/^[A-Z0-9][A-Z0-9 /&+-]*$/.test(s)) score += 6; // all-caps status-style
  if (s !== s.toLowerCase()) score += 2;
  if (/[-_]/.test(s)) score += 1;
  // Penalize compacted slug forms: "hascoverage", "referred"
  if (s === s.toLowerCase() && !/[\s_-]/.test(s)) score -= 10;
  score += Math.min(s.length, 48) * 0.01;
  return score;
}

function resolveSnapshotDisplayLabel(norm, candidates, param) {
  if (!norm) return "";
  const pool = [];
  const seen = new Set();
  for (const list of [SNAPSHOT_CANONICAL_LABELS[param] || [], candidates || []]) {
    for (const item of list) {
      const text = String(item || "").trim();
      if (!text) continue;
      const key = text.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      pool.push(text);
    }
  }
  let best = "";
  let bestScore = -1;
  for (const label of pool) {
    if (snapshotNormKey(label) !== norm) continue;
    const score = snapshotLabelPrettyScore(label);
    if (score > bestScore) {
      best = label;
      bestScore = score;
    }
  }
  let display = best || titleCase(String((candidates && candidates[0]) || norm).trim());
  // Status chips in this panel are all-caps (NEW, APPROVED, …).
  if (param === "status" && display) display = display.toUpperCase();
  return display;
}

function renderLabelSnapshot(groups) {
  if (!homeSnapshotEl) return;
  const html = groups
    .map((g) => {
      const countsByNorm = new Map();
      const rawByNorm = new Map();
      for (const [key, raw] of Object.entries(g.counts || {})) {
        const text = String(key || "").trim();
        const norm = snapshotNormKey(text);
        if (!norm) continue;
        countsByNorm.set(norm, (countsByNorm.get(norm) || 0) + (Number(raw) || 0));
        const bucket = rawByNorm.get(norm) || [];
        if (text && !bucket.some((item) => item.toLowerCase() === text.toLowerCase())) bucket.push(text);
        rawByNorm.set(norm, bucket);
      }
      const optionLabels = Array.isArray(g.labels) ? g.labels.map((x) => String(x || "").trim()).filter(Boolean) : [];
      const allNorms = new Set([...countsByNorm.keys()]);
      for (const label of optionLabels) {
        const norm = snapshotNormKey(label);
        if (norm) allNorms.add(norm);
      }
      const items = [...allNorms].map((norm) => {
        const candidates = [...(rawByNorm.get(norm) || []), ...optionLabels.filter((l) => snapshotNormKey(l) === norm)];
        return {
          label: resolveSnapshotDisplayLabel(norm, candidates, g.param),
          count: countsByNorm.get(norm) || 0
        };
      });
      const withCounts = items.sort((a, b) => b.count - a.count || a.label.localeCompare(b.label));
      const total = withCounts.reduce((sum, it) => sum + it.count, 0);
      const max = withCounts.length ? withCounts[0].count : 0;
      const rowHtml = (it) => {
        const pct = it.count > 0 && max > 0 ? Math.max(4, Math.round((it.count / max) * 100)) : 0;
        return (
          `<a class="home-snapshot-row" href="/index.html?${g.param}=${encodeURIComponent(it.label)}" title="View ${escapeHtml(it.label)} contacts">` +
          `<span class="home-snapshot-row-head"><span class="home-snapshot-row-name">${escapeHtml(it.label)}</span>` +
          `<span class="home-snapshot-row-count">${it.count.toLocaleString()}</span></span>` +
          `<span class="home-snapshot-row-bar" style="width:${pct}%"></span></a>`
        );
      };
      let body;
      if (!withCounts.length) {
        body = `<div class="home-empty">No contacts yet</div>`;
      } else {
        const top = withCounts.slice(0, SNAPSHOT_TOP_N).map(rowHtml).join("");
        const rest = withCounts.slice(SNAPSHOT_TOP_N);
        body =
          top +
          (rest.length
            ? `<div class="home-snapshot-extra" hidden>${rest.map(rowHtml).join("")}</div>` +
              `<button type="button" class="home-snapshot-more" data-snap-more data-more-count="${rest.length}">+ ${rest.length} more</button>`
            : "");
      }
      const accent = SNAPSHOT_ACCENTS[g.param] || "#4f46e5";
      return (
        `<article class="panel home-snapshot-group" style="--snap-accent:${accent}">` +
        `<div class="home-snapshot-group-head"><h3 class="home-snapshot-group-title">${escapeHtml(g.title)}</h3>` +
        `<span class="home-snapshot-group-total">${total.toLocaleString()}</span></div>` +
        `<div class="home-snapshot-bars">${body}</div></article>`
      );
    })
    .join("");
  homeSnapshotEl.innerHTML = html;
  homeSnapshotEl.querySelectorAll("[data-snap-more]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const extra = btn.previousElementSibling;
      if (!extra) return;
      if (extra.hasAttribute("hidden")) {
        extra.removeAttribute("hidden");
        btn.textContent = "Show less";
      } else {
        extra.setAttribute("hidden", "");
        btn.textContent = `+ ${btn.getAttribute("data-more-count")} more`;
      }
    });
  });
}

async function loadLabelSnapshot() {
  const section = document.getElementById("homeSnapshotSection");
  const hide = () => {
    if (section) section.style.display = "none";
  };
  try {
    const [optRes, useRes] = await Promise.all([
      fetchApiJson("/api/contacts/workspace-options"),
      fetchApiJson("/api/settings/contact-workspace-options/usage")
    ]);
    if (!useRes.response.ok) return hide();
    const options = optRes.response.ok ? optRes.data || {} : {};
    const usage = useRes.data || {};
    const groups = [
      { title: "Status", param: "status", labels: options.statusLabels || [], counts: usage.status || {} },
      { title: "Outcome", param: "outcome", labels: options.outcomeLabels || [], counts: usage.outcome || {} },
      { title: "Lead Source", param: "lead_source", labels: options.leadSourceLabels || [], counts: usage.leadSource || {} }
    ];
    if (!groups.some((g) => Object.keys(g.counts).length)) return hide();
    if (section) section.style.display = "";
    renderLabelSnapshot(groups);
  } catch {
    hide();
  }
}

function homeFormatCampaignDate(unix) {
  if (!unix) return "";
  try { return new Date(Number(unix) * 1000).toLocaleDateString(); } catch { return ""; }
}

async function loadEmailCampaigns() {
  if (!homeEmailCampaignsEl) return;
  const { response, data } = await fetchApiJson("/api/email/bulk-campaign/active");
  if (!response.ok) throw new Error((data && data.error) || "Failed to load email campaigns");
  const campaigns = Array.isArray(data.campaigns) ? data.campaigns : [];
  if (!campaigns.length) {
    homeEmailCampaignsEl.innerHTML = '<div class="home-empty">No email campaigns sending right now.</div>';
    return;
  }
  homeEmailCampaignsEl.innerHTML = campaigns
    .map((c) => {
      const bits = [Number(c.sent || 0).toLocaleString() + " sent", Number(c.pending || 0).toLocaleString() + " pending"];
      if (c.paused) bits.push(Number(c.paused).toLocaleString() + " paused");
      if (c.perHour) bits.push(c.perHour + "/hour");
      if (c.pending && c.estFinishAt) bits.push("finishes ~" + homeFormatCampaignDate(c.estFinishAt));
      return (
        '<div class="home-email-campaign-row" style="display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 0;border-top:1px solid #eef0f4;">' +
        '<span style="flex:1;min-width:0;font-size:13px;color:#334155;"><strong>' +
        escapeHtml(String(c.tag || "Campaign")) +
        "</strong> &mdash; " +
        escapeHtml(bits.join(" · ")) +
        "</span>" +
        '<a href="/email.html" style="flex:0 0 auto;font-size:12px;font-weight:600;color:#4f46e5;text-decoration:none;">View &rarr;</a>' +
        "</div>"
      );
    })
    .join("");
}

async function loadEmailOpenStats() {
  const { response, data } = await fetchApiJson("/api/email/open-stats");
  if (!response.ok) throw new Error(data.error || "Failed to load email open stats");
  if (homeEmailOpens24hEl) homeEmailOpens24hEl.textContent = String(Number(data.last24h || 0));
  if (homeEmailOpens7dEl) homeEmailOpens7dEl.textContent = String(Number(data.last7d || 0));
}

async function loadEmailClickStats() {
  const { response, data } = await fetchApiJson("/api/email/click-stats");
  if (!response.ok) throw new Error(data.error || "Failed to load email click stats");
  if (homeEmailClicks24hEl) homeEmailClicks24hEl.textContent = String(Number(data.last24h || 0));
  if (homeEmailClicks7dEl) homeEmailClicks7dEl.textContent = String(Number(data.last7d || 0));
}

async function loadEmailSentStats() {
  const { response, data } = await fetchApiJson("/api/email/sent-stats");
  if (!response.ok) throw new Error(data.error || "Failed to load email sent stats");
  if (homeEmailSent24hEl) homeEmailSent24hEl.textContent = String(Number(data.last24h || 0));
  if (homeEmailSent7dEl) homeEmailSent7dEl.textContent = String(Number(data.last7d || 0));
}

async function loadHome() {
  setHomeLoading(true);
  showMessage("");
  try {
    const [summaryRes, taskRes, birthdayRes] = await Promise.all([
      fetchApiJson("/api/activities/summary?scope=dashboard"),
      fetchApiJson("/api/tasks/upcoming?limit=100"),
      fetchApiJson("/api/contacts/upcoming-birthdays?days=30&limit=20").catch((err) => ({
        response: { ok: false },
        data: { error: err && err.message }
      }))
    ]);
    const { response, data } = summaryRes;
    if (!response.ok) throw new Error(data.error || "Failed to load activity summary");
    if (!taskRes.response.ok) throw new Error(taskRes.data.error || "Failed to load upcoming tasks");
    const totals = data.totals || {};
    const categories = buildGraphicsCategories(data.categories, totals);
    renderTopStats(totals);
    renderCategories(categories);
    renderDonut(categories);
    const taskRows = Array.isArray(taskRes.data) ? taskRes.data : [];
    renderUpcomingTasks(taskRows);
    const birthdayRows = Array.isArray(birthdayRes.data)
      ? birthdayRes.data
      : Array.isArray(birthdayRes.data?.birthdays)
        ? birthdayRes.data.birthdays
        : [];
    if (birthdayRes.response.ok) renderUpcomingBirthdays(birthdayRows);
    else if (homeUpcomingBirthdaysEl) {
      homeUpcomingBirthdaysEl.innerHTML = '<div class="home-empty">Could not load birthdays.</div>';
    }
    if (typeof window.CadenceTaskReminder?.start === "function") {
      window.CadenceTaskReminder.start(taskRows);
    }
    renderRecent(Array.isArray(data.recent) ? data.recent : []);
    await loadLabelSnapshot();
    try {
      await loadEmailOpenStats();
    } catch (openErr) {
      if (homeEmailOpens24hEl) homeEmailOpens24hEl.textContent = "—";
      if (homeEmailOpens7dEl) homeEmailOpens7dEl.textContent = "—";
    }
    try {
      await loadEmailClickStats();
    } catch (clickErr) {
      if (homeEmailClicks24hEl) homeEmailClicks24hEl.textContent = "—";
      if (homeEmailClicks7dEl) homeEmailClicks7dEl.textContent = "—";
    }
    try {
      await loadEmailSentStats();
    } catch (sentErr) {
      if (homeEmailSent24hEl) homeEmailSent24hEl.textContent = "—";
      if (homeEmailSent7dEl) homeEmailSent7dEl.textContent = "—";
    }
    try {
      await loadAutomationsDashboard();
    } catch (autoErr) {
      const msg = escapeHtml(String(autoErr?.message || "Could not load automations"));
      if (homeRunningAutomationsEl) homeRunningAutomationsEl.innerHTML = `<div class="home-empty">${msg}</div>`;
      if (homePastAutomationsEl) homePastAutomationsEl.innerHTML = `<div class="home-empty">${msg}</div>`;
    }
    try {
      await loadDripQueueDashboard();
    } catch (queueErr) {
      const msg = escapeHtml(String(queueErr?.message || "Could not load drip queue"));
      if (dripCampaignBlocksEl) dripCampaignBlocksEl.innerHTML = `<div class="contact-history-empty">${msg}</div>`;
    }
    try {
      await loadEmailCampaigns();
    } catch (campErr) {
      const msg = escapeHtml(String(campErr?.message || "Could not load email campaigns"));
      if (homeEmailCampaignsEl) homeEmailCampaignsEl.innerHTML = `<div class="home-empty">${msg}</div>`;
    }
    showMessage(`Updated ${new Date().toLocaleTimeString()}`);
  } finally {
    setHomeLoading(false);
  }
}

async function ensureAuthenticated() {
  try {
    const { response, data } = await fetchApiJson("/api/auth/status");
    if (!response.ok) return true;
    if (data.loginRequired && !data.authenticated) {
      const next = window.location.pathname + window.location.search;
      window.location.href = `/login.html?next=${encodeURIComponent(next)}`;
      return false;
    }
  } catch {
    // API unreachable — loadHome will surface the error.
  }
  return true;
}

homeRefreshBtn.addEventListener("click", () => {
  loadHome().catch((error) => showMessage(error.message, true));
});

if (homeRefreshDripQueueBtn) {
  homeRefreshDripQueueBtn.addEventListener("click", () => {
    loadDripQueueDashboard().catch((error) => showMessage(error.message, true));
    loadEmailCampaigns().catch((error) => showMessage(error.message, true));
  });
}

ensureAuthenticated().then((ok) => {
  if (ok === false) return;
  loadHome().catch((error) => showMessage(error.message, true));
});
