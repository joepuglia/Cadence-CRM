(function () {
  const STORAGE_KEY = "crm.emailOpenNotifier.lastSeenUnix";
  const STORAGE_ID_KEY = "crm.emailOpenNotifier.lastSeenId";
  const SESSION_INIT_KEY = "crm.emailOpenNotifier.sessionInit";
  const POLL_MS = 20000;
  const DEFAULT_LOOKBACK_SECONDS = 5 * 60;
  const MAX_FUTURE_SKEW_SECONDS = 30;
  /** Wall clock skew: server unix minus local unix (updated from API). */
  let serverSkewSec = 0;
  let timer = null;
  let inFlight = false;
  let lastEventUnix = 0;
  /** After manual reset with lookback, skip replaying events at or before this unix. */
  let ignoreEventsThroughUnix = 0;
  let audioCtx = null;
  let audioUnlocked = false;
  const notifiedKeysThisSession = new Set();

  function approxServerUnix() {
    return Math.floor(Date.now() / 1000) + serverSkewSec;
  }

  function getApiBase() {
    const injected =
      typeof window.__CRM_API_ORIGIN__ === "string" ? window.__CRM_API_ORIGIN__.trim().replace(/\/$/, "") : "";
    if (injected) return injected;
    const meta = document.querySelector('meta[name="crm-api-base"]');
    const fromMeta = meta && meta.getAttribute("content");
    return fromMeta ? String(fromMeta).trim().replace(/\/$/, "") : "";
  }

  function apiUrl(path) {
    const p = path.startsWith("/") ? path : `/${path}`;
    const base = getApiBase();
    return base ? `${base}${p}` : p;
  }

  function readLastSeenUnix() {
    const now = approxServerUnix();
    try {
      const raw = Number(window.localStorage.getItem(STORAGE_KEY) || 0);
      if (Number.isFinite(raw) && raw > 0) {
        const n = Math.floor(raw);
        if (n > now + MAX_FUTURE_SKEW_SECONDS) {
          const safe = Math.max(0, now - DEFAULT_LOOKBACK_SECONDS);
          try {
            window.localStorage.setItem(STORAGE_KEY, String(Math.floor(safe)));
            window.localStorage.removeItem(STORAGE_ID_KEY);
          } catch {
            // ignore
          }
          return Math.floor(safe);
        }
        return n;
      }
    } catch {
      // ignore
    }
    return Math.max(0, now - DEFAULT_LOOKBACK_SECONDS);
  }

  function writeLastSeenUnix(v) {
    const n = Number(v);
    if (!Number.isFinite(n) || n <= 0) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, String(Math.floor(n)));
    } catch {
      // ignore
    }
  }

  function readLastSeenId() {
    try {
      const raw = Number(window.localStorage.getItem(STORAGE_ID_KEY) || 0);
      if (Number.isFinite(raw) && raw > 0) return Math.floor(raw);
    } catch {
      // ignore
    }
    return 0;
  }

  function writeLastSeenId(v) {
    const n = Number(v);
    if (!Number.isFinite(n) || n <= 0) return;
    try {
      window.localStorage.setItem(STORAGE_ID_KEY, String(Math.floor(n)));
    } catch {
      // ignore
    }
  }

  function eventNotifyKey(item) {
    const id = Number(item?.id || 0);
    const unix = Math.floor(Number(item?.createdAtUnix || 0));
    return `${unix}:${id}`;
  }

  function resetAlertCursor(secondsBack = DEFAULT_LOOKBACK_SECONDS) {
    const now = approxServerUnix();
    const back = Number(secondsBack);
    const safeBack = Number.isFinite(back) && back >= 0 ? Math.floor(back) : DEFAULT_LOOKBACK_SECONDS;
    const cursor = Math.max(0, now - safeBack);
    writeLastSeenUnix(cursor);
    ignoreEventsThroughUnix = safeBack > 0 ? cursor : 0;
    try {
      window.localStorage.removeItem(STORAGE_ID_KEY);
    } catch {
      // ignore
    }
    notifiedKeysThisSession.clear();
  }

  function initSessionCursorIfNeeded() {
    let initialized = false;
    try {
      initialized = window.sessionStorage.getItem(SESSION_INIT_KEY) === "1";
    } catch {
      initialized = false;
    }
    if (initialized) return;
    resetAlertCursor(0);
    try {
      window.sessionStorage.setItem(SESSION_INIT_KEY, "1");
    } catch {
      // ignore
    }
  }

  function formatUnixLocal(unixSeconds) {
    const n = Number(unixSeconds);
    if (!Number.isFinite(n) || n <= 0) return "never";
    try {
      return new Date(n * 1000).toLocaleString();
    } catch {
      return "unknown";
    }
  }

  function removeLegacyStatusBadge() {
    try {
      const existing = document.getElementById("crmEmailOpenNotifierStatus");
      if (existing && existing.parentNode) existing.parentNode.removeChild(existing);
    } catch {
      // ignore
    }
  }

  async function fetchJson(path) {
    const resp = await fetch(apiUrl(path), { credentials: "include" });
    const text = await resp.text();
    let data = {};
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      data = {};
    }
    return { resp, data };
  }

  function refreshServerSkewFromPayload(data) {
    const t = Number(data?.serverNowUnix ?? data?.unix ?? 0);
    if (!Number.isFinite(t) || t <= 0) return;
    serverSkewSec = Math.round(t - Math.floor(Date.now() / 1000));
  }

  async function syncServerClock() {
    try {
      const { resp, data } = await fetchJson("/api/server-time");
      if (!resp.ok) return;
      refreshServerSkewFromPayload(data);
    } catch {
      // ignore
    }
  }

  function ensureAudioUnlocked() {
    if (audioUnlocked) return;
    const unlock = async () => {
      try {
        const Ctx = window.AudioContext || window.webkitAudioContext;
        if (!Ctx) return;
        if (!audioCtx) audioCtx = new Ctx();
        if (audioCtx.state === "suspended" && typeof audioCtx.resume === "function") {
          await audioCtx.resume();
        }
        audioUnlocked = true;
      } catch {
        // ignore unlock errors
      } finally {
        if (audioUnlocked) {
          window.removeEventListener("pointerdown", unlock, true);
          window.removeEventListener("keydown", unlock, true);
          window.removeEventListener("touchstart", unlock, true);
        }
      }
    };
    window.addEventListener("pointerdown", unlock, true);
    window.addEventListener("keydown", unlock, true);
    window.addEventListener("touchstart", unlock, true);
  }

  async function playAlertTone() {
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      if (!audioCtx) audioCtx = new Ctx();
      if (audioCtx.state === "suspended" && typeof audioCtx.resume === "function") {
        await audioCtx.resume();
      }
      if (audioCtx.state !== "running") return;
      const ctx = audioCtx;
      const now = ctx.currentTime;
      const beep = (startAt, freq, duration) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, startAt);
        gain.gain.setValueAtTime(0.0001, startAt);
        gain.gain.exponentialRampToValueAtTime(0.24, startAt + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.0001, startAt + duration);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(startAt);
        osc.stop(startAt + duration + 0.02);
      };
      beep(now, 880, 0.16);
      beep(now + 0.2, 988, 0.18);
    } catch {
      // ignore tone errors
    }
  }

  function parseSubject(detail) {
    const s = String(detail || "");
    const m = s.match(/Subject:\s*(.+)/i);
    return m ? String(m[1] || "").trim() : "";
  }

  function showInPageAlert(messageText, options) {
    const text = String(messageText || "").trim();
    if (!text) return;
    const title = String(options?.title || "").trim();
    const tone = String(options?.tone || "open");
    const durationMsRaw = Number(options?.durationMs || 4500);
    const durationMs = Number.isFinite(durationMsRaw) && durationMsRaw > 0 ? Math.floor(durationMsRaw) : 4500;
    let box = document.getElementById("crmEmailOpenAlertBox");
    if (!box) {
      box = document.createElement("div");
      box.id = "crmEmailOpenAlertBox";
      box.setAttribute("aria-live", "polite");
      box.setAttribute("aria-relevant", "additions");
      document.body.appendChild(box);
    }
    const item = document.createElement("div");
    item.className = `crm-email-open-alert crm-email-open-alert--${tone}`;
    item.setAttribute("role", "status");
    if (title) {
      const titleEl = document.createElement("div");
      titleEl.className = "crm-email-open-alert-title";
      titleEl.textContent = title;
      item.appendChild(titleEl);
      const bodyEl = document.createElement("div");
      bodyEl.className = "crm-email-open-alert-body";
      bodyEl.textContent = text;
      item.appendChild(bodyEl);
    } else {
      item.textContent = text;
    }
    box.appendChild(item);
    window.setTimeout(() => {
      item.classList.add("is-hiding");
      window.setTimeout(() => {
        if (item.parentNode) item.parentNode.removeChild(item);
      }, 220);
    }, durationMs);
  }

  function notifyOpen(item) {
    const suppressUntil = Number(window.crmSuppressEmailOpenAlertsUntil || 0);
    if (Number.isFinite(suppressUntil) && suppressUntil > Date.now()) return;
    const key = eventNotifyKey(item);
    if (notifiedKeysThisSession.has(key)) return;
    notifiedKeysThisSession.add(key);

    const contactName = String(item.contactName || "").trim() || "A contact";
    const subject = parseSubject(item.detail);
    const body = subject ? `${contactName} opened "${subject}"` : `${contactName} opened an email`;
    playAlertTone();
    showInPageAlert(body, { title: "Email Opened", tone: "open", durationMs: 5000 });

    if (typeof Notification === "undefined") return;
    if (Notification.permission !== "granted") return;
    try {
      const contactId = Number(item.contactId || 0);
      const url = contactId > 0 ? `/contact.html?id=${encodeURIComponent(contactId)}` : "/activities.html";
      const n = new Notification("Email Opened", {
        body,
        icon: "/favicon.svg",
        tag: `crm-email-open-${key}`
      });
      n.onclick = () => {
        window.focus();
        window.location.href = url;
      };
    } catch {
      // ignore notification errors
    }
  }

  async function poll() {
    if (inFlight) return;
    if (typeof document !== "undefined" && document.visibilityState === "hidden") return;
    inFlight = true;
    try {
      let since = readLastSeenUnix();
      const nowUnix = approxServerUnix();
      if (since > nowUnix + MAX_FUTURE_SKEW_SECONDS) {
        since = Math.max(0, nowUnix - DEFAULT_LOOKBACK_SECONDS);
        writeLastSeenUnix(since);
        try {
          window.localStorage.removeItem(STORAGE_ID_KEY);
        } catch {
          // ignore
        }
      }
      const sinceId = readLastSeenId();
      const { resp, data } = await fetchJson(
        `/api/email/open-events?since=${encodeURIComponent(String(since))}&sinceId=${encodeURIComponent(String(sinceId))}`
      );
      if (!resp.ok) return;
      refreshServerSkewFromPayload(data);
      const items = Array.isArray(data?.items) ? data.items : [];
      let maxSeen = since;
      let maxSeenId = sinceId;
      for (const item of items) {
        const createdAtUnix = Number(item?.createdAtUnix || 0);
        const itemId = Number(item?.id || 0);
        if (createdAtUnix > maxSeen) {
          maxSeen = Math.floor(createdAtUnix);
          maxSeenId = Number.isInteger(itemId) && itemId > 0 ? Math.floor(itemId) : maxSeenId;
        } else if (createdAtUnix === maxSeen && Number.isInteger(itemId) && itemId > maxSeenId) {
          maxSeenId = Math.floor(itemId);
        }
        if (ignoreEventsThroughUnix > 0 && createdAtUnix <= ignoreEventsThroughUnix) continue;
        notifyOpen(item);
      }
      if (maxSeen > 0) {
        lastEventUnix = Math.max(lastEventUnix, maxSeen);
      }
      if (maxSeen > since) writeLastSeenUnix(maxSeen);
      if (maxSeen === since && maxSeenId > sinceId) writeLastSeenId(maxSeenId);
      if (maxSeen > since && maxSeenId > sinceId) writeLastSeenId(maxSeenId);
    } catch {
      // keep polling quietly
    } finally {
      inFlight = false;
    }
  }

  function triggerPollSoon() {
    window.setTimeout(() => {
      poll().catch(() => {});
    }, 50);
  }

  function requestNotificationPermissionSafely() {
    if (typeof Notification === "undefined") return;
    if (typeof Notification.requestPermission !== "function") return;
    try {
      const maybePromise = Notification.requestPermission();
      if (maybePromise && typeof maybePromise.then === "function") {
        maybePromise.catch(() => {});
      }
    } catch {
      // ignore permission request errors
    }
  }

  async function start() {
    ensureAudioUnlocked();
    removeLegacyStatusBadge();
    await syncServerClock();
    initSessionCursorIfNeeded();
    if (typeof Notification !== "undefined" && Notification.permission === "default") {
      requestNotificationPermissionSafely();
    }
    poll().catch(() => {});
    timer = window.setInterval(() => {
      poll().catch(() => {});
    }, POLL_MS);
    window.addEventListener("focus", triggerPollSoon);
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") triggerPollSoon();
    });
    window.addEventListener("online", triggerPollSoon);
  }

  window.crmResetEmailOpenAlertsCursor = () => {
    resetAlertCursor(DEFAULT_LOOKBACK_SECONDS);
    poll().catch(() => {});
  };

  /** @param {string} message @param {{ tone?: boolean }} [options] */
  function showEmailAlertMessage(message, options) {
    const text = String(message || "").trim();
    if (!text) return;
    if (!options || options.tone !== false) playAlertTone();
    showInPageAlert(text, { title: "Email Sent", tone: "sent", durationMs: 3500 });
  }

  window.crmShowEmailAlert = showEmailAlertMessage;
  window.crmPollEmailOpenAlertsNow = triggerPollSoon;

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      start().catch(() => {});
    });
  } else {
    start().catch(() => {});
  }
})();
