/*
 * crm-loading.js — a small, shared "the CRM is working" indicator.
 *
 * Shows a centered, animated set of pulsing dots (Claude-thinking style) whenever
 * the app is genuinely busy, and stays out of the way otherwise:
 *   - First data load of each endpoint on a page  -> shows
 *   - Saves / updates (POST / PUT / PATCH / DELETE) -> shows
 *   - Repeat background polling (same GET again)    -> silent
 *   - Known pollers (server-time, open-events)      -> silent
 *   - Fast requests (< SHOW_DELAY ms)               -> never flashes
 *
 * It wraps window.fetch, so it works for every page's fetchApiJson automatically.
 * Non-blocking (pointer-events: none) — purely a visual cue.
 */
(function () {
  "use strict";
  if (window.__crmLoadingInstalled) return;
  window.__crmLoadingInstalled = true;

  var EXCLUDE = [
    "/api/server-time",
    "/api/email/open-events",
    "/ai-robot.json", // AI launcher animation — has its own visuals, shouldn't drive the loader
    "/api/assistant/" // AI panel calls — the panel shows its own inline spinner
  ];
  var SHOW_DELAY = 350; // don't show the indicator for quick requests
  var MIN_VISIBLE = 450; // once shown, keep it up briefly so it never flickers
  var MAX_VISIBLE = 20000; // failsafe: never let the indicator stay stuck longer than this

  var seenGets = Object.create(null);
  var pending = 0;
  var showTimer = null;
  var watchdog = null;
  var shownAt = 0;
  var overlay = null;

  var CSS =
    ".crm-loading-overlay{position:fixed;top:0;bottom:0;right:0;left:var(--agile-sidebar-width,234px);display:flex;align-items:center;justify-content:center;z-index:2147483000;pointer-events:none;opacity:0;visibility:hidden;transition:opacity .18s ease,visibility .18s ease}" +
    "@media (max-width:980px){.crm-loading-overlay{left:0}}" +
    ".crm-loading-overlay.crm-loading--visible{opacity:1;visibility:visible}" +
    ".crm-loading-card{display:flex;align-items:center;justify-content:center;padding:16px 22px;background:transparent;border-radius:16px;border:0;box-shadow:none}" +
    ".crm-loading-dots{display:inline-flex;gap:9px}" +
    ".crm-loading-dots i{width:12px;height:12px;border-radius:50%;background:#7c3aed;display:inline-block;animation:crmDot 1.15s infinite ease-in-out both}" +
    ".crm-loading-dots i:nth-child(1){animation-delay:-.26s}" +
    ".crm-loading-dots i:nth-child(2){animation-delay:-.13s}" +
    "@keyframes crmDot{0%,80%,100%{transform:scale(.5);opacity:.35}40%{transform:scale(1);opacity:1}}" +
    "@media (prefers-reduced-motion:reduce){.crm-loading-dots i{animation-duration:2s}}";

  var CARD_HTML =
    '<div class="crm-loading-card" role="status" aria-live="polite" aria-label="Loading">' +
    '<span class="crm-loading-dots" aria-hidden="true"><i></i><i></i><i></i></span></div>';

  function ensureOverlay() {
    if (overlay) return overlay;
    if (!document.body) return null;
    var style = document.createElement("style");
    style.textContent = CSS;
    document.head.appendChild(style);
    var el = document.createElement("div");
    el.className = "crm-loading-overlay";
    el.setAttribute("aria-hidden", "true");
    el.innerHTML = CARD_HTML;
    document.body.appendChild(el);
    overlay = el;
    return el;
  }

  function show() {
    var el = ensureOverlay();
    if (!el) return;
    el.classList.add("crm-loading--visible");
    shownAt = Date.now();
    // Failsafe: if a tracked request stalls and never reports completion,
    // force-clear so the indicator can never stay stuck.
    clearTimeout(watchdog);
    watchdog = setTimeout(function () {
      pending = 0;
      if (overlay) overlay.classList.remove("crm-loading--visible");
    }, MAX_VISIBLE);
  }

  function hide() {
    if (!overlay) return;
    var wait = Math.max(0, MIN_VISIBLE - (Date.now() - shownAt));
    setTimeout(function () {
      if (pending === 0 && overlay) {
        overlay.classList.remove("crm-loading--visible");
        clearTimeout(watchdog);
      }
    }, wait);
  }

  function begin() {
    pending++;
    if (pending === 1) {
      clearTimeout(showTimer);
      showTimer = setTimeout(function () {
        if (pending > 0) show();
      }, SHOW_DELAY);
    }
  }

  function end() {
    pending = Math.max(0, pending - 1);
    if (pending === 0) {
      clearTimeout(showTimer);
      hide();
    }
  }

  function shouldTrack(url, method) {
    var path;
    try {
      path = new URL(url, window.location.origin).pathname;
    } catch (e) {
      return false;
    }
    for (var i = 0; i < EXCLUDE.length; i++) {
      if (path.indexOf(EXCLUDE[i]) === 0) return false;
    }
    method = String(method || "GET").toUpperCase();
    if (method === "GET") {
      if (seenGets[path]) return false; // repeat GET = polling/refresh -> stay silent
      seenGets[path] = true;
      return true; // first load of this endpoint -> show
    }
    return true; // a save / update -> show
  }

  var nativeFetch = window.fetch ? window.fetch.bind(window) : null;
  if (nativeFetch) {
    window.fetch = function (input, init) {
      var url = typeof input === "string" ? input : (input && input.url) || "";
      var method = (init && init.method) || (input && input.method) || "GET";
      var track = false;
      try {
        track = shouldTrack(url, method);
      } catch (e) {
        track = false;
      }
      if (track) begin();
      var p;
      try {
        p = nativeFetch(input, init);
      } catch (e) {
        if (track) end();
        throw e;
      }
      if (track) {
        return p.then(
          function (r) {
            end();
            return r;
          },
          function (e) {
            end();
            throw e;
          }
        );
      }
      return p;
    };
  }

  // Give instant feedback while navigating to another page (which may be slow to load).
  window.addEventListener("beforeunload", function () {
    try {
      show();
    } catch (e) {}
  });

  // Expose a tiny manual API in case a page wants to show it around non-fetch work.
  window.CrmLoading = {
    show: function () {
      begin();
    },
    hide: function () {
      end();
    }
  };
})();

/* ------------------------------------------------------------------
   Cadence AI launcher loader
   Injects the floating "Cadence AI" panel widget (contactsAiPanel.js)
   on every authenticated app page. The widget self-guards: it skips the
   contact summary page (which has its own AI panel) and any page without
   the left nav. Loaded here so no per-page <script> tags are needed.
   Remove this block (and contactsAiPanel.js) to fully revert.
------------------------------------------------------------------ */
(function () {
  function loadCadenceAi() {
    try {
      if (window.__cadenceAiPanelLoaded) return;
      // If a page already includes the widget via its own <script> tag, don't double-load.
      if (document.querySelector('script[src*="contactsAiPanel.js"]')) {
        window.__cadenceAiPanelLoaded = true;
        return;
      }
      window.__cadenceAiPanelLoaded = true;
      // Prefetch Lottie so the floating robot rarely falls back to the star.
      if (!document.querySelector('script[src*="lottie-player"]')) {
        var lottie = document.createElement("script");
        lottie.src = "/vendor/lottie-player.js?v=208";
        lottie.async = true;
        (document.head || document.documentElement).appendChild(lottie);
      }
      var s = document.createElement("script");
      s.src = "/contactsAiPanel.js?v=20260920slide2";
      s.async = true;
      (document.head || document.documentElement).appendChild(s);
    } catch (e) {}
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", loadCadenceAi);
  } else {
    loadCadenceAi();
  }
})();
