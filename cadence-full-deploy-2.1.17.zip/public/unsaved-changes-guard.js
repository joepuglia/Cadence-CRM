(function () {
  if (window.CrmUnsavedGuard) return;

  const DEFAULT_CONFIRM_MESSAGE = "You have unsaved changes. Leave this page without saving?";

  let config = null;
  let baseline = null;
  let suppressBeforeUnload = false;

  function safeComputeSignature() {
    if (!config || typeof config.computeSignature !== "function") return "";
    try {
      const sig = config.computeSignature();
      return sig == null ? "" : String(sig);
    } catch {
      return "";
    }
  }

  function isDirty() {
    if (!config || baseline == null) return false;
    return safeComputeSignature() !== baseline;
  }

  function markClean() {
    baseline = safeComputeSignature();
  }

  function markDirty() {
    if (baseline == null) {
      baseline = safeComputeSignature();
      return;
    }
    baseline = `__dirty__${Date.now()}__`;
  }

  function isGuardableLink(a) {
    if (!a || !a.getAttribute) return false;
    const href = a.getAttribute("href");
    if (!href) return false;
    if (a.target && a.target !== "_self") return false;
    if (
      href.startsWith("#") ||
      href.startsWith("javascript:") ||
      href.startsWith("mailto:") ||
      href.startsWith("tel:")
    ) {
      return false;
    }
    if (a.hasAttribute("download")) return false;
    if (a.hasAttribute("data-no-unsaved-guard")) return false;
    return true;
  }

  function confirmLeave() {
    return window.confirm((config && config.confirmMessage) || DEFAULT_CONFIRM_MESSAGE);
  }

  function shouldBypassModifier(e) {
    return Boolean(e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button === 1);
  }

  function handleAnchorClick(e) {
    if (e.defaultPrevented) return;
    if (shouldBypassModifier(e)) return;
    const a = e.target.closest && e.target.closest("a");
    if (!a) return;
    if (!isGuardableLink(a)) return;
    if (!isDirty()) return;
    if (!confirmLeave()) {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation && e.stopImmediatePropagation();
      return;
    }
    suppressBeforeUnload = true;
    baseline = safeComputeSignature();
  }

  function handleBackButtonClick(e) {
    if (e.defaultPrevented) return;
    if (shouldBypassModifier(e)) return;
    const target = e.target.closest && e.target.closest("[data-unsaved-guard-back]");
    if (!target) return;
    if (!isDirty()) return;
    if (!confirmLeave()) {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation && e.stopImmediatePropagation();
      return;
    }
    suppressBeforeUnload = true;
    baseline = safeComputeSignature();
  }

  function handleBeforeUnload(e) {
    if (suppressBeforeUnload) {
      suppressBeforeUnload = false;
      return;
    }
    if (!isDirty()) return;
    e.preventDefault();
    e.returnValue = "";
    return "";
  }

  function init(opts) {
    config = opts || {};
    document.addEventListener("click", handleBackButtonClick, true);
    document.addEventListener("click", handleAnchorClick, true);
    window.addEventListener("beforeunload", handleBeforeUnload);
    setTimeout(markClean, 0);
  }

  function bypassNext() {
    suppressBeforeUnload = true;
  }

  window.CrmUnsavedGuard = { init, markClean, markDirty, isDirty, bypassNext };
})();
