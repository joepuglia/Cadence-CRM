(function () {
  const DEFAULT_ENDING = "Reply STOP to opt out.";
  let ending = DEFAULT_ENDING;
  let loaded = null;

  function fields() {
    return document.querySelectorAll("[data-sms-ending]");
  }

  function fill() {
    fields().forEach((el) => {
      if (document.activeElement === el) return;
      el.value = ending;
    });
  }

  function normalize(value) {
    return String(value == null ? "" : value).replace(/[ \t\u00A0]+$/g, "").trim().slice(0, 300);
  }

  async function load(force) {
    if (force) loaded = null;
    if (!loaded) {
      loaded = fetch("/api/runtime/agent-profile", { credentials: "same-origin" })
        .then((response) => (response.ok ? response.json() : {}))
        .then((data) => {
          ending = data && typeof data.smsEnding === "string" ? data.smsEnding : DEFAULT_ENDING;
          fill();
          return ending;
        })
        .catch(() => {
          fill();
          return ending;
        });
    } else {
      fill();
    }
    return loaded;
  }

  async function save(value) {
    ending = normalize(value);
    loaded = Promise.resolve(ending);
    fill();
    const response = await fetch("/api/runtime/agent-profile", {
      method: "PUT",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ smsEnding: ending })
    });
    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      throw new Error(data.error || "Could not save the text ending.");
    }
    return ending;
  }

  document.addEventListener("change", (event) => {
    const el = event.target;
    if (!el || !el.matches || !el.matches("[data-sms-ending]")) return;
    save(el.value).catch(() => {});
  });

  window.cadenceSmsEnding = {
    load,
    apply: fill,
    current() {
      return ending;
    },
    fromForm(form) {
      const el = form && form.querySelector("[data-sms-ending]");
      if (!el) return undefined;
      return normalize(el.value);
    },
    save
  };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => load(false));
  else load(false);
})();
