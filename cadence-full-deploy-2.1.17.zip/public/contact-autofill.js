/**

 * Stops browsers/password managers from putting login email into unrelated CRM fields.

 */

(function initCrmContactAutofillGuard() {

  const EMAIL_AUTOCOMPLETE = "email";



  function isEmailField(el) {

    const name = String(el.name || "").toLowerCase();

    const id = String(el.id || "").toLowerCase();

    return name === "email" || id === "email" || String(el.type || "").toLowerCase() === "email";

  }



  function guardInput(el) {

    if (!el || el.tagName !== "INPUT") return;

    if (isEmailField(el)) {

      el.type = "email";

      el.setAttribute("autocomplete", EMAIL_AUTOCOMPLETE);

      el.setAttribute("inputmode", "email");

      return;

    }

    const type = String(el.type || "text").toLowerCase();

    if (type === "hidden" || type === "checkbox" || type === "radio" || type === "file") return;

    if (type === "password" || el.dataset.crmSensitiveMask === "1") return;

    el.setAttribute("autocomplete", "off");

    el.setAttribute("autocapitalize", "off");

    el.setAttribute("data-lpignore", "true");

    el.setAttribute("data-1p-ignore", "true");

    if (type === "text" || type === "search" || type === "") {

      if (el.dataset.crmAutofillGuard === "1") return;

      el.dataset.crmAutofillGuard = "1";

      el.setAttribute("readonly", "readonly");

      el.addEventListener("focus", () => el.removeAttribute("readonly"));

    }

  }



  function configureContactFormAutofill(root) {

    const scope = root && root.querySelector ? root : document;

    scope.querySelectorAll("#contactPageForm, #contactModalForm").forEach((formEl) => {

      formEl.setAttribute("autocomplete", "off");

      formEl.querySelectorAll("input, textarea, select").forEach((el) => {

        if (el.tagName === "INPUT") guardInput(el);

        else if (el.tagName === "TEXTAREA") {

          el.setAttribute("autocomplete", "off");

          el.setAttribute("data-lpignore", "true");

          el.setAttribute("data-1p-ignore", "true");

        }

      });

    });

  }



  window.crmConfigureContactFormAutofill = configureContactFormAutofill;



  if (document.readyState === "loading") {

    document.addEventListener("DOMContentLoaded", () => configureContactFormAutofill(document));

  } else {

    configureContactFormAutofill(document);

  }

})();


