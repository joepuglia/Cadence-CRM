const activitiesMessageEl = document.getElementById("activitiesMessage");
const activitiesLastUpdatedEl = document.getElementById("activitiesLastUpdated");
const activitiesRefreshBtn = document.getElementById("activitiesRefreshBtn");
const activitiesExportBtn = document.getElementById("activitiesExportBtn");
const activitiesWindowSelect = document.getElementById("activitiesWindowSelect");
const activitiesWindowDaysEl = document.getElementById("activitiesWindowDays");
const activitiesEmailsSentCountEl = document.getElementById("activitiesEmailsSentCount");
const activitiesSmsSentCountEl = document.getElementById("activitiesSmsSentCount");
const activitiesCallsCountEl = document.getElementById("activitiesCallsCount");
const activitiesNewContactsCountEl = document.getElementById("activitiesNewContactsCount");
const activitiesEmailOpenedCountEl = document.getElementById("activitiesEmailOpenedCount");
const activitiesEmailClickedCountEl = document.getElementById("activitiesEmailClickedCount");
const activitiesContactEmailOpenedEl = document.getElementById("activitiesContactEmailOpened");
const activitiesEmailsSentListEl = document.getElementById("activitiesEmailsSentList");
const activitiesSmsSentListEl = document.getElementById("activitiesSmsSentList");
const activitiesCallsListEl = document.getElementById("activitiesCallsList");
const activitiesNewContactsListEl = document.getElementById("activitiesNewContactsList");
const activitiesEmailsSentBadgeEl = document.getElementById("activitiesEmailsSentBadge");
const activitiesSmsSentBadgeEl = document.getElementById("activitiesSmsSentBadge");
const activitiesCallsBadgeEl = document.getElementById("activitiesCallsBadge");
const activitiesNewContactsBadgeEl = document.getElementById("activitiesNewContactsBadge");
const activitiesStatusWeeklyChartEl = document.getElementById("activitiesStatusWeeklyChart");
const contactActivityFilterBtns = Array.from(document.querySelectorAll("[data-contact-activity-filter]"));
const metricCards = Array.from(document.querySelectorAll("[data-activity-drill]"));

const STATUS_CHART_COLORS = {
  new: "#2563eb",
  approved: "#16a34a",
  declined: "#dc2626",
  referred: "#7c3aed",
  aps: "#0891b2",
  pending: "#d97706",
  closed: "#64748b"
};

const WEEK_BAR_COLORS = ["#bfdbfe", "#60a5fa", "#2563eb", "#1e40af"];

const STATIC_DEV_PORTS = new Set(["5500", "5501", "5173", "4173", "8080", "1234", "8888", "4200", "5000"]);

let cachedApiBase;
let stickyApiBase;
let currentActivitiesData = null;
let activeContactActivityFilter = "emailOpened";
let lastUpdatedAt = null;

function setLastUpdated() {
  if (!activitiesLastUpdatedEl) return;
  lastUpdatedAt = new Date();
  activitiesLastUpdatedEl.textContent = `Last updated just now at ${lastUpdatedAt.toLocaleTimeString([], {
    hour: "numeric",
    minute: "2-digit"
  })}.`;
}

function showMessage(text, isError = false) {
  if (!activitiesMessageEl) return;
  const str = String(text == null ? "" : text);
  if (isError && typeof window.crmHandleAuthErrorMessage === "function" && window.crmHandleAuthErrorMessage(str, isError)) {
    return;
  }
  activitiesMessageEl.textContent = str;
  activitiesMessageEl.style.color = isError ? "#c62828" : "#1b5e20";
}

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function getCrmApiBase() {
  if (stickyApiBase !== undefined) return stickyApiBase;
  if (cachedApiBase !== undefined) return cachedApiBase;
  const params = new URLSearchParams(window.location.search);
  const fromQuery = params.get("api");
  if (fromQuery && String(fromQuery).trim()) {
    cachedApiBase = String(fromQuery).trim().replace(/\/$/, "");
    return cachedApiBase;
  }
  const injected =
    typeof window.__CRM_API_ORIGIN__ === "string" ? window.__CRM_API_ORIGIN__.trim().replace(/\/$/, "") : "";
  if (injected) {
    const pageOrigin = window.location.origin.replace(/\/$/, "");
    cachedApiBase = injected === pageOrigin ? "" : injected;
    return cachedApiBase;
  }
  const servedMeta = document.querySelector('meta[name="crm-served-by-api"]');
  if (servedMeta && servedMeta.getAttribute("content") === "1") {
    cachedApiBase = "";
    return cachedApiBase;
  }
  const meta = document.querySelector('meta[name="crm-api-base"]');
  const fromMeta = meta && meta.getAttribute("content");
  if (fromMeta && String(fromMeta).trim()) {
    cachedApiBase = String(fromMeta).trim().replace(/\/$/, "");
    return cachedApiBase;
  }
  const host = window.location.hostname;
  const port = window.location.port || "";
  if ((host === "localhost" || host === "127.0.0.1") && STATIC_DEV_PORTS.has(port)) {
    cachedApiBase = `${window.location.protocol}//${host}:3000`;
    return cachedApiBase;
  }
  cachedApiBase = "";
  return cachedApiBase;
}

function toAbsoluteUrl(url) {
  if (url.startsWith("http://") || url.startsWith("https://")) return url;
  return new URL(url.startsWith("/") ? url : `/${url}`, window.location.href).href;
}

function apiUrl(path) {
  const p = path.startsWith("/") ? path : `/${path}`;
  const base = getCrmApiBase();
  return base ? `${base}${p}` : p;
}

function apiUrlCandidates(path) {
  const p = path.startsWith("/") ? path : `/${path}`;
  const out = [];
  const push = (u) => {
    const abs = toAbsoluteUrl(u);
    if (!out.includes(abs)) out.push(abs);
  };
  push(apiUrl(p));
  const host = window.location.hostname;
  if (host === "localhost" || host === "127.0.0.1") {
    push(`http://127.0.0.1:3000${p}`);
    push(`http://localhost:3000${p}`);
  }
  return out;
}

function rememberSuccessfulApiOrigin(urlUsed) {
  try {
    const origin = new URL(toAbsoluteUrl(urlUsed)).origin.replace(/\/$/, "");
    const pageOrigin = window.location.origin.replace(/\/$/, "");
    stickyApiBase = origin === pageOrigin ? "" : origin;
  } catch {
    // no-op
  }
}

async function fetchApiJson(path) {
  const urls = apiUrlCandidates(path);
  let sawHtml = false;
  let lastStatus = 0;
  let lastUrl = "";
  for (const url of urls) {
    lastUrl = url;
    const response = await fetch(url, { credentials: "include" });
    lastStatus = response.status;
    const text = await response.text();
    const trimmed = text.trim();
    if (!trimmed) continue;
    if (trimmed.startsWith("<")) {
      sawHtml = true;
      continue;
    }
    try {
      const data = JSON.parse(trimmed);
      rememberSuccessfulApiOrigin(url);
      return { response, data };
    } catch {
      // try next candidate
    }
  }
  if (sawHtml) {
    throw new Error(
      `Server returned HTML instead of JSON for ${path} (tried ${lastUrl || "same origin"}). ` +
        "Check https://crmcadence.com/api/health in your browser — it must show JSON, not a web page."
    );
  }
  throw new Error(`Empty or invalid JSON from API for ${path} (last status ${lastStatus}).`);
}

function titleCase(value) {
  return String(value || "event")
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .split(" ")
    .filter(Boolean)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

function parseStoredTimestamp(value) {
  if (value == null || value === "") return null;
  const asNumber = Number(value);
  if (Number.isFinite(asNumber) && asNumber > 0) {
    return new Date(asNumber < 1e12 ? asNumber * 1000 : asNumber);
  }
  const text = String(value).trim();
  if (!text) return null;
  if (/^\d+$/.test(text)) {
    const n = Number(text);
    if (Number.isFinite(n) && n > 0) return new Date(n < 1e12 ? n * 1000 : n);
  }
  let normalized = text;
  if (/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(\.\d+)?$/.test(text)) {
    normalized = `${text.replace(" ", "T")}Z`;
  }
  const d = new Date(normalized);
  return Number.isFinite(d.getTime()) ? d : null;
}

function formatLocalTime(value) {
  const d = parseStoredTimestamp(value);
  if (!d) return String(value || "");
  try {
    return d.toLocaleString(undefined, {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit"
    });
  } catch {
    return d.toLocaleString();
  }
}

function formatDateGroupLabel(value) {
  const d = parseStoredTimestamp(value);
  if (!d) return "Undated";
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(d);
  target.setHours(0, 0, 0, 0);
  const diffDays = Math.round((today.getTime() - target.getTime()) / 86400000);
  if (diffDays === 0) return "Today";
  if (diffDays === 1) return "Yesterday";
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}

function getInitials(name) {
  const parts = String(name || "")
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  if (!parts.length) return "?";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0] || ""}${parts[parts.length - 1][0] || ""}`.toUpperCase();
}

function getAvatarStyle(name) {
  const s = String(name || "").trim();
  let hash = 0;
  for (let i = 0; i < s.length; i += 1) {
    hash = (hash * 31 + s.charCodeAt(i)) >>> 0;
  }
  const hue = hash % 360;
  return {
    background: `hsl(${hue} 78% 92%)`,
    color: `hsl(${hue} 62% 36%)`
  };
}

function contactHref(contactId) {
  const id = Number(contactId);
  return Number.isInteger(id) && id > 0 ? `/contact.html?id=${encodeURIComponent(id)}` : "";
}

function formatCallActivityDetail(rawDetail) {
  const raw = String(rawDetail || "").trim();
  if (raw === "Started call") return "Call started";
  if (/^started call campaign call$/i.test(raw)) return "Campaign call started";
  if (raw === "Started call (recording on)") return "Recorded call (processing audio…)";
  if (raw.startsWith("CALL_WITH_RECORDING:") || raw.startsWith("CALL_RECORDING:")) {
    try {
      const jsonText = raw.startsWith("CALL_WITH_RECORDING:")
        ? raw.slice("CALL_WITH_RECORDING:".length)
        : raw.slice("CALL_RECORDING:".length);
      const payload = JSON.parse(jsonText);
      if (payload && payload.status === "pending") return "Recorded call (processing audio…)";
      const seconds = Math.max(0, Math.floor(Number(payload?.durationSeconds || 0)));
      if (seconds > 0) {
        const m = Math.floor(seconds / 60);
        const s = seconds % 60;
        const dur = m > 0 ? `${m}:${String(s).padStart(2, "0")}` : `${s}s`;
        return `Recorded call (${dur})`;
      }
      return "Recorded call";
    } catch {
      return "Recorded call";
    }
  }
  return raw || "Call logged";
}

function formatSentEmailActivityDetail(rawDetail) {
  const raw = String(rawDetail || "");
  const jsonPrefix = raw.match(/^email_json:/i);
  if (!jsonPrefix) return null;
  try {
    const payload = JSON.parse(raw.slice(jsonPrefix[0].length));
    const subject = String(payload?.subject || "(no subject)").trim();
    const to = String(payload?.to || "").trim();
    const parts = [subject];
    if (to) parts.push(`To: ${to}`);
    return escapeHtml(parts.join(" · ") || "Email sent");
  } catch {
    return null;
  }
}

function formatActivityDetail(item, labelOverride) {
  if (labelOverride) return escapeHtml(labelOverride);
  const activityType = String(item.activity_type || "").trim().toLowerCase();
  const rawDetail = String(item.detail || "");
  if (activityType === "email") {
    if (rawDetail.toLowerCase().startsWith("email opened") || rawDetail.toLowerCase().startsWith("email clicked")) {
      return "";
    }
    if (item.detail_display) return escapeHtml(String(item.detail_display));
    const fromJson = formatSentEmailActivityDetail(rawDetail);
    if (fromJson) return fromJson;
    if (rawDetail.toLowerCase().startsWith("sent email:")) {
      return escapeHtml(rawDetail.replace(/^sent email:\s*/i, "").trim() || "Email sent");
    }
    return escapeHtml(rawDetail.split("\n")[0] || "Email");
  }
  if (item.detail_display) return escapeHtml(String(item.detail_display));
  if (activityType === "sms") {
    return escapeHtml(rawDetail.replace(/^sent sms:\s*/i, "").trim() || "SMS sent");
  }
  if (activityType === "call") return escapeHtml(formatCallActivityDetail(rawDetail));
  if (activityType === "new_contact") return "New contact entered";
  if (item.transition && item.transition.to) {
    const from = String(item.transition.from || "(empty)");
    const to = String(item.transition.to || "");
    return escapeHtml(`${from} → ${to}`);
  }
  return escapeHtml(rawDetail || "-");
}

function activityTypeLabel(item, labelOverride) {
  if (labelOverride) return labelOverride;
  const activityType = String(item.activity_type || "").trim().toLowerCase();
  if (activityType === "email") {
    const raw = String(item.detail || "").toLowerCase();
    return raw.startsWith("email opened") ? "Email Opened" : raw.startsWith("email clicked") ? "Email Clicked" : "Email Sent";
  }
  if (activityType === "sms") return "SMS Sent";
  if (activityType === "call") return "Call";
  if (activityType === "new_contact") return "New Contact";
  if (item.transition && item.transition.to) return titleCase(item.transition.field || "Status");
  return titleCase(activityType);
}

function renderFeedList(container, items, options = {}) {
  if (!container) return;
  const rows = Array.isArray(items) ? items : [];
  const emptyText = options.emptyText || "No activity in the last 30 days.";
  const labelOverride = options.labelOverride || "";
  if (!rows.length) {
    container.innerHTML = `<div class="home-empty">${escapeHtml(emptyText)}</div>`;
    return;
  }
  let lastDateGroup = "";
  container.innerHTML = rows
    .map((item) => {
      const dateGroup = formatDateGroupLabel(item.created_at);
      const dateHeader =
        dateGroup !== lastDateGroup
          ? `<div class="activities-date-group" role="heading" aria-level="3">${escapeHtml(dateGroup)}</div>`
          : "";
      lastDateGroup = dateGroup;
      const contactNameRaw = String(item.contact_name || "").trim() || `Contact #${item.contact_id}`;
      const contactName = escapeHtml(contactNameRaw);
      const initials = getInitials(contactNameRaw);
      const avatarStyle = getAvatarStyle(contactNameRaw);
      const href = contactHref(item.contact_id);
      const typeLabel = activityTypeLabel(item, labelOverride);
      const detail = formatActivityDetail(item, options.detailOverride);
      const time = escapeHtml(formatLocalTime(item.created_at));
      const detailHtml = detail ? `<div class="home-recent-detail">${detail}</div>` : "";
      const content = `<div class="home-recent-item-content">
        <div class="home-recent-body">
          <div class="home-recent-avatar" style="background:${avatarStyle.background};color:${avatarStyle.color};">${escapeHtml(
            initials
          )}</div>
          <div class="home-recent-main">
            <div class="home-recent-top">
              <span class="home-recent-type">${escapeHtml(typeLabel)}</span>
              <span class="home-recent-time">${time}</span>
            </div>
            <div class="home-recent-contact">${contactName}</div>
            ${detailHtml}
          </div>
        </div>
      </div>`;
      const itemMarkup = !href
        ? `<div class="home-recent-item">${content}</div>`
        : `<a class="home-recent-item home-recent-item-link" href="${href}">${content}</a>`;
      return `${dateHeader}${itemMarkup}`;
    })
    .join("");
}

function sortedByCreatedDesc(items) {
  return [...(Array.isArray(items) ? items : [])].sort((a, b) => {
    const da = parseStoredTimestamp(a?.created_at);
    const db = parseStoredTimestamp(b?.created_at);
    return (db?.getTime() || 0) - (da?.getTime() || 0);
  });
}

function contactActivityItemsForFilter(data, filter) {
  const contact = data?.contactActivities || {};
  const user = data?.userActivities || {};
  const emailOpened = contact.emailOpened?.items || [];
  const emailClicked = contact.emailClicked?.items || [];
  const callsMade = user.callsMade?.items || [];
  if (filter === "emailClicked") return sortedByCreatedDesc(emailClicked);
  if (filter === "callsMade") return sortedByCreatedDesc(callsMade);
  return sortedByCreatedDesc(emailOpened);
}

function renderContactActivityFeed() {
  if (!currentActivitiesData) return;
  const windowDays = Number(currentActivitiesData.windowDays || selectedWindowDays());
  const items = contactActivityItemsForFilter(currentActivitiesData, activeContactActivityFilter);
  const emptyByFilter = {
    emailOpened: `No email opens in the last ${windowDays} days.`,
    emailClicked: `No email clicks in the last ${windowDays} days.`,
    callsMade: `No calls logged in the last ${windowDays} days.`
  };
  renderFeedList(activitiesContactEmailOpenedEl, items, {
    emptyText: emptyByFilter[activeContactActivityFilter] || emptyByFilter.emailOpened
  });
}

function setActiveContactActivityFilter(filter) {
  activeContactActivityFilter = ["emailOpened", "emailClicked", "callsMade"].includes(filter)
    ? filter
    : "emailOpened";
  contactActivityFilterBtns.forEach((btn) => {
    btn.classList.toggle("is-active", btn.getAttribute("data-contact-activity-filter") === activeContactActivityFilter);
  });
  renderContactActivityFeed();
}

function selectedWindowDays() {
  const n = Number(activitiesWindowSelect?.value || 30);
  return [7, 30, 90].includes(n) ? n : 30;
}

function statusChartLabel(key) {
  if (key === "aps") return "APS";
  return titleCase(key);
}

function renderStatusWeeklyChart(chartData) {
  if (!activitiesStatusWeeklyChartEl) return;
  if (!chartData || !Array.isArray(chartData.weeks) || !chartData.counts) {
    activitiesStatusWeeklyChartEl.innerHTML = '<div class="home-empty">No status change data yet.</div>';
    return;
  }
  const statuses = Array.isArray(chartData.statuses) ? chartData.statuses : Object.keys(STATUS_CHART_COLORS);
  const weeks = Array.isArray(chartData.weeks) ? chartData.weeks : [];
  const counts = chartData.counts || {};
  const totals = chartData.totals || {};
  const hasAny = statuses.some((s) => Number(totals[s] || 0) > 0);
  if (!hasAny) {
    activitiesStatusWeeklyChartEl.innerHTML =
      '<div class="home-empty">No status changes in the last 4 weeks.</div>';
    return;
  }

  const activeStatuses = statuses.filter((status) => Number(totals[status] || 0) > 0);
  const weekCount = Math.max(1, weeks.length || 4);
  const weekTotals = Array.from({ length: weekCount }, (_, weekIndex) =>
    activeStatuses.reduce((sum, status) => sum + Number((counts[status] || [])[weekIndex] || 0), 0)
  );
  const maxValue = Math.max(1, ...weekTotals);
  const width = 560;
  const height = 230;
  const pad = { top: 18, right: 18, bottom: 48, left: 42 };
  const plotWidth = width - pad.left - pad.right;
  const plotHeight = height - pad.top - pad.bottom;
  const yForValue = (value) => pad.top + plotHeight - (Number(value || 0) / maxValue) * plotHeight;
  const slotWidth = plotWidth / weekCount;
  const barWidth = Math.min(70, Math.max(34, slotWidth * 0.45));

  const gridLines = [0, 0.25, 0.5, 0.75, 1]
    .map(
      (ratio) => {
        const y = pad.top + plotHeight - ratio * plotHeight;
        const label = Math.round(ratio * maxValue);
        return `<g class="activities-status-chart-gridline">
          <line x1="${pad.left}" y1="${y}" x2="${width - pad.right}" y2="${y}"></line>
          <text x="${pad.left - 10}" y="${y + 4}" text-anchor="end">${label}</text>
        </g>`;
      }
    )
    .join("");

  const bars = weekTotals
    .map((val, weekIndex) => {
      const weekLabel = weeks[weekIndex]?.label || `Week ${weekIndex + 1}`;
      const color = WEEK_BAR_COLORS[weekIndex] || "#64748b";
      const x = pad.left + weekIndex * slotWidth + (slotWidth - barWidth) / 2;
      const y = yForValue(val);
      const h = Math.max(val > 0 ? 2 : 0, pad.top + plotHeight - y);
      const breakdown = activeStatuses
        .map((status) => {
          const n = Number((counts[status] || [])[weekIndex] || 0);
          return n > 0 ? `${statusChartLabel(status)} ${n}` : "";
        })
        .filter(Boolean)
        .join(", ");
      const title = `${weekLabel}: ${val}${breakdown ? ` (${breakdown})` : ""}`;
      return `<g class="activities-status-bar">
        <rect x="${x}" y="${y}" width="${barWidth}" height="${h}" rx="5" fill="${color}">
          <title>${escapeHtml(title)}</title>
        </rect>
        <text class="activities-status-bar-value" x="${x + barWidth / 2}" y="${Math.max(12, y - 8)}" text-anchor="middle">${val}</text>
        <text class="activities-status-bar-label" x="${x + barWidth / 2}" y="${height - 18}" text-anchor="middle">${escapeHtml(weekLabel)}</text>
      </g>`;
    })
    .join("");

  const legend = Array.from({ length: weekCount })
    .map((_, weekIndex) => {
      const label = weeks[weekIndex]?.label || `Week ${weekIndex + 1}`;
      const color = WEEK_BAR_COLORS[weekIndex] || "#64748b";
      return `<span class="activities-status-chart-legend-item"><span class="activities-status-chart-legend-swatch" style="background:${color};"></span>${escapeHtml(label)}: ${weekTotals[weekIndex]}</span>`;
    })
    .join("");

  activitiesStatusWeeklyChartEl.innerHTML = `
    <div class="activities-status-chart-legend">${legend}</div>
    <div class="activities-status-bar-chart-wrap">
      <svg class="activities-status-bar-chart" viewBox="0 0 ${width} ${height}" role="img" aria-label="Status changes by week as a grouped bar chart">
        ${gridLines}
        <line class="activities-status-chart-axis" x1="${pad.left}" y1="${pad.top + plotHeight}" x2="${width - pad.right}" y2="${pad.top + plotHeight}"></line>
        <line class="activities-status-chart-axis" x1="${pad.left}" y1="${pad.top}" x2="${pad.left}" y2="${pad.top + plotHeight}"></line>
        ${bars}
      </svg>
    </div>`;
}

function setBadge(el, count) {
  if (el) el.textContent = String(Number(count || 0));
}

function renderSummary(data) {
  currentActivitiesData = data || {};
  const totals = data.totalsLast30d || {};
  const windowDays = Number(data.windowDays || 30);
  if (activitiesWindowDaysEl) activitiesWindowDaysEl.textContent = String(windowDays);
  if (activitiesWindowSelect && String(activitiesWindowSelect.value) !== String(windowDays)) {
    activitiesWindowSelect.value = String(windowDays);
  }
  if (activitiesEmailsSentCountEl) activitiesEmailsSentCountEl.textContent = String(totals.emailsSent || 0);
  if (activitiesSmsSentCountEl) activitiesSmsSentCountEl.textContent = String(totals.smsSent || 0);
  if (activitiesCallsCountEl) activitiesCallsCountEl.textContent = String(totals.callsMade || 0);
  if (activitiesNewContactsCountEl) activitiesNewContactsCountEl.textContent = String(totals.newContacts || 0);
  if (activitiesEmailOpenedCountEl) activitiesEmailOpenedCountEl.textContent = String(totals.emailOpened || 0);
  if (activitiesEmailClickedCountEl) activitiesEmailClickedCountEl.textContent = String(totals.emailClicked || 0);

  const contact = data.contactActivities || {};
  const user = data.userActivities || {};

  const emailOpened = contact.emailOpened || { count: 0, items: [] };
  renderContactActivityFeed();

  const emailsSent = user.emailsSent || { count: 0, items: [] };
  const smsSent = user.smsSent || { count: 0, items: [] };
  const callsMade = user.callsMade || { count: 0, items: [] };
  const newContacts = user.newContacts || { count: 0, items: [] };

  setBadge(activitiesEmailsSentBadgeEl, emailsSent.count);
  setBadge(activitiesSmsSentBadgeEl, smsSent.count);
  setBadge(activitiesCallsBadgeEl, callsMade.count);
  setBadge(activitiesNewContactsBadgeEl, newContacts.count);

  renderFeedList(activitiesEmailsSentListEl, emailsSent.items, { emptyText: `No emails sent in the last ${windowDays} days.` });
  renderFeedList(activitiesSmsSentListEl, smsSent.items, { emptyText: `No SMS sent in the last ${windowDays} days.` });
  renderFeedList(activitiesCallsListEl, callsMade.items, { emptyText: `No calls logged in the last ${windowDays} days.` });
  renderFeedList(activitiesNewContactsListEl, newContacts.items, {
    emptyText: `No new contacts in the last ${windowDays} days.`,
    labelOverride: "New Contact"
  });

  renderStatusWeeklyChart(data.statusWeeklyComparison);
}

async function loadActivities() {
  const loadingTimer = window.setTimeout(() => showMessage("Loading activities..."), 400);
  if (activitiesRefreshBtn) activitiesRefreshBtn.disabled = true;
  try {
    const { response, data } = await fetchApiJson(`/api/activities/summary?scope=page&days=${selectedWindowDays()}`);
    if (!response.ok) {
      const err = data && data.error ? String(data.error) : `Request failed (${response.status})`;
      throw new Error(err);
    }
    renderSummary(data);
    setLastUpdated();
    showMessage("");
  } catch (error) {
    const msg = error && error.message ? error.message : String(error);
    showMessage(msg, true);
  } finally {
    window.clearTimeout(loadingTimer);
    if (activitiesRefreshBtn) activitiesRefreshBtn.disabled = false;
  }
}

function scrollToElement(el) {
  if (!el) return;
  el.scrollIntoView({ behavior: "smooth", block: "start" });
  el.classList.add("activities-focus-flash");
  window.setTimeout(() => el.classList.remove("activities-focus-flash"), 1200);
}

function handleMetricDrill(drill) {
  const map = {
    emailOpened: () => {
      setActiveContactActivityFilter("emailOpened");
      scrollToElement(activitiesContactEmailOpenedEl?.closest(".activities-main-panel"));
    },
    emailClicked: () => {
      setActiveContactActivityFilter("emailClicked");
      scrollToElement(activitiesContactEmailOpenedEl?.closest(".activities-main-panel"));
    },
    callsMade: () => {
      setActiveContactActivityFilter("callsMade");
      scrollToElement(document.getElementById("activitiesCallsBlock"));
    },
    emailsSent: () => scrollToElement(document.getElementById("activitiesEmailsSentBlock")),
    smsSent: () => scrollToElement(document.getElementById("activitiesSmsSentBlock")),
    newContacts: () => scrollToElement(document.getElementById("activitiesNewContactsBlock"))
  };
  const fn = map[String(drill || "")];
  if (fn) fn();
}

function csvCell(value) {
  const text = String(value == null ? "" : value);
  return `"${text.replace(/"/g, '""')}"`;
}

function rowsForExport() {
  const data = currentActivitiesData || {};
  const user = data.userActivities || {};
  const contactRows = contactActivityItemsForFilter(data, activeContactActivityFilter).map((item) => ({
    section: "Contact Activities",
    type: activityTypeLabel(item),
    contact: item.contact_name,
    detail: formatActivityDetail(item).replace(/<[^>]*>/g, ""),
    created_at: item.created_at
  }));
  const addSection = (section, items) =>
    (Array.isArray(items) ? items : []).map((item) => ({
      section,
      type: activityTypeLabel(item),
      contact: item.contact_name,
      detail: formatActivityDetail(item).replace(/<[^>]*>/g, ""),
      created_at: item.created_at
    }));
  return [
    ...contactRows,
    ...addSection("Emails Sent", user.emailsSent?.items),
    ...addSection("SMS Sent", user.smsSent?.items),
    ...addSection("Calls Made", user.callsMade?.items),
    ...addSection("New Contacts", user.newContacts?.items)
  ];
}

function exportActivitiesCsv() {
  const rows = rowsForExport();
  if (!rows.length) {
    showMessage("No visible activity to export.", true);
    return;
  }
  const header = ["Section", "Type", "Contact", "Detail", "Created At"];
  const csv = [
    header.map(csvCell).join(","),
    ...rows.map((row) => [row.section, row.type, row.contact, row.detail, row.created_at].map(csvCell).join(","))
  ].join("\r\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `cadence-activities-last-${selectedWindowDays()}-days.csv`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
  showMessage("Exported visible activities.");
}

if (activitiesRefreshBtn) {
  activitiesRefreshBtn.addEventListener("click", () => {
    loadActivities();
  });
}

if (activitiesWindowSelect) {
  activitiesWindowSelect.addEventListener("change", () => {
    loadActivities();
  });
}

if (activitiesExportBtn) {
  activitiesExportBtn.addEventListener("click", exportActivitiesCsv);
}

contactActivityFilterBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    setActiveContactActivityFilter(btn.getAttribute("data-contact-activity-filter"));
  });
});

metricCards.forEach((card) => {
  card.addEventListener("click", () => handleMetricDrill(card.getAttribute("data-activity-drill")));
  card.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" && event.key !== " ") return;
    event.preventDefault();
    handleMetricDrill(card.getAttribute("data-activity-drill"));
  });
});

loadActivities();
