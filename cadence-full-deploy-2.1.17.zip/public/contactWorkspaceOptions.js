(function () {
  const QUICK_FILTER_FIELDS_BASE = [
    { value: "tags", label: "Tags" },
    { value: "status", label: "Status" },
    { value: "outcome", label: "Outcome" },
    { value: "lead_source", label: "Lead Source" },
    { value: "insurance_type", label: "Insurance Type" }
  ];
  const QUICK_FILTER_FIELD_CATALOG_BASE = [
    { value: "tags", label: "Tags" },
    { value: "status", label: "Status" },
    { value: "outcome", label: "Outcome" },
    { value: "lead_source", label: "Lead Source" },
    { value: "state", label: "State" },
    { value: "gender", label: "Gender" },
    { value: "city", label: "City" },
    { value: "zip_code", label: "Zip Code" },
    { value: "email", label: "Email" },
    { value: "profession", label: "Profession" },
    { value: "communication_type", label: "Communication Type" },
    { value: "app_id", label: "Policy Number" },
    { value: "income", label: "Income" },
    { value: "quote", label: "Quote" },
    { value: "commission", label: "Commission" },
    { value: "age", label: "Age" },
    { value: "household_size", label: "Household Size" },
    { value: "insurance_type", label: "Insurance Type" }
  ];
  const QUICK_FILTER_FIELD_INDIAN_OWNER = { value: "indian", label: "Indian" };
  const ALLOWED_QUICK_FILTER_VALUES = new Set([
    ...QUICK_FILTER_FIELD_CATALOG_BASE.map((x) => x.value),
    QUICK_FILTER_FIELD_INDIAN_OWNER.value
  ]);

  const SORT_BY_ORDER_MAP = {
    newest: ["created_at", "desc"],
    details_changed: ["updated_at", "desc"],
    last_emailed: ["last_emailed", "desc"],
    last_sms: ["last_sms", "desc"],
    last_called: ["last_called", "desc"],
    last_tagged: ["last_tagged", "desc"],
    full_name: ["full_name", "asc"],
    status: ["status", "asc"],
    outcome: ["outcome", "asc"],
    state: ["state", "asc"],
    lead_source: ["lead_source", "asc"],
    ai_lead_score: ["ai_lead_score", "desc"],
    gender: ["gender", "asc"],
    indian: ["indian", "asc"],
    age: ["age", "desc"],
    profession: ["profession", "asc"],
    income: ["income", "desc"],
    quote: ["quote", "desc"],
    commission: ["commission", "desc"],
    email: ["email", "asc"],
    city: ["city", "asc"],
    zip_code: ["zip_code", "asc"],
    communication_type: ["communication_type", "asc"],
    date_of_contact: ["date_of_contact", "desc"],
    date_of_birth: ["date_of_birth", "desc"],
    coverage_start_date: ["coverage_start_date", "desc"],
    insurance_type: ["insurance_type", "asc"],
    app_id: ["app_id", "asc"],
    household_size: ["household_size", "desc"],
    tags: ["tags", "asc"]
  };

  const SORT_BY_OPTIONS_BASE = [
    { value: "newest", label: "Newest" },
    { value: "details_changed", label: "Details Changed" },
    { value: "last_emailed", label: "Last Emailed" },
    { value: "last_sms", label: "Last SMS" },
    { value: "last_called", label: "Last Called" },
    { value: "last_tagged", label: "Last Tagged" },
    { value: "state", label: "State" },
    { value: "lead_source", label: "Lead Source" },
    { value: "ai_lead_score", label: "AI Score" },
    { value: "gender", label: "Gender" },
    { value: "profession", label: "Profession" },
    { value: "income", label: "Income" },
    { value: "date_of_contact", label: "Date of Contact" },
    { value: "household_size", label: "Household Size" }
  ];

  const SORT_BY_FIELD_CATALOG_BASE = [
    { value: "newest", label: "Newest" },
    { value: "details_changed", label: "Details Changed" },
    { value: "last_emailed", label: "Last Emailed" },
    { value: "last_sms", label: "Last SMS" },
    { value: "last_called", label: "Last Called" },
    { value: "last_tagged", label: "Last Tagged" },
    { value: "full_name", label: "Name" },
    { value: "status", label: "Status" },
    { value: "outcome", label: "Outcome" },
    { value: "state", label: "State" },
    { value: "lead_source", label: "Lead Source" },
    { value: "ai_lead_score", label: "AI Score" },
    { value: "gender", label: "Gender" },
    { value: "age", label: "Age" },
    { value: "profession", label: "Profession" },
    { value: "income", label: "Income" },
    { value: "quote", label: "Quote" },
    { value: "commission", label: "Commission" },
    { value: "email", label: "Email" },
    { value: "city", label: "City" },
    { value: "zip_code", label: "Zip Code" },
    { value: "communication_type", label: "Communication Type" },
    { value: "date_of_contact", label: "Date of Contact" },
    { value: "date_of_birth", label: "Date of Birth" },
    { value: "coverage_start_date", label: "Coverage Start Date" },
    { value: "app_id", label: "Policy Number" },
    { value: "household_size", label: "Household Size" },
    { value: "tags", label: "Tags" }
  ];

  const SORT_BY_OPTION_INDIAN_OWNER = { value: "indian", label: "Indian" };

  const DEFAULTS = {
    quickFilterFields: [...QUICK_FILTER_FIELDS_BASE],
    sortByOptions: [...SORT_BY_OPTIONS_BASE],
    statusLabels: ["NEW", "PENDING", "APPROVED", "DECLINED", "CLOSED", "WORKING", "NOT TAKEN"],
    outcomeLabels: [
      "Bad Email",
      "Bad Number",
      "Call Back",
      "Cannot Afford",
      "Cannot Insure",
      "DECLINED",
      "DNC",
      "Drip Campaign",
      "Employer Plan",
      "Fake Lead",
      "Has Coverage",
      "Long Term CB",
      "No Contact",
      "Not Interested",
      "Referred",
      "Rude",
      "SOLD",
      "Stop",
      "Stopped Responding",
      "Too Many Calls",
      "Very Interested",
      "Wrong Number"
    ],
    leadSourceLabels: [
      "Website",
      "Referral",
      "Telemarketing",
      "Facebook",
      "Instagram",
      "Google",
      "Nextgen"
    ]
  };

  let cache = null;
  const STORAGE_KEY = "crm.contactWorkspaceOptions.v1";
  const DISALLOWED_QUICK_FILTER_VALUES = new Set(["lead_score", "ai_lead_score", "ai_score", "minLeadScore"]);

  function readStoredOptions() {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      return normalizeLoadedOptions(JSON.parse(raw));
    } catch {
      return null;
    }
  }

  function persistOptions(payload) {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    } catch {
      /* ignore quota */
    }
  }

  function isAllowedQuickFilterField(field) {
    const value = String(field?.value || "").trim();
    const label = String(field?.label || value).trim();
    const normalizedLabel = label.toLowerCase().replace(/[^a-z0-9]+/g, "");
    return (
      value &&
      ALLOWED_QUICK_FILTER_VALUES.has(value) &&
      !DISALLOWED_QUICK_FILTER_VALUES.has(value) &&
      normalizedLabel !== "leadscore" &&
      normalizedLabel !== "aileadscore"
    );
  }

  function sanitizeQuickFilterFields(fields) {
    const cleaned = (Array.isArray(fields) ? fields : []).filter(isAllowedQuickFilterField);
    return cleaned.length ? cleaned : getDefaultQuickFilterFields();
  }

  function omitIndianQuickFilterFields(fields) {
    if (!window.__CRM_OMIT_INDIAN_WORKSPACE__) return fields;
    return (Array.isArray(fields) ? fields : []).filter((f) => String(f?.value || "").trim() !== "indian");
  }

  function getDefaultQuickFilterFields() {
    // Indian is catalog-only: owners can add it from Settings, but it is no longer a default Quick Filter field.
    return QUICK_FILTER_FIELDS_BASE.map((x) => ({ ...x }));
  }

  function getQuickFilterFieldCatalog() {
    const fields = QUICK_FILTER_FIELD_CATALOG_BASE.map((x) => ({ ...x }));
    if (!window.__CRM_OMIT_INDIAN_WORKSPACE__) {
      fields.push({ ...QUICK_FILTER_FIELD_INDIAN_OWNER });
    }
    return fields;
  }

  function getDefaultSortByOptions() {
    // Indian is catalog-only: owners can add it from Settings, but it is no longer a default sort field.
    return SORT_BY_OPTIONS_BASE.map((x) => ({ ...x }));
  }

  function getSortByFieldCatalog() {
    const fields = SORT_BY_FIELD_CATALOG_BASE.map((x) => ({ ...x }));
    if (!window.__CRM_OMIT_INDIAN_WORKSPACE__) {
      fields.push({ ...SORT_BY_OPTION_INDIAN_OWNER });
    }
    return fields;
  }

  function withInsuranceTypeQuickFilter(fields) {
    const list = Array.isArray(fields) ? fields.map((x) => ({ ...x })) : [];
    const existing = list.find((row) => String(row?.value || "") === "insurance_type");
    if (existing) {
      existing.label = "Insurance Type";
      return list;
    }
    const row = { value: "insurance_type", label: "Insurance Type" };
    const after = list.findIndex((item) => String(item?.value || "") === "lead_source");
    list.splice(after >= 0 ? after + 1 : list.length, 0, row);
    return list;
  }

  function omitInsuranceTypeSortOption(fields) {
    return (Array.isArray(fields) ? fields : []).filter((row) => String(row?.value || "") !== "insurance_type");
  }

  function omitIndianSortByOptions(fields) {
    if (!window.__CRM_OMIT_INDIAN_WORKSPACE__) return fields;
    return (Array.isArray(fields) ? fields : []).filter((f) => String(f?.value || "").trim() !== "indian");
  }

  function fillSortBySelect(selectEl, options) {
    if (!selectEl) return;
    const prev = String(selectEl.value || "").trim();
    const rows = omitInsuranceTypeSortOption(
      omitIndianSortByOptions(Array.isArray(options) ? options : getDefaultSortByOptions())
    );
    selectEl.replaceChildren();
    for (const row of rows) {
      const value = String(row?.value || "").trim();
      if (!value) continue;
      const opt = document.createElement("option");
      opt.value = value;
      opt.textContent = String(row?.label || value).trim() || value;
      selectEl.appendChild(opt);
    }
    if (prev && [...selectEl.options].some((o) => o.value === prev)) selectEl.value = prev;
    else if (selectEl.options.length) selectEl.value = selectEl.options[0].value;
  }

  function getSortOrderForDropdownValue(value) {
    const key = String(value || "").trim();
    const pair = SORT_BY_ORDER_MAP[key];
    if (!pair) return { sortBy: "updated_at", sortOrder: "desc" };
    return { sortBy: pair[0], sortOrder: pair[1] };
  }

  function sortLabels(values) {
    return [...values].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));
  }

  function mergeValueIntoLabels(value, labels) {
    const v = String(value || "").trim();
    const list = Array.isArray(labels) ? [...labels] : [];
    if (!v) return list;
    const key = v.toLowerCase();
    if (list.some((item) => String(item).toLowerCase() === key)) return list;
    list.push(v);
    return sortLabels(list);
  }

  function fillSelect(selectEl, labels, emptyValue, emptyLabel) {
    if (!selectEl) return;
    const prev = selectEl.value;
    selectEl.replaceChildren();
    const empty = document.createElement("option");
    empty.value = emptyValue;
    empty.textContent = emptyLabel;
    selectEl.appendChild(empty);
    for (const label of labels) {
      const opt = document.createElement("option");
      opt.value = label;
      opt.textContent = label;
      selectEl.appendChild(opt);
    }
    if (prev !== emptyValue && labels.includes(prev)) selectEl.value = prev;
    else selectEl.value = emptyValue;
  }

  const OUTCOME_GROUPS = [
    {
      label: "Positive",
      values: ["Very Interested", "Call Back", "Callback", "Long Term CB", "Drip Campaign", "Drip", "Referred"]
    },
    { label: "Closed", values: ["SOLD", "DEO - INF0", "DEO - INFO", "Approved", "APPROVED", "DECLINED"] },
    {
      label: "Negative",
      values: [
        "Not Interested",
        "Cannot Afford",
        "Has Coverage",
        "Medicare/P&A",
        "DNC",
        "Fax",
        "Employer Plan",
        "Cannot Insure",
        "No Contact",
        "Stop",
        "Stopped Responding",
        "Too Many Calls"
      ]
    },
    { label: "Bad Data", values: ["Bad Email", "Bad Number", "Wrong Number", "Fake Lead", "Rude"] }
  ];

  function normalizeOutcomeMatchKey(value) {
    const key = String(value || "")
      .trim()
      .toLowerCase()
      .replace(/[\s-]+/g, "");
    if (key === "drip") return "dripcampaign";
    if (key === "deoinf0") return "deoinfo";
    return key;
  }

  function pickPreferredOutcomeLabel(candidates, canonical) {
    const list = Array.isArray(candidates) ? candidates.filter(Boolean) : [];
    if (!list.length) return "";
    const want = String(canonical || "").trim().toLowerCase();
    if (want) {
      const exact = list.find((item) => String(item).trim().toLowerCase() === want);
      if (exact) return exact;
    }
    return list[0];
  }

  function selectOutcomeOption(selectEl, desired, emptyValue) {
    if (!selectEl) return;
    const want = String(desired || "").trim();
    const empty = emptyValue == null ? "" : String(emptyValue);
    if (!want || want === empty) {
      selectEl.value = empty;
      return;
    }
    const options = [...selectEl.options];
    if (options.some((opt) => opt.value === want && !opt.disabled)) {
      selectEl.value = want;
      return;
    }
    const wantKey = normalizeOutcomeMatchKey(want);
    const match = options.find((opt) => opt.value && !opt.disabled && normalizeOutcomeMatchKey(opt.value) === wantKey);
    selectEl.value = match ? match.value : empty;
  }

  function appendOutcomeGroupHeader(selectEl, label) {
    const header = document.createElement("option");
    header.disabled = true;
    header.value = "";
    header.textContent = label;
    header.className = "contact-outcome-group-label";
    selectEl.appendChild(header);
  }

  function fillGroupedOutcomeSelect(selectEl, labels, emptyValue, emptyLabel) {
    if (!selectEl) return;
    const prev = selectEl.value;
    const sortedLabels = sortLabels(labels || []);
    const byNorm = new Map();
    for (const label of sortedLabels) {
      const text = String(label || "").trim();
      const key = normalizeOutcomeMatchKey(text);
      if (!key) continue;
      const bucket = byNorm.get(key) || [];
      if (!bucket.some((item) => String(item).toLowerCase() === text.toLowerCase())) bucket.push(text);
      byNorm.set(key, bucket);
    }
    const usedNorm = new Set();
    const useOptionHeaders = !!(selectEl.closest && selectEl.closest(".filter-toolbar"));
    selectEl.replaceChildren();
    const empty = document.createElement("option");
    empty.value = emptyValue;
    empty.textContent = emptyLabel;
    selectEl.appendChild(empty);

    function appendOutcomeOptions(target, values) {
      for (const match of values) {
        const opt = document.createElement("option");
        opt.value = match;
        opt.textContent = match;
        target.appendChild(opt);
      }
    }

    function collectGroupMatches(group) {
      const groupMatches = [];
      for (const value of group.values) {
        const key = normalizeOutcomeMatchKey(value);
        if (!key || usedNorm.has(key)) continue;
        const candidates = byNorm.get(key);
        if (!candidates || !candidates.length) continue;
        usedNorm.add(key);
        groupMatches.push(pickPreferredOutcomeLabel(candidates, value));
      }
      return groupMatches;
    }

    for (const group of OUTCOME_GROUPS) {
      const groupMatches = collectGroupMatches(group);
      if (!groupMatches.length) continue;
      if (useOptionHeaders) {
        appendOutcomeGroupHeader(selectEl, group.label);
        appendOutcomeOptions(selectEl, groupMatches);
      } else {
        const groupEl = document.createElement("optgroup");
        groupEl.label = group.label;
        appendOutcomeOptions(groupEl, groupMatches);
        selectEl.appendChild(groupEl);
      }
    }
    const other = [];
    const otherSeen = new Set();
    for (const label of sortedLabels) {
      const key = normalizeOutcomeMatchKey(label);
      if (!key || usedNorm.has(key) || otherSeen.has(key)) continue;
      otherSeen.add(key);
      other.push(pickPreferredOutcomeLabel(byNorm.get(key), label));
    }
    if (other.length) {
      if (useOptionHeaders) {
        appendOutcomeGroupHeader(selectEl, "Other");
        appendOutcomeOptions(selectEl, other);
      } else {
        const groupEl = document.createElement("optgroup");
        groupEl.label = "Other";
        appendOutcomeOptions(groupEl, other);
        selectEl.appendChild(groupEl);
      }
    }
    selectOutcomeOption(selectEl, prev, emptyValue);
  }

  function fillSelectRequired(selectEl, labels, fallbackValue) {
    if (!selectEl) return;
    const prev = String(selectEl.value || "").trim();
    selectEl.replaceChildren();
    for (const label of labels) {
      const opt = document.createElement("option");
      opt.value = label;
      opt.textContent = label;
      selectEl.appendChild(opt);
    }
    const fallback = String(fallbackValue || labels[0] || "").trim();
    if (prev && labels.includes(prev)) selectEl.value = prev;
    else if (fallback && labels.includes(fallback)) selectEl.value = fallback;
    else selectEl.value = labels[0] || "";
  }

  function fillQuickFilterSelect(selectEl, fields) {
    if (!selectEl) return;
    const prev = selectEl.value;
    const rows = withInsuranceTypeQuickFilter(Array.isArray(fields) ? fields : getDefaultQuickFilterFields());
    selectEl.replaceChildren();
    for (const field of rows) {
      const opt = document.createElement("option");
      opt.value = field.value;
      opt.textContent = field.label;
      if (field.value === prev) opt.selected = true;
      selectEl.appendChild(opt);
    }
    if (!rows.some((f) => f.value === prev) && rows.length) {
      selectEl.value = rows[0].value;
    }
  }

  function applyAll(root) {
    const scope = root && root.querySelector ? root : document;
    const options = getCached();
    const statuses = options.statusLabels || DEFAULTS.statusLabels;
    const outcomes = sortLabels(options.outcomeLabels || DEFAULTS.outcomeLabels);
    const leadSources = sortLabels(options.leadSourceLabels || DEFAULTS.leadSourceLabels);
    const quickFields = withInsuranceTypeQuickFilter(
      sanitizeQuickFilterFields(
        omitIndianQuickFilterFields(options.quickFilterFields || getDefaultQuickFilterFields())
      )
    );
    const sortByOptions = omitInsuranceTypeSortOption(
      omitIndianSortByOptions(
        Array.isArray(options.sortByOptions) && options.sortByOptions.length
          ? options.sortByOptions
          : getDefaultSortByOptions()
      )
    );

    fillSelect(scope.querySelector("#statusFilter"), statuses, "", "Select Status");
    fillGroupedOutcomeSelect(scope.querySelector("#outcomeFilter"), outcomes, "", "Select Outcome");
    fillSelect(scope.querySelector("#contactsFilterSelect"), leadSources, "", "Select Lead Source");
    fillQuickFilterSelect(scope.querySelector("#quickFilterField"), quickFields);
    fillSortBySelect(scope.querySelector("#statusHeaderDropdown"), sortByOptions);

    scope.querySelectorAll("#contactStatusSelect").forEach((el) => {
      const onContactPage = !!(el.closest && el.closest("#contactPageForm"));
      if (onContactPage) fillSelectRequired(el, statuses, "NEW");
      else fillSelect(el, statuses, "", "Select Status");
    });
    scope.querySelectorAll("#contactOutcomeSelect").forEach((el) => {
      fillGroupedOutcomeSelect(el, outcomes, "", "Select outcome");
    });
    scope.querySelectorAll("#lead_source").forEach((el) => {
      const inAddModal = !!(el.closest && el.closest("#addContactModal"));
      fillSelect(el, leadSources, "", inAddModal ? "Lead Source (optional)" : "—");
    });
    scope.querySelectorAll("select[name='lead_source']").forEach((el) => {
      if (el.id === "lead_source") return;
      fillSelect(el, leadSources, "", "Lead Source (optional)");
    });

    applyWorkspaceUiLabels(scope);
  }

  function applyContactPageForm(scope, contact) {
    const root = scope && scope.querySelector ? scope : document;
    const form = root.querySelector("#contactPageForm");
    if (!form) return;
    const c = contact && typeof contact === "object" ? contact : {};
    const options = getCached();
    const statuses = mergeValueIntoLabels(c.status, options.statusLabels || DEFAULTS.statusLabels);
    const outcomes = mergeValueIntoLabels(c.outcome, options.outcomeLabels || DEFAULTS.outcomeLabels);
    const leadSources = mergeValueIntoLabels(c.lead_source, options.leadSourceLabels || DEFAULTS.leadSourceLabels);

    fillSelectRequired(form.querySelector("#contactStatusSelect"), statuses, "NEW");
    fillGroupedOutcomeSelect(form.querySelector("#contactOutcomeSelect"), outcomes, "", "Select outcome");
    fillSelect(form.querySelector("#lead_source"), leadSources, "", "—");

    if (c.status) {
      const statusEl = form.querySelector("#contactStatusSelect");
      if (statusEl) statusEl.value = String(c.status).trim();
    }
    if (c.outcome) {
      const outcomeEl = form.querySelector("#contactOutcomeSelect");
      if (outcomeEl) selectOutcomeOption(outcomeEl, String(c.outcome).trim(), "");
    }
    if (c.lead_source) {
      const leadEl = form.querySelector("#lead_source");
      if (leadEl) leadEl.value = String(c.lead_source).trim();
    }

    applyWorkspaceUiLabels(form);
  }

  function normalizeLoadedOptions(data) {
    const payload = data && typeof data === "object" ? data : {};
    if (payload.workspaceUi?.omitIndian) window.__CRM_OMIT_INDIAN_WORKSPACE__ = true;
    if (payload.workspaceUi?.indianFieldLabel) {
      window.__CRM_INDIAN_FIELD_LABEL__ = String(payload.workspaceUi.indianFieldLabel);
    }
    const quickFilterFields = withInsuranceTypeQuickFilter(
      sanitizeQuickFilterFields(
        omitIndianQuickFilterFields(
          Array.isArray(payload.quickFilterFields) && payload.quickFilterFields.length
            ? payload.quickFilterFields
            : getDefaultQuickFilterFields()
        )
      )
    );
    const statusLabels =
      Array.isArray(payload.statusLabels) && payload.statusLabels.length ? payload.statusLabels : DEFAULTS.statusLabels;
    const outcomeLabels =
      Array.isArray(payload.outcomeLabels) && payload.outcomeLabels.length
        ? payload.outcomeLabels
        : DEFAULTS.outcomeLabels;
    const leadSourceLabels =
      Array.isArray(payload.leadSourceLabels) && payload.leadSourceLabels.length
        ? payload.leadSourceLabels
        : DEFAULTS.leadSourceLabels;
    const sortByOptions = omitInsuranceTypeSortOption(
      Array.isArray(payload.sortByOptions) && payload.sortByOptions.length
        ? payload.sortByOptions
        : getDefaultSortByOptions()
    );
    return { quickFilterFields, statusLabels, outcomeLabels, leadSourceLabels, sortByOptions };
  }

  function setCache(payload) {
    cache = normalizeLoadedOptions(payload);
    persistOptions(cache);
    return cache;
  }

  async function fetchWorkspaceOptionsFromApi() {
    const fetchOpts = { cache: "no-store", timeoutMs: 8000 };
    if (window.CrmApi?.fetchApiJson) {
      const { response, data } = await window.CrmApi.fetchApiJson("/api/contacts/workspace-options", fetchOpts);
      if (!response.ok) throw new Error(data.error || "Failed to load contact workspace options");
      return normalizeLoadedOptions(data);
    }
    const controller = typeof AbortController !== "undefined" ? new AbortController() : null;
    const timer = controller ? setTimeout(() => controller.abort(), 8000) : null;
    try {
      const response = await fetch("/api/contacts/workspace-options", {
        credentials: "include",
        cache: "no-store",
        signal: controller ? controller.signal : undefined
      });
      const text = await response.text();
      const data = text ? JSON.parse(text) : {};
      if (!response.ok) throw new Error(data.error || "Failed to load contact workspace options");
      return normalizeLoadedOptions(data);
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  async function load(force) {
    if (cache && !force) return cache;
    if (window.__CRM_WORKSPACE_UI_READY__) {
      try {
        await window.__CRM_WORKSPACE_UI_READY__;
      } catch {
        /* continue */
      }
    }
    const stored = readStoredOptions();
    try {
      cache = await fetchWorkspaceOptionsFromApi();
      persistOptions(cache);
    } catch (error) {
      if (stored) {
        cache = stored;
      } else if (force) {
        throw error;
      }
    }
    return getCached();
  }

  async function reloadAndApply(root) {
    cache = null;
    await load(true);
    applyAll(root && root.querySelector ? root : document);
    return getCached();
  }

  function getCached() {
    return cache || DEFAULTS;
  }

  function getQuickFilterFieldLabel(fieldValue, fallback) {
    const value = String(fieldValue || "").trim();
    const fb = String(fallback || value || "").trim() || value;
    const fields = getCached().quickFilterFields || getDefaultQuickFilterFields();
    const found = fields.find((f) => String(f?.value || "").trim() === value);
    if (found) return String(found.label || fb).trim() || fb;
    const catalog = getQuickFilterFieldCatalog().find((f) => f.value === value);
    return catalog ? String(catalog.label || fb).trim() || fb : fb;
  }

  function applyWorkspaceUiLabels(scope) {
    const root = scope && scope.querySelector ? scope : document;
    const statusLabel = getQuickFilterFieldLabel("status", "Status");
    const outcomeLabel = getQuickFilterFieldLabel("outcome", "Outcome");
    const leadSourceLabel = getQuickFilterFieldLabel("lead_source", "Lead Source");

    const bulkSelect = root.querySelector("#bulkActionSelect");
    if (bulkSelect) {
      const bulkLabels = {
        "change-status": `Change ${statusLabel}`,
        "change-outcome": `Change ${outcomeLabel}`,
        "change-lead-source": `Change ${leadSourceLabel}`
      };
      for (const opt of bulkSelect.options) {
        if (bulkLabels[opt.value]) opt.textContent = bulkLabels[opt.value];
      }
    }

    const leadSourceHeader = root.querySelector(".contacts-col-lead-source");
    if (leadSourceHeader) leadSourceHeader.textContent = leadSourceLabel;

    const contactsFilter = root.querySelector("#contactsFilterSelect");
    if (contactsFilter) {
      contactsFilter.setAttribute("aria-label", `Filter contacts by ${leadSourceLabel.toLowerCase()}`);
      const emptyOpt = contactsFilter.querySelector('option[value=""]');
      if (emptyOpt) emptyOpt.textContent = `Select ${leadSourceLabel}`;
    }

    const sortLeadSourceOpt = root.querySelector('#statusHeaderDropdown option[value="lead_source"]');
    if (sortLeadSourceOpt) sortLeadSourceOpt.textContent = leadSourceLabel;

    const sortByOptions = omitIndianSortByOptions(getCached().sortByOptions || getDefaultSortByOptions());
    for (const row of sortByOptions) {
      const value = String(row?.value || "").trim();
      if (!value) continue;
      const opt = root.querySelector(`#statusHeaderDropdown option[value="${value}"]`);
      if (opt) opt.textContent = String(row.label || opt.textContent || value).trim() || value;
    }

    const statusFilterEl = root.querySelector("#statusFilter");
    if (statusFilterEl) {
      const emptyOpt = statusFilterEl.querySelector('option[value=""]');
      if (emptyOpt) emptyOpt.textContent = `Select ${statusLabel}`;
    }

    const outcomeFilterEl = root.querySelector("#outcomeFilter");
    if (outcomeFilterEl) {
      const emptyOpt = outcomeFilterEl.querySelector('option[value=""]');
      if (emptyOpt) emptyOpt.textContent = `Select ${outcomeLabel}`;
    }

    const contactStatusLabel = root.querySelector('label[for="contactStatusSelect"]');
    if (contactStatusLabel) contactStatusLabel.textContent = statusLabel;
    const contactOutcomeLabel = root.querySelector('label[for="contactOutcomeSelect"]');
    if (contactOutcomeLabel) contactOutcomeLabel.textContent = outcomeLabel;
    const contactLeadSourceLabel = root.querySelector('label[for="lead_source"]');
    if (contactLeadSourceLabel) contactLeadSourceLabel.textContent = leadSourceLabel;
    const contactLeadSourceSelect = root.querySelector("#lead_source");
    if (contactLeadSourceSelect) contactLeadSourceSelect.setAttribute("aria-label", leadSourceLabel);
  }

  function getStatusLabels() {
    return getCached().statusLabels || DEFAULTS.statusLabels;
  }

  // Statuses that represent active/enrolled clients (used by the Leads/Clients tab segmentation).
  // Anything NOT in this list is treated as a lead.
  const CLIENT_STATUS_DEFAULTS = ["APS", "APPROVED", "SOLD", "CLOSED", "Enrolled", "Active"];

  function getClientStatusLabels() {
    const all = getStatusLabels();
    // Return statuses from the user's full list that match known client status names
    const clientNorm = new Set(CLIENT_STATUS_DEFAULTS.map((s) => s.toLowerCase().trim()));
    const matched = all.filter((s) => clientNorm.has(String(s).toLowerCase().trim()));
    // Always fall back to defaults if nothing matches (e.g. all-custom labels)
    return matched.length > 0 ? matched : CLIENT_STATUS_DEFAULTS.slice(0, 4);
  }

  function getOutcomeLabels() {
    return sortLabels(getCached().outcomeLabels || DEFAULTS.outcomeLabels);
  }

  function getLeadSourceLabels() {
    return sortLabels(getCached().leadSourceLabels || DEFAULTS.leadSourceLabels);
  }

  function getSortByOptions() {
    return omitInsuranceTypeSortOption(
      omitIndianSortByOptions(getCached().sortByOptions || getDefaultSortByOptions())
    );
  }

  window.addEventListener("storage", (event) => {
    if (event.key !== STORAGE_KEY || !event.newValue) return;
    try {
      setCache(JSON.parse(event.newValue));
      applyAll(document);
      window.dispatchEvent(new Event("crm-workspace-options-applied"));
    } catch {
      /* ignore */
    }
  });

  window.CrmContactWorkspaceOptions = {
    load,
    reloadAndApply,
    setCache,
    applyAll,
    applyContactPageForm,
    applyWorkspaceUiLabels,
    fillGroupedOutcomeSelect,
    selectOutcomeOption,
    getCached,
    getQuickFilterFieldLabel,
    getQuickFilterFieldCatalog,
    getStatusLabels,
    getClientStatusLabels,
    getOutcomeLabels,
    getLeadSourceLabels,
    getSortByOptions,
    getSortByFieldCatalog,
    getSortOrderForDropdownValue,
    defaults: {
      ...DEFAULTS,
      get quickFilterFields() {
        return getDefaultQuickFilterFields();
      },
      get sortByOptions() {
        return getDefaultSortByOptions();
      }
    }
  };
})();
