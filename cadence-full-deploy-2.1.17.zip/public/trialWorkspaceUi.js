/**
 * Owner vs trial workspace UI. Indian field/filters exist only on the owner (personal) workspace.
 */
(function () {
  const OWNER_INDIAN_LABEL = "Indian";

  function isTrialWorkspace(data) {
    const ws = data && data.workspace;
    if (ws && ws.type === "trial") return true;
    if (ws && ws.type === "owner") return false;
    const tid = Number(data?.subscription?.tenantId || ws?.tenantId || 0);
    return Number.isInteger(tid) && tid > 1;
  }

  function applyTrialDomPatches() {
    window.__CRM_OMIT_INDIAN_WORKSPACE__ = true;

    const quickFilter = document.getElementById("quickFilterField");
    if (quickFilter) {
      quickFilter.querySelectorAll('option[value="indian"]').forEach((opt) => opt.remove());
      if (quickFilter.value === "indian" && quickFilter.options.length) {
        quickFilter.value = quickFilter.options[0].value;
      }
    }

    const sortBy = document.getElementById("statusHeaderDropdown");
    if (sortBy) {
      sortBy.querySelectorAll('option[value="indian"]').forEach((opt) => opt.remove());
      if (sortBy.value === "indian") sortBy.value = "newest";
    }

    const indianSelect = document.getElementById("indian");
    if (indianSelect) {
      const box = indianSelect.closest(".contact-field-box");
      if (box) box.remove();
      else indianSelect.remove();
    }

    document.querySelectorAll(".help-body li").forEach((li) => {
      const html = li.innerHTML;
      if (html.includes('"Indian" lead flag')) {
        li.innerHTML = html.replace(/, or "Indian" lead flag/g, "");
      }
    });

    document.querySelectorAll("option[data-owner-only]").forEach((opt) => opt.remove());
    document.querySelectorAll("select[data-owner-only]").forEach((el) => el.remove());

    const audience = document.getElementById("aiContentAudience");
    const audienceBox = document.getElementById("aiContentAudienceBox");
    if (audience && audienceBox) {
      const remaining = Array.from(audience.options).filter((o) => String(o.value || "").trim());
      if (remaining.length <= 1) {
        audience.value = remaining[0] ? remaining[0].value : "consumer";
        audienceBox.hidden = true;
        audienceBox.setAttribute("aria-hidden", "true");
      }
    }

    document.querySelectorAll("[data-owner-only]").forEach((el) => {
      if (el.tagName === "OPTION") return;
      el.remove();
    });
  }

  function applyOwnerOnlyVisibility() {
    const trial = window.__CRM_WORKSPACE_TYPE__ === "trial";
    document.querySelectorAll("[data-owner-only]").forEach((el) => {
      if (el.tagName === "OPTION") return;
      const hide = trial;
      el.hidden = hide;
      if (hide) el.setAttribute("aria-hidden", "true");
      else el.removeAttribute("aria-hidden");
    });
  }

  async function initWorkspaceUi() {
    if (window.__CRM_WORKSPACE_UI_APPLIED__) return window.__CRM_WORKSPACE_TYPE__ || "owner";

    let data = null;
    const controller = typeof AbortController !== "undefined" ? new AbortController() : null;
    const timer = controller ? setTimeout(() => controller.abort(), 4000) : null;
    try {
      const res = await fetch("/api/auth/status", {
        credentials: "include",
        signal: controller ? controller.signal : undefined
      });
      const text = await res.text();
      data = text ? JSON.parse(text) : {};
    } catch {
      data = null;
    } finally {
      if (timer) clearTimeout(timer);
    }

    const trial = data && data.authenticated && isTrialWorkspace(data);
    if (trial) {
      window.__CRM_OMIT_INDIAN_WORKSPACE__ = true;
      window.__CRM_WORKSPACE_TYPE__ = "trial";
      if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", applyTrialDomPatches, { once: true });
      } else {
        applyTrialDomPatches();
      }
    } else {
      window.__CRM_INDIAN_FIELD_LABEL__ = window.__CRM_INDIAN_FIELD_LABEL__ || OWNER_INDIAN_LABEL;
      window.__CRM_WORKSPACE_TYPE__ = "owner";
    }

    window.__CRM_WORKSPACE_UI_APPLIED__ = true;
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", applyOwnerOnlyVisibility, { once: true });
    } else {
      applyOwnerOnlyVisibility();
    }
    window.dispatchEvent(new Event("crm-workspace-ui-ready"));
    return window.__CRM_WORKSPACE_TYPE__;
  }

  window.__CRM_WORKSPACE_UI_READY__ = initWorkspaceUi();
})();
