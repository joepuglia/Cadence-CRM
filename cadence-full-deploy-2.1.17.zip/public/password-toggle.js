/**

 * Wires eye buttons in `.crm-password-wrap` to toggle visibility.

 * Login fields use type=password; API/bank secrets use masked text to avoid browser login autofill.

 */

(function initCrmPasswordToggleIife() {

  function usesSensitiveMask(input) {

    return input && input.dataset.crmSensitiveMask === "1";

  }



  function isInputVisible(input) {

    if (usesSensitiveMask(input)) return !input.classList.contains("crm-sensitive-masked");

    return input.type === "text";

  }



  function syncIcons(wrap, input, btn) {

    const visible = isInputVisible(input);

    const showIcon = wrap.querySelector(".crm-password-toggle-icon--show");

    const hideIcon = wrap.querySelector(".crm-password-toggle-icon--hide");

    const showLabel = btn.dataset.showLabel || "Show password";

    const hideLabel = btn.dataset.hideLabel || "Hide password";

    btn.setAttribute("aria-label", visible ? hideLabel : showLabel);

    btn.setAttribute("title", visible ? hideLabel : showLabel);

    btn.setAttribute("aria-pressed", visible ? "true" : "false");

    if (showIcon) showIcon.toggleAttribute("hidden", visible);

    if (hideIcon) hideIcon.toggleAttribute("hidden", !visible);

  }



  function setMasked(input, masked) {

    input.type = "text";

    input.classList.toggle("crm-sensitive-masked", masked);

  }



  function crmInitPasswordToggles(root) {

    const el = root && root.querySelectorAll ? root : document;

    el.querySelectorAll(".crm-password-wrap").forEach((wrap) => {

      const input = wrap.querySelector("input");

      const btn = wrap.querySelector(".crm-password-toggle");

      if (!input || !btn) return;

      if (btn.dataset.crmPwToggleBound === "1") return;

      btn.dataset.crmPwToggleBound = "1";

      if (usesSensitiveMask(input)) {

        input.type = "text";

        if (!input.classList.contains("crm-sensitive-masked")) {

          input.classList.add("crm-sensitive-masked");

        }

      }

      btn.addEventListener("click", () => {

        if (usesSensitiveMask(input)) {

          setMasked(input, isInputVisible(input));

        } else {

          input.type = input.type === "password" ? "text" : "password";

        }

        syncIcons(wrap, input, btn);

      });

      syncIcons(wrap, input, btn);

    });

  }



  function crmHidePasswordInput(input) {

    if (!input) return;

    if (usesSensitiveMask(input)) {

      setMasked(input, true);

    } else {

      input.type = "password";

    }

    const wrap = input.closest(".crm-password-wrap");

    if (!wrap) return;

    const btn = wrap.querySelector(".crm-password-toggle");

    if (btn) syncIcons(wrap, input, btn);

  }



  window.crmInitPasswordToggles = crmInitPasswordToggles;

  window.crmHidePasswordInput = crmHidePasswordInput;



  if (document.readyState === "loading") {

    document.addEventListener("DOMContentLoaded", () => crmInitPasswordToggles(document));

  } else {

    crmInitPasswordToggles(document);

  }

})();


