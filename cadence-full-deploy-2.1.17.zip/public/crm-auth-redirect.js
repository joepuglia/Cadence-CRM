/**
 * Redirects to login when the session expires or API calls return 401.
 * Loaded on CRM app pages (injected by server.js or included in HTML).
 */
(function initCrmAuthRedirect() {
  const LOGIN_TIMEOUT_MESSAGE_KEY = "crm_login_timeout_msg";
  const LOGIN_TIMEOUT_AT_KEY = "crm_login_timeout_at";
  const HAD_AUTH_SESSION_KEY = "crm_had_authenticated_session";

  const SKIP_PAGE =
    /^\/(login|signup|welcome|billing|contact-sales|terms)(\.html)?$/i.test(window.location.pathname) ||
    window.location.pathname.startsWith("/marketing-previews/");

  const AUTH_EXEMPT_401 = /^\/api\/auth\/(login|signup|register|forgot|reset|verify)/i;

  let redirectStarted = false;

  function hadAuthenticatedSession() {
    try {
      return (
        localStorage.getItem(HAD_AUTH_SESSION_KEY) === "1" ||
        sessionStorage.getItem(HAD_AUTH_SESSION_KEY) === "1"
      );
    } catch {
      return false;
    }
  }

  function markHadAuthenticatedSession() {
    try {
      sessionStorage.setItem(HAD_AUTH_SESSION_KEY, "1");
      localStorage.setItem(HAD_AUTH_SESSION_KEY, "1");
    } catch {
      /* ignore */
    }
  }

  function apiPathFromFetchInput(input) {
    try {
      const raw = typeof input === "string" ? input : input?.url || "";
      const url = new URL(raw, window.location.origin);
      return url.pathname || "";
    } catch {
      return "";
    }
  }

  function redirectToLogin(options = {}) {
    if (redirectStarted) return;
    redirectStarted = true;

    const next = encodeURIComponent(window.location.pathname + window.location.search);
    const idleMin = Math.max(1, Math.round(Number(options.idleMinutes) || 60));
    const timedOut =
      options.sessionExpired === true ||
      options.sessionTimedOut === true ||
      (options.sessionExpired !== false && hadAuthenticatedSession());

    if (timedOut) {
      const msg =
        String(options.message || "").trim() ||
        `You were signed out after ${idleMin} minutes of inactivity.`;
      try {
        sessionStorage.setItem(LOGIN_TIMEOUT_MESSAGE_KEY, msg);
        sessionStorage.setItem(LOGIN_TIMEOUT_AT_KEY, String(Date.now()));
        localStorage.setItem(LOGIN_TIMEOUT_MESSAGE_KEY, msg);
        localStorage.setItem(LOGIN_TIMEOUT_AT_KEY, String(Date.now()));
        localStorage.setItem(HAD_AUTH_SESSION_KEY, "1");
      } catch {
        /* ignore */
      }
      window.location.replace(`/login.html?timeout=1&sessionExpired=1&idle=${idleMin}&next=${next}`);
      return;
    }
    window.location.replace(`/login.html?next=${next}`);
  }

  function isAuthFailureMessage(text) {
    const s = String(text || "").trim().toLowerCase();
    if (!s) return false;
    return /please log in to continue/i.test(s) || /session expired due to inactivity/i.test(s);
  }

  function handleUnauthorizedResponse(response, payload) {
    if (!response || response.status !== 401) return false;
    const data = payload && typeof payload === "object" ? payload : {};
    const msg = String(data.error || data.message || "").trim();
    redirectToLogin({
      sessionExpired: Boolean(data.sessionExpired) || /session expired/i.test(msg) || hadAuthenticatedSession(),
      idleMinutes: 60,
      message: /session expired/i.test(msg) ? `You were signed out after 60 minutes of inactivity.` : ""
    });
    return true;
  }

  function handleAuthErrorMessage(text, isError = true) {
    if (!isError || !isAuthFailureMessage(text)) return false;
    redirectToLogin({
      sessionExpired: /session expired/i.test(String(text || "")) || hadAuthenticatedSession(),
      idleMinutes: 60
    });
    return true;
  }

  function shouldPatchFetch401(input) {
    if (SKIP_PAGE || window.__CRM_SCREENSHOT_CAPTURE__) return false;
    const path = apiPathFromFetchInput(input);
    if (!path.startsWith("/api/")) return false;
    if (AUTH_EXEMPT_401.test(path)) return false;
    return true;
  }

  if (!SKIP_PAGE && !window.__CRM_SCREENSHOT_CAPTURE__) {
    const nativeFetch = window.fetch.bind(window);
    window.fetch = async function crmAuthFetch(input, init) {
      const response = await nativeFetch(input, init);
      if (redirectStarted || !shouldPatchFetch401(input)) return response;
      const path = apiPathFromFetchInput(input);
      if (response.ok && path.startsWith("/api/") && !AUTH_EXEMPT_401.test(path)) {
        markHadAuthenticatedSession();
        return response;
      }
      if (response.status !== 401) return response;
      try {
        const data = await response.clone().json().catch(() => ({}));
        handleUnauthorizedResponse(response, data);
      } catch {
        redirectToLogin({ sessionExpired: hadAuthenticatedSession(), idleMinutes: 60 });
      }
      return response;
    };
  }

  window.crmRedirectToLogin = redirectToLogin;
  window.crmHandleUnauthorizedResponse = handleUnauthorizedResponse;
  window.crmHandleAuthErrorMessage = handleAuthErrorMessage;
  window.crmMarkHadAuthenticatedSession = markHadAuthenticatedSession;
})();
