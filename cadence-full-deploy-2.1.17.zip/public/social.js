const socialMessageEl = document.getElementById("message");
const socialPostForm = document.getElementById("socialPostForm");
const socialMessageInput = document.getElementById("socialMessage");
const socialMediaSelect = document.getElementById("socialMediaSelect");
const socialTargetsHost = document.getElementById("socialTargets");
const socialExtraTargetsInput = document.getElementById("socialExtraTargets");
const socialPostsList = document.getElementById("socialPostsList");
const socialMediaLibrary = document.getElementById("socialMediaLibrary");
const socialWebhookSetupNotice = document.getElementById("socialWebhookSetupNotice");
const socialCharCounter = document.getElementById("socialCharCounter");
const socialScheduleFieldWrap = document.getElementById("socialScheduleFieldWrap");
const socialScheduleAtInput = document.getElementById("socialScheduleAt");
const socialPostSubmitBtn = document.getElementById("socialPostSubmitBtn");
const socialMediaSearchInput = document.getElementById("socialMediaSearchInput");
const socialMediaCategoryFilter = document.getElementById("socialMediaCategoryFilter");

const socialLibraryUploadForm = document.getElementById("socialLibraryUploadForm");
const socialLibraryFileInput = document.getElementById("socialLibraryFileInput");
const socialLibraryPickBtn = document.getElementById("socialLibraryPickBtn");
const socialLibraryFileLabel = document.getElementById("socialLibraryFileLabel");
const socialLibraryUploadMessage = document.getElementById("socialLibraryUploadMessage");

let cachedPlatforms = [];
let cachedPlatformMeta = [];
let connectedPlatformCount = 0;
let cachedMedia = [];
let cachedVideos = [];
let mediaSearchQuery = "";
let mediaCategoryFilter = "ALL";

const SOCIAL_TARGET_LABELS = {
  facebook: "Facebook",
  instagram: "Instagram",
  x: "X",
  linkedin: "LinkedIn"
};

const SOCIAL_CHAR_LIMITS = {
  facebook: 63206,
  instagram: 2200,
  x: 280,
  linkedin: 3000
};

function socialTargetLabel(target) {
  const key = String(target || "").trim().toLowerCase();
  return SOCIAL_TARGET_LABELS[key] || key.charAt(0).toUpperCase() + key.slice(1);
}

function getCharLimitForTarget(target) {
  const key = String(target || "").trim().toLowerCase();
  return SOCIAL_CHAR_LIMITS[key] || 5000;
}

function showMessage(text, isError = false) {
  if (!socialMessageEl) return;
  const str = String(text || "");
  if (isError && typeof window.crmHandleAuthErrorMessage === "function" && window.crmHandleAuthErrorMessage(str, isError)) {
    return;
  }
  socialMessageEl.textContent = str;
  socialMessageEl.style.color = isError ? "#c62828" : "#1b5e20";
}

function showLibraryUploadMessage(text, isError = false) {
  if (!socialLibraryUploadMessage) return;
  socialLibraryUploadMessage.textContent = String(text || "");
  socialLibraryUploadMessage.style.color = isError ? "#b91c1c" : "#047857";
}

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function formatUnix(value) {
  const n = Number(value || 0);
  if (!Number.isFinite(n) || n < 1) return "—";
  return new Date(n * 1000).toLocaleString();
}

function formatBytes(n) {
  const size = Number(n || 0);
  if (!Number.isFinite(size) || size <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  let val = size;
  let idx = 0;
  while (val >= 1024 && idx < units.length - 1) {
    val /= 1024;
    idx += 1;
  }
  return `${val.toFixed(idx === 0 ? 0 : 1)} ${units[idx]}`;
}

function truncateText(text, max = 160) {
  const str = String(text || "").trim();
  if (str.length <= max) return str;
  return `${str.slice(0, max - 1)}…`;
}

async function fetchApiJson(path, init) {
  const response = await fetch(path, { credentials: "include", ...init });
  const text = await response.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = {};
  }
  return { response, data };
}

function syncWebhookSetupNotice() {
  if (!socialWebhookSetupNotice) return;
  socialWebhookSetupNotice.hidden = connectedPlatformCount > 0;
}

function selectedTargets() {
  const fromChecks = [...socialTargetsHost.querySelectorAll('input[type="checkbox"][name="socialTarget"]:checked')].map((el) =>
    String(el.value || "").trim().toLowerCase()
  );
  const extras = String(socialExtraTargetsInput?.value || "")
    .split(",")
    .map((s) => s.trim().toLowerCase().replace(/[^a-z0-9_-]+/g, ""))
    .filter(Boolean);
  return [...new Set([...fromChecks, ...extras])].filter((t) => t !== "yelp");
}

function renderTargets() {
  if (!socialTargetsHost) return;
  let rows = cachedPlatformMeta.length
    ? cachedPlatformMeta
    : (cachedPlatforms.length ? cachedPlatforms : ["facebook", "instagram", "x", "linkedin"]).map((target) => ({
        target,
        connected: false
      }));
  rows = rows.filter((row) => String(row.target || "").toLowerCase() !== "yelp");

  socialTargetsHost.innerHTML = rows
    .map(({ target, connected }) => {
      const label = socialTargetLabel(target);
      const checked = connected ? " checked" : "";
      const disabled = connected ? "" : " disabled";
      const classes = ["social-platform-pill", connected ? "is-connected" : "is-disconnected"].join(" ");
      const title = connected ? `Post to ${label}` : `${label} — connect webhook in Settings`;
      return `<label class="${classes}" title="${escapeHtml(title)}">
        <input type="checkbox" name="socialTarget" value="${escapeHtml(target)}"${checked}${disabled} />
        <span>${escapeHtml(label)}</span>
        ${connected ? "" : '<span class="social-platform-pill-note">Not connected</span>'}
      </label>`;
    })
    .join("");
}

function updateCharCounter() {
  if (!socialCharCounter || !socialMessageInput) return;
  const text = String(socialMessageInput.value || "");
  const len = text.length;
  const selected = selectedTargets();
  const connectedSelected = selected.filter((target) => {
    const meta = cachedPlatformMeta.find((p) => p.target === target);
    return meta ? meta.connected : true;
  });

  if (!connectedSelected.length) {
    socialCharCounter.textContent = len ? `${len} characters` : "Character limits apply per platform once connected.";
    socialCharCounter.classList.remove("is-over-limit");
    return;
  }

  const parts = connectedSelected.map((target) => {
    const limit = getCharLimitForTarget(target);
    const over = len > limit;
    return `${socialTargetLabel(target)}: ${len}/${limit}${over ? " (over limit)" : ""}`;
  });
  const anyOver = connectedSelected.some((target) => len > getCharLimitForTarget(target));
  socialCharCounter.textContent = parts.join(" · ");
  socialCharCounter.classList.toggle("is-over-limit", anyOver);
}

function isScheduleMode() {
  const picked = document.querySelector('input[name="socialPublishMode"]:checked');
  return picked && String(picked.value) === "schedule";
}

function syncPublishModeUi() {
  const schedule = isScheduleMode();
  if (socialScheduleFieldWrap) socialScheduleFieldWrap.hidden = !schedule;
  if (socialPostSubmitBtn) socialPostSubmitBtn.textContent = schedule ? "Schedule Post" : "Post Now";
  if (schedule && socialScheduleAtInput && !socialScheduleAtInput.value) {
    const d = new Date(Date.now() + 60 * 60 * 1000);
    d.setMinutes(0, 0, 0);
    socialScheduleAtInput.value = toDatetimeLocalValue(d);
  }
}

function toDatetimeLocalValue(date) {
  const pad = (n) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function getVisibleMedia() {
  const q = mediaSearchQuery.trim().toLowerCase();
  const cat = mediaCategoryFilter;
  return cachedMedia.filter((row) => {
    const name = String(row.file_name || "").toLowerCase();
    const category = String(row.category_name || "Uncategorized");
    if (cat !== "ALL" && category !== cat) return false;
    if (q && !name.includes(q)) return false;
    return true;
  });
}

function videoSelectLabel(row) {
  const title = String(row.title || `Video #${row.id}`);
  const kind = String(row.source_type) === "file" ? "uploaded file" : "hosted link";
  return `${title} (${kind})`;
}

function renderMediaSelect(preferredValue = null) {
  if (!socialMediaSelect) return;
  const prevRaw = preferredValue != null ? String(preferredValue) : String(socialMediaSelect.value || "");
  const prev = /^\d+$/.test(prevRaw) ? `media:${prevRaw}` : prevRaw;
  socialMediaSelect.innerHTML = '<option value="">No attachment</option>';

  if (cachedMedia.length) {
    const group = document.createElement("optgroup");
    group.label = "Media library";
    cachedMedia.forEach((row) => {
      const opt = document.createElement("option");
      opt.value = `media:${row.id}`;
      const category = String(row.category_name || "Uncategorized");
      opt.textContent = `${row.file_name || `Media #${row.id}`} (${category})`;
      group.appendChild(opt);
    });
    socialMediaSelect.appendChild(group);
  }

  if (cachedVideos.length) {
    const group = document.createElement("optgroup");
    group.label = "Video library";
    cachedVideos.forEach((row) => {
      const opt = document.createElement("option");
      opt.value = `video:${row.id}`;
      opt.textContent = videoSelectLabel(row);
      group.appendChild(opt);
    });
    socialMediaSelect.appendChild(group);
  }

  if (prev && [...socialMediaSelect.options].some((o) => o.value === prev)) {
    socialMediaSelect.value = prev;
  }
}

function mediaThumbInner(row) {
  const href = `/api/social/media/${row.id}/download`;
  const mime = String(row.mime_type || "").toLowerCase();
  if (mime.startsWith("image/")) {
    return `<img class="social-media-thumb-img" src="${href}" alt="" loading="lazy" decoding="async" />`;
  }
  if (mime.startsWith("video/")) {
    return `<video class="social-media-thumb-video" src="${href}" muted playsinline preload="metadata" aria-label="Video preview"></video>`;
  }
  return `<div class="social-media-thumb-fallback" title="${escapeHtml(mime || "file")}">File</div>`;
}

function renderMediaLibrary() {
  if (!socialMediaLibrary) return;
  const visible = getVisibleMedia();
  if (!cachedMedia.length) {
    socialMediaLibrary.innerHTML = '<div class="contact-history-empty">No media uploaded yet. Use <strong>Upload media</strong> above.</div>';
    return;
  }
  if (!visible.length) {
    socialMediaLibrary.innerHTML = '<div class="contact-history-empty">No media matches your search or category filter.</div>';
    return;
  }
  socialMediaLibrary.innerHTML = visible
    .map(
      (row) => `
    <div class="social-media-card" data-asset-id="${Number(row.id)}">
      <div class="social-media-card-thumb" aria-hidden="true">${mediaThumbInner(row)}</div>
      <div class="social-media-card-body">
        <div class="social-media-card-name" title="${escapeHtml(row.file_name || `Media #${row.id}`)}">${escapeHtml(
        row.file_name || `Media #${row.id}`
      )}</div>
        <div class="social-media-card-meta">${escapeHtml(String(row.category_name || "Uncategorized"))} · ${escapeHtml(formatUnix(row.created_at))} · ${Math.round(
        Number(row.size_bytes || 0) / 1024
      )} KB</div>
        <div class="social-media-card-actions">
          <a class="social-media-card-open" href="/api/social/media/${row.id}/download" target="_blank" rel="noopener noreferrer">Open</a>
          <button type="button" class="social-media-use-in-post-btn" data-id="${Number(row.id)}">Use in post</button>
          <button type="button" class="social-media-delete-btn agile-cancel-btn" data-id="${Number(row.id)}">Delete</button>
        </div>
      </div>
    </div>`
    )
    .join("");
}

function normalizeSocialDeliveryStatus(status) {
  const s = String(status || "").trim().toLowerCase();
  if (s === "queued") return "not_connected";
  return s;
}

function statusBadgeClass(status) {
  const s = normalizeSocialDeliveryStatus(status);
  if (s === "sent") return "social-status-badge social-status-badge--sent";
  if (s === "failed") return "social-status-badge social-status-badge--failed";
  if (s === "scheduled") return "social-status-badge social-status-badge--scheduled";
  if (s === "not_connected") return "social-status-badge social-status-badge--queued";
  return "social-status-badge social-status-badge--queued";
}

function statusBadgeLabel(status) {
  const s = normalizeSocialDeliveryStatus(status);
  if (s === "sent") return "Sent";
  if (s === "failed") return "Failed";
  if (s === "scheduled") return "Scheduled";
  if (s === "not_connected") return "Not connected";
  return s || "Unknown";
}

function renderTargetBadges(results) {
  if (!Array.isArray(results) || !results.length) {
    return '<span class="hint">No platforms selected</span>';
  }
  return results
    .map((t) => {
      const label = socialTargetLabel(t.target);
      const cls = statusBadgeClass(t.status);
      const tip = t.detail ? ` title="${escapeHtml(t.detail)}"` : "";
      return `<span class="${cls}"${tip}>${escapeHtml(label)} · ${escapeHtml(statusBadgeLabel(t.status))}</span>`;
    })
    .join("");
}

function overallPostStatus(row) {
  if (String(row.publish_status || "") === "scheduled") return "scheduled";
  const results = Array.isArray(row.target_results) ? row.target_results : [];
  if (!results.length) return "unknown";
  const statuses = results.map((r) => normalizeSocialDeliveryStatus(r.status));
  if (statuses.every((s) => s === "sent")) return "sent";
  if (statuses.some((s) => s === "sent")) return "partial";
  if (statuses.every((s) => s === "not_connected")) return "not_connected";
  if (statuses.every((s) => s === "failed" || s === "not_connected")) return "failed";
  return "mixed";
}

function overallPostLabel(overall, row) {
  if (overall === "scheduled") {
    return `Scheduled · ${formatUnix(row.scheduled_at || row.created_at)}`;
  }
  if (overall === "sent") return "Published";
  if (overall === "partial") return "Partially published";
  if (overall === "not_connected") return "Not connected";
  if (overall === "failed") return "Not published";
  if (overall === "unknown") return "No delivery data";
  return "Incomplete";
}

function overallPostClass(overall) {
  if (overall === "sent") return statusBadgeClass("sent");
  if (overall === "scheduled") return statusBadgeClass("scheduled");
  if (overall === "partial") return statusBadgeClass("queued");
  if (overall === "not_connected" || overall === "failed" || overall === "unknown" || overall === "mixed") {
    return statusBadgeClass("failed");
  }
  return statusBadgeClass("failed");
}

function postMediaThumbHtml(row) {
  const mediaId = Number(row.media_asset_id || 0);
  if (mediaId) {
    const mime = String(row.media_mime_type || "").toLowerCase();
    const href = `/api/social/media/${mediaId}/download`;
    if (mime.startsWith("image/")) {
      return `<div class="social-post-media-thumb"><img src="${href}" alt="" loading="lazy" /></div>`;
    }
    if (mime.startsWith("video/")) {
      return `<div class="social-post-media-thumb social-post-media-thumb--video"><video src="${href}" muted playsinline preload="metadata"></video></div>`;
    }
  }
  const videoId = Number(row.video_id || 0);
  if (videoId) {
    if (String(row.video_source_type) === "file") {
      const href = `/api/videos/${videoId}/stream`;
      return `<div class="social-post-media-thumb social-post-media-thumb--video"><video src="${href}" muted playsinline preload="metadata"></video></div>`;
    }
    if (row.video_url) {
      return `<div class="social-post-media-thumb social-post-media-thumb--link"><span class="hint">Video link attached</span></div>`;
    }
  }
  return "";
}

function postAttachmentLabel(row) {
  if (row.media_asset_id) return escapeHtml(row.media_file_name || "attachment");
  if (row.video_id) return escapeHtml(row.video_title || `Video #${row.video_id}`);
  return "No attachment";
}

function renderPosts(rows) {
  if (!socialPostsList) return;
  if (!rows.length) {
    socialPostsList.innerHTML = '<div class="contact-history-empty">No social posts yet.</div>';
    return;
  }
  socialPostsList.innerHTML = rows
    .map((row) => {
      const thumb = postMediaThumbHtml(row);
      const preview = truncateText(row.content || "", 180);
      const overall = overallPostStatus(row);
      const overallLabel = overallPostLabel(overall, row);
      const overallClass = overallPostClass(overall);
      const when =
        String(row.publish_status || "") === "scheduled"
          ? `Scheduled for ${formatUnix(row.scheduled_at)}`
          : `Created ${formatUnix(row.created_at)}`;
      const mediaText = postAttachmentLabel(row);
      return `<div class="contact-history-item social-post-item" data-post-id="${Number(row.id)}">
        <div class="contact-history-top">
          <span class="${overallClass}">${escapeHtml(overallLabel)}</span>
          <div class="social-post-top-meta">
            <span class="contact-history-date">${escapeHtml(when)}</span>
            <button type="button" class="social-post-clear-btn agile-cancel-btn" data-post-id="${Number(row.id)}">Clear</button>
          </div>
        </div>
        <div class="social-post-body-row">
          ${thumb}
          <div class="social-post-body-main">
            <div class="social-post-preview">${escapeHtml(preview)}</div>
            <div class="social-post-platform-badges">${renderTargetBadges(row.target_results)}</div>
            <div class="contact-history-detail social-post-media-line">${mediaText}</div>
          </div>
        </div>
      </div>`;
    })
    .join("");
}

async function loadPlatforms() {
  const { response, data } = await fetchApiJson("/api/social/platforms");
  if (!response.ok) throw new Error(data.error || "Failed to load social platforms");
  cachedPlatforms = Array.isArray(data.targets) ? data.targets : [];
  cachedPlatformMeta = Array.isArray(data.platforms)
    ? data.platforms
    : cachedPlatforms.map((target) => ({ target, connected: false }));
  connectedPlatformCount = Number(data.connectedCount || 0);
  syncWebhookSetupNotice();
  renderTargets();
  updateCharCounter();
}

async function loadMedia(selectAfterId = null) {
  const { response, data } = await fetchApiJson("/api/social/media?limit=100");
  if (!response.ok) throw new Error(data.error || "Failed to load social media");
  cachedMedia = Array.isArray(data) ? data : [];
  renderMediaSelect(selectAfterId != null ? `media:${selectAfterId}` : null);
  renderMediaLibrary();
}

async function loadPosts() {
  const { response, data } = await fetchApiJson("/api/social/posts?limit=100");
  if (!response.ok) throw new Error(data.error || "Failed to load social posts");
  renderPosts(Array.isArray(data) ? data : []);
}

async function deleteMedia(assetId) {
  const id = Number(assetId);
  if (!Number.isInteger(id) || id < 1) return;
  const row = cachedMedia.find((m) => Number(m.id) === id);
  const label = row?.file_name ? String(row.file_name) : `Media #${id}`;
  if (!window.confirm(`Delete "${label}" from your media library? This cannot be undone.`)) return;
  const { response, data } = await fetchApiJson("/api/social/media/delete", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id })
  });
  if (!response.ok) throw new Error(data.error || "Failed to delete media");
  if (socialMediaSelect && socialMediaSelect.value === `media:${id}`) {
    socialMediaSelect.value = "";
  }
  await loadMedia();
  showMessage("Media deleted.");
}

async function clearPost(postId) {
  const id = Number(postId);
  if (!Number.isInteger(id) || id < 1) return;
  if (!window.confirm("Remove this post from Recent Social Posts?")) return;
  const { response, data } = await fetchApiJson("/api/social/posts/clear", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id })
  });
  if (!response.ok) throw new Error(data.error || "Failed to clear post");
  await loadPosts();
  showMessage("Post cleared.");
}

function getSelectedAttachmentForPost() {
  const raw = String(socialMediaSelect?.value || "").trim();
  if (!raw) return { mediaId: null, videoId: null };
  const match = raw.match(/^(media|video):(\d+)$/);
  if (!match) return { mediaId: null, videoId: null };
  const id = Number(match[2]);
  if (!Number.isInteger(id) || id < 1) return { mediaId: null, videoId: null };
  if (match[1] === "video") return { mediaId: null, videoId: id };
  return { mediaId: id, videoId: null };
}

async function uploadLibraryFile(file) {
  const fd = new FormData();
  fd.append("media", file);
  fd.append("categoryName", "Uncategorized");
  const { response, data } = await fetchApiJson("/api/social/media/upload", {
    method: "POST",
    body: fd
  });
  if (!response.ok) throw new Error(data.error || "Upload failed");
  return Number(data.id || 0) || null;
}

function syncLibraryFileLabel() {
  if (!socialLibraryFileLabel) return;
  const list = socialLibraryFileInput?.files;
  if (!list || list.length === 0) {
    socialLibraryFileLabel.textContent = "No files chosen";
    return;
  }
  if (list.length === 1) {
    socialLibraryFileLabel.textContent = list[0].name;
    return;
  }
  const slice = Array.from(list)
    .slice(0, 3)
    .map((f) => f.name)
    .join(", ");
  socialLibraryFileLabel.textContent =
    list.length > 3 ? `${slice}, … (${list.length} files)` : `${slice} (${list.length} files)`;
}

if (socialLibraryPickBtn && socialLibraryFileInput) {
  socialLibraryPickBtn.addEventListener("click", () => socialLibraryFileInput.click());
}

if (socialLibraryFileInput) {
  socialLibraryFileInput.addEventListener("change", () => syncLibraryFileLabel());
}

if (socialMediaSearchInput) {
  socialMediaSearchInput.addEventListener("input", () => {
    mediaSearchQuery = String(socialMediaSearchInput.value || "");
    renderMediaLibrary();
  });
}

if (socialMediaCategoryFilter) {
  socialMediaCategoryFilter.addEventListener("change", () => {
    mediaCategoryFilter = String(socialMediaCategoryFilter.value || "ALL");
    renderMediaLibrary();
  });
}

document.querySelectorAll('input[name="socialPublishMode"]').forEach((el) => {
  el.addEventListener("change", syncPublishModeUi);
});

if (socialMessageInput) {
  socialMessageInput.addEventListener("input", updateCharCounter);
}

if (socialExtraTargetsInput) {
  socialExtraTargetsInput.addEventListener("input", updateCharCounter);
}

if (socialTargetsHost) {
  socialTargetsHost.addEventListener("change", updateCharCounter);
}

if (socialLibraryUploadForm) {
  socialLibraryUploadForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const files = socialLibraryFileInput?.files ? Array.from(socialLibraryFileInput.files) : [];
    if (!files.length) {
      showLibraryUploadMessage("Choose one or more image or video files first.", true);
      return;
    }
    const errors = [];
    let lastNewId = null;
    try {
      for (let i = 0; i < files.length; i++) {
        showLibraryUploadMessage(`Uploading ${i + 1} of ${files.length}…`);
        try {
          const id = await uploadLibraryFile(files[i]);
          if (id) lastNewId = id;
        } catch (err) {
          errors.push(`${files[i].name}: ${err.message || "failed"}`);
        }
      }
      if (socialLibraryFileInput) socialLibraryFileInput.value = "";
      syncLibraryFileLabel();
      await loadMedia(lastNewId);
      const ok = files.length - errors.length;
      if (errors.length) {
        const detail = errors.slice(0, 4).join("; ");
        const more = errors.length > 4 ? ` (+${errors.length - 4} more)` : "";
        showLibraryUploadMessage(`Uploaded ${ok} of ${files.length}. Errors: ${detail}${more}`, ok === 0);
      } else {
        showLibraryUploadMessage(
          `Uploaded ${files.length} file${files.length === 1 ? "" : "s"} to CRM. Attach any of them when you create a post below.`
        );
      }
    } catch (error) {
      showLibraryUploadMessage(error.message || "Upload failed.", true);
    }
  });
}

if (socialMediaLibrary) {
  socialMediaLibrary.addEventListener("click", (event) => {
    const deleteBtn = event.target?.closest?.(".social-media-delete-btn");
    if (deleteBtn) {
      const id = Number(deleteBtn.getAttribute("data-id"));
      deleteMedia(id).catch((error) => showMessage(error.message || "Failed to delete media", true));
      return;
    }
    const btn = event.target?.closest?.(".social-media-use-in-post-btn");
    if (!btn) return;
    const id = Number(btn.getAttribute("data-id"));
    if (!Number.isInteger(id) || id < 1) return;
    if (socialMediaSelect) socialMediaSelect.value = `media:${id}`;
    socialPostForm?.scrollIntoView?.({ behavior: "smooth", block: "start" });
    socialMessageInput?.focus?.();
    showMessage(`Media #${id} selected for your next post.`);
  });
}

if (socialPostsList) {
  socialPostsList.addEventListener("click", (event) => {
    const btn = event.target?.closest?.(".social-post-clear-btn");
    if (!btn) return;
    const id = Number(btn.getAttribute("data-post-id"));
    clearPost(id).catch((error) => showMessage(error.message || "Failed to clear post", true));
  });
}

if (socialPostForm) {
  socialPostForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      const message = String(socialMessageInput?.value || "").trim();
      if (!message) throw new Error("Post message is required");
      const targets = selectedTargets();
      if (!targets.length) throw new Error("Select at least one connected platform");
      const connectedOnly = targets.filter((target) => {
        const meta = cachedPlatformMeta.find((p) => p.target === target);
        return meta ? meta.connected : true;
      });
      if (!connectedOnly.length && connectedPlatformCount === 0) {
        throw new Error("Connect at least one platform webhook in Settings before posting");
      }
      const overLimit = connectedOnly.some((target) => message.length > getCharLimitForTarget(target));
      if (overLimit) {
        throw new Error("Message exceeds the character limit for one or more selected platforms");
      }
      const { mediaId, videoId } = getSelectedAttachmentForPost();
      const body = { message, mediaId, videoId, targets };
      if (isScheduleMode()) {
        const raw = String(socialScheduleAtInput?.value || "").trim();
        if (!raw) throw new Error("Choose a date and time to schedule this post");
        body.scheduleAt = new Date(raw).toISOString();
      }
      const { response, data } = await fetchApiJson("/api/social/publish", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      if (!response.ok) throw new Error(data.error || "Failed to publish social post");
      socialMessageInput.value = "";
      socialExtraTargetsInput.value = "";
      if (socialMediaSelect) socialMediaSelect.value = "";
      if (socialScheduleAtInput) socialScheduleAtInput.value = "";
      const nowRadio = document.querySelector('input[name="socialPublishMode"][value="now"]');
      if (nowRadio) nowRadio.checked = true;
      syncPublishModeUi();
      await loadPlatforms();
      await loadPosts();
      if (data.scheduled) {
        showMessage(`Post scheduled for ${formatUnix(data.scheduledAt)}.`);
      } else {
        const sent = Array.isArray(data.results) ? data.results.filter((r) => String(r.status || "").toLowerCase() === "sent").length : 0;
        const failed = Array.isArray(data.results)
          ? data.results.filter((r) => {
              const s = String(r.status || "").toLowerCase();
              return s === "failed" || s === "queued";
            }).length
          : 0;
        if (sent && !failed) showMessage(`Post published to ${sent} platform(s).`);
        else if (sent) showMessage(`Post sent to ${sent} platform(s). ${failed} need webhook setup or failed.`, true);
        else showMessage("Post saved but no platforms received it. Check Settings → Social webhooks.", true);
      }
      updateCharCounter();
    } catch (error) {
      showMessage(error.message || "Failed to publish social post", true);
    }
  });
}

const socialBulkForm = document.getElementById("socialBulkForm");
const socialBulkInput = document.getElementById("socialBulkInput");
const socialBulkPreviewBtn = document.getElementById("socialBulkPreviewBtn");
const socialBulkSubmitBtn = document.getElementById("socialBulkSubmitBtn");
const socialBulkPreview = document.getElementById("socialBulkPreview");

function escapeHtmlBulk(value) {
  return String(value || "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function parseBulkDate(input) {
  const str = String(input || "").trim();
  const m = str.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T]+(\d{1,2}):(\d{2})\s*([ap]m)?)?$/i);
  if (!m) return null;
  let hour = m[4] != null ? Number(m[4]) : 9;
  const min = m[5] != null ? Number(m[5]) : 0;
  if (m[6]) {
    const isPm = m[6].toLowerCase() === "pm";
    if (hour === 12) hour = isPm ? 12 : 0;
    else if (isPm) hour += 12;
  }
  const y = Number(m[1]);
  const mo = Number(m[2]);
  const d = Number(m[3]);
  if (hour > 23 || min > 59) return null;
  const dt = new Date(y, mo - 1, d, hour, min, 0, 0);
  if (isNaN(dt.getTime()) || dt.getMonth() !== mo - 1 || dt.getDate() !== d) return null;
  return dt;
}

function parseBulkPosts(text) {
  const blocks = String(text || "").split(/^[ \t]*-{3,}[ \t]*$/m).map((b) => b.trim()).filter(Boolean);
  const mediaByName = new Map(cachedMedia.map((m) => [String(m.file_name || "").trim().toLowerCase(), Number(m.id)]));
  const nowMs = Date.now();
  return blocks.map((block, i) => {
    const lines = block.split(/\r?\n/);
    let dateLine = "";
    let dateFound = false;
    let imageName = "";
    const msgLines = [];
    for (const line of lines) {
      const t = line.trim();
      const img = t.match(/^image:\s*(.+)$/i);
      if (!dateFound && t) {
        dateLine = t;
        dateFound = true;
        continue;
      }
      if (img) {
        imageName = img[1].trim();
        continue;
      }
      msgLines.push(line);
    }
    const message = msgLines.join("\n").trim();
    const parsedDate = parseBulkDate(dateLine);
    const errors = [];
    const warnings = [];
    if (!parsedDate) errors.push(`couldn't read date/time "${dateLine || "(missing first line)"}" — use YYYY-MM-DD HH:MM`);
    else if (parsedDate.getTime() <= nowMs) errors.push("date/time is in the past");
    if (!message) errors.push("no post text");
    let mediaId = null;
    if (imageName) {
      const id = mediaByName.get(imageName.toLowerCase());
      if (id) mediaId = id;
      else warnings.push(`image “${imageName}” isn’t in your Media library — this post will go out text-only`);
    }
    return { index: i, dateLine, parsedDate, message, imageName, mediaId, errors, warnings };
  });
}

function renderBulkPreview() {
  if (!socialBulkPreview) return;
  const parsed = parseBulkPosts(socialBulkInput?.value || "");
  if (!parsed.length) {
    socialBulkPreview.hidden = true;
    socialBulkPreview.innerHTML = "";
    if (socialBulkSubmitBtn) socialBulkSubmitBtn.disabled = true;
    return;
  }
  const errorCount = parsed.filter((p) => p.errors.length).length;
  const items = parsed
    .map((p) => {
      const when = p.parsedDate ? p.parsedDate.toLocaleString() : "—";
      const snippet = escapeHtmlBulk(truncateText(p.message.replace(/\s+/g, " "), 90) || "(no text)");
      const img = p.mediaId ? ` &nbsp;<span style="opacity:.75">image: ${escapeHtmlBulk(p.imageName)}</span>` : "";
      const errs = p.errors.map((e) => `<div style="color:#dc2626">✕ ${escapeHtmlBulk(e)}</div>`).join("");
      const warns = p.warnings.map((w) => `<div style="color:#b45309">! ${escapeHtmlBulk(w)}</div>`).join("");
      const border = p.errors.length ? "#dc2626" : p.warnings.length ? "#d97706" : "#22c55e";
      return `<li style="list-style:none;margin:0 0 8px;padding:8px 12px;border-left:3px solid ${border};background:rgba(148,163,184,.10);border-radius:4px">
        <div><strong>#${p.index + 1}</strong> &nbsp;${escapeHtmlBulk(when)}${img}</div>
        <div style="opacity:.85;margin-top:2px">${snippet}</div>${errs}${warns}
      </li>`;
    })
    .join("");
  const summaryColor = errorCount ? "#dc2626" : "#16a34a";
  const summaryText = errorCount
    ? `${parsed.length} post(s) detected — ${errorCount} need fixing before you can schedule.`
    : `${parsed.length} post(s) ready to schedule.`;
  socialBulkPreview.innerHTML =
    `<p style="font-weight:600;color:${summaryColor};margin:10px 0 8px">${summaryText}</p><ul style="margin:0;padding:0">${items}</ul>`;
  socialBulkPreview.hidden = false;
  if (socialBulkSubmitBtn) socialBulkSubmitBtn.disabled = errorCount > 0;
}

async function submitBulkSchedule() {
  const targets = selectedTargets();
  if (!targets.length) {
    showMessage("Tick at least one platform in “Post to” above (e.g. Facebook) before bulk scheduling.", true);
    return;
  }
  const parsed = parseBulkPosts(socialBulkInput?.value || "");
  if (!parsed.length) {
    showMessage("Paste your posts into the box first.", true);
    return;
  }
  if (parsed.some((p) => p.errors.length)) {
    showMessage("Fix the highlighted posts before scheduling.", true);
    renderBulkPreview();
    return;
  }
  if (socialBulkSubmitBtn) socialBulkSubmitBtn.disabled = true;
  try {
    const posts = parsed.map((p) => ({
      message: p.message,
      scheduleAt: p.parsedDate.toISOString(),
      mediaId: p.mediaId || undefined
    }));
    const { response, data } = await fetchApiJson("/api/social/publish-bulk", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ posts, targets })
    });
    if (!response.ok) throw new Error(data.error || "Bulk schedule failed");
    const ok = Number(data.scheduledCount || 0);
    const failed = (Array.isArray(data.results) ? data.results : []).filter((r) => !r.ok);
    if (failed.length) {
      showMessage(
        `Scheduled ${ok} of ${data.total}. ${failed.length} failed: ${failed.map((f) => `#${f.index + 1} (${f.error})`).join("; ")}`,
        true
      );
    } else {
      showMessage(`Scheduled ${ok} post(s) to ${targets.map(socialTargetLabel).join(", ")}.`);
    }
    if (ok > 0) {
      socialBulkInput.value = "";
      renderBulkPreview();
      await loadPosts();
    }
  } catch (error) {
    showMessage(error.message || "Bulk schedule failed", true);
  } finally {
    if (socialBulkSubmitBtn) socialBulkSubmitBtn.disabled = false;
  }
}

if (socialBulkPreviewBtn) socialBulkPreviewBtn.addEventListener("click", renderBulkPreview);
if (socialBulkInput) socialBulkInput.addEventListener("input", renderBulkPreview);
if (socialBulkForm) {
  socialBulkForm.addEventListener("submit", (event) => {
    event.preventDefault();
    submitBulkSchedule();
  });
}

Promise.resolve()
  .then(() => loadPlatforms())
  .then(() => loadMedia())
  .then(() => initVideoLibrary())
  .then(() => loadVideos())
  .then(() => loadPosts())
  .then(() => syncPublishModeUi())
  .then(() => scrollToVideoLibraryIfNeeded())
  .catch((error) => showMessage(error.message || "Failed to load social workspace", true));

// Refresh scheduled posts periodically
setInterval(() => {
  loadPosts().catch(() => {});
}, 60000);

// --- Video library (hosted links + uploads) ---
const videosForm = document.getElementById("videosForm");
const videosRefreshBtn = document.getElementById("videosRefreshBtn");
const videosListEl = document.getElementById("videosList");
const videoTitleEl = document.getElementById("videoTitle");
const videoUrlEl = document.getElementById("videoUrl");
const videoFileEl = document.getElementById("videoFile");
const videoPickBtn = document.getElementById("videoPickBtn");
const videoFileLabel = document.getElementById("videoFileLabel");
const videoNotesEl = document.getElementById("videoNotes");
const videosSaveBtn = document.getElementById("videosSaveBtn");
const videoUploadProgressWrap = document.getElementById("videoUploadProgressWrap");
const videoUploadProgressBar = document.getElementById("videoUploadProgressBar");
const videoUploadProgressPct = document.getElementById("videoUploadProgressPct");
const videoUploadProgressText = document.getElementById("videoUploadProgressText");
const videoUploadProgressTrack = videoUploadProgressWrap?.querySelector(".video-upload-progress-track");

const HOSTED_VIDEO_URL_HINT =
  "Unsupported video URL. Supports YouTube, Vimeo, Loom, and direct video links (.mp4, .mov, .webm).";

const VIDEO_FILE_EXT = /\.(mp4|webm|ogg|ogv|mov|m4v|avi|mkv|wmv|mpeg|mpg|3gp|3g2)$/i;

function videoApiUrl(path) {
  const p = path.startsWith("/") ? path : `/${path}`;
  const injected =
    typeof window.__CRM_API_ORIGIN__ === "string" ? window.__CRM_API_ORIGIN__.trim().replace(/\/$/, "") : "";
  if (injected) return `${injected}${p}`;
  const fromMeta = document.querySelector('meta[name="crm-api-base"]')?.getAttribute("content") || "";
  const base = String(fromMeta || "").trim().replace(/\/$/, "");
  return base ? `${base}${p}` : p;
}

function formatVideoDate(createdAt) {
  const sec = Number(createdAt);
  if (!Number.isFinite(sec) || sec <= 0) return "";
  try {
    return new Date(sec * 1000).toLocaleDateString(undefined, {
      year: "numeric",
      month: "short",
      day: "numeric"
    });
  } catch {
    return "";
  }
}

function parseHostedVideoUrl(rawUrl) {
  const raw = String(rawUrl || "").trim();
  if (!raw) return null;
  let u;
  try {
    u = new URL(raw);
  } catch {
    return null;
  }
  if (!/^https?:$/i.test(u.protocol)) return null;
  const host = u.hostname.toLowerCase().replace(/^www\./, "");

  if (host === "youtu.be") {
    const videoId = u.pathname.replace(/^\//, "").split(/[/?#]/)[0];
    if (!videoId) return null;
    return {
      provider: "youtube",
      label: "YouTube",
      thumbnailUrl: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
      watchUrl: raw
    };
  }
  if (host === "youtube.com" || host === "m.youtube.com" || host === "music.youtube.com") {
    let videoId = u.searchParams.get("v");
    if (!videoId) {
      const m = u.pathname.match(/\/(?:shorts|embed|live)\/([^/?#]+)/);
      videoId = m && m[1];
    }
    if (!videoId) return null;
    return {
      provider: "youtube",
      label: "YouTube",
      thumbnailUrl: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
      watchUrl: raw
    };
  }

  if (host === "vimeo.com" || host.endsWith(".vimeo.com")) {
    const m = u.pathname.match(/\/(\d+)(?:\/|$|[?#])/);
    const videoId = m && m[1];
    if (!videoId) return null;
    return { provider: "vimeo", label: "Vimeo", thumbnailUrl: null, watchUrl: raw };
  }
  if (host === "player.vimeo.com") {
    const videoId = u.pathname.replace(/^\//, "").split("/")[0];
    if (!/^\d+$/.test(videoId)) return null;
    return {
      provider: "vimeo",
      label: "Vimeo",
      thumbnailUrl: null,
      watchUrl: `https://vimeo.com/${videoId}`
    };
  }

  if (host === "loom.com" || host.endsWith(".loom.com")) {
    const m = u.pathname.match(/\/(?:share|embed)\/([a-zA-Z0-9]+)/);
    const videoId = m && m[1];
    if (!videoId) return null;
    return {
      provider: "loom",
      label: "Loom",
      thumbnailUrl: `https://cdn.loom.com/sessions/thumbnails/${videoId}-with-play.jpg`,
      watchUrl: `https://www.loom.com/share/${videoId}`
    };
  }

  const path = u.pathname || "";
  if (/\.(mp4|webm|ogg|ogv|mov|m4v|avi|mkv|wmv|mpeg|mpg|3gp|3g2)(\?.*)?$/i.test(path)) {
    return { provider: "direct", label: "Direct URL", thumbnailUrl: null, watchUrl: raw };
  }

  return null;
}

function getVideoMeta(row) {
  if (String(row.source_type) === "file") {
    const streamSrc = videoApiUrl(`/api/videos/${row.id}/stream`);
    return {
      label: "Uploaded",
      provider: "upload",
      thumbnailUrl: null,
      previewSrc: streamSrc,
      shareUrl: new URL(streamSrc, window.location.origin).href,
      subline: `${row.file_name || "Video file"} · ${formatBytes(row.size_bytes)}`
    };
  }
  const url = String(row.video_url || "").trim();
  const hosted = parseHostedVideoUrl(url);
  if (hosted) {
    return {
      label: hosted.label,
      provider: hosted.provider,
      thumbnailUrl: hosted.thumbnailUrl,
      previewSrc: hosted.watchUrl,
      shareUrl: hosted.watchUrl,
      subline: url.length > 72 ? `${url.slice(0, 69)}…` : url
    };
  }
  return {
    label: "URL",
    provider: "url",
    thumbnailUrl: null,
    previewSrc: url,
    shareUrl: url,
    subline: url
  };
}

function setVideoFileLabel() {
  if (!videoFileLabel) return;
  const f = videoFileEl?.files?.[0];
  videoFileLabel.textContent = f ? `${f.name} (${formatBytes(f.size)})` : "No file chosen";
}

function resetVideoForm() {
  if (!videosForm) return;
  videosForm.reset();
  setVideoFileLabel();
  hideVideoUploadProgress();
}

function showVideoUploadProgress(pct, text) {
  if (!videoUploadProgressWrap) return;
  const safe = Math.max(0, Math.min(100, Math.round(Number(pct) || 0)));
  videoUploadProgressWrap.classList.remove("is-hidden");
  if (videoUploadProgressBar) videoUploadProgressBar.style.width = `${safe}%`;
  if (videoUploadProgressPct) videoUploadProgressPct.textContent = `${safe}%`;
  if (videoUploadProgressText) videoUploadProgressText.textContent = text || "Uploading video…";
  if (videoUploadProgressTrack) videoUploadProgressTrack.setAttribute("aria-valuenow", String(safe));
}

function hideVideoUploadProgress() {
  if (!videoUploadProgressWrap) return;
  videoUploadProgressWrap.classList.add("is-hidden");
  if (videoUploadProgressBar) videoUploadProgressBar.style.width = "0%";
  if (videoUploadProgressPct) videoUploadProgressPct.textContent = "0%";
  if (videoUploadProgressTrack) videoUploadProgressTrack.setAttribute("aria-valuenow", "0");
}

function setVideoSavingState(isSaving) {
  if (videosSaveBtn) videosSaveBtn.disabled = isSaving;
  if (videosRefreshBtn) videosRefreshBtn.disabled = isSaving;
}

function uploadVideoWithProgress(formData) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", videoApiUrl("/api/videos/upload"));
    xhr.withCredentials = true;
    xhr.upload.addEventListener("progress", (event) => {
      if (!event.lengthComputable) {
        showVideoUploadProgress(0, "Uploading video…");
        return;
      }
      const pct = (event.loaded / event.total) * 100;
      showVideoUploadProgress(pct, `Uploading ${formatBytes(event.loaded)} of ${formatBytes(event.total)}…`);
    });
    xhr.addEventListener("load", () => {
      let data = {};
      try {
        data = xhr.responseText ? JSON.parse(xhr.responseText) : {};
      } catch {
        data = {};
      }
      if (xhr.status >= 200 && xhr.status < 300) {
        resolve(data);
        return;
      }
      reject(new Error(data.error || `Upload failed (${xhr.status})`));
    });
    xhr.addEventListener("error", () => reject(new Error("Upload failed. Check your connection and try again.")));
    xhr.addEventListener("abort", () => reject(new Error("Upload cancelled.")));
    xhr.send(formData);
  });
}

function isPcVideoFile(file) {
  if (!file) return false;
  const mime = String(file.type || "").toLowerCase();
  if (mime.startsWith("video/")) return true;
  if (mime === "application/octet-stream" && VIDEO_FILE_EXT.test(file.name || "")) return true;
  if (!mime && VIDEO_FILE_EXT.test(file.name || "")) return true;
  return VIDEO_FILE_EXT.test(file.name || "");
}

async function copyTextToClipboard(text) {
  const value = String(text || "").trim();
  if (!value) throw new Error("Nothing to copy.");
  if (navigator.clipboard && navigator.clipboard.writeText) {
    await navigator.clipboard.writeText(value);
    return;
  }
  const ta = document.createElement("textarea");
  ta.value = value;
  ta.setAttribute("readonly", "");
  ta.style.position = "fixed";
  ta.style.left = "-9999px";
  document.body.appendChild(ta);
  ta.select();
  document.execCommand("copy");
  document.body.removeChild(ta);
}

async function deleteVideo(id) {
  const n = Number(id);
  if (!Number.isInteger(n) || n < 1) return;
  if (!window.confirm("Delete this video?")) return;
  const { response, data } = await fetchApiJson(`/api/videos/${n}`, { method: "DELETE" });
  if (!response.ok) throw new Error(data.error || "Failed to delete video");
}

async function renameVideo(id, currentTitle) {
  const next = window.prompt("Rename video", currentTitle || "");
  if (next == null) return;
  const title = String(next).trim();
  if (!title) {
    showMessage("Title cannot be empty.", true);
    return;
  }
  const { response, data } = await fetchApiJson(`/api/videos/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title })
  });
  if (!response.ok) throw new Error(data.error || "Failed to rename video");
  showMessage("Video renamed.");
  await loadVideos();
}

function renderVideosEmptyState() {
  return `<div class="videos-empty-state">
    <p><strong>No videos saved yet.</strong></p>
    <p class="hint">Add your first video above to make it available across Cadence.</p>
  </div>`;
}

function renderVideoThumb(meta, row) {
  if (meta.thumbnailUrl) {
    return `<img class="video-card-thumb-img" src="${escapeHtml(meta.thumbnailUrl)}" alt="" loading="lazy" />`;
  }
  if (String(row.source_type) === "file" && meta.previewSrc) {
    return `<video class="video-card-thumb-video" muted playsinline preload="metadata" src="${escapeHtml(meta.previewSrc)}"></video>`;
  }
  const initial = escapeHtml((row.title || "V").charAt(0).toUpperCase());
  return `<div class="video-card-thumb-placeholder" aria-hidden="true"><span>${initial}</span><small>${escapeHtml(meta.label)}</small></div>`;
}

function renderVideos(rows) {
  if (!videosListEl) return;
  const list = Array.isArray(rows) ? rows : [];
  if (!list.length) {
    videosListEl.innerHTML = renderVideosEmptyState();
    return;
  }
  videosListEl.innerHTML = list
    .map((row) => {
      const meta = getVideoMeta(row);
      const dateLabel = formatVideoDate(row.created_at);
      const previewBlock =
        String(row.source_type) === "file"
          ? `<details class="video-card-preview">
              <summary>Preview upload</summary>
              <video controls preload="metadata" src="${escapeHtml(meta.previewSrc)}"></video>
            </details>`
          : meta.provider === "youtube" || meta.provider === "vimeo" || meta.provider === "loom"
            ? `<details class="video-card-preview">
                <summary>Open preview</summary>
                <p class="hint"><a href="${escapeHtml(meta.shareUrl)}" target="_blank" rel="noopener noreferrer">Watch on ${escapeHtml(meta.label)}</a></p>
              </details>`
            : meta.previewSrc
              ? `<details class="video-card-preview">
                  <summary>Preview video</summary>
                  <video controls preload="metadata" src="${escapeHtml(meta.previewSrc)}"></video>
                </details>`
              : "";

      return `<article class="video-card" data-id="${row.id}">
        <div class="video-card-thumb">${renderVideoThumb(meta, row)}</div>
        <div class="video-card-body">
          <div class="video-card-title-row">
            <h4 class="video-card-title">${escapeHtml(row.title || "Untitled Video")}</h4>
            <span class="video-card-badge video-card-badge--${escapeHtml(meta.provider)}">${escapeHtml(meta.label)}</span>
          </div>
          <p class="video-card-meta">${escapeHtml(meta.subline || "")}</p>
          ${dateLabel ? `<p class="video-card-date">Saved ${escapeHtml(dateLabel)}</p>` : ""}
          ${row.notes ? `<p class="video-card-notes hint">${escapeHtml(row.notes)}</p>` : ""}
          ${previewBlock}
          <div class="video-card-actions">
            <button type="button" class="video-copy-link-btn" data-share-url="${escapeHtml(meta.shareUrl)}">Copy link</button>
            <button type="button" class="video-rename-btn" data-id="${row.id}">Rename</button>
            <button type="button" class="danger video-delete-btn" data-id="${row.id}">Delete</button>
          </div>
        </div>
      </article>`;
    })
    .join("");

  videosListEl.querySelectorAll(".video-delete-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      try {
        await deleteVideo(btn.getAttribute("data-id"));
        showMessage("Video deleted.");
        await loadVideos();
      } catch (error) {
        showMessage(error.message || "Delete failed.", true);
      }
    });
  });

  videosListEl.querySelectorAll(".video-rename-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      try {
        const card = btn.closest(".video-card");
        const titleNode = card?.querySelector(".video-card-title");
        const currentTitle = titleNode ? titleNode.textContent.trim() : "";
        await renameVideo(btn.getAttribute("data-id"), currentTitle);
      } catch (error) {
        showMessage(error.message || "Rename failed.", true);
      }
    });
  });

  videosListEl.querySelectorAll(".video-copy-link-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      try {
        await copyTextToClipboard(btn.getAttribute("data-share-url"));
        showMessage("Link copied to clipboard.");
      } catch (error) {
        showMessage(error.message || "Copy failed.", true);
      }
    });
  });
}

async function loadVideos() {
  const { response, data } = await fetchApiJson("/api/videos");
  if (!response.ok) throw new Error(data.error || "Failed to load videos");
  cachedVideos = Array.isArray(data) ? data : [];
  if (videosListEl) renderVideos(cachedVideos);
  renderMediaSelect();
}

function initVideoLibrary() {
  if (!videosForm) return;
  if (videoPickBtn && videoFileEl) {
    videoPickBtn.addEventListener("click", () => videoFileEl.click());
  }
  if (videoFileEl) videoFileEl.addEventListener("change", setVideoFileLabel);
  if (videosRefreshBtn) {
    videosRefreshBtn.addEventListener("click", async () => {
      try {
        await loadVideos();
        showMessage("Videos refreshed.");
      } catch (error) {
        showMessage(error.message || "Refresh failed.", true);
      }
    });
  }
  videosForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      const title = String(videoTitleEl?.value || "").trim();
      const notes = String(videoNotesEl?.value || "").trim();
      const file = videoFileEl?.files?.[0];
      const videoUrl = String(videoUrlEl?.value || "").trim();
      if (!title) throw new Error("Video title is required.");
      if (!file && !videoUrl) {
        throw new Error("Enter a video URL or choose a file from your computer.");
      }

      setVideoSavingState(true);

      if (file) {
        if (!isPcVideoFile(file)) {
          throw new Error("That does not look like a video file. Use .mp4, .mov, .webm, or another common video format.");
        }
        showVideoUploadProgress(0, "Starting upload…");
        const formData = new FormData();
        formData.append("video", file);
        formData.append("title", title);
        formData.append("notes", notes);
        await uploadVideoWithProgress(formData);
        showVideoUploadProgress(100, "Upload complete");
        showMessage(`"${title}" uploaded and saved. Copy its link from Saved videos below.`);
      } else {
        if (!parseHostedVideoUrl(videoUrl)) throw new Error(HOSTED_VIDEO_URL_HINT);
        const { response, data } = await fetchApiJson("/api/videos", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title, videoUrl, notes })
        });
        if (!response.ok) throw new Error(data.error || HOSTED_VIDEO_URL_HINT);
        showMessage(`"${title}" saved. Copy its link from Saved videos below.`);
      }

      resetVideoForm();
      await loadVideos();
    } catch (error) {
      showMessage(error.message || "Save failed.", true);
    } finally {
      setVideoSavingState(false);
      hideVideoUploadProgress();
    }
  });
}

function scrollToVideoLibraryIfNeeded() {
  if (window.location.hash !== "#video-library") return;
  const el = document.getElementById("video-library");
  if (!el) return;
  window.setTimeout(() => {
    el.scrollIntoView({ behavior: "smooth", block: "start" });
  }, 120);
}
