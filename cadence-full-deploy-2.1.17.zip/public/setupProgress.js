/**
 * setupProgress.js
 * Shows a setup progress bar at the top of the page.
 * Tracks 3 key agent setup steps: password, email, cell forwarding.
 * Dismisses permanently once all 3 are complete or user clicks dismiss.
 */
(function initSetupProgress() {
  const STORAGE_KEY = "cadence_progress_dismissed";
  const prefs = window.CrmClientPrefs || {};

  function isDismissed() {
    return typeof prefs.readFlag === "function"
      ? prefs.readFlag(STORAGE_KEY)
      : localStorage.getItem(STORAGE_KEY) === "1";
  }

  function markDismissed() {
    if (typeof prefs.writeAccountFlag === "function") prefs.writeAccountFlag(STORAGE_KEY);
    else if (typeof prefs.writeFlag === "function") prefs.writeFlag(STORAGE_KEY);
    else {
      try {
        localStorage.setItem(STORAGE_KEY, "1");
      } catch {
        /* ignore */
      }
    }
  }

  function buildBar(steps) {
    const done  = steps.filter(s => s.done).length;
    const total = steps.length;
    const pct   = Math.round((done / total) * 100);
    const allDone = done === total;

    const bar = document.createElement("div");
    bar.id = "setupProgressBar";
    bar.style.cssText = `background:${allDone ? "#d1fae5" : "#eff6ff"};border:1px solid ${allDone ? "#6ee7b7" : "#bfdbfe"};border-radius:12px;padding:10px 14px;margin:0 0 12px;display:flex;align-items:center;gap:14px;flex-wrap:wrap;width:fit-content;max-width:100%;`;

    bar.innerHTML = `
      <div style="width:220px;max-width:100%;flex:none;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:5px;">
          <span style="font-size:0.82rem;font-weight:700;color:${allDone ? "#065f46" : "#1e40af"};">
            ${allDone ? "✅ Setup complete — you're ready to go!" : `Setup: ${done} of ${total} steps complete`}
          </span>
          <span style="font-size:0.78rem;color:${allDone ? "#047857" : "#3b82f6"};font-weight:600;">${pct}%</span>
        </div>
        <div style="background:${allDone ? "#a7f3d0" : "#dbeafe"};border-radius:99px;height:6px;overflow:hidden;">
          <div style="height:100%;width:${pct}%;background:${allDone ? "#059669" : "#3b82f6"};border-radius:99px;transition:width 0.4s;"></div>
        </div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        ${steps.map(s => `
          <a href="${s.href}" style="display:inline-flex;align-items:center;gap:5px;padding:5px 12px;border-radius:8px;font-size:0.78rem;font-weight:600;text-decoration:none;
            background:${s.done ? "#d1fae5" : "#fff"};color:${s.done ? "#065f46" : "#1e40af"};
            border:1px solid ${s.done ? "#6ee7b7" : "#bfdbfe"};">
            ${s.done ? "✅" : "○"} ${s.label}
          </a>
        `).join("")}
      </div>
      <button id="setupProgressDismiss" title="Dismiss" style="background:none;border:none;color:#94a3b8;font-size:1.1rem;cursor:pointer;padding:2px 6px;line-height:1;flex-shrink:0;">✕</button>
    `;

    bar.querySelector("#setupProgressDismiss")?.addEventListener("click", () => {
      markDismissed();
      bar.remove();
    });

    return bar;
  }

  async function init() {
    if (typeof prefs.resolveOnboardingAccount === "function") {
      await prefs.resolveOnboardingAccount();
    }
    if (typeof prefs.readAccountFlag === "function" ? prefs.readAccountFlag(STORAGE_KEY) : localStorage.getItem(STORAGE_KEY)) {
      return;
    }

    try {
      const [status, twilioConf] = await Promise.all([
        fetch("/api/runtime/setup-status", { credentials: "include" }).then((r) => r.json()),
        fetch("/api/twilio/config", { credentials: "include" }).then((r) => r.json())
      ]);

      const trial = window.__CRM_WORKSPACE_TYPE__ === "trial";
      let emailDone = status?.smtp?.level === "ok";
      if (trial) {
        try {
          const optRes = await fetch("/api/email/options", { credentials: "include" });
          const optData = await optRes.json();
          const detailed = Array.isArray(optData.fromAddresses) ? optData.fromAddresses : [];
          emailDone = detailed.some((d) => d && d.hasSmtp === true);
        } catch {
          emailDone = false;
        }
      }

      const steps = [
        {
          label: "Set password",
          done: trial ? true : status?.login?.level === "ok",
          href: "/settings.html?section=general"
        },
        {
          label: "Connect email",
          done: emailDone,
          href: "/settings.html?section=email-senders"
        },
        {
          label: "Forward calls",
          done: Boolean(twilioConf?.inboundForwardTo),
          href: "/settings.html?section=twilio"
        }
      ];

      const allDone = steps.every((s) => s.done);
      if (allDone) {
        markDismissed();
        return;
      }

      const bar = buildBar(steps);
      const main = document.querySelector("main") || document.body;
      main.insertBefore(bar, main.firstChild);
    } catch (_) {
      /* keep workspace usable if setup status fails */
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => setTimeout(init, 800));
  } else {
    setTimeout(init, 800);
  }
})();
