const messageEl = document.getElementById("attentionMessage");
const refreshBtn = document.getElementById("attentionRefreshBtn");
const listEl = document.getElementById("attentionQueueList");
const filterHintEl = document.getElementById("attentionFilterHint");
const countOverdueEl = document.getElementById("attentionCountOverdue");
const countTodayEl = document.getElementById("attentionCountToday");
const countUpcomingEl = document.getElementById("attentionCountUpcoming");
const countTotalEl = document.getElementById("attentionCountTotal");
const summaryGrid = document.querySelector(".attention-summary-grid");

let allItems = [];
let activeFilter = "overdue";

function showMessage(text, isError = false) {
  if (!messageEl) return;
  const str = String(text == null ? "" : text);
  if (isError && typeof window.crmHandleAuthErrorMessage === "function" && window.crmHandleAuthErrorMessage(str, isError)) {
    return;
  }
  messageEl.textContent = str;
  messageEl.classList.toggle("attention-message--error", Boolean(isError));
}

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function formatDue(dueAt) {
  const raw = String(dueAt || "").trim();
  if (!raw) return "";
  const datePart = raw.slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(datePart)) return String(raw);
  const [y, m, d] = datePart.split("-").map((n) => Number(n));
  const dt = new Date(y, m - 1, d);
  let label = dt.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
  const timeMatch = raw.match(/T(\d{2}:\d{2})/);
  if (timeMatch) {
    const [hh, mm] = timeMatch[1].split(":").map((n) => Number(n));
    const t = new Date(y, m - 1, d, hh, mm);
    label += ` · ${t.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}`;
  }
  return label;
}

function isOverdueKind(kind) {
  return ["task_overdue", "follow_up_overdue", "renewal_overdue"].includes(kind);
}

function isTodayKind(kind) {
  return ["task_today", "follow_up_today"].includes(kind);
}

function isWatchKind(kind) {
  return ["renewal_soon", "stale_lead", "hot_lead"].includes(kind);
}

function matchesFilter(item, filter) {
  if (!filter || filter === "all") return true;
  if (filter === "overdue") return isOverdueKind(item.kind);
  if (filter === "today") return isTodayKind(item.kind);
  if (filter === "watch") return isWatchKind(item.kind);
  return item.kind === filter;
}

function filterHint(filter, count) {
  const n = Number(count) || 0;
  const noun = n === 1 ? "item" : "items";
  if (filter === "overdue") return `Showing ${n} overdue ${noun}`;
  if (filter === "today") return `Showing ${n} due today`;
  if (filter === "watch") return `Showing ${n} watch-list ${noun}`;
  return `Showing all ${n} ${noun}`;
}

function itemToneClass(kind) {
  if (isOverdueKind(kind)) return "attention-item--overdue";
  if (isTodayKind(kind)) return "attention-item--today";
  if (kind === "hot_lead") return "attention-item--hot";
  if (kind === "stale_lead") return "attention-item--stale";
  if (kind === "renewal_soon" || kind === "renewal_overdue") return "attention-item--renewal";
  return "";
}

function kindBadgeClass(kind) {
  if (isOverdueKind(kind)) return "attention-kind attention-kind--overdue";
  if (isTodayKind(kind)) return "attention-kind attention-kind--today";
  if (kind === "stale_lead") return "attention-kind attention-kind--stale";
  if (kind === "hot_lead") return "attention-kind attention-kind--hot";
  if (kind === "renewal_soon" || kind === "renewal_overdue") return "attention-kind attention-kind--renewal";
  return "attention-kind";
}

function detailText(item) {
  const meta = item && item.meta ? item.meta : {};
  if (item.kind === "hot_lead") {
    const reason = String(meta.ai_lead_reason || "").trim();
    const outcome = String(meta.outcome || "").trim();
    const parts = [];
    if (outcome) parts.push(outcome);
    if (reason) parts.push(reason.length > 140 ? `${reason.slice(0, 137)}…` : reason);
    return parts.join(" · ");
  }
  if (item.kind === "stale_lead") {
    const status = String(meta.status || "").trim();
    const last = String(meta.last_at || "").trim();
    const bits = ["No outreach logged in over a week — call, text, or email, or update status."];
    if (status) bits.unshift(status);
    if (last) bits.push(`Last touch: ${last.slice(0, 16).replace("T", " ")}`);
    return bits.join(" · ");
  }
  if (item.kind === "renewal_soon" || item.kind === "renewal_overdue") {
    const days = Number(meta.days_until);
    if (Number.isFinite(days) && days < 0) return `${Math.abs(days)} day${Math.abs(days) === 1 ? "" : "s"} past renewal`;
    if (days === 0) return "Renewal date is today";
    if (Number.isFinite(days)) return `Renews in ${days} day${days === 1 ? "" : "s"}`;
  }
  if (item.kind === "task_overdue" || item.kind === "task_today") {
    const action = String(meta.action_type || "").trim();
    return action ? `${action} task` : "Open contact to complete this task";
  }
  if (item.kind === "follow_up_overdue" || item.kind === "follow_up_today") {
    return "Follow-up reminder on this contact";
  }
  return "";
}

function whenLabel(item) {
  if (isOverdueKind(item.kind)) {
    const due = formatDue(item.due_at);
    return due ? `Past due · ${due}` : "Past due";
  }
  if (isTodayKind(item.kind)) {
    const raw = String(item.due_at || "").trim();
    const timeMatch = raw.match(/T(\d{2}:\d{2})/);
    if (timeMatch) {
      const datePart = raw.slice(0, 10);
      const [y, m, d] = datePart.split("-").map((n) => Number(n));
      const [hh, mm] = timeMatch[1].split(":").map((n) => Number(n));
      const t = new Date(y, m - 1, d, hh, mm);
      return `Today · ${t.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}`;
    }
    return "Today";
  }
  if (item.kind === "hot_lead") {
    const score = Number(item.meta && item.meta.ai_lead_score);
    return Number.isFinite(score) && score > 0 ? `Score ${score}/10` : "";
  }
  return formatDue(item.due_at);
}

function setActiveFilter(filter) {
  activeFilter = filter || "all";
  if (summaryGrid) {
    summaryGrid.querySelectorAll(".attention-stat").forEach((btn) => {
      btn.classList.toggle("is-active", btn.getAttribute("data-filter") === activeFilter);
    });
  }
  renderList();
}

function preferredDefaultFilter(counts) {
  if (Number(counts.overdue || 0) > 0) return "overdue";
  if (Number(counts.today || 0) > 0) return "today";
  if (Number(counts.upcoming || 0) > 0) return "watch";
  return "all";
}

function renderList() {
  if (!listEl) return;
  const rows = allItems.filter((item) => matchesFilter(item, activeFilter));
  if (filterHintEl) filterHintEl.textContent = filterHint(activeFilter, rows.length);
  if (!rows.length) {
    const emptyByFilter = {
      overdue: "Nothing overdue. Nice work — check Due today or Watch list.",
      today: "Nothing due today. Overdue and watch-list items stay in the other tabs.",
      watch: "Watch list is empty. Contacts with no call/text/email in 7+ days, hot leads, and renewals show up here.",
      all: "Queue is clear. Add follow-ups and tasks on contacts to fill it."
    };
    listEl.innerHTML = `<div class="attention-empty">${escapeHtml(emptyByFilter[activeFilter] || emptyByFilter.all)}</div>`;
    return;
  }

  listEl.innerHTML = rows
    .map((item) => {
      const href = item.href || "#";
      const name = escapeHtml(item.contact_name || "Unnamed contact");
      const title = escapeHtml(item.title || item.kind_label || "");
      const kind = escapeHtml(item.kind_label || item.kind || "");
      const detail = escapeHtml(detailText(item));
      const when = escapeHtml(whenLabel(item));
      const tone = itemToneClass(item.kind);
      const badge = kindBadgeClass(item.kind);
      return (
        `<a class="attention-item ${tone}" href="${escapeHtml(href)}">` +
        `<div class="attention-item-main">` +
        `<div class="attention-item-top">` +
        `<span class="${badge}">${kind}</span>` +
        (when ? `<span class="attention-item-when">${when}</span>` : "") +
        `</div>` +
        `<div class="attention-item-name">${name}</div>` +
        `<div class="attention-item-title">${title}</div>` +
        (detail ? `<div class="attention-item-detail">${detail}</div>` : "") +
        `</div>` +
        `<span class="attention-item-cta">Open</span>` +
        `</a>`
      );
    })
    .join("");
}

async function loadAttention() {
  showMessage("");
  const { response, data } = await window.CrmApi.fetchApiJson("/api/attention/queue");
  if (!response.ok) throw new Error((data && data.error) || "Could not load attention queue.");
  allItems = Array.isArray(data.items) ? data.items : [];
  const counts = data.counts || {};
  if (countOverdueEl) countOverdueEl.textContent = String(Number(counts.overdue || 0));
  if (countTodayEl) countTodayEl.textContent = String(Number(counts.today || 0));
  if (countUpcomingEl) countUpcomingEl.textContent = String(Number(counts.upcoming || 0));
  if (countTotalEl) countTotalEl.textContent = String(Number(counts.total || allItems.length || 0));
  setActiveFilter(preferredDefaultFilter(counts));
  showMessage(`Updated ${new Date().toLocaleTimeString()} · ${allItems.length} item${allItems.length === 1 ? "" : "s"}`);
}

if (summaryGrid) {
  summaryGrid.addEventListener("click", (event) => {
    const btn = event.target.closest(".attention-stat[data-filter]");
    if (!btn) return;
    setActiveFilter(btn.getAttribute("data-filter"));
  });
}

if (refreshBtn) {
  refreshBtn.addEventListener("click", () => {
    loadAttention().catch((error) => showMessage(error.message, true));
  });
}

loadAttention().catch((error) => showMessage(error.message, true));
