const messageEl = document.getElementById("message");
const campaignForm = document.getElementById("campaignForm");
const campaignStepsEl = document.getElementById("campaignSteps");
const campaignTagRulesEl = document.getElementById("campaignTagRules");
const campaignListEl = document.getElementById("campaignList");
const campaignCategorySelect = document.getElementById("campaignCategorySelect");
const campaignCategoryFieldBox = campaignCategorySelect ? campaignCategorySelect.closest(".contact-field-box") : null;
const addCampaignCategoryBtn = document.getElementById("addCampaignCategoryBtn");
const renameCampaignCategoryBtn = document.getElementById("renameCampaignCategoryBtn");
const deleteCampaignCategoryBtn = document.getElementById("deleteCampaignCategoryBtn");
const addCampaignCategorySidebarBtn = document.getElementById("addCampaignCategorySidebarBtn");
const savedCampaignCategoryList = document.getElementById("savedCampaignCategoryList");
const addStepBtn = document.getElementById("addStepBtn");
const campaignStartFirstStepImmediatelyEl = document.getElementById("campaignStartFirstStepImmediately");
const timelinePreviewEl = document.getElementById("campaignTimelinePreview");
const cancelEditBtn = document.getElementById("cancelEditBtn");
const journeyChartEl = document.getElementById("campaignJourneyChart");
const journeyStepDialog = document.getElementById("journeyStepDialog");
const journeyStepDialogHeading = document.getElementById("journeyStepDialogHeading");
const journeyStepDialogBody = document.getElementById("journeyStepDialogBody");
const campaignCategoryDialog = document.getElementById("campaignCategoryDialog");
const campaignCategoryDialogForm = document.getElementById("campaignCategoryDialogForm");
const campaignCategoryDialogName = document.getElementById("campaignCategoryDialogName");
const campaignCategoryDialogCancel = document.getElementById("campaignCategoryDialogCancel");
const campaignIncludeSignatureEl = document.getElementById("campaignIncludeSignature");
const analyzeCampaignBtn = document.getElementById("analyzeCampaignBtn");
const campaignAiResult = document.getElementById("campaignAiResult");
const campaignSummaryNameEl = document.getElementById("campaignSummaryName");
const campaignSummaryStepsEl = document.getElementById("campaignSummarySteps");
const campaignSummaryDurationEl = document.getElementById("campaignSummaryDuration");
const campaignSummaryChannelsEl = document.getElementById("campaignSummaryChannels");
const campaignSummaryEnrolledEl = document.getElementById("campaignSummaryEnrolled");
const DEFAULT_CAMPAIGN_TWILIO_NUMBER = "855-924-7448";
/** Aligned with email.js template / signature image cap (RICH_EMAIL_SIGNATURE_IMAGE_MAX_PX) */
const CAMPAIGN_SIGNATURE_IMAGE_MAX_PX = 220;

/** Starter drips agents can load into the builder and customize. */
const CAMPAIGN_STARTERS = {
  "new-lead-nurture": {
    name: "New Lead Nurture",
    tag: "new-lead",
    steps: [
      {
        offset_hours: 0,
        channel: "sms",
        body:
          "Hi {{first_name}}, thanks for reaching out about health insurance. I'm {{full_name}} — reply here or call {{phone}} when you have a minute to talk."
      },
      {
        offset_hours: 24,
        channel: "email",
        subject: "Thanks for connecting, {{first_name}}",
        body:
          "<p>Hi {{first_name}},</p><p>Thanks again for your interest. I help people compare plans without the jargon — doctors, prescriptions, and budget all in one conversation.</p><p>Reply with a good time to talk, or let me know if you'd like a quote summary by email first.</p><p>Talk soon,<br>{{full_name}}</p>"
      },
      {
        offset_hours: 72,
        channel: "sms",
        body:
          "Hi {{first_name}} — just checking in. Still happy to walk through plan options whenever works for you. No pressure."
      },
      {
        offset_hours: 168,
        channel: "email",
        subject: "Quick follow-up on your health insurance quote",
        body:
          "<p>Hi {{first_name}},</p><p>I wanted to circle back in case you had questions about the quote or coverage start date.</p><p>If now isn't the right time, just reply and I'll follow up when you prefer.</p><p>Best,<br>{{full_name}}</p>"
      }
    ]
  },
  "oep-reminder": {
    name: "OEP Reminder",
    tag: "oep-prospect",
    steps: [
      {
        offset_hours: 0,
        channel: "email",
        subject: "Open enrollment ends soon — let's review your options, {{first_name}}",
        body:
          "<p>Hi {{first_name}},</p><p>Open enrollment is closing soon. After the deadline, you generally can't change individual or family coverage until next year unless you have a qualifying life event.</p><p>I'd like to schedule a quick 15-minute review of your options — premiums, deductibles, and whether you qualify for a subsidy.</p><p>Reply with a time that works or call {{phone}}.</p><p>Best,<br>{{full_name}}</p>"
      },
      {
        offset_hours: 48,
        channel: "sms",
        body:
          "Hi {{first_name}} — friendly reminder that open enrollment is ending soon. Want help comparing plans before the window closes? Reply YES and I'll reach out."
      },
      {
        offset_hours: 120,
        channel: "email",
        subject: "Last chance before open enrollment closes",
        body:
          "<p>Hi {{first_name}},</p><p>This is a final reminder before the open enrollment window closes. If you'd like to lock in coverage for next year, let's connect in the next day or two.</p><p>Best,<br>{{full_name}}</p>"
      }
    ]
  },
  "post-enrollment-retention": {
    name: "Post-Enrollment Retention",
    tag: "enrolled-client",
    steps: [
      {
        offset_hours: 0,
        channel: "email",
        subject: "Welcome aboard, {{first_name}} — your coverage is active",
        body:
          "<p>Hi {{first_name}},</p><p>Thank you for choosing your plan. Your coverage is set for <strong>{{coverage_start_date}}</strong>. Watch your mail for ID cards in the next 7–10 business days.</p><p>Questions about doctors, prescriptions, or claims? Email or call me first — I'm here for you after enrollment too.</p><p>Welcome,<br>{{full_name}}</p>"
      },
      {
        offset_hours: 336,
        channel: "sms",
        body:
          "Hi {{first_name}} — checking in after your plan started. Did your ID cards arrive? Reply if you need anything."
      },
      {
        offset_hours: 720,
        channel: "email",
        subject: "Annual check-in, {{first_name}}",
        body:
          "<p>Hi {{first_name}},</p><p>It's been a few months since your plan started. I like to check in with clients to make sure coverage still fits — especially if anything changed with doctors, prescriptions, or household size.</p><p>Reply if you'd like a quick review.</p><p>Best,<br>{{full_name}}</p>"
      }
    ]
  }
};

/** Latest steps shown in journey chart (sorted by offset), for click-to-detail */
let journeyChartState = { steps: [], startAt: NaN, twilioFromDisplay: "—" };
let cachedCampaigns = [];
let cachedCampaignCategories = [];
let emailTemplateRowsCache = [];
let emailFromAddressesCache = [];
let selectedSavedCategoryId = "__all__";
const expandedCategoryValues = new Set(["__all__"]);
let selectedSavedCampaignId = null;
let pendingEditCampaignIdFromQuery = Number(new URLSearchParams(window.location.search).get("editCampaignId") || 0);
let campaignUserEditedSinceLoad = false;

function rememberCampaignUserEdit(event) {
  if (event && event.isTrusted === false) return;
  campaignUserEditedSinceLoad = true;
}

function markCampaignBuilderCleanAfterHydration() {
  if (campaignUserEditedSinceLoad) return;
  window.setTimeout(() => {
    if (!campaignUserEditedSinceLoad && window.CrmUnsavedGuard) window.CrmUnsavedGuard.markClean();
  }, 0);
}

function showMessage(text, isError = false) {
  const str = String(text == null ? "" : text);
  messageEl.classList.toggle("is-error", Boolean(isError));
  messageEl.classList.toggle("is-success", !isError);
  if (isError && typeof window.crmHandleAuthErrorMessage === "function" && window.crmHandleAuthErrorMessage(str, isError)) {
    return;
  }
  messageEl.textContent = str;
}

function getCrmApiBase() {
  const injected =
    typeof window.__CRM_API_ORIGIN__ === "string" ? window.__CRM_API_ORIGIN__.trim().replace(/\/$/, "") : "";
  if (injected) return injected;
  const fromMeta = document.querySelector('meta[name="crm-api-base"]')?.getAttribute("content") || "";
  return String(fromMeta || "").trim().replace(/\/$/, "");
}

function apiUrl(path) {
  const p = path.startsWith("/") ? path : `/${path}`;
  const base = getCrmApiBase();
  return base ? `${base}${p}` : p;
}

async function fetchApiJson(pathAndQuery, init) {
  const response = await fetch(apiUrl(pathAndQuery), init);
  const text = await response.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = {};
  }
  return { response, data };
}

function renderCampaignAiResult(title, dataOrHtml) {
  if (!campaignAiResult) return;
  const html =
    typeof dataOrHtml === "string"
      ? dataOrHtml
      : `<p>${escapeHtml(dataOrHtml.summary || "")}</p>${
          Array.isArray(dataOrHtml.whatWorked) && dataOrHtml.whatWorked.length
            ? `<p><strong>What worked</strong></p><ul>${dataOrHtml.whatWorked.map((x) => `<li>${escapeHtml(x)}</li>`).join("")}</ul>`
            : ""
        }${
          Array.isArray(dataOrHtml.whatDidNotWork) && dataOrHtml.whatDidNotWork.length
            ? `<p><strong>What needs work</strong></p><ul>${dataOrHtml.whatDidNotWork.map((x) => `<li>${escapeHtml(x)}</li>`).join("")}</ul>`
            : ""
        }${
          Array.isArray(dataOrHtml.changes) && dataOrHtml.changes.length
            ? `<p><strong>Recommended changes</strong></p><ul>${dataOrHtml.changes.map((x) => `<li>${escapeHtml(x)}</li>`).join("")}</ul>`
            : ""
        }${dataOrHtml.nextTest ? `<p><strong>Next test:</strong> ${escapeHtml(dataOrHtml.nextTest)}</p>` : ""}`;
  campaignAiResult.innerHTML = `<div class="campaign-ai-card"><strong>${escapeHtml(title)}</strong>${html}</div>`;
}

async function analyzeSelectedCampaign() {
  const campaignId = Number(selectedSavedCampaignId);
  if (!Number.isInteger(campaignId) || campaignId <= 0) {
    renderCampaignAiResult("AI Campaign Analyzer", `<p class="is-error">Select a saved campaign first.</p>`);
    return;
  }
  if (analyzeCampaignBtn) analyzeCampaignBtn.disabled = true;
  renderCampaignAiResult("AI Campaign Analyzer", "<p>Analyzing this campaign...</p>");
  try {
    const { response, data } = await fetchApiJson(`/api/ai/campaigns/${encodeURIComponent(campaignId)}/analyze`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({})
    });
    if (!response.ok) throw new Error(data.error || "Could not analyze campaign.");
    renderCampaignAiResult("AI Campaign Analyzer", data);
  } catch (error) {
    renderCampaignAiResult("AI Campaign Analyzer", `<p class="is-error">${escapeHtml(error.message || "Could not analyze campaign.")}</p>`);
  } finally {
    if (analyzeCampaignBtn) analyzeCampaignBtn.disabled = false;
  }
}

function formatUnix(sec) {
  const n = Number(sec);
  if (!Number.isFinite(n) || n <= 0) return "Not set";
  return new Date(n * 1000).toLocaleString();
}

function escapeHtml(text) {
  return String(text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function sanitizeCampaignEmailHtml(html) {
  const raw = String(html || "");
  if (typeof window.DOMPurify !== "undefined") {
    return window.DOMPurify.sanitize(raw, {
      ALLOWED_TAGS: [
        "p",
        "br",
        "strong",
        "b",
        "em",
        "i",
        "u",
        "s",
        "strike",
        "span",
        "div",
        "font",
        "h1",
        "h2",
        "h3",
        "h4",
        "ul",
        "ol",
        "li",
        "a",
        "img",
        "blockquote",
        "pre",
        "hr",
        "table",
        "thead",
        "tbody",
        "tfoot",
        "tr",
        "td",
        "th",
        "center",
        "small",
        "sup",
        "sub",
        "code"
      ],
      ALLOWED_ATTR: [
        "style",
        "src",
        "alt",
        "href",
        "target",
        "rel",
        "title",
        "color",
        "size",
        "face",
        "class",
        "width",
        "height",
        "align",
        "valign",
        "border",
        "cellpadding",
        "cellspacing",
        "colspan",
        "rowspan",
        "bgcolor"
      ],
      ALLOWED_URI_REGEXP: /^(?:(?:https?|data|mailto):|[^a-z]|[a-z+.-]+(?:[^a-z+.-:]|$))/i
    });
  }
  return raw.replace(/<script\b[\s\S]*?<\/script>/gi, "");
}

function getEmailTemplateLabel(templateRow) {
  const category = String(templateRow?.category_name || "").trim();
  const name = String(templateRow?.name || "").trim() || "Template";
  return category ? `${category} - ${name}` : name;
}

function populateStepEmailTemplateSelect(selectEl) {
  if (!selectEl) return;
  const prev = String(selectEl.value || "");
  selectEl.innerHTML = '<option value="">Load from saved template…</option>';
  const sortedTemplates = [...emailTemplateRowsCache].sort((a, b) =>
    getEmailTemplateLabel(a).localeCompare(getEmailTemplateLabel(b), undefined, { sensitivity: "base" })
  );
  for (const row of sortedTemplates) {
    const opt = document.createElement("option");
    opt.value = String(row.id);
    opt.textContent = getEmailTemplateLabel(row);
    selectEl.appendChild(opt);
  }
  if (prev && [...selectEl.options].some((o) => o.value === prev)) {
    selectEl.value = prev;
  }
}

async function loadCampaignStepEmailTemplates() {
  const { response, data } = await fetchApiJson("/api/email/templates");
  if (!response.ok) throw new Error(data.error || "Failed to load email templates");
  emailTemplateRowsCache = Array.isArray(data) ? data : [];
  document.querySelectorAll(".step-email-template").forEach((selectEl) => {
    populateStepEmailTemplateSelect(selectEl);
  });
}

/** Remove HTML width/height attributes so CSS max-width controls display (contenteditable often preserves pixel attrs). */
function stripImgTagDimensionAttrs(imgTag) {
  return String(imgTag || "")
    .replace(/\s+width\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, "")
    .replace(/\s+height\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, "");
}

function clampCampaignEmailBodyImages(rawHtml, maxWidthPx = 420) {
  const raw = String(rawHtml || "");
  if (!raw || !/<img[\s>]/i.test(raw)) return raw;
  const safeMax = Number.isFinite(Number(maxWidthPx)) ? Math.max(120, Math.round(Number(maxWidthPx))) : 420;
  const normalizeImgTag = (imgTag) => {
    let out = stripImgTagDimensionAttrs(imgTag);
    const styleMatch = out.match(/\sstyle=(['"])([\s\S]*?)\1/i);
    const styleRaw = styleMatch ? String(styleMatch[2] || "") : "";
    const maxMatch = styleRaw.match(/max-width\s*:\s*(\d+(?:\.\d+)?)px/i);
    const existingMax = maxMatch ? Number(maxMatch[1]) : NaN;
    const effectiveMax = Number.isFinite(existingMax) && existingMax > 0 ? Math.min(existingMax, safeMax) : safeMax;
    const cleaned = styleRaw
      .replace(/(?:^|;)\s*width\s*:[^;]*/gi, "")
      .replace(/(?:^|;)\s*height\s*:[^;]*/gi, "")
      .trim();
    const styleFinal = `${cleaned ? `${cleaned};` : ""}max-width:${effectiveMax}px;height:auto;`;
    if (styleMatch) out = out.replace(/\sstyle=(['"])([\s\S]*?)\1/i, ` style="${styleFinal}"`);
    else out = out.replace(/<img\b/i, `<img style="${styleFinal}"`);
    return out;
  };
  return raw.replace(/<img\b[^>]*>/gi, (tag) => normalizeImgTag(tag));
}

const EMAIL_SIGNATURE_STORAGE_KEY = "crm.emailSignatureSettings";
const EMAIL_INCLUDE_SIGNATURE_STORAGE_KEY = "crm.emailIncludeSignature";

function textToHtmlLines(value) {
  return escapeHtml(String(value || "")).replace(/\r?\n/g, "<br>");
}

function signatureStorageHasVisibleContent(signatureHtml, signatureText) {
  if (String(signatureText || "").trim()) return true;
  const raw = String(signatureHtml || "").trim();
  if (!raw) return false;
  if (/<img[\s>]/i.test(raw)) return true;
  const stripped = raw
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
  return stripped.length > 0;
}

/**
 * Like public/email.js clampSignatureImageHtml: cap with max-width only (no fixed `width` attr)
 * so small icons and headshots size naturally up to the cap.
 */
function clampSignatureImageHtml(rawHtml) {
  const raw = String(rawHtml || "");
  if (!raw || !/<img[\s>]/i.test(raw)) return raw;
  const maxW = CAMPAIGN_SIGNATURE_IMAGE_MAX_PX;
  const normalizeImgTag = (imgTag) => {
    let out = stripImgTagDimensionAttrs(imgTag);
    const styleMatch = out.match(/\sstyle=(['"])([\s\S]*?)\1/i);
    const styleRaw = styleMatch ? String(styleMatch[2] || "") : "";
    const cleaned = styleRaw
      .replace(/(?:^|;)\s*width\s*:[^;]*/gi, "")
      .replace(/(?:^|;)\s*max-width\s*:[^;]*/gi, "")
      .replace(/(?:^|;)\s*height\s*:[^;]*/gi, "")
      .replace(/(?:^|;)\s*display\s*:[^;]*/gi, "")
      .replace(/(?:^|;)\s*margin-bottom\s*:[^;]*/gi, "")
      .trim();
    const styleFinal = `${cleaned ? `${cleaned};` : ""}max-width:${maxW}px;height:auto;display:block;margin-bottom:12px;`;
    if (styleMatch) out = out.replace(/\sstyle=(['"])([\s\S]*?)\1/i, ` style="${styleFinal}"`);
    else out = out.replace(/<img\b/i, `<img style="${styleFinal}"`);
    if (!/\salt=/i.test(out)) out = out.replace(/<img\b/i, '<img alt="Signature image"');
    return out;
  };
  return raw.replace(/<img\b[^>]*>/gi, (tag) => normalizeImgTag(tag));
}

/** Same saved signature block as Send Email / email.js getComposedEmailContent (URL image only; no live file picker). */
function buildStoredSignatureBlockHtml(hasMainAbove, includeOverride = null) {
  try {
    const includeRaw = window.localStorage.getItem(EMAIL_INCLUDE_SIGNATURE_STORAGE_KEY);
    const include =
      includeOverride == null ? (includeRaw == null ? true : includeRaw === "1") : Boolean(includeOverride);
    if (!include) return "";

    const raw = window.localStorage.getItem(EMAIL_SIGNATURE_STORAGE_KEY);
    const settings = raw ? JSON.parse(raw) : {};
    const signatureHtml = String(settings.html || "").trim();
    const signatureText = String(settings.text || "").trim();
    const fontSize = Number(settings.fontSize || 16);
    const color = String(settings.color || "#1f2937").trim();
    const linkText = String(settings.linkText || "").trim();
    const linkUrl = String(settings.linkUrl || "").trim();
    const imageUrl = String(settings.imageUrl || "").trim();

    const signatureTextHtml = clampSignatureImageHtml(signatureHtml || (signatureText ? textToHtmlLines(signatureText) : ""));
    const signatureHasInlineImage = /<img[\s>]/i.test(signatureHtml);
    const hasSignatureContent =
      signatureStorageHasVisibleContent(signatureHtml, signatureText) ||
      signatureHasInlineImage ||
      (linkText && linkUrl) ||
      Boolean(imageUrl);

    if (!hasSignatureContent) return "";

    const safeFontSize = Number.isFinite(fontSize) ? Math.min(36, Math.max(10, Math.round(fontSize))) : 16;
    const safeColor = /^#[0-9a-fA-F]{6}$/.test(color) ? color : "#1f2937";
    const linkHtml =
      linkText && linkUrl
        ? `<div style="margin-top:8px;"><a href="${escapeHtml(linkUrl)}" target="_blank" rel="noopener noreferrer">${escapeHtml(
            linkText
          )}</a></div>`
        : "";
    const imageHtml = imageUrl
      ? `<div style="margin-top:8px;"><img src="${escapeHtml(imageUrl)}" alt="Signature image" style="max-width:${CAMPAIGN_SIGNATURE_IMAGE_MAX_PX}px;height:auto;display:block;border:0;margin-bottom:12px;" /></div>`
      : "";
    const sigSep = hasMainAbove
      ? "margin-top:18px;padding-top:14px;border-top:1px solid #e5e7eb;"
      : "margin-top:0;padding-top:0;";
    return `<div class="campaign-email-signature-block" style="${sigSep}font-family:system-ui,Segoe UI,Arial,sans-serif;font-size:${safeFontSize}px;color:${safeColor};line-height:1.45;">${signatureTextHtml}${linkHtml}${imageHtml}</div>`;
  } catch {
    return "";
  }
}

/** Email step editor shows main body only; signature is merged on save/send when Include Signature is checked. */
function composeEmailStepBodyWithOptionalSignature(mainPlain) {
  const main = String(mainPlain || "").trim();
  const mainInner = main ? `<p>${escapeHtml(main).replace(/\r?\n/g, "<br />")}</p>` : "";
  const mainWrapped = mainInner
    ? `<div style="font-family:system-ui,Segoe UI,Arial,sans-serif;font-size:14px;line-height:1.5;color:#111827;">${mainInner}</div>`
    : "";
  if (!mainWrapped) return "<p></p>";
  return `<div style="max-width:100%;word-wrap:break-word;">${mainWrapped}</div>`;
}

function stripCampaignSignatureBlocks(html) {
  const raw = String(html || "");
  if (!raw.trim()) return raw;
  const host = document.createElement("div");
  host.innerHTML = raw;
  host.querySelectorAll(".campaign-email-signature-block").forEach((el) => el.remove());
  return host.innerHTML;
}

function appendStoredSignatureToEmailHtml(mainHtml, includeSignature = true) {
  const base = stripCampaignSignatureBlocks(String(mainHtml || "")).trim();
  const sig = buildStoredSignatureBlockHtml(Boolean(base), includeSignature);
  if (!sig) return base || "<p></p>";
  return `${base}${sig}`;
}

function campaignRichEmailBodyIsEmpty(rich) {
  if (!rich) return true;
  const t = String(rich.textContent || "")
    .replace(/\u00a0/g, " ")
    .trim();
  const h = String(rich.innerHTML || "")
    .trim()
    .toLowerCase();
  if (!h || h === "<p></p>" || h === "<p><br></p>" || h === "<br>" || h === "<div><br></div>") return true;
  return !t && !/<img[\s>]/i.test(rich.innerHTML || "");
}

function getStepBodyFromRow(row) {
  const ch = row.querySelector(".step-channel").value;
  if (ch === "email") {
    const rich = row.querySelector(".step-body-rich");
    const html = rich ? rich.innerHTML : "";
    const cleaned = clampCampaignEmailBodyImages(sanitizeCampaignEmailHtml(html), 420).trim();
    const includeSignature = campaignIncludeSignatureEl ? Boolean(campaignIncludeSignatureEl.checked) : true;
    const composed = includeSignature
      ? appendStoredSignatureToEmailHtml(cleaned, includeSignature)
      : stripCampaignSignatureBlocks(cleaned).trim();
    return finalizeCampaignEmailStepHtml(composed);
  }
  return String(row.querySelector(".step-body-plain").value || "").trim();
}

function readStepBodyLive(row) {
  const ch = row.querySelector(".step-channel").value;
  if (ch === "email") {
    const rich = row.querySelector(".step-body-rich");
    return rich ? rich.innerHTML : "";
  }
  return String(row.querySelector(".step-body-plain").value || "");
}

function ensureStepEmailImageWrap(wrap) {
  if (!wrap) return;
  wrap.classList.add("step-email-image-wrap");
  wrap.setAttribute("title", "Drag corner to resize image");
}

/** Outlook/Gmail-style signatures use wide tables; strip layout widths so img max-width can take effect. */
function stripCampaignSignatureTableLayout(el) {
  if (!el) return;
  el.querySelectorAll("table, tbody, thead, tfoot, tr, td, th, colgroup, col").forEach((node) => {
    node.removeAttribute("width");
    node.removeAttribute("height");
    const tag = node.tagName;
    if (tag === "TABLE") {
      node.style.maxWidth = "100%";
      node.style.width = "auto";
      node.style.tableLayout = "auto";
      node.style.removeProperty("width");
    } else if (tag === "TD" || tag === "TH") {
      node.style.maxWidth = "100%";
      node.style.removeProperty("width");
    } else if (tag === "COL" || tag === "COLGROUP") {
      node.style.removeProperty("width");
    }
  });
}

function clampSignatureBlockImages(el, maxPx) {
  const safeMax = Number.isFinite(Number(maxPx)) ? Math.max(48, Math.round(Number(maxPx))) : CAMPAIGN_SIGNATURE_IMAGE_MAX_PX;
  el.querySelectorAll("img").forEach((img) => {
    img.removeAttribute("width");
    img.removeAttribute("height");
    img.style.removeProperty("width");
    img.style.maxWidth = `${safeMax}px`;
    img.style.height = "auto";
    img.style.display = "block";
    img.style.marginBottom = "12px";
    img.style.boxSizing = "border-box";
    img.style.objectFit = "contain";
  });
}

function enforceCampaignSignatureImagesInEditor(editorEl) {
  if (!editorEl) return;
  const maxPx = CAMPAIGN_SIGNATURE_IMAGE_MAX_PX;
  editorEl.querySelectorAll(".campaign-email-signature-block").forEach((block) => {
    stripCampaignSignatureTableLayout(block);
    clampSignatureBlockImages(block, maxPx);
  });
  editorEl.querySelectorAll('img[alt="Signature image"]').forEach((img) => {
    if (img.closest(".step-email-image-wrap") || img.closest(".campaign-email-signature-block")) return;
    img.removeAttribute("width");
    img.removeAttribute("height");
    img.style.removeProperty("width");
    img.style.maxWidth = `${maxPx}px`;
    img.style.height = "auto";
    img.style.display = "block";
    img.style.boxSizing = "border-box";
    img.style.objectFit = "contain";
  });
}

/** Last-line normalization before save/API so signature graphics stay capped even when pasted. */
function finalizeCampaignEmailStepHtml(html) {
  const root = document.createElement("div");
  root.innerHTML = String(html || "");
  enforceCampaignSignatureImagesInEditor(root);
  return root.innerHTML;
}

function normalizeStepEditorImages(editorEl) {
  if (!editorEl) return;
  const imgs = [...editorEl.querySelectorAll("img")];
  for (const img of imgs) {
    if (img.closest(".campaign-email-signature-block")) continue;
    const parent = img.parentElement;
    if (parent && parent.classList.contains("step-email-image-wrap")) {
      ensureStepEmailImageWrap(parent);
      continue;
    }
    const wrap = document.createElement("span");
    ensureStepEmailImageWrap(wrap);
    img.replaceWith(wrap);
    wrap.appendChild(img);
  }
  enforceCampaignSignatureImagesInEditor(editorEl);
}

function bindStepEmailEditor(row) {
  const rich = row.querySelector(".step-body-rich");
  const wrap = row.querySelector(".step-email-editor-wrap");
  const fileInput = row.querySelector(".step-email-img-file");
  if (!rich || !wrap) return;
  normalizeStepEditorImages(rich);

  row.querySelectorAll(".step-email-cmd").forEach((btn) => {
    btn.addEventListener("mousedown", (e) => {
      e.preventDefault();
    });
    btn.addEventListener("click", () => {
      const cmd = btn.getAttribute("data-cmd");
      rich.focus();
      try {
        document.execCommand(cmd, false);
      } catch {
        /* ignore */
      }
    });
  });

  const fontSel = row.querySelector(".step-email-fontsize");
  if (fontSel) {
    fontSel.addEventListener("change", (e) => {
      const v = e.target.value;
      if (!v) return;
      rich.focus();
      try {
        document.execCommand("fontSize", false, v);
      } catch {
        /* ignore */
      }
      e.target.value = "";
    });
  }

  const colorInput = row.querySelector(".step-email-color");
  if (colorInput) {
    colorInput.addEventListener("input", () => {
      rich.focus();
      try {
        document.execCommand("foreColor", false, colorInput.value);
      } catch {
        /* ignore */
      }
    });
  }

  const imgBtn = row.querySelector(".step-email-img-btn");
  if (imgBtn && fileInput) {
    imgBtn.addEventListener("click", () => fileInput.click());
    fileInput.addEventListener("change", () => {
      const file = fileInput.files && fileInput.files[0];
      if (!file || !String(file.type || "").startsWith("image/")) return;
      const reader = new FileReader();
      reader.onload = () => {
        rich.focus();
        try {
          document.execCommand("insertImage", false, reader.result);
        } catch {
          /* ignore */
        }
        normalizeStepEditorImages(rich);
      };
      reader.readAsDataURL(file);
      fileInput.value = "";
    });
  }

  rich.addEventListener("input", () => {
    normalizeStepEditorImages(rich);
  });
  rich.addEventListener("blur", renderTimelinePreview);
}

function syncStepBodyEditors(row) {
  const ch = row.querySelector(".step-channel").value;
  const plain = row.querySelector(".step-body-plain");
  const wrap = row.querySelector(".step-email-editor-wrap");
  const rich = row.querySelector(".step-body-rich");
  const plainCompose = row.querySelector(".step-plain-compose");
  const emailComposeOuter = row.querySelector(".step-email-compose");
  if (!plain || !wrap || !rich) return;
  if (ch === "email") {
    if (emailComposeOuter) emailComposeOuter.hidden = false;
    wrap.hidden = false;
    plain.hidden = true;
    plain.disabled = true;
    rich.contentEditable = "true";
    if (plainCompose) plainCompose.hidden = true;
  } else if (ch === "call") {
    if (emailComposeOuter) emailComposeOuter.hidden = true;
    wrap.hidden = true;
    plain.hidden = true;
    plain.disabled = true;
    rich.contentEditable = "false";
    if (plainCompose) plainCompose.hidden = true;
  } else {
    if (emailComposeOuter) emailComposeOuter.hidden = true;
    wrap.hidden = true;
    plain.hidden = false;
    plain.disabled = false;
    rich.contentEditable = "false";
    if (plainCompose) plainCompose.hidden = false;
  }
}

function splitOffsetParts(totalHours) {
  const t = Number(totalHours);
  if (!Number.isFinite(t) || t < 0) return { days: 0, hours: 0, minutes: 0 };
  const days = Math.floor(t / 24);
  let rem = t - days * 24;
  let hours = Math.floor(rem);
  let minutes = Math.round((rem - hours) * 60);
  if (minutes >= 60) {
    hours += Math.floor(minutes / 60);
    minutes %= 60;
  }
  return { days, hours, minutes };
}

/** @deprecated use splitOffsetParts */
function splitOffsetHours(total) {
  return splitOffsetParts(total);
}

function offsetPartsToHours(days, hours, minutes) {
  const d = Math.max(0, Math.floor(Number(days) || 0));
  const h = Math.max(0, Number(hours) || 0);
  const m = Math.max(0, Math.min(59, Math.floor(Number(minutes) || 0)));
  return d * 24 + h + m / 60;
}

/** Human-readable offset from total hours (days, hours, minutes). */
function formatOffsetLabel(totalHours) {
  const { days, hours, minutes } = splitOffsetParts(totalHours);
  const parts = [];
  if (days) parts.push(`${days}d`);
  if (hours) parts.push(`${hours}h`);
  if (minutes || parts.length === 0) parts.push(`${minutes}m`);
  return parts.join(" ");
}

function updateCampaignSummary() {
  if (!campaignSummaryNameEl && !campaignSummaryStepsEl && !campaignSummaryDurationEl && !campaignSummaryChannelsEl) return;
  const name = String(document.getElementById("campaignDescriptionInput")?.value || "").trim();
  const rows = campaignStepsEl ? [...campaignStepsEl.querySelectorAll(".campaign-step-row")] : [];
  const counts = { email: 0, sms: 0, call: 0 };
  let maxOffset = 0;
  for (const row of rows) {
    const channel = String(row.querySelector(".step-channel")?.value || "sms").toLowerCase();
    if (Object.prototype.hasOwnProperty.call(counts, channel)) counts[channel] += 1;
    const days = Number(row.querySelector(".step-offset-days")?.value || 0);
    const hrs = Number(row.querySelector(".step-offset-hours")?.value || 0);
    const mins = Number(row.querySelector(".step-offset-minutes")?.value || 0);
    maxOffset = Math.max(maxOffset, offsetPartsToHours(days, hrs, mins));
  }
  const channelParts = [
    counts.email ? `${counts.email} Email` : "",
    counts.sms ? `${counts.sms} SMS` : "",
    counts.call ? `${counts.call} Call` : ""
  ].filter(Boolean);
  if (campaignSummaryNameEl) campaignSummaryNameEl.textContent = name || "Untitled campaign";
  if (campaignSummaryStepsEl) campaignSummaryStepsEl.textContent = String(rows.length);
  if (campaignSummaryDurationEl) campaignSummaryDurationEl.textContent = rows.length ? formatOffsetLabel(maxOffset) : "0 minutes";
  if (campaignSummaryChannelsEl) campaignSummaryChannelsEl.textContent = channelParts.length ? channelParts.join(" · ") : "No steps yet";
  if (campaignSummaryEnrolledEl) {
    const tag = String(campaignTagRulesEl?.querySelector(".tag-rule-name")?.value || "").trim();
    campaignSummaryEnrolledEl.textContent = tag ? `Tag: ${tag}` : "After save";
  }
}

/** Preview anchor: drip begins when the enroll tag is applied (shown as “now”). */
function getPreviewStartUnix() {
  return Math.floor(Date.now() / 1000);
}

let savedContactTags = [];

function collectExtraTagsFromForm() {
  return [...campaignTagRulesEl.querySelectorAll(".tag-rule-name")]
    .map((el) => String(el.value || "").trim())
    .filter(Boolean);
}

function syncTagsDatalist() {
  const dl = document.getElementById("crmSavedTagsList");
  if (!dl) return;
  const merged = new Set([...savedContactTags, ...collectExtraTagsFromForm()]);
  const sorted = [...merged].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));
  dl.innerHTML = sorted.map((t) => `<option value="${escapeHtml(t)}"></option>`).join("");
}

async function loadSavedTags() {
  const { response, data } = await fetchApiJson("/api/contacts/tags");
  if (response.ok && data && Array.isArray(data.tags)) {
    savedContactTags = data.tags;
  } else {
    savedContactTags = [];
  }
  syncTagsDatalist();
}

function syncTagRuleRowUi(row) {
  if (!row) return;
  const fnEl = row.querySelector(".tag-rule-function");
  const nameInput = row.querySelector(".tag-rule-name");
  if (!fnEl || !nameInput) return;
  const noTag = String(fnEl.value || "enroll").trim().toLowerCase() === "none";
  nameInput.disabled = noTag;
  if (noTag) {
    nameInput.value = "";
    nameInput.placeholder = "Not used when saving without tag";
  } else {
    nameInput.placeholder = "e.g. new-lead, aca-prospect, medicare-2024";
    nameInput.title = "Must match the tag exactly when applied to a contact.";
  }
}

function createTagRuleRow(initial = {}) {
  const row = document.createElement("div");
  row.className = "campaign-tag-rule-row";
  const fn = String(initial.function || "enroll").trim().toLowerCase();
  const useEnroll = fn !== "none";
  row.innerHTML = `
    <input type="text" class="tag-rule-name" list="crmSavedTagsList" autocomplete="off" spellcheck="false"
      placeholder="e.g. new-lead, aca-prospect, medicare-2024"
      title="Contacts tagged with this exact label will be enrolled automatically."
      value="${escapeHtml(String(initial.tag || ""))}" />
    <select class="tag-rule-function" aria-label="Enrollment mode">
      <option value="enroll"${useEnroll ? " selected" : ""}>Enroll contacts with this tag</option>
      <option value="none"${!useEnroll ? " selected" : ""}>Save this campaign without tag</option>
    </select>
  `;
  const nameInput = row.querySelector(".tag-rule-name");
  const fnSelect = row.querySelector(".tag-rule-function");
  nameInput.addEventListener("input", () => syncTagsDatalist());
  fnSelect.addEventListener("change", () => {
    syncTagRuleRowUi(row);
    renderTimelinePreview();
  });
  campaignTagRulesEl.appendChild(row);
  syncTagRuleRowUi(row);
  syncCampaignRowRemoveButtons();
  syncTagsDatalist();
}

function collectTagRules() {
  const rows = [...campaignTagRulesEl.querySelectorAll(".campaign-tag-rule-row")];
  if (!rows.length) return [];
  const first = rows[0];
  const fn = String(first.querySelector(".tag-rule-function")?.value || "enroll")
    .trim()
    .toLowerCase();
  if (fn === "none") return [];
  const tag = String(first.querySelector(".tag-rule-name")?.value || "").trim();
  if (!tag) {
    throw new Error('Enter an enrollment tag, or choose "Save this campaign without tag".');
  }
  return [{ tag, function: "enroll" }];
}

function clearTagRules() {
  campaignTagRulesEl.innerHTML = "";
  syncTagsDatalist();
}

function createStepRow(initial = {}) {
  const row = document.createElement("div");
  row.className = "campaign-step-row";
  const { days, hours, minutes } = splitOffsetParts(initial.offset_hours ?? 0);
  const initChannel = initial.channel || "sms";
  row.innerHTML = `
    <div class="campaign-step-number">
      <span class="campaign-step-grip" aria-hidden="true">::</span>
      <span class="campaign-step-index">Step</span>
      <span class="campaign-step-reorder" aria-label="Reorder step">
        <button type="button" class="step-move-up" title="Move step up">Up</button>
        <button type="button" class="step-move-down" title="Move step down">Down</button>
      </span>
    </div>
    <div class="campaign-step-control-strip">
      <div class="campaign-step-offset-group">
        <label><span>Days after start</span><input type="number" min="0" step="1" class="step-offset-days" value="${days}" /></label>
        <label><span>Hours after start</span><input type="number" min="0" step="1" class="step-offset-hours" value="${hours}" /></label>
        <label><span>Minutes after start</span><input type="number" min="0" max="59" step="1" class="step-offset-minutes" value="${minutes}" /></label>
      </div>
      <div class="campaign-step-channel-col">
        <label class="step-channel-label">Step type</label>
        <select class="step-channel" title="Message channel">
          <option value="sms">SMS</option>
          <option value="email">Email</option>
          <option value="call">Call</option>
        </select>
        <div class="step-twilio-from-wrap" hidden>
          <label class="step-twilio-from-label">Send from</label>
          <select class="step-twilio-from" aria-label="Twilio number for this step"></select>
        </div>
        <div class="step-email-from-wrap" hidden>
          <label class="step-email-from-label">Send from</label>
          <select class="step-email-from" aria-label="Sender email address for this email step">
            <option value="">Use campaign default</option>
          </select>
          <p class="step-email-from-hint-text" style="margin: 4px 0 0">
            Leave on <em>Use campaign default</em> to inherit the campaign <strong>From email</strong>. Add more
            addresses on the <a href="/settings.html?section=email-senders">Settings</a> page.
          </p>
        </div>
      </div>
    </div>
    <div class="step-email-meta" hidden>
      <div class="step-email-subject-field">
        <span class="step-email-field-label">Subject line</span>
        <input
          type="text"
          class="step-subject"
          placeholder="What recipients see in their inbox"
          value="${escapeHtml(String(initial.subject || ""))}"
        />
      </div>
      <div class="step-email-template-field">
        <span class="step-email-field-label">Template</span>
        <select class="step-email-template">
          <option value="">Load from saved template…</option>
        </select>
      </div>
    </div>
    <input type="hidden" class="step-twiml" value="${escapeHtml(String(initial.call_twiml_url || ""))}" />
    <div class="step-body-stack">
      <div class="step-plain-compose">
        <span class="step-body-plain-label">Message</span>
        <textarea class="step-body-plain" placeholder="Write the SMS your contact will receive. It is sent exactly as written." rows="5"></textarea>
        <div class="step-sms-ending-wrap">
          <span class="step-body-plain-label">Added under this text</span>
          <textarea class="step-sms-ending" data-sms-ending rows="2" maxlength="300">Reply STOP to opt out.</textarea>
          <p class="step-email-compose-hint" style="margin:4px 0 0">Saved for every text. Phone numbers in the message are not changed. Clear this box to send only the message.</p>
        </div>
        <div class="step-sms-photo">
          <span class="step-body-plain-label">Photo</span>
          <input type="file" class="step-sms-photo-file" accept="image/jpeg,image/jpg,image/pjpeg,image/png,image/gif,image/webp,.jpg,.jpeg,.JPG,.JPEG,.png,.gif,.webp" />
          <div class="step-sms-photo-preview" style="display:none;align-items:center;gap:10px;margin-top:6px;">
            <img alt="" style="width:72px;height:72px;object-fit:cover;border-radius:8px;border:1px solid #cbd5e1;background:#f8fafc;" />
            <button type="button" class="step-sms-photo-remove">Remove photo</button>
          </div>
          <p class="step-email-compose-hint" style="margin:4px 0 0">Optional. The picture is sent with the text the same way as a single text. JPG or PNG, under 5 MB.</p>
        </div>
      </div>
      <div class="step-email-compose" hidden>
        <span class="step-email-compose-label">Email body</span>
        <p class="step-email-compose-hint">
          Format your message below. Images and basic styling are supported. Merge fields like <code>{{first_name}}</code> are
          filled when the email is sent.
        </p>
        <div class="step-email-editor-wrap">
          <div class="step-email-toolbar" role="toolbar" aria-label="Email formatting">
            <button type="button" class="step-email-cmd" data-cmd="bold" title="Bold"><b>B</b></button>
            <button type="button" class="step-email-cmd" data-cmd="italic" title="Italic"><i>I</i></button>
            <button type="button" class="step-email-cmd" data-cmd="underline" title="Underline"><u>U</u></button>
            <select class="step-email-fontsize" aria-label="Text size" title="Size">
              <option value="">Size</option>
              <option value="1">Small</option>
              <option value="3">Normal</option>
              <option value="5">Large</option>
              <option value="7">Extra large</option>
            </select>
            <label class="step-email-color-label">Color <input type="color" class="step-email-color" value="#111827" title="Text color" /></label>
            <button type="button" class="step-email-img-btn">Image</button>
            <input type="file" class="step-email-img-file" accept="image/*" tabindex="-1" />
          </div>
          <div class="step-body-rich" contenteditable="true"></div>
        </div>
      </div>
    </div>
    <button type="button" class="step-remove">Delete step</button>
  `;
  const channelEl = row.querySelector(".step-channel");
  channelEl.value = initChannel;
  channelEl.dataset.prevChannel = initChannel;
  const subjectEl = row.querySelector(".step-subject");
  const templateEl = row.querySelector(".step-email-template");
  const plainEl = row.querySelector(".step-body-plain");
  const richEl = row.querySelector(".step-body-rich");
  populateStepEmailTemplateSelect(templateEl);

  row.dataset.smsMediaId = String(initial.sms_media_id || initial.smsMediaId || "").trim();
  row.dataset.removeSmsPhoto = "0";

  if (initChannel === "email") {
    const bodyRaw = String(initial.body || "").trim();
    richEl.innerHTML = bodyRaw
      ? sanitizeCampaignEmailHtml(stripCampaignSignatureBlocks(bodyRaw))
      : composeEmailStepBodyWithOptionalSignature("");
    normalizeStepEditorImages(richEl);
  } else {
    plainEl.value = String(initial.body || "");
  }

  const twilioWrap = row.querySelector(".step-twilio-from-wrap");
  const twilioSel = row.querySelector(".step-twilio-from");
  const twilioLabelEl = row.querySelector(".step-twilio-from-label");
  const bodyStackEl = row.querySelector(".step-body-stack");
  const emailMetaEl = row.querySelector(".step-email-meta");
  const emailFromWrap = row.querySelector(".step-email-from-wrap");
  const emailFromSel = row.querySelector(".step-email-from");

  const channelColEl = row.querySelector(".campaign-step-channel-col");

  const syncFields = () => {
    const ch = channelEl.value;
    row.classList.toggle("campaign-step-row--sms", ch === "sms");
    row.classList.toggle("campaign-step-row--email", ch === "email");
    row.classList.toggle("campaign-step-row--call", ch === "call");
    if (channelColEl) {
      channelColEl.classList.toggle("campaign-step-channel-col--sms", ch === "sms");
      channelColEl.classList.toggle("campaign-step-channel-col--call", ch === "call");
      channelColEl.classList.toggle("campaign-step-channel-col--email", ch === "email");
    }

    const photoWrap = row.querySelector(".step-sms-photo");
    if (photoWrap) photoWrap.hidden = ch !== "sms";
    const endingWrap = row.querySelector(".step-sms-ending-wrap");
    if (endingWrap) endingWrap.hidden = ch !== "sms";
    if (bodyStackEl) bodyStackEl.hidden = ch === "call";
    if (emailMetaEl) emailMetaEl.hidden = ch !== "email";
    if (emailFromWrap && emailFromSel) {
      const showEmailFrom = ch === "email";
      emailFromWrap.hidden = !showEmailFrom;
      emailFromSel.disabled = !showEmailFrom;
    }

    subjectEl.disabled = ch !== "email";
    if (templateEl) templateEl.disabled = ch !== "email";
    plainEl.disabled = ch === "call";
    if (twilioWrap && twilioSel) {
      const showTwilioFrom = ch === "sms" || ch === "call";
      twilioWrap.hidden = !showTwilioFrom;
      twilioSel.disabled = !showTwilioFrom;
      if (twilioLabelEl) {
        twilioLabelEl.textContent = ch === "call" ? "Call from" : "Send from";
      }
      twilioSel.setAttribute(
        "aria-label",
        ch === "call" ? "Twilio caller ID for this call step" : "Twilio number for this SMS step"
      );
    }
    syncStepBodyEditors(row);
  };

  channelEl.addEventListener("change", () => {
    const prev = channelEl.dataset.prevChannel || "sms";
    const next = channelEl.value;
    const rich = row.querySelector(".step-body-rich");
    const plain = row.querySelector(".step-body-plain");
    if (next === "email") {
      if (campaignRichEmailBodyIsEmpty(rich)) {
        let mainPlain = "";
        if ((prev === "sms" || prev === "call") && String(plain.value || "").trim()) {
          mainPlain = plain.value;
        }
        rich.innerHTML = composeEmailStepBodyWithOptionalSignature(mainPlain);
        normalizeStepEditorImages(rich);
      }
    } else if (next === "sms") {
      plain.value = "";
    } else if (next === "call") {
      plain.value = "";
    }
    channelEl.dataset.prevChannel = next;
    syncFields();
    renderTimelinePreview();
  });
  const photoInput = row.querySelector(".step-sms-photo-file");
  const photoRemove = row.querySelector(".step-sms-photo-remove");
  const showSmsPhoto = (src) => {
    const box = row.querySelector(".step-sms-photo-preview");
    const img = box && box.querySelector("img");
    if (!box || !img) return;
    if (!src) {
      box.style.display = "none";
      img.removeAttribute("src");
      return;
    }
    img.src = src;
    box.style.display = "flex";
  };
  if (row.dataset.smsMediaId) showSmsPhoto(`/api/drip/sms-photo/${row.dataset.smsMediaId}`);
  if (photoInput) {
    photoInput.addEventListener("change", () => {
      const file = photoInput.files && photoInput.files[0];
      row.dataset.removeSmsPhoto = "0";
      if (!file) {
        showSmsPhoto(row.dataset.smsMediaId ? `/api/drip/sms-photo/${row.dataset.smsMediaId}` : "");
        return;
      }
      if (file.size > 5 * 1024 * 1024) {
        photoInput.value = "";
        showMessage("That photo is too large for a text. Use a picture under 5 MB.", true);
        showSmsPhoto(row.dataset.smsMediaId ? `/api/drip/sms-photo/${row.dataset.smsMediaId}` : "");
        return;
      }
      showSmsPhoto(URL.createObjectURL(file));
    });
  }
  if (photoRemove) {
    photoRemove.addEventListener("click", () => {
      if (photoInput) photoInput.value = "";
      row.dataset.removeSmsPhoto = "1";
      showSmsPhoto("");
    });
  }

  if (templateEl) {
    templateEl.addEventListener("change", () => {
      const templateId = Number(templateEl.value);
      if (!Number.isInteger(templateId) || templateId < 1) return;
      const picked = emailTemplateRowsCache.find((t) => Number(t.id) === templateId);
      if (!picked) return;
      subjectEl.value = String(picked.subject || "");
      const htmlBody = String(picked.body || "");
      const cleanedBody = htmlBody ? sanitizeCampaignEmailHtml(htmlBody) : "<p><br></p>";
      richEl.innerHTML = stripCampaignSignatureBlocks(cleanedBody);
      normalizeStepEditorImages(richEl);
      plainEl.value = htmlBody;
    });
  }

  syncFields();

  if (emailFromSel) {
    const initEmailFrom = String(initial.email_from || initial.emailFrom || "").trim();
    if (initEmailFrom) emailFromSel.dataset.initEmailFrom = initEmailFrom;
    applyEmailFromOptionsToStepSelect(emailFromSel, emailFromAddressesCache);
    emailFromSel.addEventListener("change", () => renderTimelinePreview());
  }

  if (twilioSel) {
    twilioSel.addEventListener("change", () => renderTimelinePreview());
    const hydrateStepTwilio = async () => {
      if (typeof window.applyTwilioFromToStepSelect !== "function") return;
      let data = { primary: null, secondary: null, third: null, custom: [] };
      try {
        if (typeof window.loadTwilioFromData === "function") {
          data = await window.loadTwilioFromData();
        } else {
          const r = await fetch("/api/twilio/from-numbers");
          if (r.ok) data = await r.json();
        }
      } catch {
        /* ignore */
      }
      window.applyTwilioFromToStepSelect(twilioSel, data);
      const initTwilio =
        initial.twilio_from != null
          ? String(initial.twilio_from).trim()
          : initial.twilioFrom != null
            ? String(initial.twilioFrom).trim()
            : "";
      if (initTwilio && [...twilioSel.options].some((o) => o.value === initTwilio)) twilioSel.value = initTwilio;
      else twilioSel.value = "";
      syncFields();
      renderTimelinePreview();
    };
    hydrateStepTwilio();
  }

  bindStepEmailEditor(row);

  row.querySelector(".step-move-up")?.addEventListener("click", () => {
    campaignUserEditedSinceLoad = true;
    moveCampaignStep(row, -1);
  });
  row.querySelector(".step-move-down")?.addEventListener("click", () => {
    campaignUserEditedSinceLoad = true;
    moveCampaignStep(row, 1);
  });
  row.querySelector(".step-remove").addEventListener("click", () => {
    campaignUserEditedSinceLoad = true;
    row.remove();
    updateCampaignStepNumbers();
    syncImmediateStartCheckboxFromFirstStep();
    renderTimelinePreview();
  });
  campaignStepsEl.appendChild(row);
  if (window.cadenceSmsEnding) window.cadenceSmsEnding.apply();
  updateCampaignStepNumbers();
  syncCampaignRowRemoveButtons();
  renderTimelinePreview();
}

function getCampaignFormIdInput() {
  return document.getElementById("campaignFormCampaignId");
}

/** Active campaign id when editing, or empty for create. */
function setCampaignFormId(raw) {
  const el = getCampaignFormIdInput();
  if (!el) return;
  const v = raw != null && raw !== "" ? String(raw).trim() : "";
  el.value = v;
}

/** Parsed id for PUT, or null when creating a new campaign. */
function getCampaignEditId() {
  const el = getCampaignFormIdInput();
  const n = Number(el && el.value);
  return Number.isFinite(n) && n >= 1 ? Math.floor(n) : null;
}

function moveCampaignStep(row, direction) {
  if (!row || !campaignStepsEl) return;
  if (direction < 0 && row.previousElementSibling) {
    campaignStepsEl.insertBefore(row, row.previousElementSibling);
  } else if (direction > 0 && row.nextElementSibling) {
    campaignStepsEl.insertBefore(row.nextElementSibling, row);
  }
  updateCampaignStepNumbers();
  syncImmediateStartCheckboxFromFirstStep();
  renderTimelinePreview();
}

function syncCampaignRowRemoveButtons() {
  campaignStepsEl.querySelectorAll(".step-remove").forEach((btn) => {
    btn.style.display = "inline-flex";
  });
  updateCampaignStepNumbers();
}

function updateCampaignStepNumbers() {
  const rows = [...campaignStepsEl.querySelectorAll(".campaign-step-row")];
  rows.forEach((row, index) => {
    const label = row.querySelector(".campaign-step-number");
    const indexLabel = row.querySelector(".campaign-step-index");
    if (indexLabel) indexLabel.textContent = `Step ${index + 1}`;
    else if (label) label.textContent = `Step ${index + 1}`;
    const moveUp = row.querySelector(".step-move-up");
    const moveDown = row.querySelector(".step-move-down");
    if (moveUp) moveUp.disabled = index === 0;
    if (moveDown) moveDown.disabled = index === rows.length - 1;
  });
  updateCampaignSummary();
}

function setCampaignTwilioFromSelect(raw) {
  const el = campaignForm.querySelector('[name="twilioFrom"]');
  if (!el) return;
  const want = String(raw || "secondary").toLowerCase().trim();
  if (el.querySelector(`option[value="${want}"]`)) el.value = want;
  else el.value = "secondary";
}

function setCampaignTwilioDefaultNumber() {
  const el = campaignForm.querySelector('[name="twilioFrom"]');
  if (!el) return;
  const wantDigits = String(DEFAULT_CAMPAIGN_TWILIO_NUMBER).replace(/\D/g, "");
  if (!wantDigits) return;
  const options = [...el.options];
  const matched = options.find((opt) => String(opt.textContent || "").replace(/\D/g, "").includes(wantDigits));
  if (matched && !matched.disabled && !matched.hidden) {
    el.value = matched.value;
    return;
  }
  setCampaignTwilioFromSelect("secondary");
}

function buildEmailFromOptionLabel(entry) {
  const email = String(entry?.email || "").trim();
  const label = String(entry?.label || "").trim();
  if (!email) return "";
  return label ? `${label} — ${email}` : email;
}

function getDefaultCampaignEmailFromLabel() {
  const first = emailFromAddressesCache.find((entry) => String(entry?.email || "").trim());
  if (first?.email) return `${first.email} (default)`;
  return "Set up email in Settings";
}

function formatCampaignEnrollmentStats(campaign) {
  const stats = campaign?.enrollment_stats;
  if (!stats) return "";
  const active = Number(stats.active || 0);
  const completed = Number(stats.completed || 0);
  if (!active && !completed) {
    return '<span class="campaign-enrollment-stats">No contacts enrolled yet</span>';
  }
  return `<span class="campaign-enrollment-stats">${active} active · ${completed} completed</span>`;
}

function campaignBuilderHasContent() {
  const name = String(document.getElementById("campaignDescriptionInput")?.value || "").trim();
  const steps = campaignStepsEl ? campaignStepsEl.querySelectorAll(".campaign-step-row").length : 0;
  const tag = String(campaignTagRulesEl?.querySelector(".tag-rule-name")?.value || "").trim();
  return Boolean(name || steps > 1 || tag);
}

function loadStarterCampaign(starterId) {
  const starter = CAMPAIGN_STARTERS[String(starterId || "").trim()];
  if (!starter) return;
  if (campaignBuilderHasContent()) {
    const ok = window.confirm("Load this starter? Your current campaign draft will be replaced.");
    if (!ok) return;
  }
  if (getCampaignEditId() != null) setEditMode(null);
  const nameInput = document.getElementById("campaignDescriptionInput");
  if (nameInput) nameInput.value = starter.name;
  campaignStepsEl.innerHTML = "";
  clearTagRules();
  createTagRuleRow({ function: "enroll", tag: starter.tag });
  for (const step of starter.steps) createStepRow(step);
  if (campaignStartFirstStepImmediatelyEl) campaignStartFirstStepImmediatelyEl.checked = true;
  applyImmediateStartToFirstStep();
  syncImmediateStartCheckboxFromFirstStep();
  renderTimelinePreview();
  document.getElementById("createCampaignSection")?.scrollIntoView({ behavior: "smooth", block: "start" });
  showMessage(`Loaded starter: ${starter.name}. Review steps, then save.`, false);
  if (window.CrmUnsavedGuard) window.CrmUnsavedGuard.markDirty();
}

function applyEmailFromOptionsToStepSelect(selectEl, addresses) {
  if (!selectEl) return;
  const list = Array.isArray(addresses) ? addresses : [];
  const prev = String(selectEl.value || "");
  const initial = String(selectEl.dataset?.initEmailFrom || "");
  selectEl.innerHTML = "";
  const def = document.createElement("option");
  def.value = "";
  def.textContent = "Use campaign default";
  selectEl.appendChild(def);
  for (const entry of list) {
    const email = String(entry?.email || "").trim();
    if (!email) continue;
    const o = document.createElement("option");
    o.value = email;
    o.textContent = buildEmailFromOptionLabel(entry);
    selectEl.appendChild(o);
  }
  const desired = prev || initial;
  if (desired) {
    const matched = [...selectEl.options].find((o) => o.value.toLowerCase() === desired.toLowerCase());
    selectEl.value = matched ? matched.value : "";
  } else {
    selectEl.value = "";
  }
}

function syncStepEmailFromSelectsFromCache() {
  document.querySelectorAll("select.step-email-from").forEach((sel) => {
    applyEmailFromOptionsToStepSelect(sel, emailFromAddressesCache);
  });
}

async function populateCampaignEmailFromOptions() {
  const sel = document.getElementById("campaignEmailFrom");
  try {
    const { response, data } = await fetchApiJson("/api/email/options");
    const opts = response.ok && Array.isArray(data.fromOptions) ? data.fromOptions : [];
    const detailed =
      response.ok && Array.isArray(data.fromAddresses) && data.fromAddresses.length
        ? data.fromAddresses
        : opts.map((addr) => ({ email: addr, label: "", source: "", id: null }));
    emailFromAddressesCache = detailed
      .map((entry) => ({
        email: String(entry?.email || "").trim(),
        label: String(entry?.label || "").trim(),
        source: String(entry?.source || ""),
        id: entry?.id == null ? null : Number(entry.id)
      }))
      .filter((entry) => entry.email);
    if (sel) {
      const prev = sel.value;
      sel.innerHTML = "";
      const def = document.createElement("option");
      def.value = "";
      def.textContent = getDefaultCampaignEmailFromLabel();
      sel.appendChild(def);
      for (const entry of emailFromAddressesCache) {
        const o = document.createElement("option");
        o.value = entry.email;
        o.textContent = buildEmailFromOptionLabel(entry);
        sel.appendChild(o);
      }
      const preferred = String(prev || "").trim();
      setCampaignEmailFromSelect(preferred);
    }
    syncStepEmailFromSelectsFromCache();
  } catch {
    emailFromAddressesCache = [];
    if (sel) sel.innerHTML = `<option value="">${escapeHtml(getDefaultCampaignEmailFromLabel())}</option>`;
    syncStepEmailFromSelectsFromCache();
  }
}

function setCampaignEmailFromSelect(raw) {
  const el = document.getElementById("campaignEmailFrom");
  if (!el) return;
  const want = String(raw || "").trim();
  if (!want) {
    el.value = "";
    return;
  }
  const opt = [...el.options].find((o) => o.value && o.value.toLowerCase() === want.toLowerCase());
  el.value = opt ? opt.value : "";
}

function getFirstCampaignStepRow() {
  return campaignStepsEl ? campaignStepsEl.querySelector(".campaign-step-row") : null;
}

function applyImmediateStartToFirstStep() {
  const first = getFirstCampaignStepRow();
  if (!first) return;
  const d = first.querySelector(".step-offset-days");
  const h = first.querySelector(".step-offset-hours");
  const m = first.querySelector(".step-offset-minutes");
  if (d) d.value = 0;
  if (h) h.value = 0;
  if (m) m.value = 0;
}

function syncImmediateStartCheckboxFromFirstStep() {
  if (!campaignStartFirstStepImmediatelyEl) return;
  const first = getFirstCampaignStepRow();
  if (!first) {
    campaignStartFirstStepImmediatelyEl.checked = true;
    return;
  }
  const days = Number(first.querySelector(".step-offset-days")?.value || 0);
  const hours = Number(first.querySelector(".step-offset-hours")?.value || 0);
  const minutes = Number(first.querySelector(".step-offset-minutes")?.value || 0);
  const total = offsetPartsToHours(days, hours, minutes);
  campaignStartFirstStepImmediatelyEl.checked = total === 0;
}

async function attachPendingSmsPhotos() {
  const rows = [...campaignStepsEl.querySelectorAll(".campaign-step-row")];
  for (const row of rows) {
    const channel = String(row.querySelector(".step-channel")?.value || "").toLowerCase();
    if (channel !== "sms") continue;
    if (row.dataset.removeSmsPhoto === "1") {
      row.dataset.smsMediaId = "";
      row.dataset.removeSmsPhoto = "0";
      continue;
    }
    let file = row.querySelector(".step-sms-photo-file")?.files?.[0];
    if (!file) continue;
    if (window.prepareSmsPhotoFile) file = await window.prepareSmsPhotoFile(file);
    if (file.size > 5 * 1024 * 1024) {
      throw new Error("That photo is too large for a text. Use a picture under 5 MB.");
    }
    const body = new FormData();
    body.append("photo", file);
    const { response, data } = await fetchApiJson("/api/drip/sms-photo", { method: "POST", body });
    if (!response.ok || !data?.id) throw new Error(data?.error || "Could not add that photo.");
    row.dataset.smsMediaId = String(data.id);
    row.dataset.removeSmsPhoto = "0";
  }
}

function collectSteps() {
  const rows = [...campaignStepsEl.querySelectorAll(".campaign-step-row")];
  if (!rows.length) throw new Error("Add at least one step.");
  return rows.map((row) => {
    const days = Number(row.querySelector(".step-offset-days").value || 0);
    const hrs = Number(row.querySelector(".step-offset-hours").value || 0);
    const mins = Number(row.querySelector(".step-offset-minutes").value || 0);
    const offset_hours = offsetPartsToHours(days, hrs, mins);
    const ch = row.querySelector(".step-channel").value;
    const twilioStepEl = row.querySelector(".step-twilio-from");
    const twilio_from =
      (ch === "sms" || ch === "call") && twilioStepEl && !twilioStepEl.disabled
        ? String(twilioStepEl.value || "").trim()
        : "";
    const emailFromStepEl = row.querySelector(".step-email-from");
    const email_from =
      ch === "email" && emailFromStepEl && !emailFromStepEl.disabled
        ? String(emailFromStepEl.value || "").trim()
        : "";
    return {
      offset_hours,
      channel: ch,
      subject: row.querySelector(".step-subject").value,
      call_twiml_url: String(row.querySelector(".step-twiml")?.value ?? "").trim(),
      body: getStepBodyFromRow(row),
      twilio_from,
      twilioFrom: twilio_from,
      email_from,
      emailFrom: email_from,
      sms_media_id: ch === "sms" ? String(row.dataset.smsMediaId || "").trim() : ""
    };
  });
}

function setEditMode(campaign) {
  const idStr = campaign != null && campaign.id != null ? String(campaign.id).trim() : "";
  setCampaignFormId(idStr);
  const submitBtn = campaignForm.querySelector('button[type="submit"]');
  if (submitBtn) submitBtn.textContent = idStr ? "Update Campaign" : "Save Campaign";
  if (cancelEditBtn) cancelEditBtn.style.display = idStr ? "inline-block" : "none";
  syncCampaignRowRemoveButtons();
}

/** Current line key for API (primary | secondary | third) — read from the select, not FormData (avoids omitted/hidden-option quirks). */
function getCampaignTwilioFromSubmitValue() {
  const sel = document.getElementById("campaignTwilioFrom");
  let v = String((sel && sel.value) || "").trim().toLowerCase();
  if (!["primary", "secondary", "third"].includes(v)) v = "secondary";
  return v;
}

/** E.164 (or label text) for the campaign Twilio line chosen in the form — same line used for SMS and calls. */
function getCampaignTwilioFromDisplay() {
  const sel = document.getElementById("campaignTwilioFrom") || campaignForm.querySelector('[name="twilioFrom"]');
  if (!sel) return "—";
  const opt = sel.selectedOptions && sel.selectedOptions[0];
  let label = opt ? String(opt.textContent || "").replace(/\s+/g, " ").trim() : "";
  if (label && label !== "—") return label;
  const v = String(sel.value || "secondary").toLowerCase();
  if (["primary", "secondary", "third"].includes(v)) return `${v} line`;
  return label || "—";
}

function getTwilioDisplayForLine(lineKey) {
  const key = String(lineKey || "secondary").toLowerCase().trim();
  const sel = document.getElementById("campaignTwilioFrom") || campaignForm.querySelector('[name="twilioFrom"]');
  if (sel) {
    const opt = [...sel.options].find((o) => o.value === key);
    if (opt) {
      const label = String(opt.textContent || "").replace(/\s+/g, " ").trim();
      if (label && label !== "—") return label;
    }
  }
  if (["primary", "secondary", "third"].includes(key)) return `${key} line`;
  return "—";
}

function getTwilioDisplayFromSelect(sel) {
  if (!sel) return "—";
  const opt = sel.selectedOptions && sel.selectedOptions[0];
  const label = opt ? String(opt.textContent || "").replace(/\s+/g, " ").trim() : "";
  return label && label !== "—" ? label : "—";
}

/** Prefer step Twilio override (SMS or call); fallback to campaign-level display string. */
function resolveStepSmsTwilioDisplay(step, campaignFallback) {
  const ch = String(step.channel || "").toLowerCase();
  if (ch !== "sms" && ch !== "call") return campaignFallback;
  if (step.smsFromLabel && String(step.smsFromLabel).trim()) return step.smsFromLabel;
  const raw = String(step.twilio_from || step.twilioFrom || "").trim();
  if (raw) return getTwilioDisplayForLine(raw);
  return campaignFallback;
}

function describeStepFunction(channel) {
  const ch = String(channel || "").toLowerCase();
  if (ch === "sms") {
    return "SMS — sends a text, with an optional photo, to the contact. You can pick which Twilio number sends this step, or use the campaign default.";
  }
  if (ch === "email") {
    return "Email — HTML message with the subject above; sender comes from the campaign From email. Merge fields like {{first_name}} work when sent.";
  }
  if (ch === "call") {
    return "Call — connects to the contact’s phone. You can pick which Twilio number is used as the caller ID for this step, or use the campaign default.";
  }
  return "Unknown channel.";
}

function renderTimelinePreview() {
  if (!timelinePreviewEl) return;
  updateCampaignSummary();
  const startAt = getPreviewStartUnix();
  const campaignTwilioDisp = getCampaignTwilioFromDisplay();
  const steps = [...campaignStepsEl.querySelectorAll(".campaign-step-row")].map((row, idx) => {
    const days = Number(row.querySelector(".step-offset-days").value || 0);
    const hrs = Number(row.querySelector(".step-offset-hours").value || 0);
    const mins = Number(row.querySelector(".step-offset-minutes").value || 0);
    const offset = offsetPartsToHours(days, hrs, mins);
    const channel = row.querySelector(".step-channel").value;
    const subject = String(row.querySelector(".step-subject").value || "").trim();
    const twiml = String(row.querySelector(".step-twiml")?.value ?? "").trim();
    const body = readStepBodyLive(row);
    const twilioStepEl = row.querySelector(".step-twilio-from");
    const stepTwilioVal =
      (channel === "sms" || channel === "call") && twilioStepEl && !twilioStepEl.disabled
        ? String(twilioStepEl.value || "").trim()
        : "";
    const smsFromLabel =
      channel === "sms" || channel === "call"
        ? stepTwilioVal
          ? getTwilioDisplayFromSelect(twilioStepEl)
          : campaignTwilioDisp
        : "";
    const twilio_from = stepTwilioVal;
    return { idx, offset, channel, subject, twiml, body, twilio_from, smsFromLabel };
  });
  if (!steps.length) {
    timelinePreviewEl.innerHTML = '<div class="contact-history-empty">Add a step to preview schedule.</div>';
    renderJourneyChart([], NaN);
    return;
  }
  const sorted = [...steps].sort((a, b) => a.offset - b.offset);
  const anchorLabel = "from tag / enrollment";
  const twilioFrom = getCampaignTwilioFromDisplay();
  timelinePreviewEl.innerHTML = sorted
    .map((s) => {
      const channelKey = String(s.channel || "").toLowerCase();
      const previewKind = ["sms", "email", "call"].includes(channelKey) ? channelKey : "unknown";
      const sendAt = startAt + Math.round(Number(s.offset || 0) * 3600);
      const smsLine =
        channelKey === "sms" || channelKey === "call" ? resolveStepSmsTwilioDisplay(s, twilioFrom) : twilioFrom;
      const detail =
        s.channel === "email"
          ? `Email: ${s.subject || "(no subject)"}`
          : s.channel === "call"
            ? `Call from ${escapeHtml(smsLine)}`
            : `SMS from ${escapeHtml(smsLine)}`;
      const offLabel = formatOffsetLabel(s.offset);
      return `<div class="campaign-timeline-row campaign-timeline-row--${previewKind}">Step ${s.idx + 1} | ${offLabel} (${anchorLabel}) | ${detail} | ${formatUnix(sendAt)}</div>`;
    })
    .join("");
  renderJourneyChart(sorted, startAt, twilioFrom);
}

function showSavedCampaignPreview(campaignId) {
  const id = Number(campaignId);
  if (!Number.isFinite(id) || id < 1) return;
  const campaign = cachedCampaigns.find((c) => Number(c.id) === id);
  if (!campaign) return;
  const startAt = getPreviewStartUnix();
  const twilioFrom = getTwilioDisplayForLine(campaign.twilio_from);
  const steps = (Array.isArray(campaign.steps) ? campaign.steps : [])
    .map((s, idx) => {
      const channel = String(s.channel || "sms");
      const channelLower = channel.toLowerCase();
      const twilioRaw = String(s.twilio_from || "").trim();
      const smsFromLabel =
        channelLower === "sms" || channelLower === "call"
          ? twilioRaw
            ? getTwilioDisplayForLine(twilioRaw)
            : twilioFrom
          : "";
      return {
        idx,
        offset: Number(s.offset_hours || 0),
        channel,
        subject: String(s.subject || ""),
        twiml: String(s.call_twiml_url || ""),
        body: String(s.body || ""),
        twilio_from: twilioRaw,
        smsFromLabel
      };
    })
    .sort((a, b) => a.offset - b.offset);

  if (!steps.length) {
    timelinePreviewEl.innerHTML = '<div class="contact-history-empty">Selected campaign has no steps.</div>';
    renderJourneyChart([], NaN, twilioFrom);
    return;
  }

  const anchorLabel = "from tag / enrollment";
  timelinePreviewEl.innerHTML = steps
    .map((s) => {
      const channelKey = String(s.channel || "").toLowerCase();
      const previewKind = ["sms", "email", "call"].includes(channelKey) ? channelKey : "unknown";
      const sendAt = startAt + Math.round(Number(s.offset || 0) * 3600);
      const smsLine =
        channelKey === "sms" || channelKey === "call" ? resolveStepSmsTwilioDisplay(s, twilioFrom) : twilioFrom;
      const detail =
        s.channel === "email"
          ? `Email: ${s.subject || "(no subject)"}`
          : s.channel === "call"
            ? `Call from ${escapeHtml(smsLine)}`
            : `SMS from ${escapeHtml(smsLine)}`;
      const offLabel = formatOffsetLabel(s.offset);
      return `<div class="campaign-timeline-row campaign-timeline-row--${previewKind}">Step ${s.idx + 1} | ${offLabel} (${anchorLabel}) | ${detail} | ${formatUnix(sendAt)}</div>`;
    })
    .join("");

  renderJourneyChart(steps, startAt, twilioFrom);
}

function openJourneyStepDetail(step, startAt, chartIndex, twilioFromDisplay = "—") {
  if (!journeyStepDialog || !journeyStepDialogHeading || !journeyStepDialogBody) return;
  const ch = String(step.channel || "").toLowerCase();
  const order = Number(chartIndex);
  const hasStart = Number.isFinite(startAt);
  const sendAt = hasStart
    ? formatUnix(startAt + Math.round(Number(step.offset || 0) * 3600))
    : "—";
  const anchor = "enrollment (when enroll tag is applied)";

  const title =
    ch === "email"
      ? step.subject || "Email step"
      : ch === "call"
        ? "Call step"
        : "SMS step";

  journeyStepDialogHeading.textContent = `Step ${Number.isFinite(order) ? order + 1 : 1}: ${title}`;

  const parts = [];
  parts.push(`<dl class="journey-detail-list">`);
  parts.push(`<dt>Function</dt><dd>${escapeHtml(describeStepFunction(ch))}</dd>`);
  parts.push(`<dt>Channel</dt><dd>${escapeHtml(String(step.channel || "").toUpperCase())}</dd>`);
  parts.push(
    `<dt>Schedule offset</dt><dd>${escapeHtml(formatOffsetLabel(Number(step.offset ?? 0)))} after ${escapeHtml(anchor)}</dd>`
  );
  parts.push(`<dt>Scheduled send</dt><dd>${escapeHtml(sendAt)}</dd>`);
  if (ch === "sms") {
    parts.push(
      `<dt>Twilio SMS number</dt><dd>${escapeHtml(resolveStepSmsTwilioDisplay(step, twilioFromDisplay))}</dd>`
    );
  }
  if (ch === "call") {
    parts.push(
      `<dt>Twilio caller ID</dt><dd>${escapeHtml(resolveStepSmsTwilioDisplay(step, twilioFromDisplay))}</dd>`
    );
  }
  if (ch === "email") {
    parts.push(`<dt>Email subject</dt><dd>${escapeHtml(String(step.subject || "")) || "—"}</dd>`);
  }
  if (ch === "sms") {
    const raw = String(step.body || "");
    parts.push(
      `<dt>Message body</dt><dd><pre class="journey-detail-pre">${escapeHtml(raw) || "—"}</pre></dd>`
    );
  } else if (ch === "email") {
    const raw = String(step.body || "");
    const preview =
      typeof window.DOMPurify !== "undefined"
        ? window.DOMPurify.sanitize(raw, {
            ALLOWED_TAGS: [
              "p",
              "br",
              "strong",
              "b",
              "em",
              "i",
              "u",
              "s",
              "span",
              "div",
              "font",
              "h1",
              "h2",
              "h3",
              "ul",
              "ol",
              "li",
              "a",
              "img",
              "blockquote",
              "pre",
              "hr"
            ],
            ALLOWED_ATTR: ["style", "src", "alt", "href", "target", "rel", "title", "color", "size", "face", "class"],
            ALLOWED_URI_REGEXP: /^(?:(?:https?|data|mailto):|[^a-z]|[a-z+.-]+(?:[^a-z+.-:]|$))/i
          })
        : escapeHtml(raw);
    parts.push(
      `<dt>Message body</dt><dd><div class="journey-email-html-preview">${preview || "—"}</div></dd>`
    );
  }
  parts.push(`</dl>`);
  if (typeof step.idx === "number") {
    parts.push(
      `<p class="journey-detail-footnote">This corresponds to row <strong>${step.idx + 1}</strong> in your campaign steps list above (form order).</p>`
    );
  }

  journeyStepDialogBody.innerHTML = parts.join("");
  /* Use show() so the page stays interactive (showModal sets inert on the document and blocks Save/Update clicks). */
  journeyStepDialog.show();
}

function renderJourneyChart(sortedSteps, startAt, twilioFromDisplay = "—") {
  if (!journeyChartEl) return;
  const steps = Array.isArray(sortedSteps) ? sortedSteps : [];
  if (!steps.length) {
    journeyChartState = { steps: [], startAt: NaN, twilioFromDisplay: String(twilioFromDisplay || "—") };
    journeyChartEl.innerHTML = '<div class="contact-history-empty">Add steps to preview drip journey.</div>';
    return;
  }
  journeyChartState = { steps: [...steps], startAt, twilioFromDisplay: String(twilioFromDisplay || "—") };
  const hasStart = Number.isFinite(startAt);
  const twilioFrom = String(twilioFromDisplay || "—");
  journeyChartEl.innerHTML = steps
    .map((s, idx) => {
      const channelKey = String(s.channel || "").toLowerCase();
      const journeyKind = ["sms", "email", "call"].includes(channelKey) ? channelKey : "unknown";
      const sendAt = hasStart ? formatUnix(startAt + Math.round(Number(s.offset || 0) * 3600)) : "—";
      const title =
        s.channel === "email"
          ? s.subject || "Email Step"
          : s.channel === "call"
            ? "Automated Call Step"
            : "SMS Step";
      const offShort = formatOffsetLabel(s.offset);
      const smsLineForNode = s.channel === "sms" ? resolveStepSmsTwilioDisplay(s, twilioFrom) : twilioFrom;
      const detail =
        s.channel === "call"
          ? `After start: ${offShort}`
          : s.channel === "sms"
            ? `From ${smsLineForNode} · after ${offShort}`
            : `After start: ${offShort}`;
      return `<button type="button" class="journey-node journey-node--${journeyKind}" data-journey-idx="${idx}" aria-label="View step ${idx + 1} details">
        <div class="journey-node-title">Step ${idx + 1}: ${escapeHtml(title)}</div>
        <div class="journey-node-meta">${String(s.channel || "").toUpperCase()} | ${escapeHtml(detail)}</div>
        <div class="journey-node-time">${escapeHtml(sendAt)}</div>
      </button>
      ${idx < steps.length - 1 ? '<div class="journey-arrow" aria-hidden="true"></div>' : ""}`;
    })
    .join("");
}

if (journeyChartEl) {
  journeyChartEl.addEventListener("click", (e) => {
    const btn = e.target.closest("button.journey-node[data-journey-idx]");
    if (!btn || !journeyChartEl.contains(btn)) return;
    const i = Number(btn.getAttribute("data-journey-idx"));
    if (!Number.isFinite(i)) return;
    const step = journeyChartState.steps[i];
    if (!step) return;
    openJourneyStepDetail(step, journeyChartState.startAt, i, journeyChartState.twilioFromDisplay);
  });
}

if (journeyStepDialog) {
  journeyStepDialog.addEventListener("click", (e) => {
    if (e.target === journeyStepDialog) journeyStepDialog.close();
  });
  const closeBtn = journeyStepDialog.querySelector(".journey-step-dialog-close");
  if (closeBtn) {
    closeBtn.addEventListener("click", () => journeyStepDialog.close());
  }
}

async function loadCampaigns() {
  const { response, data } = await fetchApiJson("/api/drip/campaigns");
  if (!response.ok) throw new Error(data.error || "Failed to load campaigns");
  cachedCampaigns = Array.isArray(data) ? data : [];
  renderCampaignsList(cachedCampaigns);
  renderSavedCampaignCategoryList(cachedCampaignCategories, cachedCampaigns);
  tryOpenCampaignFromQuery();
}

function renderCampaignsList(sourceList) {
  if (!campaignListEl) return;
  campaignListEl.innerHTML = "";
}

async function deleteCampaignById(id) {
  const n = Number(id);
  if (!Number.isFinite(n) || n < 1) throw new Error("Invalid campaign id");
  if (!window.confirm(`Delete campaign #${n}?`)) return;
  const { response: delResp, data: delBody } = await fetchApiJson(`/api/drip/campaigns/${n}`, {
    method: "DELETE"
  });
  if (!delResp.ok) throw new Error(delBody.error || "Failed to delete campaign");
  showMessage(`Deleted campaign #${n}`);
  await loadCampaigns();
}

async function duplicateCampaignById(id) {
  const n = Number(id);
  const found = cachedCampaigns.find((x) => Number(x.id) === n);
  if (!found) throw new Error("Campaign not found");
  const baseName = String(found.name || "").trim() || `Campaign ${n}`;
  const duplicateName = getNextDuplicateCampaignName(baseName, cachedCampaigns);
  const tagRules = getCampaignTagRules(found);
  const steps = (Array.isArray(found.steps) ? found.steps : []).map((s, idx) => ({
    offset_hours: Number(s.offset_hours || 0),
    channel: String(s.channel || "sms"),
    subject: String(s.subject || ""),
    call_twiml_url: String(s.call_twiml_url || ""),
    body: String(s.body || ""),
    twilio_from: String(s.twilio_from || "").trim(),
    twilioFrom: String(s.twilio_from || "").trim(),
    email_from: String(s.email_from || "").trim(),
    emailFrom: String(s.email_from || "").trim(),
    step_order: idx
  }));
  if (!steps.length) throw new Error("Cannot duplicate a campaign without steps");
  const payload = {
    name: duplicateName,
    schedule_mode: "on_tag",
    start_at: null,
    end_at: null,
    twilio_from: String(found.twilio_from || "secondary"),
    twilioFrom: String(found.twilio_from || "secondary"),
    email_from: String(found.email_from || "").trim(),
    category_id: Number(found.category_id) > 0 ? Number(found.category_id) : null,
    tag_rules: tagRules,
    steps
  };
  const { response: dupResp, data: dupBody } = await fetchApiJson("/api/drip/campaigns", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  if (!dupResp.ok) throw new Error(dupBody.error || "Failed to duplicate campaign");
  showMessage(`Duplicated campaign #${n} as #${dupBody.id}`);
  await loadCampaigns();
}

async function renameCampaignById(id, requestedName) {
  const n = Number(id);
  const found = cachedCampaigns.find((x) => Number(x.id) === n);
  if (!found) throw new Error("Campaign not found");
  const prevName = String(found.name || "").trim() || `Campaign ${n}`;
  const nextName = String(requestedName || "").trim();
  if (!nextName || nextName === prevName) return;
  const steps = (Array.isArray(found.steps) ? found.steps : []).map((s, idx) => ({
    offset_hours: Number(s.offset_hours || 0),
    channel: String(s.channel || "sms"),
    subject: String(s.subject || ""),
    call_twiml_url: String(s.call_twiml_url || ""),
    body: String(s.body || ""),
    twilio_from: String(s.twilio_from || "").trim(),
    twilioFrom: String(s.twilio_from || "").trim(),
    email_from: String(s.email_from || "").trim(),
    emailFrom: String(s.email_from || "").trim(),
    step_order: idx
  }));
  if (!steps.length) throw new Error("Cannot rename a campaign without steps");
  const payload = {
    name: nextName,
    schedule_mode: "on_tag",
    start_at: null,
    end_at: null,
    twilio_from: String(found.twilio_from || "secondary"),
    twilioFrom: String(found.twilio_from || "secondary"),
    email_from: String(found.email_from || "").trim(),
    category_id: Number(found.category_id) > 0 ? Number(found.category_id) : null,
    tag_rules: getCampaignTagRules(found),
    steps
  };
  const { response, data } = await fetchApiJson(`/api/drip/campaigns/${n}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  if (!response.ok) throw new Error(data.error || "Failed to rename campaign");
  showMessage(`Renamed campaign #${n}`);
  await loadCampaigns();
}

function editCampaignById(id) {
  const n = Number(id);
  const found = cachedCampaigns.find((x) => Number(x.id) === n);
  if (!found) return;
  campaignForm.elements.name.value = String(found.name || "");
  setCampaignTwilioFromSelect(found.twilio_from);
  setCampaignEmailFromSelect(found.email_from);
  if (campaignCategorySelect) campaignCategorySelect.value = found.category_id != null ? String(found.category_id) : "";
  campaignForm.elements.scheduleMode.value = "on_tag";
  campaignStepsEl.innerHTML = "";
  for (const step of Array.isArray(found.steps) ? found.steps : []) {
    createStepRow(step);
  }
  clearTagRules();
  const tagRules = getCampaignTagRules(found);
  const enrollRule = tagRules.find(
    (tr) =>
      String(tr?.function || "").toLowerCase() === "enroll" && String(tr?.tag || "").trim()
  );
  if (enrollRule) {
    createTagRuleRow({ tag: String(enrollRule.tag || "").trim(), function: "enroll" });
  } else {
    createTagRuleRow({ function: "none" });
  }
  syncTagsDatalist();
  syncImmediateStartCheckboxFromFirstStep();
  setEditMode(found);
  renderTimelinePreview();
  const createSection = document.getElementById("createCampaignSection");
  if (createSection && typeof createSection.scrollIntoView === "function") {
    createSection.scrollIntoView({ behavior: "smooth", block: "start" });
  }
  campaignUserEditedSinceLoad = false;
  if (window.CrmUnsavedGuard) window.CrmUnsavedGuard.markClean();
}

function tryOpenCampaignFromQuery() {
  if (!Number.isInteger(pendingEditCampaignIdFromQuery) || pendingEditCampaignIdFromQuery < 1) return;
  const targetId = pendingEditCampaignIdFromQuery;
  const found = cachedCampaigns.find((x) => Number(x.id) === targetId);
  if (!found) return;
  pendingEditCampaignIdFromQuery = 0;
  editCampaignById(targetId);
  try {
    const clean = `${window.location.pathname}${window.location.hash || ""}`;
    window.history.replaceState({}, document.title, clean);
  } catch {
    /* ignore URL cleanup issues */
  }
}

function getCampaignTagRules(campaign) {
  let tagRules = Array.isArray(campaign?.tag_rules) ? campaign.tag_rules : [];
  if (!tagRules.length && campaign?.tag_config) {
    try {
      const parsed = JSON.parse(String(campaign.tag_config));
      if (Array.isArray(parsed)) tagRules = parsed;
    } catch {
      tagRules = [];
    }
  }
  return tagRules;
}

function getNextDuplicateCampaignName(baseName, campaigns) {
  const rawBase = String(baseName || "").trim() || "Campaign";
  const rows = Array.isArray(campaigns) ? campaigns : [];
  const existing = new Set(rows.map((c) => String(c.name || "").trim().toLowerCase()).filter(Boolean));
  const first = `${rawBase} (Copy)`;
  if (!existing.has(first.toLowerCase())) return first;
  let i = 2;
  while (i < 10000) {
    const candidate = `${rawBase} (Copy ${i})`;
    if (!existing.has(candidate.toLowerCase())) return candidate;
    i += 1;
  }
  return `${rawBase} (Copy ${Date.now()})`;
}

function focusCampaignCard(campaignId) {
  const id = Number(campaignId);
  if (!Number.isFinite(id) || id < 1 || !campaignListEl) return;
  const card = campaignListEl.querySelector(`.campaign-card[data-campaign-id="${id}"]`);
  if (!card) return;
  card.scrollIntoView({ behavior: "smooth", block: "center" });
}

function renderSavedCampaignCategoryList(categories, campaigns) {
  if (!savedCampaignCategoryList) return;
  const cats = Array.isArray(categories) ? categories : [];
  const rows = Array.isArray(campaigns) ? campaigns : [];
  const countFor = (idRaw) =>
    rows.filter((c) => {
      if (idRaw === "") return !Number(c.category_id);
      return String(c.category_id || "") === String(idRaw);
    }).length;
  const total = rows.length;
  const uncategorizedCount = countFor("");
  const categoryItems = [
    { id: "cat-uncategorized", label: "Uncategorized", value: "", count: uncategorizedCount },
    ...cats.map((c) => ({
      id: `cat-${c.id}`,
      label: String(c.name || ""),
      value: String(c.id),
      count: countFor(c.id)
    }))
  ];

  const quickFiltersHtml = `<div class="campaign-category-quick-filters">
    <button type="button" class="campaign-category-quick-btn${selectedSavedCategoryId === "__all__" ? " is-active" : ""}" data-category-value="__all__">
      <span>All</span><strong>${total}</strong>
    </button>
  </div>`;

  const groupsHtml = categoryItems
    .map((item) => {
      const isActive = String(item.value) === String(selectedSavedCategoryId);
      const value = String(item.value);
      const categoryCampaigns =
        value === "__all__"
          ? rows
          : value === ""
            ? rows.filter((c) => !Number(c.category_id))
            : rows.filter((c) => String(c.category_id || "") === value);
      const isOpen = expandedCategoryValues.has(value);
      const childrenHtml = categoryCampaigns.length
        ? categoryCampaigns
            .map((c) => {
              const legacySchedule = c.schedule_mode === "scheduled";
              const schedBadge = legacySchedule ? "Legacy" : "Tag enrollment";
              const isCampaignActive = Number(selectedSavedCampaignId) === Number(c.id);
              const twilioLine = String(c.twilio_from || "secondary").toLowerCase();
              const twilioHint = ["primary", "secondary", "third"].includes(twilioLine) ? twilioLine : "secondary";
              const tagRules = getCampaignTagRules(c);
              const enrollRule = tagRules.find((tr) => String(tr?.function || "").toLowerCase() === "enroll");
              const enrollTag = String(enrollRule?.tag || tagRules[0]?.tag || "").trim();
              const dateLine = legacySchedule
                ? `Saved window: ${formatUnix(c.start_at)} → ${formatUnix(c.end_at)}`
                : "Starts when the enroll tag is applied.";
              const stepsHtml = (Array.isArray(c.steps) ? c.steps : [])
                .map((s) => {
                  const title =
                    s.channel === "email"
                      ? `Email: ${s.subject || "(no subject)"}`
                      : s.channel === "call"
                        ? "Call"
                        : "SMS";
                  return `<li>${formatOffsetLabel(s.offset_hours)} — ${title}</li>`;
                })
                .join("");
              const enrollmentStatsHtml = formatCampaignEnrollmentStats(c);
              return `<button type="button" class="campaign-category-child${isCampaignActive ? " is-active" : ""}" data-category-value="${escapeHtml(
                value
              )}" data-campaign-id="${c.id}">
                <span class="campaign-category-child-main">
                  <span class="campaign-category-child-name">${escapeHtml(String(c.name || `Campaign #${c.id}`))}</span>
                  ${enrollmentStatsHtml}
                </span>
                <span class="campaign-category-child-badge">${escapeHtml(schedBadge)}</span>
              </button>
              <div class="campaign-category-child-details${isCampaignActive ? " is-active" : ""}">
                <div class="campaign-card-actions campaign-category-inline-actions">
                  <button type="button" class="campaign-inline-duplicate" data-id="${c.id}">Duplicate</button>
                  <button type="button" class="campaign-inline-rename" data-id="${c.id}">Rename</button>
                  <button type="button" class="campaign-inline-edit" data-id="${c.id}">Edit</button>
                  <button type="button" class="danger campaign-inline-delete" data-id="${c.id}">Delete</button>
                </div>
                <div class="campaign-inline-rename-form" data-id="${c.id}" hidden>
                  <input
                    type="text"
                    class="campaign-inline-rename-input"
                    value="${escapeHtml(String(c.name || `Campaign #${c.id}`))}"
                    aria-label="Campaign name"
                  />
                  <button type="button" class="campaign-inline-rename-save" data-id="${c.id}">Save</button>
                  <button type="button" class="campaign-inline-rename-cancel" data-id="${c.id}">Cancel</button>
                </div>
                <div class="campaign-card-meta">${escapeHtml(dateLine)}</div>
                <div class="campaign-card-meta"><strong class="campaign-tag-name-label">Tag Name:</strong> ${
                  enrollTag ? `<strong class="campaign-tag-name-value">${escapeHtml(enrollTag)}</strong>` : "<em>Not set</em>"
                }</div>
                <div class="campaign-card-meta">Twilio SMS / calls: <strong>${escapeHtml(twilioHint)}</strong> line</div>
                <div class="campaign-card-meta">Email from: ${
                  c.email_from
                    ? `<strong>${escapeHtml(String(c.email_from))}</strong>`
                    : `<em>${escapeHtml(getDefaultCampaignEmailFromLabel())}</em>`
                }</div>
                <ul>${stepsHtml || "<li>No steps</li>"}</ul>
              </div>`;
            })
            .join("")
        : '<div class="campaign-category-empty">No campaigns</div>';
      return `<details class="campaign-category-group${isActive ? " is-active" : ""}" data-category-value="${escapeHtml(
        value
      )}" ${isOpen ? "open" : ""}>
        <summary class="campaign-category-item${isActive ? " is-active" : ""}">
          <span>${escapeHtml(item.label)}</span>
          <strong>${item.count}</strong>
        </summary>
        <div class="campaign-category-children">${childrenHtml}</div>
      </details>`;
    })
    .join("");
  savedCampaignCategoryList.innerHTML = `${quickFiltersHtml}${groupsHtml}`;

  savedCampaignCategoryList.querySelectorAll(".campaign-category-quick-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const value = String(btn.getAttribute("data-category-value") || "__all__");
      selectedSavedCampaignId = null;
      if (value === "__all__") {
        const allCategoryValues = categoryItems.map((item) => String(item.value));
        const isAllAlreadySelected = selectedSavedCategoryId === "__all__";
        const areAllExpanded =
          allCategoryValues.length > 0 && allCategoryValues.every((v) => expandedCategoryValues.has(v));
        if (isAllAlreadySelected && areAllExpanded) {
          expandedCategoryValues.clear();
        } else {
          expandedCategoryValues.clear();
          allCategoryValues.forEach((v) => expandedCategoryValues.add(v));
        }
      }
      selectedSavedCategoryId = value;
      renderSavedCampaignCategoryList(cachedCampaignCategories, cachedCampaigns);
      renderCampaignsList(cachedCampaigns);
    });
  });

  savedCampaignCategoryList.querySelectorAll(".campaign-category-group").forEach((group) => {
    const value = String(group.getAttribute("data-category-value") || "");
    const summary = group.querySelector("summary.campaign-category-item");
    if (summary) {
      summary.addEventListener("click", (event) => {
        event.preventDefault();
        const isOpen = expandedCategoryValues.has(value);
        if (isOpen) expandedCategoryValues.delete(value);
        else expandedCategoryValues.add(value);
        selectedSavedCategoryId = value === "__all__" ? "__all__" : value;
        selectedSavedCampaignId = null;
        renderSavedCampaignCategoryList(cachedCampaignCategories, cachedCampaigns);
        renderCampaignsList(cachedCampaigns);
      });
    }
  });

  savedCampaignCategoryList.querySelectorAll(".campaign-category-child").forEach((btn) => {
    btn.addEventListener("click", () => {
      const value = String(btn.getAttribute("data-category-value") || "__all__");
      const campaignId = Number(btn.getAttribute("data-campaign-id"));
      selectedSavedCategoryId = value === "__all__" ? "__all__" : value;
      selectedSavedCampaignId = Number.isFinite(campaignId) ? campaignId : null;
      renderSavedCampaignCategoryList(cachedCampaignCategories, cachedCampaigns);
      renderCampaignsList(cachedCampaigns);
      focusCampaignCard(campaignId);
      const editingId = getCampaignEditId();
      if (Number.isFinite(editingId) && editingId === campaignId) {
        renderTimelinePreview();
      } else {
        showSavedCampaignPreview(campaignId);
      }
    });
  });

  savedCampaignCategoryList.querySelectorAll(".campaign-inline-edit").forEach((btn) => {
    btn.addEventListener("click", (event) => {
      event.stopPropagation();
      editCampaignById(btn.getAttribute("data-id"));
    });
  });
  savedCampaignCategoryList.querySelectorAll(".campaign-inline-duplicate").forEach((btn) => {
    btn.addEventListener("click", async (event) => {
      event.stopPropagation();
      try {
        await duplicateCampaignById(btn.getAttribute("data-id"));
      } catch (error) {
        showMessage(error.message, true);
      }
    });
  });
  savedCampaignCategoryList.querySelectorAll(".campaign-inline-rename").forEach((btn) => {
    btn.addEventListener("click", (event) => {
      event.stopPropagation();
      const id = String(btn.getAttribute("data-id") || "");
      const form = savedCampaignCategoryList.querySelector(`.campaign-inline-rename-form[data-id="${id}"]`);
      if (!form) return;
      form.hidden = false;
      const input = form.querySelector(".campaign-inline-rename-input");
      if (input) {
        window.setTimeout(() => {
          input.focus();
          input.select();
        }, 0);
      }
    });
  });
  savedCampaignCategoryList.querySelectorAll(".campaign-inline-rename-cancel").forEach((btn) => {
    btn.addEventListener("click", (event) => {
      event.stopPropagation();
      const id = String(btn.getAttribute("data-id") || "");
      const form = savedCampaignCategoryList.querySelector(`.campaign-inline-rename-form[data-id="${id}"]`);
      if (!form) return;
      const input = form.querySelector(".campaign-inline-rename-input");
      const found = cachedCampaigns.find((x) => String(x.id) === id);
      if (input && found) input.value = String(found.name || `Campaign #${id}`);
      form.hidden = true;
    });
  });
  savedCampaignCategoryList.querySelectorAll(".campaign-inline-rename-input").forEach((input) => {
    input.addEventListener("click", (event) => event.stopPropagation());
    input.addEventListener("keydown", async (event) => {
      const form = input.closest(".campaign-inline-rename-form");
      const id = form ? String(form.getAttribute("data-id") || "") : "";
      if (!id) return;
      if (event.key === "Enter") {
        event.preventDefault();
        event.stopPropagation();
        try {
          await renameCampaignById(id, input.value);
        } catch (error) {
          showMessage(error.message, true);
          return;
        }
      } else if (event.key === "Escape") {
        event.preventDefault();
        event.stopPropagation();
        if (form) form.hidden = true;
      }
    });
  });
  savedCampaignCategoryList.querySelectorAll(".campaign-inline-rename-save").forEach((btn) => {
    btn.addEventListener("click", async (event) => {
      event.stopPropagation();
      const id = String(btn.getAttribute("data-id") || "");
      const form = savedCampaignCategoryList.querySelector(`.campaign-inline-rename-form[data-id="${id}"]`);
      const input = form ? form.querySelector(".campaign-inline-rename-input") : null;
      try {
        await renameCampaignById(id, input ? input.value : "");
      } catch (error) {
        showMessage(error.message, true);
      }
    });
  });
  savedCampaignCategoryList.querySelectorAll(".campaign-inline-delete").forEach((btn) => {
    btn.addEventListener("click", async (event) => {
      event.stopPropagation();
      try {
        await deleteCampaignById(btn.getAttribute("data-id"));
      } catch (error) {
        showMessage(error.message, true);
      }
    });
  });
}

function repopulateCategorySelect(selectEl, categories, selectedValue = "") {
  if (!selectEl) return;
  const sel = String(selectedValue || "").trim();
  const opts = Array.isArray(categories) ? categories : [];
  selectEl.innerHTML = "";
  const first = document.createElement("option");
  first.value = "";
  first.textContent = "No category";
  selectEl.appendChild(first);
  for (const cat of opts) {
    const o = document.createElement("option");
    o.value = String(cat.id);
    o.textContent = String(cat.name || "");
    selectEl.appendChild(o);
  }
  if (sel && [...selectEl.options].some((o) => o.value === sel)) selectEl.value = sel;
  else selectEl.value = "";
}

async function loadCampaignCategories() {
  const selectedForm = String(campaignCategorySelect?.value || "");
  const { response, data } = await fetchApiJson("/api/drip/categories");
  if (!response.ok) throw new Error(data.error || "Failed to load categories");
  const list = Array.isArray(data) ? data : [];
  cachedCampaignCategories = list;
  repopulateCategorySelect(campaignCategorySelect, list, selectedForm);
  renderSavedCampaignCategoryList(cachedCampaignCategories, cachedCampaigns);
}

document.getElementById("backToContactsBtn").addEventListener("click", () => {
  window.location.href = "/index.html";
});

async function refreshCampaignBuilderData(showSuccess = false) {
  const results = await Promise.allSettled([
    loadSavedTags(),
    loadCampaigns(),
    loadCampaignCategories(),
    populateCampaignEmailFromOptions(),
    loadCampaignStepEmailTemplates()
  ]);
  syncTagsDatalist();
  const failures = results.filter((result) => result.status === "rejected");
  if (failures.length) {
    const firstError = failures[0].reason;
    const message =
      firstError && typeof firstError.message === "string" && firstError.message.trim()
        ? firstError.message
        : "Some campaign data failed to refresh.";
    showMessage(message, true);
    return;
  }
  if (showSuccess) showMessage("Campaigns refreshed.");
}

document.getElementById("refreshCampaignsBtn").addEventListener("click", () => {
  expandedCategoryValues.clear();
  document.querySelectorAll("details[open]").forEach((el) => {
    el.open = false;
  });
  if (document.activeElement && typeof document.activeElement.blur === "function") {
    document.activeElement.blur();
  }
  refreshCampaignBuilderData(true)
    .catch((e) => showMessage(e.message, true));
});

if (analyzeCampaignBtn) {
  analyzeCampaignBtn.addEventListener("click", () => {
    analyzeSelectedCampaign().catch((e) => showMessage(e.message, true));
  });
}

addStepBtn.addEventListener("click", () => {
  campaignUserEditedSinceLoad = true;
  createStepRow({ offset_hours: 0, channel: "sms" });
});

if (campaignStartFirstStepImmediatelyEl) {
  campaignStartFirstStepImmediatelyEl.addEventListener("change", () => {
    if (campaignStartFirstStepImmediatelyEl.checked) {
      applyImmediateStartToFirstStep();
    }
    renderTimelinePreview();
  });
}
if (campaignIncludeSignatureEl) {
  const includeRaw = window.localStorage.getItem(EMAIL_INCLUDE_SIGNATURE_STORAGE_KEY);
  campaignIncludeSignatureEl.checked = includeRaw == null ? true : includeRaw === "1";
  campaignIncludeSignatureEl.addEventListener("change", () => {
    window.localStorage.setItem(EMAIL_INCLUDE_SIGNATURE_STORAGE_KEY, campaignIncludeSignatureEl.checked ? "1" : "0");
    document.querySelectorAll(".campaign-step-row").forEach((row) => {
      const channel = String(row.querySelector(".step-channel")?.value || "").toLowerCase();
      if (channel !== "email") return;
      const richEl = row.querySelector(".step-body-rich");
      if (!richEl) return;
      const current = String(richEl.innerHTML || "");
      richEl.innerHTML = stripCampaignSignatureBlocks(current);
      normalizeStepEditorImages(richEl);
    });
    renderTimelinePreview();
  });
}
if (campaignStepsEl) {
  campaignStepsEl.addEventListener("input", (e) => {
    if (e.target && e.target.matches && e.target.matches(".step-offset-days, .step-offset-hours, .step-offset-minutes")) {
      const first = getFirstCampaignStepRow();
      if (first && first.contains(e.target)) syncImmediateStartCheckboxFromFirstStep();
    }
    renderTimelinePreview();
  });
  campaignStepsEl.addEventListener("change", () => {
    renderTimelinePreview();
  });
}

if (campaignForm) {
  campaignForm.addEventListener("input", rememberCampaignUserEdit, true);
  campaignForm.addEventListener("change", rememberCampaignUserEdit, true);
  campaignForm.addEventListener("input", updateCampaignSummary);
  campaignForm.addEventListener("change", updateCampaignSummary);
}

if (cancelEditBtn) {
  cancelEditBtn.addEventListener("click", () => {
    if (getCampaignEditId() != null && !window.confirm("Discard changes to this campaign?")) return;
    resetCampaignBuilderForm();
  });
}

document.querySelectorAll(".campaign-starter-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    campaignUserEditedSinceLoad = true;
    loadStarterCampaign(btn.getAttribute("data-starter-id"));
  });
});

function resetCampaignBuilderForm() {
  if (journeyStepDialog && journeyStepDialog.open) journeyStepDialog.close();
  campaignForm.reset();
  campaignForm.elements.scheduleMode.value = "on_tag";
  setCampaignTwilioDefaultNumber();
  setCampaignEmailFromSelect("");
  if (campaignCategorySelect) campaignCategorySelect.value = "";
  campaignStepsEl.innerHTML = "";
  clearTagRules();
  createTagRuleRow({ function: "enroll" });
  createStepRow({ offset_hours: 0, channel: "sms" });
  syncImmediateStartCheckboxFromFirstStep();
  setEditMode(null);
  selectedSavedCampaignId = null;
  renderTimelinePreview();
  campaignUserEditedSinceLoad = false;
  if (window.CrmUnsavedGuard) window.CrmUnsavedGuard.markClean();
}

campaignForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    if (campaignStartFirstStepImmediatelyEl && campaignStartFirstStepImmediatelyEl.checked) {
      applyImmediateStartToFirstStep();
    }
    const formData = new FormData(campaignForm);
    const name = String(formData.get("name") || "").trim();
    if (!name) throw new Error("Campaign name is required.");
    await attachPendingSmsPhotos();
    const steps = collectSteps();
    const tag_rules = collectTagRules();
    const twilio_from = getCampaignTwilioFromSubmitValue();
    const email_from = String(formData.get("emailFrom") || "").trim();
    const category_id_raw = String(formData.get("categoryId") || "").trim();
    const category_id = category_id_raw ? Number(category_id_raw) : null;
    const editId = getCampaignEditId();
    const isEdit = editId != null;
    const { response, data } = await fetchApiJson(isEdit ? `/api/drip/campaigns/${editId}` : "/api/drip/campaigns", {
      method: isEdit ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name,
        description: name,
        schedule_mode: "on_tag",
        start_at: null,
        end_at: null,
        twilio_from,
        twilioFrom: twilio_from,
        email_from,
        category_id: Number.isFinite(category_id) && category_id > 0 ? Math.floor(category_id) : null,
        steps,
        tag_rules
      })
    });
    if (!response.ok) throw new Error(data.error || `Failed to ${isEdit ? "update" : "create"} campaign`);
    if (journeyStepDialog && journeyStepDialog.open) journeyStepDialog.close();
    showMessage(isEdit ? "Campaign Updated" : "Campaign Saved");
    if (messageEl && typeof messageEl.scrollIntoView === "function") {
      messageEl.scrollIntoView({ behavior: "smooth", block: "end" });
    }
    resetCampaignBuilderForm();
    await Promise.all([loadSavedTags(), loadCampaigns()]);
    renderTimelinePreview();
    campaignUserEditedSinceLoad = false;
    if (window.CrmUnsavedGuard) window.CrmUnsavedGuard.markClean();
  } catch (error) {
    showMessage(error.message, true);
  }
});

createStepRow({ offset_hours: 0, channel: "sms" });
createTagRuleRow({ function: "enroll" });
setEditMode(null);
renderTimelinePreview();
setCampaignTwilioDefaultNumber();
const campaignTwilioFromEl = document.getElementById("campaignTwilioFrom");
if (campaignTwilioFromEl) {
  campaignTwilioFromEl.addEventListener("change", () => renderTimelinePreview());
}
/** After /api/twilio/from-numbers labels load, SMS preview lines show E.164 instead of "Primary"/"Secondary". */
window.__crmOnTwilioFromLabelsApplied = async () => {
  if (getCampaignEditId() == null) setCampaignTwilioDefaultNumber();
  try {
    const data =
      typeof window.loadTwilioFromData === "function"
        ? await window.loadTwilioFromData()
        : await fetch("/api/twilio/from-numbers").then((r) => (r.ok ? r.json() : {}));
    document.querySelectorAll("select.step-twilio-from").forEach((sel) => {
      const v = sel.value;
      if (typeof window.applyTwilioFromToStepSelect === "function") {
        window.applyTwilioFromToStepSelect(sel, data);
        if (v && [...sel.options].some((o) => o.value === v)) sel.value = v;
      }
    });
  } catch {
    /* ignore */
  }
  renderTimelinePreview();
  markCampaignBuilderCleanAfterHydration();
};

async function promptAndCreateCampaignCategory() {
  const name = await promptCampaignCategoryName();
  if (!name) return null;
  const { response, data } = await fetchApiJson("/api/drip/categories", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name })
  });
  if (!response.ok) throw new Error(data.error || "Failed to create category");
  await loadCampaignCategories();
  if (campaignCategorySelect) campaignCategorySelect.value = String(data.id);
  showMessage(`Created category "${data.name}"`);
  return data;
}

function promptCampaignCategoryName({
  dialogTitle = "New Category",
  inputLabel = "Category name",
  confirmLabel = "Save",
  initialValue = ""
} = {}) {
  if (!campaignCategoryDialog || !campaignCategoryDialogForm || !campaignCategoryDialogName) {
    return Promise.resolve(String(window.prompt(inputLabel, initialValue) || "").trim());
  }
  return new Promise((resolve) => {
    const heading = campaignCategoryDialog.querySelector("h3");
    const label = campaignCategoryDialog.querySelector("label");
    const submitBtn = campaignCategoryDialogForm.querySelector('button[type="submit"]');
    const prevHeading = heading ? heading.textContent : "";
    const prevLabel = label ? label.textContent : "";
    const prevSubmit = submitBtn ? submitBtn.textContent : "";
    const cleanup = () => {
      campaignCategoryDialogForm.removeEventListener("submit", onSubmit);
      campaignCategoryDialog.removeEventListener("cancel", onCancel);
      campaignCategoryDialog.removeEventListener("close", onClose);
      if (campaignCategoryDialogCancel) campaignCategoryDialogCancel.removeEventListener("click", onCancelClick);
      if (heading) heading.textContent = prevHeading;
      if (label) label.textContent = prevLabel;
      if (submitBtn) submitBtn.textContent = prevSubmit;
    };
    const finish = (value) => {
      cleanup();
      resolve(String(value || "").trim());
    };
    const onSubmit = (event) => {
      event.preventDefault();
      const value = String(campaignCategoryDialogName.value || "").trim();
      if (!value) return;
      campaignCategoryDialog.close("submit");
      finish(value);
    };
    const onCancelClick = () => {
      campaignCategoryDialog.close("cancel");
    };
    const onCancel = (event) => {
      event.preventDefault();
      campaignCategoryDialog.close("cancel");
    };
    const onClose = () => {
      if (campaignCategoryDialog.returnValue === "submit") return;
      finish("");
    };

    campaignCategoryDialogForm.addEventListener("submit", onSubmit);
    campaignCategoryDialog.addEventListener("cancel", onCancel);
    campaignCategoryDialog.addEventListener("close", onClose);
    if (campaignCategoryDialogCancel) campaignCategoryDialogCancel.addEventListener("click", onCancelClick);
    if (heading) heading.textContent = dialogTitle;
    if (label) label.textContent = inputLabel;
    if (submitBtn) submitBtn.textContent = confirmLabel;
    campaignCategoryDialogName.value = String(initialValue || "");
    campaignCategoryDialog.showModal();
    window.setTimeout(() => campaignCategoryDialogName.focus(), 0);
  });
}

if (addCampaignCategoryBtn) {
  addCampaignCategoryBtn.addEventListener("click", async () => {
    try {
      await promptAndCreateCampaignCategory();
    } catch (error) {
      showMessage(error.message, true);
    }
  });
}

if (renameCampaignCategoryBtn) {
  renameCampaignCategoryBtn.addEventListener("click", async () => {
    try {
      const categoryId = Number(campaignCategorySelect?.value || 0);
      if (!Number.isFinite(categoryId) || categoryId < 1) {
        showMessage("Select a category to rename first.", true);
        return;
      }
      const selectedCategory = cachedCampaignCategories.find((c) => Number(c.id) === categoryId);
      if (!selectedCategory) {
        showMessage("Selected category was not found.", true);
        return;
      }
      const previousName = String(selectedCategory.name || "").trim();
      const name = await promptCampaignCategoryName({
        dialogTitle: "Rename Category",
        inputLabel: "Category name",
        confirmLabel: "Rename",
        initialValue: previousName
      });
      if (!name || name === previousName) return;
      const { response, data } = await fetchApiJson(`/api/drip/categories/${categoryId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name })
      });
      if (!response.ok) throw new Error(data.error || "Failed to rename category");
      await Promise.all([loadCampaignCategories(), loadCampaigns()]);
      if (campaignCategorySelect) campaignCategorySelect.value = String(categoryId);
      showMessage(`Renamed category to "${data.name}".`);
    } catch (error) {
      showMessage(error.message, true);
    }
  });
}

if (deleteCampaignCategoryBtn) {
  deleteCampaignCategoryBtn.addEventListener("click", async () => {
    try {
      const categoryId = Number(campaignCategorySelect?.value || 0);
      if (!Number.isFinite(categoryId) || categoryId < 1) {
        showMessage("Select a category to delete first.", true);
        return;
      }
      const selectedCategory = cachedCampaignCategories.find((c) => Number(c.id) === categoryId);
      if (!selectedCategory) {
        showMessage("Selected category was not found.", true);
        return;
      }
      const categoryName = String(selectedCategory.name || `#${categoryId}`);
      const linkedCount = cachedCampaigns.filter((c) => Number(c.category_id) === categoryId).length;
      const warning = linkedCount
        ? `\n\n${linkedCount} campaign(s) currently use this category and will become uncategorized.`
        : "";
      if (!window.confirm(`Delete category "${categoryName}"?${warning}`)) return;
      const { response, data } = await fetchApiJson(`/api/drip/categories/${categoryId}`, {
        method: "DELETE"
      });
      if (!response.ok) throw new Error(data.error || "Failed to delete category");
      if (campaignCategorySelect) campaignCategorySelect.value = "";
      selectedSavedCategoryId = "__all__";
      selectedSavedCampaignId = null;
      await Promise.all([loadCampaignCategories(), loadCampaigns()]);
      showMessage(`Deleted category "${categoryName}".`);
    } catch (error) {
      showMessage(error.message, true);
    }
  });
}

if (campaignCategoryFieldBox && campaignCategorySelect) {
  const clearCategoryFromPanelClick = (event) => {
    const rawTarget = event.target;
    const targetEl = rawTarget instanceof Element ? rawTarget : rawTarget?.parentElement;
    if (!targetEl) return;
    if (targetEl.closest("select, button")) return;
    if (!String(campaignCategorySelect.value || "").trim()) return;
    campaignCategorySelect.value = "";
    showMessage("Category cleared.");
  };
  /* Handle both mouse-down and click for reliable panel interaction. */
  campaignCategoryFieldBox.addEventListener("mousedown", clearCategoryFromPanelClick);
  campaignCategoryFieldBox.addEventListener("click", clearCategoryFromPanelClick);
}

if (addCampaignCategorySidebarBtn) {
  addCampaignCategorySidebarBtn.addEventListener("click", async () => {
    try {
      const created = await promptAndCreateCampaignCategory();
      if (created && created.id != null) {
        selectedSavedCategoryId = String(created.id);
        renderSavedCampaignCategoryList(cachedCampaignCategories, cachedCampaigns);
        renderCampaignsList(cachedCampaigns);
      }
    } catch (error) {
      showMessage(error.message, true);
    }
  });
}

refreshCampaignBuilderData(false)
  .then(() => markCampaignBuilderCleanAfterHydration())
  .catch((e) => showMessage(e.message, true));

// ── AI Campaign Builder ────────────────────────────────────────────────────────
(function initAiCampaignBuilder() {
  const goalInput    = document.getElementById("campaignAiGoalInput");
  const generateBtn  = document.getElementById("campaignAiGenerateBtn");
  const statusEl     = document.getElementById("campaignAiStatus");
  const statusBadge  = document.getElementById("campaignAiStatusBadge");
  const previewEl    = document.getElementById("campaignAiPreview");
  if (!generateBtn || !goalInput) return;

  let lastCampaign = null;

  function setAiReadyBadge(state, text) {
    if (!statusBadge) return;
    statusBadge.dataset.state = state;
    statusBadge.textContent = text;
  }

  function friendlyAiError(raw) {
    const msg = String(raw || "");
    if (/getAI|getAllVoices|limit reached|\berror:\s*limit\b|\blimit\b|quota|credit|billing|rate.?limit/i.test(msg)) {
      return "Claude API usage or credit limit reached. Check billing at console.anthropic.com, then try again.";
    }
    return msg || "Generation failed.";
  }

  async function loadCampaignAiStatus() {
    if (!statusBadge) return;
    try {
      const res = await fetch("/api/assistant/status");
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Could not reach AI.");
      if (data.configured) {
        setAiReadyBadge("ready", "AI Ready");
      } else {
        setAiReadyBadge("unconfigured", "AI not configured");
      }
    } catch {
      setAiReadyBadge("error", "AI unavailable");
    }
  }

  loadCampaignAiStatus();

  function setStatus(msg, isError) {
    if (!statusEl) return;
    statusEl.textContent = msg;
    statusEl.style.color = isError ? "#dc2626" : "#64748b";
  }

  function renderPreview(campaign) {
    if (!previewEl) return;
    const channelLabel = { email: "📧 Email", sms: "💬 SMS", call: "📞 Call" };
    const rows = campaign.steps.map((s, i) => `
      <div style="padding:14px 16px;${i < campaign.steps.length - 1 ? "border-bottom:1px solid #e2e8f0;" : ""}">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
          <span style="font-size:0.75rem;font-weight:700;background:#e0e7ff;color:#3730a3;padding:2px 8px;border-radius:999px;">${channelLabel[s.channel] || s.channel}</span>
          <span style="font-size:0.78rem;color:#64748b;">Step ${s.step_order} · ${s.offset_hours === 0 ? "Immediately" : `+${s.offset_hours}h`}</span>
        </div>
        ${s.subject ? `<p style="margin:0 0 4px;font-size:0.88rem;font-weight:700;color:#1e293b;">Subject: ${escapeHtml(s.subject)}</p>` : ""}
        <p style="margin:0;font-size:0.85rem;color:#334155;white-space:pre-wrap;">${escapeHtml(s.body)}</p>
      </div>`).join("");

    previewEl.innerHTML = `
      <div style="background:#f8fafc;padding:14px 16px;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;">
        <div>
          <p style="margin:0;font-size:1rem;font-weight:700;color:#1e293b;">${escapeHtml(campaign.name)}</p>
          ${campaign.description ? `<p style="margin:2px 0 0;font-size:0.82rem;color:#64748b;">${escapeHtml(campaign.description)}</p>` : ""}
        </div>
        <button type="button" id="campaignAiSaveBtn" style="padding:8px 18px;background:#059669;color:#fff;border:none;border-radius:8px;font-size:0.88rem;font-weight:700;cursor:pointer;">✓ Save as Draft Campaign</button>
      </div>
      ${rows}
    `;
    previewEl.hidden = false;

    document.getElementById("campaignAiSaveBtn")?.addEventListener("click", saveAiCampaign);
  }

  async function saveAiCampaign() {
    if (!lastCampaign) return;
    const saveBtn = document.getElementById("campaignAiSaveBtn");
    if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = "Saving…"; }
    try {
      const payload = {
        name: lastCampaign.name,
        description: lastCampaign.description || "",
        schedule_mode: "on_tag",
        tag_config: [],
        steps: lastCampaign.steps.map(s => ({
          step_order: s.step_order,
          offset_hours: s.offset_hours,
          channel: s.channel,
          subject: s.subject || "",
          body: s.body,
          call_twiml_url: "",
          twilio_from: "",
          email_from: ""
        }))
      };
      const res = await fetch("/api/campaigns", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not save campaign.");
      setStatus("✓ Campaign saved! You can find it in the list and activate it when ready.", false);
      if (saveBtn) saveBtn.textContent = "✓ Saved";
      await refreshCampaignBuilderData(false);
    } catch (e) {
      setStatus(e.message, true);
      if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = "✓ Save as Draft Campaign"; }
    }
  }

  generateBtn.addEventListener("click", async () => {
    const goal = String(goalInput.value || "").trim();
    if (!goal) { setStatus("Describe your campaign goal first.", true); return; }
    generateBtn.disabled = true;
    generateBtn.textContent = "Generating…";
    setStatus("Claude is writing your campaign…", false);
    previewEl.hidden = true;
    lastCampaign = null;
    try {
      const res = await fetch("/api/assistant/generate-campaign", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ goal })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Generation failed.");
      lastCampaign = data.campaign;
      renderPreview(lastCampaign);
      setStatus(`${lastCampaign.steps.length} steps generated — review and save.`, false);
    } catch (e) {
      setStatus(friendlyAiError(e.message), true);
    } finally {
      generateBtn.disabled = false;
      generateBtn.textContent = "✦ Generate Campaign";
    }
  });
})();
