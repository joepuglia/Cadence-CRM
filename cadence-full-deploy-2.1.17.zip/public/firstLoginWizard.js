/**
 * firstLoginWizard.js
 * First-things checklist on first login: connect email, set up phone, add a contact.
 * Unfinished steps link to Settings. Then the product tour starts.
 * Replay with ?setup=1
 */
(function initFirstLoginWizard() {
  const STORAGE_KEY = "cadence_wizard_dismissed";
  const prefs = window.CrmClientPrefs || {};

  const ITEM_HREFS = {
    email: "/settings.html?section=email-senders",
    phone: "/settings.html?section=twilio"
  };

  function isDismissed() {
    if (typeof prefs.readAccountFlag === "function") return prefs.readAccountFlag(STORAGE_KEY);
    return typeof prefs.readFlag === "function"
      ? prefs.readFlag(STORAGE_KEY)
      : localStorage.getItem(STORAGE_KEY) === "1";
  }

  function markDismissed() {
    if (typeof prefs.writeAccountFlag === "function") prefs.writeAccountFlag(STORAGE_KEY);
    else if (typeof prefs.writeFlag === "function") prefs.writeFlag(STORAGE_KEY);
    else {
      try {
        localStorage.setItem(STORAGE_KEY, "1");
      } catch {
        /* ignore */
      }
    }
  }

  function notifyWizardDone() {
    window.dispatchEvent(new Event("crm-first-login-wizard-done"));
  }

  function forceSetup() {
    return new URLSearchParams(window.location.search).get("setup") === "1";
  }

  function forceTourOnly() {
    const params = new URLSearchParams(window.location.search);
    return params.get("onboarding") === "1" && params.get("setup") !== "1";
  }

  async function trialMailboxConnected() {
    try {
      const res = await fetch("/api/email/options", { credentials: "include" });
      const data = await res.json();
      const detailed = Array.isArray(data.fromAddresses) ? data.fromAddresses : [];
      return detailed.some((d) => d && d.hasSmtp === true);
    } catch {
      return false;
    }
  }

  async function hasContacts() {
    try {
      const res = await fetch("/api/contacts/tab-counts", { credentials: "include" });
      const data = await res.json();
      return Number(data && data.all) > 0;
    } catch {
      return false;
    }
  }

  async function checkStatus() {
    const trial = window.__CRM_WORKSPACE_TYPE__ === "trial";
    try {
      const [status, twilioConf, contactOk] = await Promise.all([
        fetch("/api/runtime/setup-status", { credentials: "include" }).then((r) => r.json()),
        fetch("/api/twilio/config", { credentials: "include" }).then((r) => r.json()),
        hasContacts()
      ]);
      const emailOk = trial ? await trialMailboxConnected() : status?.smtp?.level === "ok";
      const cellOk = Boolean(twilioConf?.inboundForwardTo);
      const cadenceNumber = String(twilioConf?.provisionedPhone || "").trim().replace(/[<>&"]/g, "");
      return {
        emailOk,
        cellOk,
        contactOk,
        cadenceNumber,
        allDone: emailOk && cellOk && contactOk
      };
    } catch {
      return { emailOk: false, cellOk: false, contactOk: false, cadenceNumber: "", allDone: false };
    }
  }

  function itemRow(opts) {
    const stateClass = opts.done ? "is-done" : "is-link";
    const mark = opts.done ? "Done" : String(opts.num);
    const inner = `
        <div class="crm-setup-item-mark crm-setup-item-mark--${Number(opts.num) || 1}" aria-hidden="true">${mark}</div>
        <div class="crm-setup-item-body">
          <p class="crm-setup-item-title">${opts.title}</p>
          <p class="crm-setup-item-copy">${opts.copy}</p>
        </div>
    `;
    if (opts.done) {
      return `<div class="crm-setup-item ${stateClass}" data-item="${opts.id}">${inner}</div>`;
    }
    if (opts.href) {
      return `<a class="crm-setup-item ${stateClass}" data-item="${opts.id}" href="${opts.href}">${inner}</a>`;
    }
    return `<button type="button" class="crm-setup-item ${stateClass}" data-item="${opts.id}" id="${opts.buttonId}">${inner}</button>`;
  }

  function buildModal(status) {
    const el = document.createElement("div");
    el.id = "firstLoginWizard";
    el.className = "crm-setup-overlay";
    el.setAttribute("role", "dialog");
    el.setAttribute("aria-modal", "true");
    el.setAttribute("aria-labelledby", "crmSetupWelcome crmSetupTitle");

    const phoneHint = status.cadenceNumber
      ? `Your Cadence number is <strong>${status.cadenceNumber}</strong>. Open Settings to forward inbound calls to your cell.`
      : "Open Settings to forward inbound Cadence calls to your cell.";

    el.innerHTML = `
      <div class="crm-setup-card">
        <div class="crm-setup-head">
          <p id="crmSetupWelcome" class="crm-setup-welcome">Welcome to Cadence CRM</p>
          <p id="crmSetupTitle" class="crm-setup-title">First things to do</p>
          <p class="crm-setup-sub">Connect email, set up your phone, and add a contact — then take a short tour of Cadence.</p>
        </div>
        <div class="crm-setup-list">
          ${itemRow({
            id: "email",
            num: 1,
            done: status.emailOk,
            href: status.emailOk ? "" : ITEM_HREFS.email,
            title: "Connect your email",
            copy: "Cadence sends from your mailbox. Using Gmail? You need a Gmail App Password."
          })}
          ${itemRow({
            id: "phone",
            num: 2,
            done: status.cellOk,
            href: status.cellOk ? "" : ITEM_HREFS.phone,
            title: "Set up your phone",
            copy: phoneHint
          })}
          ${itemRow({
            id: "contact",
            num: 3,
            done: status.contactOk,
            buttonId: status.contactOk ? "" : "wz-add-contact",
            title: "Add a contact",
            copy: "Add one person so you can call, text, and email from this workspace."
          })}
        </div>
        <div class="crm-setup-foot">
          <button type="button" id="wz-later" class="crm-setup-btn crm-setup-btn--ghost">I'll do this later</button>
          <button type="button" id="wz-start-tour" class="crm-setup-btn crm-setup-btn--accent">Start tour</button>
        </div>
      </div>
    `;
    return el;
  }

  function finishAndStartTour() {
    try {
      sessionStorage.setItem("crm.onboarding.startAfterSetup", "1");
    } catch {
      /* ignore */
    }
    markDismissed();
    const modal = document.getElementById("firstLoginWizard");
    if (modal) modal.remove();
    notifyWizardDone();
  }

  function bindAddContact(modal) {
    document.getElementById("wz-add-contact")?.addEventListener("click", () => {
      modal.style.display = "none";
      const addBtn = document.getElementById("contactsTopbarAddContactBtn");
      if (addBtn) addBtn.click();
      else modal.style.display = "flex";

      const addModal = document.getElementById("addContactModal");
      if (!addModal) {
        modal.style.display = "flex";
        return;
      }
      const observer = new MutationObserver(() => {
        if (!addModal.classList.contains("hidden")) return;
        observer.disconnect();
        modal.style.display = "flex";
      });
      observer.observe(addModal, { attributes: true, attributeFilter: ["class"] });
    });
  }

  function bindModal(modal) {
    document.getElementById("wz-later")?.addEventListener("click", finishAndStartTour);
    document.getElementById("wz-start-tour")?.addEventListener("click", finishAndStartTour);
    bindAddContact(modal);
  }

  async function init() {
    try {
      if (typeof prefs.resolveOnboardingAccount === "function") {
        await prefs.resolveOnboardingAccount();
      }
      if (typeof prefs.isMobileLayout === "function" && prefs.isMobileLayout()) {
        return;
      }
      if (forceTourOnly()) {
        return;
      }
      if (!forceSetup() && isDismissed()) {
        return;
      }

      const status = await checkStatus();
      if (!forceSetup() && status.allDone) {
        markDismissed();
        return;
      }

      const modal = buildModal(status);
      document.body.appendChild(modal);
      bindModal(modal);
    } catch (err) {
      console.error("firstLoginWizard:", err);
    } finally {
      if (!document.getElementById("firstLoginWizard")) notifyWizardDone();
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => setTimeout(() => void init(), 400));
  } else {
    setTimeout(() => void init(), 400);
  }
})();
