(function () {
  const PREVIEWS = {
    dashboard: {
      title: "Live Dashboard",
      image: "/screenshots/live-dashboard.png"
    },
    pipeline: {
      title: "Pipeline Summary",
      image: "/screenshots/pipeline.png"
    },
    contacts: {
      title: "Contacts Workspace",
      image: "/screenshots/contacts.png"
    },
    automation: {
      title: "Email, SMS And Sales Automation",
      image: "/screenshots/sales-automation.png"
    },
    calendar: {
      title: "Follow-up Reminders & Calendar",
      image: "/screenshots/calendar.png"
    },
    social: {
      title: "Social Marketing",
      image: "/screenshots/social-marketing.png"
    }
  };

  const modal = document.getElementById("welcomePreviewModal");
  const img = document.getElementById("welcomePreviewImage");
  const dialogEl = document.getElementById("welcomePreviewDialog");

  if (!modal || !img) return;

  let lastFocus = null;
  let screenshotCacheVersion = "";

  const manifestReady = fetch("/screenshots/manifest.json", { cache: "no-store" })
    .then((r) => (r.ok ? r.json() : null))
    .then((data) => {
      if (data && data.version != null) screenshotCacheVersion = String(data.version);
    })
    .catch(() => {});

  function imageUrl(base) {
    const v = screenshotCacheVersion || String(Date.now());
    const join = base.includes("?") ? "&" : "?";
    return `${base}${join}v=${encodeURIComponent(v)}`;
  }

  function showPreviewLoadError(title) {
    img.removeAttribute("src");
    img.alt = "";
    img.style.display = "none";
    let errEl = modal.querySelector(".welcome-preview-load-error");
    if (!errEl) {
      errEl = document.createElement("p");
      errEl.className = "welcome-preview-load-error";
      const wrap = modal.querySelector(".welcome-preview-frame-wrap");
      if (wrap) wrap.appendChild(errEl);
    }
    errEl.textContent = `Could not load the ${title} preview. Hard refresh the page (Ctrl+Shift+R) or try again in a moment.`;
    errEl.hidden = false;
  }

  function clearPreviewLoadError() {
    img.style.display = "";
    const errEl = modal.querySelector(".welcome-preview-load-error");
    if (errEl) errEl.hidden = true;
  }

  async function openPreview(key) {
    const preview = PREVIEWS[key];
    if (!preview) return;
    await manifestReady;
    lastFocus = document.activeElement;
    if (dialogEl) dialogEl.setAttribute("aria-label", preview.title);
    clearPreviewLoadError();
    img.alt = preview.title;
    img.onerror = () => showPreviewLoadError(preview.title);
    img.onload = () => clearPreviewLoadError();
    img.src = imageUrl(preview.image);
    modal.classList.toggle("welcome-preview-modal--full", key === "dashboard");
    modal.classList.remove("hidden");
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
    const closeBtn = modal.querySelector(".welcome-preview-close");
    if (closeBtn) closeBtn.focus();
  }

  function closePreview() {
    modal.classList.remove("welcome-preview-modal--full");
    modal.classList.add("hidden");
    modal.setAttribute("aria-hidden", "true");
    img.onload = null;
    img.onerror = null;
    img.removeAttribute("src");
    img.alt = "";
    clearPreviewLoadError();
    document.body.style.overflow = "";
    if (lastFocus && typeof lastFocus.focus === "function") lastFocus.focus();
  }

  document.querySelectorAll("[data-preview]").forEach((el) => {
    const key = el.getAttribute("data-preview");
    if (!PREVIEWS[key]) return;

    if (el.classList.contains("welcome-feature-card--preview")) {
      el.addEventListener("click", () => openPreview(key));
      el.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          openPreview(key);
        }
      });
    } else {
      el.addEventListener("click", () => openPreview(key));
    }
  });

  modal.querySelectorAll("[data-preview-close]").forEach((el) => {
    el.addEventListener("click", closePreview);
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !modal.classList.contains("hidden")) closePreview();
  });
})();
