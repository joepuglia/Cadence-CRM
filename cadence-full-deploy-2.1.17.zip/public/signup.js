(function () {
  const V = window.SignupValidation;
  const US_STATES = [
    ["AL", "Alabama"], ["AK", "Alaska"], ["AZ", "Arizona"], ["AR", "Arkansas"],
    ["CA", "California"], ["CO", "Colorado"], ["CT", "Connecticut"], ["DE", "Delaware"],
    ["FL", "Florida"], ["GA", "Georgia"], ["HI", "Hawaii"], ["ID", "Idaho"],
    ["IL", "Illinois"], ["IN", "Indiana"], ["IA", "Iowa"], ["KS", "Kansas"],
    ["KY", "Kentucky"], ["LA", "Louisiana"], ["ME", "Maine"], ["MD", "Maryland"],
    ["MA", "Massachusetts"], ["MI", "Michigan"], ["MN", "Minnesota"], ["MS", "Mississippi"],
    ["MO", "Missouri"], ["MT", "Montana"], ["NE", "Nebraska"], ["NV", "Nevada"],
    ["NH", "New Hampshire"], ["NJ", "New Jersey"], ["NM", "New Mexico"], ["NY", "New York"],
    ["NC", "North Carolina"], ["ND", "North Dakota"], ["OH", "Ohio"], ["OK", "Oklahoma"],
    ["OR", "Oregon"], ["PA", "Pennsylvania"], ["RI", "Rhode Island"], ["SC", "South Carolina"],
    ["SD", "South Dakota"], ["TN", "Tennessee"], ["TX", "Texas"], ["UT", "Utah"],
    ["VT", "Vermont"], ["VA", "Virginia"], ["WA", "Washington"], ["WV", "West Virginia"],
    ["WI", "Wisconsin"], ["WY", "Wyoming"]
  ];
  const form = document.getElementById("signupForm");
  const messageEl = document.getElementById("signupMessage");
  const submitBtn = document.getElementById("signupSubmit");
  const formWrap = document.getElementById("signupFormWrap");
  const card = document.getElementById("signupCard");
  const emailInput = document.getElementById("email");
  const emailFieldError = document.getElementById("emailFieldError");
  const residentStateSelect = document.getElementById("residentState");

  if (!form || !messageEl || !submitBtn || !V) return;

  if (residentStateSelect) {
    for (const [abbr, name] of US_STATES) {
      const opt = document.createElement("option");
      opt.value = abbr;
      opt.textContent = name;
      residentStateSelect.appendChild(opt);
    }
  }

  let submitInFlight = false;

  function setMessage(text, isError) {
    messageEl.textContent = text || "";
    messageEl.classList.remove("signup-message--error", "signup-message--ok");
    if (!text) return;
    messageEl.classList.add(isError ? "signup-message--error" : "signup-message--ok");
  }

  function setEmailFieldError(text) {
    const msg = text || "";
    if (emailFieldError) emailFieldError.textContent = msg;
    if (emailInput) {
      emailInput.setAttribute("aria-invalid", msg ? "true" : "false");
      const wrap = emailInput.closest(".signup-field");
      if (wrap) wrap.classList.toggle("signup-field--error", Boolean(msg));
    }
  }

  function validateEmailField(showError) {
    const email = String(emailInput?.value || "").trim().toLowerCase();
    const err = V.emailErrorMessage(email);
    if (showError) setEmailFieldError(err);
    return !err;
  }

  function showSuccess(data) {
    const trialEnd = data.trialEndsAt
      ? new Date(data.trialEndsAt).toLocaleDateString(undefined, {
          month: "long",
          day: "numeric",
          year: "numeric"
        })
      : "14 days from today";

    const already = Boolean(data.alreadyRegistered);
    const accessResent = Boolean(data.accessResent);
    const tempPw = data.tempPassword ? escapeHtml(data.tempPassword) : "";
    const credBlock =
      tempPw
        ? `<p>${
            accessResent
              ? "This email already had a trial workspace. We sent a <strong>new temporary password</strong> to your inbox:"
              : "Your <strong>clean trial workspace</strong> is ready. Sign in with:"
          }</p>
           <ul style="text-align:left;max-width:420px;margin:16px auto;line-height:1.6">
             <li>Email: <strong>${escapeHtml(data.email || "")}</strong></li>
             <li>Temporary password: <strong><code>${tempPw}</code></strong></li>
           </ul>
           <p>We also emailed these credentials from <strong>support@crmcadence.com</strong>. If you do not see it, check your <strong>spam or junk folder</strong>.</p>
           <p>Change your password after you log in, or use <a href="/login.html">Forgot password?</a> anytime.</p>`
        : already
          ? `<p>This email already has a trial workspace. Check your inbox (and spam folder) for login details from <strong>support@crmcadence.com</strong>. Use <a href="/login.html">Log in</a> or request a new password from that page if needed.</p>`
          : `<p>Check your inbox at <strong>${escapeHtml(data.email || "")}</strong> for login details from <strong>support@crmcadence.com</strong>. If it is missing, check your <strong>spam or junk folder</strong>.</p>`;

    formWrap.innerHTML = `
      <div class="signup-success">
        <svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
          <polyline points="22 4 12 14.01 9 11.01"/>
        </svg>
        <h2>${accessResent ? "Trial login resent" : already ? "Welcome back" : "Your trial workspace is ready"}</h2>
        ${credBlock}
        <p>Full Pro access through <strong>${escapeHtml(trialEnd)}</strong>, then <strong>$79/month</strong> to continue.</p>
        <a href="/login.html" class="welcome-btn welcome-btn--primary welcome-btn--lg">Log in to Cadence</a>
        <p class="signup-cancel-note">Cancel anytime before you subscribe.</p>
      </div>
    `;
    card.scrollIntoView({ behavior: "smooth", block: "start" });

    /* Meta Pixel: count only net-new trial workspaces as conversions. */
    if (
      typeof window.fbq === "function" &&
      !already &&
      !accessResent
    ) {
      try {
        window.fbq("track", "CompleteRegistration", {
          content_name: "cadence_trial_signup",
          status: true,
          value: 0,
          currency: "USD"
        });
      } catch (_) {
        /* ignore pixel errors */
      }
    }
  }

  function escapeHtml(s) {
    return String(s || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  if (emailInput) {
    emailInput.addEventListener("blur", () => validateEmailField(true));
    emailInput.addEventListener("input", () => {
      if (emailInput.closest(".signup-field--error")) validateEmailField(true);
    });
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (submitInFlight) return;
    setMessage("");
    setEmailFieldError("");

    const firstName = String(form.firstName?.value || "").trim();
    const lastName = String(form.lastName?.value || "").trim();
    const email = String(form.email?.value || "").trim().toLowerCase();
    const residentState = String(form.residentState?.value || "").trim();

    if (!firstName || !lastName) {
      setMessage("Please enter your first and last name.", true);
      return;
    }
    if (!residentState) {
      setMessage("Please select your resident state.", true);
      residentStateSelect?.focus();
      return;
    }
    if (!validateEmailField(true)) {
      const err = V.emailErrorMessage(email);
      setMessage(err, true);
      emailInput?.focus();
      return;
    }

    submitInFlight = true;
    submitBtn.disabled = true;
    submitBtn.textContent = "Submitting…";

    try {
      const res = await fetch("/api/subscription/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          firstName,
          lastName,
          email,
          residentState,
          plan: "pro",
          acceptTerms: true
        })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        const errText = data.error || "Could not complete signup. Please try again.";
        if (res.status === 400 && /email/i.test(errText)) {
          setEmailFieldError(errText);
          emailInput?.focus();
        }
        throw new Error(errText);
      }
      showSuccess(data);
    } catch (err) {
      setMessage(err.message || "Something went wrong.", true);
      submitBtn.disabled = false;
      submitBtn.textContent = "Start free trial";
    } finally {
      submitInFlight = false;
    }
  });
})();
