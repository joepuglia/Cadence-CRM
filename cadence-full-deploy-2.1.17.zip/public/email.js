const messageEl = document.getElementById("message");
const quickSendTopStatusEl = document.getElementById("quickSendTopStatus");
const emailPageVariant = String(document.documentElement.getAttribute("data-email-page") || "").trim();
const isEmailTemplatesOnlyPage = emailPageVariant === "templates";
/**
 * Max width for marketing/hero images in template HTML, compose preview, and the HTML actually sent.
 * (Previously compose/send used 180px, which made sent mail tiny vs the template.)
 */
const RICH_EMAIL_TEMPLATE_IMAGE_MAX_PX = 920;
// New body images insert at a readable width instead of full-bleed; the size bar
// (click an image) changes it. Small/Medium/Large map to 200/340/520.
const DEFAULT_BODY_IMAGE_WIDTH_PX = 340;
/** Same cap when composing, merging a template into the body, and building outbound HTML. */
const RICH_EMAIL_COMPOSE_IMAGE_MAX_PX = RICH_EMAIL_TEMPLATE_IMAGE_MAX_PX;
/** Signature / small inline graphics in sent mail - keep compact. */
const RICH_EMAIL_SIGNATURE_IMAGE_MAX_PX = 220;
const CADENCE_AI_ROBOT_EMAIL_ALT = "Cadence AI assistant";
const CADENCE_AI_ROBOT_EMAIL_WIDTH_PX = 140;

function getCadenceAiRobotEmailImageUrl() {
  const origin =
    typeof location !== "undefined" && location.origin && !/^file:/i.test(location.origin)
      ? location.origin.replace(/\/$/, "")
      : "https://crmcadence.com";
  return `${origin}/email-assets/cadence-ai-robot.gif`;
}

function isOwnerWorkspaceUi() {
  if (window.__CRM_WORKSPACE_TYPE__ === "trial") return false;
  if (window.__CRM_OMIT_INDIAN_WORKSPACE__) return false;
  return true;
}

function applyInsertRobotOwnerVisibility() {
  document.querySelectorAll("#emailBodyInsertRobotBtn, #templateBodyInsertRobotBtn").forEach((btn) => {
    const show = isOwnerWorkspaceUi();
    btn.hidden = !show;
    if (show) btn.removeAttribute("aria-hidden");
    else btn.setAttribute("aria-hidden", "true");
  });
}

if (window.__CRM_WORKSPACE_UI_READY__ && typeof window.__CRM_WORKSPACE_UI_READY__.then === "function") {
  window.__CRM_WORKSPACE_UI_READY__.then(applyInsertRobotOwnerVisibility);
} else {
  window.addEventListener("crm-workspace-ui-ready", applyInsertRobotOwnerVisibility, { once: true });
}
const sendEmailForm = document.getElementById("sendEmailForm");
const saveTemplateForm = document.getElementById("saveTemplateForm");
const templateSubjectInput = saveTemplateForm?.querySelector?.('[name="subject"]') || null;
const fromSelect = document.getElementById("emailFromSelect");
const toManualInput = document.getElementById("emailToManual");
const templateSelect = document.getElementById("emailTemplateSelect");
const subjectInput = document.getElementById("emailSubject");
const emailBodyEditor = document.getElementById("emailBodyEditor");
const templateBodyEditor = document.getElementById("templateBodyEditor");
const attachmentList = document.getElementById("emailAttachmentList");
const emailAttachmentSelect = document.getElementById("emailAttachmentSelect");
const emailAttachmentAddBtn = document.getElementById("emailAttachmentAddBtn");
const localFilesInput = document.getElementById("emailLocalFiles");
const localFilesList = document.getElementById("emailLocalFilesList");
const emailSignatureForm = document.getElementById("emailSignatureForm");
const emailSignatureEditor = document.getElementById("emailSignatureEditor");
const emailIncludeSignature = document.getElementById("emailIncludeSignature");
const emailIncludeSignatureBtn = document.getElementById("emailIncludeSignatureBtn");
const emailSignatureEnabledCheck = document.getElementById("emailSignatureEnabledCheck");
const emailSignatureFontSize = document.getElementById("emailSignatureFontSize");
const emailSignatureColor = document.getElementById("emailSignatureColor");
const emailSignatureLinkText = document.getElementById("emailSignatureLinkText");
const emailSignatureLinkUrl = document.getElementById("emailSignatureLinkUrl");
const emailSignatureImageUrl = document.getElementById("emailSignatureImageUrl");
const emailSignatureImageFile = document.getElementById("emailSignatureImageFile");
const signatureAddImageUrlBtn = document.getElementById("signatureAddImageUrlBtn");
const signatureInsertPhotoBtn = document.getElementById("signatureInsertPhotoBtn");
const signatureInsertGraphicUrlBtn = document.getElementById("signatureInsertGraphicUrlBtn");
const signatureBoldBtn = document.getElementById("signatureBoldBtn");
const signatureItalicBtn = document.getElementById("signatureItalicBtn");
const signatureUnderlineBtn = document.getElementById("signatureUnderlineBtn");
const signatureAlignLeftBtn = document.getElementById("signatureAlignLeftBtn");
const signatureAlignCenterBtn = document.getElementById("signatureAlignCenterBtn");
const signatureAlignRightBtn = document.getElementById("signatureAlignRightBtn");
const signatureLinkBtn = document.getElementById("signatureLinkBtn");
const signatureInlineColor = document.getElementById("signatureInlineColor");
const signatureInlineFontSize = document.getElementById("signatureInlineFontSize");
const signatureClearFormatBtn = document.getElementById("signatureClearFormatBtn");
const emailCcInput = document.getElementById("emailCc");
const emailToolbarAttachBtn = document.getElementById("emailToolbarAttachBtn");
const emailCancelBtn = document.getElementById("emailCancelBtn");
const openSignatureSettingsBtn = document.getElementById("openSignatureSettingsBtn");
const emailEnableTrackingStub = document.getElementById("emailEnableTrackingStub");
const emailComposeMergeFieldSelect = document.getElementById("emailComposeMergeFieldSelect");
const emailBodyFontFamily = document.getElementById("emailBodyFontFamily");
const emailBodyLegacyFontSize = document.getElementById("emailBodyInlineFontSize");
const templateMergeFieldSelect = document.getElementById("templateMergeFieldSelect");
const templateBodyFontFamily = document.getElementById("templateBodyFontFamily");
const templateBodyInlineFontSize = document.getElementById("templateBodyInlineFontSize");
const templateCategoryNameInput = document.getElementById("templateCategoryName");
const templateCategoryCreateBtn = document.getElementById("templateCategoryCreateBtn");
const emailTemplateCategoryList = document.getElementById("emailTemplateCategoryList");
const emailTemplateCategoryCreateToggle = document.getElementById("emailTemplateCategoryCreateToggle");
const emailTemplateCategoryCreateForm = document.getElementById("emailTemplateCategoryCreateForm");
const emailTemplateCategoryCreateName = document.getElementById("emailTemplateCategoryCreateName");
const emailTemplateCategoryCreateCancel = document.getElementById("emailTemplateCategoryCreateCancel");
const emailTemplateCategoryCreateFeedback = document.getElementById("emailTemplateCategoryCreateFeedback");
const templateEditSelect = document.getElementById("templateEditSelect");
const loadTemplateForEditBtn = document.getElementById("loadTemplateForEditBtn");
const cancelTemplateEditBtn = document.getElementById("cancelTemplateEditBtn");
const saveTemplateSubmitBtn = document.getElementById("saveTemplateSubmitBtn");
const saveTemplateAsNewBtn = document.getElementById("saveTemplateAsNewBtn");
const deleteTemplateBtn = document.getElementById("deleteTemplateBtn");
const templateEditUndoBtn = document.getElementById("templateEditUndoBtn");
const templateSaveFeedbackEl = document.getElementById("templateSaveFeedback");
const savedTemplatesByCategory = document.getElementById("savedTemplatesByCategory");
/** Last selection inside the compose editor for toolbar dropdowns (native selects steal focus). */
let emailBodyToolbarRange = null;
let emailBodyToolbarLock = 0;
let templateBodyToolbarRange = null;
let templateBodyToolbarLock = 0;
let templateMergeTarget = "body";
let emailComposeMergeTarget = "body";
let pendingSendConfirmAction = null;
let emailTemplateRowsCache = [];
let emailTemplateCategoriesCache = [];
let emailLibraryDocumentsCache = [];
const emailContactMergeCacheById = new Map();
const emailContactMergeCacheByEmail = new Map();
const emailContactIdByEmail = new Map();
const emailContactCustomFieldsById = new Map();
const emailContactCustomFieldsByEmail = new Map();
const selectedLibraryAttachmentIds = new Set();
let selectedTemplateCategory = "";

const TEMPLATE_UNDO_HISTORY_LIMIT = 75;
let templateUndoHistoryStack = [];
let templateUndoLastCommittedSnapshot = null;
let templateApplyingEditSnapshot = false;
let templateHistoryRecordTimer = null;
let templateSearchTerm = "";
const EMAIL_LEGACY_SIZE_TO_PX = {
  "1": 8,
  "2": 10,
  "3": 12,
  "4": 14,
  "5": 18,
  "6": 24,
  "7": 36
};
const EMAIL_LEGACY_SIZE_ENTRIES = Object.entries(EMAIL_LEGACY_SIZE_TO_PX).map(([key, px]) => ({
  key,
  px: Number(px)
}));
const EMAIL_SIGNATURE_KEY = "crm.emailSignatureSettings";
const EMAIL_INCLUDE_SIGNATURE_KEY = "crm.emailIncludeSignature";
/** Session-only stash so computer attachments survive refresh (same tab/session). */
const EMAIL_LOCAL_ATTACHMENTS_SESSION_KEY = "crm.emailCompose.localAttachments.v3";
/** Older keys - strip on Send Email load so stale blobs cannot reappear. */
const EMAIL_LOCAL_ATTACHMENTS_SESSION_KEYS_LEGACY = [
  "crm.emailCompose.localAttachments.v1",
  "crm.emailCompose.localAttachments.v2"
];
let persistLocalAttachmentsTimer = null;
const signatureSaveFeedbackEl = document.getElementById("signatureSaveFeedback");
let savedSignatureRange = null;
let quickSendTopStatusTimer = null;

function normalizeTemplateCategoryName(value) {
  const s = String(value || "").trim();
  return s || "Uncategorized";
}

function escapeTemplateListCell(value) {
  return escapeHtml(String(value == null ? "" : value));
}

function buildTemplateCategoryGroups() {
  const grouped = new Map();
  for (const row of emailTemplateRowsCache) {
    const category = normalizeTemplateCategoryName(row?.category_name);
    if (!grouped.has(category)) grouped.set(category, []);
    grouped.get(category).push(row);
  }
  for (const catRow of emailTemplateCategoriesCache) {
    const name = String(catRow?.name || "").trim();
    if (!name || grouped.has(name)) continue;
    grouped.set(name, []);
  }
  return grouped;
}

function setEmailTemplateCategoryCreateFeedback(text, isError = false) {
  if (!emailTemplateCategoryCreateFeedback) return;
  emailTemplateCategoryCreateFeedback.textContent = text || "";
  emailTemplateCategoryCreateFeedback.style.color = isError ? "#b91c1c" : "#047857";
}

function toggleEmailTemplateCategoryCreateForm(show) {
  if (!emailTemplateCategoryCreateForm || !emailTemplateCategoryCreateToggle) return;
  const open = !!show;
  emailTemplateCategoryCreateForm.classList.toggle("hidden", !open);
  emailTemplateCategoryCreateToggle.hidden = open;
  if (open) {
    emailTemplateCategoryCreateName?.focus();
  } else if (emailTemplateCategoryCreateName) {
    emailTemplateCategoryCreateName.value = "";
  }
}

async function createEmailTemplateCategory(name, { selectCategory = true } = {}) {
  const trimmed = String(name || "").trim();
  if (!trimmed) throw new Error("Enter a category name.");
  const { response, data } = await fetchApiJson("/api/email/template-categories", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name: trimmed })
  });
  if (!response.ok) throw new Error(data.error || "Could not create category.");
  await loadTemplateCategories();
  if (selectCategory) {
    selectedTemplateCategory = trimmed;
    templateSearchTerm = "";
    renderTemplatesByCategory({ scrollToResults: true });
  }
  if (templateCategoryNameInput) templateCategoryNameInput.value = trimmed;
  return data;
}

function notifyTemplateCategoryFilterChanged(category) {
  const value = category == null ? "" : String(category);
  window.__CRM_TEMPLATE_CATEGORY_FILTER__ = value;
  try {
    document.dispatchEvent(
      new CustomEvent("crm:template-category-changed", { detail: { category: value } })
    );
  } catch {
    /* ignore */
  }
}

function renderTemplatesByCategory(options = {}) {
  const scrollToResults = Boolean(options.scrollToResults);
  if (!savedTemplatesByCategory) return;
  const galleryMode =
    isEmailTemplatesOnlyPage && Boolean(document.querySelector('[data-et-grid="mine"]'));
  const rows = Array.isArray(emailTemplateRowsCache) ? [...emailTemplateRowsCache] : [];
  const grouped = buildTemplateCategoryGroups();
  const categories = [...grouped.keys()].sort((a, b) => {
    if (a === "Uncategorized") return 1;
    if (b === "Uncategorized") return -1;
    return a.localeCompare(b, undefined, { sensitivity: "base" });
  });
  if (!rows.length && !categories.length) {
    selectedTemplateCategory = "";
    savedTemplatesByCategory.innerHTML = galleryMode
      ? ""
      : '<div class="contact-history-empty">No saved custom templates yet. Create a category above, then save your first template.</div>';
    if (galleryMode) notifyTemplateCategoryFilterChanged("");
    return;
  }
  const available = new Set(["", "ALL", ...categories]);
  if (!available.has(selectedTemplateCategory)) {
    selectedTemplateCategory = "";
  }
  const activeCategory = selectedTemplateCategory;
  const categoryButtons = [
    `<button type="button" class="email-template-category-btn${activeCategory === "ALL" ? " is-active" : ""}" data-template-category="ALL">All Categories <strong>${rows.length}</strong></button>`,
    ...categories.map((category) => {
      const count = Array.isArray(grouped.get(category)) ? grouped.get(category).length : 0;
      const isActive = activeCategory === category;
      return `<button type="button" class="email-template-category-btn${isActive ? " is-active" : ""}" data-template-category="${escapeTemplateListCell(category)}">
        <span class="email-template-category-name">${escapeTemplateListCell(category)}</span>
        <strong>${count}</strong>
      </button>`;
    })
  ].join("");

  // Email Templates page: one category menu above the cards, not a row of chips.
  if (galleryMode) {
    const options = [
      `<option value=""${activeCategory === "" ? " selected" : ""}>Choose Category</option>`,
      `<option value="ALL"${activeCategory === "ALL" ? " selected" : ""}>All Categories</option>`,
      ...categories.map((category) => {
        const count = Array.isArray(grouped.get(category)) ? grouped.get(category).length : 0;
        const selected = activeCategory === category ? " selected" : "";
        return `<option value="${escapeTemplateListCell(category)}"${selected}>${escapeTemplateListCell(category)} (${count})</option>`;
      })
    ].join("");
    savedTemplatesByCategory.innerHTML = `<label class="et-category-filter"><span class="et-category-filter-label">Category</span><select id="emailTemplateCategoryFilter" aria-label="Filter templates by category">${options}</select></label>`;
    notifyTemplateCategoryFilterChanged(activeCategory);
    return;
  }

  const itemsForTable =
    !activeCategory
      ? []
      : activeCategory === "ALL"
      ? rows
      : grouped.get(activeCategory) || [];
  const normalizedSearch = String(templateSearchTerm || "").trim().toLowerCase();
  const filteredItems = normalizedSearch
    ? itemsForTable.filter((row) => String(row?.name || "").toLowerCase().includes(normalizedSearch))
    : itemsForTable;
  const sortedItems = filteredItems
    .slice()
    .sort((a, b) => String(a?.name || "").localeCompare(String(b?.name || ""), undefined, { sensitivity: "base" }));
  const rowsHtml = sortedItems.length
    ? sortedItems
        .map(
          (row) => `<tr>
            <td>${escapeTemplateListCell(row?.name || "")}</td>
            <td>${escapeTemplateListCell(row?.subject || "")}</td>
            <td class="email-template-list-action-cell">
              <div class="email-template-list-action-buttons">
                <button type="button" class="email-template-list-edit-btn" data-template-id="${Number(row?.id) || 0}">Edit</button>
                <button type="button" class="email-template-list-delete-btn danger" data-template-id="${Number(row?.id) || 0}">Delete</button>
              </div>
            </td>
          </tr>`
        )
        .join("")
    : `<tr><td colspan="3" class="contact-history-empty">No templates in this category.</td></tr>`;
  const tablePaneHtml = activeCategory
    ? `<div class="email-template-table-pane">
      <div class="email-template-table-head">
        <strong>${escapeTemplateListCell(activeCategory === "ALL" ? "All Categories" : activeCategory)}</strong>
        <input
          type="text"
          id="templateNameSearchInput"
          class="email-template-search-input"
          placeholder="Search template names..."
          value="${escapeTemplateListCell(templateSearchTerm)}"
          aria-label="Search templates by name"
        />
      </div>
      <div class="email-template-group-table-wrap">
        <table class="email-template-group-table">
          <thead>
            <tr><th>Name</th><th>Subject</th><th></th></tr>
          </thead>
          <tbody>${rowsHtml}</tbody>
        </table>
      </div>
    </div>`
    : `<p class="hint email-template-pick-category-hint">Click a category to view templates. Click the same category again to hide them.</p>`;
  const html = `<div class="email-templates-browser${activeCategory ? "" : " is-category-collapsed"}">
    <aside class="email-template-categories" aria-label="Template categories">
      ${categoryButtons}
    </aside>
    ${tablePaneHtml}
  </div>`;
  savedTemplatesByCategory.innerHTML = html;
  if (scrollToResults && activeCategory) {
    scrollToSavedEmailTemplatesList();
  }
}

// After a save/update, open the just-saved template's category in the
// "Your Saved Templates" list so the new template is visible right away
// (otherwise the list stays collapsed and it only appears in the dropdown).
function focusSavedTemplateCategory(categoryName, { scroll = true } = {}) {
  selectedTemplateCategory = normalizeTemplateCategoryName(categoryName);
  renderTemplatesByCategory({ scrollToResults: scroll });
}

function scrollToSavedEmailTemplatesList() {
  if (!isEmailTemplatesOnlyPage) return;
  const run = () => {
    const target =
      savedTemplatesByCategory?.querySelector(".email-template-group-table-wrap") ||
      savedTemplatesByCategory?.querySelector(".email-template-table-pane") ||
      document.getElementById("savedEmailTemplatesSection");
    if (!target) return;

    const rect = target.getBoundingClientRect();
    const padding = 20;
    let topNavBottom = 0;
    const nav = document.querySelector(".agile-nav");
    if (nav) {
      const navRect = nav.getBoundingClientRect();
      // Mobile: nav spans the top. Desktop: fixed left sidebar - do not offset vertical scroll.
      if (navRect.width > window.innerWidth * 0.55 && navRect.top <= 8) {
        topNavBottom = navRect.bottom;
      }
    }

    const minTop = topNavBottom + padding;
    const maxBottom = window.innerHeight - padding;

    if (rect.bottom > maxBottom) {
      window.scrollBy({ top: rect.bottom - maxBottom, behavior: "smooth" });
    } else if (rect.top < minTop) {
      window.scrollBy({ top: rect.top - minTop, behavior: "smooth" });
    }
  };

  requestAnimationFrame(() => requestAnimationFrame(run));
}

function setSignatureSaveFeedback(text, isError = false) {
  if (!signatureSaveFeedbackEl) return;
  signatureSaveFeedbackEl.textContent = text || "";
  signatureSaveFeedbackEl.classList.toggle("signature-save-feedback--error", Boolean(isError));
}

function setTemplateSaveFeedback(text, isError = false) {
  if (!templateSaveFeedbackEl) return;
  templateSaveFeedbackEl.textContent = text || "";
  templateSaveFeedbackEl.classList.toggle("signature-save-feedback--error", Boolean(isError));
}

function getInitialContactIdsFromQuery() {
  const params = new URLSearchParams(window.location.search);
  let raw = String(params.get("contactIds") || "").trim();
  // Large selections are handed off via sessionStorage to avoid a 414 on the URL.
  // Only read it when the batch flag is present so stale data can't leak in on a fresh visit.
  if (!raw && params.get("contactBatch") === "1") {
    try {
      raw = String(sessionStorage.getItem("cadencePendingEmailContactIds") || "").trim();
    } catch {
      raw = "";
    }
  }
  if (!raw) return [];
  return [...new Set(raw.split(",").map((v) => Number(v.trim())).filter((n) => Number.isInteger(n) && n > 0))];
}

function showMessage(text, isError = false) {
  if (!messageEl) return;
  const str = String(text == null ? "" : text);
  if (isError && typeof window.crmHandleAuthErrorMessage === "function" && window.crmHandleAuthErrorMessage(str, isError)) {
    return;
  }
  messageEl.textContent = str;
  messageEl.style.color = isError ? "#c62828" : "#1b5e20";
}

function showTimedSuccessMessage(text, timeoutMs = 5000) {
  const msg = String(text || "").trim();
  if (!msg) return;
  showMessage(msg, false);
  window.setTimeout(() => {
    if (!messageEl) return;
    if (String(messageEl.textContent || "").trim() !== msg) return;
    showMessage("", false);
  }, Math.max(0, Number(timeoutMs) || 0));
}

function showQuickSendTopStatus(text, isError = false, timeoutMs = 0) {
  if (!quickSendTopStatusEl) return;
  if (quickSendTopStatusTimer) {
    window.clearTimeout(quickSendTopStatusTimer);
    quickSendTopStatusTimer = null;
  }
  const msg = String(text || "").trim();
  if (!msg) {
    quickSendTopStatusEl.textContent = "";
    quickSendTopStatusEl.hidden = true;
    return;
  }
  quickSendTopStatusEl.hidden = false;
  quickSendTopStatusEl.textContent = msg;
  quickSendTopStatusEl.style.color = isError ? "#c62828" : "#1b5e20";
  const delay = Math.max(0, Number(timeoutMs) || 0);
  if (!delay) return;
  quickSendTopStatusTimer = window.setTimeout(() => {
    if (!quickSendTopStatusEl) return;
    if (String(quickSendTopStatusEl.textContent || "").trim() !== msg) return;
    quickSendTopStatusEl.textContent = "";
    quickSendTopStatusEl.hidden = true;
    quickSendTopStatusTimer = null;
  }, delay);
}

function getCrmApiBase() {
  const injected =
    typeof window.__CRM_API_ORIGIN__ === "string" ? window.__CRM_API_ORIGIN__.trim().replace(/\/$/, "") : "";
  if (injected) return injected;
  const fromMeta = document.querySelector('meta[name="crm-api-base"]')?.getAttribute("content") || "";
  return String(fromMeta || "").trim().replace(/\/$/, "");
}

function apiUrl(path) {
  const base = getCrmApiBase();
  const p = path.startsWith("/") ? path : `/${path}`;
  return base ? `${base}${p}` : p;
}

async function fetchApiJson(pathAndQuery, init) {
  const response = await fetch(apiUrl(pathAndQuery), {
    credentials: "include",
    ...(init || {})
  });
  const text = await response.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = {};
  }
  if (response.status === 401) {
    const msg = String(data.error || "Please log in to continue.").trim();
    showMessage(`${msg} Opening the sign-in page...`, true);
    if (!window.__crmEmailLoginRedirectScheduled) {
      window.__crmEmailLoginRedirectScheduled = true;
      window.setTimeout(() => {
        const next = `${window.location.pathname}${window.location.search || ""}`;
        window.location.href = `/login.html?next=${encodeURIComponent(next)}`;
      }, 900);
    }
  }
  return { response, data };
}

function collectAttachmentIds() {
  return [...selectedLibraryAttachmentIds];
}

function renderSelectedLibraryAttachmentTiles() {
  if (!attachmentList) return;
  attachmentList.querySelectorAll(".email-library-attach-tile").forEach((el) => el.remove());
  const selectedRows = emailLibraryDocumentsCache.filter((d) => selectedLibraryAttachmentIds.has(Number(d.id)));
  if (!selectedRows.length) {
    if (
      !attachmentList.querySelector(".email-local-attach-tile") &&
      !attachmentList.querySelector(".email-doc-attachments-empty")
    ) {
      const empty = document.createElement("div");
      empty.className = "contact-history-empty email-doc-attachments-empty";
      empty.textContent = "No documents selected.";
      attachmentList.appendChild(empty);
    }
    return;
  }
  attachmentList.querySelectorAll(".email-doc-attachments-empty").forEach((el) => el.remove());
  selectedRows.forEach((d) => {
    const row = document.createElement("div");
    row.className = "document-row email-attach-tile email-library-attach-tile";
    row.innerHTML = `<div class="email-library-tile-main">
      <span class="email-attach-filename">${escapeHtml(String(d.file_name || ""))}</span>
      <button type="button" class="email-library-remove-btn" data-doc-id="${Number(d.id)}" aria-label="Remove file from this email">Remove</button>
    </div>`;
    attachmentList.appendChild(row);
  });
}

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function getSignatureEditorHtml() {
  return String(emailSignatureEditor?.innerHTML || "").trim();
}

function getSignatureEditorText() {
  return String(emailSignatureEditor?.textContent || "").trim();
}

function setSignatureEditorHtml(html) {
  if (!emailSignatureEditor) return;
  emailSignatureEditor.innerHTML = String(html || "").trim();
  normalizeSignatureImages();
}

function ensureMovableImageWrap(wrap) {
  if (!wrap) return;
  wrap.classList.add("signature-image-wrap");
  wrap.setAttribute("draggable", "true");
  wrap.setAttribute("title", "Drag image to move");
}

/** Read any width hint already on an <img>: inline px, the width attribute, or 100%. */
function readImgWidthHint(img) {
  const s = String(img && img.style ? img.style.width : "").trim();
  let m = s.match(/^(\d+(?:\.\d+)?)px$/i);
  if (m) return { px: Math.max(40, Math.round(Number(m[1]))) };
  if (/^100%$/.test(s)) return { full: true };
  const attr = String((img && img.getAttribute && img.getAttribute("width")) || "").trim();
  m = attr.match(/^(\d+(?:\.\d+)?)$/);
  if (m) return { px: Math.max(40, Math.round(Number(m[1]))) };
  return {};
}

function normalizeImageHref(raw) {
  const href = String(raw || "").trim();
  if (!href) return "";
  if (/^(https?:\/\/|mailto:|tel:|sms:)/i.test(href)) return href;
  if (href.startsWith("/") || href.startsWith("#") || href.startsWith("{{")) return href;
  if (/^www\./i.test(href)) return `https://${href}`;
  return href;
}

function getImageWrapLinkHref(wrap) {
  if (!wrap) return "";
  const fromData = normalizeImageHref(wrap.getAttribute("data-img-href") || "");
  if (fromData) return fromData;
  const anchor = wrap.closest("a[href]");
  if (anchor && (!wrap.contains(anchor) || anchor.contains(wrap))) {
    return normalizeImageHref(anchor.getAttribute("href") || "");
  }
  return "";
}

function setImageWrapLinkHref(wrap, href) {
  if (!wrap) return;
  const normalized = normalizeImageHref(href);
  if (!normalized) {
    wrap.removeAttribute("data-img-href");
    wrap.removeAttribute("title");
    const parentAnchor = wrap.parentElement;
    if (parentAnchor && parentAnchor.tagName === "A" && parentAnchor.childElementCount === 1) {
      parentAnchor.replaceWith(wrap);
    }
    return;
  }
  wrap.setAttribute("data-img-href", normalized);
  wrap.setAttribute("title", `Linked: ${normalized} (drag to move)`);
  // Keep a real <a> around the wrap so Insert Link / selection tools stay consistent.
  let anchor = wrap.parentElement && wrap.parentElement.tagName === "A" ? wrap.parentElement : null;
  if (!anchor) {
    anchor = document.createElement("a");
    wrap.replaceWith(anchor);
    anchor.appendChild(wrap);
  }
  anchor.setAttribute("href", normalized);
  anchor.setAttribute("target", "_blank");
  anchor.setAttribute("rel", "noopener noreferrer");
  if (!String(anchor.getAttribute("style") || "").match(/text-decoration\s*:/i)) {
    anchor.style.textDecoration = "none";
  }
  if (!String(anchor.getAttribute("style") || "").match(/border\s*:/i)) {
    anchor.style.border = "0";
  }
}

function normalizeWrappedImages(editorEl) {
  if (!editorEl) return;
  const imgs = [...editorEl.querySelectorAll("img")];
  for (const img of imgs) {
    // Prevent browser-native image drag so our wrapper drag/drop reordering is used.
    img.setAttribute("draggable", "false");
    const parent = img.parentElement;
    if (parent && parent.classList.contains("signature-image-wrap")) {
      ensureMovableImageWrap(parent);
      const existingHref = getImageWrapLinkHref(parent);
      if (existingHref) setImageWrapLinkHref(parent, existingHref);
      continue;
    }
    // Preserve clickable images: <a href="..."><img></a>
    let linkHref = "";
    if (parent && parent.tagName === "A") {
      linkHref = normalizeImageHref(parent.getAttribute("href") || "");
    }
    const wrap = document.createElement("span");
    ensureMovableImageWrap(wrap);
    // The CSS forces the inner <img> to 100% of the wrapper, so the wrapper width
    // is what the reader sees. Mirror any baked width onto the wrapper so saved
    // sizes display correctly, and give unsized images a readable medium default
    // instead of full-bleed (the size bar - click the image - changes it).
    const hint = readImgWidthHint(img);
    if (hint.px) wrap.style.width = hint.px + "px";
    else if (!hint.full) wrap.style.width = DEFAULT_BODY_IMAGE_WIDTH_PX + "px";
    img.replaceWith(wrap);
    wrap.appendChild(img);
    if (linkHref) setImageWrapLinkHref(wrap, linkHref);
  }
}

function setupEditorImageDnD(editorEl) {
  if (!editorEl || editorEl.dataset.imageDndReady === "1") return;
  editorEl.dataset.imageDndReady = "1";
  let draggingWrap = null;

  editorEl.addEventListener("dragstart", (event) => {
    const wrap = event.target?.closest?.(".signature-image-wrap");
    if (!wrap || !editorEl.contains(wrap)) return;
    draggingWrap = wrap;
    wrap.classList.add("is-dragging");
    if (event.dataTransfer) {
      event.dataTransfer.effectAllowed = "move";
      event.dataTransfer.setData("text/plain", "signature-image-wrap");
    }
  });

  editorEl.addEventListener("dragend", () => {
    if (draggingWrap) draggingWrap.classList.remove("is-dragging");
    draggingWrap = null;
  });

  editorEl.addEventListener("dragover", (event) => {
    if (!draggingWrap) return;
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = "move";
  });

  editorEl.addEventListener("drop", (event) => {
    if (!draggingWrap) return;
    event.preventDefault();
    const targetWrap = event.target?.closest?.(".signature-image-wrap");
    if (targetWrap && targetWrap !== draggingWrap && editorEl.contains(targetWrap)) {
      const rect = targetWrap.getBoundingClientRect();
      const placeBefore = event.clientY < rect.top + rect.height / 2;
      targetWrap.parentNode.insertBefore(draggingWrap, placeBefore ? targetWrap : targetWrap.nextSibling);
    } else if (editorEl.contains(event.target)) {
      editorEl.appendChild(draggingWrap);
    }
  });

  // When an image is clicked, explicitly select its wrapper so alignment
  // actions (left/center/right) target the image block reliably.
  editorEl.addEventListener("click", (event) => {
    const wrap = event.target?.closest?.(".signature-image-wrap");
    if (!wrap || !editorEl.contains(wrap)) return;
    rteShowImageSizeBar(wrap);
    const sel = window.getSelection();
    if (!sel) return;
    const range = document.createRange();
    range.selectNode(wrap);
    sel.removeAllRanges();
    sel.addRange(range);
  });
}

/* ---- Reliable, precise image sizing: click an image in any rich editor and a
   size bar appears with an exact-pixels box, quick -/+ steppers, and Full width.
   The clicked image is highlighted so you always see what you're sizing. The
   wrapper width is what the editor shows and what gets baked into the <img> on
   save - replacing the fiddly corner-dragging that produced oversized images. -- */
let rteActiveImageWrap = null;
/** Current displayed width of the wrapped image, in px. */
function rteCurrentImageWidth(wrap) {
  const w = String((wrap && wrap.style && wrap.style.width) || "").trim();
  const m = w.match(/^(\d+(?:\.\d+)?)px$/i);
  if (m) return Math.round(Number(m[1]));
  const img = wrap && wrap.querySelector ? wrap.querySelector("img") : null;
  if (!img) return 0;
  return Math.round(img.getBoundingClientRect().width) || Math.round(img.offsetWidth) || 0;
}
function rteApplyImageWidth(value) {
  const wrap = rteActiveImageWrap;
  if (!wrap) return;
  const img = wrap.querySelector("img");
  if (!img) return;
  if (value === "full") {
    wrap.style.width = "100%";
    img.style.width = "100%"; // survives save so "Full" round-trips on reload
  } else {
    const px = Math.max(40, Math.min(900, Math.round(Number(value) || 0)));
    if (!px) return;
    wrap.style.width = px + "px";
    img.style.width = "100%"; // CSS makes the image fill the wrapper
  }
  // Setting .style via JS doesn't fire 'input', so the live preview / undo
  // history wouldn't update - dispatch one so they refresh immediately.
  const editable = wrap.closest('[contenteditable="true"], [contenteditable=""]');
  if (editable) editable.dispatchEvent(new Event("input", { bubbles: true }));
  rteSyncSizeInput(wrap);
  rtePositionSizeBar(wrap);
}
function rteNudgeImageWidth(delta) {
  if (!rteActiveImageWrap) return;
  const cur = rteCurrentImageWidth(rteActiveImageWrap) || DEFAULT_BODY_IMAGE_WIDTH_PX;
  rteApplyImageWidth(cur + delta);
}
function rteSyncSizeInput(wrap) {
  const bar = document.getElementById("rteImageSizeBar");
  const input = bar ? bar.querySelector("#rteImageSizeInput") : null;
  if (input) input.value = String(rteCurrentImageWidth(wrap) || "");
}
/** Set/edit the clicked image's alt text (shown if the image doesn't load and
 *  read by screen readers). Persists on the <img>, so it saves and sends. */
function rteSetImageAlt() {
  const wrap = rteActiveImageWrap;
  if (!wrap) return;
  const img = wrap.querySelector("img");
  if (!img) return;
  const current = img.getAttribute("alt") || "";
  const next = window.prompt(
    "Describe this image (shown if it doesn't load, and read aloud by screen readers):",
    current
  );
  if (next === null) return; // user cancelled
  img.setAttribute("alt", next.trim());
  const editable = wrap.closest('[contenteditable="true"], [contenteditable=""]');
  if (editable) editable.dispatchEvent(new Event("input", { bubbles: true }));
}
/** Make the clicked image open a URL when the recipient clicks it in their inbox. */
function rteSetImageLink() {
  const wrap = rteActiveImageWrap;
  if (!wrap) return;
  const current = getImageWrapLinkHref(wrap);
  const next = window.prompt(
    "Link URL for this image (leave blank to remove the link).\nExample: https://crmcadence.com/signup.html",
    current || "https://"
  );
  if (next === null) return;
  setImageWrapLinkHref(wrap, next.trim());
  const editable = wrap.closest('[contenteditable="true"], [contenteditable=""]');
  if (editable) editable.dispatchEvent(new Event("input", { bubbles: true }));
  rteSyncImageLinkButton();
}
function rteSyncImageLinkButton() {
  const bar = document.getElementById("rteImageSizeBar");
  const btn = bar ? bar.querySelector("button[data-img-link]") : null;
  if (!btn) return;
  const href = getImageWrapLinkHref(rteActiveImageWrap);
  btn.textContent = href ? "Edit link" : "Add link";
  btn.title = href
    ? `Linked to ${href}. Click to change or remove.`
    : "Make this image clickable - recipients open the URL when they tap the image";
  btn.classList.toggle("is-linked", Boolean(href));
}
function rteEnsureSizeBar() {
  let bar = document.getElementById("rteImageSizeBar");
  if (bar) return bar;
  bar = document.createElement("div");
  bar.id = "rteImageSizeBar";
  bar.className = "rte-image-size-bar";
  bar.innerHTML =
    '<span class="rte-image-size-label">Image width</span>' +
    '<button type="button" data-img-step="-20" title="Smaller">&minus;</button>' +
    '<input type="number" id="rteImageSizeInput" min="40" max="900" step="10" />' +
    '<span class="rte-image-size-unit">px</span>' +
    '<button type="button" data-img-step="20" title="Larger">+</button>' +
    '<button type="button" data-img-size="full">Full width</button>' +
    '<button type="button" data-img-link="1" title="Make this image clickable">Add link</button>' +
    '<button type="button" data-img-alt="1" title="Add a text description (shown if the image fails to load, and read by screen readers)">Alt text</button>';
  // Keep the editor's image selection on button presses, but let the input focus.
  bar.addEventListener("mousedown", (event) => {
    if (event.target && event.target.id === "rteImageSizeInput") return;
    event.preventDefault();
  });
  bar.addEventListener("click", (event) => {
    const t = event.target;
    if (!t || !t.closest) return;
    if (t.closest('button[data-img-size="full"]')) { event.preventDefault(); rteApplyImageWidth("full"); return; }
    if (t.closest("button[data-img-link]")) { event.preventDefault(); rteSetImageLink(); return; }
    if (t.closest("button[data-img-alt]")) { event.preventDefault(); rteSetImageAlt(); return; }
    const step = t.closest("button[data-img-step]");
    if (step) { event.preventDefault(); rteNudgeImageWidth(Number(step.getAttribute("data-img-step")) || 0); }
  });
  const input = bar.querySelector("#rteImageSizeInput");
  input.addEventListener("change", () => rteApplyImageWidth(Number(input.value) || 0));
  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") { event.preventDefault(); rteApplyImageWidth(Number(input.value) || 0); }
  });
  document.body.appendChild(bar);
  return bar;
}
function rtePositionSizeBar(wrap) {
  const bar = rteEnsureSizeBar();
  bar.style.display = "flex";
  const r = wrap.getBoundingClientRect();
  const top = window.scrollY + r.top - bar.offsetHeight - 8;
  bar.style.top = Math.max(window.scrollY + 4, top) + "px";
  bar.style.left = window.scrollX + r.left + "px";
}
function rteShowImageSizeBar(wrap) {
  if (rteActiveImageWrap && rteActiveImageWrap !== wrap) rteActiveImageWrap.classList.remove("rte-image-selected");
  rteActiveImageWrap = wrap;
  wrap.classList.add("rte-image-selected"); // outline so you see what you're sizing
  rteSyncSizeInput(wrap);
  rteSyncImageLinkButton();
  rtePositionSizeBar(wrap);
}
function rteHideImageSizeBar() {
  if (rteActiveImageWrap) rteActiveImageWrap.classList.remove("rte-image-selected");
  rteActiveImageWrap = null;
  const bar = document.getElementById("rteImageSizeBar");
  if (bar) bar.style.display = "none";
}
if (typeof document !== "undefined") {
  document.addEventListener("click", (event) => {
    const t = event.target;
    if (t && t.closest && (t.closest(".rte-image-size-bar") || t.closest(".signature-image-wrap"))) return;
    rteHideImageSizeBar();
  });
  window.addEventListener("scroll", () => rteHideImageSizeBar(), true);
}

function insertImageIntoSignature(url) {
  const src = String(url || "").trim();
  if (!src) return;
  withSignatureEditorFocus(() => {
    const safeSrc = src.replace(/"/g, "%22");
    document.execCommand(
      "insertHTML",
      false,
      `<span class="signature-image-wrap"><img src="${safeSrc}" alt="Signature image" /></span>`
    );
  });
}

function normalizeSignatureImages() {
  if (!emailSignatureEditor) return;
  setupEditorImageDnD(emailSignatureEditor);
  normalizeWrappedImages(emailSignatureEditor);
}

function withSignatureEditorFocus(run) {
  if (!emailSignatureEditor) return;
  emailSignatureEditor.focus();
  restoreSignatureSelection();
  run();
}

function saveSignatureSelection() {
  if (!emailSignatureEditor) return;
  const selection = window.getSelection();
  if (!selection || selection.rangeCount === 0) return;
  const range = selection.getRangeAt(0);
  if (!emailSignatureEditor.contains(range.commonAncestorContainer)) return;
  savedSignatureRange = range.cloneRange();
}

function restoreSignatureSelection() {
  if (!savedSignatureRange) return;
  const selection = window.getSelection();
  if (!selection) return;
  selection.removeAllRanges();
  selection.addRange(savedSignatureRange);
}

function clearNestedFontSizeStyles(root) {
  if (!root) return;
  const elements = [];
  if (root.nodeType === Node.ELEMENT_NODE) elements.push(root);
  if (typeof root.querySelectorAll === "function") elements.push(...root.querySelectorAll("[style], font[size]"));
  for (const el of elements) {
    if (!(el instanceof Element)) continue;
    if (el.tagName === "FONT") el.removeAttribute("size");
    if (el instanceof HTMLElement && el.style.fontSize) {
      el.style.fontSize = "";
      if (!String(el.getAttribute("style") || "").trim()) el.removeAttribute("style");
    }
  }
}

function paintInlineColor(el, hex) {
  if (!(el instanceof HTMLElement)) return;
  el.style.color = hex;
  if (el.tagName === "FONT") el.setAttribute("color", hex);
}

function applyInlineTextColor(hex, rootEl) {
  const color = String(hex || "").trim();
  if (!color) return;
  const selection = window.getSelection();
  if (!selection || selection.rangeCount === 0) return;
  const range = selection.getRangeAt(0);
  if (rootEl && range.commonAncestorContainer && !rootEl.contains(range.commonAncestorContainer)) return;

  if (selection.isCollapsed) {
    const node = range.startContainer;
    if (!node || node.nodeType !== Node.TEXT_NODE) return;
    const text = String(node.textContent || "");
    const caret = Number(range.startOffset || 0);
    if (!text.trim()) return;
    let start = Math.max(0, Math.min(caret, text.length));
    let end = start;
    while (start > 0 && !/\s/.test(text[start - 1])) start -= 1;
    while (end < text.length && !/\s/.test(text[end])) end += 1;
    if (start === end) return;
    range.setStart(node, start);
    range.setEnd(node, end);
    selection.removeAllRanges();
    selection.addRange(range);
  }
  if (rootEl && range.commonAncestorContainer && !rootEl.contains(range.commonAncestorContainer)) return;

  const host =
    range.commonAncestorContainer.nodeType === Node.ELEMENT_NODE
      ? range.commonAncestorContainer
      : range.commonAncestorContainer.parentElement;
  if (
    host &&
    host !== rootEl &&
    host.tagName === "SPAN" &&
    host.childNodes.length === 1 &&
    String(host.textContent || "") === range.toString()
  ) {
    paintInlineColor(host, color);
    const anchor = host.closest("a, font");
    if (anchor && anchor !== host && rootEl && rootEl.contains(anchor) && anchor.textContent === host.textContent) {
      paintInlineColor(anchor, color);
    }
    const painted = document.createRange();
    painted.selectNodeContents(host);
    selection.removeAllRanges();
    selection.addRange(painted);
    if (rootEl) rootEl.dispatchEvent(new Event("input", { bubbles: true }));
    return;
  }

  const wrapper = document.createElement("span");
  wrapper.style.color = color;
  const moved = range.extractContents();
  const colored = [];
  const walker = document.createTreeWalker(moved, Node.ELEMENT_NODE);
  let current = walker.nextNode();
  while (current) {
    colored.push(current);
    current = walker.nextNode();
  }
  for (const el of colored) paintInlineColor(el, color);
  wrapper.appendChild(moved);
  range.insertNode(wrapper);
  const anchor = wrapper.closest("a, font");
  if (anchor && rootEl && rootEl.contains(anchor) && anchor.textContent === wrapper.textContent) {
    paintInlineColor(anchor, color);
  }
  const painted = document.createRange();
  painted.selectNodeContents(wrapper);
  selection.removeAllRanges();
  selection.addRange(painted);
  if (rootEl) rootEl.dispatchEvent(new Event("input", { bubbles: true }));
}

function applyInlineFontSize(px, rootEl) {
  const value = Number(px);
  if (!Number.isFinite(value) || value < 8 || value > 72) return;
  const selection = window.getSelection();
  if (!selection || selection.rangeCount === 0) return;
  const range = selection.getRangeAt(0);
  if (rootEl && range.commonAncestorContainer && !rootEl.contains(range.commonAncestorContainer)) return;
  if (selection.isCollapsed) {
    const node = range.startContainer;
    if (!node || node.nodeType !== Node.TEXT_NODE) return;
    const text = String(node.textContent || "");
    const caret = Number(range.startOffset || 0);
    if (!text.trim()) return;
    let start = Math.max(0, Math.min(caret, text.length));
    let end = start;
    while (start > 0 && !/\s/.test(text[start - 1])) start -= 1;
    while (end < text.length && !/\s/.test(text[end])) end += 1;
    if (start === end) return;
    range.setStart(node, start);
    range.setEnd(node, end);
    selection.removeAllRanges();
    selection.addRange(range);
  }
  if (rootEl && range.commonAncestorContainer && !rootEl.contains(range.commonAncestorContainer)) return;

  const styleProbe =
    range.startContainer && range.startContainer.nodeType === Node.TEXT_NODE
      ? range.startContainer.parentElement
      : range.startContainer instanceof Element
        ? range.startContainer
        : range.startContainer?.parentElement;
  let fontFamily = "";
  if (styleProbe && (!rootEl || rootEl.contains(styleProbe))) {
    fontFamily = String(window.getComputedStyle(styleProbe).fontFamily || "").trim();
  }

  const wrapper = document.createElement("span");
  wrapper.style.fontSize = `${Math.round(value)}px`;
  if (fontFamily) wrapper.style.fontFamily = fontFamily;
  const moved = range.extractContents();
  clearNestedFontSizeStyles(moved);
  wrapper.appendChild(moved);
  range.insertNode(wrapper);
  const newRange = document.createRange();
  newRange.setStartAfter(wrapper);
  newRange.collapse(true);
  selection.removeAllRanges();
  selection.addRange(newRange);
  if (rootEl) rootEl.dispatchEvent(new Event("input", { bubbles: true }));
}

function setImageWrapAlignment(wrap, align) {
  if (!wrap) return;
  wrap.style.display = "block";
  if (align === "center") {
    wrap.style.marginLeft = "auto";
    wrap.style.marginRight = "auto";
  } else if (align === "right") {
    wrap.style.marginLeft = "auto";
    wrap.style.marginRight = "0";
  } else {
    wrap.style.marginLeft = "0";
    wrap.style.marginRight = "auto";
  }
}

function setGridTableAlignment(tableEl, align) {
  if (!tableEl) return;
  tableEl.style.display = "table";
  // Slightly narrower than full width so left/center/right alignment is visible.
  if (!tableEl.style.width || tableEl.style.width === "100%") {
    tableEl.style.width = "96%";
  }
  if (align === "center") {
    tableEl.style.marginLeft = "auto";
    tableEl.style.marginRight = "auto";
  } else if (align === "right") {
    tableEl.style.marginLeft = "auto";
    tableEl.style.marginRight = "0";
  } else {
    tableEl.style.marginLeft = "0";
    tableEl.style.marginRight = "auto";
  }
}

function setGridCellColor(cellEl, color) {
  if (!cellEl || (cellEl.tagName !== "TD" && cellEl.tagName !== "TH")) return;
  const safe = String(color || "").trim() || "#dbe2ef";
  cellEl.style.borderColor = safe;
  cellEl.style.backgroundColor = safe;
  cellEl.style.color = "#ffffff";
}

/** Nested layouts often wrap cells in inner tables; color the outer logical grid, not a 1×1 inner table. */
function outermostEmailGridTable(node, editorEl) {
  const el = node?.nodeType === Node.ELEMENT_NODE ? node : node?.parentElement;
  let t = el?.closest?.("table.email-grid-table");
  if (!t || !editorEl.contains(t)) return null;
  for (;;) {
    const wrap = t.parentElement?.closest?.("table.email-grid-table");
    if (!wrap || !editorEl.contains(wrap)) break;
    t = wrap;
  }
  return t;
}

function gridDirectCellFromRangeEndpoint(container, editorEl) {
  const el =
    container && container.nodeType === Node.ELEMENT_NODE ? container : container?.parentElement;
  const td = el?.closest?.("td, th");
  if (!td || !editorEl.contains(td)) return null;
  const outer = outermostEmailGridTable(td, editorEl);
  if (!outer) return null;
  for (const row of outer.rows) {
    if ([...row.cells].includes(td)) return td;
  }
  return null;
}

/** Only direct cells of each outer grid (`table.rows`), so nested tables inside a cell are ignored. */
function collectGridCellsFromSelection(editorEl) {
  const selection = window.getSelection();
  const cells = new Set();
  if (!selection || selection.rangeCount === 0) return cells;
  const range = selection.getRangeAt(0);
  if (!editorEl.contains(range.commonAncestorContainer)) return cells;

  for (const t of editorEl.querySelectorAll("table.email-grid-table")) {
    const outer = outermostEmailGridTable(t, editorEl);
    if (outer !== t) continue;
    for (const row of t.rows) {
      for (const cell of row.cells) {
        try {
          if (range.intersectsNode(cell)) cells.add(cell);
        } catch {
          //
        }
      }
    }
  }
  if (!cells.size) {
    const a = gridDirectCellFromRangeEndpoint(range.startContainer, editorEl);
    const b = gridDirectCellFromRangeEndpoint(range.endContainer, editorEl);
    if (a) cells.add(a);
    if (b && b !== a) cells.add(b);
  }
  return cells;
}

function applySelectionAlignment(editorEl, align) {
  const cmd = align === "center" ? "justifyCenter" : align === "right" ? "justifyRight" : "justifyLeft";
  document.execCommand(cmd);

  const selection = window.getSelection();
  if (!selection || selection.rangeCount === 0) return;
  const range = selection.getRangeAt(0);
  const wraps = new Set();
  const gridTables = new Set();

  const addWrapFromNode = (node) => {
    if (!node || !node.closest) return;
    const w = node.closest(".signature-image-wrap");
    if (w && editorEl.contains(w)) wraps.add(w);
    const t = outermostEmailGridTable(node, editorEl);
    if (t) gridTables.add(t);
  };

  const startEl =
    range.startContainer && range.startContainer.nodeType === Node.ELEMENT_NODE
      ? range.startContainer
      : range.startContainer?.parentElement;
  const endEl =
    range.endContainer && range.endContainer.nodeType === Node.ELEMENT_NODE
      ? range.endContainer
      : range.endContainer?.parentElement;
  addWrapFromNode(startEl);
  addWrapFromNode(endEl);

  for (const w of editorEl.querySelectorAll(".signature-image-wrap")) {
    try {
      if (range.intersectsNode(w)) wraps.add(w);
    } catch {
      //
    }
  }
  for (const t of editorEl.querySelectorAll("table.email-grid-table")) {
    try {
      if (range.intersectsNode(t)) {
        const outer = outermostEmailGridTable(t, editorEl);
        if (outer) gridTables.add(outer);
      }
    } catch {
      //
    }
  }

  for (const w of wraps) setImageWrapAlignment(w, align);
  for (const t of gridTables) setGridTableAlignment(t, align);
}

/**
 * Strip formatting by replacing the selection with plain text; keeps images in document order.
 * (Browsers often ignore execCommand("removeFormat") for inline styles in contenteditable.)
 */
function flattenFragmentToPlainTextAndImages(fragment) {
  const out = document.createDocumentFragment();
  function walk(node) {
    if (!node) return;
    if (node.nodeType === Node.TEXT_NODE) {
      out.appendChild(document.createTextNode(node.nodeValue));
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return;
    const tag = node.tagName;
    if (tag === "IMG") {
      const wrap = document.createElement("span");
      wrap.className = "signature-image-wrap";
      wrap.appendChild(node.cloneNode(true));
      ensureMovableImageWrap(wrap);
      out.appendChild(wrap);
      return;
    }
    if (tag === "BR") {
      out.appendChild(document.createTextNode("\n"));
      return;
    }
    for (const ch of [...node.childNodes]) walk(ch);
  }
  for (const ch of [...fragment.childNodes]) walk(ch);
  return out;
}

function clearRichEditorFormatting(editorEl) {
  if (!editorEl) return;
  editorEl.focus();
  const sel = window.getSelection();
  let range;
  if (!sel || sel.rangeCount === 0) {
    range = document.createRange();
    range.selectNodeContents(editorEl);
    sel?.removeAllRanges();
    sel?.addRange(range);
  } else {
    range = sel.getRangeAt(0);
    if (range.collapsed) {
      range = document.createRange();
      range.selectNodeContents(editorEl);
      sel.removeAllRanges();
      sel.addRange(range);
    }
  }
  if (!editorEl.contains(range.commonAncestorContainer)) return;

  const extracted = range.extractContents();
  const flat = flattenFragmentToPlainTextAndImages(extracted);
  range.insertNode(flat);

  normalizeWrappedImages(editorEl);

  const endRange = document.createRange();
  endRange.selectNodeContents(editorEl);
  endRange.collapse(false);
  sel?.removeAllRanges();
  sel?.addRange(endRange);
}

/**
 * Rich editors for email body / template (same patterns as signature: bold, links, images, etc.).
 */
function findSelectionAnchorInEditor(editorEl) {
  const sel = window.getSelection();
  if (!sel || sel.rangeCount === 0) return null;
  const range = sel.getRangeAt(0);
  if (!editorEl.contains(range.commonAncestorContainer)) return null;

  const findAnchorUp = (node) => {
    let cur = node instanceof Element ? node : node?.parentElement;
    while (cur) {
      if (cur.tagName === "A") return cur;
      if (cur === editorEl) break;
      cur = cur.parentElement;
    }
    return null;
  };

  return findAnchorUp(range.startContainer) || findAnchorUp(range.endContainer) || null;
}

function isCadenceCtaButton(anchor) {
  if (!anchor || anchor.tagName !== "A") return false;
  if (String(anchor.getAttribute("data-cadence-cta") || "") === "1") return true;
  const style = String(anchor.getAttribute("style") || "");
  return (
    /display\s*:\s*inline-block/i.test(style) &&
    /padding/i.test(style) &&
    (/border-radius/i.test(style) || /background/i.test(style))
  );
}

function markCadenceCtaButton(anchor) {
  if (!anchor || anchor.tagName !== "A") return;
  anchor.setAttribute("data-cadence-cta", "1");
  anchor.style.textDecoration = "none";
  if (!String(anchor.getAttribute("style") || "").match(/display\s*:/i)) {
    anchor.style.display = "inline-block";
  }
}

function normalizeCadenceCtaButtonsInEditor(editorEl) {
  if (!editorEl) return;
  editorEl.querySelectorAll("a[href]").forEach((anchor) => {
    if (isCadenceCtaButton(anchor)) markCadenceCtaButton(anchor);
  });
}

function updateEditorLinkHref(editorEl, href) {
  const trimmed = String(href || "").trim();
  if (!trimmed) return false;
  const anchor = findSelectionAnchorInEditor(editorEl);
  if (!anchor || !editorEl.contains(anchor)) return false;
  anchor.setAttribute("href", trimmed);
  if (isCadenceCtaButton(anchor)) markCadenceCtaButton(anchor);
  return true;
}

function wireRichEditor(editorEl, tools) {
  if (!editorEl || !tools) return;
  const maxGridRowsCap =
    Number.isFinite(Number(tools.maxGridRows)) && Number(tools.maxGridRows) >= 1
      ? Math.min(20, Math.max(1, Math.floor(Number(tools.maxGridRows))))
      : 6;
  setupEditorImageDnD(editorEl);
  let savedRange = null;
  function selectedHtmlWithinEditor() {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return "";
    const range = sel.getRangeAt(0);
    if (!editorEl.contains(range.commonAncestorContainer)) return "";
    const holder = document.createElement("div");
    holder.appendChild(range.cloneContents());
    return holder.innerHTML;
  }
  function saveSel() {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return;
    const range = sel.getRangeAt(0);
    if (!editorEl.contains(range.commonAncestorContainer)) return;
    savedRange = range.cloneRange();
  }
  function restoreSel() {
    if (!savedRange) return;
    const sel = window.getSelection();
    if (!sel) return;
    sel.removeAllRanges();
    sel.addRange(savedRange);
  }
  function withFocus(run) {
    editorEl.focus();
    restoreSel();
    run();
  }
  function findSelectionLinkHref() {
    const anchor = findSelectionAnchorInEditor(editorEl);
    if (anchor?.getAttribute("href")) return String(anchor.getAttribute("href") || "").trim();

    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return "";
    const range = sel.getRangeAt(0);
    if (!editorEl.contains(range.commonAncestorContainer)) return "";

    if (!range.collapsed) {
      const cloned = document.createElement("div");
      cloned.appendChild(range.cloneContents());
      const clonedAnchor = cloned.querySelector("a[href]");
      if (clonedAnchor?.getAttribute("href")) return String(clonedAnchor.getAttribute("href") || "").trim();
    }
    return "";
  }
  function insertGrid(cols, rows) {
    const safeCols = Math.min(4, Math.max(1, Number.parseInt(String(cols), 10) || 0));
    const safeRows = Math.min(maxGridRowsCap, Math.max(1, Number.parseInt(String(rows), 10) || 0));
    if (!safeCols || !safeRows) return;
    const cellPercent = (100 / safeCols).toFixed(2);
    const gridBorderColor = String(tools?.gridColorInput?.value || "#dbe2ef").trim() || "#dbe2ef";
    const rowHtml = `<tr>${new Array(safeCols)
      .fill(
        `<td style="width:${cellPercent}%;border:1px solid ${gridBorderColor};background-color:${gridBorderColor};color:#ffffff;padding:8px;vertical-align:top;">&nbsp;</td>`
      )
      .join("")}</tr>`;
    const tableHtml = `<table class="email-grid-table" role="presentation" cellspacing="0" cellpadding="0" border="0" style="width:96%;border-collapse:collapse;table-layout:fixed;margin:8px 0;">${new Array(
      safeRows
    )
      .fill(rowHtml)
      .join("")}</table><p><br></p>`;
    document.execCommand("insertHTML", false, tableHtml);
  }
  function normalizeImages() {
    normalizeWrappedImages(editorEl);
  }
  function reapplyBodyImageMaxIfNeeded() {
    const m = tools?.bodyImageMaxWidthPx;
    if (m == null || !Number.isFinite(Number(m)) || Number(m) < 1) return;
    editorEl.innerHTML = clampBodyImageHtml(editorEl.innerHTML, Number(m));
    normalizeWrappedImages(editorEl);
  }
  function insertCadenceRobotImage() {
    const src = getCadenceAiRobotEmailImageUrl();
    if (!src) return;
    withFocus(() => {
      const safeSrc = src.replace(/"/g, "%22");
      const safeAlt = escapeHtml(CADENCE_AI_ROBOT_EMAIL_ALT);
      document.execCommand(
        "insertHTML",
        false,
        `<span class="signature-image-wrap"><img src="${safeSrc}" alt="${safeAlt}" style="width:${CADENCE_AI_ROBOT_EMAIL_WIDTH_PX}px;max-width:100%;height:auto;display:inline-block" /></span>`
      );
    });
    normalizeImages();
    reapplyBodyImageMaxIfNeeded();
  }
  function insertImage(url) {
    const src = String(url || "").trim();
    if (!src) return;
    withFocus(() => {
      const safeSrc = src.replace(/"/g, "%22");
      document.execCommand(
        "insertHTML",
        false,
        `<span class="signature-image-wrap"><img src="${safeSrc}" alt="" /></span>`
      );
    });
    normalizeImages();
    reapplyBodyImageMaxIfNeeded();
  }

  editorEl.addEventListener("mouseup", saveSel);
  editorEl.addEventListener("keyup", saveSel);
  editorEl.addEventListener("focus", saveSel);
  editorEl.addEventListener("click", (event) => {
    const anchor = event.target?.closest?.("a");
    if (anchor && editorEl.contains(anchor)) event.preventDefault();
  });
  document.addEventListener("selectionchange", () => {
    const sel = window.getSelection();
    if (!sel?.rangeCount || !sel.anchorNode || !editorEl.contains(sel.anchorNode)) return;
    saveSel();
  });
  editorEl.addEventListener("input", () => {
    normalizeImages();
    normalizeCadenceCtaButtonsInEditor(editorEl);
    saveSel();
  });
  editorEl.addEventListener("paste", async (event) => {
    const clipboardItems = event.clipboardData?.items ? [...event.clipboardData.items] : [];
    const imageItem = clipboardItems.find((item) => String(item.type || "").startsWith("image/"));
    if (imageItem) {
      event.preventDefault();
      const file = imageItem.getAsFile();
      if (!file) return;
      try {
        const dataUrl = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(String(reader.result || ""));
          reader.onerror = () => reject(new Error("Failed to paste image"));
          reader.readAsDataURL(file);
        });
        withFocus(() => document.execCommand("insertImage", false, dataUrl));
        normalizeImages();
        reapplyBodyImageMaxIfNeeded();
      } catch {
        //
      }
      return;
    }

    // Clipboard often carries image HTML (not File items), e.g. copy/cut from rich editors.
    const html = String(event.clipboardData?.getData("text/html") || "");
    if (/<img[\s>]/i.test(html)) {
      event.preventDefault();
      withFocus(() => document.execCommand("insertHTML", false, html));
      normalizeImages();
      reapplyBodyImageMaxIfNeeded();
    }
  });
  editorEl.addEventListener("copy", (event) => {
    const html = selectedHtmlWithinEditor();
    if (!html || !/<img[\s>]/i.test(html)) return;
    try {
      event.clipboardData?.setData("text/html", html);
      event.clipboardData?.setData("text/plain", "[Image]");
      event.preventDefault();
    } catch {
      //
    }
  });
  editorEl.addEventListener("cut", (event) => {
    const html = selectedHtmlWithinEditor();
    if (!html || !/<img[\s>]/i.test(html)) return;
    try {
      event.clipboardData?.setData("text/html", html);
      event.clipboardData?.setData("text/plain", "[Image]");
      event.preventDefault();
      withFocus(() => document.execCommand("delete", false));
      normalizeImages();
      reapplyBodyImageMaxIfNeeded();
    } catch {
      //
    }
  });

  const {
    boldBtn,
    italicBtn,
    underlineBtn,
    alignLeftBtn,
    alignCenterBtn,
    alignRightBtn,
    linkBtn,
    bulletListBtn,
    numberListBtn,
    insert2ColBtn,
    insert3ColBtn,
    insertGridBtn,
    insertPhotoBtn,
    insertGraphicUrlBtn,
    fontFamilySelect,
    inlineColor,
    inlineFontSize,
    gridColorInput,
    applyGridColorBtn,
    clearBtn,
    imageUrlInput,
    imageFileInput,
    addImageUrlBtn
  } = tools;

  if (boldBtn) {
    boldBtn.addEventListener("mousedown", (e) => e.preventDefault());
    boldBtn.addEventListener("click", () => withFocus(() => document.execCommand("bold")));
  }
  if (italicBtn) {
    italicBtn.addEventListener("mousedown", (e) => e.preventDefault());
    italicBtn.addEventListener("click", () => withFocus(() => document.execCommand("italic")));
  }
  if (underlineBtn) {
    underlineBtn.addEventListener("mousedown", (e) => e.preventDefault());
    underlineBtn.addEventListener("click", () => withFocus(() => document.execCommand("underline")));
  }
  if (alignLeftBtn) {
    alignLeftBtn.addEventListener("mousedown", (e) => e.preventDefault());
    alignLeftBtn.addEventListener("click", () => withFocus(() => applySelectionAlignment(editorEl, "left")));
  }
  if (alignCenterBtn) {
    alignCenterBtn.addEventListener("mousedown", (e) => e.preventDefault());
    alignCenterBtn.addEventListener("click", () => withFocus(() => applySelectionAlignment(editorEl, "center")));
  }
  if (alignRightBtn) {
    alignRightBtn.addEventListener("mousedown", (e) => e.preventDefault());
    alignRightBtn.addEventListener("click", () => withFocus(() => applySelectionAlignment(editorEl, "right")));
  }
  if (linkBtn) {
    linkBtn.addEventListener("mousedown", (e) => e.preventDefault());
    linkBtn.addEventListener("click", () =>
      withFocus(() => {
        const imageWrap =
          (rteActiveImageWrap && editorEl.contains(rteActiveImageWrap) && rteActiveImageWrap) ||
          (() => {
            const sel = window.getSelection();
            if (!sel || sel.rangeCount === 0) return null;
            const node = sel.anchorNode;
            const el = node && node.nodeType === Node.ELEMENT_NODE ? node : node?.parentElement;
            return el?.closest?.(".signature-image-wrap") || null;
          })();
        if (imageWrap && editorEl.contains(imageWrap)) {
          rteActiveImageWrap = imageWrap;
          rteSetImageLink();
          return;
        }
        const existingHref = findSelectionLinkHref();
        const href = window.prompt("Enter link URL:", existingHref || "https://");
        if (!href || !href.trim()) return;
        if (!updateEditorLinkHref(editorEl, href.trim())) {
          document.execCommand("createLink", false, href.trim());
          const createdAnchor = findSelectionAnchorInEditor(editorEl);
          if (createdAnchor && isCadenceCtaButton(createdAnchor)) markCadenceCtaButton(createdAnchor);
        }
      })
    );
  }
  if (bulletListBtn) {
    bulletListBtn.addEventListener("mousedown", (e) => e.preventDefault());
    bulletListBtn.addEventListener("click", () => withFocus(() => document.execCommand("insertUnorderedList")));
  }
  if (numberListBtn) {
    numberListBtn.addEventListener("mousedown", (e) => e.preventDefault());
    numberListBtn.addEventListener("click", () => withFocus(() => document.execCommand("insertOrderedList")));
  }
  if (insert2ColBtn) {
    insert2ColBtn.addEventListener("mousedown", (e) => e.preventDefault());
    insert2ColBtn.addEventListener("click", () => withFocus(() => insertGrid(2, 1)));
  }
  if (insert3ColBtn) {
    insert3ColBtn.addEventListener("mousedown", (e) => e.preventDefault());
    insert3ColBtn.addEventListener("click", () => withFocus(() => insertGrid(3, 1)));
  }
  if (insertGridBtn) {
    insertGridBtn.addEventListener("mousedown", (e) => e.preventDefault());
    insertGridBtn.addEventListener("click", () =>
      withFocus(() => {
        const colsRaw = window.prompt("Grid columns (1-4):", "2");
        if (colsRaw == null) return;
        const rowsRaw = window.prompt(`Grid rows (1-${maxGridRowsCap}):`, "2");
        if (rowsRaw == null) return;
        insertGrid(colsRaw, rowsRaw);
      })
    );
  }
  if (inlineColor) {
    if (editorEl === templateBodyEditor) {
      inlineColor.addEventListener("pointerdown", () => captureTemplateBodyToolbarRange({ keepHighlight: true }));
    } else if (editorEl === emailBodyEditor) {
      inlineColor.addEventListener("pointerdown", () => captureEmailBodyToolbarRange({ keepHighlight: true }));
    }
    const applyTextColor = () => {
      const hex = inlineColor.value || "#1f2937";
      const run = () => applyInlineTextColor(hex, editorEl);
      if (editorEl === templateBodyEditor) withTemplateBodyToolbarFocus(run);
      else if (editorEl === emailBodyEditor) withEmailBodyToolbarFocus(run);
      else withFocus(run);
    };
    inlineColor.addEventListener("change", applyTextColor);
    inlineColor.addEventListener("input", applyTextColor);
  }
  const isTemplateRichEditor = editorEl === templateBodyEditor;
  if (fontFamilySelect) {
    if (isTemplateRichEditor) {
      fontFamilySelect.addEventListener("pointerdown", () => captureTemplateBodyToolbarRange());
    }
    fontFamilySelect.addEventListener("change", () => {
      const fam = String(fontFamilySelect.value || "").trim();
      if (!fam) return;
      const apply = () => {
        try {
          document.execCommand("styleWithCSS", false, "true");
        } catch {
          //
        }
        document.execCommand("fontName", false, fam);
      };
      if (isTemplateRichEditor) withTemplateBodyToolbarFocus(apply);
      else withFocus(apply);
    });
  }
  if (gridColorInput) {
    gridColorInput.addEventListener("mousedown", (e) => e.preventDefault());
  }
  if (applyGridColorBtn && gridColorInput) {
    applyGridColorBtn.addEventListener("mousedown", (e) => e.preventDefault());
    applyGridColorBtn.addEventListener("click", () =>
      withFocus(() => {
        const selectedCells = collectGridCellsFromSelection(editorEl);
        const color = String(gridColorInput.value || "#dbe2ef").trim() || "#dbe2ef";
        if (selectedCells.size) {
          for (const cell of selectedCells) setGridCellColor(cell, color);
          return;
        }
        if (!editorEl.querySelector("table.email-grid-table")) {
          showMessage("Insert a grid first, then apply a grid color.", true);
          return;
        }
        showMessage("Click inside the grid cell (or select multiple cells), then Color Grid.", true);
      })
    );
  }
  if (inlineFontSize) {
    if (isTemplateRichEditor) {
      inlineFontSize.addEventListener("pointerdown", () => captureTemplateBodyToolbarRange());
    }
    inlineFontSize.addEventListener("change", () => {
      const px = inlineFontSize.value;
      if (!px) return;
      if (isTemplateRichEditor) withTemplateBodyToolbarFocus(() => applyInlineFontSize(px, editorEl));
      else withFocus(() => applyInlineFontSize(px, editorEl));
    });
  }
  if (clearBtn) {
    clearBtn.addEventListener("mousedown", (e) => e.preventDefault());
    clearBtn.addEventListener("click", () =>
      withFocus(() => {
        clearRichEditorFormatting(editorEl);
        saveSel();
      })
    );
  }
  if (addImageUrlBtn && imageUrlInput) {
    addImageUrlBtn.addEventListener("click", () => {
      const url = String(imageUrlInput.value || "").trim();
      if (!url) {
        showMessage("Enter an image URL first.", true);
        return;
      }
      insertImage(url);
      showMessage("Image added.");
    });
  }
  if (insertGraphicUrlBtn && imageUrlInput) {
    insertGraphicUrlBtn.addEventListener("click", () => {
      const current = String(imageUrlInput.value || "").trim() || "https://";
      const url = String(window.prompt("Enter image URL:", current) || "").trim();
      if (!url || url === "https://") return;
      imageUrlInput.value = url;
      insertImage(url);
      showMessage("Graphic added.");
    });
  }
  if (insertPhotoBtn && imageFileInput) {
    insertPhotoBtn.addEventListener("click", () => imageFileInput.click());
  }
  if (imageUrlInput) {
    imageUrlInput.addEventListener("keydown", (event) => {
      if (event.key !== "Enter") return;
      event.preventDefault();
      const url = String(imageUrlInput.value || "").trim();
      if (!url) return;
      insertImage(url);
      showMessage("Image added.");
    });
  }
  if (imageFileInput) {
    imageFileInput.addEventListener("change", async () => {
      const file = imageFileInput.files?.[0];
      if (!file) return;
      try {
        const dataUrl = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(String(reader.result || ""));
          reader.onerror = () => reject(new Error(`Failed to read image ${file.name}`));
          reader.readAsDataURL(file);
        });
        insertImage(dataUrl);
        showMessage("Photo added.");
        imageFileInput.value = "";
      } catch (error) {
        showMessage(error.message || "Failed to add photo.", true);
      }
    });
  }
  if (tools.insertRobotBtn) {
    tools.insertRobotBtn.addEventListener("mousedown", (e) => e.preventDefault());
    tools.insertRobotBtn.addEventListener("click", () => {
      if (!isOwnerWorkspaceUi()) return;
      insertCadenceRobotImage();
      if (typeof showMessage === "function") showMessage("Cadence robot added.");
    });
  }
}

function textToHtmlLines(value) {
  return escapeHtml(String(value || "")).replace(/\r?\n/g, "<br>");
}

function setRichEditorContent(editorEl, raw) {
  if (!editorEl) return;
  const s = String(raw || "");
  if (!s) {
    editorEl.innerHTML = "";
    return;
  }
  if (/<[a-z][\s\S]*>/i.test(s)) editorEl.innerHTML = s;
  else editorEl.innerHTML = textToHtmlLines(s);
  if (editorEl === templateBodyEditor) {
    editorEl.dispatchEvent(new Event("input", { bubbles: true }));
  }
}

function richEditorHasMeaningfulContent(editorEl) {
  if (!editorEl) return false;
  const html = String(editorEl.innerHTML || "").trim();
  const text = String(editorEl.textContent || "").trim();
  return signatureEditorHasContent(html, text);
}

/** True if the signature editor has visible content (text, images, or non-empty HTML). */
function signatureEditorHasContent(htmlRaw, plainText) {
  if (String(plainText || "").trim()) return true;
  const raw = String(htmlRaw || "").trim();
  if (!raw) return false;
  if (/<img[\s>]/i.test(raw)) return true;
  const stripped = raw
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
  return stripped.length > 0;
}

function getTemplateOptionField(attr) {
  if (!templateSelect?.value) return "";
  const sel = templateSelect.options[templateSelect.selectedIndex];
  return sel ? String(sel.getAttribute(attr) || "").trim() : "";
}

/** HTML for email body: editor content, or selected template when editor is empty. */
function getEffectiveEmailBodyHtml() {
  if (richEditorHasMeaningfulContent(emailBodyEditor)) {
    return String(emailBodyEditor.innerHTML || "").trim();
  }
  const fromTpl = getTemplateOptionField("data-body");
  return fromTpl ? String(fromTpl) : "";
}

/** Plain text for multipart/alternative and activity logs. */
function getEffectiveEmailBodyPlain() {
  const html = getEffectiveEmailBodyHtml();
  if (!html) return "";
  const div = document.createElement("div");
  div.innerHTML = html;
  let t = String(div.textContent || "")
    .replace(/\u00a0/g, " ")
    .trim();
  if (!t && /<img[\s>]/i.test(html)) return "[Images in message]";
  return t;
}

/** Subject for sending: input, or selected template subject if empty. */
function getEffectiveSubject() {
  let subject = String(subjectInput?.value || "").trim();
  if (!subject) {
    const fromTpl = getTemplateOptionField("data-subject");
    if (fromTpl) subject = fromTpl;
  }
  return subject;
}

/** True after the user edits To; blocks loadContacts from overwriting their input. */
let composeToFieldTouched = false;
/** True after the user edits CC; prevents auto cleanup of mirrored values. */
let composeCcFieldTouched = false;
/** Tracks selected From value to detect accidental CC mirroring. */
let lastFromAddressValue = "";

function parseToRecipientList(raw) {
  const out = [];
  const seen = new Set();
  const parts = String(raw || "")
    .split(/[,;\n\r]+/)
    .map((s) => s.trim())
    .filter(Boolean);
  for (const piece of parts) {
    const em = extractEmailAddress(piece);
    if (!em || seen.has(em)) continue;
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) continue;
    seen.add(em);
    out.push(em);
  }
  return out;
}

function normalizeCommaSeparatedEmails(raw) {
  return parseToRecipientList(raw).join(", ");
}

function maybeClearMirroredCcFromAddress(nextFromRaw = "") {
  if (!emailCcInput || composeCcFieldTouched) return;
  const ccNorm = normalizeCommaSeparatedEmails(String(emailCcInput.value || ""));
  if (!ccNorm) return;
  const prevFromNorm = normalizeCommaSeparatedEmails(lastFromAddressValue);
  const nextFromNorm = normalizeCommaSeparatedEmails(nextFromRaw);
  if ((prevFromNorm && ccNorm === prevFromNorm) || (nextFromNorm && ccNorm === nextFromNorm)) {
    emailCcInput.value = "";
  }
}

function maybeClearMirroredCcFromTo(nextToRaw = "") {
  if (!emailCcInput || composeCcFieldTouched) return;
  const ccNorm = normalizeCommaSeparatedEmails(String(emailCcInput.value || ""));
  if (!ccNorm) return;
  const toNorm = normalizeCommaSeparatedEmails(nextToRaw);
  if (toNorm && ccNorm === toNorm) {
    emailCcInput.value = "";
  }
}

function extractEmailAddress(raw) {
  const s = String(raw || "").trim();
  if (!s) return "";
  const angled = s.match(/<([^>]+@[^>]+)>/);
  if (angled) return String(angled[1] || "").trim().toLowerCase();
  const found = s.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
  return found ? String(found[0] || "").trim().toLowerCase() : s.toLowerCase();
}

function firstRecipientEmailFromToField() {
  const list = parseToRecipientList(toManualInput?.value || "");
  return list[0] || "";
}

function splitFirstLastName(fullName) {
  const name = String(fullName || "").trim();
  if (!name) return { first: "", last: "" };
  const parts = name.split(/\s+/).filter(Boolean);
  if (!parts.length) return { first: "", last: "" };
  return {
    first: parts[0] || "",
    last: parts.slice(1).join(" ")
  };
}

/**
 * `good_through` is computed dynamically: today + 7 days, formatted as
 * "Month Day, Year" (e.g. "May 18, 2026"). Mirrors src/mergeFields.js so the
 * preview shown in the composer matches what the server renders at send time.
 */
function computeGoodThroughDate(daysFromToday = 7, baseDate = new Date()) {
  const base = baseDate instanceof Date && !Number.isNaN(baseDate.getTime()) ? baseDate : new Date();
  const target = new Date(base.getFullYear(), base.getMonth(), base.getDate() + daysFromToday);
  try {
    return target.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  } catch {
    const pad = (n) => String(n).padStart(2, "0");
    return `${target.getFullYear()}-${pad(target.getMonth() + 1)}-${pad(target.getDate())}`;
  }
}

/** Mirrors src/mergeFields.js - `coverage_start_date` as MM/DD/YYYY. */
function formatCoverageStartDateForMerge(raw) {
  const s = String(raw || "").trim();
  if (!s) return "";
  let m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (m) return `${m[2]}/${m[3]}/${m[1]}`;
  m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(s);
  if (m) {
    const mo = String(Number(m[1])).padStart(2, "0");
    const da = String(Number(m[2])).padStart(2, "0");
    return `${mo}/${da}/${m[3]}`;
  }
  return s;
}

function contactToMergeFields(data, fallbackEmail = "") {
  const row = data && typeof data === "object" ? data : {};
  const fullName = String(row.full_name || "").trim();
  const firstName = String(row.first_name || "").trim();
  const lastName = String(row.last_name || "").trim();
  const split = splitFirstLastName(fullName);
  return {
    full_name: fullName,
    first_name: firstName || split.first,
    last_name: lastName || split.last,
    age: String(row.age || "").trim(),
    email: String(row.email || "").trim() || fallbackEmail,
    phone: String(row.phone || "").trim(),
    state: String(row.state || "").trim(),
    date_of_contact: String(row.date_of_contact || "").trim(),
    quote: String(row.quote || "").trim(),
    app_id: String(row.app_id || "").trim(),
    policy_number: String(row.app_id || row.policy_number || "").trim(),
    coverage_start_date: formatCoverageStartDateForMerge(String(row.coverage_start_date || "").trim()),
    policy_renewal: formatCoverageStartDateForMerge(String(row.policy_renewal || row.policy_renewal_date || "").trim()),
    upon_approval: String(row.upon_approval || "").trim(),
    vcall: String(row.vcall || "").trim(),
    insurance_type: String(row.insurance_type || "").trim(),
    good_through: computeGoodThroughDate(7)
  };
}

function parseContactCustomFieldValuesClient(raw) {
  if (!raw) return {};
  if (typeof raw === "object" && !Array.isArray(raw)) return sanitizeContactCustomFieldMap(raw);
  const text = String(raw).trim();
  if (!text) return {};
  try {
    return sanitizeContactCustomFieldMap(JSON.parse(text));
  } catch {
    return {};
  }
}

function sanitizeContactCustomFieldMap(obj) {
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return {};
  const out = {};
  for (const [key, value] of Object.entries(obj)) {
    const slug = normalizeMergeKeySlug(key);
    if (!slug) continue;
    out[slug] = String(value == null ? "" : value);
  }
  return out;
}

function cacheContactMergeFields(row, fallbackEmail = "") {
  if (!row || typeof row !== "object") return null;
  const fields = contactToMergeFields(row, fallbackEmail);
  const extra = parseContactCustomFieldValuesClient(row.custom_fields);
  const id = Number(row.id || 0);
  if (Number.isInteger(id) && id > 0) {
    emailContactMergeCacheById.set(id, fields);
    emailContactCustomFieldsById.set(id, extra);
  }
  if (fields.email) {
    const emailKey = String(fields.email).trim().toLowerCase();
    emailContactMergeCacheByEmail.set(emailKey, fields);
    emailContactCustomFieldsByEmail.set(emailKey, extra);
    if (Number.isInteger(id) && id > 0) emailContactIdByEmail.set(emailKey, id);
  }
  return fields;
}

function resolvePrimaryContactIdForSend() {
  const firstEmail = firstRecipientEmailFromToField();
  if (firstEmail) {
    const byEmail = emailContactIdByEmail.get(firstEmail);
    if (Number.isInteger(byEmail) && byEmail > 0) return byEmail;
  }
  const queryIds = getInitialContactIdsFromQuery();
  const fromQuery = Number(queryIds[0] || 0);
  if (Number.isInteger(fromQuery) && fromQuery > 0) return fromQuery;
  return 0;
}

function hasMeaningfulMergeFields(fields) {
  const f = fields && typeof fields === "object" ? fields : {};
  return Boolean(
    String(f.full_name || "").trim() ||
      String(f.first_name || "").trim() ||
      String(f.last_name || "").trim() ||
      String(f.email || "").trim()
  );
}

async function getSelectedContactMergeFields() {
  const firstManualEmail = firstRecipientEmailFromToField();
  const fallback = {
    full_name: "",
    first_name: "",
    last_name: "",
    age: "",
    email: firstManualEmail,
    phone: "",
    state: "",
    date_of_contact: "",
    quote: "",
    app_id: "",
    policy_number: "",
    coverage_start_date: "",
    policy_renewal: "",
    upon_approval: "",
    vcall: "",
    insurance_type: "",
    good_through: computeGoodThroughDate(7)
  };
  if (firstManualEmail) {
    const cachedByEmail = emailContactMergeCacheByEmail.get(firstManualEmail.toLowerCase());
    if (cachedByEmail) return { ...fallback, ...cachedByEmail };
    try {
      const { response, data } = await fetchApiJson(
        `/api/contacts?q=${encodeURIComponent(firstManualEmail)}&searchBy=email&page=1&limit=5`
      );
      const items = Array.isArray(data?.items) ? data.items : Array.isArray(data) ? data : [];
      const match = items.find(
        (row) => String(row?.email || "").trim().toLowerCase() === firstManualEmail.toLowerCase()
      );
      if (response.ok && match) {
        const fields = cacheContactMergeFields(match, firstManualEmail);
        return { ...fallback, ...fields };
      }
    } catch {
      // Manual recipients that are not CRM contacts keep the email-only fallback.
    }
  }
  const queryContactIds = getInitialContactIdsFromQuery();
  const selectedId = Number(queryContactIds[0] || 0);
  if (Number.isInteger(selectedId) && selectedId > 0) {
    const cached = emailContactMergeCacheById.get(selectedId);
    if (cached) return { ...fallback, ...cached };
    try {
      const { response, data } = await fetchApiJson(`/api/contacts/${encodeURIComponent(selectedId)}`);
      if (!response.ok || !data || typeof data !== "object") return fallback;
      const fields = cacheContactMergeFields(data, fallback.email);
      return { ...fallback, ...fields };
    } catch {
      return fallback;
    }
  }
  return fallback;
}

/**
 * Built-in merge fields are resolved against a fixed allowlist regex below.
 * Custom merge fields (defined by the user in Settings) are resolved in a
 * second pass against this in-memory cache. The cache is hydrated by
 * `refreshCustomMergeFieldsCache()` on page load and after Settings updates.
 */
let customMergeFieldsMap = {};

function normalizeMergeKeySlug(raw) {
  return String(raw || "")
    .toLowerCase()
    .replace(/[\s-]+/g, "_")
    .replace(/[^a-z0-9_]/g, "")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "");
}

const BUILT_IN_MERGE_FIELD_SLUGS = new Set([
  "full_name",
  "first_name",
  "last_name",
  "age",
  "email",
  "phone",
  "state",
  "date_of_contact",
  "quote",
  "app_id",
  "policy_number",
  "coverage_start_date",
  "policy_renewal",
  "policy_renewal_date",
  "polcy_renewal",
  "upon_approval",
  "vcall",
  "insurance_type",
  "good_through",
  "unsubscribe_url"
]);

const BUILT_IN_MERGE_FIELD_OPTIONS = [
  { slug: "full_name", label: "Full name" },
  { slug: "first_name", label: "First name" },
  { slug: "last_name", label: "Last name" },
  { slug: "age", label: "Age" },
  { slug: "email", label: "Email" },
  { slug: "phone", label: "Phone" },
  { slug: "state", label: "State" },
  { slug: "date_of_contact", label: "Date of contact" },
  { slug: "quote", label: "Quote" },
  { slug: "policy_number", label: "Policy number" },
  { slug: "coverage_start_date", label: "Coverage start date" },
  { slug: "policy_renewal", label: "Policy renewal date" },
  { slug: "upon_approval", label: "Upon approval" },
  { slug: "vcall", label: "Verification call" },
  { slug: "insurance_type", label: "Insurance type" },
  { slug: "good_through", label: "Good through (today + 7 days)" },
  { slug: "unsubscribe_url", label: "One-click unsubscribe link (auto-filled on send)" }
];

async function refreshCustomMergeFieldsCache() {
  try {
    const { response, data } = await fetchApiJson("/api/custom-merge-fields");
    if (!response.ok) {
      console.warn("[email] custom merge fields:", (data && data.error) || response.status);
      return;
    }
    if (!Array.isArray(data)) return;
    const next = {};
    const rowsForDropdown = [];
    for (const row of data) {
      const slug = normalizeMergeKeySlug(row?.field_key);
      if (!slug || BUILT_IN_MERGE_FIELD_SLUGS.has(slug)) continue;
      const scope = String(row.field_scope || "shared").toLowerCase();
      next[slug] = scope === "contact" ? "" : String(row.field_value == null ? "" : row.field_value);
      rowsForDropdown.push({ slug, label: String(row.label || "") });
    }
    customMergeFieldsMap = next;
    rebuildMergeFieldDropdown(templateMergeFieldSelect, rowsForDropdown, "Insert merge field...");
    rebuildMergeFieldDropdown(emailComposeMergeFieldSelect, rowsForDropdown, "Merge field...");
  } catch {
    // Network errors leave the previous cache intact (best effort).
  }
}

/**
 * Rebuild merge-field dropdown (built-ins + custom). Uses disabled header rows
 * instead of optgroup so options stay visible on Windows toolbar selects.
 */
function rebuildMergeFieldDropdown(selectEl, customRows, placeholderText) {
  if (!selectEl) return;
  const placeholder = String(placeholderText || "Merge field...").trim() || "Merge field...";
  selectEl.innerHTML = "";
  const ph = document.createElement("option");
  ph.value = "";
  ph.textContent = placeholder;
  selectEl.appendChild(ph);
  for (const def of BUILT_IN_MERGE_FIELD_OPTIONS) {
    const token = `{{${def.slug}}}`;
    const opt = document.createElement("option");
    opt.value = token;
    opt.className = "email-merge-field-option";
    opt.textContent = def.label ? `${token} - ${def.label}` : token;
    selectEl.appendChild(opt);
  }
  const rows = Array.isArray(customRows) ? customRows : [];
  if (!rows.length) return;
  const header = document.createElement("option");
  header.disabled = true;
  header.className = "email-merge-field-group-label";
  header.textContent = "Merge fields";
  selectEl.appendChild(header);
  for (const row of rows) {
    const slug = normalizeMergeKeySlug(row?.slug || row?.field_key);
    if (!slug || BUILT_IN_MERGE_FIELD_SLUGS.has(slug)) continue;
    const token = `{{${slug}}}`;
    const opt = document.createElement("option");
    opt.value = token;
    opt.className = "email-merge-field-option";
    opt.textContent = row.label ? `${token} - ${row.label}` : token;
    selectEl.appendChild(opt);
  }
}

function getCustomMergeFieldsMap() {
  const base = { ...customMergeFieldsMap };
  const id = resolvePrimaryContactIdForSend();
  let extra = {};
  if (Number.isInteger(id) && id > 0 && emailContactCustomFieldsById.has(id)) {
    extra = emailContactCustomFieldsById.get(id) || {};
  } else {
    const email = firstRecipientEmailFromToField();
    if (email) extra = emailContactCustomFieldsByEmail.get(email.toLowerCase()) || {};
  }
  return { ...base, ...extra };
}

function prepareTextForMergeFields(raw) {
  let s = String(raw || "")
    .replace(/&#123;/g, "{")
    .replace(/&#125;/g, "}")
    .replace(/&lcub;/gi, "{")
    .replace(/&rcub;/gi, "}");
  s = s.replace(/\{\{([\s\S]*?)\}\}/g, (m, inner) => {
    const slug = String(inner || "")
      .replace(/<[^>]*>/g, "")
      .replace(/&nbsp;/gi, " ")
      .trim();
    return slug ? `{{${slug}}}` : m;
  });
  return s;
}

function applyMergeFields(raw, fields, options = {}) {
  const s = prepareTextForMergeFields(raw);
  if (!s) return s;
  const keepHtmlNbsp = Boolean(options.keepHtmlNbsp);
  const merge = fields || {};
  const map = {
    full_name: String(merge.full_name || "").trim(),
    first_name: String(merge.first_name || "").trim(),
    last_name: String(merge.last_name || "").trim(),
    age: String(merge.age || "").trim(),
    email: String(merge.email || "").trim(),
    phone: String(merge.phone || "").trim(),
    state: String(merge.state || "").trim(),
    date_of_contact: String(merge.date_of_contact || "").trim(),
    quote: String(merge.quote || "").trim(),
    app_id: String(merge.app_id || merge.policy_number || "").trim(),
    policy_number: String(merge.policy_number || merge.app_id || "").trim(),
    coverage_start_date: formatCoverageStartDateForMerge(String(merge.coverage_start_date || "").trim()),
    policy_renewal: formatCoverageStartDateForMerge(
      String(merge.policy_renewal || merge.policy_renewal_date || "").trim()
    ),
    policy_renewal_date: formatCoverageStartDateForMerge(
      String(merge.policy_renewal || merge.policy_renewal_date || "").trim()
    ),
    polcy_renewal: formatCoverageStartDateForMerge(
      String(merge.policy_renewal || merge.policy_renewal_date || merge.polcy_renewal || "").trim()
    ),
    upon_approval: String(merge.upon_approval || "").trim(),
    vcall: String(merge.vcall || "").trim(),
    insurance_type: String(merge.insurance_type || "").trim(),
    // Honor explicit override; otherwise auto-compute today + 7 days each time.
    good_through: String(merge.good_through || "").trim() || computeGoodThroughDate(7),
    unsubscribe_url: String(merge.unsubscribe_url || "").trim()
  };
  const normalizeKey = (raw) =>
    String(raw || "")
      .toLowerCase()
      .replace(/\s+/g, "")
      .replace("dateof_contact", "date_of_contact")
      .replace("goodthrough", "good_through")
      .replace("policynumber", "policy_number")
      .replace("policyrenewaldate", "policy_renewal")
      .replace("policyrenewal", "policy_renewal")
      .replace("polcyrenewal", "policy_renewal")
      .replace("insurancetype", "insurance_type")
      .replace("appid", "app_id");
  let merged = s.replace(
    /\(\s*(full_name|first_name|last_name|age|email|phone|state|date_of_contact|date_of\s*_\s*contact|quote|app_id|policy_number|policy\s*_\s*number|coverage_start_date|policy_renewal|policy_renewal_date|policy\s*_\s*renewal|polcy_renewal|upon_approval|vcall|insurance_type|insurance\s*_\s*type|good_through|good\s*_\s*through|unsubscribe_url|unsubscribe\s*_\s*url)\s*\)/gi,
    (m, key) => {
      const normalized = normalizeKey(key);
      return map[normalized] != null ? map[normalized] : "";
    }
  );
  merged = merged.replace(
    /\{\{\s*(full_name|first_name|last_name|age|email|phone|state|date_of_contact|date_of\s*_\s*contact|quote|app_id|policy_number|policy\s*_\s*number|coverage_start_date|policy_renewal|policy_renewal_date|policy\s*_\s*renewal|polcy_renewal|upon_approval|vcall|insurance_type|insurance\s*_\s*type|good_through|good\s*_\s*through|unsubscribe_url|unsubscribe\s*_\s*url)\s*\}\}/gi,
    (m, key) => {
      const normalized = normalizeKey(key);
      return map[normalized] != null ? map[normalized] : "";
    }
  );

  /**
   * Custom merge fields pass. Any remaining `{{slug}}` / `(slug)` placeholder
   * whose normalized key matches a user-defined custom merge field gets
   * replaced; unknown placeholders are left as-is so authors can spot typos.
   */
  const customMap =
    options.customFields && typeof options.customFields === "object"
      ? options.customFields
      : getCustomMergeFieldsMap();
  if (customMap && typeof customMap === "object") {
    const lookup = {};
    for (const key of Object.keys(customMap)) {
      const slug = normalizeMergeKeySlug(key);
      if (!slug || BUILT_IN_MERGE_FIELD_SLUGS.has(slug)) continue;
      lookup[slug] = String(customMap[key] == null ? "" : customMap[key]);
    }
    if (Object.keys(lookup).length > 0) {
      const customReplace = (m, key) => {
        const slug = normalizeMergeKeySlug(key);
        return Object.prototype.hasOwnProperty.call(lookup, slug) ? lookup[slug] : m;
      };
      merged = merged.replace(/\{\{\s*([a-zA-Z][a-zA-Z0-9 _\-]*)\s*\}\}/g, customReplace);
      merged = merged.replace(/\(\s*([a-zA-Z][a-zA-Z0-9 _\-]*)\s*\)/g, customReplace);
    }
  }

  // Handle escaped entity text copied from editors/templates.
  merged = merged.replace(/&amp;nbsp;/gi, "&nbsp;");
  if (!keepHtmlNbsp) {
    merged = merged
      .replace(/&nbsp;/gi, " ")
      .replace(/\u00a0/g, " ")
      .replace(/[ \t]{2,}/g, " ")
      .replace(/ +([:;,])/g, "$1")
      .trim();
  }
  return merged;
}

function captureEmailBodyToolbarRange(options) {
  if (emailBodyToolbarLock || !emailBodyEditor) return;
  const sel = window.getSelection();
  if (!sel || sel.rangeCount === 0) return;
  const range = sel.getRangeAt(0);
  if (!emailBodyEditor.contains(range.commonAncestorContainer)) return;
  if (options?.keepHighlight && range.collapsed && emailBodyToolbarRange && !emailBodyToolbarRange.collapsed) {
    try {
      if (emailBodyEditor.contains(emailBodyToolbarRange.commonAncestorContainer)) return;
    } catch {
      // The previous highlight was detached. Fall through and store this caret.
    }
  }
  emailBodyToolbarRange = range.cloneRange();
}

function withEmailBodyToolbarFocus(run) {
  if (!emailBodyEditor) return;
  const saved = emailBodyToolbarRange ? emailBodyToolbarRange.cloneRange() : null;
  emailBodyToolbarLock += 1;
  try {
    emailBodyEditor.focus();
    if (saved) {
      const sel = window.getSelection();
      if (sel) {
        sel.removeAllRanges();
        try {
          sel.addRange(saved);
        } catch {
          //
        }
      }
    }
    run();
  } finally {
    emailBodyToolbarLock -= 1;
  }
  captureEmailBodyToolbarRange();
}

function getClosestEmailLegacySizeKey(px) {
  const target = Number(px);
  if (!Number.isFinite(target) || target <= 0) return "";
  let best = "";
  let minDiff = Number.POSITIVE_INFINITY;
  for (const entry of EMAIL_LEGACY_SIZE_ENTRIES) {
    const diff = Math.abs(entry.px - target);
    if (diff < minDiff) {
      minDiff = diff;
      best = entry.key;
    }
  }
  return best;
}

function syncEmailBodyFontSizeDropdown() {
  if (!emailBodyLegacyFontSize || !emailBodyEditor) return;
  const sel = window.getSelection();
  if (!sel || sel.rangeCount === 0) {
    emailBodyLegacyFontSize.value = "";
    return;
  }
  const range = sel.getRangeAt(0);
  if (!emailBodyEditor.contains(range.commonAncestorContainer)) return;

  const node =
    range.startContainer && range.startContainer.nodeType === Node.ELEMENT_NODE
      ? range.startContainer
      : range.startContainer?.parentElement;
  if (!node || !(node instanceof Element)) return;

  const fontPx = parseFloat(window.getComputedStyle(node).fontSize || "");
  const key = getClosestEmailLegacySizeKey(fontPx);
  emailBodyLegacyFontSize.value = key || "";
}

function getClosestSelectNumericOptionValue(selectEl, px) {
  const target = Number(px);
  if (!selectEl || !Number.isFinite(target) || target <= 0) return "";
  const candidates = [...selectEl.options]
    .map((opt) => String(opt.value || "").trim())
    .map((v) => ({ value: v, n: Number(v) }))
    .filter((item) => item.value && Number.isFinite(item.n));
  if (!candidates.length) return "";
  let best = "";
  let minDiff = Number.POSITIVE_INFINITY;
  for (const item of candidates) {
    const diff = Math.abs(item.n - target);
    if (diff < minDiff) {
      minDiff = diff;
      best = item.value;
    }
  }
  return best;
}

function syncEditorFontSizeDropdown(editorEl, selectEl) {
  if (!editorEl || !selectEl) return;
  const sel = window.getSelection();
  if (!sel || sel.rangeCount === 0) {
    selectEl.value = "";
    return;
  }
  const range = sel.getRangeAt(0);
  if (!editorEl.contains(range.commonAncestorContainer)) return;
  const node =
    range.startContainer && range.startContainer.nodeType === Node.ELEMENT_NODE
      ? range.startContainer
      : range.startContainer?.parentElement;
  if (!node || !(node instanceof Element)) return;
  const fontPx = parseFloat(window.getComputedStyle(node).fontSize || "");
  selectEl.value = getClosestSelectNumericOptionValue(selectEl, fontPx);
}

function insertTextIntoInputAtCaret(inputEl, text) {
  if (!inputEl || typeof inputEl.value !== "string") return;
  const value = inputEl.value;
  const start = Number.isInteger(inputEl.selectionStart) ? inputEl.selectionStart : value.length;
  const end = Number.isInteger(inputEl.selectionEnd) ? inputEl.selectionEnd : start;
  inputEl.value = `${value.slice(0, start)}${text}${value.slice(end)}`;
  const next = start + text.length;
  inputEl.focus();
  inputEl.setSelectionRange(next, next);
}

function captureTemplateBodyToolbarRange(options) {
  if (templateBodyToolbarLock || !templateBodyEditor) return;
  const sel = window.getSelection();
  if (!sel || sel.rangeCount === 0) return;
  const range = sel.getRangeAt(0);
  if (!templateBodyEditor.contains(range.commonAncestorContainer)) return;
  if (options?.keepHighlight && range.collapsed && templateBodyToolbarRange && !templateBodyToolbarRange.collapsed) {
    try {
      if (templateBodyEditor.contains(templateBodyToolbarRange.commonAncestorContainer)) return;
    } catch {
      // The previous highlight was detached. Fall through and store this caret.
    }
  }
  templateBodyToolbarRange = range.cloneRange();
}

function withTemplateBodyToolbarFocus(run) {
  if (!templateBodyEditor) return;
  const saved = templateBodyToolbarRange ? templateBodyToolbarRange.cloneRange() : null;
  templateBodyToolbarLock += 1;
  try {
    templateBodyEditor.focus();
    if (saved) {
      const sel = window.getSelection();
      if (sel) {
        sel.removeAllRanges();
        try {
          sel.addRange(saved);
        } catch {
          //
        }
      }
    }
    run();
  } finally {
    templateBodyToolbarLock -= 1;
  }
  captureTemplateBodyToolbarRange();
}

function insertTemplateMergeToken(token) {
  const t = String(token || "").trim();
  if (!t) return;
  if (templateMergeTarget === "subject" && templateSubjectInput) {
    insertTextIntoInputAtCaret(templateSubjectInput, t);
    return;
  }
  if (!templateBodyEditor) return;
  withTemplateBodyToolbarFocus(() => {
    const ok = document.execCommand("insertText", false, t);
    if (!ok) {
      document.execCommand("insertHTML", false, escapeHtml(t));
    }
  });
}

function insertEmailComposeMergeToken(token) {
  const t = String(token || "").trim();
  if (!t) return;
  if (emailComposeMergeTarget === "subject" && subjectInput) {
    insertTextIntoInputAtCaret(subjectInput, t);
    return;
  }
  if (!emailBodyEditor) return;
  withEmailBodyToolbarFocus(() => {
    const ok = document.execCommand("insertText", false, t);
    if (!ok) {
      document.execCommand("insertHTML", false, escapeHtml(t));
    }
  });
}

function htmlToPlainPreview(html) {
  const div = document.createElement("div");
  div.innerHTML = String(html || "");
  return String(div.textContent || "").replace(/\s+/g, " ").trim();
}

/** Stored preference (Settings / localStorage) - not the compose-page checkbox default. */
function isIncludeEmailSignatureEnabled() {
  return getStoredSignatureSettings().include;
}

function syncIncludeSignatureButton() {
  const on = isIncludeEmailSignatureEnabled();
  if (emailIncludeSignature) emailIncludeSignature.checked = on;
  if (emailIncludeSignatureBtn) {
    emailIncludeSignatureBtn.classList.toggle("is-active", on);
    emailIncludeSignatureBtn.setAttribute("aria-pressed", on ? "true" : "false");
  }
  if (emailSignatureEnabledCheck) {
    emailSignatureEnabledCheck.hidden = !on;
    emailSignatureEnabledCheck.classList.toggle("is-visible", on);
    emailSignatureEnabledCheck.setAttribute("aria-hidden", on ? "false" : "true");
  }
}

function persistIncludeSignaturePreference(include) {
  try {
    window.localStorage.setItem(EMAIL_INCLUDE_SIGNATURE_KEY, include ? "1" : "0");
  } catch {
    //
  }
  if (typeof window.persistEmailSignatureToServer === "function") {
    const payload =
      typeof window.buildEmailSignaturePayloadFromLocal === "function"
        ? window.buildEmailSignaturePayloadFromLocal(include)
        : { include };
    window.persistEmailSignatureToServer(payload).catch(() => {});
  }
}

function setIncludeEmailSignatureEnabled(include) {
  if (emailIncludeSignature) emailIncludeSignature.checked = !!include;
  syncIncludeSignatureButton();
  updateEmailSignaturePreview();
  persistIncludeSignaturePreference(!!include);
}

function updateEmailSignaturePreview() {
  const previewEl = document.getElementById("emailSignaturePreview");
  const wrapEl = document.getElementById("emailSignaturePreviewWrap");
  if (!previewEl) return;
  const include = isIncludeEmailSignatureEnabled();
  if (!include) {
    previewEl.textContent = "Signature is turned off for outbound email.";
    previewEl.classList.add("is-muted");
    if (wrapEl) wrapEl.classList.add("is-off");
    return;
  }
  if (wrapEl) wrapEl.classList.remove("is-off");
  const stored = getStoredSignatureSettings();
  const plain =
    getSignatureEditorText() ||
    htmlToPlainPreview(getSignatureEditorHtml()) ||
    htmlToPlainPreview(stored.html) ||
    String(stored.text || "").trim();
  if (!plain) {
    previewEl.textContent = "No signature saved yet - add one in Settings before you send.";
    previewEl.classList.add("is-empty");
    previewEl.classList.remove("is-muted");
    return;
  }
  previewEl.textContent = plain.length > 140 ? `${plain.slice(0, 137)}...` : plain;
  previewEl.classList.remove("is-empty", "is-muted");
}

function hasUnresolvedMergeTokens(raw) {
  return /\{\{[^}]+\}\}/.test(String(raw || ""));
}

function formatSendConfirmTo(toCsv, mergeFields) {
  const emails = String(toCsv || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  if (!emails.length) return "";
  const mf = mergeFields && typeof mergeFields === "object" ? mergeFields : {};
  const name =
    String(mf.full_name || "").trim() ||
    [mf.first_name, mf.last_name].map((s) => String(s || "").trim()).filter(Boolean).join(" ");
  const first = emails[0];
  const extra = emails.length - 1;
  if (name && first) {
    return extra > 0 ? `${name} <${first}> (+${extra} more)` : `${name} <${first}>`;
  }
  return emails.join(", ");
}

function getSendConfirmAttachmentLabels() {
  const names = [];
  for (const id of selectedLibraryAttachmentIds) {
    const doc = emailLibraryDocumentsCache.find((d) => Number(d.id) === Number(id));
    if (doc) names.push(String(doc.file_name || `Document #${id}`));
  }
  const files = localFilesInput?.files ? [...localFilesInput.files] : [];
  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const cb = attachmentList?.querySelector(`input.email-local-attach-checkbox[data-local-index="${i}"]`);
    if (cb && !cb.checked) continue;
    names.push(String(file.name || "Attached file"));
  }
  return names;
}

async function buildSendConfirmPreview() {
  const to = parseToRecipientList(toManualInput?.value || "").join(", ");
  await refreshCustomMergeFieldsCache();
  const mergeFields = await getSelectedContactMergeFields();
  const customFields = getCustomMergeFieldsMap();
  const mergeOpts = { customFields };
  const subject = getEffectiveSubject();
  const mergedSubject = applyMergeFields(subject, mergeFields, mergeOpts);
  const composed = await getComposedEmailContent();
  const mergedText = applyMergeFields(composed.text, mergeFields, mergeOpts);
  const mergedHtml = applyMergeFields(composed.html, mergeFields, { ...mergeOpts, keepHtmlNbsp: true });
  const hasBody = Boolean(String(composed.text || "").trim() || String(composed.html || "").trim());
  return {
    to,
    toDisplay: formatSendConfirmTo(to, mergeFields),
    from: String(fromSelect?.value || "").trim(),
    mergedSubject,
    attachments: getSendConfirmAttachmentLabels(),
    tracking: Boolean(emailEnableTrackingStub?.checked),
    mergeWarning:
      hasUnresolvedMergeTokens(mergedSubject) ||
      hasUnresolvedMergeTokens(mergedText) ||
      hasUnresolvedMergeTokens(mergedHtml),
    hasBody,
    hasTemplate: Number.isInteger(Number(templateSelect?.value)) && Number(templateSelect.value) > 0
  };
}

function closeSendConfirmModal() {
  const modal = document.getElementById("emailSendConfirmModal");
  pendingSendConfirmAction = null;
  if (sendEmailForm) delete sendEmailForm.dataset.quickSend;
  if (!modal) return;
  modal.hidden = true;
  document.body.classList.remove("email-send-modal-open");
}

function openSendConfirmModal(preview, onConfirm) {
  const modal = document.getElementById("emailSendConfirmModal");
  const toEl = document.getElementById("emailSendConfirmTo");
  const fromEl = document.getElementById("emailSendConfirmFrom");
  const subjectEl = document.getElementById("emailSendConfirmSubject");
  const attachRow = document.getElementById("emailSendConfirmAttachRow");
  const attachEl = document.getElementById("emailSendConfirmAttach");
  const warnEl = document.getElementById("emailSendConfirmMergeWarn");
  const trackingEl = document.getElementById("emailSendConfirmTracking");
  if (!modal || !toEl || !fromEl || !subjectEl) {
    onConfirm();
    return;
  }
  toEl.textContent = preview.toDisplay || preview.to || "-";
  fromEl.textContent = preview.from || "-";
  subjectEl.textContent = preview.mergedSubject || "(no subject)";
  if (attachRow && attachEl) {
    if (preview.attachments?.length) {
      attachRow.hidden = false;
      attachEl.textContent = preview.attachments.join(", ");
    } else {
      attachRow.hidden = true;
      attachEl.textContent = "";
    }
  }
  if (warnEl) {
    if (preview.mergeWarning) {
      warnEl.hidden = false;
      warnEl.textContent =
        "Some merge fields could not be filled in - check the subject and message before sending.";
    } else {
      warnEl.hidden = true;
      warnEl.textContent = "";
    }
  }
  if (trackingEl) {
    trackingEl.textContent = "Open tracking off. Sent as a personal email.";
    trackingEl.classList.toggle("is-off", !preview.tracking);
  }
  pendingSendConfirmAction = onConfirm;
  modal.hidden = false;
  document.body.classList.add("email-send-modal-open");
  document.getElementById("emailSendConfirmSendBtn")?.focus();
}

function wireSendConfirmModal() {
  const modal = document.getElementById("emailSendConfirmModal");
  const cancelBtn = document.getElementById("emailSendConfirmCancelBtn");
  const sendBtn = document.getElementById("emailSendConfirmSendBtn");
  if (!modal) return;
  modal.addEventListener("click", (event) => {
    if (event.target?.closest?.("[data-send-confirm-dismiss]")) closeSendConfirmModal();
  });
  cancelBtn?.addEventListener("click", () => closeSendConfirmModal());
  sendBtn?.addEventListener("click", async () => {
    const action = pendingSendConfirmAction;
    closeSendConfirmModal();
    if (typeof action === "function") await action();
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !modal.hidden) {
      event.preventDefault();
      closeSendConfirmModal();
    }
  });
}

function clearComposeAttachments() {
  selectedLibraryAttachmentIds.clear();
  if (emailAttachmentSelect) emailAttachmentSelect.value = "";
  renderSelectedLibraryAttachmentTiles();
  if (localFilesInput) {
    clearStoredLocalAttachments();
    localFilesInput.value = "";
    renderSelectedLocalFiles();
  } else {
    clearStoredLocalAttachments();
  }
}

function resetEmailCompose() {
  if (subjectInput) subjectInput.value = "";
  if (templateSelect) templateSelect.value = "";
  if (emailBodyEditor) emailBodyEditor.innerHTML = "";
  if (toManualInput) toManualInput.value = "";
  if (toContactSelect && toContactSelect.options.length) {
    toContactSelect.selectedIndex = 0;
  }
  if (emailCcInput) emailCcInput.value = "";
  composeCcFieldTouched = false;
  clearComposeAttachments();
  emailBodyToolbarRange = null;
  showMessage("");
}

/** After a successful send: clear recipient, template, subject, body, and attachments. */
function clearComposeAfterSuccessfulSend() {
  if (toManualInput) toManualInput.value = "";
  composeToFieldTouched = false;
  if (emailCcInput) emailCcInput.value = "";
  composeCcFieldTouched = false;
  if (subjectInput) subjectInput.value = "";
  if (templateSelect) {
    templateSelect.value = "";
    templateSelect.dispatchEvent(new Event("change", { bubbles: true }));
  }
  if (emailBodyEditor) emailBodyEditor.innerHTML = "";
  clearComposeAttachments();
}

function applyLoadedSignatureSettings(settings, include) {
  const data = settings && typeof settings === "object" ? settings : {};
  const signatureHtml = String(data.html || "").trim();
  const signatureText = String(data.text || "").trim();
  if (signatureHtml) setSignatureEditorHtml(signatureHtml);
  else if (signatureText) setSignatureEditorHtml(textToHtmlLines(signatureText));
  if (emailSignatureFontSize) emailSignatureFontSize.value = String(data.fontSize || "16");
  if (emailSignatureColor) emailSignatureColor.value = String(data.color || "#1f2937");
  if (emailSignatureLinkText) emailSignatureLinkText.value = String(data.linkText || "");
  if (emailSignatureLinkUrl) emailSignatureLinkUrl.value = String(data.linkUrl || "");
  if (emailSignatureImageUrl) emailSignatureImageUrl.value = String(data.imageUrl || "");
  if (emailIncludeSignature) emailIncludeSignature.checked = include !== false;
  syncIncludeSignatureButton();
}

async function loadSavedSignature() {
  try {
    if (typeof window.fetchEmailSignatureFromServer === "function") {
      const payload = await window.fetchEmailSignatureFromServer();
      const settings = payload?.settings && typeof payload.settings === "object" ? payload.settings : {};
      applyLoadedSignatureSettings(stripByFromForSignature(settings), payload.include !== false);
      return;
    }
  } catch {
    /* fall back to local cache */
  }
  try {
    const raw = window.localStorage.getItem(EMAIL_SIGNATURE_KEY);
    const settings = raw ? JSON.parse(raw) : {};
    const includeRaw = window.localStorage.getItem(EMAIL_INCLUDE_SIGNATURE_KEY);
    const include = includeRaw == null ? true : includeRaw === "1";
    applyLoadedSignatureSettings(settings, include);
  } catch {
    if (emailIncludeSignature) emailIncludeSignature.checked = true;
  }
}

function stripByFromForSignature(raw) {
  if (!raw || typeof raw !== "object") return {};
  const o = { ...raw };
  delete o.byFrom;
  delete o.include;
  return o;
}

function getStoredSignatureSettings() {
  try {
    const raw = window.localStorage.getItem(EMAIL_SIGNATURE_KEY);
    const settings = raw ? JSON.parse(raw) : {};
    const includeRaw = window.localStorage.getItem(EMAIL_INCLUDE_SIGNATURE_KEY);
    return {
      text: String(settings.text || "").trim(),
      html: String(settings.html || "").trim(),
      fontSize: String(settings.fontSize || "16"),
      color: String(settings.color || "#1f2937"),
      linkText: String(settings.linkText || "").trim(),
      linkUrl: String(settings.linkUrl || "").trim(),
      imageUrl: String(settings.imageUrl || "").trim(),
      include: includeRaw == null ? true : includeRaw === "1"
    };
  } catch {
    return {
      text: "",
      html: "",
      fontSize: "16",
      color: "#1f2937",
      linkText: "",
      linkUrl: "",
      imageUrl: "",
      include: true
    };
  }
}

async function getSignatureImageSrc() {
  const imageUrl = String(emailSignatureImageUrl?.value || "").trim();
  if (imageUrl) return imageUrl;
  const file = emailSignatureImageFile?.files?.[0];
  if (!file) return "";
  const dataUrl = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error(`Failed to read signature image ${file.name}`));
    reader.readAsDataURL(file);
  });
  return dataUrl;
}

function wrapBodyHtmlForEmail(raw) {
  const s = String(raw || "").trim();
  if (!s) return "";
  const innerRaw = /<[a-z][\s\S]*>/i.test(s) ? s : textToHtmlLines(s);
  // Clamp first so legacy width/height attributes are stripped, then bake the
  // editor-resize wrapper width into <img>; otherwise the clamp would discard
  // the wrapper-derived pixel width and the recipient renders the image at
  // its natural intrinsic size (e.g. the United Healthcare logo).
  const clampedRaw = clampBodyImageHtml(innerRaw, RICH_EMAIL_COMPOSE_IMAGE_MAX_PX);
  const inner = applyResizedImageWrapperSizing(clampedRaw);
  return `<div style="font-family:system-ui,Segoe UI,Arial,sans-serif;font-size:14px;line-height:1.5;color:#111827;">${inner}</div>`;
}

function clampBodyImageHtml(rawHtml, maxWidthPx = 520) {
  const raw = String(rawHtml || "");
  if (!raw || !/<img[\s>]/i.test(raw)) return raw;
  const safeMax = Number.isFinite(Number(maxWidthPx)) ? Math.max(120, Math.round(Number(maxWidthPx))) : 520;
  const normalizeImgTag = (imgTag) => {
    let out = String(imgTag || "");
    const styleMatch = out.match(/\sstyle=(['"])([\s\S]*?)\1/i);
    const styleRaw = styleMatch ? String(styleMatch[2] || "") : "";
    // PRESERVE the image's intended width instead of stripping it. Stripping the
    // width was what let a resized (or designed) image balloon back to the max in
    // the sent email - the saved body is no longer wrapped, so nothing restored
    // it. Take an explicit pixel width from the inline style or the width
    // attribute (ignore responsive width:100%/auto), and cap it at safeMax.
    let fixedPx = 0;
    const sW = styleRaw.match(/(?:^|;)\s*width\s*:\s*(\d+(?:\.\d+)?)px/i);
    if (sW) fixedPx = Math.round(Number(sW[1]));
    if (!fixedPx && !/(?:^|;)\s*width\s*:\s*(?:100%|auto)/i.test(styleRaw)) {
      const aW = out.match(/\swidth\s*=\s*["']?(\d+(?:\.\d+)?)(?:px)?["']?/i);
      if (aW) fixedPx = Math.round(Number(aW[1]));
    }
    // Keep an existing smaller max-width rather than enlarging it to safeMax.
    let maxPx = safeMax;
    const sMaxW = styleRaw.match(/(?:^|;)\s*max-width\s*:\s*(\d+(?:\.\d+)?)px/i);
    if (sMaxW) maxPx = Math.min(maxPx, Math.round(Number(sMaxW[1])));
    if (fixedPx) maxPx = Math.min(maxPx, fixedPx);
    const cleaned = styleRaw
      .replace(/(?:^|;)\s*max-width\s*:[^;]*/gi, "")
      .replace(/(?:^|;)\s*min-width\s*:\s*\d+(\.\d+)?px\b[^;]*/gi, "")
      .replace(/(?:^|;)\s*height\s*:[^;]*/gi, "")
      .replace(/(?:^|;)\s*width\s*:\s*\d+(\.\d+)?px\b[^;]*/gi, "")
      .trim();
    const widthDecl = fixedPx ? `width:${Math.min(fixedPx, safeMax)}px;` : "";
    const styleFinal = `${cleaned ? `${cleaned};` : ""}${widthDecl}max-width:${maxPx}px;height:auto;`;
    if (styleMatch) out = out.replace(/\sstyle=(['"])([\s\S]*?)\1/i, ` style="${styleFinal}"`);
    else out = out.replace(/<img\b/i, `<img style="${styleFinal}"`);
    out = out.replace(/\s+width\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, "");
    out = out.replace(/\s+height\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, "");
    // Re-add the width attribute (many email clients honor it) when we kept a fixed width.
    if (fixedPx) out = out.replace(/<img\b/i, `<img width="${Math.min(fixedPx, safeMax)}"`);
    return out;
  };
  return raw.replace(/<img\b[^>]*>/gi, (tag) => normalizeImgTag(tag));
}

/**
 * Editor resize uses .signature-image-wrap (resizable span). That wrapper does not reliably
 * affect recipient rendering, so copy wrapper width to the image inline style and unwrap.
 * If the image has a link (data-img-href or parent <a>), keep it as <a><img></a> so
 * recipients can click the picture in Gmail/Outlook.
 */
function applyResizedImageWrapperSizing(rawHtml) {
  const raw = String(rawHtml || "");
  if (!raw || raw.indexOf("signature-image-wrap") < 0) return raw;
  try {
    const root = document.createElement("div");
    root.innerHTML = raw;
    const wraps = [...root.querySelectorAll("span.signature-image-wrap")];
    for (const wrap of wraps) {
      const img = wrap.querySelector("img");
      if (!img) continue;
      const widthRaw = String(wrap.style?.width || "").trim();
      const pxMatch = widthRaw.match(/^(\d+(?:\.\d+)?)px$/i);
      if (pxMatch) {
        const px = Math.max(40, Math.round(Number(pxMatch[1])));
        const styleRaw = String(img.getAttribute("style") || "");
        const cleaned = styleRaw
          .replace(/(?:^|;)\s*width\s*:[^;]*/gi, "")
          .replace(/(?:^|;)\s*max-width\s*:[^;]*/gi, "")
          .trim();
        const nextStyle = `${cleaned ? `${cleaned};` : ""}width:${px}px;max-width:${px}px;height:auto;`;
        img.setAttribute("style", nextStyle);
        img.setAttribute("width", String(px));
        img.removeAttribute("height");
      }
      // Preserve alignment: it's stored on the wrapper as display:block + auto
      // margins (see setImageWrapAlignment). The wrapper is removed below, so copy
      // it onto the image or the alignment is lost in the preview and sent email.
      if (String(wrap.style?.display || "") === "block") {
        const ml = String(wrap.style.marginLeft || "").trim();
        const mr = String(wrap.style.marginRight || "").trim();
        if (ml || mr) {
          let s = String(img.getAttribute("style") || "")
            .replace(/(?:^|;)\s*display\s*:[^;]*/gi, "")
            .replace(/(?:^|;)\s*margin-left\s*:[^;]*/gi, "")
            .replace(/(?:^|;)\s*margin-right\s*:[^;]*/gi, "")
            .trim();
          s = `${s ? `${s};` : ""}display:block;margin-left:${ml || "0"};margin-right:${mr || "0"};`;
          img.setAttribute("style", s);
        }
      }
      const linkHref = getImageWrapLinkHref(wrap);
      let replacement = img;
      if (linkHref) {
        const anchor = document.createElement("a");
        anchor.setAttribute("href", linkHref);
        anchor.setAttribute("target", "_blank");
        anchor.setAttribute("rel", "noopener noreferrer");
        anchor.setAttribute(
          "style",
          "text-decoration:none;border:0;color:inherit;display:inline-block;"
        );
        // Keep alignment on the clickable wrapper when the image was centered/right-aligned.
        if (String(wrap.style?.display || "") === "block") {
          const ml = String(wrap.style.marginLeft || "").trim();
          const mr = String(wrap.style.marginRight || "").trim();
          if (ml || mr) {
            anchor.setAttribute(
              "style",
              `text-decoration:none;border:0;color:inherit;display:block;margin-left:${ml || "0"};margin-right:${mr || "0"};`
            );
          }
        }
        anchor.appendChild(img);
        replacement = anchor;
      }
      const parentAnchor = wrap.parentElement;
      if (parentAnchor && parentAnchor.tagName === "A" && parentAnchor.contains(wrap)) {
        parentAnchor.replaceWith(replacement);
      } else {
        wrap.replaceWith(replacement);
      }
    }
    return root.innerHTML;
  } catch {
    return raw;
  }
}

/**
 * Like {@link clampBodyImageHtml} for template bodies: cap with max-width only so small
 * icons (LinkedIn, About, etc.) keep their natural size. Do not set a fixed `width` attribute
 * (that can blow up 32px icons to the max in some mail clients).
 */
function clampSignatureImageHtml(rawHtml) {
  const raw = applyResizedImageWrapperSizing(rawHtml);
  if (!raw || !/<img[\s>]/i.test(raw)) return raw;
  const maxSignatureImageWidth = RICH_EMAIL_SIGNATURE_IMAGE_MAX_PX;
  const normalizeImgTag = (imgTag) => {
    let out = String(imgTag || "");
    const styleMatch = out.match(/\sstyle=(['"])([\s\S]*?)\1/i);
    const styleRaw = styleMatch ? String(styleMatch[2] || "") : "";
    const cleaned = styleRaw
      .replace(/(?:^|;)\s*max-width\s*:[^;]*/gi, "")
      .replace(/(?:^|;)\s*height\s*:[^;]*/gi, "")
      .replace(/(?:^|;)\s*display\s*:[^;]*/gi, "")
      .replace(/(?:^|;)\s*margin-bottom\s*:[^;]*/gi, "")
      .trim();
    const styleFinal = `${cleaned ? `${cleaned};` : ""}max-width:${maxSignatureImageWidth}px;height:auto;display:block;margin-bottom:12px;`;
    if (styleMatch) out = out.replace(/\sstyle=(['"])([\s\S]*?)\1/i, ` style="${styleFinal}"`);
    else out = out.replace(/<img\b/i, `<img style="${styleFinal}"`);
    if (!/\salt=/i.test(out)) out = out.replace(/<img\b/i, '<img alt="Signature image"');
    return out;
  };
  return raw.replace(/<img\b[^>]*>/gi, (tag) => normalizeImgTag(tag));
}

async function getComposedEmailContent() {
  const baseSig = getStoredSignatureSettings();
  const fromAddr = String(fromSelect?.value || "").trim();
  const perFrom =
    typeof getSignatureForFromAddress === "function" && fromAddr
      ? getSignatureForFromAddress(fromAddr)
      : null;
  const storedSignature = perFrom ? { ...perFrom, include: baseSig.include } : baseSig;
  const bodyHtmlRaw = getEffectiveEmailBodyHtml();
  const bodyPlain = getEffectiveEmailBodyPlain();
  const mainHtml = wrapBodyHtmlForEmail(bodyHtmlRaw);
  const include = isIncludeEmailSignatureEnabled();
  const signatureHtmlRaw = getSignatureEditorHtml() || storedSignature.html;
  const signatureText = getSignatureEditorText() || storedSignature.text;
  const signatureHasInlineImage = /<img[\s>]/i.test(signatureHtmlRaw);
  const fontSize = Number(emailSignatureFontSize?.value || storedSignature.fontSize || 16);
  const color = String(emailSignatureColor?.value || storedSignature.color || "#1f2937").trim();
  const linkText = String(emailSignatureLinkText?.value || storedSignature.linkText || "").trim();
  const linkUrl = String(emailSignatureLinkUrl?.value || storedSignature.linkUrl || "").trim();
  /** Picture URL / file image is appended in addition to any inline images in the editor. */
  const imageSrc = (await getSignatureImageSrc()) || storedSignature.imageUrl;

  if (!include) {
    return { text: bodyPlain, html: mainHtml || "" };
  }

  const hasSignatureContent =
    signatureEditorHasContent(signatureHtmlRaw, signatureText) ||
    signatureHasInlineImage ||
    (linkText && linkUrl) ||
    Boolean(imageSrc);

  if (!hasSignatureContent) {
    return { text: bodyPlain, html: mainHtml || "" };
  }

  const safeFontSize = Number.isFinite(fontSize) ? Math.min(36, Math.max(10, Math.round(fontSize))) : 16;
  const safeColor = /^#[0-9a-fA-F]{6}$/.test(color) ? color : "#1f2937";
  const signatureTextHtml = clampSignatureImageHtml(signatureHtmlRaw || textToHtmlLines(signatureText));
  const linkHtml =
    linkText && linkUrl
      ? `<div style="margin-top:8px;"><a href="${escapeHtml(linkUrl)}" target="_blank" rel="noopener noreferrer">${escapeHtml(linkText)}</a></div>`
      : "";
  const imageHtml = imageSrc
    ? `<div style="margin-top:8px;"><img src="${escapeHtml(imageSrc)}" alt="Signature image" style="max-width:${RICH_EMAIL_SIGNATURE_IMAGE_MAX_PX}px;height:auto;display:block;border:0;margin-bottom:12px;" /></div>`
    : "";
  const sigSep = mainHtml
    ? "margin-top:18px;padding-top:14px;border-top:1px solid #e5e7eb;"
    : "margin-top:0;padding-top:0;";
  const signatureBlock = `<div style="${sigSep}font-family:system-ui,Segoe UI,Arial,sans-serif;font-size:${safeFontSize}px;color:${safeColor};line-height:1.45;">${signatureTextHtml}${linkHtml}${imageHtml}</div>`;

  const signatureTextLines = [];
  if (signatureText) signatureTextLines.push(signatureText);
  if (linkText && linkUrl) signatureTextLines.push(`${linkText}: ${linkUrl}`);
  if (imageSrc || signatureHasInlineImage) signatureTextLines.push("[Signature image included]");
  const signaturePlain = signatureTextLines.length ? signatureTextLines.join("\n") : "[Signature]";

  const combinedHtml = `<div style="max-width:100%;word-wrap:break-word;">${mainHtml}${signatureBlock}</div>`;

  let combinedText;
  if (bodyPlain && hasSignatureContent) {
    combinedText = `${bodyPlain}\n\n---\n\n${signaturePlain}`;
  } else if (bodyPlain) {
    combinedText = bodyPlain;
  } else {
    combinedText = signaturePlain;
  }

  return {
    text: combinedText,
    html: combinedHtml
  };
}

function schedulePersistEmailLocalAttachments() {
  clearTimeout(persistLocalAttachmentsTimer);
  persistLocalAttachmentsTimer = setTimeout(() => {
    persistLocalAttachmentsFromInput().catch(() => {});
  }, 450);
}

async function persistLocalAttachmentsFromInput() {
  if (!window.sessionStorage || !localFilesInput) return;
  const files = [...localFilesInput.files];
  if (!files.length) {
    try {
      sessionStorage.removeItem(EMAIL_LOCAL_ATTACHMENTS_SESSION_KEY);
    } catch {
      //
    }
    return;
  }
  try {
    const items = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const cb = attachmentList?.querySelector(`input.email-local-attach-checkbox[data-local-index="${i}"]`);
      items.push({
        name: String(file.name || ""),
        mimeType: String(file.type || "application/octet-stream"),
        size: file.size,
        attach: cb ? cb.checked !== false : true,
        base64: await toBase64Content(file)
      });
    }
    sessionStorage.setItem(EMAIL_LOCAL_ATTACHMENTS_SESSION_KEY, JSON.stringify({ v: 3, items }));
  } catch (e) {
    const quota =
      e && (e.name === "QuotaExceededError" || e.code === 22 || String(e.message || "").toLowerCase().includes("quota"));
    if (quota) showMessage("Attachments are too large for the browser to keep after refresh. Send the email or use smaller files.", true);
  }
}

function persistLocalAttachmentCheckboxMeta() {
  if (!window.sessionStorage || !localFilesInput || !attachmentList) return;
  let raw;
  try {
    raw = sessionStorage.getItem(EMAIL_LOCAL_ATTACHMENTS_SESSION_KEY);
  } catch {
    return;
  }
  if (!raw) return;
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return;
  }
  const itemsIn = parsed?.items;
  if (!Array.isArray(itemsIn)) return;
  const files = [...localFilesInput.files];
  if (files.length !== itemsIn.length) {
    schedulePersistEmailLocalAttachments();
    return;
  }
  for (let i = 0; i < files.length; i++) {
    const meta = itemsIn[i];
    if (
      String(meta?.name || "") !== String(files[i].name || "") ||
      Number(meta?.size || -1) !== Number(files[i].size)
    ) {
      schedulePersistEmailLocalAttachments();
      return;
    }
    const cb = attachmentList.querySelector(`input.email-local-attach-checkbox[data-local-index="${i}"]`);
    meta.attach = cb ? cb.checked !== false : true;
  }
  try {
    sessionStorage.setItem(EMAIL_LOCAL_ATTACHMENTS_SESSION_KEY, JSON.stringify({ v: 3, items: itemsIn }));
  } catch {
    //
  }
}

function clearStoredLocalAttachments() {
  try {
    sessionStorage.removeItem(EMAIL_LOCAL_ATTACHMENTS_SESSION_KEY);
  } catch {
    //
  }
}

async function restoreLocalAttachmentsFromSession() {
  if (!localFilesInput || !attachmentList || !window.sessionStorage) return;
  let raw;
  try {
    raw = sessionStorage.getItem(EMAIL_LOCAL_ATTACHMENTS_SESSION_KEY);
  } catch {
    return;
  }
  if (!raw) return;
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    clearStoredLocalAttachments();
    return;
  }
  const items = parsed?.items;
  if (!Array.isArray(items) || !items.length) {
    clearStoredLocalAttachments();
    return;
  }
  const uncheckedKeys = new Set();
  const dt = new DataTransfer();
  for (const item of items) {
    const name = String(item.name || "");
    const mime = String(item.mimeType || "application/octet-stream");
    const b64 = String(item.base64 || "");
    if (!name || !b64) continue;
    try {
      const blob = await fetch(`data:${mime};base64,${b64}`).then((r) => r.blob());
      const file = new File([blob], name, { type: mime });
      dt.items.add(file);
      if (item.attach === false) uncheckedKeys.add(`${name}::${file.size}`);
    } catch {
      //
    }
  }
  if (!dt.files.length) {
    clearStoredLocalAttachments();
    return;
  }
  localFilesInput.files = dt.files;
  syncLocalAttachmentTiles({ presetUncheckedKeys: uncheckedKeys });
}

/** When the grid HTML was replaced (e.g. library docs reload), DOM has no local tiles - read attach state from sessionStorage. */
function getLocalAttachmentUncheckedKeysFromSession() {
  const keys = new Set();
  if (!window.sessionStorage || !localFilesInput) return keys;
  let raw;
  try {
    raw = sessionStorage.getItem(EMAIL_LOCAL_ATTACHMENTS_SESSION_KEY);
  } catch {
    return keys;
  }
  if (!raw) return keys;
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return keys;
  }
  const items = parsed?.items;
  if (!Array.isArray(items)) return keys;
  const files = [...localFilesInput.files];
  for (let i = 0; i < files.length && i < items.length; i++) {
    const f = files[i];
    const meta = items[i];
    if (String(meta?.name || "") !== String(f.name || "")) continue;
    if (Number(meta?.size ?? NaN) !== Number(f.size)) continue;
    if (meta.attach === false) keys.add(`${String(f.name)}::${f.size}`);
  }
  return keys;
}

/** Remove one file from the multi-file input (FileList is read-only; rebuild via DataTransfer). */
function removeLocalAttachmentAt(index) {
  if (!localFilesInput || !Number.isInteger(index) || index < 0) return;
  const files = [...localFilesInput.files];
  if (index >= files.length) return;
  files.splice(index, 1);
  const dt = new DataTransfer();
  files.forEach((f) => dt.items.add(f));
  localFilesInput.files = dt.files;
  syncLocalAttachmentTiles();
}

/** Appends/removes tiles in `#emailAttachmentList` for computer files + updates hint below file input. */
function syncLocalAttachmentTiles(options = {}) {
  const presetUncheckedKeys = options.presetUncheckedKeys;
  const files = localFilesInput?.files ? [...localFilesInput.files] : [];
  const uncheckedKeys = new Set();
  if (presetUncheckedKeys instanceof Set) {
    presetUncheckedKeys.forEach((k) => uncheckedKeys.add(k));
  } else if (attachmentList?.querySelector(".email-local-attach-checkbox")) {
    attachmentList.querySelectorAll(".email-local-attach-checkbox").forEach((cb) => {
      if (cb.checked) return;
      const idx = Number(cb.getAttribute("data-local-index"));
      const f = Number.isInteger(idx) && idx >= 0 ? localFilesInput?.files?.[idx] : null;
      if (f) uncheckedKeys.add(`${String(f.name)}::${f.size}`);
    });
  } else {
    getLocalAttachmentUncheckedKeysFromSession().forEach((k) => uncheckedKeys.add(k));
  }

  if (!attachmentList) {
    if (localFilesList) localFilesList.textContent = files.length ? `${files.length} local file(s)` : "No local files selected.";
    if (!files.length) clearStoredLocalAttachments();
    else schedulePersistEmailLocalAttachments();
    return;
  }

  attachmentList.querySelectorAll(".email-local-attach-tile").forEach((el) => el.remove());

  const placeholderEl = attachmentList.querySelector(".email-doc-attachments-empty");
  if (placeholderEl && files.length > 0) placeholderEl.remove();

  const kbLabel = (f) => `${Math.round((f.size || 0) / 1024)} KB`;
  files.forEach((f, i) => {
    const key = `${String(f.name)}::${f.size}`;
    const attachChecked = !uncheckedKeys.has(key);
    const row = document.createElement("div");
    row.className = "document-row email-attach-tile email-local-attach-tile";
    const nameSafe = escapeHtml(String(f.name || ""));
    row.innerHTML = `<div class="email-local-tile-main">
      <label class="document-attach email-local-attach-inner">
        <input type="checkbox" class="email-local-attach-checkbox email-attach-checkbox" data-local-index="${i}" ${
          attachChecked ? "checked" : ""
        } />
        <span class="email-local-text-stack">
          <span class="email-local-attach-badge">Computer</span>
          <span class="email-attach-filename">${nameSafe}</span>
          <span class="email-local-meta">${escapeHtml(kbLabel(f))}</span>
        </span>
      </label>
      <button type="button" class="email-local-remove-btn" data-local-index="${i}">Remove</button>
    </div>`;
    attachmentList.appendChild(row);
    const rm = row.querySelector(".email-local-remove-btn");
    if (rm) rm.setAttribute("aria-label", `Remove ${String(f.name || "file")}`);
    const cb = row.querySelector(".email-local-attach-checkbox");
    if (cb) cb.setAttribute("aria-label", `Attach ${String(f.name || "file")} to email`);
  });

  if (localFilesList) {
    if (!files.length) localFilesList.textContent = "No local files selected.";
    else {
      let selected = 0;
      files.forEach((f, i) => {
        const cb = attachmentList.querySelector(`input.email-local-attach-checkbox[data-local-index="${i}"]`);
        if (cb?.checked) selected += 1;
      });
      localFilesList.textContent = `${selected} of ${files.length} computer file${
        files.length === 1 ? "" : "s"
      } selected for attachment`;
    }
  }

  const libraryTiles = attachmentList.querySelectorAll(".document-row:not(.email-local-attach-tile)");
  const hasLocals = files.length > 0;
  if (!hasLocals && libraryTiles.length === 0 && !attachmentList.querySelector(".email-doc-attachments-empty")) {
    attachmentList.innerHTML =
      '<div class="contact-history-empty email-doc-attachments-empty">No documents available.</div>';
  }

  if (files.length) schedulePersistEmailLocalAttachments();
  else clearStoredLocalAttachments();
}

function renderSelectedLocalFiles() {
  syncLocalAttachmentTiles();
}

async function toBase64Content(file) {
  const dataUrl = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error(`Failed to read ${file.name}`));
    reader.readAsDataURL(file);
  });
  const idx = dataUrl.indexOf(",");
  return idx >= 0 ? dataUrl.slice(idx + 1) : dataUrl;
}

async function collectDirectAttachments() {
  const files = localFilesInput?.files ? [...localFilesInput.files] : [];
  if (!files.length) return [];
  const output = [];
  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const cb = attachmentList?.querySelector(`input.email-local-attach-checkbox[data-local-index="${i}"]`);
    if (cb && !cb.checked) continue;
    const contentBase64 = await toBase64Content(file);
    output.push({
      fileName: String(file.name || "").trim(),
      mimeType: String(file.type || "application/octet-stream").trim(),
      contentBase64
    });
  }
  return output;
}

/** Detail for each From option (source + whether it has its own SMTP login).
 *  Populated by loadFromOptions; used to warn when a chosen sender will be
 *  silently rewritten by the mail server to the default authenticated account. */
let emailFromAddressDetail = [];

/** A From address sends "as itself" only when it logs into its own mailbox:
 *  it IS the authenticated SMTP user, or it has its own per-address SMTP saved.
 *  Otherwise the mail server authenticates with the default account and may
 *  rewrite the visible sender to that account (the confusing "sent from the
 *  wrong address" surprise). */
function fromAddressSendsAsItself(email) {
  const key = String(email || "").trim().toLowerCase();
  if (!key) return true; // nothing selected - don't warn
  const detail = emailFromAddressDetail.find(
    (d) => String(d?.email || "").trim().toLowerCase() === key
  );
  if (!detail) return true; // unknown (e.g. an env default) - don't warn
  if (detail.source === "smtp_user") return true; // the authenticated mailbox itself
  if (detail.source === "custom" && detail.hasSmtp === true) return true; // its own SMTP login
  if (detail.source === "smtp_from") {
    // SMTP_FROM authenticates via SMTP_USER. Safe only when there is no *different*
    // authenticated user (i.e. SMTP_FROM === SMTP_USER, de-duplicated to one entry).
    const hasDifferentAuthUser = emailFromAddressDetail.some(
      (d) => d?.source === "smtp_user" && String(d?.email || "").trim().toLowerCase() !== key
    );
    return !hasDifferentAuthUser;
  }
  return false; // custom address with no SMTP login of its own
}

function updateFromSmtpNotice() {
  if (!fromSelect) return;
  let notice = document.getElementById("emailFromSmtpNotice");
  const selected = String(fromSelect.value || "").trim();
  const risky = Boolean(selected) && !fromAddressSendsAsItself(selected);
  if (!risky) {
    if (notice) notice.hidden = true;
    return;
  }
  if (!notice) {
    notice = document.createElement("div");
    notice.id = "emailFromSmtpNotice";
    notice.setAttribute("role", "status");
    notice.style.cssText =
      "margin:6px 0 2px;padding:8px 12px;border-radius:8px;background:#fef3c7;" +
      "border:1px solid #f59e0b;color:#92400e;font-size:13px;line-height:1.45;";
    const row = fromSelect.closest(".agile-email-field-row") || fromSelect.parentElement;
    if (row) row.insertAdjacentElement("afterend", notice);
    else fromSelect.insertAdjacentElement("afterend", notice);
  }
  const safe = escapeHtml(selected);
  notice.innerHTML =
    "⚠️ <strong>" +
    safe +
    "</strong> has no mailbox login of its own, so your mail server signs in with your default " +
    "account and may show that account as the sender instead. To actually send as <strong>" +
    safe +
    '</strong>, add its SMTP login under <a href="/settings.html">Settings → Email Sender Addresses</a>.';
  notice.hidden = false;
}

async function loadFromOptions() {
  const { response, data } = await fetchApiJson("/api/email/options");
  if (!response.ok) throw new Error(data.error || "Failed to load from options");
  const opts = Array.isArray(data.fromOptions) ? data.fromOptions : [];
  emailFromAddressDetail = Array.isArray(data.fromAddresses) ? data.fromAddresses : [];
  fromSelect.innerHTML = "";
  if (!opts.length) {
    const o = document.createElement("option");
    o.value = "";
    o.textContent = "No sender configured";
    fromSelect.appendChild(o);
    lastFromAddressValue = "";
    maybeClearMirroredCcFromAddress("");
    return;
  }
  for (const from of opts) {
    const o = document.createElement("option");
    o.value = from;
    o.textContent = from;
    fromSelect.appendChild(o);
  }
  if (typeof prefillSignatureForAllFromAddresses === "function") {
    const prefilled = prefillSignatureForAllFromAddresses(opts);
    if (prefilled && typeof window.persistEmailSignatureToServer === "function") {
      try {
        await window.persistEmailSignatureToServer(window.buildEmailSignaturePayloadFromLocal());
      } catch {
        /* non-fatal */
      }
    }
  }
  const selectedFrom = String(fromSelect?.value || "").trim();
  maybeClearMirroredCcFromAddress(selectedFrom);
  lastFromAddressValue = selectedFrom;
  updateFromSmtpNotice();
}

function appendContactSelectOption(parent, id, displayName, email) {
  const o = document.createElement("option");
  o.value = String(id);
  o.textContent = `${displayName || "Contact"} <${email}>`;
  o.setAttribute("data-email", email);
  parent.appendChild(o);
}

async function loadContacts() {
  if (!toManualInput) return;
  const { response, data } = await fetchApiJson("/api/contacts?page=1&limit=200&sortBy=full_name&sortOrder=asc");
  if (!response.ok) throw new Error(data.error || "Failed to load contacts");
  const list = Array.isArray(data.items) ? data.items : Array.isArray(data) ? data : [];
  const preselectedIds = getInitialContactIdsFromQuery();
  const preselected = new Set(preselectedIds);
  const idToEmail = new Map();
  const idToName = new Map();
  for (const c of list) {
    const em = String(c.email || "").trim();
    if (!em || c.id == null) continue;
    const id = Number(c.id);
    idToEmail.set(id, em);
    idToName.set(id, String(c.full_name || "").trim() || "Contact");
    cacheContactMergeFields(c, em);
  }
  const missingIds = preselectedIds.filter((id) => !idToEmail.has(id));
  for (const id of missingIds) {
    try {
      const { response: r, data: row } = await fetchApiJson(`/api/contacts/${encodeURIComponent(id)}`);
      if (r.ok && row && String(row.email || "").trim()) {
        idToEmail.set(id, String(row.email).trim());
        idToName.set(id, String(row.full_name || "").trim() || "Contact");
        cacheContactMergeFields(row, String(row.email).trim());
      }
    } catch {
      //
    }
  }
  const seenEmails = new Set();
  const recipientsOrdered = [];
  for (const id of preselectedIds) {
    const em = idToEmail.get(id);
    if (!em || seenEmails.has(em.toLowerCase())) continue;
    seenEmails.add(em.toLowerCase());
    recipientsOrdered.push({
      id,
      full_name: idToName.get(id) || "Contact",
      email: em
    });
  }
  const emailsOrdered = recipientsOrdered.map((r) => r.email);
  if (emailsOrdered.length && !composeToFieldTouched) {
    toManualInput.value = emailsOrdered.join(", ");
    maybeClearMirroredCcFromTo(toManualInput.value || "");
  } else if (!emailsOrdered.length) {
    let firstMatched = "";
    for (const c of list) {
      const em = String(c.email || "").trim();
      if (!em || c.id == null) continue;
      if (preselected.has(Number(c.id))) {
        firstMatched = em;
        break;
      }
    }
    if (firstMatched && !composeToFieldTouched) {
      toManualInput.value = firstMatched;
      maybeClearMirroredCcFromTo(firstMatched);
    }
  }
}

function updateEmailTemplatesWorkspaceBanner(rows) {
  const banner = document.getElementById("emailTemplatesWorkspaceBanner");
  const textEl = document.getElementById("emailTemplatesWorkspaceBannerText");
  if (!banner || !textEl || !isEmailTemplatesOnlyPage) return;

  const count = Array.isArray(rows) ? rows.length : 0;
  const wsType = window.__CRM_WORKSPACE_TYPE__ || "owner";
  const isTrial = wsType === "trial";

  if (isTrial) {
    banner.hidden = false;
    banner.classList.add("email-templates-workspace-banner--trial");
    textEl.innerHTML =
      `<strong>Trial workspace:</strong> Saved templates you created on the main operator login are stored separately and will not appear here. ` +
      `Use <a href="/login.html">Log in</a> with your Settings sign-in email (not a trial signup email) to see them. ` +
      `Use the <strong>Starter templates</strong> section on this page - click <strong>Use this</strong>, then Save.`;
    return;
  }

  if (count === 0) {
    banner.hidden = false;
    banner.classList.remove("email-templates-workspace-banner--trial");
    textEl.innerHTML =
      `<strong>No saved templates in this workspace.</strong> Use the <strong>Starter templates</strong> section above (click <strong>Use this</strong>), or restore <code>crm.sqlite</code> from a cPanel backup if a deploy replaced your database.`;
    return;
  }

  banner.hidden = false;
  banner.classList.remove("email-templates-workspace-banner--trial");
  textEl.innerHTML =
    `<strong>Operator workspace - ${count} saved template${count === 1 ? "" : "s"} loaded.</strong> ` +
    `Open <strong>Your Saved Templates</strong> at the bottom of this page and click a category to view and edit them. ` +
    `Starter layouts are in the section above.`;
}

async function loadTemplates() {
  const { response, data } = await fetchApiJson("/api/email/templates");
  if (!response.ok) throw new Error(data.error || "Failed to load templates");
  const rows = Array.isArray(data) ? data : [];
  emailTemplateRowsCache = rows;
  window.__CRM_EMAIL_TEMPLATE_ROWS__ = rows;
  window.CadenceEmailTemplateActions = {
    loadTemplateIntoEditForm,
    deleteEmailTemplateById
  };
  updateEmailTemplatesWorkspaceBanner(rows);
  // Templates page keeps the menu the person already chose. First visit stays on Choose Category.
  if (!isEmailTemplatesOnlyPage) selectedTemplateCategory = "";
  renderTemplatesByCategory();
  if (templateSelect) {
    templateSelect.innerHTML = '<option value="">No template</option>';
  }
  if (templateEditSelect) {
    templateEditSelect.innerHTML = '<option value="">Select template to edit</option>';
  }
  if (templateEditSelect) {
    for (const t of rows) {
      const editOpt = document.createElement("option");
      editOpt.value = String(t.id);
      const categoryName = String(t.category_name || "").trim();
      editOpt.textContent = categoryName ? `${categoryName} - ${t.name}` : t.name;
      templateEditSelect.appendChild(editOpt);
    }
  }
  // "Choose Template" dropdown: group templates under their category using
  // disabled header rows (optgroup renders poorly in selects on Windows here).
  if (templateSelect) {
    const groups = buildTemplateCategoryGroups();
    const categoryNames = [...groups.keys()]
      .filter((name) => (groups.get(name) || []).length > 0)
      .sort((a, b) => {
        if (a === "Uncategorized") return 1;
        if (b === "Uncategorized") return -1;
        return a.localeCompare(b, undefined, { sensitivity: "base" });
      });
    for (const name of categoryNames) {
      const header = document.createElement("option");
      header.disabled = true;
      header.className = "email-template-group-label";
      header.textContent = name;
      templateSelect.appendChild(header);
      const items = [...(groups.get(name) || [])].sort((x, y) =>
        String(x.name || "").localeCompare(String(y.name || ""), undefined, { sensitivity: "base" })
      );
      for (const t of items) {
        const o = document.createElement("option");
        o.value = String(t.id);
        o.textContent = `   ${t.name}`;
        o.setAttribute("data-subject", String(t.subject || ""));
        o.setAttribute("data-body", String(t.body || ""));
        templateSelect.appendChild(o);
      }
    }
  }
}

function setTemplateFormMode(editing) {
  const isEdit = !!editing;
  if (saveTemplateSubmitBtn) {
    saveTemplateSubmitBtn.textContent = isEdit ? "Update template" : "Save template";
  }
  const editorHeading = document.getElementById("emailTemplateEditorHeading");
  if (editorHeading) editorHeading.textContent = isEdit ? "Editing template" : "New template";
  if (cancelTemplateEditBtn) {
    cancelTemplateEditBtn.style.display = isEdit ? "" : "none";
  }
  if (saveTemplateAsNewBtn) {
    saveTemplateAsNewBtn.hidden = !isEdit;
  }
  updateTemplateUndoButton();
}

function isTemplateEditorEditMode() {
  const id = Number(saveTemplateForm?.querySelector('[name="template_id"]')?.value || "");
  return Number.isInteger(id) && id > 0;
}

function captureTemplateEditSnapshot() {
  return {
    name: String(saveTemplateForm?.querySelector('[name="name"]')?.value ?? ""),
    subject: String(saveTemplateForm?.querySelector('[name="subject"]')?.value ?? ""),
    category: String(templateCategoryNameInput?.value ?? ""),
    bodyHtml: String(templateBodyEditor?.innerHTML ?? "")
  };
}

function templateEditSnapshotsEqual(a, b) {
  return (
    a.name === b.name &&
    a.subject === b.subject &&
    a.category === b.category &&
    a.bodyHtml === b.bodyHtml
  );
}

function applyTemplateEditSnapshot(snap) {
  if (!saveTemplateForm || !snap) return;
  templateApplyingEditSnapshot = true;
  try {
    const nameEl = saveTemplateForm.querySelector('[name="name"]');
    const subjectEl = saveTemplateForm.querySelector('[name="subject"]');
    if (nameEl) nameEl.value = snap.name;
    if (subjectEl) subjectEl.value = snap.subject;
    if (templateCategoryNameInput) templateCategoryNameInput.value = snap.category;
    if (templateBodyEditor) {
      setRichEditorContent(templateBodyEditor, snap.bodyHtml);
      normalizeWrappedImages(templateBodyEditor);
    }
  } finally {
    templateApplyingEditSnapshot = false;
  }
}

function resetTemplateEditHistory() {
  templateUndoHistoryStack = [];
  templateUndoLastCommittedSnapshot = null;
  if (templateHistoryRecordTimer) {
    window.clearTimeout(templateHistoryRecordTimer);
    templateHistoryRecordTimer = null;
  }
  updateTemplateUndoButton();
}

function initTemplateEditHistoryBaseline() {
  if (!isEmailTemplatesOnlyPage || !templateBodyEditor || !saveTemplateForm) return;
  templateUndoHistoryStack = [];
  templateUndoLastCommittedSnapshot = captureTemplateEditSnapshot();
  if (templateHistoryRecordTimer) {
    window.clearTimeout(templateHistoryRecordTimer);
    templateHistoryRecordTimer = null;
  }
  updateTemplateUndoButton();
}

function scheduleTemplateEditHistoryRecord() {
  if (!isEmailTemplatesOnlyPage || !templateBodyEditor || !saveTemplateForm) return;
  if (templateApplyingEditSnapshot) return;
  if (templateHistoryRecordTimer) window.clearTimeout(templateHistoryRecordTimer);
  templateHistoryRecordTimer = window.setTimeout(() => {
    templateHistoryRecordTimer = null;
    recordTemplateEditHistoryNow();
  }, 450);
}

function recordTemplateEditHistoryNow() {
  if (templateApplyingEditSnapshot) return;
  if (!isEmailTemplatesOnlyPage || !templateBodyEditor || !saveTemplateForm) return;
  const snap = captureTemplateEditSnapshot();
  if (templateUndoLastCommittedSnapshot && templateEditSnapshotsEqual(snap, templateUndoLastCommittedSnapshot)) return;
  if (templateUndoLastCommittedSnapshot) {
    templateUndoHistoryStack.push(templateUndoLastCommittedSnapshot);
    if (templateUndoHistoryStack.length > TEMPLATE_UNDO_HISTORY_LIMIT) {
      templateUndoHistoryStack = templateUndoHistoryStack.slice(-TEMPLATE_UNDO_HISTORY_LIMIT);
    }
  }
  templateUndoLastCommittedSnapshot = snap;
  updateTemplateUndoButton();
}

function updateTemplateUndoButton() {
  if (!templateEditUndoBtn) return;
  templateEditUndoBtn.hidden = false;
  templateEditUndoBtn.disabled = templateUndoHistoryStack.length < 1;
}

function undoTemplateEditStep() {
  if (!isEmailTemplatesOnlyPage || !templateBodyEditor || !saveTemplateForm) return;
  if (templateHistoryRecordTimer) {
    window.clearTimeout(templateHistoryRecordTimer);
    templateHistoryRecordTimer = null;
    recordTemplateEditHistoryNow();
  }
  const previousSnapshot = templateUndoHistoryStack.pop();
  if (!previousSnapshot) {
    updateTemplateUndoButton();
    return;
  }
  applyTemplateEditSnapshot(previousSnapshot);
  templateUndoLastCommittedSnapshot = previousSnapshot;
  updateTemplateUndoButton();
  setTemplateSaveFeedback(templateUndoHistoryStack.length ? "Last edit undone. Click again to undo the previous change." : "Last edit undone.");
}

function resetTemplateEditMode() {
  if (!saveTemplateForm) return;
  setEditingTemplateId(0);
  if (templateEditSelect) templateEditSelect.value = "";
  setTemplateFormMode(false);
  initTemplateEditHistoryBaseline();
}

function setEditingTemplateId(templateId) {
  const id = Number(templateId);
  const safeId = Number.isInteger(id) && id > 0 ? id : 0;
  window.__CRM_CURRENT_TEMPLATE_EDIT_ID__ = safeId;
  if (saveTemplateForm) {
    if (safeId) saveTemplateForm.dataset.editingTemplateId = String(safeId);
    else delete saveTemplateForm.dataset.editingTemplateId;
    const idField = saveTemplateForm.querySelector('[name="template_id"]');
    if (idField) idField.value = safeId ? String(safeId) : "";
  }
  return safeId;
}

function getEditingTemplateId() {
  const idFromForm = Number(saveTemplateForm?.querySelector('[name="template_id"]')?.value || "");
  const idFromDataset = Number(saveTemplateForm?.dataset?.editingTemplateId || "");
  const idFromDropdown = Number(templateEditSelect?.value || "");
  const idFromWindow = Number(window.__CRM_CURRENT_TEMPLATE_EDIT_ID__ || "");
  for (const id of [idFromForm, idFromDataset, idFromDropdown, idFromWindow]) {
    if (Number.isInteger(id) && id > 0) return id;
  }
  return 0;
}

function applyTemplateRowToEditForm(row) {
  if (!saveTemplateForm || !row) return false;
  const id = Number(row.id);
  if (!Number.isInteger(id) || id < 1) return false;
  const nameField = saveTemplateForm.querySelector('[name="name"]');
  const subjectField = saveTemplateForm.querySelector('[name="subject"]');
  setEditingTemplateId(id);
  if (nameField) nameField.value = String(row.name || "");
  if (subjectField) subjectField.value = String(row.subject || "");
  if (templateCategoryNameInput) {
    templateCategoryNameInput.value = String(row.category_name || row.category || "");
  }
  if (templateBodyEditor) {
    setRichEditorContent(
      templateBodyEditor,
      clampBodyImageHtml(String(row.body || row.html || ""), RICH_EMAIL_TEMPLATE_IMAGE_MAX_PX)
    );
    normalizeWrappedImages(templateBodyEditor);
    normalizeCadenceCtaButtonsInEditor(templateBodyEditor);
  }
  if (templateEditSelect) {
    const value = String(id);
    if (![...templateEditSelect.options].some((opt) => opt.value === value)) {
      const opt = document.createElement("option");
      opt.value = value;
      const categoryName = String(row.category_name || row.category || "").trim();
      opt.textContent = categoryName ? `${categoryName} - ${row.name || value}` : String(row.name || value);
      templateEditSelect.appendChild(opt);
    }
    templateEditSelect.value = value;
  }
  setTemplateFormMode(true);
  initTemplateEditHistoryBaseline();
  if (window.CrmUnsavedGuard) window.CrmUnsavedGuard.markClean();
  return true;
}

function loadTemplateIntoEditForm(templateId, rowOverride) {
  if (!saveTemplateForm) return false;
  const id = Number(templateId);
  if (!Number.isInteger(id) || id < 1) return false;
  let row = rowOverride && Number(rowOverride.id) === id ? rowOverride : null;
  if (!row) row = emailTemplateRowsCache.find((t) => Number(t.id) === id) || null;
  // Gallery "Use this" can run before the edit-form cache is populated.
  if (!row && Array.isArray(window.__CRM_EMAIL_TEMPLATE_ROWS__)) {
    row = window.__CRM_EMAIL_TEMPLATE_ROWS__.find((t) => Number(t.id) === id) || null;
  }
  if (!row) return false;
  return applyTemplateRowToEditForm(row);
}

/** Used by Email Templates gallery thumbnails (Use this / Preview → Use this). */
function loadTemplateFromGalleryCard(card) {
  if (!card) return false;
  const id = Number(card.savedId || card.id);
  if (!Number.isInteger(id) || id < 1) return false;
  const row = {
    id,
    name: String(card.name || ""),
    subject: String(card.subject || ""),
    body: String(card._rawHtml || card.html || card.body || ""),
    category_name:
      String(card.category_name || "").trim() ||
      (String(card.category || "").trim() === "Your Templates" ? "" : String(card.category || "").trim())
  };
  // Keep gallery + editor caches aligned so later deletes/edits resolve the row.
  const idx = emailTemplateRowsCache.findIndex((t) => Number(t.id) === id);
  if (idx >= 0) emailTemplateRowsCache[idx] = { ...emailTemplateRowsCache[idx], ...row };
  else emailTemplateRowsCache.push(row);
  window.__CRM_EMAIL_TEMPLATE_ROWS__ = emailTemplateRowsCache;
  return applyTemplateRowToEditForm(row);
}

async function deleteEmailTemplateById(id) {
  const templateId = Number(id);
  if (!Number.isInteger(templateId) || templateId < 1) {
    throw new Error("Select a valid template to delete.");
  }
  const row = emailTemplateRowsCache.find((t) => Number(t.id) === templateId);
  const label = row && String(row.name || "").trim() ? String(row.name).trim() : `Template #${templateId}`;
  if (!window.confirm(`Delete template "${label}"? This cannot be undone.`)) return false;
  const { response, data } = await fetchApiJson(`/api/email/templates/${templateId}`, { method: "DELETE" });
  if (!response.ok) throw new Error(data.error || "Failed to delete template");
  const composeHad = templateSelect && Number(templateSelect.value) === templateId;
  if (composeHad) {
    templateSelect.value = "";
    if (subjectInput) subjectInput.value = "";
    if (emailBodyEditor) emailBodyEditor.innerHTML = "";
  }
  if (saveTemplateForm) saveTemplateForm.reset();
  if (templateBodyEditor) templateBodyEditor.innerHTML = "";
  resetTemplateEditMode();
  setTemplateSaveFeedback("Template deleted.");
  const previousCategory = selectedTemplateCategory;
  const previousSearch = templateSearchTerm;
  await Promise.all([loadTemplates(), loadTemplateCategories()]);
  if (previousCategory) {
    selectedTemplateCategory = previousCategory;
    templateSearchTerm = previousSearch;
    renderTemplatesByCategory();
  }
  document.dispatchEvent(new CustomEvent("crm:email-template-saved"));
  if (window.CrmUnsavedGuard) window.CrmUnsavedGuard.markClean();
  return true;
}

function clearSaveTemplateFormForNew() {
  if (!saveTemplateForm) return;
  const nameField = saveTemplateForm.querySelector('[name="name"]');
  const subjectField = saveTemplateForm.querySelector('[name="subject"]');
  setEditingTemplateId(0);
  if (nameField) nameField.value = "";
  if (subjectField) subjectField.value = "";
  if (templateCategoryNameInput) templateCategoryNameInput.value = "";
  if (templateBodyEditor) templateBodyEditor.innerHTML = "";
  if (templateEditSelect) templateEditSelect.value = "";
  setTemplateFormMode(false);
  initTemplateEditHistoryBaseline();
}

async function loadTemplateCategories() {
  if (!emailTemplateCategoryList && !savedTemplatesByCategory) return;
  const { response, data } = await fetchApiJson("/api/email/template-categories");
  if (!response.ok) throw new Error(data.error || "Failed to load template categories");
  const rows = Array.isArray(data) ? data : [];
  emailTemplateCategoriesCache = rows;
  if (emailTemplateCategoryList) {
    emailTemplateCategoryList.innerHTML = rows
      .map((row) => `<option value="${escapeHtml(String(row.name || ""))}"></option>`)
      .join("");
  }
  if (savedTemplatesByCategory) renderTemplatesByCategory();
}

async function loadAttachments() {
  if (!attachmentList) return;
  const { response, data } = await fetchApiJson("/api/documents");
  if (!response.ok) throw new Error(data.error || "Failed to load documents");
  emailLibraryDocumentsCache = Array.isArray(data) ? data : [];
  selectedLibraryAttachmentIds.forEach((id) => {
    if (!emailLibraryDocumentsCache.some((d) => Number(d.id) === Number(id))) {
      selectedLibraryAttachmentIds.delete(id);
    }
  });
  if (emailAttachmentSelect) {
    const previous = String(emailAttachmentSelect.value || "");
    emailAttachmentSelect.innerHTML = '<option value="">Select a saved document</option>';
    emailLibraryDocumentsCache.forEach((d) => {
      const opt = document.createElement("option");
      opt.value = String(d.id);
      opt.textContent = String(d.file_name || `Document #${d.id}`);
      emailAttachmentSelect.appendChild(opt);
    });
    if (previous && emailLibraryDocumentsCache.some((d) => String(d.id) === previous)) {
      emailAttachmentSelect.value = previous;
    }
  }
  renderSelectedLibraryAttachmentTiles();
  syncLocalAttachmentTiles();
}

if (templateSelect && subjectInput && emailBodyEditor) {
  templateSelect.addEventListener("change", async () => {
    const selected = templateSelect.options[templateSelect.selectedIndex];
    if (!selected) return;
    const templateId = Number(templateSelect.value);
    if (!Number.isInteger(templateId) || templateId < 1) {
      clearSaveTemplateFormForNew();
      return;
    }
    const subj = String(selected.getAttribute("data-subject") || "");
    const body = String(selected.getAttribute("data-body") || "");
    /* Load the template with its merge tokens INTACT (e.g. {{first_name}}).
       Do NOT bake one contact's values into the editor here - tokens are resolved
       per-recipient at send time (single send AND "Send to a Tag" campaigns), and
       the live preview / send-confirm dialog show a merged sample. Pre-merging used
       to flatten the body to the first/loaded contact, so every recipient of a tag
       campaign received that one person's name. Keep the editor token-faithful. */
    if (subj) {
      subjectInput.value = subj;
    }
    if (body) {
      setRichEditorContent(
        emailBodyEditor,
        clampBodyImageHtml(body, RICH_EMAIL_COMPOSE_IMAGE_MAX_PX)
      );
      normalizeWrappedImages(emailBodyEditor);
    }
    loadTemplateIntoEditForm(templateId);
  });
}

if (localFilesInput) {
  localFilesInput.addEventListener("change", renderSelectedLocalFiles);
}

if (attachmentList) {
  attachmentList.addEventListener("click", async (event) => {
    const libBtn = event.target?.closest?.(".email-library-remove-btn");
    if (libBtn && attachmentList.contains(libBtn)) {
      event.preventDefault();
      event.stopPropagation();
      const docId = Number(libBtn.getAttribute("data-doc-id"));
      if (!Number.isInteger(docId) || docId < 1) return;
      selectedLibraryAttachmentIds.delete(docId);
      renderSelectedLibraryAttachmentTiles();
      showMessage("Removed from this email only.", false);
      return;
    }
    const btn = event.target && event.target.closest ? event.target.closest(".email-local-remove-btn") : null;
    if (!btn || !attachmentList.contains(btn)) return;
    event.preventDefault();
    event.stopPropagation();
    const idx = Number(btn.getAttribute("data-local-index"));
    if (!Number.isInteger(idx) || idx < 0) return;
    removeLocalAttachmentAt(idx);
  });
  attachmentList.addEventListener("change", (event) => {
    const cb = event.target && event.target.closest ? event.target.closest(".email-local-attach-checkbox") : null;
    if (!cb || !attachmentList.contains(cb) || !localFilesList || !localFilesInput) return;
    const files = [...localFilesInput.files];
    if (!files.length) return;
    let selected = 0;
    files.forEach((_, i) => {
      const box = attachmentList.querySelector(`input.email-local-attach-checkbox[data-local-index="${i}"]`);
      if (box?.checked) selected += 1;
    });
    localFilesList.textContent = `${selected} of ${files.length} computer file${
      files.length === 1 ? "" : "s"
    } selected for attachment`;
    persistLocalAttachmentCheckboxMeta();
  });
}

if (emailAttachmentAddBtn) {
  emailAttachmentAddBtn.addEventListener("click", () => {
    const id = Number(emailAttachmentSelect?.value || "");
    if (!Number.isInteger(id) || id < 1) {
      showMessage("Choose a saved document first.", true);
      return;
    }
    selectedLibraryAttachmentIds.add(id);
    renderSelectedLibraryAttachmentTiles();
    showMessage("Attachment added.");
  });
}

async function performSendEmail(isQuickSend) {
  if (isQuickSend) {
    showQuickSendTopStatus("Email Sending...", false);
    showMessage("", false);
  } else {
    showMessage("Email Sending", false);
  }
  const recipientEmails = parseToRecipientList(toManualInput?.value || "");
  if (!recipientEmails.length) throw new Error("Enter at least one To email address.");
  const to = recipientEmails.join(", ");
  await refreshCustomMergeFieldsCache();
  const subject = getEffectiveSubject();
  const templateIdNum = templateSelect?.value ? Number(templateSelect.value) : NaN;
  const hasTemplate = Number.isInteger(templateIdNum) && templateIdNum > 0;
  const directAttachments = await collectDirectAttachments();
  const composed = await getComposedEmailContent();
  const mergeFields = await getSelectedContactMergeFields();
  const customFields = getCustomMergeFieldsMap();
  const mergeOpts = { customFields };
  const mergedSubject = applyMergeFields(subject, mergeFields, mergeOpts);
  const mergedText = applyMergeFields(composed.text, mergeFields, mergeOpts);
  const mergedHtml = applyMergeFields(composed.html, mergeFields, { ...mergeOpts, keepHtmlNbsp: true });
  const hasBody = Boolean(String(composed.text || "").trim() || String(composed.html || "").trim());
  if (!hasBody && !hasTemplate) {
    throw new Error("Enter a message in the body and/or email signature (or choose a template).");
  }
  const ccNorm = normalizeCommaSeparatedEmails(String(emailCcInput?.value || ""));
  const primaryContactId = resolvePrimaryContactIdForSend();
  const payload = {
    from: String(fromSelect?.value || "").trim(),
    to,
    recipientEmails,
    subject: mergedSubject,
    text: mergedText,
    html: mergedHtml,
    attachmentIds: collectAttachmentIds(),
    directAttachments,
    enableTracking: Boolean(emailEnableTrackingStub?.checked)
  };
  if (Number.isInteger(primaryContactId) && primaryContactId > 0) {
    payload.contactId = primaryContactId;
  }
  if (ccNorm) payload.cc = ccNorm;
  window.crmSuppressEmailOpenAlertsUntil = Date.now() + 120000;
  const { response, data } = await fetchApiJson("/api/email/send", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  if (!response.ok) throw new Error(data.error || "Failed to send email");
  window.crmSuppressEmailOpenAlertsUntil = 0;
  clearComposeAfterSuccessfulSend();
  syncLocalAttachmentTiles();
  const sentLine = isQuickSend
    ? "Sent."
    : `Email sent${mergedSubject ? `: ${mergedSubject}` : ""}. Attachments: ${data.attachments || 0}${
        data.trackingEnabled ? " - open tracking on" : ""
      }${data.bccBulk ? ` - ${data.bccRecipientCount || ""} recipients via Bcc (only your From address visible in To)` : ""}`;
  if (typeof window.crmShowEmailAlert === "function") {
    window.crmShowEmailAlert(sentLine, { tone: true });
  }
  if (isQuickSend) {
    showQuickSendTopStatus("Sent", false, 5000);
    showMessage("", false);
  } else {
    showTimedSuccessMessage(sentLine, 5000);
  }
  if (String(data.trackingWarning || "").trim()) {
    showMessage(String(data.trackingWarning).trim(), true);
  }
  if (Array.isArray(data.skippedDoNotEmail) && data.skippedDoNotEmail.length) {
    showMessage(`Skipped - "Do Not Email" is set for: ${data.skippedDoNotEmail.join(", ")}`, true);
  }
}

if (sendEmailForm) {
  sendEmailForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const isQuickSend = sendEmailForm.dataset.quickSend === "1";
    try {
      const recipientEmails = parseToRecipientList(toManualInput?.value || "");
      if (!recipientEmails.length) throw new Error("Enter at least one To email address.");
      const subject = String(getEffectiveSubject() || "").trim();
      if (!subject) throw new Error("Enter a subject line.");
      const composed = await getComposedEmailContent();
      const templateIdNum = templateSelect?.value ? Number(templateSelect.value) : NaN;
      const hasTemplate = Number.isInteger(templateIdNum) && templateIdNum > 0;
      const hasBody = Boolean(String(composed.text || "").trim() || String(composed.html || "").trim());
      if (!hasBody && !hasTemplate) {
        throw new Error("Enter a message in the body and/or email signature (or choose a template).");
      }
      /* Group-send personalization guard: a plain multi-recipient send is one
         shared BCC copy, so {{first_name}} etc. can only resolve to ONE contact
         (everyone gets that same name). Detect personalization from the RAW
         template (tokens are already merged out of the editor by now) and from
         anything typed in the body, then warn before sending to 2+ people. */
      if (recipientEmails.length >= 2) {
        const tokenRe = /\{\{\s*[\w.]+\s*\}\}/;
        const selectedOpt = templateSelect?.options?.[templateSelect.selectedIndex];
        const rawTemplate =
          String(selectedOpt?.getAttribute("data-body") || "") +
          " " +
          String(selectedOpt?.getAttribute("data-subject") || "");
        const typedNow = `${String(emailBodyEditor?.innerText || "")} ${String(subjectInput?.value || "")}`;
        if (tokenRe.test(rawTemplate) || tokenRe.test(typedNow)) {
          const proceed = window.confirm(
            `⚠️ You're sending to ${recipientEmails.length} recipients, and this message uses personalization like {{first_name}}.\n\n` +
              `A group email sends ONE shared copy, so everyone will get the SAME name (the first recipient's) - not their own.\n\n` +
              `To give each person their own name, click Cancel and use "Send to a Tag" at the bottom of the page instead.\n\n` +
              `Send the group email anyway?`
          );
          if (!proceed) {
            showMessage('Canceled. Use "Send to a Tag" to personalize each recipient.', false);
            delete sendEmailForm.dataset.quickSend;
            return;
          }
        }
      }
      const preview = await buildSendConfirmPreview();
      openSendConfirmModal(preview, async () => {
        try {
          await performSendEmail(isQuickSend);
        } catch (error) {
          if (isQuickSend) {
            showQuickSendTopStatus(error.message, true, 7000);
            showMessage("", false);
          } else {
            showMessage(error.message, true);
          }
        } finally {
          delete sendEmailForm.dataset.quickSend;
        }
      });
    } catch (error) {
      if (isQuickSend) {
        showQuickSendTopStatus(error.message, true, 7000);
        showMessage("", false);
      } else {
        showMessage(error.message, true);
      }
      delete sendEmailForm.dataset.quickSend;
    }
  });
}

if (emailSignatureForm) {
  emailSignatureForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      const defaultBlock = {
        text: getSignatureEditorText(),
        html: getSignatureEditorHtml(),
        fontSize: String(emailSignatureFontSize?.value || "16"),
        color: String(emailSignatureColor?.value || "#1f2937"),
        linkText: String(emailSignatureLinkText?.value || ""),
        linkUrl: String(emailSignatureLinkUrl?.value || ""),
        imageUrl: String(emailSignatureImageUrl?.value || "")
      };
      const include = Boolean(emailIncludeSignature?.checked);
      const fromAddresses = fromSelect
        ? [...fromSelect.options].map((o) => String(o.value || "").trim()).filter(Boolean)
        : [];
      try {
        window.localStorage.setItem(EMAIL_INCLUDE_SIGNATURE_KEY, include ? "1" : "0");
      } catch {
        //
      }
      if (typeof window.syncByFromWithDefaultForAddresses === "function" && fromAddresses.length) {
        window.syncByFromWithDefaultForAddresses(fromAddresses, defaultBlock);
      } else {
        window.localStorage.setItem(EMAIL_SIGNATURE_KEY, JSON.stringify(defaultBlock));
      }
      if (typeof window.persistEmailSignatureToServer === "function") {
        const payload =
          typeof window.buildEmailSignaturePayloadFromLocal === "function"
            ? window.buildEmailSignaturePayloadFromLocal(include)
            : { settings: defaultBlock, include };
        await window.persistEmailSignatureToServer(payload);
      }
      setSignatureSaveFeedback("Signature Saved");
    } catch (error) {
      setSignatureSaveFeedback((error && error.message) || "Failed to save signature.", true);
    }
  });
}

if (emailSignatureEditor) {
  ["mouseup", "keyup", "focus"].forEach((evt) => {
    emailSignatureEditor.addEventListener(evt, () => {
      saveSignatureSelection();
      syncEditorFontSizeDropdown(emailSignatureEditor, signatureInlineFontSize);
    });
  });
  emailSignatureEditor.addEventListener("paste", async (event) => {
    const clipboardItems = event.clipboardData?.items ? [...event.clipboardData.items] : [];
    const imageItem = clipboardItems.find((item) => String(item.type || "").startsWith("image/"));
    if (!imageItem) return;
    event.preventDefault();
    const file = imageItem.getAsFile();
    if (!file) return;
    try {
      const dataUrl = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ""));
        reader.onerror = () => reject(new Error("Failed to paste image"));
        reader.readAsDataURL(file);
      });
      document.execCommand("insertImage", false, dataUrl);
      normalizeSignatureImages();
    } catch {
      // leave editor unchanged on image paste failure
    }
  });
  emailSignatureEditor.addEventListener("input", () => {
    normalizeSignatureImages();
    saveSignatureSelection();
  });
}

if (signatureBoldBtn) {
  signatureBoldBtn.addEventListener("mousedown", (event) => event.preventDefault());
  signatureBoldBtn.addEventListener("click", () => withSignatureEditorFocus(() => document.execCommand("bold")));
}

if (signatureItalicBtn) {
  signatureItalicBtn.addEventListener("mousedown", (event) => event.preventDefault());
  signatureItalicBtn.addEventListener("click", () => withSignatureEditorFocus(() => document.execCommand("italic")));
}

if (signatureUnderlineBtn) {
  signatureUnderlineBtn.addEventListener("mousedown", (event) => event.preventDefault());
  signatureUnderlineBtn.addEventListener("click", () => withSignatureEditorFocus(() => document.execCommand("underline")));
}

if (signatureAlignLeftBtn) {
  signatureAlignLeftBtn.addEventListener("mousedown", (event) => event.preventDefault());
  signatureAlignLeftBtn.addEventListener("click", () =>
    withSignatureEditorFocus(() => applySelectionAlignment(emailSignatureEditor, "left"))
  );
}

if (signatureAlignCenterBtn) {
  signatureAlignCenterBtn.addEventListener("mousedown", (event) => event.preventDefault());
  signatureAlignCenterBtn.addEventListener("click", () =>
    withSignatureEditorFocus(() => applySelectionAlignment(emailSignatureEditor, "center"))
  );
}

if (signatureAlignRightBtn) {
  signatureAlignRightBtn.addEventListener("mousedown", (event) => event.preventDefault());
  signatureAlignRightBtn.addEventListener("click", () =>
    withSignatureEditorFocus(() => applySelectionAlignment(emailSignatureEditor, "right"))
  );
}

if (signatureLinkBtn) {
  signatureLinkBtn.addEventListener("mousedown", (event) => event.preventDefault());
  signatureLinkBtn.addEventListener("click", () =>
    withSignatureEditorFocus(() => {
      const href = window.prompt("Enter link URL:", "https://");
      if (!href || !href.trim()) return;
      document.execCommand("createLink", false, href.trim());
    })
  );
}

if (signatureInlineColor) {
  signatureInlineColor.addEventListener("pointerdown", () => saveSignatureSelection());
  const applySignatureTextColor = () =>
    withSignatureEditorFocus(() => {
      try {
        document.execCommand("styleWithCSS", false, "true");
      } catch {
        //
      }
      document.execCommand("foreColor", false, signatureInlineColor.value || "#1f2937");
    });
  signatureInlineColor.addEventListener("change", applySignatureTextColor);
  signatureInlineColor.addEventListener("input", applySignatureTextColor);
}

if (signatureInlineFontSize) {
  signatureInlineFontSize.addEventListener("change", () => {
    const px = signatureInlineFontSize.value;
    if (!px) return;
    withSignatureEditorFocus(() => applyInlineFontSize(px, emailSignatureEditor));
    syncEditorFontSizeDropdown(emailSignatureEditor, signatureInlineFontSize);
  });
}

if (signatureClearFormatBtn) {
  signatureClearFormatBtn.addEventListener("mousedown", (event) => event.preventDefault());
  signatureClearFormatBtn.addEventListener("click", () =>
    withSignatureEditorFocus(() => {
      clearRichEditorFormatting(emailSignatureEditor);
      saveSignatureSelection();
    })
  );
}

if (signatureAddImageUrlBtn) {
  signatureAddImageUrlBtn.addEventListener("click", () => {
    const url = String(emailSignatureImageUrl?.value || "").trim();
    if (!url) {
      showMessage("Enter an image URL first.", true);
      return;
    }
    insertImageIntoSignature(url);
    showMessage("URL photo added to signature.");
  });
}

if (signatureInsertGraphicUrlBtn) {
  signatureInsertGraphicUrlBtn.addEventListener("click", () => {
    const current = String(emailSignatureImageUrl?.value || "").trim() || "https://";
    const url = String(window.prompt("Enter image URL:", current) || "").trim();
    if (!url || url === "https://") return;
    if (emailSignatureImageUrl) emailSignatureImageUrl.value = url;
    insertImageIntoSignature(url);
    showMessage("Graphic URL added to signature.");
  });
}

if (signatureInsertPhotoBtn && emailSignatureImageFile) {
  signatureInsertPhotoBtn.addEventListener("click", () => {
    emailSignatureImageFile.click();
  });
}

if (emailSignatureImageUrl) {
  emailSignatureImageUrl.addEventListener("keydown", (event) => {
    if (event.key !== "Enter") return;
    event.preventDefault();
    const url = String(emailSignatureImageUrl.value || "").trim();
    if (!url) return;
    insertImageIntoSignature(url);
    showMessage("URL photo added to signature.");
  });
}

if (emailSignatureImageFile) {
  emailSignatureImageFile.addEventListener("change", async () => {
    const file = emailSignatureImageFile.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ""));
        reader.onerror = () => reject(new Error(`Failed to read signature image ${file.name}`));
        reader.readAsDataURL(file);
      });
      insertImageIntoSignature(dataUrl);
      showMessage("Photo added to signature.");
    } catch (error) {
      showMessage(error.message || "Failed to add photo to signature.", true);
    }
  });
}

async function persistEmailTemplate({ saveAsNew = false } = {}) {
  if (!saveTemplateForm) return;
  setTemplateSaveFeedback("");
  showMessage("");
  // Immediate click feedback so it's never "nothing happened": disable the action
  // button and show a working state until the save resolves (restored in finally).
  const saveActionBtn = saveAsNew ? saveTemplateAsNewBtn : saveTemplateSubmitBtn;
  const saveActionLabel = saveActionBtn ? saveActionBtn.textContent : "";
  if (saveActionBtn) {
    saveActionBtn.disabled = true;
    saveActionBtn.textContent = "Saving...";
  }
  try {
    const templateId = Number(saveTemplateForm.querySelector('[name="template_id"]')?.value || "");
    const isEdit = !saveAsNew && Number.isInteger(templateId) && templateId > 0;
    const name = String(saveTemplateForm.querySelector('[name="name"]')?.value || "").trim();
    const subject = String(saveTemplateForm.querySelector('[name="subject"]')?.value || "").trim();
    // Bake the chosen image size (wrapper width) into each <img> so it renders
    // the same in the editor, the preview, and the sent email.
    const bodyHtml = applyResizedImageWrapperSizing(
      clampBodyImageHtml(String(templateBodyEditor?.innerHTML || "").trim(), RICH_EMAIL_TEMPLATE_IMAGE_MAX_PX)
    );
    const categoryName = String(templateCategoryNameInput?.value || "").trim();
    if (!name) throw new Error("Enter a template name before saving.");
    if (!subject) throw new Error("Enter a template subject before saving.");
    if (!richEditorHasMeaningfulContent(templateBodyEditor)) throw new Error("Add a template body before saving.");
    const payload = { name, subject, body: bodyHtml, category_name: categoryName };
    const { response, data } = await fetchApiJson(isEdit ? `/api/email/templates/${templateId}` : "/api/email/templates", {
      method: isEdit ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (!response.ok) throw new Error(data.error || `Failed to ${isEdit ? "update" : "save"} template`);

    if (saveAsNew) {
      await Promise.all([loadTemplates(), loadTemplateCategories()]);
      const newId = Number(data?.id);
      if (Number.isInteger(newId) && newId > 0 && loadTemplateIntoEditForm(newId)) {
        focusSavedTemplateCategory(categoryName, { scroll: false });
        setTemplateSaveFeedback("Saved as new template. You are now editing the copy.");
      } else {
        saveTemplateForm.reset();
        if (templateBodyEditor) templateBodyEditor.innerHTML = "";
        resetTemplateEditMode();
        await Promise.all([loadTemplates(), loadTemplateCategories()]);
        focusSavedTemplateCategory(categoryName);
        setTemplateSaveFeedback("Saved as new template.");
      }
      document.dispatchEvent(new CustomEvent("crm:email-template-saved"));
      if (window.CrmUnsavedGuard) window.CrmUnsavedGuard.markClean();
      return;
    }

    if (isEdit) {
      // Keep the template in the editor so the user's work stays visible and they
      // can keep tweaking; just refresh the saved list, then confirm AFTER the
      // reload so nothing clears the message.
      await Promise.all([loadTemplates(), loadTemplateCategories()]);
      focusSavedTemplateCategory(categoryName, { scroll: false });
      document.dispatchEvent(new CustomEvent("crm:email-template-saved"));
      if (window.CrmUnsavedGuard) window.CrmUnsavedGuard.markClean();
      setTemplateSaveFeedback("✓ Template updated and saved.");
      showTimedSuccessMessage("✓ Template updated and saved.", 12000);
    } else {
      saveTemplateForm.reset();
      if (templateBodyEditor) templateBodyEditor.innerHTML = "";
      resetTemplateEditMode();
      await Promise.all([loadTemplates(), loadTemplateCategories()]);
      focusSavedTemplateCategory(categoryName);
      document.dispatchEvent(new CustomEvent("crm:email-template-saved"));
      if (window.CrmUnsavedGuard) window.CrmUnsavedGuard.markClean();
      setTemplateSaveFeedback("✓ Template saved.");
      showTimedSuccessMessage("✓ Template saved.", 12000);
    }
  } catch (error) {
    setTemplateSaveFeedback(error.message, true);
  } finally {
    if (saveActionBtn) {
      saveActionBtn.disabled = false;
      saveActionBtn.textContent = saveActionLabel;
    }
  }
}

if (saveTemplateForm) {
  saveTemplateForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    await persistEmailTemplate({ saveAsNew: false });
  });
}

if (saveTemplateAsNewBtn) {
  saveTemplateAsNewBtn.addEventListener("click", () => persistEmailTemplate({ saveAsNew: true }));
}

if (loadTemplateForEditBtn) {
  loadTemplateForEditBtn.addEventListener("click", () => {
    const id = Number(templateEditSelect?.value || "");
    if (!id) {
      setTemplateSaveFeedback("Choose a template to edit.", true);
      return;
    }
    const loaded = loadTemplateIntoEditForm(id);
    if (!loaded) {
      setTemplateSaveFeedback("Template not found. Reload and try again.", true);
      return;
    }
    setTemplateSaveFeedback(
      "Template loaded. Click Update Template to overwrite this one, or Save as new template to keep the original unchanged."
    );
    if (window.CrmUnsavedGuard) window.CrmUnsavedGuard.markClean();
  });
}

if (cancelTemplateEditBtn) {
  cancelTemplateEditBtn.addEventListener("click", () => {
    if (saveTemplateForm) saveTemplateForm.reset();
    if (templateBodyEditor) templateBodyEditor.innerHTML = "";
    resetTemplateEditMode();
    setTemplateSaveFeedback("Template edit canceled.");
    if (window.CrmUnsavedGuard) window.CrmUnsavedGuard.markClean();
  });
}

if (deleteTemplateBtn) {
  deleteTemplateBtn.addEventListener("click", async () => {
    setTemplateSaveFeedback("");
    showMessage("");
    const id = getEditingTemplateId();
    if (id) {
      try {
        await deleteEmailTemplateById(id);
      } catch (error) {
        setTemplateSaveFeedback(error.message, true);
      }
      return;
    }

    // Built-in sample loaded via gallery "Use this" — hide it from the gallery.
    const sampleId = String(window.__CRM_CURRENT_SAMPLE_TEMPLATE_ID__ || "").trim();
    const formName = String(saveTemplateForm?.querySelector('[name="name"]')?.value || "").trim();
    const sampleName = String(window.__CRM_CURRENT_SAMPLE_TEMPLATE_NAME__ || formName || "").trim();
    if (sampleId && window.CadenceEmailSampleActions?.hideBuiltInSample) {
      const removed = window.CadenceEmailSampleActions.hideBuiltInSample(sampleId, sampleName);
      if (removed) {
        if (saveTemplateForm) saveTemplateForm.reset();
        if (templateBodyEditor) templateBodyEditor.innerHTML = "";
        resetTemplateEditMode();
        window.__CRM_CURRENT_SAMPLE_TEMPLATE_ID__ = "";
        window.__CRM_CURRENT_SAMPLE_TEMPLATE_NAME__ = "";
        setTemplateSaveFeedback("Built-in sample removed from your gallery.");
        if (window.CrmUnsavedGuard) window.CrmUnsavedGuard.markClean();
      }
      return;
    }

    setTemplateSaveFeedback(
      "Load a template first (Use this / Load for Edit), then click Delete Template.",
      true
    );
  });
}

const backToContactsBtn = document.getElementById("backToContactsBtn");
if (backToContactsBtn) {
  backToContactsBtn.addEventListener("click", () => {
    window.location.href = "/index.html";
  });
}

const emailContactDetailsBtn = document.getElementById("emailContactDetailsBtn");
const emailQuickSendTopBtn = document.getElementById("emailQuickSendTopBtn");
if (emailContactDetailsBtn) {
  emailContactDetailsBtn.addEventListener("click", async () => {
    const contactIds = getInitialContactIdsFromQuery();
    const contactId = Number(contactIds[0]);
    if (Number.isInteger(contactId) && contactId > 0) {
      window.location.href = `/contact.html?id=${encodeURIComponent(contactId)}&full=1`;
      return;
    }
    const firstRecipient = String(toManualInput?.value || "")
      .split(/[;,]/)
      .map((value) => String(value || "").trim())
      .find(Boolean);
    if (firstRecipient) {
      try {
        const { response, data } = await fetchApiJson(
          `/api/contacts?q=${encodeURIComponent(firstRecipient)}&page=1&limit=1`
        );
        const items = Array.isArray(data?.items) ? data.items : Array.isArray(data) ? data : [];
        const matchedId = Number(items[0]?.id);
        if (response.ok && Number.isInteger(matchedId) && matchedId > 0) {
          window.location.href = `/contact.html?id=${encodeURIComponent(matchedId)}&full=1`;
          return;
        }
      } catch {
        // Fall through to guidance message.
      }
    }
    window.location.href = "/index.html";
  });
}

if (emailQuickSendTopBtn) {
  emailQuickSendTopBtn.addEventListener("click", () => {
    if (!sendEmailForm) return;
    sendEmailForm.dataset.quickSend = "1";
    if (typeof sendEmailForm.requestSubmit === "function") {
      sendEmailForm.requestSubmit();
      return;
    }
    sendEmailForm.dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }));
  });
}

if (emailBodyEditor) {
  ["mouseup", "keyup", "focus"].forEach((evt) => {
    emailBodyEditor.addEventListener(evt, () => {
      emailComposeMergeTarget = "body";
      captureEmailBodyToolbarRange();
      syncEmailBodyFontSizeDropdown();
    });
  });
}

wireRichEditor(emailBodyEditor, {
  bodyImageMaxWidthPx: RICH_EMAIL_TEMPLATE_IMAGE_MAX_PX,
  boldBtn: document.getElementById("emailBodyBoldBtn"),
  italicBtn: document.getElementById("emailBodyItalicBtn"),
  underlineBtn: document.getElementById("emailBodyUnderlineBtn"),
  alignLeftBtn: document.getElementById("emailBodyAlignLeftBtn"),
  alignCenterBtn: document.getElementById("emailBodyAlignCenterBtn"),
  alignRightBtn: document.getElementById("emailBodyAlignRightBtn"),
  linkBtn: document.getElementById("emailBodyLinkBtn"),
  /* Insert Image now toggles the combined upload/URL panel (bound in
     emailPageUpgrades below) instead of opening the file dialog directly. */
  insertPhotoBtn: null,
  insertGraphicUrlBtn: null,
  inlineColor: document.getElementById("emailBodyInlineColor"),
  inlineFontSize: null,
  clearBtn: document.getElementById("emailBodyClearFormatBtn"),
  imageUrlInput: document.getElementById("emailBodyImageUrl"),
  imageFileInput: document.getElementById("emailBodyImageFile"),
  addImageUrlBtn: document.getElementById("emailBodyAddImageUrlBtn"),
  insertRobotBtn: document.getElementById("emailBodyInsertRobotBtn")
});

if (emailBodyFontFamily) {
  emailBodyFontFamily.addEventListener("pointerdown", () => captureEmailBodyToolbarRange());
  emailBodyFontFamily.addEventListener("change", () => {
    const fam = String(emailBodyFontFamily.value || "").trim();
    if (!fam) return;
    withEmailBodyToolbarFocus(() => {
      try {
        document.execCommand("styleWithCSS", false, "true");
      } catch {
        //
      }
      document.execCommand("fontName", false, fam);
    });
  });
}

if (emailBodyLegacyFontSize) {
  emailBodyLegacyFontSize.addEventListener("change", () => {
    const key = String(emailBodyLegacyFontSize.value || "").trim();
    const px = EMAIL_LEGACY_SIZE_TO_PX[key];
    if (!px) return;
    withEmailBodyToolbarFocus(() => applyInlineFontSize(px, emailBodyEditor));
  });
}

if (emailToolbarAttachBtn && localFilesInput) {
  emailToolbarAttachBtn.addEventListener("click", () => localFilesInput.click());
}

if (emailCancelBtn) {
  emailCancelBtn.addEventListener("click", () => resetEmailCompose());
}

if (openSignatureSettingsBtn) {
  openSignatureSettingsBtn.addEventListener("click", () => {
    window.location.href = "/settings.html?section=signature";
  });
}

if (emailIncludeSignatureBtn) {
  emailIncludeSignatureBtn.addEventListener("click", () => {
    const next = !(emailIncludeSignature && emailIncludeSignature.checked);
    setIncludeEmailSignatureEnabled(next);
  });
}

if (templateMergeFieldSelect) {
  templateMergeFieldSelect.addEventListener("change", () => {
    const token = String(templateMergeFieldSelect.value || "").trim();
    if (!token) return;
    insertTemplateMergeToken(token);
    templateMergeFieldSelect.value = "";
  });
}

if (toManualInput) {
  const markToFieldTouched = () => {
    composeToFieldTouched = true;
    maybeClearMirroredCcFromTo(toManualInput.value || "");
  };
  toManualInput.addEventListener("input", markToFieldTouched);
  toManualInput.addEventListener("change", markToFieldTouched);
}

if (emailCcInput) {
  const markCcFieldTouched = () => {
    composeCcFieldTouched = true;
  };
  emailCcInput.addEventListener("input", markCcFieldTouched);
  emailCcInput.addEventListener("change", markCcFieldTouched);
}

if (fromSelect) {
  fromSelect.addEventListener("change", () => {
    const nextFrom = String(fromSelect.value || "").trim();
    maybeClearMirroredCcFromAddress(nextFrom);
    lastFromAddressValue = nextFrom;
    updateFromSmtpNotice();
  });
}

if (emailComposeMergeFieldSelect) {
  emailComposeMergeFieldSelect.addEventListener("change", () => {
    const token = String(emailComposeMergeFieldSelect.value || "").trim();
    if (!token) return;
    insertEmailComposeMergeToken(token);
    emailComposeMergeFieldSelect.value = "";
  });
}

if (subjectInput) {
  subjectInput.addEventListener("focus", () => {
    emailComposeMergeTarget = "subject";
  });
}

wireSendConfirmModal();

wireRichEditor(templateBodyEditor, {
  bodyImageMaxWidthPx: RICH_EMAIL_TEMPLATE_IMAGE_MAX_PX,
  maxGridRows: 8,
  boldBtn: document.getElementById("templateBodyBoldBtn"),
  italicBtn: document.getElementById("templateBodyItalicBtn"),
  underlineBtn: document.getElementById("templateBodyUnderlineBtn"),
  alignLeftBtn: document.getElementById("templateBodyAlignLeftBtn"),
  alignCenterBtn: document.getElementById("templateBodyAlignCenterBtn"),
  alignRightBtn: document.getElementById("templateBodyAlignRightBtn"),
  linkBtn: document.getElementById("templateBodyLinkBtn"),
  bulletListBtn: document.getElementById("templateBodyBulletListBtn"),
  numberListBtn: document.getElementById("templateBodyNumberListBtn"),
  insert2ColBtn: document.getElementById("templateBodyInsert2ColBtn"),
  insert3ColBtn: document.getElementById("templateBodyInsert3ColBtn"),
  insertGridBtn: document.getElementById("templateBodyInsertGridBtn"),
  insertPhotoBtn: document.getElementById("templateBodyInsertPhotoBtn"),
  insertGraphicUrlBtn: document.getElementById("templateBodyInsertGraphicUrlBtn"),
  fontFamilySelect: templateBodyFontFamily,
  inlineColor: document.getElementById("templateBodyInlineColor"),
  inlineFontSize: document.getElementById("templateBodyInlineFontSize"),
  gridColorInput: document.getElementById("templateBodyGridColor"),
  applyGridColorBtn: document.getElementById("templateBodyApplyGridColorBtn"),
  clearBtn: document.getElementById("templateBodyClearFormatBtn"),
  imageUrlInput: document.getElementById("templateBodyImageUrl"),
  imageFileInput: document.getElementById("templateBodyImageFile"),
  addImageUrlBtn: document.getElementById("templateBodyAddImageUrlBtn"),
  insertRobotBtn: document.getElementById("templateBodyInsertRobotBtn")
});

if (isEmailTemplatesOnlyPage && saveTemplateForm && templateBodyEditor) {
  templateBodyEditor.addEventListener("input", scheduleTemplateEditHistoryRecord);
  const tplNameInput = saveTemplateForm.querySelector('[name="name"]');
  const tplSubjectInputForUndo = saveTemplateForm.querySelector('[name="subject"]');
  if (tplNameInput) tplNameInput.addEventListener("input", scheduleTemplateEditHistoryRecord);
  if (tplSubjectInputForUndo) tplSubjectInputForUndo.addEventListener("input", scheduleTemplateEditHistoryRecord);
  if (templateCategoryNameInput) templateCategoryNameInput.addEventListener("input", scheduleTemplateEditHistoryRecord);
}

if (templateEditUndoBtn) {
  templateEditUndoBtn.addEventListener("click", () => undoTemplateEditStep());
}

if (templateBodyEditor && templateBodyInlineFontSize) {
  ["mouseup", "keyup", "focus"].forEach((evt) => {
    templateBodyEditor.addEventListener(evt, () => {
      templateMergeTarget = "body";
      captureTemplateBodyToolbarRange();
      syncEditorFontSizeDropdown(templateBodyEditor, templateBodyInlineFontSize);
    });
  });
}

if (templateSubjectInput) {
  templateSubjectInput.addEventListener("focus", () => {
    templateMergeTarget = "subject";
  });
}

if (savedTemplatesByCategory) {
  savedTemplatesByCategory.addEventListener("change", (event) => {
    const select = event.target?.closest?.("#emailTemplateCategoryFilter");
    if (!select) return;
    selectedTemplateCategory = String(select.value ?? "");
    templateSearchTerm = "";
    renderTemplatesByCategory();
  });
  savedTemplatesByCategory.addEventListener("input", (event) => {
    const input = event.target?.closest?.("#templateNameSearchInput");
    if (!input) return;
    templateSearchTerm = String(input.value || "");
    renderTemplatesByCategory();
  });
  savedTemplatesByCategory.addEventListener("click", (event) => {
    const categoryBtn = event.target?.closest?.(".email-template-category-btn");
    if (categoryBtn) {
      const categoryValue = String(categoryBtn.getAttribute("data-template-category") || "").trim();
      if (!categoryValue) return;
      if (selectedTemplateCategory === categoryValue) {
        // On the templates gallery, clicking the active chip returns to All (don't collapse).
        selectedTemplateCategory = isEmailTemplatesOnlyPage ? "ALL" : "";
        templateSearchTerm = "";
      } else {
        selectedTemplateCategory = categoryValue;
      }
      renderTemplatesByCategory({
        scrollToResults: Boolean(selectedTemplateCategory) && !isEmailTemplatesOnlyPage
      });
      return;
    }
    const editBtn = event.target?.closest?.(".email-template-list-edit-btn");
    if (editBtn) {
      const id = Number(editBtn.getAttribute("data-template-id") || "");
      if (!Number.isInteger(id) || id < 1) return;
      const loaded = loadTemplateIntoEditForm(id);
      if (!loaded) {
        setTemplateSaveFeedback("Template not found. Reload and try again.", true);
        return;
      }
      setTemplateSaveFeedback("Template loaded. Update fields and click Update Template.");
      saveTemplateForm?.scrollIntoView({ behavior: "smooth", block: "start" });
      return;
    }
    const deleteBtn = event.target?.closest?.(".email-template-list-delete-btn");
    if (!deleteBtn) return;
    const deleteId = Number(deleteBtn.getAttribute("data-template-id") || "");
    if (!Number.isInteger(deleteId) || deleteId < 1) return;
    setTemplateSaveFeedback("");
    showMessage("");
    deleteEmailTemplateById(deleteId).catch((error) => {
      setTemplateSaveFeedback(error.message, true);
    });
  });
}

if (emailTemplateCategoryCreateToggle) {
  emailTemplateCategoryCreateToggle.addEventListener("click", () => {
    toggleEmailTemplateCategoryCreateForm(true);
    setEmailTemplateCategoryCreateFeedback("");
  });
}

if (emailTemplateCategoryCreateCancel) {
  emailTemplateCategoryCreateCancel.addEventListener("click", () => {
    toggleEmailTemplateCategoryCreateForm(false);
    setEmailTemplateCategoryCreateFeedback("");
  });
}

if (emailTemplateCategoryCreateForm) {
  emailTemplateCategoryCreateForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const name = String(emailTemplateCategoryCreateName?.value || "").trim();
    try {
      await createEmailTemplateCategory(name);
      toggleEmailTemplateCategoryCreateForm(false);
      setEmailTemplateCategoryCreateFeedback(`Category "${name}" created.`);
    } catch (error) {
      setEmailTemplateCategoryCreateFeedback(error.message || "Could not create category.", true);
    }
  });
}

if (templateCategoryCreateBtn) {
  templateCategoryCreateBtn.addEventListener("click", async () => {
    const name = String(templateCategoryNameInput?.value || "").trim();
    try {
      await createEmailTemplateCategory(name);
      setTemplateSaveFeedback(`Category "${name}" created. It will be used when you save this template.`);
      setEmailTemplateCategoryCreateFeedback(`Category "${name}" created.`);
    } catch (error) {
      setTemplateSaveFeedback(error.message || "Could not create category.", true);
    }
  });
}

document.addEventListener("crm:reload-email-templates", () => {
  Promise.all([loadTemplates(), loadTemplateCategories()]).catch((e) => showMessage(e.message, true));
});

if (isEmailTemplatesOnlyPage) {
  const bootTemplatesPage = () =>
    Promise.all([loadTemplates(), loadTemplateCategories(), refreshCustomMergeFieldsCache()]).catch((e) =>
      showMessage(e.message, true)
    );
  if (window.__CRM_WORKSPACE_UI_READY__) {
    window.__CRM_WORKSPACE_UI_READY__.then(bootTemplatesPage);
  } else {
    window.addEventListener("crm-workspace-ui-ready", bootTemplatesPage, { once: true });
    bootTemplatesPage();
  }
} else {
  (async () => {
    try {
      try {
        if (window.sessionStorage) {
          for (const k of EMAIL_LOCAL_ATTACHMENTS_SESSION_KEYS_LEGACY) {
            sessionStorage.removeItem(k);
          }
        }
      } catch {
        //
      }
      await restoreLocalAttachmentsFromSession();
      applyAssistantEmailDraftFromSession();
      await Promise.all([
        loadFromOptions(),
        loadContacts(),
        loadTemplates(),
        loadTemplateCategories(),
        loadAttachments(),
        refreshCustomMergeFieldsCache()
      ]);
      syncIncludeSignatureButton();
      await loadSavedSignature();
      updateEmailSignaturePreview();
    } catch (e) {
      showMessage(e.message || String(e), true);
    }
  })();
}

function refreshEmailSignaturePreferenceFromStorage() {
  syncIncludeSignatureButton();
  updateEmailSignaturePreview();
}

window.addEventListener("storage", (event) => {
  if (event.key !== EMAIL_INCLUDE_SIGNATURE_KEY && event.key !== EMAIL_SIGNATURE_KEY) return;
  refreshEmailSignaturePreferenceFromStorage();
});

document.addEventListener("visibilitychange", () => {
  if (document.visibilityState !== "visible" || isEmailTemplatesOnlyPage) return;
  loadSavedSignature()
    .then(() => refreshEmailSignaturePreferenceFromStorage())
    .catch(() => refreshEmailSignaturePreferenceFromStorage());
});

function applyAssistantEmailDraftFromSession() {
  if (!window.sessionStorage) return;
  try {
    const raw = sessionStorage.getItem("crm_assistant_email_draft");
    if (!raw) return;
    sessionStorage.removeItem("crm_assistant_email_draft");
    const draft = JSON.parse(raw);
    if (toManualInput && draft.contactEmail) toManualInput.value = String(draft.contactEmail);
    if (subjectInput && draft.subject) subjectInput.value = String(draft.subject);
    if (emailBodyEditor) {
      emailBodyEditor.innerHTML = String(draft.html || draft.text || "")
        .replace(/\n/g, "<br>");
    }
    showMessage("Email draft loaded from AI Assistant.");
  } catch {
    /* ignore malformed draft */
  }
}

/**
 * Allow other pages (Settings) opened in the same tab session to invalidate
 * the custom merge fields cache after a user adds or removes a field.
 */
window.__cadenceRefreshCustomMergeFields = refreshCustomMergeFieldsCache;
window.CadenceEmailTemplateActions = {
  loadTemplateIntoEditForm,
  loadTemplateFromGalleryCard,
  deleteEmailTemplateById,
  getEditingTemplateId,
  setEditingTemplateId
};
resetTemplateEditMode();

/* ── Send Email: inline AI draft (same API + robot as AI Assistant) ─────── */
(function emailAiDraftPanel() {
  if (isEmailTemplatesOnlyPage) return;

  const statusBadge = document.getElementById("emailAiStatusBadge");
  const robotTip = document.getElementById("emailAiRobotTip");
  const generateBtn = document.getElementById("emailAiGenerateBtn");
  const aiDraftRoot = document.getElementById("emailAiDraftForm");
  const purposeSelect = document.getElementById("emailAiPurposeSelect");
  const purposeCustomWrap = document.getElementById("emailAiPurposeCustomWrap");
  const purposeCustomInput = document.getElementById("emailAiPurposeCustom");
  const clearFormBtn = document.getElementById("emailAiClearFormBtn");
  const resultEl = document.getElementById("emailAiDraftResult");
  const toneSelect = document.getElementById("emailAiTone");
  const contextInput = document.getElementById("emailAiContext");
  const leadSourceSelect = document.getElementById("emailAiLeadSource");
  const quoteInput = document.getElementById("emailAiQuote");

  const generateDefaultLabel = generateBtn ? generateBtn.textContent : "Draft with AI";

  function setAiStatus(state, text) {
    if (!statusBadge) return;
    statusBadge.dataset.state = state;
    statusBadge.textContent = text;
  }

  function isTimeoutError(err) {
    return Boolean(
      err &&
        (err.name === "AbortError" ||
          /aborted|timed out/i.test(String(err.message || err.name || "")))
    );
  }

  async function fetchAssistantStatus(timeoutMs) {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), timeoutMs);
    try {
      return await fetchApiJson("/api/assistant/status", { signal: controller.signal });
    } finally {
      window.clearTimeout(timer);
    }
  }

  async function loadEmailAiStatus() {
    if (!statusBadge) return;
    setAiStatus("loading", "Checking AI...");
    if (generateBtn) generateBtn.disabled = false;
    let lastErr = null;
    for (let attempt = 0; attempt < 2; attempt += 1) {
      try {
        if (attempt > 0) setAiStatus("loading", "Still checking AI...");
        const { response, data } = await fetchAssistantStatus(8000);
        if (!response.ok) throw new Error(data.error || "Could not reach AI.");
        if (data.configured) {
          setAiStatus("ready", "AI ready");
          if (robotTip) robotTip.textContent = "Pick a topic - I'll draft subject and message.";
        } else {
          setAiStatus("unconfigured", "AI not configured");
          if (generateBtn) generateBtn.disabled = true;
          if (robotTip) robotTip.textContent = "AI drafting is included. It is not turned on for this site yet.";
        }
        return;
      } catch (err) {
        lastErr = err;
        if (!isTimeoutError(err)) break;
      }
    }
    const timedOut = isTimeoutError(lastErr);
    setAiStatus("error", timedOut ? "AI check timed out" : "AI unavailable");
    if (robotTip) {
      robotTip.textContent = timedOut
        ? "Status check was slow. You can still click Draft with AI."
        : "Could not reach AI - refresh or open AI Assistant.";
    }
  }

  window.setTimeout(loadEmailAiStatus, 200);

  if (!aiDraftRoot || !purposeSelect || !generateBtn || !resultEl) return;

  let lastPayload = null;

  const escapeAiHtml = (value) =>
    String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");

  const formatAiDraftBody = (text) => {
    const paragraphs = String(text || "")
      .replace(/\r\n/g, "\n")
      .split(/\n\s*\n/)
      .map((part) => part.trim())
      .filter(Boolean);
    if (!paragraphs.length) return `<p class="hint">No body returned.</p>`;
    return paragraphs.map((part) => `<p>${escapeAiHtml(part.replace(/\n/g, " "))}</p>`).join("");
  };

  function getAiPurpose() {
    if (purposeSelect.value === "__custom__") {
      return String(purposeCustomInput?.value || "").trim();
    }
    return String(purposeSelect.value || "").trim();
  }

  function syncCustomTopicField() {
    const isCustom = purposeSelect.value === "__custom__";
    if (!purposeCustomWrap) return;
    if (isCustom) {
      purposeCustomWrap.hidden = false;
      purposeCustomWrap.removeAttribute("hidden");
      window.requestAnimationFrame(() => {
        purposeCustomInput?.focus();
        purposeCustomInput?.select();
      });
    } else {
      purposeCustomWrap.hidden = true;
      purposeCustomWrap.setAttribute("hidden", "");
      if (purposeCustomInput) purposeCustomInput.value = "";
    }
  }

  function setAiGenerating(loading) {
    generateBtn.disabled = Boolean(loading);
    generateBtn.textContent = loading ? "Drafting..." : generateDefaultLabel;
  }

  function playRobot() {
    const robot = document.querySelector(".email-ai-robot lottie-player");
    if (robot) window.setTimeout(() => { try { robot.play(); } catch { /* ignore */ } }, 50);
  }

  function applyAiDraftToCompose(draft) {
    if (!draft || typeof draft !== "object") return;
    if (subjectInput && draft.subject) subjectInput.value = String(draft.subject);
    if (emailBodyEditor) {
      const rawHtml = String(draft.html || "").trim();
      const rawText = String(draft.text || "").trim();
      if (rawHtml && /<[a-z][\s\S]*>/i.test(rawHtml)) {
        setRichEditorContent(emailBodyEditor, rawHtml);
      } else if (rawText) {
        setRichEditorContent(emailBodyEditor, rawText);
      }
    }
    showMessage("AI draft applied - review and edit before sending.");
    if (robotTip) robotTip.textContent = "Draft applied. Tweak the message below, then send.";
    playRobot();
  }

  function renderAiResult(draft) {
    resultEl.hidden = false;
    resultEl.innerHTML = `
      <h4 class="email-ai-result-title">Suggested draft</h4>
      <p class="hint email-ai-result-note">Review before sending - AI suggestions are not guaranteed accurate.</p>
      <p><strong>Subject:</strong> ${escapeAiHtml(draft.subject || "(none)")}</p>
      <div class="email-ai-result-body">${formatAiDraftBody(draft.text || "")}</div>
      <div class="email-ai-result-actions">
        <button type="button" class="email-ai-use-draft-btn">Use in message</button>
        <button type="button" class="email-ai-regenerate-btn agile-cancel-btn">Regenerate</button>
        <button type="button" class="email-ai-clear-result-btn agile-cancel-btn">Dismiss</button>
      </div>
    `;
    resultEl.querySelector(".email-ai-use-draft-btn")?.addEventListener("click", () => applyAiDraftToCompose(draft));
    resultEl.querySelector(".email-ai-regenerate-btn")?.addEventListener("click", () => runEmailAiDraft());
    resultEl.querySelector(".email-ai-clear-result-btn")?.addEventListener("click", () => {
      resultEl.hidden = true;
      resultEl.innerHTML = "";
    });
    playRobot();
  }

  purposeSelect.addEventListener("change", syncCustomTopicField);

  function clearAiDraftForm() {
    if (purposeSelect) purposeSelect.value = "";
    if (purposeCustomInput) purposeCustomInput.value = "";
    if (toneSelect) toneSelect.value = "professional";
    if (contextInput) contextInput.value = "";
    if (leadSourceSelect) leadSourceSelect.value = "";
    if (quoteInput) quoteInput.value = "";
    if (purposeCustomWrap) {
      purposeCustomWrap.hidden = true;
      purposeCustomWrap.setAttribute("hidden", "");
    }
    purposeSelect?.classList.remove("email-ai-field--error");
    resultEl.hidden = true;
    resultEl.innerHTML = "";
    lastPayload = null;
    if (robotTip) robotTip.textContent = "Uses your To contact for personalization.";
  }

  async function runEmailAiDraft() {
    const purpose = getAiPurpose();
    if (!purpose) {
      purposeSelect?.classList.add("email-ai-field--error");
      purposeSelect?.focus();
      resultEl.hidden = false;
      resultEl.innerHTML =
        '<p class="email-ai-error">Choose a topic from the list, or pick Custom topic and describe what you want to say.</p>';
      showMessage("Choose or enter a topic for the AI draft.", true);
      return;
    }
    purposeSelect?.classList.remove("email-ai-field--error");
    const contactId = resolvePrimaryContactIdForSend();
    const payload = {
      mode: "email",
      purpose,
      tone: String(toneSelect?.value || "professional").trim(),
      context: String(contextInput?.value || "").trim(),
      contactId: contactId > 0 ? String(contactId) : "",
      leadSource: String(leadSourceSelect?.value || "").trim(),
      quoteAmount: String(quoteInput?.value || "").trim()
    };
    lastPayload = payload;
    setAiGenerating(true);
    if (robotTip) robotTip.textContent = "Writing your draft...";
    try {
      const { response, data } = await fetchApiJson("/api/assistant/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!response.ok) throw new Error(data.error || "Could not generate email draft.");
      const draft = {
        subject: data.subject || "",
        text: data.text || "",
        html: data.html || data.text || ""
      };
      renderAiResult(draft);
    } catch (err) {
      resultEl.hidden = false;
      resultEl.innerHTML = `<p class="email-ai-error">${escapeAiHtml(err.message || "Draft failed.")}</p>`;
      if (robotTip) robotTip.textContent = "Something went wrong - try again or open AI Assistant.";
    } finally {
      setAiGenerating(false);
    }
  }

  clearFormBtn?.addEventListener("click", clearAiDraftForm);
  generateBtn.addEventListener("click", () => runEmailAiDraft());

  const AI_LEAD_SOURCE_FALLBACK = [
    "Website", "Referral", "Telemarketing", "Facebook", "Instagram", "Google", "Nextgen"
  ];

  function addAiLeadSourceOptions(labels) {
    if (!leadSourceSelect || !Array.isArray(labels)) return 0;
    const existing = new Set([...leadSourceSelect.options].map((o) => o.value.trim().toLowerCase()));
    let added = 0;
    for (const label of labels) {
      const v = String(label || "").trim();
      if (!v || existing.has(v.toLowerCase())) continue;
      existing.add(v.toLowerCase());
      const opt = document.createElement("option");
      opt.value = v;
      opt.textContent = v;
      leadSourceSelect.appendChild(opt);
      added += 1;
    }
    return added;
  }

  async function populateAiLeadSources() {
    if (!leadSourceSelect) return;
    addAiLeadSourceOptions(AI_LEAD_SOURCE_FALLBACK);
    try {
      const { response, data } = await fetchApiJson("/api/contacts/workspace-options");
      if (response && response.ok) {
        addAiLeadSourceOptions(data && data.leadSourceLabels);
      } else {
        console.warn("[email-ai] lead-source options unavailable (status " + (response && response.status) + ")");
      }
    } catch (err) {
      console.warn("[email-ai] lead-source fetch failed:", (err && err.message) || err);
    }
  }
  populateAiLeadSources();
})();

/* ── Send Email page upgrades ──────────────────────────────────────────────
   1) Insert Image opens a compact upload/URL panel (declutter)
   2) Contact autocomplete in the To field
   3) "Send to a Tag" throttled campaigns
   4) Recent Opens (warm leads) panel
   All elements are null-guarded so this is inert on email-templates.html. */
(function emailPageUpgrades() {
  try {
  // ---- 1) Insert Image panel ----
  const insertPhotoBtn = document.getElementById("emailBodyInsertPhotoBtn");
  const imagePanel = document.getElementById("emailImageInsertPanel");
  if (insertPhotoBtn && imagePanel) {
    insertPhotoBtn.addEventListener("click", () => {
      imagePanel.hidden = !imagePanel.hidden;
    });
    const imageFileInput = document.getElementById("emailBodyImageFile");
    if (imageFileInput) {
      imageFileInput.addEventListener("change", () => {
        window.setTimeout(() => {
          imagePanel.hidden = true;
        }, 150);
      });
    }
    const addUrlBtn = document.getElementById("emailBodyAddImageUrlBtn");
    if (addUrlBtn) {
      addUrlBtn.addEventListener("click", () => {
        window.setTimeout(() => {
          imagePanel.hidden = true;
        }, 150);
      });
    }
  }

  // ---- 2) Contact autocomplete in To ----
  const toSuggest = document.getElementById("emailToSuggest");
  if (toManualInput && toSuggest) {
    let suggestTimer = null;
    let suggestItems = [];
    let suggestIndex = -1;
    const hideSuggest = () => {
      toSuggest.hidden = true;
      toSuggest.innerHTML = "";
      suggestItems = [];
      suggestIndex = -1;
    };
    const currentTerm = () => {
      const value = String(toManualInput.value || "");
      return String(value.split(",").pop() || "").trim();
    };
    const applySuggestion = (email) => {
      const parts = String(toManualInput.value || "").split(",");
      parts[parts.length - 1] = " " + email;
      toManualInput.value = parts.join(",").replace(/^\s+/, "") + ", ";
      try {
        composeToFieldTouched = true;
      } catch {
        /* ignore */
      }
      hideSuggest();
      toManualInput.focus();
    };
    toManualInput.addEventListener("input", () => {
      const term = currentTerm();
      window.clearTimeout(suggestTimer);
      if (term.length < 2) {
        hideSuggest();
        return;
      }
      suggestTimer = window.setTimeout(async () => {
        try {
          const { response, data } = await fetchApiJson("/api/contacts?q=" + encodeURIComponent(term));
          if (!response.ok) return hideSuggest();
          const list = Array.isArray(data) ? data : Array.isArray(data?.items) ? data.items : [];
          suggestItems = list.filter((c) => String(c.email || "").includes("@")).slice(0, 8);
          if (!suggestItems.length) return hideSuggest();
          toSuggest.innerHTML = "";
          suggestItems.forEach((c) => {
            const item = document.createElement("div");
            const isDne = String(c.do_not_email || "").trim() === "1";
            item.className = "email-to-suggest-item" + (isDne ? " email-to-suggest-item--dne" : "");
            item.setAttribute("role", "option");
            const nameEl = document.createElement("strong");
            nameEl.textContent = String(c.full_name || "Contact");
            const emailEl = document.createElement("span");
            emailEl.textContent = String(c.email || "");
            item.appendChild(nameEl);
            item.appendChild(emailEl);
            if (isDne) {
              const dneEl = document.createElement("span");
              dneEl.className = "email-to-suggest-dne";
              dneEl.textContent = "Do Not Email";
              item.appendChild(dneEl);
            }
            item.addEventListener("mousedown", (ev) => {
              ev.preventDefault();
              if (isDne) {
                showMessage(`Cannot add ${String(c.full_name || "this contact").trim()} - "Do Not Email" is set.`, true);
                hideSuggest();
                return;
              }
              applySuggestion(String(c.email || "").trim());
            });
            toSuggest.appendChild(item);
          });
          suggestIndex = -1;
          toSuggest.hidden = false;
        } catch {
          hideSuggest();
        }
      }, 250);
    });
    toManualInput.addEventListener("keydown", (ev) => {
      if (toSuggest.hidden) return;
      const items = [...toSuggest.children];
      if (ev.key === "ArrowDown" || ev.key === "ArrowUp") {
        ev.preventDefault();
        suggestIndex =
          ev.key === "ArrowDown"
            ? Math.min(items.length - 1, suggestIndex + 1)
            : Math.max(0, suggestIndex - 1);
        items.forEach((el, i) => el.classList.toggle("is-active", i === suggestIndex));
      } else if (ev.key === "Enter" && suggestIndex >= 0 && suggestItems[suggestIndex]) {
        ev.preventDefault();
        const picked = suggestItems[suggestIndex];
        if (String(picked.do_not_email || "").trim() === "1") {
          showMessage(`Cannot add ${String(picked.full_name || "this contact").trim()} - "Do Not Email" is set.`, true);
          hideSuggest();
          return;
        }
        applySuggestion(String(picked.email || "").trim());
      } else if (ev.key === "Escape") {
        hideSuggest();
      }
    });
    toManualInput.addEventListener("blur", () => window.setTimeout(hideSuggest, 180));
  }

  // ---- 4) Send to a Tag (throttled campaign) ----
  const bulkTagSelect = document.getElementById("emailBulkTagSelect");
  const bulkRateSelect = document.getElementById("emailBulkRateSelect");
  const bulkQueueBtn = document.getElementById("emailBulkQueueBtn");
  const bulkPreviewLine = document.getElementById("emailBulkPreviewLine");
  const bulkQueueMsg = document.getElementById("emailBulkQueueMsg");
  const bulkCampaignsList = document.getElementById("emailBulkCampaignsList");
  const bulkSkipSent = document.getElementById("emailBulkSkipSent");
  let bulkPollTimer = null;

  const stopBulkPolling = () => {
    if (bulkPollTimer) {
      window.clearInterval(bulkPollTimer);
      bulkPollTimer = null;
    }
  };
  const startBulkPolling = () => {
    if (bulkPollTimer) return;
    bulkPollTimer = window.setInterval(refreshBulkCampaigns, 12000);
  };

  function collectCampaignPickerLabels(campaigns) {
    const set = new Set();
    for (const c of Array.isArray(campaigns) ? campaigns : []) {
      const name = String(c?.name || "").trim();
      if (name) set.add(name);
      const rules = Array.isArray(c?.tag_rules) ? c.tag_rules : [];
      for (const r of rules) {
        const tag = String(r?.tag || "").trim();
        const fn = String(r?.function || "enroll").trim().toLowerCase();
        if (tag && fn !== "none") set.add(tag);
      }
    }
    return set;
  }

  async function loadBulkTags() {
    if (!bulkTagSelect) return;
    const set = new Set();
    try {
      const { response, data } = await fetchApiJson("/api/contacts/tags");
      if (response.ok) {
        for (const tag of Array.isArray(data?.tags) ? data.tags : []) {
          const t = String(tag || "").trim();
          if (t) set.add(t);
        }
      }
    } catch {
      /* ignore */
    }
    try {
      const { response, data } = await fetchApiJson("/api/drip/campaigns");
      if (response.ok) {
        for (const label of collectCampaignPickerLabels(data)) set.add(label);
      }
    } catch {
      /* ignore */
    }
    const placeholder = bulkTagSelect.querySelector('option[value=""]');
    bulkTagSelect.innerHTML = "";
    if (placeholder) {
      bulkTagSelect.appendChild(placeholder);
    } else {
      const opt = document.createElement("option");
      opt.value = "";
      opt.textContent = "Choose a tag or campaign...";
      bulkTagSelect.appendChild(opt);
    }
    const sorted = [...set].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));
    for (const tag of sorted) {
      const opt = document.createElement("option");
      opt.value = tag;
      opt.textContent = tag;
      bulkTagSelect.appendChild(opt);
    }
  }

  async function refreshBulkPreviewLine() {
    if (!bulkPreviewLine) return;
    const tag = String(bulkTagSelect?.value || "").trim();
    if (!tag) {
      bulkPreviewLine.textContent = "";
      return;
    }
    try {
      const skipParam = bulkSkipSent?.checked ? "&skipSent=1" : "";
      const subjParam =
        "&subject=" + encodeURIComponent(typeof getEffectiveSubject === "function" ? String(getEffectiveSubject() || "").trim() : "");
      const { response, data } = await fetchApiJson(
        "/api/email/bulk-campaign/preview?tag=" + encodeURIComponent(tag) + skipParam + subjParam
      );
      if (!response.ok) throw new Error(data.error || "Could not load tag preview");
      const bits = [data.sendable + " contact" + (data.sendable === 1 ? "" : "s") + " will receive it"];
      if (data.alreadyEmailed) bits.push(data.alreadyEmailed + " already emailed (skipped)");
      if (data.skippedDoNotEmail) bits.push(data.skippedDoNotEmail + " blocked (Do Not Email)");
      if (data.skippedNoEmail) bits.push(data.skippedNoEmail + " missing email");
      if (data.duplicateEmails) bits.push(data.duplicateEmails + " duplicate");
      bulkPreviewLine.textContent = bits.join(" - ");
    } catch (err) {
      bulkPreviewLine.textContent = err.message || "Could not load tag preview.";
    }
  }

  const formatEta = (unix) => (unix ? new Date(unix * 1000).toLocaleString() : "");

  function setBulkQueueMsg(text, isError) {
    if (!bulkQueueMsg) return;
    const str = String(text || "");
    bulkQueueMsg.textContent = str;
    bulkQueueMsg.style.color = isError ? "#c62828" : "#1b5e20";
    bulkQueueMsg.hidden = !str.trim();
  }

  function bulkCampaignSummaryText(c) {
    const parts = ['Campaign "' + c.tag + '": ' + c.sent + " sent", c.pending + " pending"];
    if (c.failed) parts.push(c.failed + " failed");
    if (c.skipped) parts.push(c.skipped + " skipped");
    if (c.canceled) parts.push(c.canceled + " canceled");
    if (c.paused) parts.push(c.paused + " paused");
    if (c.perHour) parts.push(c.perHour + "/hour");
    if (c.pending && c.estFinishAt) parts.push("finishes ~" + formatEta(c.estFinishAt));
    let line = parts.join(" - ");
    if (c.pending && c.sent === 0 && c.nextScheduledAt) {
      const dueInSec = Number(c.nextScheduledAt) - Math.floor(Date.now() / 1000);
      if (dueInSec <= 0) line += " - starting shortly...";
    }
    if (c.lastError) line += " - last error: " + c.lastError;
    return line;
  }

  async function refreshBulkCampaigns() {
    if (!bulkCampaignsList) return;
    try {
      const controller = new AbortController();
      const timer = window.setTimeout(() => controller.abort(), 12000);
      let response;
      let data;
      try {
        ({ response, data } = await fetchApiJson("/api/email/bulk-campaign/active", { signal: controller.signal }));
      } finally {
        window.clearTimeout(timer);
      }
      if (!response.ok) {
        bulkCampaignsList.innerHTML = '<div class="hint">Could not load campaigns. Refresh to try again.</div>';
        stopBulkPolling();
        return;
      }
      const campaigns = Array.isArray(data.campaigns) ? data.campaigns : [];
      if (!campaigns.length) {
        bulkCampaignsList.innerHTML = '<div class="hint">No campaigns are currently sending.</div>';
        stopBulkPolling();
        return;
      }
      bulkCampaignsList.innerHTML = "";
      let anyPending = false;
      for (const c of campaigns) {
        if (c.pending) anyPending = true;
        const row = document.createElement("div");
        row.className = "email-bulk-campaign-row";
        const text = document.createElement("span");
        text.className = "email-bulk-campaign-text";
        text.textContent = bulkCampaignSummaryText(c);
        row.appendChild(text);
        const addCampaignBtn = (cls, label) => {
          const b = document.createElement("button");
          b.type = "button";
          b.className = cls;
          b.textContent = label;
          b.setAttribute("data-batch-id", c.batchId);
          row.appendChild(b);
        };
        if (c.pending) {
          addCampaignBtn("email-bulk-campaign-pause", "Pause");
          addCampaignBtn("danger email-bulk-campaign-cancel", "Cancel");
        } else if (c.paused) {
          addCampaignBtn("email-bulk-campaign-resume", "Resume");
          addCampaignBtn("danger email-bulk-campaign-cancel", "Cancel");
        }
        bulkCampaignsList.appendChild(row);
      }
      if (data.emailConfigured === false && anyPending) {
        const warn = document.createElement("div");
        warn.className = "hint";
        warn.textContent = "SMTP not configured - open Settings to enable sending.";
        bulkCampaignsList.appendChild(warn);
      }
      if (anyPending) startBulkPolling();
      else stopBulkPolling();
    } catch {
      bulkCampaignsList.innerHTML = '<div class="hint">Campaign list is taking too long. Sending still works — refresh to try again.</div>';
      stopBulkPolling();
    }
  }

  if (bulkQueueBtn) {
    bulkQueueBtn.addEventListener("click", async () => {
      const queueBtnLabel = bulkQueueBtn.textContent;
      try {
        setBulkQueueMsg("");
        const tag = String(bulkTagSelect?.value || "").trim();
        if (!tag) throw new Error("Choose a tag first.");
        const subject = String(getEffectiveSubject() || "").trim();
        if (!subject) throw new Error("Enter a subject (or pick a template) before queueing.");
        const composed = await getComposedEmailContent();
        const templateIdNum = templateSelect?.value ? Number(templateSelect.value) : NaN;
        const hasTemplate = Number.isInteger(templateIdNum) && templateIdNum > 0;
        const hasBody = Boolean(String(composed.text || "").trim() || String(composed.html || "").trim());
        if (!hasBody && !hasTemplate) {
          throw new Error("Write a message or choose a template before queueing.");
        }
        const skipAlreadySent = Boolean(bulkSkipSent?.checked);
        const previewRes = await fetchApiJson(
          "/api/email/bulk-campaign/preview?tag=" + encodeURIComponent(tag) + (skipAlreadySent ? "&skipSent=1" : "") + "&subject=" + encodeURIComponent(subject)
        );
        const sendable = Number(previewRes?.data?.sendable || 0);
        if (!sendable) throw new Error("No sendable contacts for that tag.");
        const perHour = Number(bulkRateSelect?.value || 40);
        const campaignFrom = String(fromSelect?.value || "").trim();
        const fromWarn =
          campaignFrom && !fromAddressSendsAsItself(campaignFrom)
            ? "\n\n⚠ Heads up: " +
              campaignFrom +
              " has no SMTP login of its own, so recipients may see your default sender address instead. " +
              "Add SMTP for it in Settings → Email Sender Addresses to send as " +
              campaignFrom +
              "."
            : "";
        const ok = window.confirm(
          "Queue this message to " +
            sendable +
            " contact" +
            (sendable === 1 ? "" : "s") +
            ' tagged "' +
            tag +
            '" at ' +
            perHour +
            "/hour?\n\nEach email is personalized ({{first_name}} etc.) and Do Not Email contacts are skipped." +
            fromWarn
        );
        if (!ok) return;
        bulkQueueBtn.disabled = true;
        bulkQueueBtn.textContent = "Queuing...";
        setBulkQueueMsg("Queuing campaign... this can take a few seconds for a large tag.", false);
        const payload = {
          tag,
          subject,
          html: composed.html,
          text: composed.text,
          from: String(fromSelect?.value || "").trim(),
          perHour,
          skipAlreadySent
        };
        if (hasTemplate) payload.templateId = templateIdNum;
        const { response, data } = await fetchApiJson("/api/email/bulk-campaign", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
        if (!response.ok) throw new Error(data.error || "Could not queue the campaign");
        const queuedMsg =
          "Campaign queued: " +
          data.queued +
          " emails at " +
          data.perHour +
          "/hour" +
          (data.skippedAlreadySent ? " (" + data.skippedAlreadySent + " already emailed for this tag were skipped)" : "") +
          ". Sending runs on the server - you can leave this page.";
        showMessage(queuedMsg, false);
        setBulkQueueMsg(queuedMsg, false);
        await refreshBulkCampaigns();
      } catch (err) {
        const emsg = err.message || "Could not queue the campaign.";
        showMessage(emsg, true);
        setBulkQueueMsg(emsg, true);
      } finally {
        bulkQueueBtn.disabled = false;
        bulkQueueBtn.textContent = queueBtnLabel;
      }
    });
  }
  if (bulkCampaignsList) {
    bulkCampaignsList.addEventListener("click", async (e) => {
      const pauseBtn = e.target.closest(".email-bulk-campaign-pause");
      const resumeBtn = e.target.closest(".email-bulk-campaign-resume");
      const cancelBtn = e.target.closest(".email-bulk-campaign-cancel");
      const btn = pauseBtn || resumeBtn || cancelBtn;
      if (!btn) return;
      const batchId = btn.getAttribute("data-batch-id") || "";
      if (!batchId) return;
      let endpoint = "/api/email/bulk-campaign/cancel";
      if (pauseBtn) endpoint = "/api/email/bulk-campaign/pause";
      else if (resumeBtn) endpoint = "/api/email/bulk-campaign/resume";
      if (cancelBtn && !window.confirm("Cancel all remaining emails in this campaign?")) return;
      const originalLabel = btn.textContent;
      if (pauseBtn) btn.textContent = "Pausing...";
      else if (resumeBtn) btn.textContent = "Resuming...";
      else if (cancelBtn) btn.textContent = "Canceling...";
      // Disable every button in this campaign's row so repeated clicks during the
      // (sometimes 10-15s) server action can't fire duplicate requests.
      const rowBtns = btn.parentElement ? [...btn.parentElement.querySelectorAll("button")] : [btn];
      rowBtns.forEach((b) => { b.disabled = true; });
      try {
        const { response, data } = await fetchApiJson(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ batchId })
        });
        if (!response.ok) throw new Error(data.error || "Action failed");
        const plural = (n) => (Number(n) === 1 ? "" : "s");
        if (pauseBtn) setBulkQueueMsg("Paused " + (data.paused || 0) + " email" + plural(data.paused) + ".", false);
        else if (resumeBtn) setBulkQueueMsg("Resumed " + (data.resumed || 0) + " email" + plural(data.resumed) + ".", false);
        else setBulkQueueMsg("Canceled " + (data.canceled || 0) + " email" + plural(data.canceled) + ".", false);
        await refreshBulkCampaigns();
      } catch (err) {
        setBulkQueueMsg(err.message || "Action failed.", true);
        rowBtns.forEach((b) => { b.disabled = false; });
        btn.textContent = originalLabel;
      }
    });
  }
  if (bulkTagSelect) {
    bulkTagSelect.addEventListener("change", refreshBulkPreviewLine);
    if (bulkSkipSent) bulkSkipSent.addEventListener("change", refreshBulkPreviewLine);
    loadBulkTags();
    window.setTimeout(refreshBulkCampaigns, 600);
  }

  // ---- 5) Recent opens (warm leads) ----
  const recentOpensList = document.getElementById("emailRecentOpensList");
  const timeAgo = (unix) => {
    const s = Math.max(0, Math.floor(Date.now() / 1000) - Number(unix || 0));
    if (s < 60) return "just now";
    if (s < 3600) return Math.floor(s / 60) + "m ago";
    if (s < 86400) return Math.floor(s / 3600) + "h ago";
    return Math.floor(s / 86400) + "d ago";
  };
  async function loadRecentOpens() {
    if (!recentOpensList) return;
    try {
      const { response, data } = await fetchApiJson("/api/email/recent-opens?limit=15");
      if (!response.ok) return;
      const items = Array.isArray(data?.items) ? data.items : [];
      if (!items.length) {
        recentOpensList.innerHTML =
          '<div class="hint">No opens yet - recipients appear here the moment they open one of your emails.</div>';
        return;
      }
      recentOpensList.innerHTML = "";
      for (const item of items) {
        const row = document.createElement("div");
        row.className = "email-recent-open-row";
        const who = document.createElement(item.contactId ? "a" : "span");
        who.className = "email-recent-open-who";
        who.textContent = item.contactName || item.toEmails || "Unknown";
        if (item.contactId) who.setAttribute("href", "/contact.html?id=" + encodeURIComponent(item.contactId));
        const meta = document.createElement("span");
        meta.className = "email-recent-open-meta";
        const phone = String(item.contactPhone || "").trim();
        meta.textContent =
          ' opened "' + item.subject + '" - ' + timeAgo(item.openedAt) + (phone ? " - " + phone : "");
        row.appendChild(who);
        row.appendChild(meta);
        recentOpensList.appendChild(row);
      }
    } catch {
      /* ignore */
    }
  }
  if (recentOpensList) {
    loadRecentOpens();
    window.setInterval(loadRecentOpens, 60000);
  }
  } catch (err) {
    console.warn("Send Email page upgrades:", err);
  }
})();

/* ── Email Templates page: live rendered preview ───────────────────────── */
(function templateEditorLivePreview() {
  if (!isEmailTemplatesOnlyPage) return;
  const previewFrame = document.getElementById("templateLivePreviewFrame");
  const previewToggle = document.getElementById("templateLivePreviewToggleBtn");
  const subjectInput = document.getElementById("saveTemplateSubject");
  if (!previewFrame || !previewToggle || !templateBodyEditor) return;

  let previewVisible = false;
  let previewTimer = null;

  const escapeForPreview = (s) =>
    String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");

  function sampleTemplateMergeFields() {
    const origin = String(window.location?.origin || "").replace(/\/$/, "");
    return {
      full_name: "Jane Doe",
      first_name: "Jane",
      last_name: "Doe",
      age: "42",
      email: "jane@example.com",
      phone: "(555) 555-0100",
      state: "TX",
      date_of_contact: "Jan 15, 2026",
      quote: "$412/mo",
      policy_number: "POL-10482",
      app_id: "POL-10482",
      coverage_start_date: "Mar 1, 2026",
      policy_renewal: "01/01/2026",
      upon_approval: "Upon approval",
      vcall: "https://meet.example.com/review",
      insurance_type: "ACA",
      good_through: computeGoodThroughDate(7),
      unsubscribe_url: origin ? `${origin}/email-unsubscribe.html?token=preview` : "#unsubscribe-preview"
    };
  }

  async function renderTemplateLivePreview() {
    if (!previewVisible) return;
    try {
      await refreshCustomMergeFieldsCache();
      const mergeFields = sampleTemplateMergeFields();
      const customFields = getCustomMergeFieldsMap();
      let html = String(templateBodyEditor.innerHTML || "").trim();
      if (!html) {
        html = "";
      } else {
        html = applyMergeFields(html, mergeFields, { customFields, keepHtmlNbsp: true });
        // Match the send path: clamp first, then bake the editor's resize-wrapper
        // width into the <img> so a resized photo previews at its real size.
        html = applyResizedImageWrapperSizing(clampBodyImageHtml(html, RICH_EMAIL_TEMPLATE_IMAGE_MAX_PX));
      }
      const subjectLine = applyMergeFields(String(subjectInput?.value || ""), mergeFields, { customFields });
      const subjectBar = subjectLine.trim()
        ? '<div style="background:#ffffff;border-bottom:1px solid #e2e8f0;padding:10px 16px;font:600 13px Arial,sans-serif;color:#334155;">Subject: ' +
          escapeForPreview(subjectLine) +
          "</div>"
        : "";
      const emptyNote =
        '<div style="color:#94a3b8;font:14px Arial,sans-serif;padding:24px;text-align:center;background:#ffffff;border-radius:10px;">Nothing to preview yet - pick a starter template or write a body.</div>';
      previewFrame.srcdoc =
        '<!doctype html><html><head><meta charset="utf-8"><style>img{max-width:100%;height:auto;}</style></head><body style="margin:0;background:#e2e8f0;font-family:Arial,sans-serif;">' +
        subjectBar +
        '<div style="padding:14px;">' +
        (html || emptyNote) +
        "</div></body></html>";
    } catch (err) {
      console.warn("Template live preview:", err);
    }
  }

  function scheduleTemplatePreview() {
    if (!previewVisible) return;
    window.clearTimeout(previewTimer);
    previewTimer = window.setTimeout(renderTemplateLivePreview, 600);
  }

  const setPreviewVisible = (next) => {
    previewVisible = Boolean(next);
    previewFrame.hidden = !previewVisible;
    previewToggle.textContent = previewVisible ? "Hide preview" : "Show preview";
    if (previewVisible) renderTemplateLivePreview();
  };
  previewToggle.addEventListener("click", () => setPreviewVisible(!previewVisible));
  templateBodyEditor.addEventListener("input", scheduleTemplatePreview);
  if (subjectInput) subjectInput.addEventListener("input", scheduleTemplatePreview);

  document.addEventListener("crm:reload-email-templates", () => {
    if (previewVisible) scheduleTemplatePreview();
  });
})();

/* ── Live rendered email preview (self-building; resilient to HTML edits) ───
   Inserts after attachments so compose (message + files) comes first, then
   review, then send. Falls back to after the message box if attachments are missing. */
(function emailLivePreviewModule() {
  try {
    if (document.getElementById("emailLivePreviewFrame")) return; // already present in HTML
    const messageBox =
      document.querySelector(".email-body-box") || document.querySelector(".agile-email-message-box");
    const attachmentsWrap = document.querySelector(".email-attachments-wrap");
    const insertAfter = attachmentsWrap || messageBox;
    if (!insertAfter || typeof getComposedEmailContent !== "function") return;

    const wrap = document.createElement("div");
    wrap.className = "email-live-preview-wrap";
    wrap.id = "emailLivePreviewWrap";
    const head = document.createElement("div");
    head.className = "email-live-preview-head";
    const label = document.createElement("span");
    label.className = "contact-modal-field-label";
    label.textContent = "Preview - what the recipient sees";
    const toggle = document.createElement("button");
    toggle.type = "button";
    toggle.id = "emailLivePreviewToggleBtn";
    toggle.textContent = "Show preview";
    head.appendChild(label);
    head.appendChild(toggle);
    const frame = document.createElement("iframe");
    frame.id = "emailLivePreviewFrame";
    frame.className = "email-live-preview-frame";
    frame.title = "Rendered email preview";
    frame.setAttribute("sandbox", "");
    frame.hidden = true;
    wrap.appendChild(head);
    wrap.appendChild(frame);
    insertAfter.insertAdjacentElement("afterend", wrap);

    const subjectInput = document.getElementById("emailSubject");
    const editor = document.getElementById("emailBodyEditor");
    const templateSel = document.getElementById("emailTemplateSelect");
    const toInput = document.getElementById("emailToManual");
    let visible = false;
    let timer = null;

    const esc = (s) =>
      String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

    async function render() {
      if (!visible) return;
      try {
        if (typeof refreshCustomMergeFieldsCache === "function") await refreshCustomMergeFieldsCache();
        const composed = await getComposedEmailContent();
        const mergeFields =
          typeof getSelectedContactMergeFields === "function" ? await getSelectedContactMergeFields() : {};
        const customFields = typeof getCustomMergeFieldsMap === "function" ? getCustomMergeFieldsMap() : {};
        let html = String(composed.html || "").trim();
        if (!html) html = esc(String(composed.text || "").trim()).replace(/\n/g, "<br>");
        if (typeof applyMergeFields === "function") {
          html = applyMergeFields(html, mergeFields, { customFields, keepHtmlNbsp: true });
        }
        let subjectLine = String(subjectInput?.value || "");
        if (typeof applyMergeFields === "function") {
          subjectLine = applyMergeFields(subjectLine, mergeFields, { customFields });
        }
        const subjectBar = subjectLine.trim()
          ? '<div style="background:#fff;border-bottom:1px solid #e2e8f0;padding:10px 16px;font:600 13px Arial,sans-serif;color:#334155;">Subject: ' +
            esc(subjectLine) +
            "</div>"
          : "";
        const empty =
          '<div style="color:#94a3b8;font:14px Arial,sans-serif;padding:24px;text-align:center;background:#fff;border-radius:10px;">Nothing to preview yet - choose a template or write a message.</div>';
        frame.srcdoc =
          '<!doctype html><html><head><meta charset="utf-8"><style>img{max-width:100%;height:auto;}</style></head><body style="margin:0;background:#e2e8f0;font-family:Arial,sans-serif;">' +
          subjectBar +
          '<div style="padding:14px;">' +
          (html || empty) +
          "</div></body></html>";
      } catch (err) {
        console.warn("Email live preview:", err);
      }
    }
    function schedule() {
      if (!visible) return;
      window.clearTimeout(timer);
      timer = window.setTimeout(render, 600);
    }
    function setVisible(next) {
      visible = Boolean(next);
      frame.hidden = !visible;
      toggle.textContent = visible ? "Hide preview" : "Show preview";
      if (visible) render();
    }
    toggle.addEventListener("click", () => setVisible(!visible));
    if (editor) editor.addEventListener("input", schedule);
    if (subjectInput) subjectInput.addEventListener("input", schedule);
    if (toInput) toInput.addEventListener("change", schedule);
    /* The signature on/off toggle (and the From address, which can carry a
       per-address signature) change the composed body, so refresh the preview
       when they change - otherwise it shows a stale render with the signature
       still attached after it has been turned off. */
    const sigToggleBtn = document.getElementById("emailIncludeSignatureBtn");
    const sigToggleCheck = document.getElementById("emailIncludeSignature");
    const fromSel = document.getElementById("emailFromSelect");
    if (sigToggleBtn) sigToggleBtn.addEventListener("click", () => window.setTimeout(render, 60));
    if (sigToggleCheck) sigToggleCheck.addEventListener("change", () => window.setTimeout(render, 60));
    if (fromSel) fromSel.addEventListener("change", schedule);
    if (templateSel) {
      templateSel.addEventListener("change", () => {
        if (templateSel.value && !visible) window.setTimeout(() => setVisible(true), 250);
        else window.setTimeout(schedule, 250);
      });
    }
  } catch (err) {
    console.warn("emailLivePreviewModule:", err);
  }
})();
