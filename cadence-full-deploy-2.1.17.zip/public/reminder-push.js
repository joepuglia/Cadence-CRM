(function () {
  function getApiBase() {
    let injected =
      typeof window.__CRM_API_ORIGIN__ === "string" ? window.__CRM_API_ORIGIN__.trim().replace(/\/$/, "") : "";
    if (!injected && typeof window.location !== "undefined") {
      const proto = window.location.protocol;
      if (proto === "http:" || proto === "https:") {
        injected = window.location.origin.replace(/\/$/, "");
      }
    }
    if (injected) return injected;
    const fromMeta = document.querySelector('meta[name="crm-api-base"]');
    return fromMeta ? String(fromMeta.getAttribute("content") || "").trim().replace(/\/$/, "") : "";
  }

  function apiUrl(path) {
    const p = path.startsWith("/") ? path : `/${path}`;
    const base = getApiBase();
    return base ? `${base}${p}` : p;
  }

  function urlBase64ToUint8Array(base64String) {
    const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; ++i) outputArray[i] = rawData.charCodeAt(i);
    return outputArray;
  }

  async function fetchJson(path, init) {
    const response = await fetch(apiUrl(path), init);
    const text = await response.text();
    let data = {};
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      data = {};
    }
    return { response, data };
  }

  let smsToggleReady = false;

  function setSmsHint(text, isErr) {
    const hint = document.getElementById("taskSmsRemindersHint");
    if (!hint) return;
    hint.textContent = text;
    hint.style.color = isErr ? "#c62828" : "";
  }

  function prettyPhone(raw) {
    const digits = String(raw || "").replace(/\D/g, "");
    const local = digits.length === 11 && digits.startsWith("1") ? digits.slice(1) : digits;
    if (local.length === 10) return `(${local.slice(0, 3)}) ${local.slice(3, 6)}-${local.slice(6)}`;
    return String(raw || "").trim();
  }

  function smsRouteHint(data, enabled) {
    const lastError = String((data && data.lastTaskSmsError) || "").trim();
    if (lastError) return lastError;
    if (!enabled) return "Text reminders are off. Turn on “Text me when a task is due” under Your phone number. Email reminders still go out.";
    if (data && data.taskSmsBlockedBusinessLine) {
      return "Task texts are blocked because the cell saved under Your phone number is your Cadence business number. Enter your personal cell.";
    }
    const from = prettyPhone(data && data.taskSmsFrom);
    const to = prettyPhone(data && data.taskSmsTo);
    if (!from) {
      return "Text reminders are on, but no sending number is connected. Contact support@crmcadence.com.";
    }
    if (!to) {
      return "Text reminders are on. Add your personal cell under Settings → Your phone number. Do not use your Cadence business number.";
    }
    return `Text reminders come from ${from} and go to ${to}. The contact is not texted.`;
  }

  async function loadStatusIntoDom() {
    const emailEl = document.getElementById("reminderEmailStatus");
    const pushEl = document.getElementById("reminderPushStatus");
    const subsEl = document.getElementById("reminderPushSubsCount");
    const toggle = document.getElementById("taskSmsRemindersToggle");
    if (!emailEl && !pushEl && !toggle) return;
    const { response, data } = await fetchJson("/api/reminders/status");
    if (!response.ok) {
      if (emailEl) emailEl.textContent = "Could not load";
      if (pushEl) pushEl.textContent = "Could not load";
      setSmsHint("Could not load the text reminder switch.", true);
      return;
    }
    if (emailEl) {
      const to = String(data.emailReminderTo || "").trim();
      emailEl.textContent = data.emailReminderReady
        ? `On${to ? ` — ${to}` : ""}`
        : "Off — no mail sender is saved";
    }
    if (pushEl) pushEl.textContent = data.pushReminderReady ? "On" : "Off";
    if (subsEl) subsEl.textContent = String(Number(data.pushSubscriptionCount || 0));
    if (toggle) {
      smsToggleReady = false;
      toggle.checked = data.taskSmsRemindersEnabled !== false;
      smsToggleReady = true;
      setSmsHint(smsRouteHint(data, toggle.checked), Boolean(String(data.lastTaskSmsError || "").trim() || data.taskSmsBlockedBusinessLine));
    }
  }

  async function saveTaskSmsReminders(enabled) {
    const toggle = document.getElementById("taskSmsRemindersToggle");
    const { response, data } = await fetchJson("/api/reminders/task-sms", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ enabled: Boolean(enabled) })
    });
    if (!response.ok) {
      if (toggle) {
        smsToggleReady = false;
        toggle.checked = !enabled;
        smsToggleReady = true;
      }
      setSmsHint(data.error || "Could not save the text reminder switch.", true);
      return;
    }
    await loadStatusIntoDom();
  }

  async function enablePush() {
    const msg = document.getElementById("reminderPushMessage");
    const setMsg = (t, isErr) => {
      if (!msg) return;
      msg.textContent = t;
      msg.style.color = isErr ? "#c62828" : "#1b5e20";
    };

    if (!("serviceWorker" in navigator) || !("PushManager" in window)) {
      setMsg("This browser does not support push notifications.", true);
      return;
    }

    setMsg("Checking server…");
    const { response: stResp, data: status } = await fetchJson("/api/reminders/status");
    if (!stResp.ok) {
      setMsg("Could not turn on browser notifications. Refresh this page and try again.", true);
      return;
    }
    if (!status.vapidPublicKey || !String(status.vapidPublicKey).trim()) {
      setMsg("Browser notifications are not available right now.", true);
      return;
    }

    const permission = await Notification.requestPermission();
    if (permission !== "granted") {
      setMsg("Notification permission was not granted.", true);
      return;
    }

    const reg = await navigator.serviceWorker.register("/sw.js");
    await reg.update();

    const sub = await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(status.vapidPublicKey)
    });

    const json = sub.toJSON();
    const { response: postResp, data: postBody } = await fetchJson("/api/reminders/push-subscribe", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ subscription: json })
    });

    if (!postResp.ok) {
      setMsg(postBody.error || "Failed to save subscription.", true);
      return;
    }

    setMsg("Browser notifications enabled for follow-up reminders.");
    await loadStatusIntoDom();
  }

  async function disablePush() {
    const msg = document.getElementById("reminderPushMessage");
    const setMsg = (t, isErr) => {
      if (!msg) return;
      msg.textContent = t;
      msg.style.color = isErr ? "#c62828" : "#1b5e20";
    };

    const reg = await navigator.serviceWorker.getRegistration("/sw.js");
    const sub = reg && reg.pushManager ? await reg.pushManager.getSubscription() : null;
    if (!sub) {
      setMsg("Browser notifications are already off on this device.", true);
      await loadStatusIntoDom();
      return;
    }

    const json = sub.toJSON();
    await fetchJson("/api/reminders/push-unsubscribe", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ endpoint: json.endpoint })
    });

    await sub.unsubscribe().catch(() => {});
    setMsg("Browser notifications disabled for this device.");
    await loadStatusIntoDom();
  }

  document.addEventListener("DOMContentLoaded", () => {
    const enableBtn = document.getElementById("enablePushRemindersBtn");
    const disableBtn = document.getElementById("disablePushRemindersBtn");
    const smsToggle = document.getElementById("taskSmsRemindersToggle");
    if (!enableBtn && !disableBtn && !smsToggle) return;

    loadStatusIntoDom().catch(() => {});
    if (enableBtn) enableBtn.addEventListener("click", () => enablePush().catch(() => {}));
    if (disableBtn) disableBtn.addEventListener("click", () => disablePush().catch(() => {}));
    if (smsToggle) {
      smsToggle.addEventListener("change", () => {
        if (!smsToggleReady) return;
        saveTaskSmsReminders(smsToggle.checked).catch(() => {});
      });
    }
  });
})();
