(function () {
  function twilioPhoneDigits(e164) {
    return String(e164 || "").replace(/\D/g, "") || "0";
  }

  function compareTwilioPhoneNumbers(a, b) {
    const da = twilioPhoneDigits(a);
    const db = twilioPhoneDigits(b);
    if (da.length !== db.length) return da.length < db.length ? -1 : 1;
    if (da < db) return -1;
    if (da > db) return 1;
    return 0;
  }

  function sortTwilioFromEntries(entries) {
    const lineOrder = { primary: 0, secondary: 1, third: 2, custom: 3 };
    return [...entries].sort((a, b) => {
      const cmp = compareTwilioPhoneNumbers(a.number, b.number);
      if (cmp !== 0) return cmp;
      return (lineOrder[a.line] ?? 9) - (lineOrder[b.line] ?? 9);
    });
  }

  window.CrmTwilioNumberSort = {
    twilioPhoneDigits,
    compareTwilioPhoneNumbers,
    sortTwilioFromEntries
  };
})();
