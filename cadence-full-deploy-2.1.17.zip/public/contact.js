const messageEl = document.getElementById("message");
const form = document.getElementById("contactPageForm");
let contactDetailsStickySaveEl = null;
let contactDetailsStickyTextEl = null;
const CONTACT_STICKY_SAVE_PENDING = "Save changes before leaving this contact.";
const CONTACT_STICKY_SAVE_SAVED = "Contact Saved";
const backBtn = document.getElementById("backToContactsBtn");
const backToSummaryBtn = document.getElementById("backToSummaryBtn");
const smsBtn = document.getElementById("contactPageSmsBtn");
const emailBtn = document.getElementById("contactPageEmailBtn");
const callBtn = document.getElementById("contactPageCallBtn");
const whatsAppBtn = document.getElementById("contactPageWhatsAppBtn");
const addCampaignBtn = document.getElementById("contactPageAddCampaignBtn");
const deleteBtn = document.getElementById("contactPageDeleteBtn");
const summarySmsBtn = document.getElementById("contactSummarySmsBtn");
const summaryEmailBtn = document.getElementById("contactSummaryEmailBtn");
const summaryCallBtn = document.getElementById("contactSummaryCallBtn");
const summaryHealthSherpaBtn = document.getElementById("contactSummaryHealthSherpaBtn");
const pageHealthSherpaBtn = document.getElementById("contactPageHealthSherpaBtn");
const pageThanksIoBtn = document.getElementById("contactPageThanksIoBtn");
const summaryAddCampaignBtn = document.getElementById("contactSummaryAddCampaignBtn");
const summaryDeleteBtn = document.getElementById("contactSummaryDeleteBtn");
const aiLeadScoreBtn = document.getElementById("aiLeadScoreBtn");
const aiCallSummaryBtn = document.getElementById("aiCallSummaryBtn");
const aiCallSummaryNotes = document.getElementById("aiCallSummaryNotes");
const aiObjectionCoachBtn = document.getElementById("aiObjectionCoachBtn");
const aiObjectionInput = document.getElementById("aiObjectionInput");
const contactAiResult = document.getElementById("contactAiResult");
const contactHistoryList = document.getElementById("contactHistoryList");
const contactHistoryCount = document.getElementById("contactHistoryCount");
const contactTwilioCallModal = document.getElementById("contactTwilioCallModal");
const contactTwilioCallModalCloseBtn = document.getElementById("contactTwilioCallModalCloseBtn");
const contactTwilioCallForm = document.getElementById("contactTwilioCallForm");
const contactTwilioEndCallBtn = document.getElementById("contactTwilioEndCallBtn");
const contactTwilioCallStatus = document.getElementById("contactTwilioCallStatus");
const contactTwilioCallUseHeadset = document.getElementById("contactTwilioCallUseHeadset");
const contactTwilioCallRecord = document.getElementById("contactTwilioCallRecord");
const contactTwilioSmsModal = document.getElementById("contactTwilioSmsModal");
const contactTwilioSmsModalCloseBtn = document.getElementById("contactTwilioSmsModalCloseBtn");
const contactTwilioSmsForm = document.getElementById("contactTwilioSmsForm");
const contactTwilioSmsStatus = document.getElementById("contactTwilioSmsStatus");
const contactHistoryActionMenu = document.getElementById("contactHistoryActionMenu");
const contactHistoryActionPinBtn = document.getElementById("contactHistoryActionPinBtn");
const contactHistoryActionStarBtn = document.getElementById("contactHistoryActionStarBtn");
const contactHistoryActionDeleteBtn = document.getElementById("contactHistoryActionDeleteBtn");
const contactHistoryLoadMoreBtn = document.getElementById("contactHistoryLoadMoreBtn");
const contactSummaryRecordingsList = document.getElementById("contactSummaryRecordingsList");
const contactHistoryEmailModal = document.getElementById("contactHistoryEmailModal");
const contactHistoryEmailModalCloseBtn = document.getElementById("contactHistoryEmailModalCloseBtn");
const contactHistoryEmailMeta = document.getElementById("contactHistoryEmailMeta");
const contactHistoryEmailFrame = document.getElementById("contactHistoryEmailFrame");
const contactTaskNewBtn = document.getElementById("contactTaskNewBtn");
const contactTaskForm = document.getElementById("contactTaskForm");
const contactTasksList = document.getElementById("contactTasksList");
const contactTaskSaveBtn = document.getElementById("contactTaskSaveBtn");
const contactSummaryPanel = document.getElementById("contactSummaryPanel");
const contactFullDetailsWrap = document.getElementById("contactFullDetailsWrap");
const openFullDetailsBtn = document.getElementById("openFullDetailsBtn");
const jumpToAiPanelBtn = document.getElementById("jumpToAiPanelBtn");
const contactPageHeading = document.getElementById("contactPageHeading");
const contactPageHeadingText = document.getElementById("contactPageHeadingText");
const contactNavActiveText = document.getElementById("contactNavActiveText");
const followUpReminderEnterBtn = document.getElementById("followUpReminderEnterBtn");
const followUpSaveMessageEl = document.getElementById("followUpSaveMessage");
const contactTaskSaveMessageEl = document.getElementById("contactTaskSaveMessage");
const SECTION_SAVE_HIDE_MS = 4500;
let followUpSaveHideTimer = null;
let contactTaskSaveHideTimer = null;
const bulkTagsModal = document.getElementById("bulkTagsModal");
const bulkTagsModalForm = document.getElementById("bulkTagsModalForm");
const bulkTagsModalTitle = document.getElementById("bulkTagsModalTitle");
const bulkTagsModalInput = document.getElementById("bulkTagsModalInput");
const bulkTagsModalSubmitBtn = document.getElementById("bulkTagsModalSubmitBtn");
const bulkTagsModalCloseBtn = document.getElementById("bulkTagsModalCloseBtn");

let activeContact = null;
let householdMembers = [];
let contactQuotes = [];
let householdMemberEditId = "";
let contactQuoteEditId = "";
let contactTwilioCallStatusPollTimer = null;
let activeContactTwilioCallSid = "";
let activeContactTwilioCallMode = "";
let contactTwilioSmsCloseTimer = null;
let activeHistoryItemId = 0;
const historyEmailPayloadById = new Map();
const contactEmailOpensBySubject = new Map();
let historyRenderRequestSeq = 0;
let historyOffset = 0;
let historyVisibleCount = 0;
/** History row id for the latest Call Back Notes change (only that row may show a green note). */
let latestNotesHistoryHighlightId = 0;
let historyHasMore = false;
const HISTORY_PAGE_SIZE = 40;
const HISTORY_RENDER_BATCH_SIZE = 20;
const isFullDetailsMode = true;
const shouldFocusTasksOnLoad = (() => {
  const params = new URLSearchParams(window.location.search);
  const focus = String(params.get("focus") || "")
    .trim()
    .toLowerCase();
  const hash = String(window.location.hash || "")
    .trim()
    .toLowerCase();
  return focus === "tasks" || hash === "#contacttaskssection" || hash === "#tasks";
})();
const shouldFocusFollowUpOnLoad = (() => {
  const params = new URLSearchParams(window.location.search);
  const focus = String(params.get("focus") || "")
    .trim()
    .toLowerCase();
  const hash = String(window.location.hash || "")
    .trim()
    .toLowerCase();
  return (
    focus === "follow_up" ||
    focus === "followup" ||
    hash === "#contactfollowupsection" ||
    hash === "#followup"
  );
})();

function formatCommissionValue(raw) {
  const value = String(raw == null ? "" : raw).trim();
  if (!value) return "";
  return value.startsWith("$") ? value : `$${value}`;
}

/** Numeric income → $85,000; labels like Low/Medium/High stay as entered. */
function formatIncomeValue(raw) {
  const value = String(raw == null ? "" : raw).trim();
  if (!value) return "";
  const stripped = value.replace(/[$,\s]/g, "");
  if (/^-?\d+(\.\d+)?$/.test(stripped)) {
    const num = Number(stripped);
    if (Number.isFinite(num)) {
      return new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: "USD",
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
      }).format(num);
    }
  }
  return value;
}

function showMessage(text, isError = false) {
  const str = String(text == null ? "" : text);
  if (isError && typeof window.crmHandleAuthErrorMessage === "function" && window.crmHandleAuthErrorMessage(str, isError)) {
    return;
  }
  messageEl.textContent = str;
  messageEl.style.color = isError ? "#c62828" : "#1b5e20";
}

function showSectionSaveMessage(el, text, isError = false, timerKey = "") {
  if (!el) return;
  const timerMap = { followUp: followUpSaveHideTimer, task: contactTaskSaveHideTimer };
  const activeTimer = timerMap[timerKey];
  if (activeTimer) clearTimeout(activeTimer);
  const str = String(text || "").trim();
  if (!str) {
    el.hidden = true;
    el.textContent = "";
    el.classList.remove("contact-section-save-message--ok", "contact-section-save-message--error");
    return;
  }
  el.hidden = false;
  el.textContent = str;
  el.classList.toggle("contact-section-save-message--ok", !isError);
  el.classList.toggle("contact-section-save-message--error", isError);
  if (!isError && timerKey) {
    const hideTimer = setTimeout(() => {
      el.hidden = true;
      el.textContent = "";
      el.classList.remove("contact-section-save-message--ok", "contact-section-save-message--error");
      if (timerKey === "followUp") followUpSaveHideTimer = null;
      if (timerKey === "task") contactTaskSaveHideTimer = null;
    }, SECTION_SAVE_HIDE_MS);
    if (timerKey === "followUp") followUpSaveHideTimer = hideTimer;
    if (timerKey === "task") contactTaskSaveHideTimer = hideTimer;
  }
}

function setSummaryValue(id, value) {
  const el = document.getElementById(id);
  if (!el) return;
  const v = String(value == null ? "" : value).trim();
  el.textContent = v || "-";
}

function setSummaryMailto(id, value) {
  const el = document.getElementById(id);
  if (!el) return;
  const v = String(value == null ? "" : value).trim();
  if (!v) {
    el.textContent = "-";
    return;
  }
  el.innerHTML = `<a href="mailto:${escapeHtmlAttr(v)}">${escapeHtml(v)}</a>`;
}

function setSummaryTel(id, value) {
  const el = document.getElementById(id);
  if (!el) return;
  const v = String(value == null ? "" : value).trim();
  if (!v) {
    el.textContent = "-";
    return;
  }
  const tel = v.replace(/[^\d+]/g, "");
  el.innerHTML = `<a href="tel:${escapeHtmlAttr(tel)}">${escapeHtml(v)}</a>`;
}

function setSummaryTags(value) {
  const el = document.getElementById("contactSummaryTags");
  if (!el) return;
  const tags = String(value || "")
    .split(",")
    .map((tag) => tag.trim())
    .filter(Boolean);
  if (!tags.length) {
    el.textContent = "-";
    return;
  }
  el.innerHTML = tags.map((tag) => `<span class="contact-summary-tag-pill">${escapeHtml(tag)}</span>`).join("");
}

const SUMMARY_SENSITIVE_KEY_RE = /ssn|routing|bank account|account number|date of birth|\bdob\b/i;

function looksLikeApplicationDump(text) {
  const lines = String(text || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  if (lines.length < 6) return false;
  const headers = lines.filter((line) => /^[A-Z][A-Z0-9 /&._-]{3,}$/.test(line)).length;
  const kv = lines.filter((line) => /^[A-Za-z][A-Za-z0-9 /._-]{1,40}:\s+\S/.test(line)).length;
  return headers >= 2 || kv >= 5;
}

function maskSensitiveValue(value) {
  const v = String(value || "").trim();
  if (!v) return "-";
  if (v.length <= 4) return "••••";
  return `••••${v.slice(-4)}`;
}

function renderApplicationDumpHtml(text) {
  const lines = String(text || "").replace(/\r\n/g, "\n").split("\n");
  const sections = [];
  let current = { title: "Notes", lines: [] };
  for (const raw of lines) {
    const line = String(raw || "").trim();
    if (!line) continue;
    if (/^[A-Z][A-Z0-9 /&._-]{3,}$/.test(line) && line.length < 48) {
      if (current.lines.length || current.title !== "Notes") sections.push(current);
      current = { title: line, lines: [] };
      continue;
    }
    current.lines.push(raw);
  }
  if (current.lines.length || !sections.length) sections.push(current);
  return sections
    .map((section, index) => {
      const pairs = [];
      const leftover = [];
      for (const line of section.lines) {
        const match = String(line).trim().match(/^([A-Za-z][A-Za-z0-9 /._-]{1,40}):\s*(.*)$/);
        if (match) pairs.push([match[1], match[2]]);
        else leftover.push(line);
      }
      let body = "";
      if (pairs.length) {
        body += `<dl class="contact-summary-note-kv">${pairs
          .map(([key, value]) => {
            const sensitive = SUMMARY_SENSITIVE_KEY_RE.test(key);
            const shown = sensitive ? maskSensitiveValue(value) : escapeHtml(value || "-");
            const cls = sensitive
              ? ` class="contact-summary-note-sensitive" title="Click to reveal" data-sensitive-value="${escapeHtmlAttr(value)}"`
              : "";
            return `<dt>${escapeHtml(key)}</dt><dd${cls}>${shown}</dd>`;
          })
          .join("")}</dl>`;
      }
      if (leftover.length) {
        body += `<div class="contact-summary-notes-preview">${leftover.map((line) => escapeHtml(line)).join("<br>")}</div>`;
      }
      return `<details class="contact-summary-note-section"${index === 0 ? " open" : ""}><summary>${escapeHtml(section.title)}</summary>${body || "<div>-</div>"}</details>`;
    })
    .join("");
}

function renderSummaryNotesHtml(value, options = {}) {
  const expanded = !!options.expanded;
  const text = String(value == null ? "" : value).trim();
  if (!text) return "-";
  if (looksLikeApplicationDump(text)) return renderApplicationDumpHtml(text);
  const lines = splitCallbackNotesByNewline(text);
  if (!lines.length) return "-";
  const visible = expanded || lines.length <= 3 ? lines : lines.slice(-3);
  const offset = expanded || lines.length <= 3 ? 0 : lines.length - visible.length;
  const body = visible
    .map((line, index) => {
      const html = escapeHtml(line);
      return offset + index === lines.length - 1 ? `<span class="contact-history-note-newest">${html}</span>` : html;
    })
    .join("<br>");
  if (lines.length > 3) {
    return `<div class="contact-summary-notes-preview">${body}</div><button type="button" class="contact-summary-notes-toggle">${expanded ? "Show latest only" : `View all notes (${lines.length})`}</button>`;
  }
  return body;
}

function setSummaryHtml(id, html) {
  const el = document.getElementById(id);
  if (!el) return;
  el.innerHTML = html || "-";
}

function setSummaryMultilineValue(id, value) {
  const el = document.getElementById(id);
  if (!el) return;
  const v = String(value == null ? "" : value).trim();
  el.dataset.rawNotes = v;
  el.style.whiteSpace = "normal";
  if (looksLikeApplicationDump(v)) {
    el.innerHTML = renderApplicationDumpHtml(v);
    return;
  }
  el.style.whiteSpace = "pre-line";
  el.textContent = v || "-";
}

function setSummaryCallbackNotesValue(id, value) {
  const el = document.getElementById(id);
  if (!el) return;
  el.dataset.rawNotes = String(value == null ? "" : value);
  el.dataset.notesExpanded = "0";
  el.style.whiteSpace = "normal";
  el.innerHTML = renderSummaryNotesHtml(value, { expanded: false });
}

function aiScorePillHtml(scoreRaw, reasonRaw) {
  const score = Number(scoreRaw);
  if (!Number.isFinite(score) || score <= 0) return `<span class="ai-score-pill ai-score-pill--empty">Not scored</span>`;
  const level = score >= 8 ? "hot" : score >= 5 ? "warm" : "cool";
  const reason = escapeHtml(reasonRaw || "");
  return `<span class="ai-score-pill ai-score-pill--${level}" title="${reason}">AI Score ${Math.round(score)}/10</span>`;
}

function applySummaryAiScorePriority(scoreRaw) {
  const el = document.getElementById("contactSummaryInitials");
  if (!el) return;
  el.classList.remove("contact-summary-initials--score-hot", "contact-summary-initials--score-warm", "contact-summary-initials--score-cool");
  const score = Number(scoreRaw);
  if (!Number.isFinite(score) || score <= 0) return;
  if (score >= 8) el.classList.add("contact-summary-initials--score-hot");
  else if (score >= 5) el.classList.add("contact-summary-initials--score-warm");
  else el.classList.add("contact-summary-initials--score-cool");
}

const URGENCY_NOTE_PATTERNS = [
  /\bmoving\b/i,
  /\bmove\b/i,
  /\brelocat(?:e|ing|ion)\b/i,
  /\bdeadline\b/i,
  /\bexpires?\b/i,
  /\bexpiring\b/i,
  /\burgent\b/i,
  /\basap\b/i,
  /\bsoon\b/i,
  /\bnext\s+(?:week|month)\b/i,
  /\b\d+\s*(?:day|days|week|weeks|wk|wks|month|months)\b/i,
  /\bby\s+(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b/i
];

const DISMISSED_URGENCY_STORAGE_KEY = "crm.dismissedUrgencyAlerts.v1";

function readDismissedUrgencyAlerts() {
  try {
    const raw = window.localStorage.getItem(DISMISSED_URGENCY_STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function writeDismissedUrgencyAlerts(map) {
  try {
    window.localStorage.setItem(DISMISSED_URGENCY_STORAGE_KEY, JSON.stringify(map));
  } catch {
    /* ignore quota */
  }
}

function isUrgencyAlertDismissed(contactId, note) {
  const id = String(contactId || "").trim();
  const text = String(note || "").trim();
  if (!id || !text) return false;
  return String(readDismissedUrgencyAlerts()[id] || "") === text;
}

function dismissUrgencyAlert(contactId, note) {
  const id = String(contactId || "").trim();
  const text = String(note || "").trim();
  if (!id || !text) return;
  const map = readDismissedUrgencyAlerts();
  map[id] = text;
  writeDismissedUrgencyAlerts(map);
}

function findTimeSensitiveNote(contact) {
  const lines = [
    ...splitCallbackNotesByNewline(contact?.notes || ""),
    ...String(contact?.special_notes || "")
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean)
  ];
  for (let i = lines.length - 1; i >= 0; i -= 1) {
    const line = lines[i];
    if (URGENCY_NOTE_PATTERNS.some((pattern) => pattern.test(line))) return line;
  }
  return "";
}

function renderContactUrgencyAlert(contact) {
  const alertEl = document.getElementById("contactUrgencyAlert");
  if (!alertEl) return;
  const note = findTimeSensitiveNote(contact);
  if (!note || isUrgencyAlertDismissed(contact?.id, note)) {
    alertEl.hidden = true;
    alertEl.innerHTML = "";
    return;
  }
  const shortNote = note.length > 180 ? `${note.slice(0, 180).trim()}...` : note;
  alertEl.hidden = false;
  alertEl.innerHTML = `<button type="button" class="contact-urgency-alert-dismiss" aria-label="Dismiss urgent reminder">&times;</button><strong>Time-sensitive:</strong> ${escapeHtml(shortNote)} <span>Follow up urgently.</span>`;
  alertEl.querySelector(".contact-urgency-alert-dismiss")?.addEventListener("click", () => {
    dismissUrgencyAlert(contact.id, note);
    alertEl.hidden = true;
    alertEl.innerHTML = "";
  });
}

/**
 * Parse timestamps from SQLite/API: UTC "YYYY-MM-DD HH:MM:SS", ISO strings, or Unix seconds.
 */
function parseStoredTimestamp(value) {
  if (value == null || value === "") return null;
  if (value instanceof Date) return Number.isFinite(value.getTime()) ? value : null;

  const asNumber = Number(value);
  if (Number.isFinite(asNumber) && asNumber > 0) {
    return new Date(asNumber < 1e12 ? asNumber * 1000 : asNumber);
  }

  const text = String(value).trim();
  if (!text) return null;
  if (/^\d+$/.test(text)) {
    const n = Number(text);
    if (Number.isFinite(n) && n > 0) return new Date(n < 1e12 ? n * 1000 : n);
  }

  let normalized = text;
  if (/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(\.\d+)?$/.test(text)) {
    normalized = `${text.replace(" ", "T")}Z`;
  } else if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(text)) {
    normalized = `${text.replace(" ", "T")}:00Z`;
  } else if (/^\d{4}-\d{2}-\d{2}$/.test(text)) {
    normalized = `${text}T00:00:00Z`;
  }

  const d = new Date(normalized);
  return Number.isFinite(d.getTime()) ? d : null;
}

function formatCreatedAtDisplay(raw) {
  const s = String(raw == null ? "" : raw).trim();
  if (!s) return "";
  const formatted = toReadableDateTime(raw);
  return formatted || s;
}

function summaryStatusPillHtml(statusRaw) {
  const label = String(statusRaw ?? "").trim();
  if (!label) return "-";
  const slug = label.toLowerCase().replace(/\s+/g, "-");
  const slugClass = slug === "call-back" ? "" : ` status-${slug}`;
  return `<span class="status-pill${slugClass}">${escapeHtml(label)}</span>`;
}

function summaryOutcomePillHtml(outcomeRaw) {
  const trimmed = outcomeRaw != null ? String(outcomeRaw).trim() : "";
  if (!trimmed) return "-";
  const matchKey = trimmed.toLowerCase().replace(/[\s-]+/g, "");
  if (matchKey === "sold") return `<span class="outcome-pill outcome-sold">${escapeHtml(trimmed)}</span>`;
  if (matchKey === "callback") return `<span class="outcome-pill outcome-call-back">${escapeHtml(trimmed)}</span>`;
  return `<span class="outcome-pill">${escapeHtml(trimmed)}</span>`;
}

function summaryLeadSourcePillHtml(leadSourceRaw) {
  const trimmed = leadSourceRaw != null ? String(leadSourceRaw).trim() : "";
  if (!trimmed || trimmed === "-") return "-";
  const mod = trimmed.toLowerCase() === "referral" ? " lead-source-pill--referral" : "";
  return `<span class="lead-source-pill${mod}">${escapeHtml(trimmed)}</span>`;
}

function getContactInitials(fullName) {
  const parts = String(fullName || "")
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  if (!parts.length) return "--";
  const first = parts[0]?.charAt(0) || "";
  const second = (parts[1] || parts[0] || "").charAt(0) || "";
  return `${first}${second}`.toUpperCase();
}

function applySummaryInitialsStatus(statusValue) {
  const el = document.getElementById("contactSummaryInitials");
  if (!el) return;
  const raw = String(statusValue || "").trim().toLowerCase();
  el.classList.remove(
    "contact-summary-initials--approved",
    "contact-summary-initials--pending",
    "contact-summary-initials--declined",
    "contact-summary-initials--referred",
    "contact-summary-initials--aps"
  );
  if (raw === "approved") el.classList.add("contact-summary-initials--approved");
  else if (raw === "pending") el.classList.add("contact-summary-initials--pending");
  else if (raw === "declined" || raw === "closed") el.classList.add("contact-summary-initials--declined");
  else if (raw === "referred") el.classList.add("contact-summary-initials--referred");
  else if (raw === "aps") el.classList.add("contact-summary-initials--aps");
}

function parseContactId() {
  const params = new URLSearchParams(window.location.search);
  const id = Number(params.get("id"));
  return Number.isInteger(id) && id > 0 ? id : 0;
}

function getActiveTwilioFromSelect() {
  const summary = document.getElementById("contactSummaryTwilioFromSelect");
  const full = document.getElementById("contactTwilioFromSelect");
  if (summary && summary.offsetParent !== null) return summary;
  return full || summary;
}

function openEmailPage(contactIds = []) {
  const ids = [...new Set((Array.isArray(contactIds) ? contactIds : []).map((n) => Number(n)).filter((n) => Number.isInteger(n) && n > 0))];
  const params = new URLSearchParams();
  if (ids.length) params.set("contactIds", ids.join(","));
  window.location.href = `/email.html${params.toString() ? `?${params.toString()}` : ""}`;
}

async function fetchApiJson(path, init) {
  const response = await fetch(path, init);
  const text = await response.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = {};
  }
  return { response, data };
}

function renderAiResult(title, html, scrollIntoView = false) {
  if (!contactAiResult) return;
  contactAiResult.innerHTML = `<div class="contact-ai-result-card"><strong>${escapeHtml(title)}</strong><div>${html}</div></div>`;
  if (scrollIntoView) scrollContactAiResultIntoView();
}

function scrollContactAiResultIntoView() {
  if (!contactAiResult) return;
  requestAnimationFrame(() => {
    contactAiResult.scrollIntoView({ behavior: "smooth", block: "start" });
  });
}

function aiListHtml(items) {
  const list = Array.isArray(items) ? items.map((item) => String(item || "").trim()).filter(Boolean) : [];
  if (!list.length) return "";
  return `<ul>${list.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>`;
}

async function refreshActiveContact() {
  if (!activeContact?.id) return;
  const { response, data } = await fetchApiJson(`/api/contacts/${encodeURIComponent(activeContact.id)}`);
  if (response.ok && data) fillForm(data);
}

async function scoreActiveLead() {
  if (!activeContact?.id || !aiLeadScoreBtn) return;
  aiLeadScoreBtn.disabled = true;
  renderAiResult("AI Lead Score", "<p>Scoring this lead...</p>");
  try {
    const { response, data } = await fetchApiJson(`/api/ai/contacts/${encodeURIComponent(activeContact.id)}/score`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({})
    });
    if (!response.ok) throw new Error(data.error || "Could not score lead.");
    if (data.cleared) {
      renderAiResult("AI Lead Score", "<p>This contact is declined, so the AI score was removed.</p>");
    } else {
      renderAiResult(
        "AI Lead Score",
        `<p><strong>${escapeHtml(data.score || "-")}/10</strong> ${escapeHtml(data.reason || "")}</p>${
          data.nextBestAction ? `<p><strong>Next action:</strong> ${escapeHtml(data.nextBestAction)}</p>` : ""
        }`
      );
    }
    await refreshActiveContact();
  } catch (error) {
    renderAiResult("AI Lead Score", `<p class="is-error">${escapeHtml(error.message || "Could not score lead.")}</p>`);
  } finally {
    aiLeadScoreBtn.disabled = false;
  }
}

async function summarizeActiveCall() {
  if (!activeContact?.id || !aiCallSummaryBtn) return;
  const notes = String(aiCallSummaryNotes?.value || "").trim();
  if (!notes) {
    renderAiResult("AI Call Summary", `<p class="is-error">Paste call notes or a transcript first.</p>`, true);
    return;
  }
  aiCallSummaryNotesCommitLock = true;
  cancelAiCallSummaryNotesBlurCommit();
  try {
    await commitAiCallSummaryNotesToContactDetails();
  } catch (error) {
    showMessage(error.message || "Failed to save notes.", true);
    return;
  } finally {
    aiCallSummaryNotesCommitLock = false;
  }
  aiCallSummaryBtn.disabled = true;
  renderAiResult("AI Call Summary", "<p>Summarizing the call...</p>", true);
  try {
    const { response, data } = await fetchApiJson(`/api/ai/contacts/${encodeURIComponent(activeContact.id)}/call-summary`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ notes })
    });
    if (!response.ok) throw new Error(data.error || "Could not summarize call.");
    renderAiResult(
      "AI Call Summary",
      `<p>${escapeHtml(data.summary || "Summary created.")}</p>${aiListHtml(data.discussed)}${
        data.nextSteps?.length ? `<p><strong>Next steps</strong></p>${aiListHtml(data.nextSteps)}` : ""
      }${data.followUpDate ? `<p><strong>Follow up:</strong> ${escapeHtml(data.followUpDate)}</p>` : ""}`,
      true
    );
    aiCallSummaryNotes.value = "";
    aiCallSummaryNotesLastCommittedDraft = "";
    await loadHistory();
  } catch (error) {
    renderAiResult("AI Call Summary", `<p class="is-error">${escapeHtml(error.message || "Could not summarize call.")}</p>`, true);
  } finally {
    aiCallSummaryBtn.disabled = false;
  }
}

async function coachActiveObjection() {
  if (!activeContact?.id || !aiObjectionCoachBtn) return;
  const objection = String(aiObjectionInput?.value || "").trim();
  if (!objection) {
    renderAiResult("AI Objection Coach", `<p class="is-error">Enter the client's objection first.</p>`, true);
    return;
  }
  aiObjectionCoachBtn.disabled = true;
  renderAiResult("AI Objection Coach", "<p>Preparing coaching...</p>", true);
  try {
    const { response, data } = await fetchApiJson(`/api/ai/contacts/${encodeURIComponent(activeContact.id)}/objection-coach`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ objection })
    });
    if (!response.ok) throw new Error(data.error || "Could not coach objection.");
    renderAiResult(
      "AI Objection Coach",
      `${aiListHtml(data.rebuttals)}${
        data.bestQuestion ? `<p><strong>Best question:</strong> ${escapeHtml(data.bestQuestion)}</p>` : ""
      }${data.complianceNote ? `<p><strong>Compliance note:</strong> ${escapeHtml(data.complianceNote)}</p>` : ""}`,
      true
    );
    await loadHistory();
  } catch (error) {
    renderAiResult("AI Objection Coach", `<p class="is-error">${escapeHtml(error.message || "Could not coach objection.")}</p>`, true);
  } finally {
    aiObjectionCoachBtn.disabled = false;
  }
}

async function transcribeRecording(recordingSid, buttonEl) {
  if (!activeContact?.id || !recordingSid) return;
  if (buttonEl) {
    buttonEl.disabled = true;
    buttonEl.textContent = "Transcribing...";
  }
  renderAiResult("Whisper Transcription", "<p>Transcribing the recording...</p>");
  try {
    const { response, data } = await fetchApiJson(
      `/api/ai/contacts/${encodeURIComponent(activeContact.id)}/recordings/${encodeURIComponent(recordingSid)}/transcribe`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({})
      }
    );
    if (!response.ok) throw new Error(data.error || "Could not transcribe recording.");
    if (aiCallSummaryNotes) aiCallSummaryNotes.value = data.transcript || "";
    renderAiResult(
      "Whisper Transcription",
      `<p>Transcript created. Summarizing the call now...</p>`
    );
    await summarizeActiveCall();
    await loadSummaryCallRecordings();
  } catch (error) {
    renderAiResult("Whisper Transcription", `<p class="is-error">${escapeHtml(error.message || "Could not transcribe recording.")}</p>`);
  } finally {
    if (buttonEl) {
      buttonEl.disabled = false;
      buttonEl.textContent = "Transcribe with AI";
    }
  }
}

function parseContactCustomFieldValuesClient(raw) {
  if (!raw) return {};
  if (typeof raw === "object" && !Array.isArray(raw)) return sanitizeContactCustomFieldMap(raw);
  const text = String(raw).trim();
  if (!text) return {};
  try {
    return sanitizeContactCustomFieldMap(JSON.parse(text));
  } catch {
    return {};
  }
}

function sanitizeContactCustomFieldMap(obj) {
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return {};
  const out = {};
  for (const [key, value] of Object.entries(obj)) {
    const slug = String(key || "")
      .toLowerCase()
      .replace(/[\s-]+/g, "_")
      .replace(/[^a-z0-9_]/g, "")
      .replace(/_+/g, "_")
      .replace(/^_+|_+$/g, "");
    if (!slug) continue;
    out[slug] = String(value == null ? "" : value);
  }
  return out;
}

let contactScopedMergeFieldDefs = [];
const BUILT_IN_CONTACT_MERGE_SLUGS = new Set(["policy_renewal", "policy_renewal_date", "polcy_renewal"]);

function isBuiltInContactMergeField(slug, label) {
  const key = String(slug || "").trim();
  if (!key) return false;
  if (BUILT_IN_CONTACT_MERGE_SLUGS.has(key)) return true;
  const compact = key.replace(/_/g, "");
  if (/^poli?cyrenewal(date)?$/.test(compact)) return true;
  return /policy\s*renewal/i.test(String(label || ""));
}

async function ensureContactScopedMergeFieldDefs() {
  try {
    const { response, data } = await fetchApiJson("/api/custom-merge-fields");
    if (!response.ok || !Array.isArray(data)) {
      contactScopedMergeFieldDefs = [];
      return;
    }
    contactScopedMergeFieldDefs = data.filter(
      (row) => String(row?.field_scope || "").toLowerCase() === "contact"
    );
  } catch {
    contactScopedMergeFieldDefs = [];
  }
}

function renderContactCustomMergeFields(contact) {
  const host = document.getElementById("contactCustomMergeFieldsGrid");
  const panel = document.getElementById("cd-panel-custom-fields");
  if (!host) return;
  const visibleDefs = contactScopedMergeFieldDefs.filter((def) => {
    const slug = String(def.field_key || "")
      .toLowerCase()
      .replace(/[\s-]+/g, "_")
      .replace(/[^a-z0-9_]/g, "")
      .replace(/_+/g, "_")
      .replace(/^_+|_+$/g, "");
    return slug && !isBuiltInContactMergeField(slug, def.label);
  });
  if (!visibleDefs.length) {
    if (panel) panel.hidden = true;
    host.innerHTML = "";
    return;
  }
  if (panel) panel.hidden = false;
  const values = parseContactCustomFieldValuesClient(contact?.custom_fields);
  host.innerHTML = visibleDefs
    .map((def) => {
      const slug = String(def.field_key || "")
        .toLowerCase()
        .replace(/[\s-]+/g, "_")
        .replace(/[^a-z0-9_]/g, "")
        .replace(/_+/g, "_")
        .replace(/^_+|_+$/g, "");
      if (!slug) return "";
      const label = String(def.label || slug).trim() || slug;
      const val = escapeHtml(values[slug] || "");
      return `
        <div class="contact-field-box">
          <label class="contact-modal-field-label" for="custom_field_${escapeHtml(slug)}">${escapeHtml(label)}</label>
          <input id="custom_field_${escapeHtml(slug)}" type="text" data-custom-merge-key="${escapeHtml(slug)}" value="${val}" />
          <p class="hint">{{${escapeHtml(slug)}}}</p>
        </div>
      `;
    })
    .join("");
}

async function refreshContactCustomMergeFields(contact) {
  const snapshotId = Number(contact?.id || 0);
  await ensureContactScopedMergeFieldDefs();
  if (Number(activeContact?.id || 0) !== snapshotId) return;
  renderContactCustomMergeFields(contact);
}

function collectContactCustomFieldValues() {
  const out = {};
  document.querySelectorAll("[data-custom-merge-key]").forEach((el) => {
    const slug = String(el.getAttribute("data-custom-merge-key") || "").trim();
    if (!slug || isBuiltInContactMergeField(slug)) return;
    out[slug] = String(el.value || "");
  });
  return out;
}

function contactPageFormEl() {
  return form || document.getElementById("contactPageForm");
}

function namedFormControl(name) {
  const pageForm = contactPageFormEl();
  if (!pageForm) return document.getElementById(name);
  let el = null;
  try {
    el = pageForm.elements ? pageForm.elements.namedItem(name) || pageForm.elements[name] : null;
  } catch {
    el = null;
  }
  if (el && typeof RadioNodeList !== "undefined" && el instanceof RadioNodeList) {
    el = el[0] || null;
  }
  return el || pageForm.querySelector(`[name="${String(name)}"]`) || document.getElementById(name);
}

function toDateInputValue(raw) {
  const s = String(raw || "").trim();
  if (!s) return "";
  let m = /^(\d{4})-(\d{1,2})-(\d{1,2})/.exec(s);
  if (m) {
    return `${m[1]}-${String(Number(m[2])).padStart(2, "0")}-${String(Number(m[3])).padStart(2, "0")}`;
  }
  m = /^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})$/.exec(s);
  if (m) {
    return `${m[3]}-${String(Number(m[1])).padStart(2, "0")}-${String(Number(m[2])).padStart(2, "0")}`;
  }
  return "";
}

function firstCustomFieldValue(contact, slugs) {
  const values = parseContactCustomFieldValuesClient(contact?.custom_fields);
  for (const slug of slugs) {
    const v = String(values[slug] || "").trim();
    if (v) return v;
  }
  return "";
}

function setNamedFormValue(name, value) {
  const el = namedFormControl(name);
  if (!el || typeof el.value === "undefined") return;
  el.value = value == null ? "" : value;
}

function splitStoredContactName(contact) {
  const fullName = String(contact?.full_name || "").trim();
  const middle = String(contact?.middle_name || "").trim();
  const parts = fullName.split(/\s+/).filter(Boolean);
  const first = parts.length ? parts[0] : "";
  let rest = parts.slice(1);
  if (middle) {
    const midParts = middle.split(/\s+/).filter(Boolean);
    const head = rest.slice(0, midParts.length).join(" ");
    if (head.toLowerCase() === middle.toLowerCase()) rest = rest.slice(midParts.length);
  }
  return { fullName, first, middle, last: rest.join(" ") };
}

function joinContactName(first, middle, last) {
  return [first, middle, last].map((part) => String(part || "").trim()).filter(Boolean).join(" ");
}

function fillForm(contact) {
  resetAiCallSummaryNotesSync(contact);
  activeContact = contact;
  const storedName = splitStoredContactName(contact);
  const fullName = storedName.fullName;
  const first = storedName.first;
  const middle = storedName.middle;
  const last = storedName.last;
  const pageForm = contactPageFormEl();
  if (pageForm && pageForm.elements) {
    try {
    setNamedFormValue("id", String(contact.id || ""));
    setNamedFormValue("full_name", fullName);
    setNamedFormValue("first_name", first);
    setNamedFormValue("middle_name", middle);
    setNamedFormValue("last_name", last);
    setNamedFormValue("email", contact.email || "");
    setNamedFormValue(
      "primary_phone",
      isUsContactPhone(contact.phone || "") ? formatUsContactPhoneDisplay(contact.phone) : contact.phone || ""
    );
    setNamedFormValue(
      "secondary_phone",
      isUsContactPhone(contact.secondary_phone || "")
        ? formatUsContactPhoneDisplay(contact.secondary_phone)
        : contact.secondary_phone || ""
    );
    setNamedFormValue("age", contact.age || "");
    setNamedFormValue("gender", contact.gender || "");
    if (namedFormControl("indian")) setNamedFormValue("indian", contact.indian || "");
    setNamedFormValue("household_size", contact.household_size || "");
    setNamedFormValue("income", formatIncomeValue(contact.income || ""));
    setNamedFormValue("communication_type", contact.communication_type || "");
    if (namedFormControl("created_at")) {
      setNamedFormValue("created_at", formatCreatedAtDisplay(contact.created_at));
    }
    if (namedFormControl("app_id")) setNamedFormValue("app_id", contact.app_id || "");
    const doNotEmailEl = namedFormControl("do_not_email");
    if (doNotEmailEl && "checked" in doNotEmailEl) {
      doNotEmailEl.checked = String(contact.do_not_email || "") === "1";
    }
    setNamedFormValue("date_of_contact", toDateInputValue(contact.date_of_contact || ""));
    if (window.CrmContactWorkspaceOptions?.applyContactPageForm) {
      window.CrmContactWorkspaceOptions.applyContactPageForm(document, contact);
    } else {
      setNamedFormValue("lead_source", contact.lead_source || "");
      setNamedFormValue("outcome", contact.outcome || "");
      setNamedFormValue("status", contact.status || "NEW");
    }
    setNamedFormValue("date_of_birth", toDateInputValue(contact.date_of_birth || ""));
    setNamedFormValue("coverages_sold", contact.coverages_sold || "");
    setNamedFormValue("profession", contact.profession || "");
    if (namedFormControl("height")) setNamedFormValue("height", contact.height || "");
    if (namedFormControl("weight")) setNamedFormValue("weight", contact.weight || "");
    setNamedFormValue("quote", formatCommissionValue(contact.quote || ""));
    setNamedFormValue("health_issues", contact.health_issues || "");
    setNamedFormValue("coverage_start_date", toDateInputValue(contact.coverage_start_date || ""));
    if (namedFormControl("policy_renewal")) {
      setNamedFormValue(
        "policy_renewal",
        toDateInputValue(
          contact.policy_renewal ||
            firstCustomFieldValue(contact, ["policy_renewal", "policy_renewal_date", "polcy_renewal"])
        )
      );
    }
    if (namedFormControl("renewal_interval")) {
      const interval = String(contact.renewal_interval || "").trim();
      setNamedFormValue(
        "renewal_interval",
        interval === "3" || interval === "6" || interval === "12"
          ? interval
          : String(contact.annual_renewal || "") === "1"
            ? "12"
            : ""
      );
    }
    if (namedFormControl("bank_routing")) setNamedFormValue("bank_routing", contact.bank_routing || "");
    if (namedFormControl("bank_account")) setNamedFormValue("bank_account", contact.bank_account || "");
    if (namedFormControl("ssn_last4")) setNamedFormValue("ssn_last4", contact.ssn_last4 || "");
    if (typeof window.crmHidePasswordInput === "function") {
      if (namedFormControl("bank_routing")) window.crmHidePasswordInput(namedFormControl("bank_routing"));
      if (namedFormControl("bank_account")) window.crmHidePasswordInput(namedFormControl("bank_account"));
      if (namedFormControl("ssn_last4")) window.crmHidePasswordInput(namedFormControl("ssn_last4"));
    }
    setNamedFormValue("vcall", contact.vcall || "");
    if (namedFormControl("insurance_type")) setNamedFormValue("insurance_type", contact.insurance_type || "");
    setNamedFormValue("commission", formatCommissionValue(contact.commission || ""));
    setNamedFormValue("home_address", contact.home_address || "");
    setNamedFormValue("city", contact.city || "");
    setNamedFormValue("state", contact.state || "");
    setNamedFormValue("zip_code", contact.zip_code || "");
    setNamedFormValue("tags", contact.tags || "");
    if (document.activeElement === aiCallSummaryNotes) {
      previewAiCallSummaryNotesInContactDetails();
    } else {
      setNamedFormValue("notes", normalizeCallbackNotes(contact.notes || ""));
    }
    setNamedFormValue("special_notes", contact.special_notes || "");
    if (namedFormControl("follow_up_date")) setNamedFormValue("follow_up_date", contact.follow_up_date || "");
    if (namedFormControl("follow_up_time")) setNamedFormValue("follow_up_time", contact.follow_up_time || "");
    householdMembers = parseContactJsonArray(contact.household_members).map(normalizeHouseholdMemberRecord);
    contactQuotes = parseContactJsonArray(contact.quotes).map(normalizeContactQuoteRecord);
    renderHouseholdMembers();
    renderContactQuotes();
    } catch (err) {
      console.error("fillForm fields:", err);
    }
  }
  const activeCampaignCount = Number(contact.active_campaign_count || 0);
  const dripPendingCount = Number(contact.drip_pending_count || 0);
  const dripCompletedCampaignCount = Number(contact.drip_completed_campaign_count || 0);
  const enrolledWrap = document.getElementById("contactSummaryEnrolledWrap");
  const enrolledBadge = document.getElementById("contactSummaryEnrolledBadge");
  if (enrolledBadge) {
    enrolledBadge.className = "contact-enrolled-badge";
    let badgeText = "";
    if (activeCampaignCount > 0) {
      if (dripPendingCount > 0) {
        enrolledBadge.classList.add("contact-enrolled-badge--live");
        badgeText =
          activeCampaignCount > 1 ? `Enrolled Live (${activeCampaignCount})` : "Enrolled Live";
      }
    } else if (dripCompletedCampaignCount > 0) {
      enrolledBadge.classList.add("contact-enrolled-badge--completed");
      badgeText =
        dripCompletedCampaignCount > 1
          ? `Drip Completed (${dripCompletedCampaignCount})`
          : "Drip Completed";
    }
    enrolledBadge.textContent = badgeText;
    if (enrolledWrap) enrolledWrap.style.display = badgeText ? "" : "none";
  } else if (enrolledWrap) {
    enrolledWrap.style.display = "none";
  }
  setSummaryValue("contactSummaryName", fullName);
  setSummaryValue("contactSummaryInitials", getContactInitials(fullName));
  setSummaryValue("contactSummaryAge", contact.age || "");
  const scoreRow = document.getElementById("contactSummaryScoreRow");
  if (scoreRow) scoreRow.innerHTML = aiScorePillHtml(contact.ai_lead_score, contact.ai_lead_reason);
  applySummaryAiScorePriority(contact.ai_lead_score);
  renderContactUrgencyAlert(contact);
  setSummaryMailto("contactSummaryEmail", contact.email || "");
  setSummaryTel("contactSummaryPhonePrimary", contact.phone || "");
  setSummaryTel("contactSummaryPhoneSecondary", contact.secondary_phone || "");
  setSummaryHtml("contactSummaryStatus", summaryStatusPillHtml(contact.status || ""));
  applySummaryInitialsStatus(contact.status || "");
  setSummaryHtml("contactSummaryOutcome", summaryOutcomePillHtml(contact.outcome || ""));
  setSummaryValue("contactSummaryCreatedAt", formatCreatedAtDisplay(contact.created_at));
  setSummaryValue("contactSummaryAppId", contact.app_id || "");
  setSummaryValue("contactSummaryQuote", formatCommissionValue(contact.quote || ""));
  setSummaryValue("contactSummaryState", contact.state || "");
  setSummaryValue("contactSummaryZipCode", contact.zip_code || "");
  setSummaryHtml("contactSummaryLeadSource", summaryLeadSourcePillHtml(contact.lead_source || ""));
  setSummaryValue("contactSummaryAiLeadScore", contact.ai_lead_score ? `${contact.ai_lead_score}/10` : "");
  setSummaryValue("contactSummaryCommunicationType", contact.communication_type || "");
  setSummaryValue("contactSummaryHouseholdSize", contact.household_size || "");
  setSummaryValue("contactSummaryGender", contact.gender || "");
  setSummaryTags(contact.tags || "");
  setSummaryMultilineValue("contactSummaryAiLeadReason", contact.ai_lead_reason || "");
  setSummaryCallbackNotesValue("contactSummaryNotes", contact.notes || "");
  setSummaryMultilineValue("contactSummarySpecialNotes", contact.special_notes || "");
  if (isFullDetailsMode) {
    ["email", "primary_phone", "secondary_phone", "zip_code", "date_of_birth"].forEach((id) =>
      validateContactField(document.getElementById(id))
    );
  }
  void refreshContactCustomMergeFields(contact);
}

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/** For embedding strings in double-quoted HTML attributes (e.g. iframe srcdoc). */
function escapeHtmlAttr(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

/** Detects filled background on common marketing-email banner cells. */
function looksLikeHeadingBarCell(styleAttr, bgcolor) {
  const bg = String(bgcolor || "").trim();
  if (bg.length >= 2 && bg.toLowerCase() !== "#ffffff" && bg.toLowerCase() !== "ffffff") return true;
  const st = String(styleAttr || "").toLowerCase();
  return /background(?:-color)?\s*:\s*(?!none|transparent|#fff(?:fff)?\b|#ffffff\b|white\b)/i.test(st);
}

function wrapEmailHeadingRowInTable(doc, row) {
  const table = doc.createElement("table");
  table.setAttribute("width", "100%");
  table.setAttribute("cellpadding", "0");
  table.setAttribute("cellspacing", "0");
  table.style.borderCollapse = "collapse";
  table.style.margin = "0";
  const tbody = doc.createElement("tbody");
  tbody.appendChild(row.cloneNode(true));
  table.appendChild(tbody);
  return table.outerHTML;
}

/**
 * Extracts the top visual heading/banner block (e.g. solid title bar) from sent HTML for the history preview.
 */
function extractEmailHeadingBarHtml(htmlBody) {
  const raw = String(htmlBody || "").trim();
  if (!raw) return "";
  try {
    const doc = new DOMParser().parseFromString(raw, "text/html");
    const body = doc.body;
    if (!body) return "";

    const first = body.firstElementChild;
    if (first && first.tagName === "DIV") {
      const st = (first.getAttribute("style") || "").toLowerCase();
      const txt = String(first.textContent || "").trim();
      if (txt.length > 0 && txt.length <= 200 && looksLikeHeadingBarCell(st, "")) {
        return first.outerHTML;
      }
    }

    let n = 0;
    for (const row of body.querySelectorAll("tr")) {
      if (++n > 50) break;
      for (const cell of row.cells) {
        const st = (cell.getAttribute("style") || "").toLowerCase();
        const bgc = (cell.getAttribute("bgcolor") || "").trim();
        const txt = String(cell.textContent || "").trim();
        if (txt.length === 0 || txt.length > 220) continue;
        if (looksLikeHeadingBarCell(st, bgc)) return wrapEmailHeadingRowInTable(doc, row);
      }
    }

    const t0 = body.querySelector("table");
    const r0 = t0?.rows?.[0];
    if (r0) {
      const txt = String(r0.textContent || "").trim();
      if (txt.length > 0 && txt.length <= 180 && r0.cells.length <= 3) {
        return wrapEmailHeadingRowInTable(doc, r0);
      }
    }
  } catch (_) {
    /* ignore */
  }
  return "";
}

function buildEmailHeadingSrcdoc(headingFragmentHtml) {
  const inner = String(headingFragmentHtml || "").trim();
  if (!inner) return "";
  return `<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;padding:0;background:#fff;}body{font-family:system-ui,Segoe UI,Arial,sans-serif;font-size:15px;line-height:1.45;color:#111827;}table{max-width:100%;border-collapse:collapse;width:100%;}img{max-width:100%;height:auto;}</style></head><body>${inner}</body></html>`;
}

function emailHistoryCardTitle(subject, htmlBody, fallback = "Sent Email") {
  const subj = String(subject || "").trim();
  if (subj && subj !== "(no subject)") return subj;
  const headingText = String(extractEmailHeadingBarHtml(htmlBody) || "")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (headingText) return headingText.slice(0, 160);
  return fallback;
}

function emailHistoryHeadingIframeHtml(htmlBody) {
  const headingSrcdoc = buildEmailHeadingSrcdoc(extractEmailHeadingBarHtml(htmlBody));
  if (!headingSrcdoc) return "";
  return `<iframe class="contact-history-email-heading-preview-iframe" title="Email heading preview" srcdoc="${escapeHtmlAttr(
    headingSrcdoc
  )}"></iframe>`;
}

function initHistoryEmailHeadingIframes(container) {
  if (!container || !container.querySelectorAll) return;
  container.querySelectorAll("iframe.contact-history-email-heading-preview-iframe:not([data-heading-frame-wired])").forEach((frame) => {
    frame.setAttribute("data-heading-frame-wired", "1");
    const resize = () => {
      try {
        const h = frame.contentDocument?.body?.scrollHeight;
        if (Number.isFinite(h) && h > 0) {
          frame.style.height = `${Math.min(200, Math.max(32, h + 6))}px`;
        }
      } catch (_) {
        /* cross-origin or blocked */
      }
    };
    frame.addEventListener("load", resize);
    queueMicrotask(resize);
  });
}

function setContactHistoryCount(count, hasMore = false) {
  historyVisibleCount = Math.max(0, Number(count || 0));
  if (!contactHistoryCount) return;
  const suffix = historyVisibleCount === 1 ? "event" : "events";
  contactHistoryCount.textContent = `${historyVisibleCount}${hasMore ? "+" : ""} ${suffix}`;
}

function compactEmailPreviewText(htmlBody, textBody) {
  const text = String(textBody || "").trim();
  if (text) return text.replace(/\s+/g, " ").trim().slice(0, 180);
  const html = String(htmlBody || "").trim();
  if (!html) return "";
  const withoutTags = html
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/\s+/g, " ")
    .trim();
  return withoutTags.slice(0, 180);
}

/** Same document wrapper as the full-email modal; optional preview mode clips height. */
function buildEmailIframeSrcdoc(htmlBody, textBody, options = {}) {
  const preview = Boolean(options.preview);
  const html = String(htmlBody || "").trim();
  const text = String(textBody || "").trim();
  const renderedBody = html
    ? html
    : escapeHtml(text || "(empty body)").replace(/\r?\n/g, "<br>");
  const pad = preview ? "5px 6px" : "10px";
  const previewClip = preview ? "body{overflow:hidden;max-height:3.6em;}" : "";
  return `<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;padding:0;background:#fff;}body{font-family:system-ui,Segoe UI,Arial,sans-serif;font-size:14px;line-height:1.45;color:#111827;padding:${pad};}${previewClip}img{max-width:100%;height:auto;}table{max-width:100%;}</style></head><body>${renderedBody}</body></html>`;
}

function toReadableDateTime(value) {
  const d = parseStoredTimestamp(value);
  if (!d) return String(value == null ? "" : value).trim();
  try {
    return d.toLocaleString(undefined, {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit"
    });
  } catch {
    return d.toLocaleString();
  }
}

function normalizeEmailSubjectKey(subject) {
  return String(subject || "").trim().toLowerCase();
}

function getEmailOpenBadgeHtml(subjectValue) {
  const openedAt = contactEmailOpensBySubject.get(normalizeEmailSubjectKey(subjectValue));
  if (!openedAt) return "";
  const when = new Date(openedAt * 1000).toLocaleString();
  return `<span class="contact-history-email-opened-badge" title="Opened ${escapeHtml(when)}">Opened ✓</span>`;
}

function applyContactEmailOpensFromHistoryPayload(data) {
  contactEmailOpensBySubject.clear();
  const opensMap = data?.emailOpensBySubject && typeof data.emailOpensBySubject === "object" ? data.emailOpensBySubject : {};
  for (const [subject, openedAt] of Object.entries(opensMap)) {
    const key = normalizeEmailSubjectKey(subject);
    if (!key) continue;
    contactEmailOpensBySubject.set(key, Number(openedAt));
  }
}

function formatTaskDateTime(taskDate, taskTime) {
  const d = String(taskDate || "").trim();
  const t = String(taskTime || "").trim();
  if (!d && !t) return "No schedule";
  if (d && !t) {
    const parsed = new Date(d);
    return Number.isFinite(parsed.getTime()) ? parsed.toLocaleDateString() : d;
  }
  if (!d && t) return t;
  const parsed = new Date(`${d}T${t}`);
  return Number.isFinite(parsed.getTime()) ? parsed.toLocaleString() : `${d} ${t}`;
}

function formatDateMmDdYyyy(value) {
  const raw = String(value == null ? "" : value).trim();
  if (!raw) return "";
  const isoMatch = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (isoMatch) return `${isoMatch[2]}/${isoMatch[3]}/${isoMatch[1]}`;
  const parsed = new Date(raw);
  if (!Number.isFinite(parsed.getTime())) return raw;
  const mm = String(parsed.getMonth() + 1).padStart(2, "0");
  const dd = String(parsed.getDate()).padStart(2, "0");
  const yyyy = String(parsed.getFullYear());
  return `${mm}/${dd}/${yyyy}`;
}

function isHistoryPinned(item) {
  return Number(item?.is_pinned || 0) === 1;
}

function isHistoryStarred(item) {
  return Number(item?.is_starred || 0) === 1;
}

function closeHistoryActionMenu() {
  if (!contactHistoryActionMenu) return;
  contactHistoryActionMenu.classList.add("hidden");
  contactHistoryActionMenu.setAttribute("aria-hidden", "true");
  activeHistoryItemId = 0;
}

function stashHistoryEmailPayload(historyId, payload) {
  if (!Number.isInteger(historyId) || historyId < 1) return;
  historyEmailPayloadById.set(historyId, payload);
}

function historyCardHasOpenableEmail(historyId) {
  return Number.isInteger(historyId) && historyId > 0 && historyEmailPayloadById.has(historyId);
}

function tryOpenHistoryEmailCard(card) {
  if (!card) return false;
  const historyId = Number(card.getAttribute("data-history-id"));
  const payload = historyCardHasOpenableEmail(historyId) ? historyEmailPayloadById.get(historyId) : null;
  if (!payload) return false;
  closeHistoryActionMenu();
  openContactHistoryEmailModal(payload);
  return true;
}

function activateHistoryCard(card, options = {}) {
  if (!card) return;
  if (!options.forceActionsMenu && tryOpenHistoryEmailCard(card)) return;
  const item = {
    id: Number(card.getAttribute("data-history-id")),
    is_pinned: Number(card.getAttribute("data-pinned") || 0),
    is_starred: Number(card.getAttribute("data-starred") || 0)
  };
  if (activeHistoryItemId === item.id && contactHistoryActionMenu && !contactHistoryActionMenu.classList.contains("hidden")) {
    closeHistoryActionMenu();
    return;
  }
  closeHistoryActionMenu();
  openHistoryActionMenu(card, item);
}

function openHistoryActionMenu(cardEl, item) {
  if (!contactHistoryActionMenu || !contactHistoryActionPinBtn || !contactHistoryActionStarBtn || !contactHistoryActionDeleteBtn) return;
  const historyId = Number(item?.id);
  if (!Number.isInteger(historyId) || historyId < 1) return;
  const rect = cardEl.getBoundingClientRect();
  const top = rect.top + window.scrollY + 28;
  const left = rect.right + window.scrollX - 170;
  contactHistoryActionMenu.style.top = `${Math.max(8, top)}px`;
  contactHistoryActionMenu.style.left = `${Math.max(8, left)}px`;
  contactHistoryActionPinBtn.textContent = isHistoryPinned(item) ? "Unpin" : "Pin";
  contactHistoryActionStarBtn.textContent = isHistoryStarred(item) ? "Unstar" : "Star";
  contactHistoryActionDeleteBtn.textContent = "Delete";
  activeHistoryItemId = historyId;
  contactHistoryActionMenu.classList.remove("hidden");
  contactHistoryActionMenu.setAttribute("aria-hidden", "false");
}

async function updateHistoryItem(historyId, patch) {
  if (!activeContact?.id) throw new Error("Contact not loaded");
  const safeId = Number(historyId);
  if (!Number.isInteger(safeId) || safeId < 1) throw new Error("Invalid history id");
  const { response, data } = await fetchApiJson(`/api/contacts/${activeContact.id}/history/${safeId}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(patch || {})
  });
  if (!response.ok) throw new Error(data.error || "Failed to update history item");
  return data;
}

async function deleteHistoryItem(historyId) {
  if (!activeContact?.id) throw new Error("Contact not loaded");
  const safeId = Number(historyId);
  if (!Number.isInteger(safeId) || safeId < 1) throw new Error("Invalid history id");
  const { response, data } = await fetchApiJson(`/api/contacts/${activeContact.id}/history/${safeId}`, {
    method: "DELETE"
  });
  if (!response.ok) throw new Error(data.error || "Failed to delete history item");
}

function describeTwilioRestCallStatus(data) {
  const status = String(data?.status || "").trim().toLowerCase();
  const duration = Number(data?.duration) || 0;
  const errorDetail = String(data?.errorMessage || "").trim();
  if (status === "queued") return { label: "Dialing...", terminal: false, isError: false };
  if (status === "ringing") return { label: "Ringing the contact...", terminal: false, isError: false };
  if (status === "in-progress" && String(data?.bridgeStatus || "") === "ringing-contact") {
    return { label: "Ringing the contact...", terminal: false, isError: false };
  }
  if (status === "in-progress") return { label: "On call", terminal: false, isError: false };
  if (status === "busy") return { label: "Line busy.", terminal: true, isError: true };
  if (status === "no-answer") return { label: "No answer.", terminal: true, isError: false };
  if (status === "failed") {
    const base = "Call failed.";
    const hint = errorDetail
      ? errorDetail.slice(0, 180)
      : "Check the phone number and your Twilio account (trial accounts can only call verified numbers).";
    return { label: `${base} ${hint}`.trim(), terminal: true, isError: true };
  }
  if (status === "canceled" || status === "cancelled") {
    return { label: "Call canceled.", terminal: true, isError: false };
  }
  if (status === "completed" || status === "complete") {
    return {
      label: "Call ended.",
      terminal: true,
      isError: false
    };
  }
  return { label: "", terminal: false, isError: false };
}

function isActiveTwilioCallStatusLabel(normalized) {
  return (
    normalized === "on call" ||
    normalized.startsWith("on call ·") ||
    normalized === "dialing..." ||
    normalized === "ringing..." ||
    normalized.startsWith("ringing your phone") ||
    normalized.startsWith("you answered") ||
    normalized === "connecting..." ||
    normalized === "starting call..."
  );
}

function setContactTwilioCallStatus(text, isError = false) {
  if (!contactTwilioCallStatus) return;
  const statusText = String(text || "");
  const normalized = statusText.trim().toLowerCase();
  contactTwilioCallStatus.textContent = statusText;
  contactTwilioCallStatus.classList.toggle("is-error", !!isError);
  contactTwilioCallStatus.classList.toggle("is-success", !isError && isActiveTwilioCallStatusLabel(normalized));
  contactTwilioCallStatus.classList.toggle("align-right", true);
  contactTwilioCallStatus.classList.remove("align-left");
}

function finalizeContactTwilioCallUi(message = "") {
  stopContactTwilioCallStatusPolling();
  activeContactTwilioCallMode = "";
  setContactTwilioCallStatus(message, false);
}

function clearContactTwilioCallPhoneInput() {
  if (contactTwilioCallForm && contactTwilioCallForm.elements.phone) {
    contactTwilioCallForm.elements.phone.value = "";
  }
}

function stopContactTwilioCallStatusPolling() {
  if (contactTwilioCallStatusPollTimer) {
    clearInterval(contactTwilioCallStatusPollTimer);
    contactTwilioCallStatusPollTimer = null;
  }
  activeContactTwilioCallSid = "";
  activeContactTwilioCallMode = "";
}

function startContactTwilioCallStatusPolling(callSid) {
  stopContactTwilioCallStatusPolling();
  activeContactTwilioCallSid = String(callSid || "").trim();
  if (!activeContactTwilioCallSid) return;
  activeContactTwilioCallMode = "rest";
  setContactTwilioCallStatus("Dialing...");
  const pollOnce = async () => {
    if (!activeContactTwilioCallSid) return;
    try {
      const { response, data } = await fetchApiJson(
        `/api/twilio/call-status/${encodeURIComponent(activeContactTwilioCallSid)}`
      );
      if (!response.ok) return;
      const info = describeTwilioRestCallStatus(data);
      if (info.label) setContactTwilioCallStatus(info.label, info.isError);
      if (info.terminal) {
        const endedSid = activeContactTwilioCallSid;
        if (info.isError) showMessage(info.label, true);
        stopContactTwilioCallStatusPolling();
        if (!info.isError) clearContactTwilioCallPhoneInput();
        scheduleRecordingSync({
          callSid: endedSid,
          phone: String(activeContact?.phone || "").trim()
        });
        await loadHistory();
      }
    } catch {
      // Keep polling quietly; transient errors should not block the UI.
    }
  };
  pollOnce();
  contactTwilioCallStatusPollTimer = setInterval(pollOnce, 2000);
}

function openContactTwilioCallModal() {
  if (!contactTwilioCallModal) return;
  const callInProgress = !!(String(activeContactTwilioCallSid || "").trim() || activeContactTwilioCallMode);
  if (!callInProgress) {
    stopContactTwilioCallStatusPolling();
    setContactTwilioCallStatus("");
  } else {
    setContactTwilioCallStatus("On Call");
  }
  if (contactTwilioCallForm && contactTwilioCallForm.elements.contactName) {
    const fullName = String(activeContact?.full_name || "").trim();
    const parts = fullName.split(/\s+/).filter(Boolean);
    const first = parts.length ? parts[0] : "";
    const last = parts.length > 1 ? parts.slice(1).join(" ") : "";
    contactTwilioCallForm.elements.contactName.value = `${first} ${last}`.trim();
  }
  if (contactTwilioCallForm && contactTwilioCallForm.elements.phone) {
    contactTwilioCallForm.elements.phone.value = String(activeContact?.phone || "").trim();
  }
  const mainFrom = document.getElementById("contactTwilioFromSelect");
  const summaryFrom = document.getElementById("contactSummaryTwilioFromSelect");
  const callFrom = document.getElementById("contactTwilioCallFrom");
  const activeFrom = getActiveTwilioFromSelect();
  if (activeFrom && callFrom && window.mirrorTwilioFromSelect) {
    window.mirrorTwilioFromSelect(activeFrom, callFrom);
  } else if (mainFrom && callFrom && window.mirrorTwilioFromSelect) {
    window.mirrorTwilioFromSelect(mainFrom, callFrom);
  } else if (summaryFrom && callFrom && window.mirrorTwilioFromSelect) {
    window.mirrorTwilioFromSelect(summaryFrom, callFrom);
  }
  contactTwilioCallModal.classList.remove("hidden");
  contactTwilioCallModal.setAttribute("aria-hidden", "false");
  // Do NOT prewarm (acquire mic / register device) on open — that makes the
  // browser show the red "microphone in use" tab indicator before any call.
  // The mic is acquired when the user actually starts the call (connectCall).
  refreshContactTwilioHeadsetUi().catch(() => {});
}

function closeContactTwilioCallModal() {
  if (!contactTwilioCallModal) return;
  contactTwilioCallModal.classList.add("hidden");
  contactTwilioCallModal.setAttribute("aria-hidden", "true");
  stopContactTwilioCallStatusPolling();
}

function setContactTwilioSmsStatus(text, isError = false) {
  if (!contactTwilioSmsStatus) return;
  const statusText = String(text || "");
  contactTwilioSmsStatus.textContent = statusText;
  const isSuccess = statusText.trim().toLowerCase() === "messaged sent";
  contactTwilioSmsStatus.classList.toggle("is-error", !!isError);
  contactTwilioSmsStatus.classList.toggle("is-success", !isError && isSuccess);
  contactTwilioSmsStatus.classList.toggle("align-left", isSuccess);
  contactTwilioSmsStatus.classList.toggle("align-right", !isSuccess);
}

function openContactTwilioSmsModal() {
  if (!contactTwilioSmsModal) return;
  setContactTwilioSmsStatus("");
  if (contactTwilioSmsForm && contactTwilioSmsForm.elements.contactName) {
    const fullName = String(activeContact?.full_name || "").trim();
    const parts = fullName.split(/\s+/).filter(Boolean);
    const first = parts.length ? parts[0] : "";
    const last = parts.length > 1 ? parts.slice(1).join(" ") : "";
    contactTwilioSmsForm.elements.contactName.value = `${first} ${last}`.trim();
  }
  if (contactTwilioSmsForm && contactTwilioSmsForm.elements.phone) {
    contactTwilioSmsForm.elements.phone.value = String(activeContact?.phone || "").trim();
  }
  const mainFrom = document.getElementById("contactTwilioFromSelect");
  const summaryFrom = document.getElementById("contactSummaryTwilioFromSelect");
  const smsFrom = document.getElementById("contactTwilioSmsFrom");
  const activeFrom = getActiveTwilioFromSelect();
  if (activeFrom && smsFrom && window.mirrorTwilioFromSelect) {
    window.mirrorTwilioFromSelect(activeFrom, smsFrom);
  } else if (mainFrom && smsFrom && window.mirrorTwilioFromSelect) {
    window.mirrorTwilioFromSelect(mainFrom, smsFrom);
  } else if (summaryFrom && smsFrom && window.mirrorTwilioFromSelect) {
    window.mirrorTwilioFromSelect(summaryFrom, smsFrom);
  }
  contactTwilioSmsModal.classList.remove("hidden");
  contactTwilioSmsModal.setAttribute("aria-hidden", "false");
}

function closeContactTwilioSmsModal() {
  if (!contactTwilioSmsModal) return;
  if (contactTwilioSmsCloseTimer) {
    clearTimeout(contactTwilioSmsCloseTimer);
    contactTwilioSmsCloseTimer = null;
  }
  contactTwilioSmsModal.classList.add("hidden");
  contactTwilioSmsModal.setAttribute("aria-hidden", "true");
}

function closeContactHistoryEmailModal() {
  if (!contactHistoryEmailModal) return;
  contactHistoryEmailModal.classList.add("hidden");
  contactHistoryEmailModal.setAttribute("aria-hidden", "true");
  if (contactHistoryEmailFrame) contactHistoryEmailFrame.removeAttribute("srcdoc");
  if (contactHistoryEmailMeta) contactHistoryEmailMeta.innerHTML = "";
}

function openContactHistoryEmailModal(payload) {
  if (!contactHistoryEmailModal || !contactHistoryEmailFrame || !contactHistoryEmailMeta) return;
  const fromValue = String(payload?.from || "(default sender)");
  const toValue = String(payload?.to || "-");
  const ccValue = String(payload?.cc || "-");
  const subjectValue = String(payload?.subject || "(no subject)");
  const htmlBody = String(payload?.html || "").trim();
  const textBody = String(payload?.text || "").trim();
  contactHistoryEmailMeta.innerHTML = `<div><strong>From:</strong> ${escapeHtml(fromValue)}</div>
    <div><strong>To:</strong> ${escapeHtml(toValue)}</div>
    <div><strong>CC:</strong> ${escapeHtml(ccValue)}</div>
    <div><strong>Subject:</strong> ${escapeHtml(subjectValue)}</div>`;
  contactHistoryEmailFrame.setAttribute("srcdoc", buildEmailIframeSrcdoc(htmlBody, textBody));
  contactHistoryEmailModal.classList.remove("hidden");
  contactHistoryEmailModal.setAttribute("aria-hidden", "false");
}

const HISTORY_TYPE_META = {
  detail_change: { label: "Detail Change", className: "detail-change" },
  sms: { label: "SMS", className: "sms" },
  call: { label: "Call", className: "call" },
  email: { label: "Email", className: "email" },
  campaign: { label: "Campaign", className: "campaign" }
};

function toCssSlug(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

/** One call back note per line (newline-separated). */
function normalizeCallbackNotes(text) {
  return String(text || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .join("\n");
}

function splitCallbackNotesByNewline(text) {
  const normalized = normalizeCallbackNotes(text);
  if (!normalized) return [];
  return normalized.split("\n");
}

function isCallbackNotesFieldName(normalizedField) {
  const f = String(normalizedField || "").trim().toLowerCase();
  return f === "notes" || f === "call back notes";
}

function findLatestNotesHistoryItemId(items) {
  for (const item of items) {
    if (String(item?.activity_type || "").trim().toLowerCase() !== "detail_change") continue;
    const parsed = parseDetailChangeRecord(item?.detail);
    if (!parsed) continue;
    if (!isCallbackNotesFieldName(parsed.fieldName.trim().toLowerCase())) continue;
    return Number(item.id) || 0;
  }
  return 0;
}

/** Line(s) newly added in this notes edit (usually one line). */
function getNotesLinesAddedInChange(beforeText, afterText) {
  const beforeLines = splitCallbackNotesByNewline(beforeText);
  const afterLines = splitCallbackNotesByNewline(afterText);
  if (!afterLines.length) return [];
  if (!beforeLines.length) return [afterLines[afterLines.length - 1]];
  if (afterLines.length > beforeLines.length) {
    return afterLines.slice(beforeLines.length);
  }
  const lastAfter = afterLines[afterLines.length - 1];
  const lastBefore = beforeLines[beforeLines.length - 1];
  if (lastAfter !== lastBefore) return [lastAfter];
  return [];
}

function renderCallbackNotesHistoryHtml(text, { greenLines = null } = {}) {
  const lines = splitCallbackNotesByNewline(text);
  if (!lines.length) return "";
  const greenSet = new Set(
    (Array.isArray(greenLines) ? greenLines : [])
      .map((line) => String(line).trim())
      .filter(Boolean)
  );
  return lines
    .map((line) => {
      const html = escapeHtml(line);
      if (greenSet.has(String(line).trim())) {
        return `<span class="contact-history-note-newest">${html}</span>`;
      }
      return html;
    })
    .join("<br>");
}

function mergeCallbackNotes(existingNotes, textareaNotes, newNoteLine) {
  let notes = normalizeCallbackNotes(textareaNotes || existingNotes || "");
  const newLine = String(newNoteLine || "").trim();
  if (!newLine) return notes;
  if (!notes) return newLine;
  const lines = splitCallbackNotesByNewline(notes);
  if (lines.length && lines[lines.length - 1] === newLine) return notes;
  return `${notes}\n${newLine}`;
}

let aiCallSummaryNotesLastCommittedDraft = "";
let aiCallSummaryNotesCommitLock = false;
let aiCallSummaryNotesCommitPromise = null;
let aiCallSummaryNotesSyncContactId = null;
let aiCallSummaryNotesBlurCommitTimer = null;

function resetAiCallSummaryNotesSync(contact) {
  const contactId = Number(contact?.id) || 0;
  if (contactId && contactId !== aiCallSummaryNotesSyncContactId) {
    aiCallSummaryNotesLastCommittedDraft = "";
    aiCallSummaryNotesSyncContactId = contactId;
  }
}

function removeTrailingNoteBlock(saved, block) {
  const savedLines = splitCallbackNotesByNewline(saved);
  const blockLines = splitCallbackNotesByNewline(block);
  if (!blockLines.length || !savedLines.length) return normalizeCallbackNotes(saved);
  if (blockLines.length === 1) {
    if (savedLines[savedLines.length - 1] === blockLines[0]) {
      return savedLines.slice(0, -1).join("\n");
    }
    return normalizeCallbackNotes(saved);
  }
  if (savedLines.length < blockLines.length) return normalizeCallbackNotes(saved);
  const tail = savedLines.slice(-blockLines.length);
  if (tail.every((line, index) => line === blockLines[index])) {
    return savedLines.slice(0, -blockLines.length).join("\n");
  }
  return normalizeCallbackNotes(saved);
}

function computeContactNotesWithAiDraft({
  draftText = aiCallSummaryNotes?.value,
  savedNotes = activeContact?.notes,
  stripDraft = aiCallSummaryNotesLastCommittedDraft
} = {}) {
  let base = normalizeCallbackNotes(savedNotes || "");
  const committedDraft = normalizeCallbackNotes(stripDraft || "");
  if (committedDraft) {
    base = removeTrailingNoteBlock(base, committedDraft);
  }
  const draft = normalizeCallbackNotes(draftText || "");
  if (!draft) return base;
  return base ? `${base}\n${draft}` : draft;
}

function previewAiCallSummaryNotesInContactDetails() {
  if (!aiCallSummaryNotes) return;
  const notesEl = document.getElementById("notes");
  if (!notesEl) return;
  const preview = computeContactNotesWithAiDraft();
  notesEl.value = preview;
  setSummaryCallbackNotesValue("contactSummaryNotes", preview);
}

function appendAiCallSummaryNotesToContactDetails() {
  if (!aiCallSummaryNotes) return false;
  const notesEl = document.getElementById("notes");
  if (!notesEl) return false;
  const draft = normalizeCallbackNotes(aiCallSummaryNotes.value || "");
  if (!draft) return false;

  const merged = computeContactNotesWithAiDraft();
  const savedNotes = normalizeCallbackNotes(activeContact?.notes || "");
  if (merged === savedNotes) {
    notesEl.value = savedNotes;
    setSummaryCallbackNotesValue("contactSummaryNotes", savedNotes);
    return false;
  }

  notesEl.value = merged;
  setSummaryCallbackNotesValue("contactSummaryNotes", merged);
  setContactStickySaveBarState(false);
  return true;
}

async function persistContactNotesFromDetailsField() {
  if (!activeContact?.id) return;
  const notesEl = document.getElementById("notes");
  if (!notesEl) return;
  const mergedNotes = normalizeCallbackNotes(notesEl.value || "");
  const savedNotes = normalizeCallbackNotes(activeContact?.notes || "");
  if (mergedNotes === savedNotes) return;
  const { response, data } = await fetchApiJson(`/api/contacts/${activeContact.id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ notes: mergedNotes })
  });
  if (!response.ok) throw new Error(data.error || "Failed to save notes.");
  const persisted = normalizeCallbackNotes(data.notes || mergedNotes);
  activeContact.notes = persisted;
  notesEl.value = persisted;
  setSummaryCallbackNotesValue("contactSummaryNotes", persisted);
  aiCallSummaryNotesLastCommittedDraft = normalizeCallbackNotes(aiCallSummaryNotes?.value || "");
  await loadHistory();
}

function cancelAiCallSummaryNotesBlurCommit() {
  if (aiCallSummaryNotesBlurCommitTimer) {
    window.clearTimeout(aiCallSummaryNotesBlurCommitTimer);
    aiCallSummaryNotesBlurCommitTimer = null;
  }
}

async function commitAiCallSummaryNotesToContactDetails() {
  if (aiCallSummaryNotesCommitPromise) {
    await aiCallSummaryNotesCommitPromise;
    return;
  }
  aiCallSummaryNotesCommitPromise = (async () => {
    appendAiCallSummaryNotesToContactDetails();
    await persistContactNotesFromDetailsField();
  })();
  try {
    await aiCallSummaryNotesCommitPromise;
  } finally {
    aiCallSummaryNotesCommitPromise = null;
  }
}

function scheduleAiCallSummaryNotesBlurCommit() {
  if (aiCallSummaryNotesBlurCommitTimer) {
    window.clearTimeout(aiCallSummaryNotesBlurCommitTimer);
  }
  aiCallSummaryNotesBlurCommitTimer = window.setTimeout(() => {
    aiCallSummaryNotesBlurCommitTimer = null;
    if (aiCallSummaryNotesCommitLock) return;
    commitAiCallSummaryNotesToContactDetails().catch((error) => {
      showMessage(error.message || "Failed to save notes.", true);
    });
  }, 400);
}

function parseDetailChangeRecord(rawDetail) {
  const raw = String(rawDetail || "");
  const arrowIdx = raw.indexOf(" -> ");
  if (arrowIdx < 0) return null;
  const head = raw.slice(0, arrowIdx);
  const afterValue = raw.slice(arrowIdx + 4);
  const colonIdx = head.indexOf(":");
  if (colonIdx < 0) return null;
  return {
    fieldName: head.slice(0, colonIdx).trim(),
    beforeValue: head.slice(colonIdx + 1).trim(),
    afterValue: String(afterValue || "").trim()
  };
}

function extractDetailChangeField(item) {
  const rawDetail = String(item?.detail || "");
  const parsed = parseDetailChangeRecord(rawDetail);
  const fieldPart = parsed ? parsed.fieldName : rawDetail.split(":")[0] || "";
  const normalizedField = String(fieldPart).trim().toLowerCase();
  let displayLabel = fieldPart.trim() || "Detail Change";
  if (normalizedField === "notes") displayLabel = "Call Back Notes";
  if (normalizedField === "special_notes") displayLabel = "Special Notes";
  if (normalizedField === "vcall") displayLabel = "Verification call";
  if (normalizedField === "policy_renewal") displayLabel = "Policy renewal date";
  if (normalizedField === "indian") {
    displayLabel = window.__CRM_OMIT_INDIAN_WORKSPACE__
      ? "Lead flag"
      : String(window.__CRM_INDIAN_FIELD_LABEL__ || "Indian").trim() || "Indian";
  }
  if (normalizedField === "created date") displayLabel = "Created Date";
  if (normalizedField === "follow up date") displayLabel = "Follow Up Date";
  if (normalizedField === "follow up time") displayLabel = "Follow Up Time";
  if (normalizedField === "follow up reminder") displayLabel = "Follow Up Reminder";
  return { normalizedField, displayLabel };
}

function normalizeHistoryDetailText(detail) {
  return String(detail || "").replace(/^\uFEFF/, "").trim();
}

function isEmailOpenedHistoryDetail(detail) {
  return /^\s*email\s+opened\b/i.test(normalizeHistoryDetailText(detail));
}

function parseEmailOpenedHistoryDetail(detail) {
  const raw = normalizeHistoryDetailText(detail);
  if (!isEmailOpenedHistoryDetail(raw)) return null;
  const lines = raw.split(/\r?\n/).map((line) => String(line || "").trim()).filter(Boolean);
  let subject = "";
  let openedAt = "";
  for (const line of lines) {
    const subjectMatch = line.match(/^subject:\s*(.+)$/i);
    if (subjectMatch) {
      subject = String(subjectMatch[1] || "").trim();
      continue;
    }
    const openedMatch = line.match(/^opened\s+at:\s*(.+)$/i);
    if (openedMatch) openedAt = String(openedMatch[1] || "").trim();
  }
  return { subject: subject || "(no subject)", openedAt };
}

function formatEmailOpenedHistoryDetail(detail) {
  const parsed = parseEmailOpenedHistoryDetail(detail);
  if (!parsed) return null;
  const openedHtml = parsed.openedAt
    ? `<div class="contact-history-email-opened-when"><span class="contact-history-email-key">Opened:</span> <span class="contact-history-email-value">${escapeHtml(parsed.openedAt)}</span></div>`
    : "";
  return {
    html: `<div class="contact-history-email-opened-detail">
      <div class="contact-history-email-opened-title">${escapeHtml(parsed.subject)}</div>
      ${openedHtml}
    </div>`,
    isSoldChange: false,
    statusShadeClass: "",
    normalizedField: ""
  };
}

function historyFilterBucket(item, typeMeta) {
  const activity = String(item?.activity_type || "").trim().toLowerCase();
  if (activity === "call" || activity === "sms") return "call";
  if (activity === "email") return "email";
  if (typeMeta?.className === "status-change") return "status";
  return "other";
}

function getHistoryTypeMeta(item) {
  const normalized = String(item?.activity_type || "event").trim().toLowerCase();
  const detail = normalizeHistoryDetailText(item?.detail).toLowerCase();
  if (normalized === "email") {
    if (detail.startsWith("email opened")) return { label: "Email Opened", className: "email-opened" };
    return { label: "Email Sent", className: "email" };
  }
  if (normalized === "detail_change") {
    const { normalizedField, displayLabel } = extractDetailChangeField(item);
    if (normalizedField === "notes" || normalizedField === "call back notes" || normalizedField === "special_notes" || normalizedField === "special notes") {
      return { label: "Notes Update", className: "notes-update" };
    }
    if (normalizedField === "status" || normalizedField === "outcome") {
      return { label: "Status Change", className: "status-change" };
    }
    return { label: displayLabel, className: toCssSlug(displayLabel) || "detail-change" };
  }
  if (HISTORY_TYPE_META[normalized]) return HISTORY_TYPE_META[normalized];
  return {
    label: normalized
      .split(/[_\s-]+/)
      .filter(Boolean)
      .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
      .join(" ") || "Event",
    className: "event"
  };
}

const ALLOWED_DETAIL_CHANGE_FIELDS = new Set([
  "outcome",
  "status",
  "vcall",
  "tags",
  "notes",
  "call back notes",
  "special_notes",
  "special notes",
  "created date",
  "follow up date"
]);
const ALLOWED_ACTIVITY_TYPES = new Set(["sms", "email", "call"]);

function isAllowedHistoryItem(item) {
  const activityType = String(item?.activity_type || "").trim().toLowerCase();
  if (ALLOWED_ACTIVITY_TYPES.has(activityType)) return true;
  if (activityType !== "detail_change") return false;
  const { normalizedField } = extractDetailChangeField(item);
  return ALLOWED_DETAIL_CHANGE_FIELDS.has(normalizedField);
}

function formatCallRecordingDuration(seconds) {
  const n = Math.max(0, Math.floor(Number(seconds || 0)));
  if (!n) return "";
  const m = Math.floor(n / 60);
  const s = n % 60;
  return m > 0 ? `${m}:${String(s).padStart(2, "0")}` : `${s}s`;
}

function resolveRecordingPlayUrl(payloadOrUrl) {
  const sidFrom = (value) => {
    const match = String(value || "").match(/\b(RE[a-f0-9]{32})\b/i);
    return match ? match[1] : "";
  };
  if (payloadOrUrl && typeof payloadOrUrl === "object") {
    const play = String(payloadOrUrl.playUrl || "").trim();
    if (play) return play;
    const sid = String(payloadOrUrl.recordingSid || "").trim();
    if (sid) return `/api/twilio/recordings/${encodeURIComponent(sid)}/audio`;
    const url = String(payloadOrUrl.url || "").trim();
    if (url.startsWith("/api/twilio/recordings/")) return url;
    const urlSid = sidFrom(url) || sidFrom(payloadOrUrl.recordingUrl);
    if (urlSid) return `/api/twilio/recordings/${encodeURIComponent(urlSid)}/audio`;
    return "";
  }
  const url = String(payloadOrUrl || "").trim();
  if (!url) return "";
  if (url.startsWith("/api/twilio/recordings/")) return url;
  const sid = sidFrom(url);
  if (sid) return `/api/twilio/recordings/${encodeURIComponent(sid)}/audio`;
  return "";
}

function renderCallRecordingPlayerHtml(playUrl) {
  const src = resolveRecordingPlayUrl(playUrl);
  if (!src) return "";
  return `<audio class="crm-call-recording-player" controls preload="metadata" src="${escapeHtml(src)}">Audio not supported</audio>`;
}

function parseCallRecordingHistoryPayload(detail) {
  const raw = String(detail || "").trim();
  if (raw === "Started call (recording on)") {
    return { status: "pending" };
  }
  if (raw.startsWith("CALL_WITH_RECORDING:")) {
    try {
      return JSON.parse(raw.slice("CALL_WITH_RECORDING:".length));
    } catch {
      return null;
    }
  }
  if (raw.startsWith("CALL_RECORDING:")) {
    try {
      const payload = JSON.parse(raw.slice("CALL_RECORDING:".length));
      return { ...payload, status: "completed" };
    } catch {
      return null;
    }
  }
  return null;
}

function isCallRecordingHistoryItem(item) {
  return Boolean(parseCallRecordingHistoryPayload(item?.detail));
}

function parseEmailHeaderMetaLines(lines) {
  const meta = { from: "(default sender)", to: "-", cc: "-", subject: "(no subject)" };
  for (const line of lines) {
    const idx = line.indexOf(":");
    if (idx <= 0) continue;
    const key = line.slice(0, idx).trim().toLowerCase();
    const value = line.slice(idx + 1).trim();
    if (key === "from") meta.from = value;
    else if (key === "to") meta.to = value;
    else if (key === "cc") meta.cc = value;
    else if (key === "subject") meta.subject = value;
  }
  return meta;
}

function buildHistoryCardHtml(item) {
  const typeMeta = getHistoryTypeMeta(item);
  const detailMeta = formatHistoryDetail(item, {
    highlightLatestNoteEntry: Number(item.id) === latestNotesHistoryHighlightId
  });
  const time = escapeHtml(toReadableDateTime(item.created_at));
  const soldClass = detailMeta.isSoldChange ? " contact-history-item-sold-change" : "";
  const statusShadeClass = detailMeta.statusShadeClass || "";
  const pinnedClass = isHistoryPinned(item) ? " contact-history-item-pinned" : "";
  const starredClass = isHistoryStarred(item) ? " contact-history-item-starred" : "";
  const followUpClass =
    detailMeta.normalizedField === "follow up date" || detailMeta.normalizedField === "follow up time"
      ? " contact-history-item-follow-up"
      : "";
  const historyIcon = historyTypeIcon(item.activity_type, detailMeta.normalizedField, item.detail);
  const markers = `${isHistoryPinned(item) ? '<span class="contact-history-marker">📌</span>' : ""}${
    isHistoryStarred(item) ? '<span class="contact-history-marker">★</span>' : ""
  }`;
  const historyId = Number(item.id || 0);
  const openEmailAttr = historyCardHasOpenableEmail(historyId) ? ' data-history-open-email="1"' : "";
  const markersBlock = `<div class="contact-history-actions-hit" title="Pin, star, or delete" aria-label="Open history actions"><div class="contact-history-markers">${markers}</div></div>`;
  const bucket = historyFilterBucket(item, typeMeta);
  return `<div class="contact-history-item contact-history-item-type-${typeMeta.className}${soldClass}${statusShadeClass}${followUpClass}${pinnedClass}${starredClass}" data-history-id="${historyId}" data-history-bucket="${bucket}" data-pinned="${isHistoryPinned(item) ? "1" : "0"}" data-starred="${isHistoryStarred(item) ? "1" : "0"}"${openEmailAttr} role="button" tabindex="0">
      <div class="contact-history-top"><span class="contact-history-type contact-history-type-${typeMeta.className}"><span class="contact-history-type-icon">${escapeHtml(historyIcon)}</span>${escapeHtml(typeMeta.label)}</span><span class="contact-history-date">${time}</span></div>
      <div class="contact-history-detail">${detailMeta.html}</div>
      ${markersBlock}
    </div>`;
}

function formatCallRecordingHistoryHtmlCompact(payload) {
  if (!payload || payload.status === "pending") return "";
  const dur = formatCallRecordingDuration(payload.durationSeconds);
  if (!dur) return "";
  return `<div class="contact-history-call-summary"><span class="contact-history-call-length">Length: ${escapeHtml(dur)}</span></div>`;
}

function isPendingCallRecordingHistoryItem(item) {
  if (String(item?.activity_type || "").toLowerCase() !== "call") return false;
  const payload = parseCallRecordingHistoryPayload(item?.detail);
  return Boolean(payload && payload.status === "pending");
}

function filterSummaryCallHistoryItems(items) {
  const list = Array.isArray(items) ? items : [];
  if (isFullDetailsMode) return list;
  return list.filter((item) => !isPendingCallRecordingHistoryItem(item));
}

function formatCallRecordingHistoryHtml(payload, options = {}) {
  if (!payload) return "";
  if (options.compact) return formatCallRecordingHistoryHtmlCompact(payload);
  if (payload.status === "pending") {
    return `<div class="contact-history-call-recording"><span class="contact-history-call-recording-label">Recorded call started</span><span class="contact-history-call-recording-pending"> — processing audio…</span></div>`;
  }
  const dur = formatCallRecordingDuration(payload.durationSeconds);
  const player = renderCallRecordingPlayerHtml(payload);
  const sid = String(payload.recordingSid || "").trim();
  const aiButton = sid
    ? `<div class="contact-history-call-recording-actions"><button type="button" class="ai-transcribe-recording-btn" data-recording-sid="${escapeHtmlAttr(sid)}">Transcribe with AI</button></div>`
    : "";
  return `<div class="contact-history-call-recording"><span class="contact-history-call-recording-label">Recorded call${dur ? ` (${escapeHtml(dur)})` : ""}</span>${player ? `<div class="contact-history-call-recording-player">${player}</div>` : ""}${aiButton}</div>`;
}

function renderSummaryCallRecordings(items) {
  if (!contactSummaryRecordingsList) return;
  const section = document.getElementById("contactSummaryRecordingsSection");
  const list = Array.isArray(items) ? items : [];
  if (!list.length) {
    contactSummaryRecordingsList.innerHTML = `<div class="contact-summary-recordings-empty">No recordings yet.</div>`;
    if (section) section.classList.add("is-empty");
    return;
  }
  if (section) section.classList.remove("is-empty");
  contactSummaryRecordingsList.innerHTML = list
    .slice(0, 4)
    .map((item) => {
      const html = formatCallRecordingHistoryHtml({
        status: item.status,
        playUrl: item.playUrl,
        recordingSid: item.recordingSid,
        durationSeconds: item.durationSeconds
      });
      const when = item.updatedAt || item.createdAt ? `<div class="contact-summary-recording-date">${escapeHtml(toReadableDateTime(item.updatedAt || item.createdAt))}</div>` : "";
      return `<div class="contact-summary-recording-card">${when}${html || `<div class="contact-summary-recordings-empty">Recording unavailable.</div>`}</div>`;
    })
    .join("");
}

async function loadSummaryCallRecordings() {
  if (!activeContact?.id || !contactSummaryRecordingsList) return;
  const section = document.getElementById("contactSummaryRecordingsSection");
  if (section) section.classList.remove("is-empty");
  contactSummaryRecordingsList.innerHTML = `<div class="contact-summary-recordings-empty">Loading recordings...</div>`;
  try {
    const { response, data } = await fetchApiJson(`/api/contacts/${encodeURIComponent(activeContact.id)}/call-recordings`);
    if (!response.ok) throw new Error(data.error || "Failed to load call recordings");
    renderSummaryCallRecordings(Array.isArray(data?.items) ? data.items : []);
  } catch (error) {
    contactSummaryRecordingsList.innerHTML = `<div class="contact-summary-recordings-empty is-error">${escapeHtml(error.message || "Could not load recordings.")}</div>`;
    const section = document.getElementById("contactSummaryRecordingsSection");
    if (section) section.classList.remove("is-empty");
  }
}

function isCallRecordingHistoryDetail(detail) {
  const raw = String(detail || "").trim();
  return (
    raw === "Started call (recording on)" ||
    raw.startsWith("CALL_WITH_RECORDING:") ||
    raw.startsWith("CALL_RECORDING:")
  );
}

function mergeCallRecordingHistoryItems(items) {
  const list = Array.isArray(items) ? items : [];
  const out = [];
  for (let i = 0; i < list.length; i += 1) {
    const item = list[i];
    const detail = String(item?.detail || "").trim();
    const prev = out[out.length - 1];
    const prevDetail = String(prev?.detail || "").trim();
    if (
      detail === "Started call (recording on)" &&
      prev &&
      String(prev.activity_type || "").toLowerCase() === "call" &&
      (prevDetail.startsWith("CALL_RECORDING:") || prevDetail.startsWith("CALL_WITH_RECORDING:"))
    ) {
      continue;
    }
    out.push(item);
  }
  return out;
}

function formatHistoryDetail(item, options = {}) {
  const rawDetail = String(item?.detail || "");
  const escapedDetail = escapeHtml(rawDetail);
  const normalizedType = String(item?.activity_type || "").trim().toLowerCase();
  const historyId = Number(item?.id || 0);
  if (normalizedType === "ai_call_summary") {
    try {
      const payload = JSON.parse(rawDetail);
      return {
        html: `<div class="contact-history-ai-detail"><strong>AI Call Summary</strong><p>${escapeHtml(
          payload.summary || ""
        )}</p>${aiListHtml(payload.nextSteps?.length ? payload.nextSteps : payload.discussed)}${
          payload.followUpDate ? `<p><strong>Follow up:</strong> ${escapeHtml(payload.followUpDate)}</p>` : ""
        }</div>`,
        isSoldChange: false,
        statusShadeClass: "",
        normalizedField: ""
      };
    } catch {
      return {
        html: `<div class="contact-history-ai-detail"><strong>AI Call Summary</strong><p>${escapedDetail}</p></div>`,
        isSoldChange: false,
        statusShadeClass: "",
        normalizedField: ""
      };
    }
  }
  if (normalizedType === "ai_objection_coach") {
    try {
      const payload = JSON.parse(rawDetail);
      return {
        html: `<div class="contact-history-ai-detail"><strong>AI Objection Coach</strong>${
          payload.objection ? `<p><strong>Objection:</strong> ${escapeHtml(payload.objection)}</p>` : ""
        }${aiListHtml(payload.rebuttals)}${
          payload.bestQuestion ? `<p><strong>Best question:</strong> ${escapeHtml(payload.bestQuestion)}</p>` : ""
        }</div>`,
        isSoldChange: false,
        statusShadeClass: "",
        normalizedField: ""
      };
    } catch {
      return {
        html: `<div class="contact-history-ai-detail"><strong>AI Objection Coach</strong><p>${escapedDetail}</p></div>`,
        isSoldChange: false,
        statusShadeClass: "",
        normalizedField: ""
      };
    }
  }
  if (normalizedType === "call_transcript") {
    try {
      const payload = JSON.parse(rawDetail);
      return {
        html: `<div class="contact-history-ai-detail"><strong>Call Transcript</strong><p>${escapeHtml(
          String(payload.transcript || "").length > 600
            ? `${String(payload.transcript || "").slice(0, 600)}...`
            : payload.transcript || ""
        )}</p></div>`,
        isSoldChange: false,
        statusShadeClass: "",
        normalizedField: ""
      };
    } catch {
      return {
        html: `<div class="contact-history-ai-detail"><strong>Call Transcript</strong><p>${escapedDetail}</p></div>`,
        isSoldChange: false,
        statusShadeClass: "",
        normalizedField: ""
      };
    }
  }
  if (normalizedType === "call" && isCallRecordingHistoryDetail(rawDetail)) {
    const payload = parseCallRecordingHistoryPayload(rawDetail);
    if (payload) {
      return {
        html: formatCallRecordingHistoryHtml(payload, { compact: !isFullDetailsMode }),
        isSoldChange: false,
        statusShadeClass: "",
        normalizedField: ""
      };
    }
  }
  if (normalizedType === "call" && !isFullDetailsMode) {
    return {
      html: "",
      isSoldChange: false,
      statusShadeClass: "",
      normalizedField: ""
    };
  }
  if (normalizedType === "email") {
    const emailOpenedFormatted = formatEmailOpenedHistoryDetail(rawDetail);
    if (emailOpenedFormatted) return emailOpenedFormatted;
    if (rawDetail.startsWith("EMAIL_JSON:")) {
      const rawJson = rawDetail.slice("EMAIL_JSON:".length);
      try {
        const payload = JSON.parse(rawJson);
        const bccBulk = Boolean(payload?.bccBulk);
        const smtpVisibleTo = String(payload?.smtpVisibleTo || "").trim();
        const bccRecipients = String(payload?.bccRecipients || "").trim();
        const fromValue = String(payload?.from || "(default sender)");
        const toValue = String(payload?.to || "-");
        const ccValue = String(payload?.cc || "-");
        const subjectValue = String(payload?.subject || "(no subject)");
        const htmlBody = String(payload?.html || "").trim();
        const textBody = String(payload?.text || "").trim();
        const previewText = compactEmailPreviewText(htmlBody, textBody);
        const title = emailHistoryCardTitle(subjectValue, htmlBody);
        const headingIframeHtml = emailHistoryHeadingIframeHtml(htmlBody);
        const headingSrcdoc = headingIframeHtml ? "1" : "";
        const bodyPreviewClass = headingSrcdoc
          ? "contact-history-email-body contact-history-email-body--after-heading"
          : "contact-history-email-body";
        stashHistoryEmailPayload(historyId, {
          from: fromValue,
          to: toValue,
          cc: ccValue,
          subject: subjectValue,
          html: htmlBody,
          text: textBody
        });
        return {
          html: `<div class="contact-history-email-detail">
            <div class="contact-history-email-title">${escapeHtml(title)} ${getEmailOpenBadgeHtml(subjectValue)}</div>
            <div class="contact-history-email-meta">
              <div><span class="contact-history-email-key">From:</span> <span class="contact-history-email-value">${escapeHtml(fromValue)}</span></div>
              <div><span class="contact-history-email-key">To:</span> <span class="contact-history-email-value">${escapeHtml(toValue)}</span></div>
              <div><span class="contact-history-email-key">CC:</span> <span class="contact-history-email-value">${escapeHtml(ccValue)}</span></div>
              ${
                bccBulk
                  ? `<div><span class="contact-history-email-key">Delivery:</span> <span class="contact-history-email-value">Bcc — visible <strong>To</strong> on each copy: ${escapeHtml(smtpVisibleTo || "—")}</span></div>
              <div><span class="contact-history-email-key">Bcc list:</span> <span class="contact-history-email-value">${escapeHtml(bccRecipients || "—")}</span></div>`
                  : ""
              }
              <div><span class="contact-history-email-key">Subject:</span> <span class="contact-history-email-value">${escapeHtml(subjectValue)}</span></div>
            </div>
            <div class="contact-history-email-body-label">Body Preview</div>
            ${headingIframeHtml}
            <div class="${bodyPreviewClass}">${escapeHtml(previewText || "(empty body)")}</div>
            <div class="contact-history-email-actions">
              <button type="button" class="contact-history-email-show-more" data-history-id="${historyId > 0 ? historyId : ""}">Show More</button>
            </div>
          </div>`,
          isSoldChange: false,
          statusShadeClass: "",
          normalizedField: ""
        };
      } catch {
        // fall through to legacy/plain rendering
      }
    }
    const sentEmailPlain = /^\s*sent email:\s*(.+)\s*$/i.exec(rawDetail);
    if (sentEmailPlain && !rawDetail.includes("\n")) {
      const subject = sentEmailPlain[1].trim();
      const title = emailHistoryCardTitle(subject, "", subject);
      stashHistoryEmailPayload(historyId, {
        from: "(default sender)",
        to: "-",
        cc: "-",
        subject: subject || "(no subject)",
        html: "",
        text: ""
      });
      return {
        html: `<div class="contact-history-email-detail">
          <div class="contact-history-email-title">${escapeHtml(title)}</div>
        </div>`,
        isSoldChange: false,
        statusShadeClass: "",
        normalizedField: ""
      };
    }
    const lines = rawDetail.split(/\r?\n/);
    const bodyIndex = lines.findIndex((line) => String(line || "").trim().toLowerCase() === "body:");
    if (bodyIndex >= 0) {
      const headerLines = lines.slice(0, bodyIndex).map((line) => String(line || "").trim()).filter(Boolean);
      const bodyText = lines.slice(bodyIndex + 1).join("\n").trim();
      let legacySubject = "";
      const metaLines = [];
      for (const line of headerLines) {
        const idx = line.indexOf(":");
        if (idx > 0 && line.slice(0, idx).trim().toLowerCase() === "subject") {
          legacySubject = line.slice(idx + 1).trim();
          continue;
        }
        metaLines.push(line);
      }
      const headerMeta = parseEmailHeaderMetaLines(headerLines);
      const subjectValue = legacySubject || headerMeta.subject;
      stashHistoryEmailPayload(historyId, {
        from: headerMeta.from,
        to: headerMeta.to,
        cc: headerMeta.cc,
        subject: subjectValue,
        html: "",
        text: bodyText
      });
      const firstLine = emailHistoryCardTitle(subjectValue, "", headerLines.length ? headerLines[0] : "Sent Email");
      const metaHtml = metaLines
        .map((line) => {
          const idx = line.indexOf(":");
          if (idx <= 0) return `<div>${escapeHtml(line)}</div>`;
          const key = line.slice(0, idx).trim();
          const value = line.slice(idx + 1).trim();
          return `<div><span class="contact-history-email-key">${escapeHtml(key)}:</span> <span class="contact-history-email-value">${escapeHtml(value)}</span></div>`;
        })
        .join("");
      return {
        html: `<div class="contact-history-email-detail">
          <div class="contact-history-email-title">${escapeHtml(firstLine)}</div>
          <div class="contact-history-email-meta">${metaHtml}</div>
          <div class="contact-history-email-body-label">Body</div>
          <div class="contact-history-email-body">${escapeHtml(bodyText || "(empty body)")}</div>
        </div>`,
        isSoldChange: false,
        statusShadeClass: "",
        normalizedField: ""
      };
    }
  }
  if (normalizedType === "sms") {
    const trimmed = rawDetail.trim();
    let displayBody = trimmed;
    const smsLoggedPrefix = /^sent sms:\s*/i;
    if (smsLoggedPrefix.test(trimmed)) {
      displayBody = trimmed.replace(smsLoggedPrefix, "");
    }
    return {
      html: `<div class="contact-history-sms-detail">
        <div class="contact-history-sms-body">${escapeHtml(displayBody.trim() || "(empty message)")}</div>
      </div>`,
      isSoldChange: false,
      statusShadeClass: "",
      normalizedField: ""
    };
  }
  if (normalizedType !== "detail_change") {
    return { html: escapedDetail || "-", isSoldChange: false, statusShadeClass: "", normalizedField: "" };
  }
  const parsed = parseDetailChangeRecord(rawDetail);
  if (!parsed) return { html: escapedDetail || "-", isSoldChange: false, statusShadeClass: "", normalizedField: "" };
  const { fieldName, beforeValue, afterValue } = parsed;
  const detailFieldMeta = extractDetailChangeField({ detail: rawDetail });
  let cleanBefore = String(beforeValue || "").trim() === "(empty)" ? "" : String(beforeValue || "");
  let cleanAfter = String(afterValue || "").trim() === "(empty)" ? "" : String(afterValue || "");
  if (detailFieldMeta.normalizedField === "follow up date") {
    cleanBefore = formatDateMmDdYyyy(cleanBefore);
    cleanAfter = formatDateMmDdYyyy(cleanAfter);
  }
  if (detailFieldMeta.normalizedField === "created date") {
    if (cleanBefore) cleanBefore = toReadableDateTime(cleanBefore);
    if (cleanAfter) cleanAfter = toReadableDateTime(cleanAfter);
  }
  const normalizedAfterValue = String(afterValue || "").trim().toLowerCase();
  let statusShadeClass = "";
  if (detailFieldMeta.normalizedField === "status") {
    if (normalizedAfterValue === "pending") statusShadeClass = " contact-history-item-status-pending";
    else if (normalizedAfterValue === "declined" || normalizedAfterValue === "closed")
      statusShadeClass = " contact-history-item-status-declined";
    else if (normalizedAfterValue === "aps") statusShadeClass = " contact-history-item-status-aps";
    else if (normalizedAfterValue === "referred") statusShadeClass = " contact-history-item-status-referred";
  }
  const isCallbackNotesField = isCallbackNotesFieldName(detailFieldMeta.normalizedField);
  if (isCallbackNotesField) {
    cleanBefore = normalizeCallbackNotes(cleanBefore);
    cleanAfter = normalizeCallbackNotes(cleanAfter);
  }
  let greenNoteLines = null;
  if (isCallbackNotesField && options.highlightLatestNoteEntry) {
    const added = getNotesLinesAddedInChange(cleanBefore, cleanAfter);
    greenNoteLines = added.length ? [added[added.length - 1]] : null;
  }
  const beforeHtml = isCallbackNotesField
    ? renderCallbackNotesHistoryHtml(cleanBefore)
    : escapeHtml(cleanBefore);
  const afterHtml = isCallbackNotesField
    ? renderCallbackNotesHistoryHtml(cleanAfter, { greenLines: greenNoteLines })
    : escapeHtml(cleanAfter);
  return {
    html: `<span class="contact-history-detail-field">${escapeHtml(detailFieldMeta.displayLabel || fieldName)}</span>: <span class="contact-history-detail-before">${beforeHtml}</span> <span class="contact-history-detail-arrow">→</span> <span class="contact-history-detail-after">${afterHtml}</span>`,
    isSoldChange: normalizedAfterValue === "sold" || normalizedAfterValue === "approved",
    statusShadeClass,
    normalizedField: detailFieldMeta.normalizedField
  };
}

function historyTypeIcon(typeRaw, normalizedField = "", detailRaw = "") {
  const type = String(typeRaw || "").trim().toLowerCase();
  const field = String(normalizedField || "").trim().toLowerCase();
  const detail = String(detailRaw || "").trim().toLowerCase();
  if (type === "email" && detail.startsWith("email opened")) return "👁";
  if (type === "email") return "📧";
  if (type === "email_open") return "👁";
  if (type === "call") return "📞";
  if (type === "sms") return "💬";
  if (type === "detail_change") {
    if (field === "notes" || field === "call back notes" || field === "special_notes" || field === "special notes") return "📝";
    if (field === "status" || field === "outcome") return "🔄";
    return "🔄";
  }
  if (type === "campaign") return "💬";
  return "🔄";
}

async function scheduleRecordingSync({ callSid, phone } = {}) {
  const contactId = Number(activeContact?.id);
  if (!Number.isInteger(contactId) || contactId < 1) return;
  const body = { contactId, callSid: String(callSid || "").trim(), phone: String(phone || "").trim() };
  const runSync = async () => {
    try {
      await fetchApiJson("/api/twilio/sync-call-recordings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      await Promise.all([loadHistory(), loadSummaryCallRecordings()]);
    } catch (err) {
      console.warn("Recording sync:", err);
    }
  };
  setTimeout(runSync, 6000);
  setTimeout(runSync, 20000);
}

window.addEventListener("crm-refresh-contact", () => {
  refreshActiveContact().catch(() => {});
});
window.addEventListener("crm-reload-history", () => {
  loadHistory().catch(() => {});
});

async function loadHistory() {
  if (!activeContact || !activeContact.id || !contactHistoryList) return;
  const renderSeq = ++historyRenderRequestSeq;
  closeHistoryActionMenu();
  historyEmailPayloadById.clear();
  historyOffset = 0;
  if (contactHistoryLoadMoreBtn) {
    contactHistoryLoadMoreBtn.hidden = true;
    contactHistoryLoadMoreBtn.disabled = true;
  }
  const { response, data } = await fetchApiJson(
    `/api/contacts/${activeContact.id}/history?limit=${HISTORY_PAGE_SIZE}&offset=0`
  );
  if (!response.ok) throw new Error(data.error || "Failed to load contact history");
  if (renderSeq !== historyRenderRequestSeq) return;
  applyContactEmailOpensFromHistoryPayload(data);
  const rawItems = Array.isArray(data) ? data : Array.isArray(data?.items) ? data.items : [];
  const items = filterSummaryCallHistoryItems(
    mergeCallRecordingHistoryItems(rawItems.filter(isAllowedHistoryItem))
  );
  historyOffset = rawItems.length;
  historyHasMore = Boolean(data && typeof data === "object" && "hasMore" in data ? data.hasMore : rawItems.length === HISTORY_PAGE_SIZE);
  if (contactHistoryLoadMoreBtn) {
    contactHistoryLoadMoreBtn.hidden = !historyHasMore;
    contactHistoryLoadMoreBtn.disabled = false;
  }
  if (!items.length) {
    contactHistoryList.innerHTML =
      '<div class="contact-history-empty">No history yet. Calls, texts, and emails will appear here.</div>';
    setContactHistoryCount(0, false);
    return;
  }
  setContactHistoryCount(items.length, historyHasMore);
  latestNotesHistoryHighlightId = findLatestNotesHistoryItemId(items);
  const batchSize = HISTORY_RENDER_BATCH_SIZE;
  let index = 0;
  contactHistoryList.innerHTML = "";
  const renderBatch = () => {
    if (renderSeq !== historyRenderRequestSeq || !contactHistoryList) return;
    const next = items.slice(index, index + batchSize);
    if (!next.length) return;
    contactHistoryList.insertAdjacentHTML("beforeend", next.map((item) => buildHistoryCardHtml(item)).join(""));
    initHistoryEmailHeadingIframes(contactHistoryList);
    index += batchSize;
    if (index < items.length) window.setTimeout(renderBatch, 0);
  };
  renderBatch();
}

async function loadMoreHistory() {
  if (!activeContact || !activeContact.id || !contactHistoryList || !historyHasMore) return;
  if (contactHistoryLoadMoreBtn) contactHistoryLoadMoreBtn.disabled = true;
  const renderSeq = historyRenderRequestSeq;
  const { response, data } = await fetchApiJson(
    `/api/contacts/${activeContact.id}/history?limit=${HISTORY_PAGE_SIZE}&offset=${historyOffset}`
  );
  if (!response.ok) throw new Error(data.error || "Failed to load more history");
  if (renderSeq !== historyRenderRequestSeq) return;
  applyContactEmailOpensFromHistoryPayload(data);
  const rawItems = Array.isArray(data) ? data : Array.isArray(data?.items) ? data.items : [];
  const items = filterSummaryCallHistoryItems(
    mergeCallRecordingHistoryItems(rawItems.filter(isAllowedHistoryItem))
  );
  historyOffset += rawItems.length;
  historyHasMore = Boolean(data && typeof data === "object" && "hasMore" in data ? data.hasMore : rawItems.length === HISTORY_PAGE_SIZE);
  if (contactHistoryLoadMoreBtn) {
    contactHistoryLoadMoreBtn.hidden = !historyHasMore;
    contactHistoryLoadMoreBtn.disabled = false;
  }
  if (!items.length) return;
  setContactHistoryCount(historyVisibleCount + items.length, historyHasMore);
  const batchSize = HISTORY_RENDER_BATCH_SIZE;
  let index = 0;
  const renderBatch = () => {
    if (renderSeq !== historyRenderRequestSeq || !contactHistoryList) return;
    const next = items.slice(index, index + batchSize);
    if (!next.length) return;
    contactHistoryList.insertAdjacentHTML("beforeend", next.map((item) => buildHistoryCardHtml(item)).join(""));
    initHistoryEmailHeadingIframes(contactHistoryList);
    index += batchSize;
    if (index < items.length) window.setTimeout(renderBatch, 0);
  };
  renderBatch();
}

async function loadTasks() {
  if (!activeContact?.id || !contactTasksList) return;
  const { response, data } = await fetchApiJson(`/api/contacts/${activeContact.id}/tasks`);
  if (!response.ok) throw new Error(data.error || "Failed to load tasks");
  const items = Array.isArray(data) ? data : [];
  if (!items.length) {
    contactTasksList.innerHTML = '<div class="contact-history-empty">No tasks yet.</div>';
    return;
  }
  contactTasksList.innerHTML = items
    .map((task) => {
      const taskId = Number(task.id);
      const condition = String(task.condition || "Yet to Start");
      const classSlug =
        condition === "Completed" ? "completed" : condition === "In Progress" ? "in-progress" : "yet-to-start";
      const showCompleteBtn = Number.isInteger(taskId) && taskId > 0 && condition !== "Completed";
      return `<div class="contact-task-item">
        <div class="contact-task-name">${escapeHtml(String(task.task_name || "-"))}</div>
        <div class="contact-task-meta">
          <span>${escapeHtml(String(task.action_type || "Other"))}</span>
          <span>${escapeHtml(formatTaskDateTime(task.task_date, task.task_time))}</span>
        </div>
        <div class="contact-task-footer">
          <div class="contact-task-condition contact-task-condition-${classSlug}">${escapeHtml(condition)}</div>
          ${
            showCompleteBtn
              ? `<button type="button" class="contact-task-complete-btn" data-task-id="${taskId}">Mark Completed</button>`
              : ""
          }
        </div>
      </div>`;
    })
    .join("");
}

async function markTaskCompleted(taskId) {
  if (!activeContact?.id) return;
  const safeTaskId = Number(taskId);
  if (!Number.isInteger(safeTaskId) || safeTaskId < 1) return;
  const { response, data } = await fetchApiJson(`/api/contacts/${activeContact.id}/tasks/${safeTaskId}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ condition: "Completed" })
  });
  if (!response.ok) throw new Error(data.error || "Failed to mark task completed");
}

async function loadContact() {
  const id = parseContactId();
  if (!id) {
    showMessage("Invalid contact id.", true);
    revealContactDetailsLayout();
    return;
  }
  const { response, data } = await fetchApiJson(`/api/contacts/${id}`);
  if (!response.ok) throw new Error(data.error || "Failed to load contact");
  try {
    fillForm(data);
  } catch (err) {
    console.error("fillForm:", err);
    showMessage(err.message || "Could not display this contact.", true);
  }
  applyContactNotesHeights();
  if (contactHistoryList && !contactHistoryList.innerHTML.trim()) {
    contactHistoryList.innerHTML = '<div class="contact-history-empty">Loading history...</div>';
  }
  if (contactTasksList && !contactTasksList.innerHTML.trim()) {
    contactTasksList.innerHTML = '<div class="contact-history-empty">Loading tasks...</div>';
  }
  await Promise.all([
    loadHistory().catch((err) => {
      console.error("loadHistory:", err);
      if (contactHistoryList) {
        contactHistoryList.innerHTML = `<div class="contact-history-empty">${escapeHtml(
          err.message || "Could not load history."
        )}</div>`;
      }
      setContactHistoryCount(0, false);
    }),
    loadTasks().catch((err) => {
      console.error("loadTasks:", err);
      if (contactTasksList) {
        contactTasksList.innerHTML = `<div class="contact-history-empty">${escapeHtml(
          err.message || "Could not load tasks."
        )}</div>`;
      }
    }),
    loadSummaryCallRecordings()
  ]);
  revealContactDetailsLayout();
  if (shouldFocusTasksOnLoad) {
    const tasksSection = document.getElementById("contactTasksSection");
    if (tasksSection && typeof tasksSection.scrollIntoView === "function") {
      window.requestAnimationFrame(() => {
        tasksSection.classList.add("contact-tasks-section--focus");
        tasksSection.scrollIntoView({ behavior: "smooth", block: "start" });
        window.setTimeout(() => tasksSection.classList.remove("contact-tasks-section--focus"), 2600);
      });
    }
  } else if (shouldFocusFollowUpOnLoad) {
    const followUpSection = document.getElementById("contactFollowUpSection");
    if (followUpSection && typeof followUpSection.scrollIntoView === "function") {
      window.requestAnimationFrame(() => {
        followUpSection.classList.add("contact-tasks-section--focus");
        followUpSection.scrollIntoView({ behavior: "smooth", block: "start" });
        window.setTimeout(() => followUpSection.classList.remove("contact-tasks-section--focus"), 2600);
      });
    }
  }
}

function parseContactJsonArray(raw) {
  if (Array.isArray(raw)) return raw;
  const text = String(raw == null ? "" : raw).trim();
  if (!text) return [];
  try {
    const parsed = JSON.parse(text);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function crmLocalId(prefix) {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  return `${prefix || "id"}_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
}

function isoDateValue(raw) {
  const value = String(raw == null ? "" : raw).trim();
  return /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : "";
}

function normalizeHouseholdMemberRecord(item) {
  const relationship = String(item?.relationship || "").trim();
  const gender = String(item?.gender || "").trim();
  const tobacco = String(item?.tobacco || "").trim();
  return {
    id: String(item?.id || "").trim() || crmLocalId("hm"),
    relationship: ["Spouse", "Child", "Domestic Partner", "Parent", "Other"].includes(relationship)
      ? relationship
      : "Other",
    first_name: String(item?.first_name || "").trim(),
    middle_name: String(item?.middle_name || "").trim(),
    last_name: String(item?.last_name || "").trim(),
    date_of_birth: isoDateValue(item?.date_of_birth),
    gender: gender === "Male" || gender === "Female" ? gender : "",
    tobacco: tobacco === "Yes" || tobacco === "No" ? tobacco : ""
  };
}

function normalizeContactQuoteRecord(item) {
  const status = String(item?.status || "").trim();
  const currentRaw = item?.current;
  return {
    id: String(item?.id || "").trim() || crmLocalId("qt"),
    carrier: String(item?.carrier || "").trim(),
    plan_name: String(item?.plan_name || "").trim(),
    premium: formatCommissionValue(item?.premium || ""),
    quoted_at: isoDateValue(item?.quoted_at),
    status: ["Quoted", "Presented", "Chosen", "Declined"].includes(status) ? status : "Quoted",
    notes: String(item?.notes || "").trim(),
    current: currentRaw === true || currentRaw === 1 || String(currentRaw || "") === "1"
  };
}

function householdMemberDisplayName(member) {
  return [member?.first_name, member?.middle_name, member?.last_name]
    .map((part) => String(part || "").trim())
    .filter(Boolean)
    .join(" ") || "Household member";
}

function syncHouseholdSizeFromMembers() {
  const sizeEl = namedFormControl("household_size");
  if (!sizeEl) return;
  const size = String(1 + householdMembers.length);
  if (![...sizeEl.options].some((option) => option.value === size)) {
    const option = document.createElement("option");
    option.value = size;
    option.textContent = size;
    sizeEl.appendChild(option);
  }
  sizeEl.value = size;
}

function syncCurrentQuoteField() {
  const current = contactQuotes.find((quote) => quote.current);
  if (!current) return;
  const quoteEl = namedFormControl("quote");
  if (quoteEl) quoteEl.value = formatCommissionValue(current.premium || "");
}

function markContactRecordDirty() {
  setContactStickySaveBarState(false);
}

function renderHouseholdMembers() {
  const list = document.getElementById("contactHouseholdList");
  if (!list) return;
  if (!householdMembers.length) {
    list.innerHTML = `<div class="contact-record-empty">No spouse or dependents added yet.</div>`;
    return;
  }
  list.innerHTML = householdMembers
    .map((member) => {
      const meta = [
        member.relationship,
        member.date_of_birth ? `DOB ${formatDateMmDdYyyy(member.date_of_birth)}` : "",
        member.gender,
        member.tobacco === "Yes" ? "Tobacco" : member.tobacco === "No" ? "Non-tobacco" : ""
      ]
        .filter(Boolean)
        .join(" · ");
      return `<article class="contact-record-card" data-household-id="${escapeHtml(member.id)}">
        <div>
          <p class="contact-record-card-title">${escapeHtml(householdMemberDisplayName(member))}</p>
          <p class="contact-record-card-meta">${escapeHtml(meta)}</p>
        </div>
        <div class="contact-record-card-actions">
          <button type="button" data-household-edit="${escapeHtml(member.id)}">Edit</button>
          <button type="button" class="danger" data-household-remove="${escapeHtml(member.id)}">Remove</button>
        </div>
      </article>`;
    })
    .join("");
}

function renderContactQuotes() {
  const list = document.getElementById("contactQuotesList");
  if (!list) return;
  if (!contactQuotes.length) {
    const premium = String(namedFormControl("quote")?.value || "").trim();
    list.innerHTML = premium
      ? `<div class="contact-record-empty">The amount above is the current premium. Add a carrier quote only if you want to keep other plan options on this contact.</div>`
      : `<div class="contact-record-empty">Add a carrier quote if you want to keep plan options on this contact.</div>`;
    return;
  }
  list.innerHTML = contactQuotes
    .map((quote) => {
      const title = [quote.carrier, quote.plan_name].filter(Boolean).join(" · ") || "Quote";
      const meta = [
        quote.premium || "",
        quote.status,
        quote.quoted_at ? `Quoted ${formatDateMmDdYyyy(quote.quoted_at)}` : "",
        quote.notes
      ]
        .filter(Boolean)
        .join(" · ");
      const currentBtn = quote.current
        ? ""
        : `<button type="button" data-quote-current="${escapeHtml(quote.id)}">Make current</button>`;
      return `<article class="contact-record-card" data-quote-id="${escapeHtml(quote.id)}">
        <div>
          <p class="contact-record-card-title">${escapeHtml(title)}${
            quote.current ? `<span class="contact-record-badge">Current</span>` : ""
          }</p>
          <p class="contact-record-card-meta">${escapeHtml(meta)}</p>
        </div>
        <div class="contact-record-card-actions">
          ${currentBtn}
          <button type="button" data-quote-edit="${escapeHtml(quote.id)}">Edit</button>
          <button type="button" class="danger" data-quote-remove="${escapeHtml(quote.id)}">Remove</button>
        </div>
      </article>`;
    })
    .join("");
}

const CONTACT_SECTION_NAV = [
  {
    id: "contact-section-identity",
    label: "Overview",
    icon: "M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"
  },
  {
    id: "contact-section-location",
    label: "Contact info",
    icon: "M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5a2.5 2.5 0 110-5 2.5 2.5 0 010 5z"
  },
  {
    id: "contact-section-household",
    label: "Household",
    icon: "M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 3-1.34 3-3S9.66 5 8 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"
  },
  {
    id: "contact-section-quotes",
    label: "Quotes",
    icon: "M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"
  },
  {
    id: "contact-section-coverage",
    label: "Coverage",
    icon: "M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"
  },
  {
    id: "contact-section-lead",
    label: "Lead",
    icon: "M14.4 6L14 4H5v17h2v-7h5.6l.4 2h7V6z"
  },
  {
    id: "contact-section-tasks",
    label: "Tasks",
    icon: "M22 7h-9v2h9V7zm0 8h-9v2h9v-2zM5.54 11L2 7.46l1.41-1.41 2.12 2.12 4.24-4.24 1.41 1.41L5.54 11zm0 8L2 15.46l1.41-1.41 2.12 2.12 4.24-4.24 1.41 1.41L5.54 19z"
  },
  {
    id: "contact-section-notes",
    label: "Notes",
    icon: "M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"
  },
  {
    id: "contactHistoryPanel",
    label: "History",
    icon: "M13 3a9 9 0 00-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42A8.954 8.954 0 0013 21a9 9 0 000-18zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z"
  }
];

function buildContactRecordNav() {
  const nav = document.createElement("nav");
  nav.className = "contact-record-nav";
  nav.id = "contactRecordNav";
  nav.setAttribute("aria-label", "Contact sections");
  CONTACT_SECTION_NAV.forEach((item, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.setAttribute("data-scroll-section", item.id);
    button.setAttribute("data-label", item.label);
    button.setAttribute("aria-label", item.label);
    button.innerHTML = `<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="${item.icon}"/></svg>`;
    if (index === 0) button.classList.add("is-active");
    nav.appendChild(button);
  });
  return nav;
}

function setActiveContactSectionNav(sectionId) {
  const nav = document.getElementById("contactRecordNav");
  if (!nav) return;
  nav.querySelectorAll("[data-scroll-section]").forEach((button) => {
    button.classList.toggle("is-active", button.getAttribute("data-scroll-section") === sectionId);
  });
}

function wireContactSectionNav() {
  const nav = document.getElementById("contactRecordNav");
  if (!nav || nav.dataset.wired === "1") return;
  nav.dataset.wired = "1";
  nav.addEventListener("click", (event) => {
    const button = event.target.closest("[data-scroll-section]");
    if (!button) return;
    const sectionId = button.getAttribute("data-scroll-section");
    const target = document.getElementById(sectionId);
    if (!target) return;
    setActiveContactSectionNav(sectionId);
    target.scrollIntoView({ behavior: "smooth", block: "start" });
  });
  if (typeof IntersectionObserver === "function") {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target?.id) setActiveContactSectionNav(visible.target.id);
      },
      { rootMargin: "-18% 0px -62% 0px", threshold: [0.12, 0.28, 0.5] }
    );
    CONTACT_SECTION_NAV.forEach((item) => {
      const el = document.getElementById(item.id);
      if (el) observer.observe(el);
    });
  }
}

function createContactRecordListSection(title, extraClass, sectionId, hintText, listId, addId, addLabel) {
  const created = createContactDetailsSection(title, extraClass, sectionId);
  if (hintText) {
    const hint = document.createElement("p");
    hint.className = "hint contact-details-section-hint";
    hint.textContent = hintText;
    created.section.insertBefore(hint, created.grid);
  }
  const list = document.createElement("div");
  list.id = listId;
  list.className = "contact-record-card-list";
  const addBtn = document.createElement("button");
  addBtn.type = "button";
  addBtn.id = addId;
  addBtn.className = "contact-record-add-btn";
  addBtn.textContent = addLabel;
  created.section.appendChild(list);
  created.section.appendChild(addBtn);
  return created;
}

function openContactModal(modal) {
  if (!modal) return;
  modal.classList.remove("hidden");
  modal.setAttribute("aria-hidden", "false");
}

function closeContactModal(modal) {
  if (!modal) return;
  modal.classList.add("hidden");
  modal.setAttribute("aria-hidden", "true");
}

function openHouseholdMemberModal(member) {
  const modal = document.getElementById("contactHouseholdModal");
  const formEl = document.getElementById("contactHouseholdModalForm");
  if (!modal || !formEl) return;
  householdMemberEditId = String(member?.id || "");
  const title = document.getElementById("contactHouseholdModalTitle");
  if (title) title.textContent = householdMemberEditId ? "Edit household member" : "Add household member";
  document.getElementById("contactHouseholdMemberId").value = householdMemberEditId;
  document.getElementById("contactHouseholdRelationship").value = member?.relationship || "Spouse";
  document.getElementById("contactHouseholdFirstName").value = member?.first_name || "";
  document.getElementById("contactHouseholdMiddleName").value = member?.middle_name || "";
  document.getElementById("contactHouseholdLastName").value = member?.last_name || "";
  document.getElementById("contactHouseholdDob").value = member?.date_of_birth || "";
  document.getElementById("contactHouseholdGender").value = member?.gender || "";
  document.getElementById("contactHouseholdTobacco").value = member?.tobacco || "";
  openContactModal(modal);
  requestAnimationFrame(() => document.getElementById("contactHouseholdFirstName")?.focus());
}

function saveHouseholdMemberFromModal() {
  const firstName = String(document.getElementById("contactHouseholdFirstName")?.value || "").trim();
  if (!firstName) {
    showMessage("First name is required for a household member.", true);
    return false;
  }
  const record = normalizeHouseholdMemberRecord({
    id: householdMemberEditId || crmLocalId("hm"),
    relationship: document.getElementById("contactHouseholdRelationship")?.value,
    first_name: firstName,
    middle_name: document.getElementById("contactHouseholdMiddleName")?.value,
    last_name: document.getElementById("contactHouseholdLastName")?.value,
    date_of_birth: document.getElementById("contactHouseholdDob")?.value,
    gender: document.getElementById("contactHouseholdGender")?.value,
    tobacco: document.getElementById("contactHouseholdTobacco")?.value
  });
  const index = householdMembers.findIndex((member) => member.id === record.id);
  if (index >= 0) householdMembers[index] = record;
  else householdMembers.push(record);
  syncHouseholdSizeFromMembers();
  renderHouseholdMembers();
  markContactRecordDirty();
  closeContactModal(document.getElementById("contactHouseholdModal"));
  return true;
}

function removeHouseholdMember(id) {
  householdMembers = householdMembers.filter((member) => member.id !== id);
  syncHouseholdSizeFromMembers();
  renderHouseholdMembers();
  markContactRecordDirty();
}

function openContactQuoteModal(quote) {
  const modal = document.getElementById("contactQuoteModal");
  if (!modal) return;
  contactQuoteEditId = String(quote?.id || "");
  const title = document.getElementById("contactQuoteModalTitle");
  if (title) title.textContent = contactQuoteEditId ? "Edit quote" : "Add quote";
  document.getElementById("contactQuoteId").value = contactQuoteEditId;
  document.getElementById("contactQuoteCarrier").value = quote?.carrier || "";
  document.getElementById("contactQuotePlanName").value = quote?.plan_name || "";
  document.getElementById("contactQuotePremium").value = quote?.premium || "";
  document.getElementById("contactQuoteQuotedAt").value = quote?.quoted_at || "";
  document.getElementById("contactQuoteStatus").value = quote?.status || "Quoted";
  document.getElementById("contactQuoteNotes").value = quote?.notes || "";
  document.getElementById("contactQuoteCurrent").checked = Boolean(quote?.current) || !contactQuotes.length;
  openContactModal(modal);
  requestAnimationFrame(() => document.getElementById("contactQuoteCarrier")?.focus());
}

function saveContactQuoteFromModal() {
  const carrier = String(document.getElementById("contactQuoteCarrier")?.value || "").trim();
  const planName = String(document.getElementById("contactQuotePlanName")?.value || "").trim();
  const premium = String(document.getElementById("contactQuotePremium")?.value || "").trim();
  if (!carrier && !planName && !premium) {
    showMessage("Enter a carrier, plan, or premium for the quote.", true);
    return false;
  }
  const record = normalizeContactQuoteRecord({
    id: contactQuoteEditId || crmLocalId("qt"),
    carrier,
    plan_name: planName,
    premium,
    quoted_at: document.getElementById("contactQuoteQuotedAt")?.value,
    status: document.getElementById("contactQuoteStatus")?.value,
    notes: document.getElementById("contactQuoteNotes")?.value,
    current: document.getElementById("contactQuoteCurrent")?.checked
  });
  if (record.current) {
    contactQuotes = contactQuotes.map((quote) => ({ ...quote, current: false }));
  }
  const index = contactQuotes.findIndex((quote) => quote.id === record.id);
  if (index >= 0) contactQuotes[index] = record;
  else contactQuotes.push(record);
  if (contactQuotes.length === 1) contactQuotes[0].current = true;
  syncCurrentQuoteField();
  renderContactQuotes();
  markContactRecordDirty();
  closeContactModal(document.getElementById("contactQuoteModal"));
  return true;
}

function setCurrentContactQuote(id) {
  contactQuotes = contactQuotes.map((quote) => ({ ...quote, current: quote.id === id }));
  syncCurrentQuoteField();
  renderContactQuotes();
  markContactRecordDirty();
}

function removeContactQuote(id) {
  const wasCurrent = contactQuotes.some((quote) => quote.id === id && quote.current);
  contactQuotes = contactQuotes.filter((quote) => quote.id !== id);
  if (wasCurrent && contactQuotes.length) contactQuotes[0].current = true;
  syncCurrentQuoteField();
  renderContactQuotes();
  markContactRecordDirty();
}

function wireContactRecordLists() {
  if (!form || form.dataset.recordListsWired === "1") return;
  form.dataset.recordListsWired = "1";
  form.addEventListener("click", (event) => {
    const addHousehold = event.target.closest("#contactHouseholdAddBtn");
    if (addHousehold) {
      openHouseholdMemberModal(null);
      return;
    }
    const editHousehold = event.target.closest("[data-household-edit]");
    if (editHousehold) {
      const id = editHousehold.getAttribute("data-household-edit");
      const member = householdMembers.find((item) => item.id === id);
      if (member) openHouseholdMemberModal(member);
      return;
    }
    const removeHousehold = event.target.closest("[data-household-remove]");
    if (removeHousehold) {
      removeHouseholdMember(removeHousehold.getAttribute("data-household-remove"));
      return;
    }
    const addQuote = event.target.closest("#contactQuoteAddBtn");
    if (addQuote) {
      openContactQuoteModal(null);
      return;
    }
    const hsQuote = event.target.closest("#contactQuotesHealthSherpaBtn");
    if (hsQuote) {
      openContactInHealthSherpa().catch((err) => showMessage(err.message || "Could not open HealthSherpa.", true));
      return;
    }
    const editQuote = event.target.closest("[data-quote-edit]");
    if (editQuote) {
      const id = editQuote.getAttribute("data-quote-edit");
      const quote = contactQuotes.find((item) => item.id === id);
      if (quote) openContactQuoteModal(quote);
      return;
    }
    const currentQuote = event.target.closest("[data-quote-current]");
    if (currentQuote) {
      setCurrentContactQuote(currentQuote.getAttribute("data-quote-current"));
      return;
    }
    const removeQuote = event.target.closest("[data-quote-remove]");
    if (removeQuote) {
      removeContactQuote(removeQuote.getAttribute("data-quote-remove"));
    }
  });
}

function wireContactRecordModals() {
  const householdModal = document.getElementById("contactHouseholdModal");
  const householdForm = document.getElementById("contactHouseholdModalForm");
  const householdClose = document.getElementById("contactHouseholdModalCloseBtn");
  if (householdForm && householdForm.dataset.wired !== "1") {
    householdForm.dataset.wired = "1";
    householdForm.addEventListener("submit", (event) => {
      event.preventDefault();
      saveHouseholdMemberFromModal();
    });
  }
  if (householdClose && householdClose.dataset.wired !== "1") {
    householdClose.dataset.wired = "1";
    householdClose.addEventListener("click", () => closeContactModal(householdModal));
  }
  if (householdModal && householdModal.dataset.wired !== "1") {
    householdModal.dataset.wired = "1";
    householdModal.addEventListener("click", (event) => {
      if (event.target?.getAttribute?.("data-close-contact-household-modal") === "1") {
        closeContactModal(householdModal);
      }
    });
  }
  const quoteModal = document.getElementById("contactQuoteModal");
  const quoteForm = document.getElementById("contactQuoteModalForm");
  const quoteClose = document.getElementById("contactQuoteModalCloseBtn");
  if (quoteForm && quoteForm.dataset.wired !== "1") {
    quoteForm.dataset.wired = "1";
    quoteForm.addEventListener("submit", (event) => {
      event.preventDefault();
      saveContactQuoteFromModal();
    });
  }
  if (quoteClose && quoteClose.dataset.wired !== "1") {
    quoteClose.dataset.wired = "1";
    quoteClose.addEventListener("click", () => closeContactModal(quoteModal));
  }
  if (quoteModal && quoteModal.dataset.wired !== "1") {
    quoteModal.dataset.wired = "1";
    quoteModal.addEventListener("click", (event) => {
      if (event.target?.getAttribute?.("data-close-contact-quote-modal") === "1") {
        closeContactModal(quoteModal);
      }
    });
  }
}

function createContactDetailsSection(title, extraClass = "", sectionId = "") {
  const section = document.createElement("section");
  section.className = `contact-details-section${extraClass ? ` ${extraClass}` : ""}`;
  if (sectionId) section.id = sectionId;
  const heading = document.createElement("h3");
  heading.textContent = title;
  const grid = document.createElement("div");
  grid.className = "contact-details-section-grid";
  section.appendChild(heading);
  section.appendChild(grid);
  return { section, grid };
}

function contactDetailsFieldNode(id) {
  if (!id) return null;
  const root = form || document;
  let el = null;
  try {
    el = root.querySelector("#" + CSS.escape(id));
  } catch {
    el = root.querySelector("#" + id);
  }
  if (!el) el = document.getElementById(id);
  if (!el) return null;
  return el.closest(".contact-field-box, .contact-status-box") || null;
}

function appendContactDetailsFields(grid, ids) {
  ids.forEach((id) => {
    const node = contactDetailsFieldNode(id);
    if (node) grid.appendChild(node);
  });
}

function revealContactDetailsLayout() {
  document.documentElement.classList.remove("contact-summary-mode-pending");
  document.documentElement.classList.remove("contact-full-mode-pending");
}

function enhanceContactDetailsLayout() {
  if (!form || form.dataset.detailsEnhanced === "1") return;
  form.dataset.detailsEnhanced = "1";
  if (window.__CRM_OMIT_INDIAN_WORKSPACE__) {
    const indianSelect = document.getElementById("indian");
    if (indianSelect) {
      const indianBox = indianSelect.closest(".contact-field-box");
      if (indianBox) indianBox.remove();
      else indianSelect.remove();
    }
  }
  const split = form.querySelector(".contact-details-form-split");
  const twilioFromBox = contactDetailsFieldNode("contactTwilioFromSelect");
  const originalActions = smsBtn?.closest(".contact-modal-actions") || null;
  const saveBtn = document.getElementById("contactPageSaveBtn");
  const saveActions = saveBtn?.closest(".contact-modal-actions") || null;

  const toolbar = document.createElement("div");
  toolbar.className = "contact-details-toolbar";
  if (twilioFromBox) toolbar.appendChild(twilioFromBox);

  const primaryActions = document.createElement("div");
  primaryActions.className = "contact-details-primary-actions";
  [callBtn, smsBtn, emailBtn, whatsAppBtn, addCampaignBtn, deleteBtn].forEach((button) => {
    if (button) primaryActions.appendChild(button);
  });

  toolbar.appendChild(primaryActions);
  form.insertBefore(toolbar, split || form.firstElementChild?.nextSibling || null);
  if (originalActions && originalActions.children.length) {
    originalActions.classList.add("contact-details-secondary-actions");
    form.insertBefore(originalActions, toolbar.nextSibling);
  } else if (originalActions) {
    originalActions.remove();
  }

  const layout = document.createElement("div");
  layout.className = "contact-details-redesign-grid";
  const leftCol = document.createElement("div");
  leftCol.className = "contact-details-redesign-col";
  const rightCol = document.createElement("div");
  rightCol.className = "contact-details-redesign-col contact-details-redesign-col--right";
  layout.appendChild(leftCol);
  layout.appendChild(rightCol);
  form.insertBefore(layout, split || saveActions || null);

  const identity = createContactDetailsSection("Identity", "", "contact-section-identity");
  const identityFields = [
    "first_name",
    "middle_name",
    "last_name",
    "email",
    "primary_phone",
    "secondary_phone",
    "age",
    "date_of_birth",
    "gender",
    "profession",
    "height",
    "weight",
    "income"
  ];
  if (!window.__CRM_OMIT_INDIAN_WORKSPACE__) identityFields.splice(8, 0, "indian");
  appendContactDetailsFields(identity.grid, identityFields);
  leftCol.appendChild(identity.section);

  const location = createContactDetailsSection("Location", "", "contact-section-location");
  appendContactDetailsFields(location.grid, ["home_address", "city", "state", "zip_code"]);
  leftCol.appendChild(location.section);

  const household = createContactRecordListSection(
    "Household",
    "contact-details-section--household",
    "contact-section-household",
    "Add a spouse, children, or other dependents on this contact. Household size updates when you add or remove members.",
    "contactHouseholdList",
    "contactHouseholdAddBtn",
    "Add household member"
  );
  appendContactDetailsFields(household.grid, ["household_size"]);
  leftCol.appendChild(household.section);

  const quotes = createContactRecordListSection(
    "Quotes",
    "contact-details-section--quotes",
    "contact-section-quotes",
    "The Quote field is the current premium. Add carrier quotes below if you want to compare plans.",
    "contactQuotesList",
    "contactQuoteAddBtn",
    "Add quote"
  );
  appendContactDetailsFields(quotes.grid, ["quote"]);
  const quoteBox = contactDetailsFieldNode("quote");
  if (quoteBox) quoteBox.classList.add("contact-quote-emphasis");
  const quoteAddBtn = quotes.section.querySelector("#contactQuoteAddBtn");
  if (quoteAddBtn) {
    const quoteActions = document.createElement("div");
    quoteActions.className = "contact-record-quote-actions";
    quoteAddBtn.replaceWith(quoteActions);
    quoteActions.appendChild(quoteAddBtn);
    const hsQuoteBtn = document.createElement("button");
    hsQuoteBtn.type = "button";
    hsQuoteBtn.id = "contactQuotesHealthSherpaBtn";
    hsQuoteBtn.className = "contact-record-add-btn";
    hsQuoteBtn.textContent = "Quote in HealthSherpa";
    quoteActions.appendChild(hsQuoteBtn);
  }
  leftCol.appendChild(quotes.section);

  const coverage = createContactDetailsSection("Coverage", "contact-details-section--coverage", "contact-section-coverage");
  const coverageHint = document.createElement("p");
  coverageHint.className = "hint contact-details-section-hint";
  coverageHint.textContent =
    "Track 3-month, 6-month, or 12-month renewals from Coverage Start Date. Current premium lives in Quotes.";
  coverage.section.insertBefore(coverageHint, coverage.grid);
  appendContactDetailsFields(coverage.grid, [
    "coverages_sold",
    "coverage_start_date",
    "policy_renewal",
    "renewal_interval",
    "health_issues",
    "app_id",
    "commission",
    "vcall",
    "insurance_type"
  ]);
  leftCol.appendChild(coverage.section);

  const customPanel = document.getElementById("cd-panel-custom-fields");
  if (customPanel) leftCol.appendChild(customPanel);

  const followUp = createContactDetailsSection("Follow-Up & Tasks", "contact-details-section--priority", "contact-section-tasks");
  const followUpSection = document.querySelector(".contact-follow-up-section");
  const tasksSection = document.getElementById("contactTasksSection");
  if (followUpSection) followUp.grid.appendChild(followUpSection);
  if (tasksSection) followUp.grid.appendChild(tasksSection);
  rightCol.appendChild(followUp.section);

  const lead = createContactDetailsSection("Lead Details", "contact-details-section--lead-details", "contact-section-lead");
  appendContactDetailsFields(lead.grid, [
    "contactStatusSelect",
    "contactOutcomeSelect",
    "lead_source",
    "created_at",
    "date_of_contact",
    "communication_type",
    "do_not_email"
  ]);
  rightCol.appendChild(lead.section);

  const notes = createContactDetailsSection("Notes", "", "contact-section-notes");
  appendContactDetailsFields(notes.grid, ["notes", "special_notes", "tags"]);
  rightCol.appendChild(notes.section);

  const shell = document.createElement("div");
  shell.className = "contact-record-shell";
  const main = document.createElement("div");
  main.className = "contact-record-main";
  layout.replaceWith(shell);
  shell.appendChild(buildContactRecordNav());
  shell.appendChild(main);
  main.appendChild(layout);

  const hiddenSensitive = document.createElement("div");
  hiddenSensitive.hidden = true;
  hiddenSensitive.setAttribute("aria-hidden", "true");
  appendContactDetailsFields(hiddenSensitive, ["bank_routing", "bank_account", "ssn_last4"]);
  if (hiddenSensitive.childNodes.length) form.appendChild(hiddenSensitive);

  if (split) split.remove();

  const sticky = document.createElement("div");
  sticky.className = "contact-details-sticky-save";
  sticky.id = "contactDetailsStickySave";
  const stickyText = document.createElement("span");
  stickyText.className = "contact-details-sticky-save-label";
  stickyText.textContent = CONTACT_STICKY_SAVE_PENDING;
  sticky.appendChild(stickyText);
  if (saveBtn) sticky.appendChild(saveBtn);
  form.appendChild(sticky);
  contactDetailsStickySaveEl = sticky;
  contactDetailsStickyTextEl = stickyText;
  if (saveActions && saveActions !== sticky && !saveActions.children.length) saveActions.remove();
  document.documentElement.classList.add("contact-details-layout-ready");
  wireContactNotesResize();
  wireContactSectionNav();
  wireContactRecordLists();
  wireContactRecordModals();
  renderHouseholdMembers();
  renderContactQuotes();
}

const CONTACT_NOTES_DEFAULT_HEIGHT = { notes: 200, special_notes: 260 };

function applyContactNotesHeights() {
  Object.keys(CONTACT_NOTES_DEFAULT_HEIGHT).forEach((id) => {
    const ta = document.getElementById(id);
    if (!ta) return;
    const minH = CONTACT_NOTES_DEFAULT_HEIGHT[id];
    const contentH = Number(ta.scrollHeight) || 0;
    const next = Math.min(Math.max(contentH, minH), 900);
    ta.style.height = `${next}px`;
  });
}

function wireContactNotesResize() {
  Object.keys(CONTACT_NOTES_DEFAULT_HEIGHT).forEach((id) => {
    const ta = document.getElementById(id);
    if (!ta || ta.dataset.crmNotesResize === "1") return;
    ta.dataset.crmNotesResize = "1";
    ta.style.resize = "none";
    let wrap = ta.closest(".contact-notes-resize-wrap");
    if (!wrap) {
      wrap = document.createElement("div");
      wrap.className = "contact-notes-resize-wrap";
      ta.parentNode.insertBefore(wrap, ta);
      wrap.appendChild(ta);
    }
    if (!wrap.querySelector(".contact-notes-resize-handle")) {
      const handle = document.createElement("div");
      handle.className = "contact-notes-resize-handle";
      handle.setAttribute("role", "separator");
      handle.setAttribute("aria-orientation", "horizontal");
      handle.setAttribute("aria-label", "Drag to resize notes");
      handle.title = "Drag to resize";
      wrap.appendChild(handle);
      let startY = 0;
      let startH = 0;
      const onMove = (event) => {
        const point = event.touches ? event.touches[0] : event;
        if (!point) return;
        event.preventDefault();
        const next = Math.min(Math.max(startH + (point.clientY - startY), 140), 900);
        ta.style.height = `${next}px`;
      };
      const onUp = () => {
        document.removeEventListener("mousemove", onMove);
        document.removeEventListener("mouseup", onUp);
        document.removeEventListener("touchmove", onMove);
        document.removeEventListener("touchend", onUp);
      };
      handle.addEventListener("mousedown", (event) => {
        event.preventDefault();
        startY = event.clientY;
        startH = ta.getBoundingClientRect().height;
        document.addEventListener("mousemove", onMove);
        document.addEventListener("mouseup", onUp);
      });
      handle.addEventListener(
        "touchstart",
        (event) => {
          const point = event.touches && event.touches[0];
          if (!point) return;
          startY = point.clientY;
          startH = ta.getBoundingClientRect().height;
          document.addEventListener("touchmove", onMove, { passive: false });
          document.addEventListener("touchend", onUp);
        },
        { passive: true }
      );
    }
  });
  applyContactNotesHeights();
}

function setContactStickySaveBarState(saved) {
  if (!contactDetailsStickySaveEl || !contactDetailsStickyTextEl) return;
  const isSaved = saved === true;
  contactDetailsStickySaveEl.classList.toggle("is-saved", isSaved);
  contactDetailsStickyTextEl.textContent = isSaved ? CONTACT_STICKY_SAVE_SAVED : CONTACT_STICKY_SAVE_PENDING;
}

function wireContactStickySaveDirtyTracking() {
  if (!form || form.dataset.stickySaveWired === "1") return;
  form.dataset.stickySaveWired = "1";
  const markDirty = () => setContactStickySaveBarState(false);
  form.addEventListener("input", markDirty);
  form.addEventListener("change", markDirty);
}

function setInlineValidation(input, state, message) {
  const box = input?.closest(".contact-field-box");
  if (!box) return;
  let hint = box.querySelector(".contact-inline-validation");
  if (!hint) {
    hint = document.createElement("div");
    hint.className = "contact-inline-validation";
    box.appendChild(hint);
  }
  box.classList.remove("contact-field-valid", "contact-field-invalid");
  if (!state) {
    hint.textContent = "";
    return;
  }
  box.classList.add(state === "valid" ? "contact-field-valid" : "contact-field-invalid");
  hint.textContent = message;
}

function contactPhoneDigits(value) {
  return String(value || "").replace(/\D/g, "");
}

function isUsContactPhone(value) {
  const digits = contactPhoneDigits(value);
  return digits.length === 10 || (digits.length === 11 && digits.startsWith("1"));
}

function formatUsContactPhoneDisplay(value) {
  const digits = contactPhoneDigits(value);
  let local = digits;
  if (digits.length === 11 && digits.startsWith("1")) local = digits.slice(1);
  if (local.length !== 10) return String(value || "").trim();
  return `+1 (${local.slice(0, 3)}) ${local.slice(3, 6)}-${local.slice(6)}`;
}

function normalizeContactPhoneForSave(value) {
  const raw = String(value || "").trim();
  if (!raw) return "";
  if (isUsContactPhone(raw)) {
    const digits = contactPhoneDigits(raw);
    return digits.length === 11 && digits.startsWith("1") ? digits.slice(1) : digits;
  }
  return raw;
}

function isValidContactEmail(value) {
  const email = String(value || "").trim().toLowerCase();
  if (!email || email.length > 254 || email.includes("..") || email.endsWith(".")) return false;
  const parts = email.split("@");
  if (parts.length !== 2 || !parts[0] || !parts[1]) return false;
  const [local, domain] = parts;
  if (local.startsWith(".") || local.endsWith(".")) return false;
  if (!/^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+$/i.test(local)) return false;
  if (!/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}$/i.test(domain)) return false;
  const tld = domain.split(".").pop();
  return !["con", "cmo", "comm"].includes(tld);
}

function validateContactField(input, options = {}) {
  if (!input) return true;
  const format = Boolean(options.format);
  const value = String(input.value || "").trim();
  if (!value) {
    setInlineValidation(input, "", "");
    return true;
  }
  if (input.id === "email") {
    const ok = isValidContactEmail(value);
    setInlineValidation(input, ok ? "valid" : "invalid", ok ? "Looks good." : "Enter a valid email address.");
    return ok;
  }
  if (input.id === "primary_phone" || input.id === "secondary_phone") {
    const digits = contactPhoneDigits(value);
    const usOk = isUsContactPhone(value);
    const intlOk =
      !usOk &&
      (value.startsWith("+") || digits.length > 11) &&
      digits.length >= 8 &&
      digits.length <= 15;
    const ok = usOk || intlOk;
    if (ok && usOk && format) {
      const formatted = formatUsContactPhoneDisplay(value);
      if (formatted && formatted !== input.value) input.value = formatted;
    }
    setInlineValidation(
      input,
      ok ? "valid" : "invalid",
      ok
        ? usOk
          ? "Looks good — U.S. number (+1)."
          : "Looks good."
        : "Enter a 10-digit U.S. number. Country code 1 is added automatically."
    );
    return ok;
  }
  if (input.id === "zip_code") {
    const ok = /^\d{5}(-?\d{4})?$/.test(value);
    setInlineValidation(input, ok ? "valid" : "invalid", ok ? "Looks good." : "ZIP should be 5 digits.");
    return ok;
  }
  if (input.id === "date_of_birth") {
    const date = new Date(`${value}T00:00:00`);
    const ok = Number.isFinite(date.getTime()) && date <= new Date();
    setInlineValidation(input, ok ? "valid" : "invalid", ok ? "Looks good." : "Date of birth cannot be in the future.");
    return ok;
  }
  return true;
}

function wireContactDetailsValidation() {
  if (!form || form.dataset.validationWired === "1") return;
  form.dataset.validationWired = "1";
  ["email", "primary_phone", "secondary_phone", "zip_code", "date_of_birth"].forEach((id) => {
    const input = document.getElementById(id);
    if (!input) return;
    input.addEventListener("input", () => validateContactField(input));
    input.addEventListener("blur", () => validateContactField(input, { format: true }));
  });
}

if (backBtn) {
  backBtn.addEventListener("click", () => {
    window.location.href = "/index.html";
  });
}

if (contactPageHeadingText) contactPageHeadingText.textContent = "Contact Details";
else if (contactPageHeading) contactPageHeading.textContent = "Contact Details";
document.title = "Cadence Contact Details";
if (contactNavActiveText) contactNavActiveText.textContent = "Contact Details";
if (contactSummaryPanel) {
  contactSummaryPanel.style.display = "none";
  contactSummaryPanel.querySelectorAll("lottie-player").forEach((el) => {
    try {
      el.removeAttribute("autoplay");
      if (typeof el.pause === "function") el.pause();
      el.remove();
    } catch {
      /* lottie-player can throw when hidden: Cannot read properties of null (reading 'element') */
    }
  });
}
document.body.classList.add("contact-full-mode");
document.body.classList.remove("contact-summary-mode");
try {
  enhanceContactDetailsLayout();
  wireContactDetailsValidation();
  wireContactStickySaveDirtyTracking();
} catch (err) {
  console.error("contact details layout:", err);
  revealContactDetailsLayout();
}
window.setTimeout(revealContactDetailsLayout, 8000);

if (openFullDetailsBtn) {
  openFullDetailsBtn.addEventListener("click", () => {
    const id = activeContact?.id || parseContactId();
    if (!id) return;
    window.location.href = `/contact.html?id=${encodeURIComponent(String(id))}&full=1`;
  });
}

if (jumpToAiPanelBtn) {
  jumpToAiPanelBtn.addEventListener("click", () => {
    window.location.href = "/assistant.html";
  });
}

(function wireContactSummaryWorkspaceChrome() {
  const workspace = document.getElementById("contactSummaryWorkspace");
  const aiColumn = document.getElementById("contactSummaryAiColumn");
  const aiToggle = document.getElementById("contactSummaryAiToggle");
  const historyPanel = document.getElementById("contactHistoryPanel");
  const notesEl = document.getElementById("contactSummaryNotes");
  const specialNotesEl = document.getElementById("contactSummarySpecialNotes");
  let userToggledAi = false;

  function setAiCollapsed(collapsed) {
    if (!aiColumn || !workspace || !aiToggle) return;
    aiColumn.classList.toggle("is-collapsed", collapsed);
    workspace.classList.toggle("is-ai-collapsed", collapsed);
    aiToggle.setAttribute("aria-expanded", collapsed ? "false" : "true");
    aiToggle.textContent = collapsed ? "Show AI" : "Hide AI";
  }

  function syncAiColumnToViewport() {
    if (userToggledAi || isFullDetailsMode) return;
    setAiCollapsed(window.innerWidth < 1200);
  }

  if (aiToggle && aiColumn && workspace && !isFullDetailsMode) {
    setAiCollapsed(window.innerWidth < 1200);
    aiToggle.addEventListener("click", () => {
      userToggledAi = true;
      setAiCollapsed(!aiColumn.classList.contains("is-collapsed"));
    });
    window.addEventListener("resize", syncAiColumnToViewport);
  }

  document.querySelectorAll(".contact-ai-tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      const name = tab.getAttribute("data-ai-tab");
      document.querySelectorAll(".contact-ai-tab").forEach((btn) => {
        const active = btn === tab;
        btn.classList.toggle("is-active", active);
        btn.setAttribute("aria-selected", active ? "true" : "false");
      });
      document.querySelectorAll(".contact-ai-tab-panel").forEach((panel) => {
        panel.hidden = panel.getAttribute("data-ai-panel") !== name;
      });
    });
  });

  if (historyPanel) {
    historyPanel.addEventListener("click", (event) => {
      const btn = event.target && event.target.closest ? event.target.closest("[data-history-filter]") : null;
      if (!btn || !historyPanel.contains(btn)) return;
      const filter = btn.getAttribute("data-history-filter") || "all";
      historyPanel.setAttribute("data-history-filter", filter);
      historyPanel.querySelectorAll(".contact-history-filter").forEach((item) => {
        item.classList.toggle("is-active", item === btn);
      });
    });
  }

  function handleNotesClick(event) {
    const sensitive = event.target && event.target.closest ? event.target.closest(".contact-summary-note-sensitive") : null;
    if (sensitive) {
      event.preventDefault();
      const raw = sensitive.getAttribute("data-sensitive-value") || "";
      sensitive.textContent = raw || "-";
      sensitive.classList.add("is-revealed");
      return;
    }
    const toggle = event.target && event.target.closest ? event.target.closest(".contact-summary-notes-toggle") : null;
    if (!toggle) return;
    event.preventDefault();
    const host = toggle.closest("#contactSummaryNotes, #contactSummarySpecialNotes") || notesEl;
    if (!host) return;
    const expanded = host.dataset.notesExpanded === "1";
    host.dataset.notesExpanded = expanded ? "0" : "1";
    host.innerHTML = renderSummaryNotesHtml(host.dataset.rawNotes || "", { expanded: !expanded });
  }

  if (notesEl) notesEl.addEventListener("click", handleNotesClick);
  if (specialNotesEl) specialNotesEl.addEventListener("click", handleNotesClick);
})();

if (backToSummaryBtn) {
  backToSummaryBtn.style.display = "none";
}

if (contactTaskNewBtn && contactTaskForm) {
  contactTaskNewBtn.addEventListener("click", () => {
    contactTaskForm.classList.toggle("hidden");
  });
}

async function submitContactTask(event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  if (!contactTaskForm) return;
  if (!activeContact?.id) {
    showSectionSaveMessage(contactTaskSaveMessageEl, "Open a saved contact first, then add the task.", true, "task");
    return;
  }
  const taskNameEl = document.getElementById("contactTaskName");
  const taskActionEl = document.getElementById("contactTaskAction");
  const taskDateEl = document.getElementById("contactTaskDate");
  const taskTimeEl = document.getElementById("contactTaskTime");
  const taskConditionEl = document.getElementById("contactTaskCondition");
  const taskName = String(taskNameEl?.value || "").trim();
  if (!taskName) {
    showSectionSaveMessage(contactTaskSaveMessageEl, "Task name is required.", true, "task");
    if (taskNameEl && typeof taskNameEl.focus === "function") taskNameEl.focus();
    return;
  }
  try {
    const payload = {
      task_name: taskName,
      action_type: String(taskActionEl?.value || "Other").trim() || "Other",
      task_date: String(taskDateEl?.value || "").trim(),
      task_time: String(taskTimeEl?.value || "").trim(),
      condition: String(taskConditionEl?.value || "In Progress").trim() || "In Progress"
    };
    const { response, data } = await fetchApiJson(`/api/contacts/${activeContact.id}/tasks`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (!response.ok) throw new Error(data.error || "Failed to save task");
    showSectionSaveMessage(contactTaskSaveMessageEl, "Task saved", false, "task");
    if (taskNameEl) taskNameEl.value = "";
    if (taskActionEl) taskActionEl.value = "Other";
    if (taskDateEl) taskDateEl.value = "";
    if (taskTimeEl) taskTimeEl.value = "";
    if (taskConditionEl) taskConditionEl.value = "In Progress";
    await loadTasks();
  } catch (error) {
    showSectionSaveMessage(contactTaskSaveMessageEl, error.message || "Failed to save task.", true, "task");
  }
}

if (contactTaskForm) {
  contactTaskForm.addEventListener("submit", submitContactTask);
}

if (contactTaskSaveBtn) {
  contactTaskSaveBtn.addEventListener("click", submitContactTask);
}
window.__crmSaveTask = submitContactTask;

if (contactTaskForm) {
  contactTaskForm.addEventListener("keydown", (event) => {
    if (event.key !== "Enter") return;
    const target = event.target;
    if (target && target.tagName === "TEXTAREA") return;
    submitContactTask(event);
  });
}

if (contactTasksList) {
  contactTasksList.addEventListener("click", async (event) => {
    const btn = event.target && event.target.closest ? event.target.closest(".contact-task-complete-btn") : null;
    if (!btn) return;
    const taskId = Number(btn.getAttribute("data-task-id"));
    if (!Number.isInteger(taskId) || taskId < 1) return;
    btn.disabled = true;
    try {
      await markTaskCompleted(taskId);
      showMessage("Task marked as completed.");
      await loadTasks();
    } catch (error) {
      showMessage(error.message || "Failed to mark task completed.", true);
      btn.disabled = false;
    }
  });
}

if (contactHistoryLoadMoreBtn) {
  contactHistoryLoadMoreBtn.addEventListener("click", async () => {
    try {
      await loadMoreHistory();
    } catch (error) {
      showMessage(error.message || "Failed to load more history.", true);
      contactHistoryLoadMoreBtn.disabled = false;
    }
  });
}

if (form) form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const fieldsToValidate = ["email", "primary_phone", "secondary_phone", "zip_code", "date_of_birth"].map((id) =>
    document.getElementById(id)
  );
  if (!fieldsToValidate.every((input) => validateContactField(input))) {
    showMessage("Please fix the highlighted fields before saving.", true);
    return;
  }
  const payload = Object.fromEntries(new FormData(form).entries());
  /* Long-text fields can be missed by FormData when their resize handle has been used
     (the textarea collection sometimes reads stale .value). Always pull the live value
     directly from the DOM so Special Notes and Call Back Notes persist reliably. */
  const notesEl = document.getElementById("notes");
  const specialNotesEl = document.getElementById("special_notes");
  const mergedNotes = normalizeCallbackNotes(notesEl?.value || activeContact?.notes || "");
  if (notesEl) notesEl.value = mergedNotes;
  payload.notes = mergedNotes;
  if (specialNotesEl && typeof specialNotesEl.value === "string") {
    payload.special_notes = specialNotesEl.value;
  }
  const appIdEl = document.getElementById("app_id");
  if (appIdEl && typeof appIdEl.value === "string") {
    payload.app_id = String(appIdEl.value || "").trim();
  }
  if (document.querySelector("[data-custom-merge-key]")) {
    payload.custom_fields = collectContactCustomFieldValues();
  }
  const id = Number(payload.id);
  const first = String(payload.first_name || "").trim();
  const middle = String(payload.middle_name || "").trim();
  const last = String(payload.last_name || "").trim();
  payload.middle_name = middle;
  payload.full_name = joinContactName(first, middle, last);
  payload.phone = normalizeContactPhoneForSave(payload.primary_phone);
  payload.secondary_phone = normalizeContactPhoneForSave(payload.secondary_phone);
  payload.commission = formatCommissionValue(payload.commission);
  payload.quote = formatCommissionValue(payload.quote);
  payload.income = formatIncomeValue(payload.income);
  /* Unchecked checkboxes are absent from FormData — send an explicit value so
     clearing the opt-out actually saves. */
  payload.do_not_email = form.elements.do_not_email?.checked ? "1" : "";
  payload.renewal_interval = String(form.elements.renewal_interval?.value || "").trim();
  payload.household_members = householdMembers;
  if (contactQuotes.length) {
    const currentQuote = contactQuotes.find((quote) => quote.current);
    if (currentQuote) {
      const livePremium = formatCommissionValue(payload.quote);
      if (livePremium) currentQuote.premium = livePremium;
      else payload.quote = formatCommissionValue(currentQuote.premium);
    }
  }
  payload.quotes = contactQuotes;
  delete payload.id;
  delete payload.first_name;
  delete payload.last_name;
  delete payload.primary_phone;
  delete payload.created_at;
  if (!payload.full_name) {
    showMessage("First name is required.", true);
    return;
  }
  const { response, data } = await fetchApiJson(`/api/contacts/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  if (!response.ok) throw new Error(data.error || "Failed to update contact");
  setContactStickySaveBarState(true);
  showMessage(`Updated contact #${data.id}`);
  fillForm(data);
  await loadHistory();
});

if (followUpReminderEnterBtn) {
  followUpReminderEnterBtn.addEventListener("click", async () => {
    if (!activeContact?.id || !form) return;
    const payload = {
      follow_up_date: String(form.elements.follow_up_date?.value || "").trim(),
      follow_up_time: String(form.elements.follow_up_time?.value || "").trim()
    };
    try {
      const { response, data } = await fetchApiJson(`/api/contacts/${activeContact.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!response.ok) throw new Error(data.error || "Failed to set follow-up reminder");
      showSectionSaveMessage(followUpSaveMessageEl, "Follow-up saved", false, "followUp");
      fillForm(data);
      await loadHistory();
    } catch (error) {
      showSectionSaveMessage(followUpSaveMessageEl, error.message || "Failed to save follow-up.", true, "followUp");
    }
  });
}

const followUpDateInput = form?.elements?.follow_up_date || null;
const followUpTimeInput = form?.elements?.follow_up_time || null;
const handleFollowUpEnter = (event) => {
  if (event.key !== "Enter" || !followUpReminderEnterBtn) return;
  event.preventDefault();
  followUpReminderEnterBtn.click();
};
if (followUpDateInput) followUpDateInput.addEventListener("keydown", handleFollowUpEnter);
if (followUpTimeInput) followUpTimeInput.addEventListener("keydown", handleFollowUpEnter);

if (form && form.elements.commission) {
  form.elements.commission.addEventListener("blur", () => {
    form.elements.commission.value = formatCommissionValue(form.elements.commission.value);
  });
}
if (form && form.elements.quote) {
  form.elements.quote.addEventListener("blur", () => {
    form.elements.quote.value = formatCommissionValue(form.elements.quote.value);
  });
}
if (form && form.elements.income) {
  form.elements.income.addEventListener("blur", () => {
    form.elements.income.value = formatIncomeValue(form.elements.income.value);
  });
}

if (smsBtn) smsBtn.addEventListener("click", async () => {
  if (!activeContact) return;
  openContactTwilioSmsModal();
});
if (summarySmsBtn) summarySmsBtn.addEventListener("click", async () => {
  if (!activeContact) return;
  openContactTwilioSmsModal();
});

/* =========================================================================
   Click-to-WhatsApp (zero-API path).
   Builds a wa.me link from the contact's primary phone and a friendly default
   greeting that uses the first name when we have one, then opens it in a new
   tab. wa.me bounces the user into WhatsApp Web on desktop, or the WhatsApp
   app on mobile, with the recipient and draft text already filled in.

   Notes:
     - This sends from the AGENT's own WhatsApp account, not from Cadence.
       Nothing is logged in the contact's history because the message never
       passes through our backend.
     - wa.me requires the phone in international format WITHOUT the leading
       "+" and stripped of any spaces, dashes, or parens.
   ========================================================================= */
function normalizePhoneForWaMe(raw) {
  const digits = String(raw || "").replace(/\D+/g, "");
  if (!digits) return "";
  if (digits.length === 10) return `1${digits}`;
  return digits;
}

function buildContactWhatsAppGreeting(contact) {
  const fullName = String(contact?.full_name || "").trim();
  const first = fullName ? fullName.split(/\s+/)[0] : "";
  return first ? `Hi ${first}, ` : "";
}

function openContactInWhatsApp() {
  if (!activeContact) return;
  const phone = normalizePhoneForWaMe(activeContact.phone);
  if (!phone) {
    showMessage("This contact has no phone number on file. Add one before opening WhatsApp.", true);
    return;
  }
  const greeting = buildContactWhatsAppGreeting(activeContact);
  // wa.me with empty text= still works; we only append when we have a draft.
  const params = greeting ? `?text=${encodeURIComponent(greeting)}` : "";
  const url = `https://wa.me/${phone}${params}`;
  const opened = window.open(url, "_blank");
  if (!opened) {
    showMessage("Couldn't open WhatsApp — check that pop-ups are allowed.", true);
    return;
  }
  try { opened.opener = null; } catch { /* ignore */ }
}

if (whatsAppBtn) {
  whatsAppBtn.addEventListener("click", openContactInWhatsApp);
}

const DEFAULT_HEALTHSHERPA_URL = "https://www.healthsherpa.com/sessions/new";

function buildHealthSherpaQuoteNotes(contact) {
  const lines = [];
  const name = String(contact?.full_name || "").trim();
  const zip = String(contact?.zip_code || "").trim();
  const dob = String(contact?.date_of_birth || "").trim();
  const household = String(contact?.household_size || "").trim();
  const gender = String(contact?.gender || "").trim();
  const state = String(contact?.state || "").trim();
  if (name) lines.push(`Name: ${name}`);
  if (zip) lines.push(`ZIP: ${zip}`);
  if (state) lines.push(`State: ${state}`);
  if (dob) lines.push(`DOB: ${dob}`);
  if (household) lines.push(`Household: ${household}`);
  if (gender) lines.push(`Gender: ${gender}`);
  return lines.join("\n");
}

function applyHealthSherpaUrlPlaceholders(url, contact) {
  const zip = encodeURIComponent(String(contact?.zip_code || "").trim());
  const state = encodeURIComponent(String(contact?.state || "").trim());
  return String(url || "")
    .replace(/\{zip\}/gi, zip)
    .replace(/\{state\}/gi, state);
}

async function resolveHealthSherpaUrl(contact) {
  let url = DEFAULT_HEALTHSHERPA_URL;
  try {
    const { response, data } = await fetchApiJson("/api/runtime/healthsherpa");
    if (response.ok && data?.url) url = String(data.url).trim() || url;
  } catch {
    /* use default */
  }
  return applyHealthSherpaUrlPlaceholders(url, contact);
}

async function copyHealthSherpaQuoteNotes(contact) {
  const notes = buildHealthSherpaQuoteNotes(contact);
  if (!notes || !navigator.clipboard || typeof navigator.clipboard.writeText !== "function") return notes;
  try {
    await navigator.clipboard.writeText(notes);
  } catch {
    /* clipboard may be blocked */
  }
  return notes;
}

async function openContactInHealthSherpa() {
  if (!activeContact) return;
  const url = await resolveHealthSherpaUrl(activeContact);
  const notes = await copyHealthSherpaQuoteNotes(activeContact);
  const opened = window.open(url, "_blank");
  if (!opened) {
    showMessage("Couldn't open HealthSherpa — check that pop-ups are allowed.", true);
    return;
  }
  try { opened.opener = null; } catch { /* ignore */ }
  showMessage(
    notes
      ? "HealthSherpa opened in a new tab. ZIP and household details were copied — paste them into the quoter, then save the premium in Quote."
      : "HealthSherpa opened in a new tab. Add ZIP and household details on the contact to copy them next time."
  );
}

if (summaryHealthSherpaBtn) summaryHealthSherpaBtn.addEventListener("click", () => {
  openContactInHealthSherpa().catch((err) => showMessage(err.message || "Could not open HealthSherpa.", true));
});
if (pageHealthSherpaBtn) pageHealthSherpaBtn.addEventListener("click", () => {
  openContactInHealthSherpa().catch((err) => showMessage(err.message || "Could not open HealthSherpa.", true));
});

const DEFAULT_THANKS_IO_URL = "https://thanks.io";

function buildThanksIoMailingNotes(contact) {
  const name = String(contact?.full_name || "").trim();
  const street = String(contact?.home_address || "").trim();
  const city = String(contact?.city || "").trim();
  const state = String(contact?.state || "").trim();
  const zip = String(contact?.zip_code || "").trim();
  const cityLine = [city, state].filter(Boolean).join(", ");
  const lines = [];
  if (name) lines.push(name);
  if (street) lines.push(street);
  if (cityLine || zip) lines.push([cityLine, zip].filter(Boolean).join(" "));
  return lines.join("\n");
}

async function copyThanksIoMailingNotes(contact) {
  const notes = buildThanksIoMailingNotes(contact);
  if (!notes) return "";
  try {
    await navigator.clipboard.writeText(notes);
    return notes;
  } catch {
    return notes;
  }
}

async function openContactInThanksIo() {
  if (!activeContact) return;
  let url = DEFAULT_THANKS_IO_URL;
  try {
    const { response, data } = await fetchApiJson("/api/thanksio/config");
    if (response.ok && data?.appUrl) url = String(data.appUrl).trim() || url;
  } catch {
    /* default */
  }
  const notes = await copyThanksIoMailingNotes(activeContact);
  const opened = window.open(url, "_blank", "noopener,noreferrer");
  if (!opened) {
    showMessage("Couldn't open Thanks.io — check that pop-ups are allowed.", true);
    return;
  }
  showMessage(
    notes
      ? "Thanks.io opened in a new tab. The mailing address was copied — paste it into the recipient."
      : "Thanks.io opened in a new tab. Add a home address on this contact to copy it next time."
  );
}

if (pageThanksIoBtn) {
  pageThanksIoBtn.addEventListener("click", () => {
    openContactInThanksIo().catch((err) => showMessage(err.message || "Could not open Thanks.io.", true));
  });
}

if (emailBtn) {
  emailBtn.addEventListener("click", async () => {
    if (!activeContact) return;
    openEmailPage([activeContact.id]);
  });
}
if (summaryEmailBtn) {
  summaryEmailBtn.addEventListener("click", async () => {
    if (!activeContact) return;
    openEmailPage([activeContact.id]);
  });
}

if (callBtn) callBtn.addEventListener("click", () => {
  if (!activeContact) return;
  openContactTwilioCallModal();
});
if (summaryCallBtn) summaryCallBtn.addEventListener("click", () => {
  if (!activeContact) return;
  openContactTwilioCallModal();
});

function openAddTagsModal() {
  if (!bulkTagsModal || !bulkTagsModalForm || !bulkTagsModalInput || !bulkTagsModalTitle || !bulkTagsModalSubmitBtn) {
    return Promise.resolve("");
  }
  return new Promise((resolve) => {
    bulkTagsModalTitle.textContent = "Add Tags";
    bulkTagsModalSubmitBtn.textContent = "Add Tags";
    bulkTagsModalInput.value = "";
    bulkTagsModal.classList.remove("hidden");
    bulkTagsModal.setAttribute("aria-hidden", "false");
    requestAnimationFrame(() => bulkTagsModalInput.focus());

    const cleanup = () => {
      bulkTagsModalForm.removeEventListener("submit", onSubmit);
      if (bulkTagsModalCloseBtn) bulkTagsModalCloseBtn.removeEventListener("click", onCancel);
      bulkTagsModal.removeEventListener("click", onBackdrop);
    };
    const close = (value) => {
      cleanup();
      bulkTagsModal.classList.add("hidden");
      bulkTagsModal.setAttribute("aria-hidden", "true");
      resolve(String(value || "").trim());
    };
    const onSubmit = (event) => {
      event.preventDefault();
      close(String(bulkTagsModalInput.value || "").trim());
    };
    const onCancel = () => close("");
    const onBackdrop = (event) => {
      const target = event.target;
      if (target && target.getAttribute && target.getAttribute("data-close-bulk-tags-modal") === "1") {
        close("");
      }
    };

    bulkTagsModalForm.addEventListener("submit", onSubmit);
    if (bulkTagsModalCloseBtn) bulkTagsModalCloseBtn.addEventListener("click", onCancel);
    bulkTagsModal.addEventListener("click", onBackdrop);
  });
}

async function addTagsToActiveContact() {
  if (!activeContact?.id) return;
  const rawTags = await openAddTagsModal();
  if (!rawTags) return;
  const { response, data } = await fetchApiJson("/api/contacts/bulk-update", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ contactIds: [activeContact.id], addTags: rawTags })
  });
  if (!response.ok) throw new Error(data.error || "Failed to add tags");
  showMessage("Tags added.");
  await loadContact();
}

if (addCampaignBtn) {
  addCampaignBtn.addEventListener("click", async () => {
    try {
      await addTagsToActiveContact();
    } catch (error) {
      showMessage(error.message || "Failed to add tags.", true);
    }
  });
}

if (summaryAddCampaignBtn) {
  summaryAddCampaignBtn.addEventListener("click", async () => {
    try {
      await addTagsToActiveContact();
    } catch (error) {
      showMessage(error.message || "Failed to add tags.", true);
    }
  });
}

async function deleteActiveContact() {
  if (!activeContact?.id) return;
  const label = activeContact.full_name || `contact #${activeContact.id}`;
  if (!window.confirm(`Delete ${label}? They will move to the Recycle Bin and can be restored from there.`)) return;
  try {
    const { response, data } = await fetchApiJson("/api/contacts/bulk-delete", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contactIds: [Number(activeContact.id)] })
    });
    if (!response.ok) throw new Error(data?.error || "Failed to delete contact");
    const deleted = Number(data?.deleted ?? 0);
    if (deleted <= 0) throw new Error("Contact could not be deleted. Refresh and try again.");
    showMessage("Deleted contact.");
    setTimeout(() => {
      window.location.href = "/index.html";
    }, 300);
  } catch (error) {
    showMessage(error.message || "Failed to delete contact.", true);
  }
}

if (deleteBtn) deleteBtn.addEventListener("click", () => {
  deleteActiveContact();
});
if (summaryDeleteBtn) summaryDeleteBtn.addEventListener("click", () => {
  deleteActiveContact();
});

if (contactTwilioCallModalCloseBtn) {
  contactTwilioCallModalCloseBtn.addEventListener("click", closeContactTwilioCallModal);
}

if (contactTwilioCallModal) {
  contactTwilioCallModal.addEventListener("click", (event) => {
    const target = event.target;
    if (
      target &&
      target.getAttribute &&
      target.getAttribute("data-close-contact-twilio-call-modal") === "1"
    ) {
      closeContactTwilioCallModal();
    }
  });
}

if (contactTwilioSmsModalCloseBtn) {
  contactTwilioSmsModalCloseBtn.addEventListener("click", closeContactTwilioSmsModal);
}

if (contactTwilioSmsModal) {
  contactTwilioSmsModal.addEventListener("click", (event) => {
    const target = event.target;
    if (
      target &&
      target.getAttribute &&
      target.getAttribute("data-close-contact-twilio-sms-modal") === "1"
    ) {
      closeContactTwilioSmsModal();
    }
  });
}

if (contactHistoryEmailModalCloseBtn) {
  contactHistoryEmailModalCloseBtn.addEventListener("click", closeContactHistoryEmailModal);
}

if (contactHistoryEmailModal) {
  contactHistoryEmailModal.addEventListener("click", (event) => {
    const target = event.target;
    if (
      target &&
      target.getAttribute &&
      target.getAttribute("data-close-contact-history-email-modal") === "1"
    ) {
      closeContactHistoryEmailModal();
    }
  });
}

if (aiLeadScoreBtn) aiLeadScoreBtn.addEventListener("click", scoreActiveLead);
if (aiCallSummaryBtn) {
  aiCallSummaryBtn.addEventListener("mousedown", () => {
    aiCallSummaryNotesCommitLock = true;
    cancelAiCallSummaryNotesBlurCommit();
  });
  aiCallSummaryBtn.addEventListener("mouseup", () => {
    aiCallSummaryNotesCommitLock = false;
  });
  aiCallSummaryBtn.addEventListener("mouseleave", () => {
    aiCallSummaryNotesCommitLock = false;
  });
  aiCallSummaryBtn.addEventListener("click", summarizeActiveCall);
}
if (aiObjectionCoachBtn) aiObjectionCoachBtn.addEventListener("click", coachActiveObjection);
if (aiCallSummaryNotes) {
  aiCallSummaryNotes.addEventListener("input", previewAiCallSummaryNotesInContactDetails);
  aiCallSummaryNotes.addEventListener("blur", () => {
    if (aiCallSummaryNotesCommitLock) return;
    scheduleAiCallSummaryNotesBlurCommit();
  });
}

function contactSmsPhotoFile(form) {
  const input = form && form.querySelector('input[name="photo"]');
  const file = input && input.files && input.files[0];
  return file && file.size > 0 ? file : null;
}

function syncContactSmsPhotoName(form) {
  if (!form) return;
  const file = contactSmsPhotoFile(form);
  const nameEl = form.querySelector(".sms-photo-name");
  const clearBtn = form.querySelector(".sms-photo-clear");
  if (nameEl) {
    nameEl.textContent = file ? file.name : "";
    nameEl.hidden = !file;
  }
  if (clearBtn) clearBtn.hidden = !file;
}

if (contactTwilioSmsForm) {
  const photoInput = contactTwilioSmsForm.querySelector('input[name="photo"]');
  const photoClear = contactTwilioSmsForm.querySelector(".sms-photo-clear");
  if (photoInput) photoInput.addEventListener("change", () => syncContactSmsPhotoName(contactTwilioSmsForm));
  if (photoClear) {
    photoClear.addEventListener("click", () => {
      if (photoInput) photoInput.value = "";
      syncContactSmsPhotoName(contactTwilioSmsForm);
    });
  }
  contactTwilioSmsForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = event.target;
    const phone = String((form.elements.phone && form.elements.phone.value) || "").trim();
    const body = String((form.elements.body && form.elements.body.value) || "").trim();
    let photo = contactSmsPhotoFile(form);
    if (photo && window.prepareSmsPhotoFile) {
      try {
        photo = await window.prepareSmsPhotoFile(photo);
      } catch (error) {
        showMessage(error.message, true);
        setContactTwilioSmsStatus(error.message, true);
        return;
      }
    }

    if (!phone) {
      const msg = "Phone number is required.";
      showMessage(msg, true);
      setContactTwilioSmsStatus(msg, true);
      return;
    }

    if (!body && !photo) {
      const msg = "Type a message or attach a photo.";
      showMessage(msg, true);
      setContactTwilioSmsStatus(msg, true);
      return;
    }

    if (photo && photo.size > 5 * 1024 * 1024) {
      const msg = "That photo is too large for a text. Use a picture under 5 MB.";
      showMessage(msg, true);
      setContactTwilioSmsStatus(msg, true);
      return;
    }

    const smsFromEl = document.getElementById("contactTwilioSmsFrom");
    const twilioFrom =
      (form.elements.twilioFrom && form.elements.twilioFrom.value) ||
      (smsFromEl && smsFromEl.value) ||
      (window.pickDefaultTwilioFromSelect && window.pickDefaultTwilioFromSelect(smsFromEl)) ||
      "primary";
    const formData = new FormData();
    formData.set("phone", phone);
    formData.set("body", body);
    formData.set("twilioFrom", twilioFrom);
    if (window.cadenceSmsEnding) formData.set("smsEnding", window.cadenceSmsEnding.fromForm(form));
    if (photo) formData.set("photo", photo);
    const contactId = Number(activeContact?.id);
    if (Number.isInteger(contactId) && contactId > 0) formData.set("contactId", String(contactId));
    try {
      const { response, data } = await fetchApiJson("/api/twilio/send-sms", {
        method: "POST",
        body: formData
      });
      if (!response.ok) throw new Error(data.error || "Failed to send SMS");
      showMessage(data.photoDropped ? "Text sent. The photo was left off so the message could go through." : `SMS sent. SID: ${data.sid}`);
      setContactTwilioSmsStatus(data.photoDropped ? "Text sent without the photo" : "Messaged Sent");
      form.reset();
      syncContactSmsPhotoName(form);
      if (window.cadenceSmsEnding) window.cadenceSmsEnding.apply();
      await loadHistory();
      if (contactTwilioSmsCloseTimer) clearTimeout(contactTwilioSmsCloseTimer);
      contactTwilioSmsCloseTimer = setTimeout(() => {
        closeContactTwilioSmsModal();
      }, 1000);
    } catch (error) {
      showMessage(error.message, true);
      setContactTwilioSmsStatus(error.message, true);
    }
  });
}

async function startContactRestDialOut(callPayload) {
  const { response, data } = await fetchApiJson("/api/twilio/start-call", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contactId: activeContact?.id,
      phone: callPayload.phone,
      twimlUrl: String(callPayload.twimlUrl || ""),
      twilioFrom: callPayload.twilioFrom,
      recordCall: contactTwilioCallRecord && contactTwilioCallRecord.checked,
      voiceProvider: "twilio"
    })
  });
  if (!response.ok) throw new Error(data.error || "Failed to start call");
  const callSid = String((data && (data.sid != null ? data.sid : data.callSid)) || "").trim();
  if (!callSid) throw new Error("Server did not return a call SID.");
  showMessage(`Calling the contact. SID: ${callSid}`);
  setContactTwilioCallStatus("Ringing the contact...");
  startContactTwilioCallStatusPolling(callSid);
  await loadHistory();
  return callSid;
}

if (contactTwilioCallForm) {
  contactTwilioCallForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    setContactTwilioCallStatus("Starting call...");
    const payload = Object.fromEntries(new FormData(event.target).entries());
    delete payload.contactName;
    payload.phone = String(payload.phone || "").trim();
    const callFromEl = document.getElementById("contactTwilioCallFrom") || document.getElementById("contactTwilioSmsFrom");
    if (!payload.twilioFrom) {
      payload.twilioFrom =
        (callFromEl && callFromEl.value) ||
        (window.pickDefaultTwilioFromSelect && window.pickDefaultTwilioFromSelect(callFromEl)) ||
        "primary";
    }
    if (!payload.phone) {
      showMessage("Phone number is required.", true);
      setContactTwilioCallStatus("Phone number is required.", true);
      return;
    }
    payload.voiceProvider = "twilio";
    const useHeadset =
      contactTwilioCallUseHeadset && contactTwilioCallUseHeadset.checked && window.CrmTwilioVoice;
    try {
      if (useHeadset) {
        // Unlock browser audio playback inside the click gesture so the
        // autoplay policy does not silently mute the remote call audio.
        if (typeof CrmTwilioVoice.unlockAudioPlayback === "function") {
          CrmTwilioVoice.unlockAudioPlayback();
        }
        const toNorm = CrmTwilioVoice.normalizePhoneForTwilio(payload.phone);
        if (!toNorm.startsWith("+")) {
          showMessage("Enter a 10-digit U.S. number or a full number with country code.", true);
          setContactTwilioCallStatus("Enter a valid phone number.", true);
          return;
        }
        payload.phone = toNorm;
        const fetchCfg =
          typeof CrmTwilioVoice.fetchVoiceConfig === "function"
            ? () => CrmTwilioVoice.fetchVoiceConfig()
            : () => fetch("/api/twilio/voice-config").then((r) => (r.ok ? r.json() : {}));
        const voiceCfg = await fetchCfg();
        try {
          let recordCall = contactTwilioCallRecord && contactTwilioCallRecord.checked;
          if (recordCall && !voiceCfg.recordingReady) {
            showMessage(
              "Recording needs HTTPS CRM Public URL in Settings → Runtime. Starting call without recording.",
              true
            );
            recordCall = false;
          }
          let browserCallSid = "";
          let browserCallLogged = false;
          const logBrowserCallToHistory = async () => {
            if (browserCallLogged) return;
            browserCallSid =
              typeof CrmTwilioVoice.getBrowserCallSid === "function" ? CrmTwilioVoice.getBrowserCallSid() : "";
            const { response, data } = await fetchApiJson("/api/twilio/notify-browser-call", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                contactId: activeContact?.id,
                phone: toNorm,
                callSid: browserCallSid,
                recordCall
              })
            });
            if (!response.ok) {
              throw new Error(data.error || "Could not log call to contact history.");
            }
            browserCallLogged = true;
            await loadHistory();
          };
          const call = await CrmTwilioVoice.connectCall({
            to: toNorm,
            twilioFrom: payload.twilioFrom,
            recordCall,
            contactId: activeContact?.id,
            onRinging: () => {
              logBrowserCallToHistory().catch((logErr) => console.warn("Call history log:", logErr));
            }
          });
          showMessage("Call started (this computer). Allow the mic if prompted.");
          setContactTwilioCallStatus("Connecting...");
          activeContactTwilioCallMode = "browser";
          let browserCallConnected = false;
          let browserCallRinging = false;
          const reportComputerAudioFailed = (detail) => {
            activeContactTwilioCallMode = "";
            if (typeof clearAudioDiag === "function") clearAudioDiag();
            if (window.CrmTwilioVoice && typeof CrmTwilioVoice.disconnectActive === "function") {
              CrmTwilioVoice.disconnectActive();
            }
            if (window.CrmTwilioVoice && typeof CrmTwilioVoice.releaseCallMedia === "function") {
              CrmTwilioVoice.releaseCallMedia();
            }
            const msg = detail || "Computer audio failed. This call stays on this computer and does not ring your cell.";
            showMessage(msg, true);
            setContactTwilioCallStatus(msg, true);
          };
          // Live audio diagnostic: watch real mic + speaker levels so we can
          // tell whether audio is actually flowing in each direction.
          let micSeen = false;
          let remoteSeen = false;
          let audioVerdictTimer = null;
          let lastAudioLabel = "";
          const clearAudioDiag = () => {
            if (audioVerdictTimer) {
              clearTimeout(audioVerdictTimer);
              audioVerdictTimer = null;
            }
            if (typeof CrmTwilioVoice.setOnVolume === "function") CrmTwilioVoice.setOnVolume(null);
          };
          const renderAudioStatus = () => {
            if (!browserCallConnected) return;
            const mic = micSeen ? "mic ✓" : "mic …";
            const spk = remoteSeen ? "speaker ✓" : "speaker …";
            const label = `On Call · ${mic} · ${spk}`;
            if (label !== lastAudioLabel) {
              lastAudioLabel = label;
              setContactTwilioCallStatus(label);
            }
          };
          if (typeof CrmTwilioVoice.setOnVolume === "function") {
            CrmTwilioVoice.setOnVolume((input, output) => {
              if (input > 0.02) micSeen = true;
              if (output > 0.02) remoteSeen = true;
              renderAudioStatus();
            });
          }
          const formatBrowserCallError =
            typeof CrmTwilioVoice.formatCallError === "function"
              ? (err) => CrmTwilioVoice.formatCallError(err)
              : (err) => String((err && err.message) || "Browser audio failed.");
          call.on("ringing", () => {
            browserCallRinging = true;
            setContactTwilioCallStatus("Ringing...");
          });
          call.on("accept", async () => {
            browserCallConnected = true;
            setContactTwilioCallStatus("On Call");
            try {
              await logBrowserCallToHistory();
            } catch (logErr) {
              console.warn("Call history log:", logErr);
            }
            // After ~7s of real talk time, if a direction is still silent,
            // tell the user exactly which side is the problem.
            if (audioVerdictTimer) clearTimeout(audioVerdictTimer);
            audioVerdictTimer = setTimeout(() => {
              if (!browserCallConnected) return;
              if (!micSeen && !remoteSeen) {
                const m =
                  "Connected, but no call audio is flowing. This is almost always a VPN or security software blocking call audio (e.g. Avast SecureLine VPN, NordVPN, or an antivirus firewall). Turn off your VPN and call again. If you don't use a VPN, try a phone hotspot.";
                setContactTwilioCallStatus(m, true);
                showMessage(m, true);
              } else if (!remoteSeen) {
                const m =
                  "You're not hearing the caller. This is almost always a VPN or security software blocking incoming call audio (e.g. Avast SecureLine VPN, NordVPN, or an antivirus firewall). Turn off your VPN and call again. If you don't use a VPN, make sure your headset is the Windows playback device.";
                setContactTwilioCallStatus(m, true);
                showMessage(m, true);
              } else if (!micSeen) {
                const m =
                  "Your microphone isn't being picked up. In Windows sound settings choose your headset mic as the input device, allow mic access for the browser, then call again.";
                setContactTwilioCallStatus(m, true);
                showMessage(m, true);
              }
            }, 7000);
          });
          call.on("error", (err) => {
            const msg = formatBrowserCallError(err);
            if (!browserCallConnected && !browserCallRinging) {
              reportComputerAudioFailed(msg);
              return;
            }
            activeContactTwilioCallMode = "";
            clearAudioDiag();
            setContactTwilioCallStatus(msg, true);
            showMessage(msg, true);
          });
          call.on("disconnect", async () => {
            clearAudioDiag();
            const wasConnected = browserCallConnected;
            const wasRinging = browserCallRinging;
            browserCallConnected = false;
            browserCallRinging = false;
            if (window.CrmTwilioVoice && typeof CrmTwilioVoice.releaseCallMedia === "function") {
              CrmTwilioVoice.releaseCallMedia();
            }
            if (!browserCallLogged && (wasConnected || wasRinging)) {
              try {
                await logBrowserCallToHistory();
              } catch (logErr) {
                console.warn("Call history log:", logErr);
              }
            }
            if (wasConnected || wasRinging) {
              finalizeContactTwilioCallUi("Call ended.");
            } else {
              reportComputerAudioFailed();
              return;
            }
            if (wasConnected || wasRinging) clearContactTwilioCallPhoneInput();
            if (browserCallLogged) {
              scheduleRecordingSync({ callSid: browserCallSid, phone: toNorm });
              await loadHistory();
            }
          });
          return;
        } catch (headsetError) {
          if (window.CrmTwilioVoice && typeof CrmTwilioVoice.releaseCallMedia === "function") {
            CrmTwilioVoice.releaseCallMedia();
          }
          activeContactTwilioCallMode = "";
          const msg = headsetError?.message || "Computer audio failed. This call stays on this computer and does not ring your cell.";
          showMessage(msg, true);
          setContactTwilioCallStatus(msg, true);
          return;
        }
      }
      showMessage("Turn on Use this computer for the call. Cadence does not ring your cell.", true);
      setContactTwilioCallStatus("Use this computer for the call.", true);
      return;
    } catch (error) {
      showMessage(error.message, true);
      setContactTwilioCallStatus(error.message, true);
    }
  });
}

if (contactTwilioEndCallBtn) {
  contactTwilioEndCallBtn.addEventListener("click", async () => {
    const preSdkSid =
      window.CrmTwilioVoice && typeof CrmTwilioVoice.getBrowserCallSid === "function"
        ? CrmTwilioVoice.getBrowserCallSid()
        : "";
    if (window.CrmTwilioVoice && typeof CrmTwilioVoice.disconnectActive === "function") {
      CrmTwilioVoice.disconnectActive();
    }
    const hangupSid = String(preSdkSid || activeContactTwilioCallSid || "").trim();
    if (!hangupSid) {
      finalizeContactTwilioCallUi("Call ended.");
      return;
    }
    try {
      const { response, data } = await fetchApiJson("/api/twilio/end-call", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sid: hangupSid })
      });
      if (!response.ok) throw new Error(data.error || "Failed to end call");
      showMessage("Call ended.");
      finalizeContactTwilioCallUi("");
      clearContactTwilioCallPhoneInput();
      const phone =
        contactTwilioCallForm?.elements?.phone?.value ||
        activeContact?.phone ||
        "";
      scheduleRecordingSync({ callSid: hangupSid, phone: String(phone || "").trim() });
      await loadHistory();
    } catch (error) {
      showMessage(error.message, true);
      setContactTwilioCallStatus(error.message, true);
    }
  });
}

async function fetchContactTwilioVoiceConfig() {
  if (window.CrmTwilioVoice && typeof CrmTwilioVoice.fetchVoiceConfig === "function") {
    return CrmTwilioVoice.fetchVoiceConfig();
  }
  const r = await fetch("/api/twilio/voice-config", { credentials: "include" });
  return r.ok ? r.json() : {};
}

function applyContactCallRecordingUi(cfg) {
  if (!contactTwilioCallRecord) return;
  const recordingReady = !!cfg.recordingReady;
  const recordHint = recordingReady
    ? "When checked, Twilio saves a recording. A play link appears in contact history when ready."
    : "Set your public CRM URL in Settings → Runtime (HTTPS). You can check this box; the server validates before the call.";
  contactTwilioCallRecord.disabled = false;
  contactTwilioCallRecord.title = recordHint;
  const label = contactTwilioCallRecord.closest("label");
  if (label) label.classList.toggle("twilio-record-opt--warn", !recordingReady);
  contactTwilioCallRecord.checked = cfg.callRecordingDefault !== false;
}

async function refreshContactTwilioHeadsetUi(options = {}) {
  const cfg = await fetchContactTwilioVoiceConfig();
  const hintEl = document.getElementById("contactTwilioHeadsetHint");
  let state = { ready: false };
  if (window.CrmTwilioVoice && typeof CrmTwilioVoice.applyHeadsetUi === "function") {
    state = CrmTwilioVoice.applyHeadsetUi({
      cfg,
      checkboxes: [contactTwilioCallUseHeadset].filter(Boolean),
      hintElements: [hintEl].filter(Boolean)
    });
    if (typeof CrmTwilioVoice.applyRestProviderUi === "function") {
      CrmTwilioVoice.applyRestProviderUi({
        cfg,
        selects: [document.getElementById("contactTwilioCallProvider")].filter(Boolean),
        boxes: [document.getElementById("contactTwilioCallProviderBox")].filter(Boolean)
      });
    }
  } else if (contactTwilioCallUseHeadset) {
    const ready = !!(cfg.browserCallReady || cfg.voiceApiCredentialsValid);
    contactTwilioCallUseHeadset.disabled = false;
    contactTwilioCallUseHeadset.checked = true;
    state = { ready };
  }
  applyContactCallRecordingUi(cfg);
  if (options.prewarm && state.ready && window.CrmTwilioVoice?.ensureDevice) {
    try {
      await window.CrmTwilioVoice.ensureDevice();
    } catch {
      // mic prompt may wait until Start Call
    }
  }
  return cfg;
}

(function initContactHeadsetOption() {
  if (!contactTwilioCallUseHeadset) return;
  refreshContactTwilioHeadsetUi().catch(() => {
    contactTwilioCallUseHeadset.disabled = false;
    contactTwilioCallUseHeadset.checked = true;
    contactTwilioCallUseHeadset.title =
      "Use this computer for call audio (mic / speakers / headset).";
    const hintEl = document.getElementById("contactTwilioHeadsetHint");
    if (hintEl) {
      hintEl.textContent =
        "Could not load computer-audio status. Refresh the page, then check Settings → Twilio and Settings → Runtime.";
      hintEl.classList.add("is-blocked");
    }
    if (contactTwilioCallRecord) {
      contactTwilioCallRecord.disabled = false;
      contactTwilioCallRecord.checked = true;
    }
  });
  contactTwilioCallUseHeadset.addEventListener("change", () => {
    if (window.CrmTwilioVoice && typeof CrmTwilioVoice.setUseHeadsetPreference === "function") {
      CrmTwilioVoice.setUseHeadsetPreference(contactTwilioCallUseHeadset.checked);
    }
  });
})();

(function wireContactTwilioFromPair() {
  const main = document.getElementById("contactTwilioFromSelect");
  const summary = document.getElementById("contactSummaryTwilioFromSelect");
  const call = document.getElementById("contactTwilioCallFrom");
  const sms = document.getElementById("contactTwilioSmsFrom");
  if ((!main && !summary) || !call || !window.mirrorTwilioFromSelect) return;
  const master = main || summary;
  const syncAll = () => {
    window.mirrorTwilioFromSelect(master, call);
    if (sms) window.mirrorTwilioFromSelect(master, sms);
    if (main && summary && summary !== master) window.mirrorTwilioFromSelect(master, summary);
    if (main && summary && main !== master) window.mirrorTwilioFromSelect(master, main);
  };
  if (main) main.addEventListener("change", () => {
    if (summary) window.mirrorTwilioFromSelect(main, summary);
    syncAll();
  });
  if (summary) summary.addEventListener("change", () => {
    if (main) window.mirrorTwilioFromSelect(summary, main);
    syncAll();
  });
  call.addEventListener("change", () => {
    window.mirrorTwilioFromSelect(call, master);
    if (main && main !== master) window.mirrorTwilioFromSelect(master, main);
    if (summary && summary !== master) window.mirrorTwilioFromSelect(master, summary);
  });
  if (sms) sms.addEventListener("change", () => {
    window.mirrorTwilioFromSelect(sms, master);
    if (main && main !== master) window.mirrorTwilioFromSelect(master, main);
    if (summary && summary !== master) window.mirrorTwilioFromSelect(master, summary);
  });
  syncAll();
})();

window.__crmSyncTwilioFromPairs = function syncContactTwilioFromPair() {
  const main = document.getElementById("contactTwilioFromSelect");
  const summary = document.getElementById("contactSummaryTwilioFromSelect");
  const call = document.getElementById("contactTwilioCallFrom");
  const sms = document.getElementById("contactTwilioSmsFrom");
  const master = main || summary;
  if (!master || !call || !window.mirrorTwilioFromSelect) return;
  window.mirrorTwilioFromSelect(master, call);
  if (sms) window.mirrorTwilioFromSelect(master, sms);
  if (main && summary) {
    window.mirrorTwilioFromSelect(master, main);
    window.mirrorTwilioFromSelect(master, summary);
  }
};

(async function bootContactPage() {
  try {
    if (window.CrmContactWorkspaceOptions?.reloadAndApply) {
      await window.CrmContactWorkspaceOptions.reloadAndApply(document);
    } else if (window.CrmContactWorkspaceOptions) {
      await window.CrmContactWorkspaceOptions.load(true);
      window.CrmContactWorkspaceOptions.applyAll(document);
    }
  } catch {
    /* fillForm falls back to applyContactPageForm with defaults */
  }
  await loadContact();
})().catch((e) => {
  revealContactDetailsLayout();
  showMessage(e.message, true);
});

if (contactHistoryList) {
  contactHistoryList.addEventListener("click", (event) => {
    const transcribeBtn =
      event.target && event.target.closest ? event.target.closest(".ai-transcribe-recording-btn") : null;
    if (transcribeBtn) {
      event.preventDefault();
      event.stopPropagation();
      transcribeRecording(String(transcribeBtn.getAttribute("data-recording-sid") || "").trim(), transcribeBtn).catch((e) =>
        showMessage(e.message, true)
      );
      return;
    }
    const showMoreBtn = event.target && event.target.closest ? event.target.closest(".contact-history-email-show-more") : null;
    if (showMoreBtn) {
      event.preventDefault();
      event.stopPropagation();
      try {
        const historyId = Number(showMoreBtn.getAttribute("data-history-id") || "");
        const payload = Number.isInteger(historyId) && historyId > 0 ? historyEmailPayloadById.get(historyId) : null;
        if (!payload) return;
        openContactHistoryEmailModal(payload);
      } catch {
        showMessage("Unable to open full email preview.", true);
      }
      return;
    }
    if (event.target && event.target.closest && event.target.closest(".crm-call-recording-player")) {
      return;
    }
    const actionsHit =
      event.target && event.target.closest ? event.target.closest(".contact-history-actions-hit") : null;
    if (actionsHit) {
      event.preventDefault();
      event.stopPropagation();
      const card = actionsHit.closest(".contact-history-item[data-history-id]");
      if (!card) return;
      activateHistoryCard(card, { forceActionsMenu: true });
      return;
    }
    const card = event.target && event.target.closest ? event.target.closest(".contact-history-item[data-history-id]") : null;
    if (!card) return;
    activateHistoryCard(card);
  });
  contactHistoryList.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" && event.key !== " ") return;
    const card = event.target && event.target.closest ? event.target.closest(".contact-history-item[data-history-id]") : null;
    if (!card) return;
    event.preventDefault();
    activateHistoryCard(card);
  });
}

if (contactSummaryRecordingsList) {
  contactSummaryRecordingsList.addEventListener("click", (event) => {
    const transcribeBtn =
      event.target && event.target.closest ? event.target.closest(".ai-transcribe-recording-btn") : null;
    if (!transcribeBtn) return;
    event.preventDefault();
    event.stopPropagation();
    transcribeRecording(String(transcribeBtn.getAttribute("data-recording-sid") || "").trim(), transcribeBtn).catch((e) =>
      showMessage(e.message, true)
    );
  });
}

if (contactHistoryActionPinBtn) {
  contactHistoryActionPinBtn.addEventListener("click", async (event) => {
    event.stopPropagation();
    try {
      const card = contactHistoryList?.querySelector(`.contact-history-item[data-history-id="${activeHistoryItemId}"]`);
      if (!card || !activeHistoryItemId) return;
      const isPinned = Number(card.getAttribute("data-pinned") || 0) === 1;
      await updateHistoryItem(activeHistoryItemId, { is_pinned: !isPinned });
      closeHistoryActionMenu();
      await loadHistory();
    } catch (error) {
      showMessage(error.message, true);
    }
  });
}

if (contactHistoryActionStarBtn) {
  contactHistoryActionStarBtn.addEventListener("click", async (event) => {
    event.stopPropagation();
    try {
      const card = contactHistoryList?.querySelector(`.contact-history-item[data-history-id="${activeHistoryItemId}"]`);
      if (!card || !activeHistoryItemId) return;
      const isStarred = Number(card.getAttribute("data-starred") || 0) === 1;
      await updateHistoryItem(activeHistoryItemId, { is_starred: !isStarred });
      closeHistoryActionMenu();
      await loadHistory();
    } catch (error) {
      showMessage(error.message, true);
    }
  });
}

if (contactHistoryActionDeleteBtn) {
  contactHistoryActionDeleteBtn.addEventListener("click", async (event) => {
    event.stopPropagation();
    try {
      if (!activeHistoryItemId) return;
      if (!window.confirm("Delete this history item?")) return;
      await deleteHistoryItem(activeHistoryItemId);
      closeHistoryActionMenu();
      await loadHistory();
    } catch (error) {
      showMessage(error.message, true);
    }
  });
}

document.addEventListener("click", (event) => {
  if (!contactHistoryActionMenu || contactHistoryActionMenu.classList.contains("hidden")) return;
  const target = event.target;
  const withinMenu = !!(target && target.closest && target.closest("#contactHistoryActionMenu"));
  const withinCard = !!(target && target.closest && target.closest(".contact-history-item[data-history-id]"));
  if (!withinMenu && !withinCard) {
    closeHistoryActionMenu();
  }
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    closeHistoryActionMenu();
    closeContactHistoryEmailModal();
    closeContactModal(document.getElementById("contactHouseholdModal"));
    closeContactModal(document.getElementById("contactQuoteModal"));
  }
});

window.addEventListener("scroll", closeHistoryActionMenu, true);
window.addEventListener("resize", closeHistoryActionMenu);
